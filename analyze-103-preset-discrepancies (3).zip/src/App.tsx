import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  Copy,
  Menu,
  Search,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { configAudit } from "./configReview";
import {
  auditApi,
  categoryLabels,
  currentRevision,
  findings,
  legacyRevision,
  previousRevision,
  repository,
  reviewSummary,
  reviewedBranch,
  sourceUrl,
  statusDescriptions,
  statusLabels,
  testCases,
  type Category,
  type Evidence,
  type Finding,
  type Status,
} from "./reportData";

type Filter = "all" | Category;

const navigation = [
  { id: "overview", number: "00", label: "审查概览" },
  { id: "scope", number: "01", label: "对照口径" },
  { id: "findings", number: "02", label: "问题清单" },
  { id: "crosswalk", number: "03", label: "联动断点" },
  { id: "api", number: "04", label: "26.1.2 API" },
  { id: "plan", number: "05", label: "实施顺序" },
  { id: "tests", number: "06", label: "验收矩阵" },
  { id: "config", number: "07", label: "配置页评估" },
  { id: "sources", number: "08", label: "证据边界" },
];

const filters: { id: Filter; label: string }[] = [
  { id: "all", label: "全部问题" },
  { id: "mechanic", label: categoryLabels.mechanic },
  { id: "economy", label: categoryLabels.economy },
  { id: "copy", label: categoryLabels.copy },
  { id: "content", label: categoryLabels.content },
];

const statusOrder: Status[] = ["fixed", "partial", "open"];

function statusClassName(status: Status) {
  return `status-${status}`;
}

const crosswalk: { key: string; effect: string; surface: string; target: string; status: Status; finding: string }[] = [
  {
    key: "classic103Mode / epiphany family",
    effect: "运行帧概率归零，handler 结果、槽位和付费全部关闭",
    surface: "主界面隐藏 + 服务端拒绝刷新/锁定",
    target: "保持多层门禁，防并行改动回退",
    status: "fixed",
    finding: "epiphany-gate",
  },
  {
    key: "classic103Mode / waitTicks = 0",
    effect: "结算阶段与 headless fallback 均强制零失误概率",
    surface: "即时完成，无抄错/串行",
    target: "补一个免磨损母本 + 遗留队列测试",
    status: "fixed",
    finding: "ritual-slip",
  },
  {
    key: "classic103Mode / salted cost",
    effect: "材料按玩家 salt，经典表按帧切换",
    surface: "行来源与 JEI/REI 都改为经典 full 语义",
    target: "统一 quote 对象，避免后续再分叉",
    status: "fixed",
    finding: "pricing-source",
  },
  {
    key: "classic103Mode / tab.inscribe.desc",
    effect: "实际按完整目标等级收费",
    surface: "附魔页签 tooltip 仍说“自动抵扣”",
    target: "新增 classic 页签说明键",
    status: "partial",
    finding: "incremental-copy",
  },
  {
    key: "classic overlay + synced cost row",
    effect: "服务器数据包可替换经典成本/升书/置换表",
    surface: "客户端 classic 分支先读本地表，再才查同步行",
    target: "先 syncedRow，后本地经典回退；XP 不写死",
    status: "open",
    finding: "overlay-sync",
  },
  {
    key: "classic profile / naming",
    effect: "主标题已改为玩法规则，但短名和状态条仍称原味",
    surface: "经典页可自定义后仍显示“已启用原汁原味模式”",
    target: "区分“完整预设”与“基于 1.0.3 的自定义规则”",
    status: "partial",
    finding: "policy-truth",
  },
];

const roadmap = [
  {
    number: "01",
    title: "保住已经修好的服务端门禁",
    body: "顿悟、抄错、经典价格表、默认解锁和 0.03 野生书架附魔率已经对齐。先补回归测试，防止后续并行编辑把这些成果带回去。",
    output: "涉及：Handler / BlockEntity / ConfigurationSafetyTest",
  },
  {
    number: "02",
    title: "把 overlay 优先级闭环到客户端",
    body: "服务端 overlay 已经能替换经典表，但客户端材料分支在同步行之前返回本地表；经典置换 XP 还写死 3/1。先修这条链路，再宣布自定义经典数据完全一致。",
    output: "涉及：syncedRow 顺序 / classicSaltedItemCosts / transformation XP",
  },
  {
    number: "03",
    title: "补齐最后三类说明残留",
    body: "附魔页签仍承诺补差价；经典页不区分“可编辑值”和“硬门禁”；预设短名/应用提示/状态条仍叫原味。把这三处改为按模式与自定义状态显示。",
    output: "涉及：tab.inscribe.desc / class merge page / preset notice",
  },
  {
    number: "04",
    title: "用两种模式加数据包反向回归",
    body: "默认 bundled 经典表、服务器 overlay、编辑经典页、JEI/REI 信息页刷新都要两两组合验证，避免只测单机默认路径。",
    output: "涉及：JUnit / 专用服联机 / 新区块与重启",
  },
];

function BrandMark() {
  return (
    <svg className="brand-mark" width="35" height="35" viewBox="0 0 35 35" fill="none" aria-hidden="true">
      <path d="M5.5 8.5C10.2 7.2 14.2 8.2 17.5 10.6C20.8 8.2 24.8 7.2 29.5 8.5V25.9C24.8 24.6 20.8 25.6 17.5 28C14.2 25.6 10.2 24.6 5.5 25.9V8.5Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M17.5 10.7V28M9 13C10.8 12.7 12.2 12.8 13.7 13.5M21.3 13.5C22.8 12.8 24.2 12.7 26 13" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
      <path d="M10 17H13.3M21.7 17H25" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}

function SectionHeading({
  number,
  eyebrow,
  title,
  description,
  inverted = false,
}: {
  number: string;
  eyebrow: string;
  title: string;
  description?: string;
  inverted?: boolean;
}) {
  return (
    <div className={`section-heading${inverted ? " section-heading-inverted" : ""}`}>
      <span className="section-index">{number}</span>
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h2>{title}</h2>
        {description ? <p>{description}</p> : null}
      </div>
    </div>
  );
}

function EvidenceLink({ item }: { item: Evidence }) {
  return (
    <a href={item.url} target="_blank" rel="noopener noreferrer" className="evidence-link">
      <span className={`evidence-revision ${item.revision === "1.0.3" ? "is-old" : ""}`}>
        {item.revision}
      </span>
      <span>{item.label}</span>
      <ArrowUpRight size={13} strokeWidth={1.8} aria-hidden="true" />
    </a>
  );
}

function FindingRow({
  finding,
  open,
  toggle,
  copyLink,
  reducedMotion,
}: {
  finding: Finding;
  open: boolean;
  toggle: () => void;
  copyLink: () => void;
  reducedMotion: boolean;
}) {
  const statusClass = statusClassName(finding.status);
  const detailId = `${finding.id}-details`;

  return (
    <article className={`finding ${open ? "finding-open" : ""} ${statusClass}`} id={finding.id}>
      <button
        type="button"
        className="finding-toggle"
        onClick={toggle}
        aria-expanded={open}
        aria-controls={detailId}
      >
        <span className="finding-side">
          <span className="finding-number">{finding.number}</span>
          <span className={`priority priority-${finding.priority.toLowerCase()}`}>{finding.priority}</span>
          <span className={`status-pill ${statusClass}`}>{statusLabels[finding.status]}</span>
        </span>
        <span className="finding-main">
          <span className="finding-category">{categoryLabels[finding.category]}</span>
          <span className="finding-title">{finding.title}</span>
          <span className="finding-summary">{finding.summary}</span>
        </span>
        <span className={`finding-chevron ${open ? "finding-chevron-open" : ""}`}>
          <ChevronDown size={20} strokeWidth={1.6} aria-hidden="true" />
        </span>
      </button>

      <AnimatePresence initial={false}>
        {open ? (
          <motion.div
            id={detailId}
            className="finding-detail-clip"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: reducedMotion ? 0 : 0.3, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="finding-detail">
              <div className="comparison">
                <div className="comparison-cell">
                  <span className="detail-label"><i /> 1.0.3 标签源码</span>
                  <p>{finding.baseline}</p>
                </div>
                <div className="comparison-cell">
                  <span className="detail-label"><i /> 当前 26.1.2 分支</span>
                  <p>{finding.current}</p>
                </div>
              </div>
              <div className="recommendation">
                <div className="detail-label detail-label-accent">建议如何改</div>
                <ol>
                  {finding.recommendations.map((item) => <li key={item}>{item}</li>)}
                </ol>
              </div>
              <div className="acceptance">
                <div className="detail-label">如何验收</div>
                <p>{finding.acceptance}</p>
              </div>
              <p className="status-note"><strong>{statusLabels[finding.status]}</strong>：{statusDescriptions[finding.status]}</p>
              {finding.caveat ? <p className="finding-caveat">判断边界：{finding.caveat}</p> : null}
              <div className="evidence-footer">
                <div className="evidence-header">
                  <span className="detail-label">源码证据</span>
                  <button type="button" onClick={copyLink} className="copy-issue">
                    <Copy size={14} aria-hidden="true" /> 复制此问题链接
                  </button>
                </div>
                <div className="evidence-list">
                  {finding.evidence.map((item) => <EvidenceLink key={item.url} item={item} />)}
                </div>
              </div>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </article>
  );
}

export default function App() {
  const [activeSection, setActiveSection] = useState("overview");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set(["overlay-sync"]));
  const [toast, setToast] = useState("");
  const prefersReducedMotion = useReducedMotion();

  const counts = useMemo(() => {
    const result: Record<Filter, number> = {
      all: findings.length,
      mechanic: 0,
      economy: 0,
      copy: 0,
      content: 0,
    };
    for (const item of findings) result[item.category] += 1;
    return result;
  }, []);

  const statusCounts = useMemo(() => {
    const result: Record<Status, number> = { fixed: 0, partial: 0, open: 0 };
    for (const item of findings) result[item.status] += 1;
    return result;
  }, []);

  const visibleFindings = useMemo(() => {
    const term = query.trim().toLocaleLowerCase();
    return findings.filter((item) => {
      if (filter !== "all" && item.category !== filter) return false;
      if (!term) return true;
      return [
        item.title,
        item.summary,
        item.baseline,
        item.current,
        item.recommendations.join(" "),
        item.acceptance,
        categoryLabels[item.category],
        item.priority,
      ].join(" ").toLocaleLowerCase().includes(term);
    });
  }, [filter, query]);

  const allVisibleExpanded = visibleFindings.length > 0 && visibleFindings.every((item) => expanded.has(item.id));

  useEffect(() => {
    const sections = navigation
      .map((item) => document.getElementById(item.id))
      .filter((item): item is HTMLElement => item !== null);
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((entry) => entry.isIntersecting);
        if (visible.length > 0) {
          setActiveSection(visible[visible.length - 1].target.id);
        }
      },
      { rootMargin: "-15% 0px -68% 0px", threshold: 0 },
    );
    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const hash = decodeURIComponent(window.location.hash.slice(1));
    if (findings.some((item) => item.id === hash)) {
      setExpanded((previous) => new Set([...previous, hash]));
      const timer = window.setTimeout(() => document.getElementById(hash)?.scrollIntoView(), 180);
      return () => window.clearTimeout(timer);
    }
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2700);
    return () => window.clearTimeout(timer);
  }, [toast]);

  function toggleFinding(id: string) {
    setExpanded((previous) => {
      const next = new Set(previous);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function toggleVisible() {
    setExpanded((previous) => {
      const next = new Set(previous);
      visibleFindings.forEach((item) => {
        if (allVisibleExpanded) next.delete(item.id);
        else next.add(item.id);
      });
      return next;
    });
  }

  function jumpToFinding(id: string) {
    setFilter("all");
    setQuery("");
    setExpanded((previous) => new Set([...previous, id]));
    window.setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: prefersReducedMotion ? "auto" : "smooth" }), 60);
  }

  async function copyText(text: string, message: string) {
    try {
      await navigator.clipboard.writeText(text);
      setToast(message);
    } catch {
      window.prompt("复制以下内容", text);
    }
  }

  const checklistText = [
    "纂刻附魔台 / 1.0.3 预设验收清单",
    ...testCases.map((item, index) => `${index + 1}. [ ] ${item.scenario}：${item.expected}（${item.layer}）`),
    `证据快照：${repository}/tree/${currentRevision}；基线：${repository}/tree/${legacyRevision}`,
  ].join("\n");

  return (
    <div className="app-shell">
      <div className="mobile-header">
        <div className="mobile-brand"><BrandMark /><span>纂刻附魔台 <small>审查报告</small></span></div>
        <button type="button" className="mobile-menu-button" onClick={() => setMobileNavOpen(!mobileNavOpen)} aria-expanded={mobileNavOpen} aria-label={mobileNavOpen ? "关闭目录" : "打开目录"}>
          {mobileNavOpen ? <X size={23} /> : <Menu size={23} />}
        </button>
      </div>

      {mobileNavOpen ? <button type="button" className="sidebar-scrim" onClick={() => setMobileNavOpen(false)} aria-label="关闭目录" /> : null}

      <aside className={`sidebar ${mobileNavOpen ? "sidebar-open" : ""}`}>
        <a href="#overview" className="sidebar-brand" onClick={() => setMobileNavOpen(false)}>
          <BrandMark />
          <span><strong>纂刻附魔台</strong><small>CHISELED ENCHANTING TABLE</small></span>
        </a>
        <div className="sidebar-report-title">
          <span className="sidebar-overline">SOURCE AUDIT / ROUND 3</span>
          <p>1.0.3 经典预设<br />复检报告</p>
        </div>
        <div className="sidebar-nav-label">报告目录</div>
        <nav aria-label="报告目录" className="sidebar-nav">
          {navigation.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              className={`sidebar-nav-item ${activeSection === item.id ? "sidebar-nav-active" : ""}`}
              onClick={() => {
                setActiveSection(item.id);
                setMobileNavOpen(false);
              }}
            >
              {activeSection === item.id ? <motion.span layoutId="active-nav" className="nav-active-line" transition={{ duration: prefersReducedMotion ? 0 : 0.25 }} /> : null}
              <span className="nav-number">{item.number}</span>
              <span>{item.label}</span>
              {item.id === "findings" ? <span className="nav-count">{findings.length}</span> : null}
            </a>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-bottom-label">对照版本</div>
          <div className="sidebar-version"><span>基线标签</span><strong>1.0.3</strong></div>
          <div className="sidebar-version"><span>当前快照</span><strong>{currentRevision}</strong></div>
          <a href={repository} target="_blank" rel="noopener noreferrer" className="sidebar-repo">打开源仓库 <ArrowUpRight size={15} /></a>
        </div>
      </aside>

      <div className="main-area">
        <header className="topbar">
          <div className="topbar-path"><span className="path-root">ROUND 3 / RECHECK</span><span className="path-divider">/</span><span>MC 26.1.2</span><span className="path-divider">/</span><span>{currentRevision}</span></div>
          <div className="topbar-links">
            <a href={`${repository}/tree/${legacyRevision}`} target="_blank" rel="noopener noreferrer">1.0.3 标签 <ArrowUpRight size={13} /></a>
            <a href={`${repository}/tree/${currentRevision}`} target="_blank" rel="noopener noreferrer">当前源码 <ArrowUpRight size={13} /></a>
          </div>
        </header>

        <main>
          <section id="overview" className="hero content-width">
            <div className="hero-copy">
              <div className="hero-kicker"><span className="kicker-line" /> Round 3 复检 / {currentRevision}</div>
              <h1>纂刻附魔台</h1>
              <h2>“1.0.3 经典”预设<br /><em>再次检测</em></h2>
              <p className="hero-description">这次不只核对旧问题，还检查 Round 3 新增的经典数据 overlay 与可编辑 profile。上一轮的服务端门禁已确认修好；剩余项集中在一处静态页签文案、经典页语义表达，以及 overlay 的客户端同步闭环。</p>
              <div className="hero-links">
                <a href="#findings" className="hero-primary">阅读复检结果 <ArrowDownRight size={18} strokeWidth={1.7} /></a>
                <a href="#scope" className="hero-secondary">先看判定口径 <ArrowRight size={16} strokeWidth={1.7} /></a>
              </div>
              <div className="recheck-summary">
                <div className="recheck-tag">复检分支：<code>{reviewedBranch}</code><span>· {currentRevision}</span></div>
                <strong>{reviewSummary.headline}</strong>
                <p>{reviewSummary.body}</p>
                <div className="recheck-metrics">
                  {reviewSummary.metrics.map((item) => <span key={item.label}><b>{item.value}</b>{item.label}</span>)}
                </div>
                <div className="status-strip">
                  {statusOrder.map((status) => (
                    <span key={status} className={`status-pill ${statusClassName(status)}`}>
                      {statusLabels[status]} {statusCounts[status]}
                    </span>
                  ))}
                </div>
              </div>
            </div>
            <div className="hero-compare" aria-hidden="true">
              <div className="hero-compare-label">CODEBASE / COMPARISON</div>
              <div className="hero-version hero-version-old">1.0.3<span>TAGGED BASELINE</span></div>
              <div className="hero-track"><span /><i /><span /></div>
              <div className="hero-version hero-version-new">1.1.0<span>CURRENT SNAPSHOT</span></div>
              <div className="hero-compare-foot">ROUND 3 / {previousRevision} → {currentRevision}<br />Classic overlay & profile semantics</div>
            </div>
          </section>

          <section className="verdict-band">
            <div className="content-width verdict-inner">
              <div className="verdict-side"><span className="verdict-line" /> 复检结论 <span>AT A GLANCE</span></div>
              <div className="verdict-copy"><strong>服务端核心还原已基本闭合；剩余问题主要在说明层和新增 overlay 的跨端优先级。</strong><p>Round 3 把顿悟、抄错、旧成本表、旧升书表、旧置换表、默认解锁、0.03 野生书架附魔率都补上了，还把经典模式改成“模式开关 + 可编辑 profile”。本轮唯一新增 open 项是 classic overlay 在客户端预览中没有优先使用服务端同步行；另有两处文案/配置语义和一个预设命名残留。</p></div>
            </div>
          </section>

          <section id="scope" className="report-section content-width scope-section">
            <SectionHeading number="01" eyebrow="AUDIT BASIS / 判定口径" title="先确定比较的是哪两个版本" description="使用同一 Minecraft 26.1.2 移植线，避免把 26.3 的 API 或原作者早期版本混作 1.0.3 基线。" />
            <div className="scope-grid">
              <div className="scope-column">
                <span className="scope-column-top">BASELINE / 旧版</span>
                <h3>26.1.2_1.0.3</h3>
                <p>仓库正式标签，提交 <code>09f854e</code>。对照旧版的处理器、附魔应用、物品置换、成本 JSON 与书架生成数据，不以如今的 Wiki 叙述代替旧源码。</p>
                <a href={`${repository}/tree/${legacyRevision}`} target="_blank" rel="noopener noreferrer" className="text-link">打开旧版标签 <ArrowUpRight size={15} /></a>
              </div>
              <div className="scope-column">
                <span className="scope-column-top">WORKING TREE / 最新复检</span>
                <h3>{currentRevision} <small>/ Round 3</small></h3>
                <p>目标仍是 <code>arena/8eb3bb9e...</code>，但分支已从上一轮的 <code>{previousRevision}</code> 前进到 <code>{currentRevision}</code>。本轮重点核对 classic overlay、salted 成本、profile 语义、JEI/REI 与配置页联动。</p>
                <a href={`${repository}/tree/${currentRevision}`} target="_blank" rel="noopener noreferrer" className="text-link">打开当前快照 <ArrowUpRight size={15} /></a>
              </div>
            </div>
            <div className="scope-boundary"><span>保留什么</span><p>世界生成死锁修复、服务端成本同步、存档兼容注册与安全校验继续保留。64 堆叠现在只是 classic profile 的启动期建议值，不再由 build() 强制；配方仍是现行静态数据，但已在预设说明里明确披露。旧标签源码中的 64 堆叠仍是 TODO，不能把它当作 1.0.3 构建已实现的事实。</p><a href={sourceUrl("old", "src/main/java/chiseled_enchanting_table/ChiseledEnchantingTable.java", "L20-L28")} target="_blank" rel="noopener noreferrer">查看旧版 TODO <ArrowUpRight size={13} /></a></div>
          </section>

          <section id="findings" className="report-section content-width findings-section">
            <SectionHeading number="02" eyebrow="RECHECK / 逐项复核" title="15 项复核：11 项已修，3 项部分，1 项新增缺口" description={`以 ${currentRevision} 为准，对照上一轮 ${previousRevision} 与 1.0.3 标签。优先看服务端结果，再看静态文案与内容边界。`} />
            <div className="finding-tools">
              <div className="filter-tabs" role="group" aria-label="按类别筛选问题">
                {filters.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    className={`filter-tab ${filter === item.id ? "filter-active" : ""}`}
                    onClick={() => setFilter(item.id)}
                    aria-pressed={filter === item.id}
                  >
                    {item.label} <span>{counts[item.id]}</span>
                  </button>
                ))}
              </div>
              <div className="finding-utilities">
                <label className="search-field">
                  <Search size={16} strokeWidth={1.7} aria-hidden="true" />
                  <span className="sr-only">搜索问题内容</span>
                  <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索关键词或源码问题" />
                  {query ? <button type="button" onClick={() => setQuery("")} aria-label="清除搜索"><X size={14} /></button> : null}
                </label>
                <button type="button" className="expand-all" onClick={toggleVisible} disabled={visibleFindings.length === 0}>{allVisibleExpanded ? "收起当前" : "展开当前"}</button>
              </div>
            </div>
            <div className="findings-result" aria-live="polite">显示 {visibleFindings.length} 项 / 共 {findings.length} 项</div>
            <div className="finding-list">
              {visibleFindings.length ? visibleFindings.map((item) => (
                <FindingRow
                  key={item.id}
                  finding={item}
                  open={expanded.has(item.id)}
                  toggle={() => toggleFinding(item.id)}
                  copyLink={() => copyText(`${window.location.origin}${window.location.pathname}#${item.id}`, "问题链接已复制")}
                  reducedMotion={Boolean(prefersReducedMotion)}
                />
              )) : <div className="empty-results"><Search size={28} strokeWidth={1.3} /><strong>没有找到对应问题</strong><p>试试其他关键词，或切回“全部问题”。</p><button type="button" onClick={() => { setQuery(""); setFilter("all"); }}>清除筛选 <ArrowRight size={15} /></button></div>}
            </div>
          </section>

          <section id="crosswalk" className="report-section content-width crosswalk-section">
            <SectionHeading number="03" eyebrow="DEPENDENCY MAP / 联动断点" title="从设置到表现，中间断在哪里" description="同一个开关至少要管住四层：配置值、服务端能力、最终报价、面向玩家的说明。" />
            <div className="crosswalk-table" aria-label="配置与界面联动断点">
              <div className="crosswalk-head"><span>设置或条件</span><span>服务端实际</span><span>玩家看到</span><span>应修正 / 状态</span></div>
              {crosswalk.map((row) => (
                <button type="button" className="crosswalk-row" key={row.key} onClick={() => jumpToFinding(row.finding)} title="查看相关问题">
                  <span><code>{row.key}</code></span><span>{row.effect}</span><span>{row.surface}</span><span className="crosswalk-target"><span className={`status-pill ${statusClassName(row.status)}`}>{statusLabels[row.status]}</span>{row.target} <ArrowUpRight size={13} /></span>
                </button>
              ))}
            </div>
            <p className="under-table-note">选择任一行，可跳转到对应问题的旧版、现行代码及具体改法。</p>
          </section>

          <section id="api" className="api-section">
            <div className="content-width">
              <SectionHeading number="04" eyebrow="IMPLEMENTATION CONTEXT / API 校核" title="建议必须落在 26.1.2 的 API 上" description="以下同时对照此分支的实际调用与 Fabric API 0.151.0+26.1.2 文档，避免套用其他 Minecraft 版本的接口名称。" inverted />
              <div className="api-list">
                {auditApi.map((item, index) => (
                  <div className="api-row" key={item.title}>
                    <span className="api-number">0{index + 1}</span>
                    <div className="api-main"><h3>{item.title}</h3><code>{item.code}</code><p>{item.text}</p><div className="api-links"><a href={item.source} target="_blank" rel="noopener noreferrer">分支调用 <ArrowUpRight size={13} /></a><a href={item.api} target="_blank" rel="noopener noreferrer">26.1.2 官方 API <ArrowUpRight size={13} /></a></div></div>
                  </div>
                ))}
              </div>
              <p className="api-footnote">依赖版本以仓库 <a href={sourceUrl("current", "gradle.properties", "L5-L26")} target="_blank" rel="noopener noreferrer">gradle.properties</a> 为准：Minecraft 26.1.2、Fabric Loader 0.19.3、Fabric API 0.151.0+26.1.2。资源条件只在加载或重载资源时生效，不可替代服务端运行时门禁。</p>
            </div>
          </section>

          <section id="plan" className="report-section content-width plan-section">
            <SectionHeading number="05" eyebrow="EXECUTION / 建议顺序" title="锁住已修好的，再补最后一公里" description="Round 3 的主要结果已经对齐；剩下建议按“服务端闭环 → 报价与文案 → 命名与状态 → 双模式回归”四步收尾。" />
            <div className="roadmap-list">
              {roadmap.map((item) => (
                <div className="roadmap-step" key={item.number}>
                  <div className="roadmap-marker">{item.number}</div>
                  <div className="roadmap-copy"><h3>{item.title}</h3><p>{item.body}</p><span>{item.output}</span></div>
                </div>
              ))}
            </div>
          </section>

          <section id="tests" className="report-section content-width tests-section">
            <SectionHeading number="06" eyebrow="ACCEPTANCE / 验收矩阵" title="不要只测“按钮看不见了”" description="这里列的是建议新增的回归测试，不是声称已经在游戏内通过的结果。" />
            <div className="test-table">
              <div className="test-head"><span>测试场景</span><span>预期结果</span><span>覆盖层</span></div>
              {testCases.map((test) => <div className="test-row" key={test.scenario}><span>{test.scenario}</span><span>{test.expected}</span><span>{test.layer}</span></div>)}
            </div>
            <button type="button" className="copy-checklist" onClick={() => copyText(checklistText, "验收清单已复制")}><Copy size={16} strokeWidth={1.7} /> 复制验收清单 <ArrowUpRight size={15} /></button>
          </section>

          <section id="config" className="report-section content-width config-section">
            <SectionHeading number="07" eyebrow="CONFIG AUDIT / 配置页专项" title="64 项配置：覆盖了多少，哪些真的生效" description={configAudit.scope} />

            <div className="config-stat-row">
              <div className="config-stat"><b>64</b><span>配置项总数</span></div>
              <div className="config-stat"><b>6</b><span>意图分类</span></div>
              <div className="config-stat"><b>57</b><span>经典页行数</span></div>
              <div className="config-stat"><b>29</b><span>经典 profile 写入字段</span></div>
              <div className="config-stat"><b>22</b><span>规则接管（已锁定标注）</span></div>
              <div className="config-stat"><b>6</b><span>误标为可修改</span></div>
            </div>

            <h3 className="config-subhead">一、覆盖与有效性：值层面基本齐，但不是“全部修改项”</h3>
            <div className="effect-table">
              <div className="effect-head"><span>分组</span><span>数量</span><span>判定</span><span>说明与键位</span></div>
              {configAudit.effectiveness.map((g) => (
                <div className={`effect-row ${g.verdict.includes("误标") ? "effect-row-warn" : ""}`} key={g.group}>
                  <span className="effect-group">{g.group}</span>
                  <span className="effect-count">{g.count}</span>
                  <span className={`effect-verdict ${g.verdict.includes("无效 — 但") ? "is-warn" : g.verdict.includes("有效") && !g.verdict.includes("误标") ? "is-ok" : ""}`}>{g.verdict}</span>
                  <span className="effect-detail"><em>{g.detail}</em><code>{g.keys}</code></span>
                </div>
              ))}
            </div>
            <div className="coverage-gap">
              <span>不覆盖的部分</span>
              <ul>{configAudit.coverageGaps.map((item) => <li key={item}>{item}</li>)}</ul>
              <p className="config-note">结论：经典页把「数值与规则」层面的 1.0.3 差异基本收齐（29 项 profile 字段全部在页内，另加 27 项相关键），但「内容层」差异（配方、新物品、战利品权重）与三张经典数据表不在游戏内配置范围内——后者只能靠数据包覆盖，且客户端预览还有问题 15 的缺口。</p>
            </div>

            <h3 className="config-subhead">二、分页与可查找性：结构对，容量与检索不够</h3>
            <div className="two-col-list">
              <div className="list-block"><span className="detail-label"><i /> 已做对</span><ul>{configAudit.pagination.good.map((i) => <li key={i}>{i}</li>)}</ul></div>
              <div className="list-block list-block-warn"><span className="detail-label"><i /> 待改进</span><ul>{configAudit.pagination.bad.map((i) => <li key={i}>{i}</li>)}</ul></div>
            </div>

            <h3 className="config-subhead">三、UI 与美术：信息架构好，视觉与可读性拖后腿</h3>
            <p className="config-lead">{configAudit.ui.headline}</p>
            <div className="ui-fact-grid">
              {configAudit.ui.facts.map((f) => (
                <div className="ui-fact" key={f.label}><b>{f.value}</b><span>{f.label}</span><em>{f.note}</em></div>
              ))}
            </div>
            <p className="config-note">{configAudit.ui.verdict}</p>

            <h3 className="config-subhead">四、AI 绘图方案：建议做，但按规范走</h3>
            <p className="config-lead">{configAudit.artPlan.verdict}</p>
            <ol className="art-steps">{configAudit.artPlan.steps.map((s, i) => <li key={s}><b>0{i + 1}</b>{s}</li>)}</ol>
            <div className="asset-table">
              <div className="asset-head"><span>资产</span><span>建议尺寸</span><span>说明</span></div>
              {configAudit.artPlan.assets.map((a) => (
                <div className="asset-row" key={a.name}><span>{a.name}</span><code>{a.size}</code><span>{a.note}</span></div>
              ))}
            </div>

            <h3 className="config-subhead">五、优秀的内置配置页应该怎么分页</h3>
            <div className="level-list">
              {configAudit.reference.levels.map((l) => (
                <div className="level-row" key={l.level}><span className="level-name">{l.level}</span><span>{l.detail}</span></div>
              ))}
            </div>
            <ul className="ref-rules">{configAudit.reference.rules.map((r) => <li key={r}>{r}</li>)}</ul>
          </section>

          <footer id="sources" className="footer-section">
            <div className="content-width footer-inner">
              <div className="footer-main">
                <span className="eyebrow">SOURCE NOTE / 证据边界</span>
                <h2>让“经典规则”<br />成为可验证的承诺。</h2>
                <p>本页是针对公开源码的静态复检与修改建议，并非已合入模组的补丁，也未声称完成 Minecraft 客户端或专用服实测。条件性行为与数据包覆盖边界已在具体问题中注明；实际发布前须运行模组测试、构建及联机回归。</p>
              </div>
              <div className="footer-sources">
                <span className="footer-sources-label">核对所用的一手材料</span>
                <a href={`${repository}/tree/${legacyRevision}`} target="_blank" rel="noopener noreferrer"><span>1.0.3 标签源码</span><ArrowUpRight size={15} /></a>
                <a href={`${repository}/tree/${currentRevision}`} target="_blank" rel="noopener noreferrer"><span>当前 26.1.2 快照</span><ArrowUpRight size={15} /></a>
                <a href={`${repository}/compare/${legacyRevision}...${currentRevision}`} target="_blank" rel="noopener noreferrer"><span>两个版本的完整差异</span><ArrowUpRight size={15} /></a>
                <a href="https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/" target="_blank" rel="noopener noreferrer"><span>Fabric API 0.151.0 Javadoc</span><ArrowUpRight size={15} /></a>
              </div>
            </div>
            <div className="content-width footer-bottom"><span>纂刻附魔台 / 源码审查报告</span><span>BASELINE {legacyRevision} &nbsp; / &nbsp; SNAPSHOT {currentRevision}</span><a href="#overview">返回顶部 <ArrowUpRight size={13} /></a></div>
          </footer>
        </main>
      </div>
      <AnimatePresence>
        {toast ? <motion.div className="toast" role="status" aria-live="polite" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} transition={{ duration: prefersReducedMotion ? 0 : 0.2 }}><Check size={16} />{toast}</motion.div> : null}
      </AnimatePresence>
    </div>
  );
}