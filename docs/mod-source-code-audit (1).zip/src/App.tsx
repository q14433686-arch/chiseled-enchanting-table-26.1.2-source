import Hero from "./components/Hero";
import Findings from "./components/Findings";
import { HardcodeTable, Headline, Method, PathGrid, Roadmap } from "./components/Sections";
import { REPO } from "./data/audit";

const NAV = [
  { href: "#paths", label: "审查路径" },
  { href: "#hardcode", label: "硬编码清单" },
  { href: "#findings", label: "审计发现" },
  { href: "#roadmap", label: "修复优先级" },
  { href: "#method", label: "方法" },
];

export default function App() {
  return (
    <div className="min-h-screen bg-[#09080f] text-slate-200 antialiased">
      <nav className="sticky top-0 z-40 border-b border-white/10 bg-[#09080f]/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-5 py-3 sm:px-8">
          <a href="#top" className="flex items-center gap-2.5">
            <span className="flex h-7 w-7 items-center justify-center rounded-md bg-gradient-to-br from-violet-500 to-fuchsia-600 text-[13px] font-bold text-white shadow-lg shadow-violet-900/40">
              ✦
            </span>
            <span className="text-[13px] font-semibold tracking-tight text-white">
              CET <span className="text-slate-500">/</span> 26.3 Audit
            </span>
          </a>
          <div className="hidden items-center gap-1 md:flex">
            {NAV.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="rounded-md px-3 py-1.5 text-[12.5px] text-slate-400 transition hover:bg-white/5 hover:text-white"
              >
                {n.label}
              </a>
            ))}
          </div>
          <a
            href={REPO.url}
            target="_blank"
            rel="noreferrer"
            className="rounded-md border border-white/10 bg-white/5 px-3 py-1.5 text-[12px] text-slate-300 transition hover:border-violet-400/40 hover:text-violet-100"
          >
            仓库 ↗
          </a>
        </div>
      </nav>

      <div id="top">
        <Hero />
        <Headline />
        <PathGrid />
        <HardcodeTable />
        <Findings />
        <Roadmap />
        <Method />
      </div>

      <footer className="border-t border-white/10 bg-black/30">
        <div className="mx-auto max-w-7xl px-5 py-10 sm:px-8">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div className="max-w-2xl">
              <div className="text-[13px] font-semibold text-white">关于本报告</div>
              <p className="mt-2 text-[12.5px] leading-relaxed text-slate-400">
                本报告基于分支{" "}
                <code className="font-mono text-[11.5px] text-slate-300">{REPO.branch}</code>{" "}
                的源码静态走查，未在真实 Minecraft {REPO.mc} 运行时环境中执行（该版本的 Fabric 工具链与 JDK 25
                不在审计沙箱内）。标记为
                <span className="text-emerald-300"> 已在源码定位 </span>
                的条目均可在给出的文件与行号直接复核；标记为
                <span className="text-sky-300"> 需运行期复核 </span>
                的条目（BAL-03、BAL-04 的符号方向）建议在开发环境中用一次实测确认后再动代码。
              </p>
              <p className="mt-2 text-[12.5px] leading-relaxed text-slate-500">
                原版 mod 由 Sacramentix 创作并以 MIT 许可发布；本仓库为社区非官方 26.3 移植，报告仅针对该移植分支的工程质量。
              </p>
            </div>
            <div className="shrink-0 font-mono text-[11px] leading-relaxed text-slate-600">
              <div>95 java files · 33,359 LOC</div>
              <div>12 mixin classes · 8 registered</div>
              <div>12 payload channels · protocol rev 8</div>
              <div>11 locales · 624 keys</div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
