export type Severity = "blocker" | "high" | "medium" | "low" | "info";

export type PathId =
  | "api"
  | "codec"
  | "network"
  | "gui"
  | "mixin"
  | "dead"
  | "coupling"
  | "balance";

export interface Evidence {
  file: string;
  note: string;
}

export interface Finding {
  id: string;
  title: string;
  severity: Severity;
  paths: PathId[];
  confidence: "verified" | "likely" | "needs-review";
  summary: string;
  detail: string[];
  evidence: Evidence[];
  impact: string;
  fix: string[];
  snippet?: { lang: string; title: string; code: string };
}

export const REPO = {
  owner: "q14433686-arch",
  name: "chiseled-enchanting-table-26.1.2-source",
  branch: "arena/1ac4c727-chiseled-enchanting-table-26-1",
  url: "https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/tree/arena%2F1ac4c727-chiseled-enchanting-table-26-1",
  modVersion: "1.1.0",
  mc: "26.3",
  loader: "Fabric 0.19.5",
  fabricApi: "0.162.0+26.3",
  java: "25",
};

export const STATS = [
  { label: "Java 源文件", value: "95", sub: "main 63 / client 27 / test 5" },
  { label: "Java 总行数", value: "33,359", sub: "单文件最大 2,594 行" },
  { label: "Mixin 类 / 已注册", value: "12 / 8", sub: "4 个类从未被加载" },
  { label: "本地化", value: "11 语言", sub: "en_us 624 键" },
  { label: "活跃网络通道", value: "12 条", sub: "4 条未带协议版本号" },
  { label: "审计发现", value: "35 条", sub: "1 致命 / 6 高 / 18 中 / 9 低" },
];

export const PATHS: Record<
  PathId,
  { label: string; en: string; accent: string; desc: string }
> = {
  api: {
    label: "源码 API",
    en: "Source API",
    accent: "#7dd3fc",
    desc: "26.3 Mojmap 接口使用、构建脚本、元数据声明、第三方 API 桩代码",
  },
  codec: {
    label: "数据编解码",
    en: "Codec / Serialization",
    accent: "#a78bfa",
    desc: "NBT 持久化、DataComponents、数据包 Codec、StreamCodec 对称性",
  },
  network: {
    label: "网络同步",
    en: "Network Sync",
    accent: "#f0abfc",
    desc: "Payload 通道、协议版本握手、服务端权威校验、解码边界",
  },
  gui: {
    label: "GUI 输入",
    en: "GUI Input",
    accent: "#fcd34d",
    desc: "事件转发、模态 overlay、焦点与按键、客户端渲染时钟",
  },
  mixin: {
    label: "Mixin 注入",
    en: "Mixin Injection",
    accent: "#fb7185",
    desc: "注册完整性、注入点选择、目标状态可变性、第三方共存",
  },
  dead: {
    label: "死代码",
    en: "Dead Code",
    accent: "#94a3b8",
    desc: "零调用点的生产代码、冗余常量、仅测试可达的重载",
  },
  coupling: {
    label: "耦合风险",
    en: "Coupling Risk",
    accent: "#5eead4",
    desc: "包间反向依赖、God Object、跨线程共享静态态、层次混淆",
  },
  balance: {
    label: "数值 / 机制",
    en: "Balance & Design",
    accent: "#fdba74",
    desc: "经济守恒、阈值一致性、曲线归一化常数、配置可达性",
  },
};

export const SEVERITY: Record<
  Severity,
  { label: string; ring: string; chip: string; dot: string; order: number }
> = {
  blocker: {
    label: "致命",
    ring: "ring-rose-500/40",
    chip: "bg-rose-500/15 text-rose-300 border-rose-500/30",
    dot: "bg-rose-400",
    order: 0,
  },
  high: {
    label: "高",
    ring: "ring-orange-500/40",
    chip: "bg-orange-500/15 text-orange-300 border-orange-500/30",
    dot: "bg-orange-400",
    order: 1,
  },
  medium: {
    label: "中",
    ring: "ring-amber-400/40",
    chip: "bg-amber-400/15 text-amber-200 border-amber-400/30",
    dot: "bg-amber-300",
    order: 2,
  },
  low: {
    label: "低",
    ring: "ring-sky-400/40",
    chip: "bg-sky-400/15 text-sky-200 border-sky-400/30",
    dot: "bg-sky-300",
    order: 3,
  },
  info: {
    label: "提示",
    ring: "ring-slate-400/30",
    chip: "bg-slate-400/10 text-slate-300 border-slate-400/25",
    dot: "bg-slate-400",
    order: 4,
  },
};

export const FINDINGS: Finding[] = [
  {
    id: "MX-01",
    title: "4 个 @Mixin 类从未注册 —— 整条 Tier-2 世界生成书架链路是死的",
    severity: "blocker",
    paths: ["mixin", "dead", "api"],
    confidence: "verified",
    summary:
      "mixins.json 只列了 8 个类，但 mixin 包下实际有 12 个 @Mixin 类。未注册的 4 个被正常编译进 jar，却永远不会被 Mixin 加载。",
    detail: [
      "src/main/resources/chiseled-enchanting-table-port.mixins.json 的 mixins 数组是：anvil.RemoveEnchantMerge、anvil.RemoveXpCostScaling、bookshelf.AddRandomTick、enchanting_table.DisableBookEnchanting、grindstone.GrindstoneBookDepleteMixin、loot.ReloadableServerRegistriesMixin、structure.StructurePlaceSettingsMixin、structure.StructureTemplatePoolProjectionMixin。",
      "实际存在却缺席的是：structure.LevelChunkPostProcessMixin、structure.StructurePieceMarkMixin、structure.StructurePieceAccessor、chiseled_bookshelf.AddRandomTick。",
      "build.gradle 的 sourceSets 块只对 client 的 jei/rei 目录做 exclude，main 没有任何 exclude —— 所以这 4 个类确实会被 javac 编译、会被打进 jar，只是没有任何配置去加载它们。",
      "docs/reports/WORLDGEN_BOOKSHELF_DEADLOCK_REPORT.md 第 111 行明确写着 “stronghold library 路径（StructurePieceMarkMixin → LevelChunkPostProcessMixin）”是唯一可行方案，docs/EXTENDING.md 与两份 patch 也把它当作在役基础设施描述。文档与运行时事实分叉。",
    ],
    evidence: [
      {
        file: "src/main/resources/chiseled-enchanting-table-port.mixins.json",
        note: "mixins 数组仅 8 项，无 structure.LevelChunkPostProcessMixin / StructurePieceMarkMixin / StructurePieceAccessor / chiseled_bookshelf.AddRandomTick",
      },
      {
        file: "src/main/java/.../mixin/structure/LevelChunkPostProcessMixin.java",
        note: "@Inject(method=\"postProcessGeneration\", at=@At(\"HEAD\")) —— 唯一调用 postProcessBookshelf/postProcessFilledBookshelf 的地方",
      },
      {
        file: "src/main/java/.../mechanics/structure/BookshelfReplacerProcessor.java:150,161",
        note: "postProcessBookshelf / postProcessFilledBookshelf 全仓零生产调用点",
      },
      {
        file: "build.gradle:63-76",
        note: "sourceSets 只有 client.jei / client.rei 的 exclude，main 无 exclude",
      },
    ],
    impact:
      "① 要塞图书馆等“程序化摆放”的结构不会把原版书架换成纂刻书架（这是 TODO.md 里打勾的核心特性之一）；② 模板路径在 BookshelfReplacerProcessor:206 调用 markPosForPostProcessing 标记的坐标永远没人消费，朝向启发式从不运行，生成出来的纂刻书架朝向可能对着墙；③ 这些类白白增加 jar 体积并误导后续维护者。",
    fix: [
      "把 4 个类加入 chiseled-enchanting-table-port.mixins.json（注意先解决 MX-03 的冲突，chiseled_bookshelf.AddRandomTick 应当直接删除而不是注册）。",
      "给 ci_static_checks.py 增加反向 Tier A′：扫描 src/*/java/**/mixin/**/*.java，凡含 @Mixin 注解的类必须出现在某个 mixins.json 的 mixins/client/server 列表中，否则 fail。",
      "为要塞图书馆写一条 gametest 或在 build.yml 的无头服务器 smoke 里用 /place structure 验证替换真的发生，而不是只验证“mixin 被命中”。",
    ],
    snippet: {
      lang: "json",
      title: "chiseled-enchanting-table-port.mixins.json（建议）",
      code: `"mixins": [
  "anvil.RemoveEnchantMerge",
  "anvil.RemoveXpCostScaling",
  "bookshelf.AddRandomTick",
  "enchanting_table.DisableBookEnchanting",
  "grindstone.GrindstoneBookDepleteMixin",
  "loot.ReloadableServerRegistriesMixin",
+ "structure.StructurePieceAccessor",
+ "structure.StructurePieceMarkMixin",
+ "structure.LevelChunkPostProcessMixin",
  "structure.StructurePlaceSettingsMixin",
  "structure.StructureTemplatePoolProjectionMixin"
]`,
    },
  },
  {
    id: "MX-02",
    title: "CI 的 Mixin 完整性门禁是单向的，结构性地放过了 MX-01",
    severity: "high",
    paths: ["mixin", "api"],
    confidence: "verified",
    summary:
      "ci_static_checks.py 的 Tier A 只校验“json 里列的类必须存在”，没有校验“存在的 @Mixin 类必须被列”。这正好是 MX-01 的反方向。",
    detail: [
      "脚本注释自述：Tier A “Every class listed in a *.mixins.json must exist as a .java file”，Tier B “registered mixins must actually be compiled”。两条都是 json → java 方向。",
      "resolve_mixin_source() 由 (package, mixin) 拼出路径再 os.path.exists —— 天然无法发现多出来的 java 文件。",
      "consistency.yml / compile-check.yml / build.yml 三条流水线全绿，但 4 个 mixin 从来没进过游戏。这说明“全绿 CI”在这个仓库里对 Mixin 注册是无信号的。",
    ],
    evidence: [
      { file: "scripts/ci_static_checks.py:88-130", note: "mixin_config_files() / resolve_mixin_source() 均为单向查找" },
      { file: "scripts/ci_static_checks.py:337-340", note: "main() 只跑 4 个 check，无反向注册校验" },
    ],
    impact:
      "任何“写了 mixin 忘了注册”的改动都会静默通过全部门禁，并且因为文档同步更新，review 时会误以为功能已上线。这是 MX-01 能活到 revision 8 的根因。",
    fix: [
      "新增 check_orphan_mixins()：glob src/*/java/**/mixin/**/*.java，正则匹配 ^@Mixin，与所有 mixins.json 的并集做差集，非空即 fail。",
      "顺带校验包前缀：mixins.json 的 package 字段 + 条目路径必须与文件实际 package 声明一致（可发现 MX-03 那种包名误植）。",
    ],
  },
  {
    id: "MX-03",
    title: "两个 AddRandomTick 指向同一个 ChiseledBookShelfBlock，且包名互相误导",
    severity: "high",
    paths: ["mixin", "dead"],
    confidence: "verified",
    summary:
      "mixin/bookshelf/AddRandomTick（已注册）和 mixin/chiseled_bookshelf/AddRandomTick（未注册）都 @Mixin(ChiseledBookShelfBlock.class)，功能重叠。",
    detail: [
      "已注册版 extends BaseEntityBlock 并用 @Override + super 调用，只在有书的槽位上开随机刻 —— 写法正确。",
      "未注册版是裸类，方法没有任何 Mixin 注解（既不是 @Overwrite 也不是 @Inject），且无条件 return true，对空书架也开随机刻。",
      "按 MX-01 的建议“把缺失的都补进去”会直接踩雷：同一目标类上两个 mixin 提供同名同签名方法，轻则后者被静默丢弃并打 WARN，重则 apply 阶段报冲突。",
      "包名还反了：装 ChiseledBookShelf mixin 的包叫 bookshelf，而叫 chiseled_bookshelf 的那个才是该删的残留。",
    ],
    evidence: [
      { file: "src/main/java/.../mixin/bookshelf/AddRandomTick.java", note: "@Mixin(ChiseledBookShelfBlock.class)，已注册，带 SLOT_OCCUPIED_PROPERTIES 判定" },
      { file: "src/main/java/.../mixin/chiseled_bookshelf/AddRandomTick.java", note: "@Mixin(ChiseledBookShelfBlock.class)，未注册，无注解裸方法，无条件 return true" },
    ],
    impact:
      "当前是纯死代码（无运行时影响）；一旦被“顺手补注册”就会变成启动崩溃或静默失效。同时空书架无条件随机刻会给区块随机刻预算带来无谓开销。",
    fix: [
      "删除 src/main/java/.../mixin/chiseled_bookshelf/ 整个目录。",
      "把 mixin/bookshelf/ 重命名为 mixin/chiseled_bookshelf/ 并同步 mixins.json，消除包名误导。",
    ],
  },
  {
    id: "MX-04",
    title: "RemoveEnchantMerge 在 createResult 期间临时改写真实输入槽的 count，且无 try/finally",
    severity: "high",
    paths: ["mixin", "coupling"],
    confidence: "verified",
    summary:
      "HEAD 注入把左槽附魔书 count 存起来后直接 left.setCount(1)，RETURN 注入再还原。中间任何异常或第三方 cancel 都会让玩家的整摞书永久变成 1 本。",
    detail: [
      "cet$normalizeStackedLeftBookHead 把 this.inputSlots.getItem(0) 这个真实 ItemStack 实例改成 count=1，目的是绕开原版“多件物品 cost=40”锁和创造模式 64× 复制。",
      "cet$restoreStackedLeftBookAndFilterSameLevelMerge 在 @At(\"RETURN\") 还原。两段之间是整个 vanilla createResult + 其它模组可能注入的任意代码。",
      "AnvilMenu#createResult 在 slotsChanged 时两端都会跑；@At(\"RETURN\") 不会在异常抛出路径上执行，也不会在其它 mixin 把方法 cancel 掉时执行。",
      "cet$savedLeftBookCount 是 @Unique 实例字段，跨 tick 残留；HEAD 虽然每次重置为 0，但只要还原分支被跳过一次，物品本身已经被改写了。",
    ],
    evidence: [
      { file: "src/main/java/.../mixin/anvil/RemoveEnchantMerge.java:63-78", note: "left.setCount(1) 后在 RETURN 还原，无 try/finally 保护" },
    ],
    impact:
      "铁砧交互中可被触发的物品丢失（最多 63 本附魔书）。属于“数据损坏”级别风险，发生概率依赖第三方模组，但一旦发生不可逆、且难以复现归因。",
    fix: [
      "改用 @ModifyVariable / @WrapOperation 把 count=1 的副本注入局部计算，不碰容器里的真实实例。",
      "若必须临时改写，用 @Inject(method=\"createResult\", at=@At(\"HEAD\")) + @Inject(..., at=@At(value=\"RETURN\")) 之外再加一次兜底：在 slotsChanged / broadcastChanges 处断言 count 已还原。",
      "最稳妥：用 MixinExtras 的 @WrapMethod 包住 createResult，在 Java 层写 try { ... } finally { restore(); }。",
    ],
    snippet: {
      lang: "java",
      title: "现状（危险）",
      code: `@Inject(method = "createResult", at = @At("HEAD"))
private void cet$normalizeStackedLeftBookHead(CallbackInfo ci) {
    this.cet$savedLeftBookCount = 0;
    ItemStack left = this.inputSlots.getItem(0);
    ItemStack right = this.inputSlots.getItem(1);
    if (!right.isEmpty() && left.is(Items.ENCHANTED_BOOK) && left.getCount() > 1) {
        this.cet$savedLeftBookCount = left.getCount();
        left.setCount(1);          // <-- 改写容器中的真实实例
    }
}
// ... 任何异常 / cancel 都会跳过下面这段还原
@Inject(method = "createResult", at = @At("RETURN"))
private void cet$restore...(CallbackInfo ci) { /* left.setCount(saved) */ }`,
    },
  },
  {
    id: "MX-05",
    title: "GrindstoneBookDepleteMixin 构造期替换槽位对象并硬编码容器下标 2",
    severity: "medium",
    paths: ["mixin", "coupling"],
    confidence: "verified",
    summary:
      "在构造器 RETURN 处 this.slots.set(RESULT_SLOT, wrapped)，新 Slot 用字面量 2 作为容器索引，而不是读 delegate 的实际索引。",
    detail: [
      "new Slot(this.resultSlots, 2, delegate.x, delegate.y) —— 下标 2 是从原版源码抄来的常量，没有用 delegate.getContainerSlot() 推导。原版若调整结果容器布局，这里会静默读到空槽。",
      "wrapped 只代理了 mayPlace 和 onTake；delegate 若还覆写了 mayPickup / isActive / isHighlightable（现在没有，将来可能有，或被别的模组包装过），这些行为会丢失。",
      "直接 set 到 AbstractContainerMenu#slots 是“最后写入者赢”的全局共享状态：任意另一个也包装砂轮结果槽的模组会把本 mod 的包装踢掉（或反之），取决于 mixin 应用顺序。",
      "onTake 里恢复剩余书的逻辑依赖 “delegate.onTake 之后 repairRef 槽位变空” 这个时序假设；若有模组在 onTake 里也写回输入槽，两边会互相覆盖。",
    ],
    evidence: [
      { file: "src/main/java/.../mixin/grindstone/GrindstoneBookDepleteMixin.java:62-96", note: "slots.set(RESULT_SLOT, wrapped)，new Slot(resultSlots, 2, ...)，wrapped.index = delegate.index" },
    ],
    impact: "与其它砂轮类模组的兼容性脆弱；原版布局变动时静默失效（不会崩溃，只是不再把附魔书变成耗尽之卷）。",
    fix: [
      "用 delegate.getContainerSlot() 和 delegate.container 推导，不要写死 2。",
      "优先改成 @Redirect/@WrapOperation 包住原版 addSlot 调用，而不是事后替换 slots 列表。",
      "在 onTake 里不要假设 delegate 清空了输入槽，改为先记录再 diff。",
    ],
  },
  {
    id: "MX-06",
    title: "defaultRequire:1 + 字符串方法名，全部注入点都是硬失败",
    severity: "medium",
    paths: ["mixin", "api"],
    confidence: "verified",
    summary:
      "mixins.json 设了 injectors.defaultRequire=1，任何一个注入点在未来快照里失配都会直接让游戏启动崩溃，而不是降级。",
    detail: [
      "RemoveXpCostScaling 对 calculateIncreasedRepairCost（一个 1 行的纯静态函数）用 @Inject(HEAD, cancellable) + setReturnValue —— 这种“整条替换”语义用 @ModifyReturnValue（MixinExtras）或 @Overwrite 表达更准确，也更容易被其它模组兼容叠加。",
      "GrindstoneBookDepleteMixin 用 @Shadow 引用了 GrindstoneMenu 的 private removeNonCursesFrom；私有成员是最容易在版本更新中改名的目标。",
      "这个 mod 的定位是“社区非官方移植”，目标版本 26.3 仍在滚动。硬失败策略意味着每一次 MC 小版本更新都是一次确定性崩溃，而不是功能静默降级。",
    ],
    evidence: [
      { file: "src/main/resources/chiseled-enchanting-table-port.mixins.json", note: "\"injectors\": { \"defaultRequire\": 1 }" },
      { file: "src/main/java/.../mixin/anvil/RemoveXpCostScaling.java:16-22", note: "@Inject(HEAD, cancellable) 用于单行纯函数" },
    ],
    impact: "版本漂移时从“某个特性失效”升级为“游戏打不开”。对终端玩家的体感差异很大。",
    fix: [
      "对可选增强（铁砧扁平惩罚、砂轮耗尽之卷、书架粒子）在 mixin 上标 require = 0 并在 Java 侧做能力探测日志。",
      "对不可降级的核心注入（结构替换、附魔台禁用）保留 require = 1，并在 mixins.json 里分组到两个 config。",
      "引入 MixinExtras（@ModifyReturnValue / @WrapOperation），减少 cancellable Inject 的使用。",
    ],
  },

  {
    id: "NET-01",
    title: "协议版本握手只在客户端单向执行，服务端完全不设防",
    severity: "high",
    paths: ["network", "coupling"],
    confidence: "verified",
    summary:
      "ClientPlayConnectionEvents.JOIN 里客户端自行 disconnect；服务端对未版本化的 apply_chiseled_enchantment 等通道无条件注册接收器，没有任何对称检查。",
    detail: [
      "EnchantingProtocol.incompatible(peerHasMod, peerHasRevision) 只在 ChiseledEnchantingTableClient.onInitializeClient 的 JOIN 回调里被调用。",
      "服务端侧 ChiseledEnchantingTableScreenHandler.init() 和 ModConfigNetworking 都是 registerGlobalReceiver(...)，没有检查发送方是否声明了 protocol_26_3_revision_8 能力。",
      "这意味着“版本不匹配就断开”依赖客户端自觉。一个旧版本客户端、或一个把 JOIN 回调删掉的客户端，依然可以对新服务端的通道发包。",
      "业务层校验（containerMenu instanceof、payload.targets(containerId)、stillValid）做得不错，所以这不是直接的权限漏洞，但它让“协议版本”这层保护形同虚设。",
    ],
    evidence: [
      { file: "src/client/java/.../ChiseledEnchantingTableClient.java:47-53", note: "客户端 JOIN 时单向 disconnect" },
      { file: "src/main/java/.../menu/ChiseledEnchantingTableScreenHandler.java:53-139", note: "服务端 5 个 registerGlobalReceiver，均无能力校验" },
    ],
    impact: "混合版本环境下，旧客户端会以旧语义操作新服务端的菜单；错误表现为“玩家偶发地拿到错误等级/错误花费”，极难从日志定位。",
    fix: [
      "注册 ServerPlayConnectionEvents.JOIN，若 ServerPlayNetworking.canSend(player, legacy 通道) 为真而 canSend(player, Capability.TYPE) 为假，则 player.connection.disconnect(MISMATCH_MESSAGE)。",
      "或者更彻底：把所有通道都带上 REVISION 后缀（见 NET-02），让旧对端连通道都注册不上，然后只保留一条无版本号的“探针”通道专门用于握手。",
    ],
  },
  {
    id: "NET-02",
    title: "12 条活跃通道里 4 条没带协议版本号，探针通道同时也是业务通道",
    severity: "medium",
    paths: ["network", "api"],
    confidence: "verified",
    summary:
      "available_chiseled_enchantment / live_shelf_state / skip_ritual / sync_ritual_state 带 _26_3_revision_8 后缀；apply_chiseled_enchantment / reroll_epiphany / freeze_epiphany / reopen_table 不带。",
    detail: [
      "EnchantingProtocol 的注释说“Bump its ID whenever any menu/cost payload wire layout changes”，但实践中只 bump 了一半。",
      "apply_chiseled_enchantment 被当成“对端装没装本 mod”的探针，所以必须保持无版本号 —— 可它同时也是最核心的操作载荷通道。",
      "后果是：如果 ApplyEnchantmentPayload 的字段顺序/类型变了，旧对端会在 disconnect 生效之前按旧布局解码至少一次。目前写序为 VarInt containerId → Utf token → Int level → Identifier id，这个顺序一旦调整就是静默错位。",
      "reroll_epiphany / freeze_epiphany / reopen_table 是纯 containerId/BlockPos，布局稳定，风险较小，但命名不一致本身就是维护陷阱。",
    ],
    evidence: [
      { file: "src/main/java/.../menu/ChiseledEnchantingMenuPayloads.java:24-31", note: "8 个 PACKET_ID 常量，只有 4 个拼接了 EnchantingProtocol.REVISION" },
      { file: "src/main/java/.../menu/EnchantingProtocol.java:16-32", note: "REVISION = \"26_3_revision_8\"，并保留 5 个历史 cost 通道常量" },
    ],
    impact: "版本过渡期的一次性错位解码；长期维护成本（每次 bump 都要人工记住哪几条不能改名）。",
    fix: [
      "给所有业务通道加 REVISION 后缀；单独定义一条 chiseled_enchanting_table:handshake 永不改名的空载荷通道专门做探针。",
      "在 NetworkCompatibilityTest 里加一条断言：所有 *_PACKET_ID 要么全部包含 REVISION，要么在白名单里显式列出豁免原因。",
    ],
  },
  {
    id: "NET-03",
    title: "ApplyEnchantmentPayload 的解码边界校验缺位，范围校验埋在业务深处",
    severity: "medium",
    paths: ["network", "codec"],
    confidence: "verified",
    summary:
      "项目自建了 PayloadLimits 工具类来“在分配前约束长度前缀数据”，但 apply 载荷的 readUtf()/readInt() 完全没用它；等级 1..255 和 id 长度 512 的校验却写在 EnchantmentApplication.apply 的中段。",
    detail: [
      "read() 里 buf.readUtf() 使用默认上限 32767 字符，随后交给 OptionType.fromToken；未知 token 会抛 IllegalArgumentException(\"Unknown enchanting option type: \" + token)，把攻击者可控的 32KB 字符串拼进服务端日志。",
      "enchantment_level 用 readInt() 读入，没有任何边界；真正的 1..255 检查出现在 EnchantmentApplication.apply 里，而且排在 findEnchantment、canDirectUpgradeExistingEnchantment、admissionTable.canQueue 之后 —— 先用后校验。",
      "payload.enchantment_id().toString().length() > 512 同样是事后检查，而且 512 这个数字在全仓只出现这一次，没有常量名。",
      "record 的 compact constructor 是天然的校验位置，目前是空的。",
    ],
    evidence: [
      { file: "src/main/java/.../menu/ChiseledEnchantingMenuPayloads.java:525-532", note: "write/read 未使用 PayloadLimits，readUtf() 无长度上限" },
      { file: "src/main/java/.../mechanics/enchanting/EnchantmentApplication.java:~82", note: "enchantment_level < 1 || > 255 || id.length() > 512 的检查排在业务调用之后" },
      { file: "src/main/java/.../menu/PayloadLimits.java", note: "类注释自述职责是“在分配/迭代前约束长度前缀数据”，但该载荷未接入" },
    ],
    impact: "日志注入 / 日志膨胀（低危）；更重要的是校验分散，后续新增 OptionType 时很容易忘记补范围检查。",
    fix: [
      "在 ApplyEnchantmentPayload 的 compact constructor 里做 containerId > 0、1 <= level <= MAX_ENCHANT_LEVEL、id 非空的断言。",
      "readUtf(32) 足够容纳最长 token（book_research_upgrade = 21 字符）；fromToken 失败时返回 Optional 并在 handler 里静默丢弃，不要把原始字符串写日志。",
      "把 255 / 512 提成 PayloadLimits.MAX_ENCHANT_LEVEL / MAX_ID_CHARS。",
    ],
  },
  {
    id: "NET-04",
    title: "ReopenTablePayload 无速率限制，距离阈值 64.0D 两处硬编码",
    severity: "low",
    paths: ["network", "gui"],
    confidence: "verified",
    summary:
      "客户端可以每 tick 发一次 reopen_table，服务端只校验“区块已加载 + 距离平方 ≤ 64 + 方块是本 mod 的台子”，然后 openMenu。",
    detail: [
      "openMenu 每次都会新建 ScreenHandler、重算整张书架扫描（7×5×7 = 245 格）、重发 AvailableEnchantmentPayload（含全部 CostEntry 和 ItemStack 组件）。单客户端即可持续制造可观的服务端 CPU 和带宽开销。",
      "64.0D 这个阈值在 handler 里和 ContainerLevelAccess.stillValid 里各写一遍，没有共享常量；原版若调整交互距离（已经随 player_block_interaction_range 属性可配），这里不会跟随。",
      "客户端触发点在 ChiseledEnchantingTableScreen:167，是正常 UI 流程，所以不是功能 bug，只是缺少服务端侧的防滥用。",
    ],
    evidence: [
      { file: "src/main/java/.../menu/ChiseledEnchantingTableScreenHandler.java:101-120", note: "reopen_table 接收器，无节流，距离常量 64.0D 字面量" },
    ],
    impact: "恶意/异常客户端可对服务端造成放大型负载；多人服务器上单人即可影响他人 TPS。",
    fix: [
      "按玩家做简单节流（例如 ≥ 5 tick 一次），或直接复用 player.canInteractWithBlock(pos, 1.0) 代替手写距离。",
      "把 64.0D 换成 player.blockInteractionRange() 的平方，跟随原版属性。",
    ],
  },

  {
    id: "DATA-01",
    title: "仪式队列用分号拼接的字符串存 NBT，长度上限魔数写了两遍",
    severity: "medium",
    paths: ["codec"],
    confidence: "verified",
    summary:
      "ritualQueue 通过 InscriptionRitualMechanics.serializeQueue 拼成 \"a;b;c\" 后 output.putString 持久化，而不是用 Codec 或列表 NBT。",
    detail: [
      "同一个 BlockEntity 的 ritualTarget 已经用了 output.store(\"ritualTarget\", ItemStack.CODEC, ...) 这种正确写法，队列却退回手搓字符串，风格不统一。",
      "32_000 这个上限在 ChiseledEnchantingTableBlockEntity.MAX_RITUAL_CHARACTERS 和 deserializeQueue 内部各写了一次（后者是裸字面量 32_000），两处一旦漂移，“隔离损坏队列”的诊断截断逻辑就会错位。",
      "步数上限 256 也是裸字面量，和 PayloadLimits.MAX_COST_OPTIONS = 256 同值但毫无关联。",
      "好的一面：deserializeQueue 的失败路径做得相当扎实 —— 抛 IllegalArgumentException 后把原串隔离进 ritualCorruptQueue、置 ritualBlocked、保留库存、打 error 日志，不会吞存档。",
    ],
    evidence: [
      { file: "src/main/java/.../block/ChiseledEnchantingTableBlockEntity.java:667-668", note: "output.putString(\"ritualQueue\", serializeQueue(...))" },
      { file: "src/main/java/.../mechanics/ritual/InscriptionRitualMechanics.java:496,500", note: "if (raw.length() > 32_000) / if (out.size() >= 256) 裸字面量" },
    ],
    impact:
      "可读性与演进成本：队列结构一旦需要新增字段（例如每步的折扣快照），字符串格式就得自己做版本化；Codec 则能自然叠加 optionalFieldOf。",
    fix: [
      "改为 Codec<List<QueuedInscription>> + output.store()，旧存档走 getStringOr 兼容分支读一轮后自动迁移。",
      "把 32_000 / 256 提到 InscriptionRitualMechanics 的公共常量，BlockEntity 引用它而不是自己再定义一个。",
    ],
  },
  {
    id: "DATA-02",
    title: "ChiseledEnchantingTableData 的 14 张静态可变表只有 2 个 volatile",
    severity: "medium",
    paths: ["codec", "coupling"],
    confidence: "likely",
    summary:
      "数据包重载在服务端线程重写这些 private static 字段，客户端渲染线程 / JEI / REI / tooltip 回调在读，缺少可见性保证。",
    detail: [
      "rawItemTransformations、itemTransformations、costTables、bookshelfBookPool、bookUpgradeRules、treasureEpiphanyRules、disenchantingRules、defaultEnchantmentValues … 共 14 个 private static 非 final 字段。",
      "只有 preloadedLootInjections 和 preloadedVanillaChestBooksMode 标了 volatile —— 说明作者意识到了跨线程问题，但只处理了战利品预加载这一条路径。",
      "单人模式下集成服务端与客户端共用同一个 JVM 和同一份静态表：/reload 在服务端线程写，渲染线程同 tick 读，理论上可见到撕裂的中间状态（例如 transformations 已换、costTables 未换）。",
      "ChiseledEnchantingTableClient 的 DISCONNECT 回调还会在客户端线程直接调用 applyRuntimeConfig 重写这批表（见 COUP-04）。",
    ],
    evidence: [
      { file: "src/main/java/.../data/ChiseledEnchantingTableData.java:87-114", note: "14 个 private static 可变字段，仅 2 个 volatile" },
      { file: "src/main/java/.../data/ChiseledEnchantingTableData.java:46,152", note: "implements SimpleSynchronousResourceReloadListener + ResourceManagerHelper 注册" },
    ],
    impact:
      "低概率、难复现的 UI/成本显示错乱；在高核数机器上更容易暴露。不会损坏存档，但会产生“只有我这台机器会这样”的报告。",
    fix: [
      "把所有运行期表收进一个不可变快照 record（Tables），用单个 volatile Tables 字段原子换入换出。读侧一次性取引用，保证同一帧看到的是一致快照。",
      "顺带解决 COUP-02 的 God Object 问题：Tables 可以独立于 ReloadListener 存在。",
    ],
  },
  {
    id: "DATA-03",
    title: "服务端用默认 Locale 格式化倒计时字符串写进物品 LORE",
    severity: "low",
    paths: ["codec", "api"],
    confidence: "verified",
    summary:
      "collectImplicitComponents 里 String.format(\"%02d:%02d\", ...) 使用服务端 JVM 默认 Locale，结果作为翻译参数烘焙进 ItemLore。",
    detail: [
      "README 明确声称 “Generated book lore components use server-neutral translation keys so items read naturally in each player's client language.”",
      "翻译键确实是中立的（item.chiseled_enchanting_table.frozen_lore），但传给它的参数已经是服务端本地化过的字符串了。在 ar/fa/hi 等使用非 ASCII 数字的 Locale 下，%02d 会输出本地数字字形。",
      "更稳的做法是把 totalSec 作为整数参数传进去，由客户端的语言文件决定排版；或至少用 Locale.ROOT。",
    ],
    evidence: [
      { file: "src/main/java/.../block/ChiseledEnchantingTableBlockEntity.java:934-941", note: "String.format(\"%02d:%02d\", totalSec/60, totalSec%60) 作为 translatable 参数" },
    ],
    impact: "极少数服务端 Locale 下物品描述出现非预期数字字形；与 README 承诺不完全一致。",
    fix: ["改为 String.format(Locale.ROOT, ...)，或把分秒拆成两个 int 参数交给语言文件。"],
  },
  {
    id: "DATA-04",
    title: "客户端 5 处 String.format 缺 Locale，同一文件里又有用对的反例",
    severity: "low",
    paths: ["gui", "codec"],
    confidence: "verified",
    summary:
      "ChiseledEnchantingTableScreen:1371/1415 的 \"%.1f\" 和 ConfigCatalog:641/652 的 \"%.2f×\" 没传 Locale，而 ChiseledEnchantingTableClient 的 tooltip 正确用了 Locale.ROOT。",
    detail: [
      "在 de_DE / fr_FR / ru_RU 等 Locale 下小数点会变成逗号，与同屏其它用 Locale.ROOT 渲染的数字风格冲突。",
      "ConfigCatalog 的 displayValue 还会被写进配置界面和（间接地）发给服务端做回显，形式不一致。",
      "ChiseledEnchantingConfigScreen:842 的 \"%dm%02ds\" 同样未指定 Locale。",
    ],
    evidence: [
      { file: "src/client/java/.../gui/ChiseledEnchantingTableScreen.java:1371,1415", note: "String.format(\"%.1f\", ...)" },
      { file: "src/main/java/.../config/ConfigCatalog.java:641,652,842", note: "String.format(\"%.2f\\u00d7\", ...) / \"%dm%02ds\"" },
      { file: "src/client/java/.../ChiseledEnchantingTableClient.java:~102", note: "正确示范：String.format(java.util.Locale.ROOT, \"%.1f\", loadL)" },
    ],
    impact: "纯显示一致性问题。",
    fix: ["全仓统一：禁止无 Locale 的 String.format，加一条 ci_static_checks 正则门禁。"],
  },

  {
    id: "API-01",
    title: "modid 用连字符、资源命名空间用下划线，为一张图标多养一个 assets 目录",
    severity: "medium",
    paths: ["api", "coupling"],
    confidence: "verified",
    summary:
      "fabric.mod.json 的 id 是 chiseled-enchanting-table，icon 指向 assets/chiseled-enchanting-table/icon.png；而所有游戏资源在 assets/chiseled_enchanting_table/。",
    detail: [
      "src/main/resources/assets/ 下只有 chiseled-enchanting-table/（只放 icon.png）；src/client/resources/assets/ 下是 chiseled_enchanting_table/（blockstates、models、lang、textures 全在这里）。",
      "Identifier 的命名空间来自 ChiseledEnchantingTable.identifier()，用的是下划线；mod id 却是连字符。Fabric 允许二者不同，但这里是“为了让 icon 路径合法而额外造了一个命名空间目录”。",
      "ci_static_checks.py 的 LANG_DIR 也硬编码了下划线那一套路径 —— 两套命名并存，任何资源重构都要同时记住两个拼写。",
      "build.gradle 的 loom.mods 块里 mod 名又写成 \"chiseled-enchanting-table\"，archives_base_name 同名，maven_group 则是下划线。四处拼写在两种风格之间来回横跳。",
    ],
    evidence: [
      { file: "src/main/resources/fabric.mod.json", note: "\"id\": \"chiseled-enchanting-table\", \"icon\": \"assets/chiseled-enchanting-table/icon.png\"" },
      { file: "src/main/resources/assets/chiseled-enchanting-table/icon.png", note: "唯一一个连字符命名空间下的文件" },
      { file: "gradle.properties", note: "maven_group=chiseled_enchanting_table（下划线）vs archives_base_name=chiseled-enchanting-table（连字符）" },
    ],
    impact:
      "不会立刻出错，但这是典型的“隐性硬编码”：命名空间字符串散落在 json、gradle、python 脚本和 Java 里，任何一次重命名都必然漏改一处。",
    fix: [
      "统一成下划线 chiseled_enchanting_table（Fabric modid 允许下划线），icon 移到同一个 assets 目录，删掉连字符目录。",
      "若必须保留连字符 modid，则在 ci_static_checks 里加一条断言：两个命名空间目录同时存在时必须解释原因。",
    ],
  },
  {
    id: "API-02",
    title: "fabric-api 依赖声明为 \"*\"，与构建期钉死的 0.162.0+26.3 不一致",
    severity: "medium",
    paths: ["api"],
    confidence: "verified",
    summary:
      "gradle.properties 把 fabric_version 精确钉到 0.162.0+26.3 并在 build.gradle 里用 toolchainPins 严防 JEI/REI 把它顶掉；fabric.mod.json 却写 \"fabric-api\": \"*\"。",
    detail: [
      "build.gradle 的那段长注释详细论证了“Fabric API 版本漂移会导致 injected_interfaces 编译失败”，说明作者非常清楚版本敏感性。",
      "但运行期约束完全放开：玩家装任意版本 Fabric API 都能启动，直到调用到某个 0.162.0 才有的 API 才 NoSuchMethodError。",
      "同一份 json 里 fabricloader 写了 >=0.19.5、java 写了 >=25、minecraft 写了精确 26.3，唯独 fabric-api 是通配。",
    ],
    evidence: [
      { file: "src/main/resources/fabric.mod.json", note: "\"depends\": { \"fabric-api\": \"*\" }" },
      { file: "gradle.properties", note: "fabric_version=0.162.0+26.3，并有 toolchainPins 排除传递依赖" },
    ],
    impact: "低版本 Fabric API 下启动成功但运行时崩溃，错误堆栈指向 Fabric 而非本 mod，增加误报。",
    fix: ["改为 \">=0.162.0\"，并在 consistency.yml 里加一条：fabric.mod.json 的下限必须等于 gradle.properties 的 fabric_version 前缀。"],
  },
  {
    id: "API-03",
    title: "-Penable_jei=false 产出的 jar 仍然声明 jei_mod_plugin entrypoint",
    severity: "medium",
    paths: ["api", "coupling"],
    confidence: "likely",
    summary:
      "viewer 开关只在 sourceSets 里 exclude 源码目录，fabric.mod.json 的 entrypoints 是静态写死的，processResources 只替换 ${version}。",
    detail: [
      "build.gradle: if (!jeiEnabled) exclude 'chiseled_enchanting_table/compat/jei/**' —— 类不会被编译进 jar。",
      "fabric.mod.json 的 entrypoints 仍然包含 jei_mod_plugin → chiseled_enchanting_table.compat.jei.ChiseledEnchantingJeiPlugin。",
      "processResources 只做 expand \"version\"，不会裁剪 entrypoints。",
      "结果：用 -Penable_jei=false 构建的 jar，如果玩家装了 JEI，JEI 在枚举 jei_mod_plugin 入口时会 ClassNotFoundException。gradle.properties 注释把这个开关描述成“沙箱/CI 无法访问 maven.blamejared.com 时的逃生舱”，这类产物很可能被当作应急发布版分发。",
      "同类问题：rei_client → ChiseledEnchantingReiPlugin。",
    ],
    evidence: [
      { file: "build.gradle:63-76", note: "只 exclude 源码，不处理 entrypoints" },
      { file: "build.gradle:115-123", note: "processResources 仅 expand version" },
      { file: "src/main/resources/fabric.mod.json", note: "entrypoints 静态包含 jei_mod_plugin / rei_client" },
    ],
    impact: "应急构建产物在装了 JEI/REI 的客户端上崩溃；而本地无 viewer 环境下测不出来。",
    fix: [
      "在 processResources 里按 jeiEnabled/reiEnabled 动态过滤 entrypoints（用 filesMatching + JsonSlurper 重写，或准备两份模板）。",
      "ci_static_checks 加一条：jar 内 entrypoints 列出的每个类都必须存在于 jar 中（这正好是脚本自述的 Tier B，但目前只覆盖 mixin，没覆盖 entrypoints）。",
    ],
  },
  {
    id: "API-04",
    title: "仓库内手写 ModMenu API 桩，并用 Jar 级 exclude 兜底",
    severity: "low",
    paths: ["api", "coupling"],
    confidence: "verified",
    summary:
      "src/client/java/com/terraformersmc/modmenu/api/ 下有自己写的 ConfigScreenFactory / ModMenuApi，再靠 tasks.withType(Jar) { exclude 'com/terraformersmc/**' } 保证不打包。",
    detail: [
      "这是在自己的源码树里伪造第三方包名。编译期能过，运行期靠真 ModMenu 提供同名接口。",
      "一旦 ModMenu 改了接口签名（例如 ConfigScreenFactory 泛型变化），本地编译依然绿，只有装了 ModMenu 的玩家会 AbstractMethodError / NoSuchMethodError。",
      "blanket exclude 'com/terraformersmc/**' 作用于所有 Jar 任务，包括 withSourcesJar() 产出的 sources jar —— 发布的源码包会缺这两个文件，别人 clone sources jar 后无法复现构建。",
      "对比：JEI/REI 走的是正经 compileOnly maven 依赖。ModMenu 其实也在 maven.terraformersmc.com 上有 API 产物，没有理由特殊对待。",
    ],
    evidence: [
      { file: "src/client/java/com/terraformersmc/modmenu/api/ModMenuApi.java", note: "手写第三方包名桩" },
      { file: "build.gradle:160-163", note: "tasks.withType(Jar).configureEach { exclude 'com/terraformersmc/**' }" },
    ],
    impact: "ModMenu 升级时的静默二进制不兼容；sources jar 不完整。",
    fix: [
      "换成 modCompileOnly \"com.terraformersmc:modmenu:<ver>\"（或 compileOnly），删除桩代码和 Jar exclude。",
      "若坚持保留桩，至少把 exclude 限定到 remapJar/jar，不要影响 sourcesJar。",
    ],
  },

  {
    id: "GUI-01",
    title: "overlay 模态转发不对称：mouseClicked/keyPressed 丢弃返回值，charTyped 根本没转发",
    severity: "medium",
    paths: ["gui"],
    confidence: "verified",
    summary:
      "同一个屏幕里，6 个输入回调有 2 种不同的转发策略；且 charTyped 完全没有被覆写。",
    detail: [
      "mouseClicked / keyPressed：调用 overlay 的方法后 **丢弃返回值并无条件 return true**。",
      "mouseScrolled / mouseDragged / mouseReleased / keyReleased：**返回 overlay 的结果**。",
      "charTyped 没有覆写 —— 现在两个 overlay 都没有文本框所以看不出问题，但只要配置界面加一个搜索框或数值输入框，字符输入就会直接穿透到父 AbstractContainerScreen（触发物品快捷键、关闭界面等）。",
      "模态语义目前靠 overlay 自己处理 ESC（ChiseledEnchantingConfigScreen:823、ArcaneGrimoireScreen:1297 都有 onClose）。能工作，但这是隐式约定而非显式契约 —— 新加一个 overlay 忘了处理 ESC，玩家就会被卡在界面里。",
    ],
    evidence: [
      { file: "src/client/java/.../gui/ChiseledEnchantingTableScreen.java:354-366", note: "mouseClicked 丢弃 overlay 返回值，return true" },
      { file: "src/client/java/.../gui/ChiseledEnchantingTableScreen.java:493-505", note: "keyPressed 同样 return true；无 charTyped 覆写" },
      { file: "src/client/java/.../gui/ChiseledEnchantingTableScreen.java:463-489", note: "mouseDragged/mouseReleased 返回 overlay 结果 —— 策略不一致" },
    ],
    impact:
      "当前无可见故障；是一个“等着被下一个功能踩中”的结构性缺陷。加文本框时必然出 bug，且症状（打字触发快捷键）很难第一时间归因到转发层。",
    fix: [
      "抽一个 private @Nullable Screen activeOverlay() 和一个统一的 forward(...) 模板，所有 6+1 个回调走同一条路径并一致返回 overlay 的结果。",
      "补 charTyped、mouseMoved、keyReleased 的转发。",
      "给 overlay 定义一个显式接口（OverlayScreen { boolean handlesEscape(); }），父屏幕在 overlay 不处理 ESC 时负责兜底关闭。",
    ],
  },
  {
    id: "GUI-02",
    title: "配置界面把 1–6 硬编码映射到 CategoryId.values()[key - KEY_1]",
    severity: "low",
    paths: ["gui", "coupling"],
    confidence: "verified",
    summary:
      "六个分类用物理按键 1–6 切换，索引直接取自枚举顺序，没有上界检查。",
    detail: [
      "if (key >= KEY_1 && key <= KEY_6) { activeCategory = CategoryId.values()[key - KEY_1]; }",
      "CategoryId 现在正好 6 个（GENERAL / BOOKSHELVES / TOMES_ECONOMY / EPIPHANY / CLEANSE_TRANSMUTE / WORLD_LOOT）。加第 7 个分类时：既无法用键盘访问，也没有编译期提示；如果有人把范围改成 KEY_1..KEY_9 而枚举只有 7 个，就是 ArrayIndexOutOfBounds。",
      "同时占用了玩家的快捷栏键位 —— 在 overlay 模态下可接受，但没有任何 UI 提示告诉玩家这些键被接管了。",
    ],
    evidence: [
      { file: "src/client/java/.../gui/config/ChiseledEnchantingConfigScreen.java:827-833", note: "CategoryId.values()[key - InputConstants.KEY_1]，无长度校验" },
    ],
    impact: "扩展性缺陷 + 潜在越界。",
    fix: [
      "用 Math.min(idx, CategoryId.values().length - 1) 或 idx < values().length 守卫；更好的做法是让分类 Tab 本身声明自己的助记键。",
    ],
  },
  {
    id: "GUI-03",
    title: "图谱动画用 System.currentTimeMillis 驱动，不跟随游戏时钟",
    severity: "low",
    paths: ["gui"],
    confidence: "verified",
    summary:
      "GrimoireDiagramRenderer:1177 用 Math.floorMod(System.currentTimeMillis() / 1600L, n) 轮播示例物品。",
    detail: [
      "不使用 partialTick / level.getGameTime()，意味着暂停游戏（单人 ESC）、截图、F1 隐藏 HUD 时动画仍在推进。",
      "1600L 这个周期是裸字面量；配置界面的 toast 超时 2600L/5000L 同样是裸字面量。",
      "对纯装饰动画影响很小，但它和 mod 内其它基于 tick 的动画（顿悟倒计时、仪式进度）在暂停时的表现不一致。",
    ],
    evidence: [
      { file: "src/client/java/.../gui/grimoire/GrimoireDiagramRenderer.java:1177", note: "System.currentTimeMillis() / 1600L" },
      { file: "src/client/java/.../gui/config/ChiseledEnchantingConfigScreen.java:224,228,246,700", note: "statusToastUntilMs 使用墙钟时间" },
    ],
    impact: "暂停时动画不停；录制/截图体验不一致。",
    fix: ["改用 Minecraft.getInstance().getDeltaTracker() 或 gui tick 计数；把周期提成命名常量。"],
  },

  {
    id: "DEAD-01",
    title: "BookshelfReplacerProcessor 的两个 postProcess* 方法零生产调用点",
    severity: "high",
    paths: ["dead", "mixin"],
    confidence: "verified",
    summary:
      "postProcessBookshelf(ServerLevel, BlockPos) 和 postProcessFilledBookshelf(ServerLevel, BlockPos) 的唯一调用方是未注册的 LevelChunkPostProcessMixin。",
    detail: [
      "这是 MX-01 的直接后果，但值得单列：它意味着 BookshelfReplacerProcessor:206 的 protoChunk.markPosForPostProcessing(pos) 在往一个没有消费者的队列里写数据。",
      "这些标记会进入区块的 postProcessing 短整型列表并被存档持久化，原版自己的 postProcessGeneration 会把它们当普通方块更新处理掉 —— 不会崩，但是纯浪费。",
      "WORLDGEN_BOOKSHELF_DEADLOCK_REPORT.md 花了大篇幅论证“为什么必须从 worldgen 挪到区块后处理”，结论正确，实施断链。",
    ],
    evidence: [
      { file: "src/main/java/.../mechanics/structure/BookshelfReplacerProcessor.java:150,161,206", note: "两个 public static 方法 + markPosForPostProcessing 写入端" },
    ],
    impact: "功能缺失（见 MX-01）+ 每个含书架的结构区块都多存一批无用的后处理标记。",
    fix: ["随 MX-01 一起修；修复后用 /place structure minecraft:stronghold_library 做验收。"],
  },
  {
    id: "DEAD-02",
    title: "47 处 Config.DEFAULT 回退重载，其中 computeSacrificeXpLevels(long) 只被测试使用",
    severity: "low",
    paths: ["dead", "coupling", "balance"],
    confidence: "verified",
    summary:
      "单参重载 computeSacrificeXpLevels(long) 内部写死 Config.DEFAULT，生产代码全部走双参版本，只有单元测试在调它。",
    detail: [
      "InscriptionRitualMechanics:643-645 —— public static int computeSacrificeXpLevels(long) { return computeSacrificeXpLevels(Config.DEFAULT, remainingTicks); }",
      "ScreenHandler:729 和 :877 两处生产调用都传了真实 config。EconomyAndConfigVerificationTest:1292/1301 是仅有的其它调用点。",
      "全仓 Config.DEFAULT 回退共出现 47 次。这个模式本身是合理的防御（配置为 null 时不崩），但“无参/单参便利重载”会把它变成陷阱：新代码随手调了便利重载，服务端配置就被静默忽略，而且测试还会通过（因为测试用的就是默认值）。",
    ],
    evidence: [
      { file: "src/main/java/.../mechanics/ritual/InscriptionRitualMechanics.java:643-645", note: "单参重载硬编码 Config.DEFAULT" },
      { file: "src/test/java/.../EconomyAndConfigVerificationTest.java:1292,1301", note: "唯二的其它调用点，均在测试中" },
    ],
    impact: "配置静默失效的高发模式；当前仅是死代码。",
    fix: [
      "删除仅测试使用的便利重载，测试里显式传 Config.DEFAULT。",
      "对确实需要的 @Nullable Config 回退保留，但禁止再新增无 Config 参数的重载（可加一条 checkstyle/正则门禁）。",
    ],
  },
  {
    id: "DEAD-03",
    title: "PayloadLimits.MAX_COLLECTION 与 5 个历史协议通道常量是只增不减的包袱",
    severity: "low",
    paths: ["dead", "network"],
    confidence: "verified",
    summary:
      "MAX_COLLECTION 是 MAX_COLLECTION_ENTRIES 的同值别名且零引用；EnchantingProtocol 保留了 revision 4/5/6/7 + 无后缀共 5 个历史 cost 通道。",
    detail: [
      "PayloadLimits.MAX_COLLECTION = MAX_COLLECTION_ENTRIES —— 全仓无任何引用。",
      "5 个历史通道只在 EnchantCostSync:48-52 的一长串 canSend(...) || 里用作“对端是不是装了某个旧版本”的探测。每升一版就多一个常量和多一个 || 分支，没有淘汰策略。",
      "注释写着 “Never register a decoder on these older channels” —— 说明作者清楚风险，但没有给出退役时间表。",
    ],
    evidence: [
      { file: "src/main/java/.../menu/PayloadLimits.java:8", note: "MAX_COLLECTION 零引用别名" },
      { file: "src/main/java/.../menu/EnchantingProtocol.java:19-32", note: "LEGACY / PREVIOUS / REVISION_5 / 6 / 7 共 5 个历史通道" },
      { file: "src/main/java/.../menu/EnchantCostSync.java:48-52", note: "5 个 canSend 的 || 链" },
    ],
    impact: "维护噪声；每次 bump 协议都线性增长。",
    fix: [
      "删除 MAX_COLLECTION。",
      "历史通道改成 List<Type<?>> LEGACY_PROBES 并用 stream().anyMatch 检测；约定只保留最近 2 个版本，更早的直接移除（反正它们都会被 disconnect 拦下）。",
    ],
  },

  {
    id: "COUP-01",
    title: "menu 包反向依赖全栈，ScreenHandler 2525 行且大量使用全限定名内联引用",
    severity: "high",
    paths: ["coupling"],
    confidence: "verified",
    summary:
      "P15 解耦报告宣称 menu 只负责槽位/成本/派发，实际上 ChiseledEnchantingTableScreenHandler 仍然直接 new/引用 block、mechanics、data、config 四层。",
    detail: [
      "类里反复出现 chiseled_enchanting_table.block.ChiseledEnchantingTableBlockEntity、chiseled_enchanting_table.mechanics.ritual.InscriptionRitualMechanics 这种**全限定名内联写法**（而不是 import）。在 Java 里这通常是 import 名字冲突或作者在规避循环依赖感知的信号。",
      "同时它还是网络层：静态 init() 里注册了 5 个 serverbound 接收器，等于把“容器”“协议”“业务派发”三件事塞进同一个类。",
      "字段清单直接暴露为 public：unlocked_enchantements、xpDiscountPercent、regularBookshelves、chiseledBookshelves、storedMasterLevels、masterTomeCharges、transformationDisplays … 共 12 个 public 可变字段，被 client GUI 直接读写。",
      "命名风格也混用了 Java 的 camelCase 和上游遗留的 snake_case（get_cost_item / get_enchantable_item / unlocked_enchantements）。",
    ],
    evidence: [
      { file: "src/main/java/.../menu/ChiseledEnchantingTableScreenHandler.java", note: "2,525 行；静态 init() 注册 5 个网络接收器；12 个 public 可变字段" },
      { file: "同上:150-160, 729, 877", note: "chiseled_enchanting_table.block.* / mechanics.ritual.* 全限定名内联引用" },
      { file: "docs/reports/PORTING_26_1_2_P15_DECOUPLING_REPORT.md", note: "声称 menu 已只保留容器职责" },
    ],
    impact:
      "任何对附魔逻辑的改动都要动这个 2500 行的类；单元测试无法脱离 Minecraft 启动它（现有测试只能测 codec 和纯算术）。",
    fix: [
      "把 static init() 的网络注册搬到独立的 EnchantingNetworking 类（和已有的 EnchantCostSync 并列）。",
      "把 12 个 public 字段收成一个不可变 MenuSnapshot record，GUI 只读快照。",
      "统一命名：get_cost_item → getCostItem 等，上游遗留名加 @Deprecated 过渡。",
    ],
  },
  {
    id: "COUP-02",
    title: "ChiseledEnchantingTableData 是 2594 行的 God Object",
    severity: "medium",
    paths: ["coupling", "codec"],
    confidence: "verified",
    summary:
      "同一个类既是 ReloadListener，又持有 14 张静态表，又定义全部数据包 Codec 和内置 fallback，还负责 Identifier 常量表。",
    detail: [
      "implements SimpleSynchronousResourceReloadListener + 14 个 static 可变字段 + builtIn*Fallback() 系列 + 10 个 RELOAD/数据文件 Identifier 常量。",
      "它同时被 menu、mechanics、compat（JEI/REI 索引）、client GUI 四个方向引用 —— 是整个依赖图的枢纽节点。",
      "2594 行是全仓最大文件，紧随其后的是 2525 行的 ScreenHandler。两个枢纽都超过 2500 行，说明“解耦”系列报告（P15/P17/P18）处理的是叶子而不是中心。",
    ],
    evidence: [
      { file: "src/main/java/.../data/ChiseledEnchantingTableData.java", note: "2,594 行；ReloadListener + 14 静态表 + Codec + fallback + 常量表" },
    ],
    impact: "改任何一张数据表都要重编译半个项目；并发语义不清（见 DATA-02）。",
    fix: [
      "拆成：DataTables（不可变快照 record）/ DataCodecs（纯 Codec 定义）/ DataReloadListener（只负责读取与换入）/ DataIds（常量）。",
      "快照化之后 DATA-02 的 volatile 问题自然消失。",
    ],
  },
  {
    id: "COUP-03",
    title: "MasterTomeWear 把物品 NBT 层和世界方块实体层揉在一个静态工具类",
    severity: "medium",
    paths: ["coupling"],
    confidence: "verified",
    summary:
      "同一个类既定义 cet_tome_wear 等 NBT 键和纯函数式的磨损计算，又直接扫描世界、读写 ChiseledBookShelfBlockEntity。",
    detail: [
      "纯数据侧：NBT_WEAR_KEY / NBT_REGEN_TICKS_KEY / NBT_REGEN_BUCKET_KEY、computeUnbreakingWaiverChance、computeRegenIntervalTicks —— 这些是可单测的纯逻辑。",
      "世界侧：snapshotLiveMasterCharges(...)、applyShelfWearDetailed(world, tablePos, ...) 会遍历扫描范围内所有方块实体、按 CANDIDATE_ORDER 排序、写回书架。",
      "两类代码混在 706 行里，导致磨损公式无法在不 mock ServerLevel 的情况下被测试，也导致 client 侧 tooltip 必须 import 同一个类（从而把世界扫描代码拖进客户端 classpath）。",
    ],
    evidence: [
      { file: "src/main/java/.../mechanics/resonance/MasterTomeWear.java:50-75, 455-540, 599+", note: "NBT 键 + 纯计算 + 世界扫描混排" },
      { file: "src/client/java/.../ChiseledEnchantingTableClient.java:~95", note: "客户端 tooltip 直接调用 MasterTomeWear.getWearUsed / computeUnbreakingWaiverChance" },
    ],
    impact: "测试成本高；客户端被迫依赖服务端世界逻辑。",
    fix: ["拆成 TomeWearData（NBT 读写 + 纯公式，client 可安全依赖）和 TomeWearWorldOps（世界扫描与写回，server only）。"],
  },
  {
    id: "COUP-04",
    title: "客户端 DISCONNECT 回调直接重写服务端共享的静态数据表",
    severity: "medium",
    paths: ["coupling", "codec"],
    confidence: "likely",
    summary:
      "ClientPlayConnectionEvents.DISCONNECT 里调用 ChiseledEnchantingTableData.applyRuntimeConfig(ModRuntimeConfig.get())，在单人模式下与集成服务端的关闭流程共享同一份静态状态。",
    detail: [
      "JOIN/SYNC 路径已经很小心了：收到 SyncRuntimeConfigPayload 时有 if (!ctx.client().hasSingleplayerServer()) 保护，注释明确写“集成服务端已在服务端线程提交过共享表”。",
      "但 DISCONNECT 路径没有同样的保护，无条件在客户端线程重写表。",
      "单人退出世界时，集成服务端可能仍在保存区块 / 跑最后几个 tick（loot、战利品注入都会读这些表）。这是一个窄但真实的竞态窗口。",
    ],
    evidence: [
      { file: "src/client/java/.../ChiseledEnchantingTableClient.java:186-190", note: "DISCONNECT 无 hasSingleplayerServer 保护" },
      { file: "src/client/java/.../ChiseledEnchantingTableClient.java:141-152", note: "SYNC 路径有保护，形成对照" },
    ],
    impact: "单人退出瞬间的罕见不一致；最坏情况是最后一批区块保存时用了错误的战利品规则。",
    fix: ["给 DISCONNECT 加同样的 hasSingleplayerServer 判断；或把恢复动作推迟到 ServerLifecycleEvents.SERVER_STOPPED。"],
  },

  {
    id: "BAL-01",
    title: "仪式时长曲线的归一化常数 42.0 / 22.0 硬编码，与可配置的书架上限脱钩",
    severity: "medium",
    paths: ["balance", "coupling"],
    confidence: "verified",
    summary:
      "shelfLoad = nearbyBookshelves / 42.0、tomeLoad = totalMasterTomeEnchantments / 22.0 是裸字面量，而 max_direct_bookshelves 在配置里可调 4–64、扫描半径可调 1–8。",
    detail: [
      "完整公式：intensity = (0.42·shelfLoad + 0.58·tomeLoad) · (0.35 + 0.65·relLevel^1.15) · max(1, applicabilityFactor)；seconds = maxSec · (1 − e^(−0.62·intensity))。",
      "其中 0.42 / 0.58 / 0.35 / 0.65 / 1.15 / 0.62 以及下界 Mth.clamp(ticks, 100, ...) 的 100 全部是裸字面量，没有一个进入 InscriptionRitualMechanics.Config。",
      "42.0 显然是从 MasterTomeWear.DEFAULT_REGEN_TIER2_SHELVES = 42 抄来的，但是复制而非引用。管理员把 max_direct_bookshelves 调到 64 后，shelfLoad 会超过 1.0 并继续线性推高 intensity；调到 20 则永远跑不满曲线。",
      "对比之下，CrosslineSlipConfig 把 24 个参数全部做成了可配置并带 clampFinite 兜底 —— 同一个类里两套标准。",
    ],
    evidence: [
      { file: "src/main/java/.../mechanics/ritual/InscriptionRitualMechanics.java:628-637", note: "/42.0、/22.0、0.42/0.58/0.35/0.65/1.15/0.62、clamp(ticks,100,...)" },
      { file: "src/main/java/.../mechanics/resonance/MasterTomeWear.java:74", note: "DEFAULT_REGEN_TIER2_SHELVES = 42 —— 42.0 的真正来源" },
      { file: "src/main/java/.../config/ConfigCatalog.java", note: "max_direct_bookshelves 范围 4–64，horizontal_scan_radius 1–8" },
    ],
    impact: "改配置后仪式时长曲线行为不可预测；是“配置系统看起来很完整但关键曲线绕过了它”的典型。",
    fix: [
      "把归一化分母改成 cfg.maxDirectBookshelves() 和一个新增的 ritualTomeLoadReference 配置项。",
      "把 6 个曲线系数收进 Config（和 CrosslineSlipConfig 一样带 clampFinite），默认值保持现状以免破坏存档平衡。",
    ],
  },
  {
    id: "BAL-02",
    title: "XP 折扣的分段上限互相冗余，40% 总上限在多数路径上不可达",
    severity: "medium",
    paths: ["balance"],
    confidence: "verified",
    summary:
      "木书架 ≤15% + 全局精通 ≤20% = 35%，恰好等于 MAX_BASE_XP_DISCOUNT_PERCENT；再加对应词条 ≤15% 才会撞上 MAX_TOTAL_XP_DISCOUNT_PERCENT = 40%。",
    detail: [
      "LibraryResonance 的 6 个上限常量：MIN_DISCOUNT_BOOKSHELVES=12、MAX_WOODEN_DISCOUNT_PERCENT=15、MAX_GLOBAL_MASTERY_DISCOUNT_PERCENT=20、MAX_BASE_XP_DISCOUNT_PERCENT=35、MAX_SPECIFIC_ENCHANT_BONUS_PERCENT=15、MAX_TOTAL_XP_DISCOUNT_PERCENT=40。",
      "35 = 15 + 20 不是巧合，是“两项之和”的硬编码复述。也就是说 base 上限这一层永远不会真正生效（它恰好等于两个子项的理论最大值）。",
      "真正起约束的只有 40 这一层，而且只在“匹配词条加成生效”时才触发：15+20+15 = 50 → 截到 40。",
      "结果：调参者改 MAX_WOODEN_DISCOUNT_PERCENT 到 20 后，35 这一层突然开始生效，产生一个非线性的、没人预期的拐点。",
    ],
    evidence: [
      { file: "src/main/java/.../mechanics/resonance/LibraryResonance.java:31-36", note: "6 个上限常量，35 = 15 + 20" },
    ],
    impact: "调参时出现不可达区间和隐藏拐点；README 里写的“up to −20% global + −15% matching，total cap −40%”对玩家也是误导（木书架那 15% 没写进这句话）。",
    fix: [
      "删掉 MAX_BASE_XP_DISCOUNT_PERCENT，或把它改成由两个子上限之和派生（min(35, wooden + mastery)）而不是独立常量。",
      "在 EconomyAndConfigVerificationTest 里加一条属性测试：对所有子上限组合，断言总上限层确实是唯一的截断点。",
    ],
  },
  {
    id: "BAL-03",
    title: "模板书经济可能净增：4 点耐久 / 抄录消耗 2，而抄出来的新书满耐久",
    severity: "medium",
    paths: ["balance"],
    confidence: "needs-review",
    summary:
      "一本满耐久（4）的模板书可以抄 2 次，产出 2 本各 4 点的新书 —— 总耐久从 4 变成 8，外加原书残留 0。",
    detail: [
      "README 的参数：非 Infinity 附魔书每档 4 点耐久；给装备附魔消耗 1，抄到书上消耗 2；Unbreaking 最高 30% 免磨损；野外战利品书预磨损（多数只剩 1–2 点）。",
      "预磨损只作用于世界生成/战利品（ApplyWildBookWearFunction 是一个 LootItemFunction），玩家在台子上抄出来的新书走的是正常制作路径。需要确认 BookUpgradeApplication / EnchantmentApplication 是否对“新产出的书”也写入初始磨损。",
      "如果没有，那么净耐久是单调递增的：4 → (2 次抄录) → 8。再叠加书架被动回充（0/38/42 书架分别 6/3/1 游戏日 +1 耐久），模板书实际上是可再生资源，“耐久”这层约束只在时间维度上生效，不在总量维度上生效。",
      "这不一定是 bug —— 可能就是设计意图（用时间而非总量限流）。但 README 把它描述成消耗品经济（“durability per tier”“spends 1 / spends 2”），两种叙述不一致。",
      "Unbreaking 30% 免磨损会进一步放大：一本带 Unbreaking III 的模板书期望抄录次数 ≈ 4 / (2 × 0.7) ≈ 2.86 次。",
    ],
    evidence: [
      { file: "src/main/java/.../mechanics/resonance/MasterTomeWear.java:59-75", note: "DEFAULT_MAX_TOME_USES=4、DEFAULT_BOOK_COPY_WEAR_COST=2、UNBREAKING_WAIVER_MAX=0.30、REGEN 6/3/1 游戏日" },
      { file: "src/main/java/.../mechanics/loot/ApplyWildBookWearFunction.java", note: "预磨损是 LootItemFunction —— 只影响世界生成产物" },
      { file: "src/main/java/.../mechanics/enchanting/BookUpgradeApplication.java", note: "需确认新产出的书是否写入初始 wear" },
    ],
    impact:
      "若确认为净增，则“模板书耐久”这一整套机制在中后期形同虚设，README 的描述会误导服务器管理员的平衡预期。",
    fix: [
      "优先确认 BookUpgradeApplication 产出的新书初始 wear 值；若为 0，考虑让抄录产物继承 ceil(source.wear / 2) 或直接写入 1 点初始磨损。",
      "或者接受“时间限流”设计，但把 README 改写成“耐久 = 冷却计量器”而不是“消耗品”。",
      "无论哪种，都应在 EconomyAndConfigVerificationTest 里加一条守恒断言（现有测试已有 XP 守恒断言，缺耐久守恒）。",
    ],
  },
  {
    id: "BAL-04",
    title: "Infinity 模板书的风险曲线与奖励直觉相反",
    severity: "medium",
    paths: ["balance"],
    confidence: "likely",
    summary:
      "Infinity 书完全免磨损，但一旦装载 L ≥ 3 条附魔就开始有 ≤18% 的抄录事故（70% 降一档 / 25% 废词条 / 5% 诅咒）。",
    detail: [
      "设计意图可以理解：给“无限资源”加一道税。但执行上，玩家拿到 Infinity 书之后的最优策略变成“故意保持每本只装 1–2 条附魔”，因为 L < minLoadThreshold(3.0) 时事故率为 0。",
      "这把 Infinity 从“终局奖励”变成了“需要小心管理的负担”，而且最优解是反直觉的（不要把好东西堆在一起）。",
      "18% 的单次判定在批量操作下方差很大：连续抄 10 次，至少一次事故的概率 ≈ 86%；其中 5% 分支会直接给一个诅咒。虽然有 50% XP/材料返还和墨渍可清洗，但“10 次里几乎必然翻车一次”的体感偏硬。",
      "shelfTier1/2/3 Bonus（32/38/42 书架分别 +1%/+2%/+3%）是**增加**事故率还是**降低**？从字段名 Bonus 和 CrosslineSlipConfig 的上下文看是叠加进 slipChance 的 —— 如果是增加，那么“建更大的图书馆”会让事故更频繁，这与图书馆共鸣其它所有维度（降 XP、加速回充、解锁档位）的方向完全相反，强烈建议复核。",
    ],
    evidence: [
      { file: "src/main/java/.../mechanics/ritual/InscriptionRitualMechanics.java:82,120-165", note: "MAX_TRANSCRIPTION_SLIP_CHANCE=0.18；CrosslineSlipConfig.DEFAULT 的 minLoadThreshold=3.0、shelfTier1/2/3Bonus=0.01/0.02/0.03、tierDrop/junk/curse = 0.70/0.25/0.05、pollutionRefundRatio=0.50" },
    ],
    impact: "终局玩法激励扭曲；shelfTierBonus 的符号方向若为正则与整个图书馆共鸣系统自相矛盾。",
    fix: [
      "复核 shelfTier*Bonus 的叠加方向；若确为提高事故率，建议改为降低（大图书馆 = 更稳的抄录），把“税”留给 L 载荷维度。",
      "把单次 18% 改成“每次抄录累积一个隐藏的风险计数器，到阈值必定触发一次小事故”，用确定性替代高方差。",
      "minLoadThreshold 从 3.0 提高到 5.0 左右，让“2–3 条附魔的 Infinity 书”依然是纯粹的奖励。",
    ],
  },
  {
    id: "BAL-05",
    title: "外部附魔 25% 返还依赖写在物品上的 Provenance，跨版本/跨模组装备会被误判",
    severity: "medium",
    paths: ["balance", "codec"],
    confidence: "likely",
    summary:
      "disenchantExternalRefundScale 默认 0.25，用来防止刷怪物掉落附魔装备换 XP；判定依据是 EnchantmentProvenance 写在物品 NBT/组件上的来源标记。",
    detail: [
      "EnchantmentProvenance（222 行）负责标记“这条附魔是不是在本台子上刻的”。没有标记的一律按外部处理，退 25%。",
      "这意味着：① 安装本 mod 之前就存在的老存档装备，全部变成“外部”；② 其它附魔类模组产出的装备，全部“外部”；③ 用 /enchant 或创造模式给的装备，“外部”；④ 组件被某些工具（如一些背包/存储 mod 的序列化）剥离后，也变成“外部”。",
      "对于一个号称“可以随时剥离或降级而不损失进度”的 mod，老玩家升级后第一次拆解旧装备就会发现只退 25%，而且没有任何 UI 解释为什么。",
      "好的一面：README 把这条写出来了，且 refundScale 是可配置的。",
    ],
    evidence: [
      { file: "src/main/java/.../mechanics/enchanting/EnchantmentProvenance.java", note: "222 行，附魔来源标记" },
      { file: "src/main/java/.../menu/EnchantCostTablePayload.java:35", note: "disenchantExternalRefundScale 作为网络同步字段" },
    ],
    impact: "存档迁移体验差；跨模组兼容性差；玩家会以为是 bug。",
    fix: [
      "在 GUI 的返还数值旁边显示一个可悬停的徽标，说明“此附魔非本台刻印，按 X% 返还”。",
      "提供一次性迁移开关（grandfather_existing_gear），首次加载旧存档时把现有附魔视为内部。",
      "对 /enchant 和创造模式给予的装备，考虑单独的 creativeRefundScale。",
    ],
  },
  {
    id: "BAL-06",
    title: "五组书架阈值彼此独立硬编码，42 超出了书架上限 38",
    severity: "low",
    paths: ["balance"],
    confidence: "verified",
    summary:
      "档位 [0,7,16,27,38]、折扣起点 12、Treasure Epiphany 门槛 32、回充 Tier1 38 / Tier2 42 —— 而 DEFAULT_MAX_DIRECT_BOOKSHELVES = 38。",
    detail: [
      "38 同时扮演两个角色：“解锁满档所需书架数”和“回充 Tier1 阈值”。它们恰好相等，但在代码里是两个独立常量（BookshelfProgression.DEFAULT_MAX_DIRECT_BOOKSHELVES 和 MasterTomeWear.DEFAULT_REGEN_TIER1_SHELVES），改一个不会动另一个。",
      "42 > 38：要吃满“1 游戏日回充”必须额外摆 4 个对附魔档位完全无贡献的书架。README 的表格把这解释为“empty chiseled bookshelf 也计入 total nearby shelves”，所以是可达的 —— 但设计意图（为什么是 42？）没有在代码或文档里说明。",
      "32（Treasure Epiphany）落在 27 和 38 两个档位之间，不对应任何档位边界。",
      "五个数字（12 / 16 / 27 / 32 / 38 / 42）分散在三个类里，没有一张集中的阈值表，也没有一条测试断言它们的相对顺序。",
    ],
    evidence: [
      { file: "src/main/java/.../mechanics/resonance/BookshelfProgression.java:40-54", note: "DEFAULT_MAX_DIRECT_BOOKSHELVES=38、TIER1=12、TIER2=32、曲线指数 1.25" },
      { file: "src/main/java/.../mechanics/resonance/MasterTomeWear.java:70-75", note: "REGEN_TIER1_SHELVES=38、REGEN_TIER2_SHELVES=42" },
    ],
    impact: "玩家无法从 UI 推断为什么 39–42 个书架“还有用”；调参者容易把两个 38 改成不一致。",
    fix: [
      "建一张 ShelfThresholds 常量表（或直接放进 shelf_gates.json 数据包），所有阈值从一处派生。",
      "加一条 ordering 断言测试：discountStart < epiphanyGate < maxDirect ≤ regenTier1 < regenTier2 ≤ 扫描体积上限。",
      "在纂刻秘典里画一条阈值刻度尺，把 12/32/38/42 标出来。",
    ],
  },
  {
    id: "BAL-07",
    title: "正面评价：XP 守恒与载荷边界做得扎实",
    severity: "info",
    paths: ["balance", "network", "codec"],
    confidence: "verified",
    summary:
      "有几处设计明显优于同类 mod，审计中应当记录下来以免后续重构时被误删。",
    detail: [
      "XpCostConversion 全链路用“点数”而不是“等级”做扣减与返还（totalPlayerXpPoints / pointsForLevelCost），并在 applyEnchantementConditionWithReceipt 里以 xpBefore − xpAfter 的实测差额开收据 —— 这是防止“等级制四舍五入刷 XP”的正确做法。",
      "PayloadLimits.readBoundedCount 显式拒绝负数（注释写明 “never treat negative counts as empty”），EnchantCostTablePayload 在编码和解码两侧都做对称的 MAX_TOTAL_COST_STACKS 校验。",
      "NetworkCompatibilityTest 用真实 StreamCodec 做 round-trip 并断言 buf.readableBytes() == 0（“Unconsumed bytes: encoder/decoder field drift”），还特意用互不相同的数值填充 config 以捕获字段换位 —— 这是我在 mod 仓库里见过的最好的编解码测试之一。",
      "BlockEntity 的损坏队列隔离（ritualCorruptQueue + ritualBlocked + 保留库存 + error 日志）而不是吞异常或清空，对存档安全友好。",
      "CrosslineSlipConfig 的 24 个参数全部带 clampFinite(value, min, max, fallback)，对 NaN/Infinity 也有防御。",
    ],
    evidence: [
      { file: "src/main/java/.../mechanics/enchanting/XpCostConversion.java", note: "点数制扣减 + 实测差额收据" },
      { file: "src/test/java/.../NetworkCompatibilityTest.java:23-29", note: "round-trip + 剩余字节断言 + 异值填充" },
      { file: "src/main/java/.../menu/PayloadLimits.java:14-33", note: "负数与上界双向拒绝" },
    ],
    impact: "—",
    fix: ["重构 menu/data 包时请保留这些不变量，并把 round-trip 测试的覆盖扩展到 ApplyEnchantmentPayload 的非法输入分支。"],
  },
];

export const ROADMAP = [
  {
    tier: "P0",
    title: "先让已经写好的代码真正跑起来",
    tone: "rose",
    items: [
      "注册 structure.StructurePieceAccessor / StructurePieceMarkMixin / LevelChunkPostProcessMixin（MX-01、DEAD-01）",
      "删除 mixin/chiseled_bookshelf/ 重复目录，避免补注册时冲突（MX-03）",
      "给 ci_static_checks.py 加反向 Mixin 注册门禁，否则同类问题必然复发（MX-02）",
      "用 /place structure 做一次要塞图书馆验收，而不是只看 mixin 是否命中",
    ],
  },
  {
    tier: "P1",
    title: "消除数据损坏与协议单边信任",
    tone: "orange",
    items: [
      "RemoveEnchantMerge 改用 @WrapOperation/局部副本，消除 count 改写窗口（MX-04）",
      "补服务端侧协议能力校验，并把业务通道统一加 REVISION 后缀（NET-01、NET-02）",
      "ApplyEnchantmentPayload 在 compact constructor 做边界校验，readUtf 限长（NET-03）",
      "ChiseledEnchantingTableData 快照化为单个 volatile 不可变 record（DATA-02、COUP-02）",
    ],
  },
  {
    tier: "P2",
    title: "把隐性硬编码收进配置与常量表",
    tone: "amber",
    items: [
      "仪式时长曲线的 42.0 / 22.0 / 6 个系数进 Config（BAL-01）",
      "五组书架阈值集中到 ShelfThresholds 或 shelf_gates.json，加 ordering 断言（BAL-06）",
      "折扣上限层级去冗余，删掉派生性质的 MAX_BASE_XP_DISCOUNT_PERCENT（BAL-02）",
      "统一命名空间为 chiseled_enchanting_table，删除连字符 assets 目录（API-01）",
      "entrypoints 随 enable_jei/enable_rei 动态裁剪（API-03）",
    ],
  },
  {
    tier: "P3",
    title: "结构与体验打磨",
    tone: "sky",
    items: [
      "GUI 输入统一转发模板 + 补 charTyped（GUI-01）",
      "拆分 ScreenHandler 的网络注册职责、收敛 12 个 public 字段（COUP-01）",
      "MasterTomeWear 拆成纯数据层 / 世界操作层（COUP-03）",
      "复核模板书耐久守恒与 Infinity 风险曲线方向（BAL-03、BAL-04）",
      "外部附魔返还加 UI 解释与老存档迁移开关（BAL-05）",
    ],
  },
];

export const METHOD = [
  {
    step: "01",
    title: "获取与建立基线",
    body: "按指定分支浅克隆仓库，统计 95 个 Java 文件 / 33,359 行，建立文件—包—职责映射，并对照 gradle.properties、fabric.mod.json、mixins.json 三份声明确认目标平台（MC 26.3 / Fabric 0.19.5 / Java 25）。",
  },
  {
    step: "02",
    title: "声明层与实现层对账",
    body: "把所有“声明性文件”（mixins.json、fabric.mod.json entrypoints、build.gradle sourceSets、CI 脚本断言）与实际源码做双向差集。MX-01 / API-03 都是从这一步的反向差集里掉出来的。",
  },
  {
    step: "03",
    title: "按七条路径逐条走查",
    body: "源码 API（构建与元数据）→ 数据编解码（NBT/Codec/StreamCodec 对称性）→ 网络同步（通道、握手、服务端权威校验）→ GUI 输入（事件转发与模态）→ Mixin 注入（注册、注入点、目标可变性）→ 死代码（零调用点）→ 耦合风险（依赖方向与共享可变态）。",
  },
  {
    step: "04",
    title: "数值与机制合理性复核",
    body: "提取全部调参常量，区分“进了 Config 的”和“裸字面量”，再检查两者之间的隐式耦合（例如 42.0 抄自 REGEN_TIER2_SHELVES）。随后对经济链路做守恒推演：XP、模板书耐久、返还比例。",
  },
  {
    step: "05",
    title: "定级与可执行化",
    body: "每条发现标注证据位置、置信度（verified / likely / needs-review）、影响面与具体修法。只有能在源码里定位到行的才计入 verified；依赖运行期验证的标 needs-review。",
  },
];
