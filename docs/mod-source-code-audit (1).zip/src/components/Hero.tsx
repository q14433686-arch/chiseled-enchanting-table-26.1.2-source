import { REPO, STATS } from "../data/audit";

export default function Hero() {
  return (
    <header className="relative overflow-hidden border-b border-white/10">
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.25]"
        style={{
          backgroundImage:
            "radial-gradient(60rem 30rem at 15% -10%, #7c3aed55, transparent 60%), radial-gradient(45rem 25rem at 85% 0%, #0891b255, transparent 60%)",
        }}
      />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            "linear-gradient(to right, #fff 1px, transparent 1px), linear-gradient(to bottom, #fff 1px, transparent 1px)",
          backgroundSize: "44px 44px",
          maskImage: "linear-gradient(to bottom, black, transparent 85%)",
        }}
      />

      <div className="relative mx-auto max-w-7xl px-5 pb-14 pt-10 sm:px-8 lg:pt-16">
        <div className="flex flex-wrap items-center gap-3 text-[11px] font-medium tracking-wide">
          <span className="rounded-full border border-violet-400/30 bg-violet-500/10 px-3 py-1 text-violet-200">
            源码审计报告 · Source Audit
          </span>
          <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-slate-300">
            Minecraft {REPO.mc} · {REPO.loader} · Java {REPO.java}
          </span>
          <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-slate-300">
            mod v{REPO.modVersion} · 网络协议 revision 8
          </span>
        </div>

        <h1 className="mt-6 text-balance text-3xl font-semibold leading-tight tracking-tight text-white sm:text-4xl lg:text-[2.9rem]">
          Chiseled Enchanting Table
          <span className="block bg-gradient-to-r from-violet-300 via-fuchsia-200 to-sky-300 bg-clip-text text-transparent">
            26.3 非官方移植分支 · 全链路代码审查
          </span>
        </h1>

        <p className="mt-5 max-w-3xl text-[15px] leading-relaxed text-slate-300/90">
          按「源码 API → 数据编解码 → 网络同步 → GUI 输入 → Mixin 注入 → 死代码 → 耦合风险 → 数值与机制设计」
          八条路径对整个仓库做了一轮逐文件走查，重点追查
          <span className="text-violet-200"> 不应该硬编码的常量</span>、
          <span className="text-fuchsia-200"> 对 26.3 这个具体版本成立的缺陷</span>，
          以及 <span className="text-sky-200">声明层与实现层之间的分叉</span>。
          共 35 条发现，其中 1 条致命级 —— 一整套已经写完、文档也写完的世界生成特性从未被加载过。
        </p>

        <a
          href={REPO.url}
          target="_blank"
          rel="noreferrer"
          className="group mt-6 inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-4 py-2 font-mono text-xs text-slate-300 transition hover:border-violet-400/40 hover:bg-violet-500/10 hover:text-violet-100"
        >
          <svg viewBox="0 0 16 16" className="h-4 w-4 fill-current" aria-hidden>
            <path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82a7.4 7.4 0 0 1 2-.27c.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.01 8.01 0 0 0 16 8c0-4.42-3.58-8-8-8Z" />
          </svg>
          {REPO.owner}/{REPO.name}
          <span className="text-slate-500">@</span>
          <span className="text-fuchsia-200/80">arena/1ac4c727…-26-1</span>
          <span className="transition group-hover:translate-x-0.5">→</span>
        </a>

        <dl className="mt-10 grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-white/10 bg-white/10 sm:grid-cols-3 lg:grid-cols-6">
          {STATS.map((s) => (
            <div key={s.label} className="bg-[#0d0b18] px-4 py-4">
              <dt className="text-[11px] font-medium text-slate-400">{s.label}</dt>
              <dd className="mt-1 font-mono text-xl font-semibold text-white">{s.value}</dd>
              <dd className="mt-0.5 text-[10.5px] leading-snug text-slate-500">{s.sub}</dd>
            </div>
          ))}
        </dl>
      </div>
    </header>
  );
}
