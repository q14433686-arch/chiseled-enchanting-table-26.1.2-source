import { useMemo, useState } from "react";
import {
  FINDINGS,
  PATHS,
  SEVERITY,
  type Finding,
  type PathId,
  type Severity,
} from "../data/audit";
import { cn } from "../utils/cn";

const CONFIDENCE: Record<Finding["confidence"], { label: string; cls: string }> = {
  verified: { label: "已在源码定位", cls: "text-emerald-300 border-emerald-400/30 bg-emerald-400/10" },
  likely: { label: "高度可能", cls: "text-amber-200 border-amber-400/30 bg-amber-400/10" },
  "needs-review": { label: "需运行期复核", cls: "text-sky-200 border-sky-400/30 bg-sky-400/10" },
};

function SeverityChip({ s }: { s: Severity }) {
  const m = SEVERITY[s];
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 text-[11px] font-semibold", m.chip)}>
      <span className={cn("h-1.5 w-1.5 rounded-full", m.dot)} />
      {m.label}
    </span>
  );
}

function Card({ f, index }: { f: Finding; index: number }) {
  const [open, setOpen] = useState(index < 1);
  return (
    <article
      className={cn(
        "overflow-hidden rounded-xl border border-white/10 bg-[#0e0c1a]/80 ring-1 ring-inset transition",
        open ? SEVERITY[f.severity].ring : "ring-transparent hover:border-white/20",
      )}
    >
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-start gap-4 px-4 py-4 text-left sm:px-5"
      >
        <span className="mt-0.5 shrink-0 rounded-md bg-white/5 px-2 py-1 font-mono text-[11px] font-semibold text-slate-300">
          {f.id}
        </span>
        <span className="min-w-0 flex-1">
          <span className="flex flex-wrap items-center gap-2">
            <SeverityChip s={f.severity} />
            {f.paths.map((p) => (
              <span
                key={p}
                className="rounded border border-white/10 px-1.5 py-0.5 text-[10.5px] font-medium"
                style={{ color: PATHS[p].accent, backgroundColor: PATHS[p].accent + "12" }}
              >
                {PATHS[p].label}
              </span>
            ))}
            <span className={cn("rounded border px-1.5 py-0.5 text-[10.5px]", CONFIDENCE[f.confidence].cls)}>
              {CONFIDENCE[f.confidence].label}
            </span>
          </span>
          <h3 className="mt-2 text-[15px] font-semibold leading-snug text-white">{f.title}</h3>
          <p className="mt-1.5 text-[13px] leading-relaxed text-slate-400">{f.summary}</p>
        </span>
        <span
          className={cn(
            "mt-1 shrink-0 text-slate-500 transition-transform",
            open && "rotate-180",
          )}
        >
          <svg viewBox="0 0 20 20" className="h-4 w-4 fill-current">
            <path d="M5.5 7.5 10 12l4.5-4.5H5.5Z" />
          </svg>
        </span>
      </button>

      {open && (
        <div className="border-t border-white/10 px-4 pb-5 pt-4 sm:px-5">
          <div className="grid gap-5 lg:grid-cols-[1.35fr_1fr]">
            <div className="space-y-4">
              <section>
                <h4 className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">分析</h4>
                <ul className="mt-2 space-y-2">
                  {f.detail.map((d, i) => (
                    <li key={i} className="flex gap-2.5 text-[13px] leading-relaxed text-slate-300">
                      <span className="mt-[0.45rem] h-1 w-1 shrink-0 rounded-full bg-violet-400/70" />
                      <span>{d}</span>
                    </li>
                  ))}
                </ul>
              </section>

              {f.snippet && (
                <section>
                  <h4 className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                    {f.snippet.title}
                  </h4>
                  <pre className="mt-2 overflow-x-auto rounded-lg border border-white/10 bg-black/50 p-3 font-mono text-[11.5px] leading-relaxed text-slate-300">
                    {f.snippet.code.split("\n").map((line, i) => (
                      <div
                        key={i}
                        className={cn(
                          line.startsWith("+") && "text-emerald-300",
                          line.startsWith("-") && "text-rose-300",
                          line.includes("<--") && "text-amber-200",
                        )}
                      >
                        {line || " "}
                      </div>
                    ))}
                  </pre>
                </section>
              )}

              <section>
                <h4 className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">影响</h4>
                <p className="mt-2 rounded-lg border border-white/10 bg-white/[0.03] p-3 text-[13px] leading-relaxed text-slate-300">
                  {f.impact}
                </p>
              </section>
            </div>

            <div className="space-y-4">
              <section>
                <h4 className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">证据</h4>
                <ul className="mt-2 space-y-2">
                  {f.evidence.map((e, i) => (
                    <li key={i} className="rounded-lg border border-white/10 bg-black/30 p-2.5">
                      <div className="break-all font-mono text-[11px] text-sky-300/90">{e.file}</div>
                      <div className="mt-1 text-[12px] leading-relaxed text-slate-400">{e.note}</div>
                    </li>
                  ))}
                </ul>
              </section>

              <section>
                <h4 className="text-[11px] font-semibold uppercase tracking-wider text-emerald-400/80">建议修法</h4>
                <ol className="mt-2 space-y-2">
                  {f.fix.map((x, i) => (
                    <li
                      key={i}
                      className="flex gap-2.5 rounded-lg border border-emerald-400/15 bg-emerald-400/[0.05] p-2.5 text-[12.5px] leading-relaxed text-emerald-50/90"
                    >
                      <span className="font-mono text-[11px] text-emerald-400/70">{i + 1}.</span>
                      <span>{x}</span>
                    </li>
                  ))}
                </ol>
              </section>
            </div>
          </div>
        </div>
      )}
    </article>
  );
}

export default function Findings() {
  const [path, setPath] = useState<PathId | "all">("all");
  const [sev, setSev] = useState<Severity | "all">("all");
  const [q, setQ] = useState("");

  const counts = useMemo(() => {
    const byPath = {} as Record<PathId, number>;
    (Object.keys(PATHS) as PathId[]).forEach((p) => {
      byPath[p] = FINDINGS.filter((f) => f.paths.includes(p)).length;
    });
    return byPath;
  }, []);

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return FINDINGS.filter((f) => {
      if (path !== "all" && !f.paths.includes(path)) return false;
      if (sev !== "all" && f.severity !== sev) return false;
      if (!needle) return true;
      const hay = [f.id, f.title, f.summary, ...f.detail, ...f.fix, ...f.evidence.map((e) => e.file + e.note)]
        .join(" ")
        .toLowerCase();
      return hay.includes(needle);
    }).sort((a, b) => SEVERITY[a.severity].order - SEVERITY[b.severity].order);
  }, [path, sev, q]);

  return (
    <section id="findings" className="mx-auto max-w-7xl scroll-mt-20 px-5 py-16 sm:px-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-semibold tracking-tight text-white">审计发现</h2>
          <p className="mt-1.5 text-[13.5px] text-slate-400">
            按严重度排序。点击任意条目展开分析、证据位置与建议修法。
          </p>
        </div>
        <div className="relative">
          <svg viewBox="0 0 20 20" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 fill-slate-500">
            <path d="M8.5 3a5.5 5.5 0 1 0 3.4 9.8l3.6 3.7 1.4-1.4-3.7-3.6A5.5 5.5 0 0 0 8.5 3Zm0 2a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7Z" />
          </svg>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="搜索 mixin / codec / 42.0 / Locale …"
            className="w-full rounded-lg border border-white/10 bg-white/5 py-2 pl-9 pr-3 text-[13px] text-slate-200 outline-none transition placeholder:text-slate-500 focus:border-violet-400/40 focus:bg-violet-500/5 sm:w-80"
          />
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-1.5">
        <button
          onClick={() => setPath("all")}
          className={cn(
            "rounded-lg border px-3 py-1.5 text-[12px] font-medium transition",
            path === "all"
              ? "border-white/25 bg-white/10 text-white"
              : "border-white/10 bg-white/[0.02] text-slate-400 hover:text-slate-200",
          )}
        >
          全部路径 <span className="font-mono text-[11px] opacity-60">{FINDINGS.length}</span>
        </button>
        {(Object.keys(PATHS) as PathId[]).map((p) => (
          <button
            key={p}
            onClick={() => setPath(p === path ? "all" : p)}
            className={cn(
              "rounded-lg border px-3 py-1.5 text-[12px] font-medium transition",
              path === p ? "text-white" : "border-white/10 bg-white/[0.02] text-slate-400 hover:text-slate-200",
            )}
            style={
              path === p
                ? { borderColor: PATHS[p].accent + "66", backgroundColor: PATHS[p].accent + "1f", color: PATHS[p].accent }
                : undefined
            }
          >
            {PATHS[p].label} <span className="font-mono text-[11px] opacity-60">{counts[p]}</span>
          </button>
        ))}
      </div>

      <div className="mt-2.5 flex flex-wrap gap-1.5">
        {(["all", "blocker", "high", "medium", "low", "info"] as const).map((s) => (
          <button
            key={s}
            onClick={() => setSev(s === sev ? "all" : (s as Severity))}
            className={cn(
              "rounded-lg border px-3 py-1.5 text-[12px] font-medium transition",
              sev === s
                ? s === "all"
                  ? "border-white/25 bg-white/10 text-white"
                  : SEVERITY[s as Severity].chip
                : "border-white/10 bg-white/[0.02] text-slate-500 hover:text-slate-300",
            )}
          >
            {s === "all" ? "全部严重度" : SEVERITY[s as Severity].label}
            <span className="ml-1 font-mono text-[11px] opacity-60">
              {s === "all" ? FINDINGS.length : FINDINGS.filter((f) => f.severity === s).length}
            </span>
          </button>
        ))}
      </div>

      <div className="mt-6 space-y-3">
        {list.map((f, i) => (
          <Card key={f.id} f={f} index={i} />
        ))}
        {list.length === 0 && (
          <div className="rounded-xl border border-dashed border-white/15 py-16 text-center text-sm text-slate-500">
            没有匹配的条目。
          </div>
        )}
      </div>
    </section>
  );
}
