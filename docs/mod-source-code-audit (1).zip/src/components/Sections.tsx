import { FINDINGS, METHOD, PATHS, ROADMAP, SEVERITY, type PathId } from "../data/audit";
import { cn } from "../utils/cn";

export function PathGrid() {
  return (
    <section id="paths" className="mx-auto max-w-7xl scroll-mt-20 px-5 py-14 sm:px-8">
      <h2 className="text-2xl font-semibold tracking-tight text-white">八条审查路径</h2>
      <p className="mt-1.5 max-w-3xl text-[13.5px] leading-relaxed text-slate-400">
        每条路径都从“声明层说了什么”和“实现层做了什么”两侧对账。最有价值的发现几乎全部来自两者的差集 ——
        配置里有的常量被代码绕过、mixins.json 里没有的类被文档当成在役、entrypoint 指向了被 exclude 掉的类。
      </p>

      <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {(Object.keys(PATHS) as PathId[]).map((p) => {
          const items = FINDINGS.filter((f) => f.paths.includes(p));
          const worst = items.reduce(
            (acc, f) => Math.min(acc, SEVERITY[f.severity].order),
            9,
          );
          const worstKey = (Object.keys(SEVERITY) as (keyof typeof SEVERITY)[]).find(
            (k) => SEVERITY[k].order === worst,
          );
          return (
            <div
              key={p}
              className="group relative overflow-hidden rounded-xl border border-white/10 bg-[#0e0c1a]/70 p-4 transition hover:border-white/20"
            >
              <div
                className="absolute inset-x-0 top-0 h-px opacity-60"
                style={{ background: `linear-gradient(90deg, transparent, ${PATHS[p].accent}, transparent)` }}
              />
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-[15px] font-semibold text-white">{PATHS[p].label}</div>
                  <div className="font-mono text-[10.5px] uppercase tracking-wider" style={{ color: PATHS[p].accent }}>
                    {PATHS[p].en}
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-mono text-2xl font-semibold text-white">{items.length}</div>
                  {worstKey && worstKey !== "info" && (
                    <div className={cn("mt-0.5 rounded border px-1.5 py-0.5 text-[10px]", SEVERITY[worstKey].chip)}>
                      最高 {SEVERITY[worstKey].label}
                    </div>
                  )}
                </div>
              </div>
              <p className="mt-3 text-[12px] leading-relaxed text-slate-400">{PATHS[p].desc}</p>
              <div className="mt-3 flex flex-wrap gap-1">
                {items.slice(0, 5).map((f) => (
                  <span key={f.id} className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-[10px] text-slate-400">
                    {f.id}
                  </span>
                ))}
                {items.length > 5 && (
                  <span className="px-1 py-0.5 font-mono text-[10px] text-slate-600">+{items.length - 5}</span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}

export function Headline() {
  return (
    <section className="mx-auto max-w-7xl px-5 pt-14 sm:px-8">
      <div className="relative overflow-hidden rounded-2xl border border-rose-500/25 bg-gradient-to-br from-rose-950/40 via-[#120b16] to-[#0b0a14] p-6 sm:p-8">
        <div
          className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full opacity-30 blur-3xl"
          style={{ background: "radial-gradient(circle, #f43f5e, transparent 70%)" }}
        />
        <div className="relative">
          <div className="flex flex-wrap items-center gap-2 text-[11px] font-semibold">
            <span className="rounded-md border border-rose-500/40 bg-rose-500/15 px-2 py-1 text-rose-200">
              致命级 · MX-01
            </span>
            <span className="rounded-md border border-white/10 bg-white/5 px-2 py-1 text-slate-300">
              Mixin 注入 · 死代码 · 源码 API
            </span>
          </div>
          <h2 className="mt-4 text-xl font-semibold leading-snug text-white sm:text-2xl">
            mixin 包里有 12 个 <code className="font-mono text-rose-200">@Mixin</code> 类，mixins.json 只注册了 8 个
          </h2>
          <p className="mt-3 max-w-4xl text-[14px] leading-relaxed text-slate-300">
            缺席的四个是{" "}
            <code className="rounded bg-black/40 px-1.5 py-0.5 font-mono text-[12px] text-rose-200">
              structure.LevelChunkPostProcessMixin
            </code>
            、
            <code className="rounded bg-black/40 px-1.5 py-0.5 font-mono text-[12px] text-rose-200">
              structure.StructurePieceMarkMixin
            </code>
            、
            <code className="rounded bg-black/40 px-1.5 py-0.5 font-mono text-[12px] text-rose-200">
              structure.StructurePieceAccessor
            </code>{" "}
            和{" "}
            <code className="rounded bg-black/40 px-1.5 py-0.5 font-mono text-[12px] text-slate-300">
              chiseled_bookshelf.AddRandomTick
            </code>
            。build.gradle 的 main sourceSet 没有任何 exclude，所以它们会被正常编译、正常打包，只是永远不会被 Mixin
            加载。
          </p>
          <div className="mt-5 grid gap-3 sm:grid-cols-3">
            {[
              {
                t: "特性静默缺失",
                d: "要塞图书馆这类“程序化摆放”的结构不会把原版书架替换成纂刻书架 —— 而这是 TODO.md 里已经打勾的核心特性。",
              },
              {
                t: "写入端仍在跑",
                d: "BookshelfReplacerProcessor:206 仍然调用 markPosForPostProcessing，往一个没有消费者的队列里持续写标记。",
              },
              {
                t: "文档与 CI 都站在错误一边",
                d: "WORLDGEN_BOOKSHELF_DEADLOCK_REPORT 把这条链路当在役描述；ci_static_checks 的 Tier A 只做 json→java 单向校验，结构性地看不见。",
              },
            ].map((x) => (
              <div key={x.t} className="rounded-xl border border-white/10 bg-black/25 p-3.5">
                <div className="text-[13px] font-semibold text-rose-100">{x.t}</div>
                <div className="mt-1.5 text-[12.5px] leading-relaxed text-slate-400">{x.d}</div>
              </div>
            ))}
          </div>
          <a
            href="#findings"
            className="mt-5 inline-flex items-center gap-1.5 text-[13px] font-medium text-rose-200 transition hover:text-rose-100"
          >
            查看完整条目与修法 <span>→</span>
          </a>
        </div>
      </div>
    </section>
  );
}

export function Method() {
  return (
    <section id="method" className="mx-auto max-w-7xl scroll-mt-20 px-5 py-14 sm:px-8">
      <h2 className="text-2xl font-semibold tracking-tight text-white">审计方法</h2>
      <div className="mt-6 grid gap-3 lg:grid-cols-5">
        {METHOD.map((m) => (
          <div key={m.step} className="rounded-xl border border-white/10 bg-[#0e0c1a]/70 p-4">
            <div className="font-mono text-[11px] font-semibold text-violet-300/80">{m.step}</div>
            <div className="mt-1.5 text-[14px] font-semibold text-white">{m.title}</div>
            <p className="mt-2 text-[12.5px] leading-relaxed text-slate-400">{m.body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

const TONES: Record<string, string> = {
  rose: "border-rose-500/30 bg-rose-500/[0.07] text-rose-200",
  orange: "border-orange-500/30 bg-orange-500/[0.07] text-orange-200",
  amber: "border-amber-400/30 bg-amber-400/[0.07] text-amber-200",
  sky: "border-sky-400/30 bg-sky-400/[0.07] text-sky-200",
};

export function Roadmap() {
  return (
    <section id="roadmap" className="mx-auto max-w-7xl scroll-mt-20 px-5 py-14 sm:px-8">
      <h2 className="text-2xl font-semibold tracking-tight text-white">修复优先级</h2>
      <p className="mt-1.5 max-w-3xl text-[13.5px] leading-relaxed text-slate-400">
        排序原则：先让已经写完的代码真正生效，再堵住会造成数据损坏和单边信任的口子，最后才是把隐性硬编码收进配置、以及结构层面的打磨。
      </p>
      <div className="mt-7 grid gap-3 lg:grid-cols-4">
        {ROADMAP.map((r) => (
          <div key={r.tier} className="flex flex-col rounded-xl border border-white/10 bg-[#0e0c1a]/70 p-4">
            <div className="flex items-center gap-2">
              <span className={cn("rounded-md border px-2 py-0.5 font-mono text-[11px] font-bold", TONES[r.tone])}>
                {r.tier}
              </span>
              <span className="text-[13.5px] font-semibold text-white">{r.title}</span>
            </div>
            <ul className="mt-3 space-y-2">
              {r.items.map((it, i) => (
                <li key={i} className="flex gap-2 text-[12.5px] leading-relaxed text-slate-300">
                  <span className="mt-[0.42rem] h-1 w-1 shrink-0 rounded-full bg-slate-500" />
                  <span>{it}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
}

export function HardcodeTable() {
  const rows = [
    { v: "42.0 / 22.0", where: "InscriptionRitualMechanics:629-630", why: "仪式时长归一化分母", cfg: "否", risk: "high" },
    { v: "0.42 / 0.58 / 0.35 / 0.65 / 1.15 / 0.62", where: "InscriptionRitualMechanics:631-635", why: "仪式强度与饱和曲线系数", cfg: "否", risk: "high" },
    { v: "240.0", where: "InscriptionRitualMechanics:653", why: "XP 献祭衰减时间常数", cfg: "否", risk: "mid" },
    { v: "clamp(ticks, 100, …)", where: "InscriptionRitualMechanics:637", why: "仪式最短 5 秒", cfg: "否", risk: "mid" },
    { v: "35 = 15 + 20", where: "LibraryResonance:31-36", why: "base 折扣上限 = 两子项之和（冗余层）", cfg: "部分", risk: "mid" },
    { v: "38 / 42", where: "BookshelfProgression:45 + MasterTomeWear:71,74", why: "满档阈值与回充阈值分别硬编码，42 > 38", cfg: "部分", risk: "mid" },
    { v: "32_000 / 256", where: "BlockEntity:199 + InscriptionRitualMechanics:496,500", why: "仪式队列长度/步数上限，同值写两遍", cfg: "否", risk: "mid" },
    { v: "64.0D", where: "ScreenHandler:110（reopen_table）", why: "交互距离平方，与 stillValid 重复", cfg: "否", risk: "low" },
    { v: "255 / 512", where: "EnchantmentApplication:~82", why: "附魔等级上限与 id 长度上限，裸字面量且事后校验", cfg: "否", risk: "mid" },
    { v: "1600L / 2600L / 5000L", where: "GrimoireDiagramRenderer:1177, ConfigScreen:224,228,246", why: "墙钟动画周期与 toast 超时", cfg: "否", risk: "low" },
    { v: "\"minecraft:chiseled_bookshelf\"", where: "BookshelfBookFiller:134", why: "方块实体 id 字符串字面量", cfg: "否", risk: "low" },
    { v: "assets/chiseled-enchanting-table/", where: "fabric.mod.json icon", why: "与资源命名空间 chiseled_enchanting_table 不一致", cfg: "—", risk: "mid" },
  ];
  const riskCls: Record<string, string> = {
    high: "bg-orange-500/15 text-orange-300",
    mid: "bg-amber-400/15 text-amber-200",
    low: "bg-sky-400/15 text-sky-200",
  };
  return (
    <section id="hardcode" className="mx-auto max-w-7xl scroll-mt-20 px-5 py-14 sm:px-8">
      <h2 className="text-2xl font-semibold tracking-tight text-white">硬编码清单</h2>
      <p className="mt-1.5 max-w-3xl text-[13.5px] leading-relaxed text-slate-400">
        这个仓库有一套相当完整的配置系统 —— <code className="font-mono text-[12px] text-violet-200">ConfigCatalog</code> 用
        声明式 schema 管理了 6 大类数十个选项，还带父子联动、会话权限分级和生效时机标记。问题不在“没有配置系统”，
        而在<span className="text-amber-200">部分关键曲线绕过了它</span>，并且与配置项之间存在复制而非引用的隐式耦合。
      </p>
      <div className="mt-6 overflow-x-auto rounded-xl border border-white/10">
        <table className="w-full min-w-[820px] border-collapse text-left">
          <thead>
            <tr className="bg-white/[0.04] text-[11px] uppercase tracking-wider text-slate-400">
              <th className="px-4 py-3 font-semibold">常量</th>
              <th className="px-4 py-3 font-semibold">位置</th>
              <th className="px-4 py-3 font-semibold">用途</th>
              <th className="px-4 py-3 font-semibold">可配置</th>
              <th className="px-4 py-3 font-semibold">风险</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {rows.map((r) => (
              <tr key={r.where + r.v} className="bg-[#0e0c1a]/60 text-[12.5px] transition hover:bg-white/[0.03]">
                <td className="px-4 py-3 font-mono text-[11.5px] text-violet-200">{r.v}</td>
                <td className="px-4 py-3 font-mono text-[11px] text-sky-300/80">{r.where}</td>
                <td className="px-4 py-3 text-slate-300">{r.why}</td>
                <td className="px-4 py-3">
                  <span
                    className={cn(
                      "rounded px-1.5 py-0.5 text-[11px]",
                      r.cfg === "否" ? "bg-rose-500/15 text-rose-300" : "bg-slate-400/15 text-slate-300",
                    )}
                  >
                    {r.cfg}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className={cn("rounded px-1.5 py-0.5 text-[11px] font-medium", riskCls[r.risk])}>
                    {r.risk === "high" ? "高" : r.risk === "mid" ? "中" : "低"}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
