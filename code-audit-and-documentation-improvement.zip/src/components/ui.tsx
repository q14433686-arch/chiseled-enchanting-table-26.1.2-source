import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { SEV_META, type Severity } from "../data/findings";

/* ------------------------------------------------------------------ reveal */

export function Reveal({
  children,
  className,
  delay = 0,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  as?: "div" | "section" | "li" | "article" | "header";
}) {
  const ref = useRef<HTMLElement | null>(null);
  const [seen, setSeen] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setSeen(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            setSeen(true);
            io.unobserve(e.target);
          }
        }
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.06 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <Tag
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      ref={ref as any}
      className={cn("reveal", seen && "is-in", className)}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}

/* ---------------------------------------------------------------- severity */

export function SevPill({
  sev,
  className,
  showDot = true,
}: {
  sev: Severity;
  className?: string;
  showDot?: boolean;
}) {
  const m = SEV_META[sev];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-[3px] font-mono text-[10.5px] tracking-[0.14em] uppercase",
        className,
      )}
      style={{
        color: m.color,
        borderColor: `${m.color}55`,
        background: `${m.color}12`,
      }}
    >
      {showDot && (
        <span
          className="inline-block h-1.5 w-1.5 rounded-full"
          style={{ background: m.color, boxShadow: `0 0 7px ${m.color}` }}
        />
      )}
      {m.zh}
    </span>
  );
}

export function SevBar({ sev }: { sev: Severity }) {
  const m = SEV_META[sev];
  const width = [100, 84, 64, 44, 30, 30][m.rank];
  return (
    <span className="relative block h-[3px] w-16 overflow-hidden rounded-full bg-white/8">
      <span
        className="fill-x absolute inset-y-0 left-0 rounded-full"
        style={{ width: `${width}%`, background: m.color, boxShadow: `0 0 8px ${m.color}` }}
      />
    </span>
  );
}

/* -------------------------------------------------------------------- code */

export function Code({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <code
      className={cn(
        "rounded-[4px] border border-lapis-400/20 bg-lapis-500/10 px-[5px] py-[1px] font-mono text-[0.855em] text-lapis-300",
        className,
      )}
    >
      {children}
    </code>
  );
}

export function CodeBlock({
  children,
  label,
  className,
}: {
  children: ReactNode;
  label?: string;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "group relative overflow-hidden rounded-md border border-lapis-400/15 bg-obsidian-950/80",
        className,
      )}
    >
      {label && (
        <div className="flex items-center justify-between border-b border-lapis-400/12 bg-obsidian-850/70 px-3 py-1.5">
          <span className="font-mono text-[10px] tracking-[0.18em] text-parchment-faint uppercase">
            {label}
          </span>
          <span className="flex gap-1">
            <i className="h-1.5 w-1.5 rounded-full bg-amethyst-400/50" />
            <i className="h-1.5 w-1.5 rounded-full bg-lapis-400/50" />
            <i className="h-1.5 w-1.5 rounded-full bg-emerald-glow/50" />
          </span>
        </div>
      )}
      <pre className="overflow-x-auto px-3.5 py-3 font-mono text-[11.5px] leading-[1.75] text-lapis-300/90">
        {children}
      </pre>
    </div>
  );
}

/* ------------------------------------------------------------ section head */

export function SectionHead({
  idx,
  zh,
  en,
  accent = "#6fa0f0",
  blurb,
  right,
}: {
  idx: string;
  zh: string;
  en: string;
  accent?: string;
  blurb?: string;
  right?: ReactNode;
}) {
  return (
    <Reveal className="mb-7">
      <div className="flex flex-wrap items-end justify-between gap-x-8 gap-y-4 border-b pb-4"
        style={{ borderColor: `${accent}2e` }}
      >
        <div className="min-w-0">
          <div className="mb-2 flex items-center gap-3">
            <span
              className="font-mono text-[11px] tracking-[0.3em]"
              style={{ color: accent }}
            >
              {idx}
            </span>
            <span className="h-px w-8" style={{ background: `${accent}66` }} />
            <span className="font-mono text-[10.5px] tracking-[0.22em] text-parchment-faint uppercase">
              {en}
            </span>
          </div>
          <h2 className="font-cjk-display engraved text-[clamp(1.5rem,3.4vw,2.35rem)] leading-[1.2] font-bold text-parchment">
            {zh}
          </h2>
          {blurb && (
            <p className="mt-2.5 max-w-3xl text-[13.5px] leading-relaxed text-parchment-dim">
              {blurb}
            </p>
          )}
        </div>
        {right && <div className="shrink-0">{right}</div>}
      </div>
    </Reveal>
  );
}

/* ------------------------------------------------------------------- stats */

export function Stat({
  value,
  label,
  accent = "#6fa0f0",
  sub,
}: {
  value: ReactNode;
  label: string;
  accent?: string;
  sub?: string;
}) {
  return (
    <div className="plate plate-hover group relative overflow-hidden rounded-lg px-4 py-3.5">
      <div
        className="absolute inset-x-0 top-0 h-px opacity-70 transition-opacity group-hover:opacity-100"
        style={{ background: `linear-gradient(90deg, transparent, ${accent}, transparent)` }}
      />
      <div
        className="tnum font-display text-[clamp(1.35rem,2.6vw,1.9rem)] leading-none font-bold"
        style={{ color: accent }}
      >
        {value}
      </div>
      <div className="mt-2 text-[11.5px] leading-snug text-parchment-dim">{label}</div>
      {sub && (
        <div className="mt-1 font-mono text-[10px] tracking-wide text-parchment-faint">{sub}</div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------- meter */

export function Meter({
  value,
  max = 100,
  color,
  height = 6,
  label,
  right,
}: {
  value: number;
  max?: number;
  color: string;
  height?: number;
  label?: ReactNode;
  right?: ReactNode;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === "undefined") return setSeen(true);
    const io = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && (setSeen(true), io.unobserve(e.target))),
      { threshold: 0.3 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div ref={ref}>
      {(label || right) && (
        <div className="mb-1.5 flex items-baseline justify-between gap-3 text-[11.5px]">
          <span className="text-parchment-dim">{label}</span>
          <span className="tnum font-mono text-[11px]" style={{ color }}>
            {right}
          </span>
        </div>
      )}
      <div
        className="relative w-full overflow-hidden rounded-full bg-white/7"
        style={{ height }}
      >
        <div
          className="absolute inset-y-0 left-0 rounded-full"
          style={{
            width: `${pct}%`,
            background: `linear-gradient(90deg, ${color}66, ${color})`,
            boxShadow: `0 0 12px -2px ${color}`,
            transform: seen ? "none" : "scaleX(0)",
            transformOrigin: "left",
            transition: "transform 1.2s cubic-bezier(.16,1,.3,1)",
          }}
        />
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------- misc */

export function Tag({
  children,
  color = "#9dc0ff",
  className,
}: {
  children: ReactNode;
  color?: string;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded border px-1.5 py-[1px] font-mono text-[10px] tracking-[0.08em]",
        className,
      )}
      style={{ color, borderColor: `${color}3d`, background: `${color}0f` }}
    >
      {children}
    </span>
  );
}

export function Rule({ color = "#6fa0f0", className }: { color?: string; className?: string }) {
  return (
    <div
      className={cn("h-px w-full", className)}
      style={{ background: `linear-gradient(90deg, ${color}00, ${color}55, ${color}00)` }}
    />
  );
}
