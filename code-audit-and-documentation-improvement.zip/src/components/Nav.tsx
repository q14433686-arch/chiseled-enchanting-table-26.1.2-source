import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { REPO_META } from "../data/findings";

export type Route = "overview" | "audit" | "text" | "doubt";

export const ROUTES: { key: Route; zh: string; en: string; hash: string }[] = [
  { key: "overview", zh: "总览", en: "Dossier", hash: "#/" },
  { key: "audit", zh: "七路径审计", en: "Audit", hash: "#/audit" },
  { key: "text", zh: "文本三重审查", en: "Wording", hash: "#/text" },
  { key: "doubt", zh: "怀疑与建议", en: "Doubts", hash: "#/doubt" },
];

export function routeFromHash(): Route {
  const h = window.location.hash.replace(/^#\/?/, "");
  const found = ROUTES.find((r) => r.hash.replace(/^#\/?/, "") === h);
  return found ? found.key : "overview";
}

export function useRoute(): [Route, (r: Route) => void] {
  const [route, setRoute] = useState<Route>(() =>
    typeof window === "undefined" ? "overview" : routeFromHash(),
  );
  useEffect(() => {
    const on = () => setRoute(routeFromHash());
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  const go = (r: Route) => {
    const target = ROUTES.find((x) => x.key === r)!;
    if (window.location.hash !== target.hash) window.location.hash = target.hash;
    else setRoute(r);
  };
  return [route, go];
}

export default function Nav({
  route,
  go,
}: {
  route: Route;
  go: (r: Route) => void;
}) {
  const [solid, setSolid] = useState(false);
  useEffect(() => {
    const on = () => setSolid(window.scrollY > 40);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-500",
        solid
          ? "border-b border-lapis-400/18 bg-obsidian-950/88 backdrop-blur-xl"
          : "border-b border-transparent",
      )}
    >
      <div className="mx-auto flex max-w-[1400px] items-center gap-4 px-4 py-2.5 sm:px-7">
        {/* sigil */}
        <a
          href="#/"
          onClick={(e) => {
            e.preventDefault();
            go("overview");
          }}
          className="group relative flex shrink-0 items-center gap-2.5"
        >
          <span className="relative grid h-8 w-8 place-items-center">
            <span
              className="anim-slow-spin absolute inset-0 rounded-[7px] border border-dashed border-amethyst-400/45"
              aria-hidden
            />
            <span className="font-display text-[15px] leading-none font-bold text-lapis-300 transition-colors group-hover:text-amethyst-300">
              ᛝ
            </span>
          </span>
          <span className="hidden leading-tight sm:block">
            <span className="block font-display text-[12.5px] font-bold tracking-[0.16em] text-parchment uppercase">
              Chiseled Audit
            </span>
            <span className="block font-mono text-[9.5px] tracking-[0.1em] text-parchment-faint">
              {REPO_META.mcVersion} · rev{REPO_META.protocolRevision.split("_").pop()}
            </span>
          </span>
        </a>

        <nav className="ml-auto flex items-center gap-0.5 overflow-x-auto">
          {ROUTES.map((r) => {
            const active = route === r.key;
            return (
              <a
                key={r.key}
                href={r.hash}
                onClick={(e) => {
                  e.preventDefault();
                  go(r.key);
                }}
                className={cn(
                  "group relative shrink-0 rounded-md px-2.5 py-1.5 text-[12.5px] transition-colors duration-300 sm:px-3.5",
                  active ? "text-parchment" : "text-parchment-faint hover:text-lapis-300",
                )}
              >
                <span className="font-cjk-display font-medium">{r.zh}</span>
                <span
                  className={cn(
                    "absolute inset-x-2.5 bottom-0.5 h-px origin-left transition-transform duration-400",
                    active ? "scale-x-100" : "scale-x-0 group-hover:scale-x-100",
                  )}
                  style={{
                    background: active
                      ? "linear-gradient(90deg,#a46ee5,#6fa0f0)"
                      : "linear-gradient(90deg,#6fa0f0,#43c59e)",
                  }}
                />
              </a>
            );
          })}
        </nav>

        <a
          href="https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/tree/arena%2Fb99a37c2-chiseled-enchanting-table-26-1"
          target="_blank"
          rel="noreferrer noopener"
          className="link-underline hidden shrink-0 font-mono text-[10.5px] tracking-[0.08em] text-parchment-faint hover:text-emerald-glow lg:block"
        >
          {REPO_META.owner}/{REPO_META.name} ↗
        </a>
      </div>
    </header>
  );
}
