import { useEffect, useMemo, useState } from "react";

const RUNES = ["ᛝ", "ᚦ", "ᛟ", "ᚱ", "ᛉ", "ᚹ", "ᛊ", "ᛚ", "ᚻ", "ᛞ", "◇", "◆", "▲", "●"];

interface Rune {
  id: number;
  left: number;
  top: number;
  char: string;
  size: number;
  dur: number;
  delay: number;
  dx: number;
  op: number;
  color: string;
}

const COLORS = ["#6fa0f0", "#a46ee5", "#43c59e", "#d99b38", "#3e9ab0"];

function makeRunes(n: number): Rune[] {
  return Array.from({ length: n }, (_, i) => ({
    id: i,
    left: Math.random() * 100,
    top: 12 + Math.random() * 88,
    char: RUNES[Math.floor(Math.random() * RUNES.length)],
    size: 9 + Math.random() * 15,
    dur: 15 + Math.random() * 20,
    delay: -Math.random() * 30,
    dx: (Math.random() - 0.5) * 90,
    op: 0.14 + Math.random() * 0.3,
    color: COLORS[Math.floor(Math.random() * COLORS.length)],
  }));
}

export default function Ambient() {
  const runes = useMemo(() => makeRunes(26), []);
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => setScrollY(window.scrollY));
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      {/* base wash */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(120% 78% at 78% -8%, rgba(61,111,209,0.22), transparent 58%)," +
            "radial-gradient(90% 60% at 8% 4%, rgba(164,110,229,0.17), transparent 60%)," +
            "radial-gradient(120% 80% at 50% 108%, rgba(67,197,158,0.1), transparent 62%)," +
            "linear-gradient(180deg, #0b0813 0%, #100c1c 40%, #0b0813 100%)",
        }}
      />

      {/* parallax rune grid */}
      <div
        className="rune-grid absolute inset-0 opacity-70"
        style={{ transform: `translate3d(0, ${scrollY * -0.045}px, 0)` }}
      />

      {/* chiseled-shelf 3x2 motif, upper right */}
      <div
        className="shelf-motif absolute -top-24 -right-32 h-[420px] w-[560px] rotate-[14deg] opacity-45"
        style={{ transform: `rotate(14deg) translate3d(0, ${scrollY * 0.03}px, 0)` }}
      />
      <div
        className="shelf-motif absolute -bottom-40 -left-28 h-[380px] w-[460px] opacity-30"
        style={{ transform: `rotate(-8deg) translate3d(0, ${scrollY * -0.02}px, 0)` }}
      />

      {/* slow enchantment-glint sheen */}
      <div className="glint-sweep absolute inset-0 opacity-80" />

      {/* drifting runes */}
      {runes.map((r) => (
        <span
          key={r.id}
          className="absolute select-none font-display"
          style={
            {
              left: `${r.left}%`,
              top: `${r.top}%`,
              fontSize: r.size,
              color: r.color,
              textShadow: `0 0 12px ${r.color}88`,
              animation: `float-rune ${r.dur}s linear ${r.delay}s infinite`,
              "--rune-dx": `${r.dx}px`,
              "--rune-op": r.op,
            } as React.CSSProperties
          }
        >
          {r.char}
        </span>
      ))}

      {/* vignette + grain */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(105% 78% at 50% 42%, transparent 42%, rgba(6,4,12,0.72) 100%)",
        }}
      />
      <div className="noise-veil absolute inset-0 opacity-[0.045] mix-blend-overlay" />
    </div>
  );
}
