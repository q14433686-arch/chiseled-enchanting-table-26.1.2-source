export interface Doubt {
  id: string;
  title: string;
  stance: "strong" | "moderate" | "mild";
  claim: string;
  why: string;
  counterEvidence: string;
  testIt: string;
}

export interface Suggestion {
  id: string;
  priority: "P0" | "P1" | "P2" | "P3";
  title: string;
  what: string;
  cost: string;
  refs: string[];
}

export const DOUBTS: Doubt[] = [
  {
    id: "D-01",
    stance: "strong",
    title: "这个 mod 有没有真的在客户端里被打开过一次？",
    claim:
      "仓库在 README、gradle.properties 与三份 report 里反复说明：开发沙箱既没有 JDK 也连不上 maven.fabricmc.net，所以**所有编译都发生在 GitHub Actions**，日志再回推到分支。CI 的 build.yml 门是「static gates → full build + jar artifact → no-viewers」，compile-check.yml 门是「compileJava + compileClientJava」。",
    why:
      "一份 44,031 行 Java、13 个 mixin、50 位置参数 record、5 个 2000+ 行 GUI/菜单类的 mod，其正确性的大头不在编译期。本次审计里最严重的两条（MIXIN-01 的 removeItemNoUpdate 语义、GUI-06 的 🔒 缺字方块）**编译都能过、静态门都能过**，只有在真实客户端里点开一次配置界面、在一个装着 64 本附魔书的雕纹书架上跑一次结构模板保存才会暴露。GUI-01/02（手写搜索框无粘贴、退格切断代理对）同理——它们只有真人打字才能发现。",
    counterEvidence:
      "build-reports/ 里确实有 server-smoke.log，scripts/ 里有 server_smoke.py 与 test_sync_26_1_2.py，说明作者在「无法本地编译」的约束下仍然尽力搭了运行时验证。6 个测试类共 3,494 行，其中 EconomyAndConfigVerificationTest 1,878 行、ConfigurationSafetyTest 472 行、NetworkCompatibilityTest 241 行、AuditMechanicsTest 316 行、RuleArchitectureTest、FullPortRuntimeTest——这个测试体量在同类社区移植里属于上游。但 server smoke 覆盖的是**专用服务器**路径，客户端 GUI/渲染代码不在其中。",
    testIt:
      "在 CI 里加一个 headless 客户端 job：用 Fabric 的 runClient + 一个自动化脚本（或 Gametest/`--quickPlay`）进入世界、打开雕纹附魔台、打开配置界面、在搜索框输入一个含星平面字符的字符串、截图。哪怕只跑一次并把截图提交到 build-reports/，GUI-01/02/06 会立刻自己暴露。",
  },
  {
    id: "D-02",
    stance: "strong",
    title: "测试挂载方式让「测试失败」与「编译失败」耦合得过松",
    claim:
      "build.gradle 用 `tasks.named('compileClientJava') { finalizedBy(tasks.named('test')) }` 把测试挂在客户端编译之后，而不是 `dependsOn` 或让 build 直接依赖 test。",
    why:
      "finalizedBy 的语义是「无论被终结的任务成功与否都执行终结任务」，且终结任务的失败不会归因到被终结的任务上。结果是：日志里 compileClientJava 显示 SUCCESS，test 的失败出现在后面，读日志的人（尤其是只回推 compile-java.log 的那条流程）很容易把「编译绿了」当成「这版能要」。而 compile-check.yml 回推的正是 compile-java.log。另外测试全部位于 src/test（挂在 main 源集），**无法覆盖 src/client**——而本次审计中 GUI 路径的缺陷密度最高（GUI-01/02/03/04/05/06/07 七条）。",
    counterEvidence:
      "整体 build 仍然会因为 test 失败而失败（Gradle 的 finalizer 失败会 fail 整个 invocation），build.yml 也确实会红。所以这不是「测试不跑」，而是「测试结果在日志里的可见性与归因偏弱」，以及「测试覆盖面在源集上就够不到客户端」。",
    testIt:
      "把 test 提升为 build 的显式依赖（`tasks.named('build') { dependsOn('test') }`），并让 compile-check.yml 同时回推 test 的 XML/HTML 报告摘要；为 src/client 增加一个 clientTest 源集（哪怕只测 GrimoireTextLayout 的换行与 ChiseledEnchantingConfigScreen 的搜索字符串处理这类纯逻辑），GUI-02 的代理对问题就能变成一条红灯断言。",
  },
  {
    id: "D-03",
    stance: "strong",
    title: "「数据驱动」在文档里是全称判断，在代码里是局部判断",
    claim:
      "README 与 shelf_gates.json / library_resonance.json 的 _comment 都以「Every key below is read directly by …」的口吻描述数据驱动；BundledDefaults 的类注释写明「the Java DEFAULT records used to retype the same numbers and could drift silently」——这条纪律是真的，而且由 ci_static_checks.py 逐字节校验。",
    why:
      "但同一纪律没有覆盖到：EXACT_CHEST_SPECS（24 张原版箱子表 + 概率 + 数量，CODEC-06）、HIGH_APPLICABILITY_IDS（10 个魔咒 ID，COUP-01）、CLASSIC_103_DEFAULT_TREASURES、rarityMultiplier 的 4 个常数与守恒安全边际 5（BAL-01）、computeApplicabilityFactor 的 8 个常数与参考值 24（BAL-02/03）、TomeParticleEffects 的槽位几何 4 个常数（COUP-07）、附魔书堆叠上限 64（API-05）。这些不是边角料：它们决定了掉落率、等待时长、返还经济与特效位置。",
    counterEvidence:
      "反过来说，被纪律覆盖的部分质量非常高：JSON 是分组良好的、_schema_version 存在、生成器 + CI 逐字节校验的组合确实消灭了「Java DEFAULT 与 JSON 漂移」这一整类缺陷，而这类缺陷在同类 mod 里极其常见。WIKI 的数值公式可复算且全部复算通过。所以问题不是「纪律没用」，而是「纪律的边界没有写在任何地方，读者无法判断某个数值到底可不可配」。",
    testIt:
      "加一条 CI 门（纯静态、零成本）：扫描 src/main 与 src/client 里所有 `Map.entry(\"chests/`、`Identifier.withDefaultNamespace(\"`、以及出现在 return 表达式中的浮点字面量，输出一份「硬编码清单」到 build-reports/hardcode-inventory.log，并允许一份显式的 allowlist 文件。清单一旦可见，边界争议就变成逐条决策而不是整体印象。",
  },
  {
    id: "D-04",
    stance: "moderate",
    title: "16 个协议 revision 说明的不是严谨，而是线格式在设计定型前就被反复冻结",
    claim:
      "EnchantingProtocol.REVISION = \"26_1_2_revision_16\"，配套 12 个具名 legacy 常量、2 个 probe 列表、一套「probe 退休政策」注释，以及一个「Bump its ID whenever any menu/cost payload wire layout changes」的规则。",
    why:
      "版本化协议通道本身是**正确且少见**的好做法（大多数 mod 直接改线格式然后让用户看解码崩溃）。但一条尚未发布到 Modrinth/CurseForge 的社区移植分支，在一条 arena 快照分支上产生 16 次 revision，意味着平均每次改动菜单/价格 payload 就冻结一次线格式。CHANGELOG.md 有 514 行，却没有为每个 revision 写「改了什么」的对照——所以这 16 个 revision 对未来的维护者是不可解读的，它们只保证了「不会解码崩溃」，没有保证「能理解为什么」。",
    counterEvidence:
      "注释里的 probe 退休政策考虑得很细：「a probe constant stays while any publicly shipped build registered that channel, because it is the only signal that lets the JOIN handshake disconnect an outdated peer gracefully instead of failing later with a raw decode error」——这是真正理解了握手时序的人写的。而且明确禁止在 legacy channel 上注册解码器，理由（老服务器可能在客户端 JOIN 回调能断开它之前就发包）也是对的。",
    testIt:
      "把 revision 改成生成式（一个 int + 一个 id(base, rev) 函数），并在 docs/ 下加一份 PROTOCOL_HISTORY.md，每个 revision 一行「改了什么 / 为什么 / 是否可以退休」。然后加一条 CI 断言：任何已发布 git tag 里注册过的 channel id 必须仍在 probe 列表中——把「退休政策」从注释变成门。",
  },
  {
    id: "D-05",
    stance: "moderate",
    title: "一次「审计驱动的修复」引入了比原问题更隐蔽的新缺陷，说明审计闭环缺一步",
    claim:
      "LockedBookContainerMixin 的 removeItemNoUpdate 覆写带着注释「Audit MIXIN-02: … Overriding Container#removeItemNoUpdate(int) directly on the target class closes the removeItemNoUpdate extraction path fail-closed」。动机（堵住锁定母本的提取旁路）完全正确。",
    why:
      "但修复把原版「取走整格」的语义改成了「取走 1 个」，并顺手引入了 setChanged() 与 blockstate 更新——与方法名的 NoUpdate 承诺相反。在一个把附魔书堆叠上限提到 64 的 mod 里，这个偏差的后果是「自动化/结构保存只搬走 1 本，留下 63 本」。仓库里有大量「Audit XXX-nn」标记（NET-02/03、MX-04/05、M-07、H-06、API-03、GUI-01、MIXIN-02、DEAD-03、R-01），说明审计→修复的流程是真实存在且高频运转的；缺的是「修复之后由谁验证修复本身」这一步。",
    counterEvidence:
      "同一次审计里的其它修复质量明显更高：MX-04/M-07 把 HEAD/RETURN 注入对改成 @WrapMethod + try/finally（消除异常导致堆叠永久缩成 1）；MX-05 把砂轮槽位的 container/index 从硬编码 2 改成从 delegate 派生；H-06 把等级校验提到定价与副作用之前；R-01 给 payload 加了字节预算。这些都是**方向正确且实现正确**的修复。所以问题不在审计能力，在于 mixin 类修复天然无法被单元测试覆盖（需要游戏运行时），而 D-01/D-02 说明运行时验证恰好是最薄弱的一环——两个弱点叠加。",
    testIt:
      "给每一条「Audit XXX」标记的修复配一条可执行的验证：能进测试的进测试（如 removeItemNoUpdate 的堆叠语义可以用一个 Container 的假实现测）；不能进测试的写进一份 docs/reports/MANUAL_QA.md 的手工清单（步骤 + 期望结果），并在 release 前跑一遍。清单不需要自动化，只需要存在。",
  },
  {
    id: "D-06",
    stance: "moderate",
    title: "depends.minecraft 是精确等号，对社区移植来说过紧",
    claim: "fabric.mod.json：\"minecraft\": \"26.1.2\"（不是 \">=26.1.2\"、不是 \"~26.1\"、不是 \"1.26.x\"）。",
    why:
      "精确等号意味着任何 26.1.x 补丁版本都会让 Fabric Loader 直接拒绝加载。对一个明确说明「不发布到 Modrinth/CurseForge、bug 报到本仓库、由 CI 代编译」的社区移植来说，这条约束的收益（避免在不兼容的补丁版本上跑）小于成本（补丁版本一出，所有用户都要等一次 CI + 一次 version bump + 一次 consistency gate 通过）。而且仓库已经有一套 26.3 分支同步机制，说明跨小版本适配的能力是存在的。",
    counterEvidence:
      "反方向的理由也成立：26.x 线的 mixin 目标（calculateIncreasedRepairCost、getEnchantmentList、createResult、ChiseledBookShelfBlockEntity 的接口默认方法继承结构）都是版本敏感的，NET-04 与 MIXIN-01 都建立在具体的方法名/继承形态上。宽松的版本范围可能把「启动崩溃」变成「运行期诡异行为」，后者更难报障。",
    testIt:
      "折中方案：保持精确等号，但在 CI 里加一个每周定时的 job，对最新的 26.1.x 补丁版本跑一次 compile-check + server smoke，结果只作为 issue 评论/状态徽章，不影响发布。这样「补丁版本是否兼容」从猜测变成一个持续可见的事实，version bump 的决策就有了依据。",
  },
  {
    id: "D-07",
    stance: "mild",
    title: "三个巨型类是拆过一次之后的结果，这本身值得警惕",
    claim:
      "EnchantingNetworking 的类注释写明它是「Extracted verbatim from ChiseledEnchantingTableScreenHandler#init() (god-class split, 2026-10-24 audit)」。拆分之后 ScreenHandler 仍有 3,088 行。",
    why:
      "「拆过一次仍然 3,000 行」通常意味着被拆走的是**最容易拆**的那部分（网络注册是纯 wiring，无状态、无返回值耦合），而留下来的是耦合最紧的部分（容器状态 × 定价 × 仪式队列 × 顿悟 × 净化页解锁 × 准入队列）。COUP-03 那段「一个配置项隐式驱动四个旋钮」的重算逻辑住在 ChiseledEnchantingTableData 而不是 LibraryResonance，就是这种边界的直接产物。",
    counterEvidence:
      "拆分方向是对的，而且注释诚实地记录了拆分的时间与动机（「Receivers only call public handler methods, so behavior is unchanged」——这是一条可验证的声明，也是拆分的安全条件）。docs/reports/PORTING_26_1_2_P15_DECOUPLING_REPORT.md 说明解耦是被当作一个独立阶段来做的。",
    testIt:
      "下一次拆分选「有明确输入输出」的那部分而不是「最容易」的那部分：MenuPricing（输入：菜单状态 + 配置 + 书架扫描结果；输出：AvailableOption 列表）是最清晰的候选，它同时也是 JEI/REI 与 GUI 三处重复渲染成本的地方——拆出来之后三方可以共用同一个定价解析器，顺带解决 COUP-03 的住址问题。",
  },
  {
    id: "D-08",
    stance: "mild",
    title: "文档的自我批评能力很强，但批评的落点集中在流程而不是产物",
    claim:
      "21 份 docs/reports/、CURRENT_BASELINE.md、NEXT_TASK.md、TODO.md、docs/ci/README.md（记录两次失败 run 及各自的教训）、ci_static_checks.py 的 Tier D 主动把悬空文档链接报为 warn 并写明「docs/COMPATIBILITY.md and the P19 cross-mod report are referenced from two documents but are not in the tree on any branch」。",
    why:
      "这是一种很健康的技术文化：失败被记录、漂移被主动暴露、纪律被写成脚本。但落点几乎全在「流程是否正确运转」（CI 是否绿、版本号是否五处一致、mixin 配置是否可解析、lang key 是否齐），而不是「产物是否真的对」（这个数值合理吗、这句话是真的吗、这个特效出现在正确的位置吗）。TXT-01（9 个语言包 69% 是英文）与 MIXIN-01（整格语义被改成 1 个）都属于后者：流程门全绿，产物有问题。",
    counterEvidence:
      "公平地说，「产物是否真的对」这一类断言在静态 CI 里本来就难写，而作者已经把能写的那部分写了（compat_check.py 做 data-pack schema / JSON-vs-Java drift，包括 26.1.2 的 loot/advancement schema 门；RuleArchitectureTest 与 EconomyAndConfigVerificationTest 显然在断言机制不变式）。所以这更像是一个「再往前一步」的方向，而不是缺陷。",
    testIt:
      "把门从「形式一致」扩展到「语义一致」的三条最便宜的加法：① lang 门加「非英文比例 + 占位符同构」（TXT-01/02 立刻变红）；② 加一份 docs/CLAIMS.md，把 README/WIKI/fabric.mod.json 里所有**带数字的断言**列成表，由脚本核对仓库实际值（TXT-04/05/07 立刻变红）；③ 硬编码清单（D-03）。三条都是纯 Python，不需要 JDK、不需要网络，完全符合这个仓库的 CI 现实。",
  },
];

export const SUGGESTIONS: Suggestion[] = [
  {
    id: "S-01",
    priority: "P0",
    title: "修 removeItemNoUpdate 的整格语义",
    what: "把 `return self.removeItem(slot, 1)` 改为按当前格的实际数量移除；若确实需要「不触发 update」，直接操作底层 items 列表并单独同步 blockstate。补一条针对堆叠 >1 的回归断言。",
    cost: "1 行改动 + 1 条测试。收益：消除 64 本附魔书被只搬走 1 本的数据风险。",
    refs: ["MIXIN-01"],
  },
  {
    id: "S-02",
    priority: "P0",
    title: "把 🔒 换成已经 shipped 的贴图",
    what: "ChiseledEnchantingConfigScreen 第 1224/1480 行的 \\uD83D\\uDD12 改为 blit toggle_locked.png（或 BMP 内的几何字符，与 EffectScope 的 ●◆▲ 家族一致）。",
    cost: "两处替换。收益：「这一项被锁定」这个最关键的语义不再显示为缺字方块。",
    refs: ["GUI-06"],
  },
  {
    id: "S-03",
    priority: "P0",
    title: "lang 门升级：非英文比例 + 占位符同构",
    what: "ci_static_checks.py 的 check_lang_parity 增加两条：① 每个 locale 统计「值与 en_us 逐字节相同」的比例，超阈值报 warn（阈值可先设 20%）；② 提取每条 value 的 %[0-9]*\\$?[sdf] 集合，与 en_us 不同构则 fail。",
    cost: "纯 Python，约 30 行，不需要 JDK/网络，完全符合现有 CI 约束。收益：TXT-01 与 TXT-02 立刻从「不可见」变成红灯/黄灯。",
    refs: ["TXT-01", "TXT-02", "D-08"],
  },
  {
    id: "S-04",
    priority: "P0",
    title: "README 首屏的两处数字改对",
    what: "「grant XP reduction starting at 12+ shelves」→「from 3 shelves (up to −15% at 45)」；fabric.mod.json port_notes 的「10-advancement」改为不带数字的表述或改成 29。",
    cost: "两行文本。收益：首屏与 mod 元数据是绝大多数人唯一会读的两段。",
    refs: ["TXT-05", "TXT-04"],
  },
  {
    id: "S-05",
    priority: "P0",
    title: "配置词法去版本化",
    what: "Preset.fromToken 与 CostTableDataset 移除 \"1.1.0\" / \"1.0.3\" 别名，改用 classic/standard/casual/expert；旧别名进 LEGACY_ALIASES 表并 warn；两个解析器统一 fail-closed。",
    cost: "约 30 行 + 一条 ConfigurationSafetyTest 断言。收益：下一次 version bump 不会再静默改变已落盘配置的语义。",
    refs: ["CODEC-01", "CODEC-02", "TXT-09"],
  },
  {
    id: "S-06",
    priority: "P1",
    title: "删除 HIGH_APPLICABILITY_IDS，让标签成为唯一真相源",
    what: "keystone 判定只查 #chiseled_enchanting_table:broad_applicability；unbreaking/mending 的专门系数改用显式分级标签或 JSON 的 id→系数映射；删除 3 参 public 重载。",
    cost: "中等（需要设计分级标签）。收益：「数据驱动」的承诺在这一处成立，同时消灭一个 public 旁路入口。",
    refs: ["COUP-01", "DEAD-03", "BAL-03"],
  },
  {
    id: "S-07",
    priority: "P1",
    title: "EXACT_CHEST_SPECS 迁入数据包",
    what: "24 条箱表 spec + 2 条前缀规则迁入 loot_injections.json（新增 chest_spawn_specs / prefix_rules 段），纳入 BundledDefaults 生成与 compat_check 校验；放开 isBuiltin 守卫改为「数据包优先、内置兜底」。",
    cost: "中等（需要扩 schema + 更新 import_upstream_loot.py）。收益：新版本新增结构时整合包作者能自己补，不必等一次 CI + release。",
    refs: ["CODEC-06", "D-03"],
  },
  {
    id: "S-08",
    priority: "P1",
    title: "overrides 阶梯加校验，消费端去掉 break",
    what: "fromJson 校验严格不减、∈[0, maxDirectBookshelves]、长度匹配 maxLevel；违规 warn + 丢弃回落曲线。maxUnlockedDirectTier 改为取所有满足条件的最大 lvl。",
    cost: "约 25 行 + 3 条测试。收益：数据包作者写错阶梯时得到告警而不是「玩家永久停在 II 级」。",
    refs: ["CODEC-03"],
  },
  {
    id: "S-09",
    priority: "P1",
    title: "协议 revision 改生成式 + 版本号注入文案",
    what: "REVISION 用 int + id(base, rev) 生成；probe 列表由 revision 列表生成；MISMATCH_MESSAGE 的 MC 版本由 processResources 从 gradle.properties 注入；补 docs/PROTOCOL_HISTORY.md。",
    cost: "小（重构 + 一份文档）。收益：改一次线格式只动一处；断线理由不再会说谎。",
    refs: ["NET-01", "NET-02", "D-04"],
  },
  {
    id: "S-10",
    priority: "P1",
    title: "搜索框改用 vanilla EditBox",
    what: "替换手写搜索框；长度上限抽常量并按 codePointCount 计数；补 Ctrl+V、光标移动；charTyped 转发给 scrollContainer 以对称。",
    cost: "中等（需要重排该控件的渲染，贴图可复用）。收益：一次性解决 GUI-01/02/03/04 四条，并让 IME 输入可用。",
    refs: ["GUI-01", "GUI-02", "GUI-03", "GUI-04"],
  },
  {
    id: "S-11",
    priority: "P2",
    title: "LibraryResonance.Config 迁到 Codec + 嵌套分组 record",
    what: "按 JSON 已有的分组（wooden_bookshelves / chiseled_mastery / tome_pages / wild_book_wear / epiphany_affinity / ritual / wait_curve / crossline_slip）拆成嵌套 record，整体写一个 RecordCodecBuilder Codec，fromJson 改为 codec.parse，删掉手写 intOr/doubleOr。",
    cost: "大（50 个字段的重构 + 所有构造点）。收益：位置参数互换这一整类静默缺陷被结构性消灭；新增旋钮的成本从「改全仓库」降为「改一个分组」。",
    refs: ["COUP-02"],
  },
  {
    id: "S-12",
    priority: "P2",
    title: "折扣上限：去掉隐式乘数，加上不变式校验",
    what: "删除 masteryScale 的隐式联动（或做成显式开关 scale_subcaps_with_total，默认 false）；fromJson 校验 woodDisc/globalDiscCap/baseDiscCap/specDiscCap 全部 ≤ totalDisc，违规 warn + 钳制（钳 woodDisc，不放过它）。",
    cost: "小。收益：GUI/JEI/REI/grimoire 五处显示的 −N% 与实际扣费一致；「上调会放大、下调不缩回」的不对称消失。",
    refs: ["COUP-03", "BAL-01"],
  },
  {
    id: "S-13",
    priority: "P2",
    title: "粒子位置按朝向计算",
    what: "TomeParticleEffects.burst 改为读取 BlockState 的 FACING，先算 +Z 面局部坐标再做旋转变换（或直接用原版按 facing 的槽位向量）；四个几何常数抽成命名常量。",
    cost: "小（约 20 行）。收益：母本温养系统唯一的空间反馈在四个朝向上都出现在正确的一面。",
    refs: ["COUP-07"],
  },
  {
    id: "S-14",
    priority: "P2",
    title: "剩余硬编码常数进 JSON",
    what: "rarityMultiplier 的 1.45/1.00/0.18/1.15、CONSERVATION_SAFETY_MARGIN_POINTS=5、applicability 的 0.42/24.0/2.35 与 keystone/rarityBoost 档位，迁入 library_resonance.json 新段（essence_valuation / applicability），纳入 BundledDefaults 生成与 GUI 的 EXPERIENCE_ECONOMY 域。",
    cost: "中等。收益：精华返还经济与仪式等待时长这两条玩家最能感知的曲线变成可调、可见、可同步。",
    refs: ["BAL-01", "BAL-02", "BAL-03"],
  },
  {
    id: "S-15",
    priority: "P2",
    title: "W ∩ C = ∅ 从偶然变成保证",
    what: "regular_bookshelves 的判定里显式排除雕纹书架（或排除「书架容器类」集合）；启动时自检，若某方块同时落入 W 与 C 则 warn 并列出。WIKI 的措辞改为「本 mod 强制排除」。",
    cost: "小。收益：原版未来把 chiseled_bookshelf 加入 enchantment_power_provider 时，双轨书库不会静默坍塌。",
    refs: ["COUP-05"],
  },
  {
    id: "S-16",
    priority: "P2",
    title: "ModMenu 换成真实 compileOnly 坐标",
    what: "加 `compileOnly(\"com.terraformersmc:modmenu:<ver>\")` + `-Penable_modmenu` 开关，删除 vendored shim 目录与虚构的 attachModpackBadges；CI 的 no-viewers job 同时关掉它。",
    cost: "小（但需要能访问 ModMenu 的 maven）。收益：三个可选集成的处理方式统一，编译期能发现上游 API 变化。",
    refs: ["API-04", "DEAD-02"],
  },
  {
    id: "S-17",
    priority: "P3",
    title: "建一份 GLOSSARY.md 作为术语与写法的唯一真相源",
    what: "canonical 英文名 / canonical 中文名 / ID / 允许别名 / 禁止别名 + 一节写法规范（区间、维度、阈值、专有名词大小写）。加一条 lint 扫 *.md 与 JSON 的 _comment 报违规为 warn。JEI/REI 的搜索关键词显式加入别名。",
    cost: "中等（一次整理 + 一条脚本）。收益：TXT-03 与 TXT-10 一并解决，且让后续翻译有可依据的术语表。",
    refs: ["TXT-03", "TXT-10"],
  },
  {
    id: "S-18",
    priority: "P3",
    title: "书架阈值总表 + 文档入口决策表，均由脚本渲染",
    what: "WIKI 增「书架阈值总表」（38/42/45/32/22/12/3/4/10 → 机制 / JSON 键 / 到达难度 / 调整影响），由脚本从 shelf_gates.json + library_resonance.json 生成；DOCUMENTATION_INDEX.md 顶部加按角色三行表；TODO.md 合并进 NEXT_TASK.md。",
    cost: "中等。收益：TXT-06 与 TXT-12 解决，且阈值表不会再有第四份手抄副本。",
    refs: ["TXT-06", "TXT-12", "COUP-04"],
  },
  {
    id: "S-19",
    priority: "P3",
    title: "命名大扫除放在 2.0.0，1.x 期间加 @Deprecated 桥接",
    what: "Enchantement* → Enchantment*（73 处）、snake_case 访问器 → camelCase（约 100 处）、EntityRegistry → BlockEntityRegistry；1.x 里保留旧名桥接并在 CHANGELOG 给出对照表。",
    cost: "大但机械（可脚本化）。收益：公共 API 表面在还有人依赖之前变干净；越晚成本越高。",
    refs: ["API-01", "API-02", "API-03"],
  },
  {
    id: "S-20",
    priority: "P3",
    title: "把随机刻收敛到附魔台的 1 秒刷新循环",
    what: "AddRandomTick 的 isRandomlyTicking 只在「该书架处于某座附魔台的 scan_volume 内且该附魔台当前有玩家打开」时为 true；或把粒子/音效触发迁到已经存在的 1 秒实时刷新路径上。",
    cost: "中等。收益：满配书库（最多 342 个书架）× 多座附魔台的服务器不再有每书架级别的随机刻成本与 ~96 粒子/tick 的 S2C 压力。",
    refs: ["MIXIN-05"],
  },
  {
    id: "S-21",
    priority: "P3",
    title: "手工 QA 清单 + headless 客户端截图 job",
    what: "docs/reports/MANUAL_QA.md：每条「Audit XXX」修复配一组步骤 + 期望结果；CI 加一个 headless runClient job（--quickPlay 进世界、开附魔台、开配置界面、搜索框输入含星平面字符的串、截图提交到 build-reports/）。",
    cost: "中等（需要 CI 能跑客户端）。收益：D-01 与 D-05 两个弱点一起补上——GUI 与 mixin 这两条最难测的路径第一次有了可见证据。",
    refs: ["D-01", "D-02", "D-05"],
  },
];

export const VERDICT = {
  headline: "总体判断",
  summary:
    "这是一个工程纪律明显高于同类社区移植的项目：BundledDefaults 的「JSON 是唯一真相源 + CI 逐字节校验」、16 个版本化的协议通道与握手断开、服务端「先校验后扣费」的权威模型、以及对失败 CI run 的公开记录，都是真功夫。WIKI 里所有可复算的数值公式本次逐项复算全部通过。",
  risk:
    "风险集中在三个地方，而且它们互相放大：① 产物级验证缺失（无 JDK/无网络的沙箱 + 测试够不到 client 源集），使得 GUI 与 mixin 这两条最需要真人验证的路径恰好最没被验证；② 「数据驱动」的纪律有明确边界但边界没有写下来，于是掉落表、稀有度倍率、普适度参考值、粒子几何这些玩家能直接感知的东西仍然是 Java 字面量；③ 文本层的宣称（11 种语言、10 个进度、12 架起减免）与实际内容之间存在可测量的落差，而现有 CI 门的语义恰好检测不到这种落差。",
  bottomLine:
    "如果只做五件事：修 removeItemNoUpdate 的整格语义（1 行）、把 🔒 换成已有贴图（2 处）、给 lang 门加「非英文比例 + 占位符同构」（30 行 Python）、改对 README 首屏的两个数字（2 行）、把配置词法去版本化（30 行）。这五件加起来不到一天工作量，却覆盖了本次审计里 1 条严重、4 条高危，以及全部三条「宣称与现实不符」。",
};
