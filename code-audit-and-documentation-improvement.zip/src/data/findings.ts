export type Severity = "crit" | "high" | "med" | "low" | "info" | "good";

export type PathKey =
  | "api"
  | "codec"
  | "net"
  | "gui"
  | "mixin"
  | "dead"
  | "coupling"
  | "balance";

export interface Finding {
  id: string;
  path: PathKey;
  severity: Severity;
  title: string;
  where: string[];
  evidence: string;
  impact: string;
  fix: string;
  /** reproducible command, so every claim can be re-verified */
  probe?: string;
  versionBound?: string;
}

export interface PathMeta {
  key: PathKey;
  idx: string;
  zh: string;
  en: string;
  accent: string;
  glyph: string;
  blurb: string;
}

export const PATHS: PathMeta[] = [
  {
    key: "api",
    idx: "01",
    zh: "源码 API",
    en: "Source API surface",
    accent: "#3e9ab0",
    glyph: "◇",
    blurb:
      "对外暴露的类名、方法名、常量与可选集成的接入方式。这里是「以后改不动」的成本发生地。",
  },
  {
    key: "codec",
    idx: "02",
    zh: "数据编解码",
    en: "Data & codec",
    accent: "#3d6fd1",
    glyph: "▤",
    blurb:
      "JSON → record、record → 线格式、线格式 → record。所有边界解析的容错方向与校验缺口。",
  },
  {
    key: "net",
    idx: "03",
    zh: "网络同步",
    en: "Network sync",
    accent: "#6fa0f0",
    glyph: "⇄",
    blurb:
      "16 个协议 revision、能力握手、S2C 价格表、服务端权威性与限流。跨版本最容易静默分叉的地方。",
  },
  {
    key: "gui",
    idx: "04",
    zh: "GUI 输入",
    en: "GUI & input",
    accent: "#a46ee5",
    glyph: "▣",
    blurb:
      "鼠标/键盘路由、模态覆盖层契约、手写搜索框、字形可渲染性。审计中缺陷密度最高的一条路径。",
  },
  {
    key: "mixin",
    idx: "05",
    zh: "Mixin 注入",
    en: "Mixin injection",
    accent: "#d99b38",
    glyph: "✦",
    blurb:
      "13 个 mixin、2 处 createResult 包裹、槽位实例替换、随机刻开关。对原版语义的偏离最危险。",
  },
  {
    key: "dead",
    idx: "06",
    zh: "死代码",
    en: "Dead code",
    accent: "#766b93",
    glyph: "○",
    blurb:
      "空方法、指向已删除类的构建注释、跨版本搬来的 workaround、无人实现的 shim API。",
  },
  {
    key: "coupling",
    idx: "07",
    zh: "耦合风险",
    en: "Coupling risk",
    accent: "#d17a47",
    glyph: "⬡",
    blurb:
      "双真相源、50 位置参数 record、隐式乘数、四个书架天花板、以及对原版标签的偶然依赖。",
  },
  {
    key: "balance",
    idx: "08",
    zh: "数值 / 机制设计",
    en: "Numbers & mechanics",
    accent: "#43c59e",
    glyph: "≡",
    blurb:
      "哪些常数该进数据包却没进、哪些曲线设计得当、哪些价格关系是可验证的倾斜。",
  },
];

export const SEV_META: Record<
  Severity,
  { zh: string; color: string; rank: number }
> = {
  crit: { zh: "严重", color: "#ff6b6b", rank: 0 },
  high: { zh: "高", color: "#ffa24d", rank: 1 },
  med: { zh: "中", color: "#ffd66b", rank: 2 },
  low: { zh: "低", color: "#7fd6a8", rank: 3 },
  info: { zh: "观察", color: "#7fb6ff", rank: 4 },
  good: { zh: "做得好", color: "#43c59e", rank: 5 },
};

export const FINDINGS: Finding[] = [
  // ---------------------------------------------------------------- 01 API
  {
    id: "API-01",
    path: "api",
    severity: "high",
    title: "公共 API 里 73 处法语拼写 “Enchantement”（正确英文是 Enchantment）",
    where: [
      "src/client/…/gui/EnchantementListWidget.java（public 类名，32 处出现）",
      "src/main/…/menu/ChiseledEnchantingTableScreenHandler.java：unlocked_enchantements（public 字段，43 处）",
      "applyEnchantement / applyEnchantementCondition / applyEnchantementConditionWithReceipt / streamAllEnchantements / get_unlocked_enchantements",
    ],
    evidence:
      "`grep -rno \"[Ee]nchantement\" src` → 73 命中。全部落在 public 表面：一个 public client 类名、一个 public 字段、五个 public 方法。",
    impact:
      "JEI/REI 适配器、其它 mod 的 mixin、以及任何反编译读者看到的都是拼错的词。它不是内部变量，改名即破坏性变更；越晚修越贵。拼写错误还会传染：新代码倾向于沿用既有拼法以保持一致。",
    fix: "在下一个 major（2.0.0）统一改为 Enchantment*；1.x 期间保留 @Deprecated 的薄别名桥接，并在 CHANGELOG 里给出一张「旧名 → 新名」对照表。",
    probe: "grep -rno \"Enchantement\\|enchantement\" --include=*.java src | wc -l",
  },
  {
    id: "API-02",
    path: "api",
    severity: "med",
    title: "同一个 public 表面上 snake_case 与 camelCase 并存",
    where: [
      "get_enchantable_item（37 处）、get_cost_item（26 处）",
      "is_category_header（14）、is_tome_entry（10）、is_transformation（9）",
      "apply_wild_book_wear、unlocked_enchantements",
    ],
    evidence:
      "上游原版遗留的 snake_case 访问器与移植期新增的 camelCase 方法在同一个 3088 行的 ScreenHandler 里混排。",
    impact:
      "调用方无法从命名预测风格；IDE 补全里同一语义出现两种拼法。对 mixin 作者尤其糟——注入目标的方法名没有稳定约定。",
    fix: "统一 camelCase（与 Mojmap/Fabric 生态一致），旧名保留一版 @Deprecated 桥接。可与 API-01 合并成一次「命名大扫除」release。",
    probe:
      "grep -rnoE \"\\b(get|set|apply|is)_[a-z_]+\\b\" --include=*.java src/main src/client | wc -l",
  },
  {
    id: "API-03",
    path: "api",
    severity: "low",
    title: "EntityRegistry 名不副实，且 init() 是空方法",
    where: ["src/main/…/registry/EntityRegistry.java"],
    evidence:
      "该类注册的是 BlockEntityType<ChiseledEnchantingTableBlockEntity>，与 Entity 无关；`public static void init() { }` 方法体为空，由 ChiseledEnchantingTable.onInitialize 调用。",
    impact:
      "读者会去找「哪个 Entity」；空 init() 制造了「初始化发生在这里」的假象，真实注册发生在类加载时的静态字段初始化——两者的时序含义完全不同（静态初始化在首次引用该类时触发，而 init() 调用点是显式的）。",
    fix: "改名 BlockEntityRegistry；空 init() 保留为「触发类加载」的显式意图时，加一行注释说明它就是为此存在，否则删掉调用点。",
  },
  {
    id: "API-04",
    path: "api",
    severity: "high",
    title: "ModMenu 走手写 vendored shim，且 shim 里有真实 API 中不存在的方法",
    where: [
      "src/client/java/com/terraformersmc/modmenu/api/ModMenuApi.java",
      "src/client/java/com/terraformersmc/modmenu/api/ConfigScreenFactory.java",
      "build.gradle：tasks.withType(Jar) { exclude 'com/terraformersmc/**' }",
    ],
    evidence:
      "shim 声明了 `default void attachModpackBadges(Consumer<String>)`，而 ChiseledEnchantingModMenuPlugin 只实现了 getModConfigScreenFactory。仓库里搜不到 `modmenu` 出现在 gradle.properties / build.gradle 依赖 / 任何 workflow 中——没有 compileOnly 坐标，也没有 -Penable_modmenu 开关。",
    impact:
      "三个可选集成三种处理方式：JEI/REI 用真实 compileOnly 坐标 + 可关闭开关 + CI 的 no-viewers job 验证；ModMenu 用一份「猜出来的接口」。真实 ModMenu 若新增抽象方法或改动 ConfigScreenFactory 签名，编译期不会报错（编的是 shim），运行期直接 AbstractMethodError / 入口点加载失败。虚构的 attachModpackBadges 还会误导后续贡献者以为可以覆写它。",
    fix: "换成 `compileOnly(\"com.terraformersmc:modmenu:<ver>\")` + `-Penable_modmenu` 开关，删掉 vendored 目录；或至少把 shim 精简到真实存在的两个方法，并在文件头写明「这是对上游 API 的最小子集复刻，签名以 ModMenu 实际发布为准」。",
    probe: "grep -rn \"modmenu\" gradle.properties build.gradle .github/workflows/ || echo 'no coordinate, no toggle'",
  },
  {
    id: "API-05",
    path: "api",
    severity: "high",
    title: "附魔书堆叠上限 64 在至少三处独立硬编码，且参与断线握手",
    where: [
      "ChiseledEnchantingTable.onInitialize：Math.max(1, Math.min(64, ModRuntimeConfig.get().enchantedBookStackSize()))",
      "EnchantingProtocol.Capability 紧凑构造器：Math.max(1, Math.min(64, enchantedBookStackSize))",
      "ModRuntimeConfig.Preset.applyTo：fresh.enchantedBookStackSize = 64",
    ],
    evidence:
      "三处各写一次 `64`，没有共享常量；而 bootEnchantedBookStackSize() 的结果会被编入 S2C/S2C 能力包并用于 stackSizeIncompatible() 判定，不匹配就 disconnect。",
    impact:
      "任一处漂移（例如把 preset 默认改成 16 却忘了改钳位）→ 客户端与服务端对「同一个配置值」算出不同的 boot 值 → 启动握手误判 → 玩家批量被踢，且踢人理由里显示的两个数字看起来是一样的，极难排查。",
    fix: "抽 `PayloadLimits.MAX_ENCHANTED_BOOK_STACK`（或放进 BundledDefaults 由 JSON 生成），三处统一引用；握手比较用未钳位原值，钳位只用于本地应用。",
    probe: "grep -rn \"Math.min(64\" --include=*.java src/main src/client",
  },

  // -------------------------------------------------------------- 02 CODEC
  {
    id: "CODEC-01",
    path: "codec",
    severity: "high",
    title: "发行版本号被写进了持久化配置的词法：\"1.1.0\" 是 Preset 的解析别名",
    where: [
      "ModRuntimeConfig.Preset.fromToken：case \"standard\", \"default\", \"normal\", \"1.1.0\" -> STANDARD",
      "ModRuntimeConfig.CostTableDataset：MODERN_1_1_0(\"modern_1_1_0\")",
    ],
    evidence:
      "配置文件里写 `\"preset\": \"1.1.0\"` 今天能解析成 STANDARD；枚举常量名 MODERN_1_1_0 与 token `modern_1_1_0` 也带着版本号。",
    impact:
      "1.2.0 发布后：(a) 已经落盘的 `\"1.1.0\"` 变成未识别 token；(b) 枚举名继续宣称自己是「1.1.0 的现代表」，而它承载的是 1.2.0 的数值；(c) 任何自动化脚本按当前版本号生成配置都会在下一次 bump 后静默失效。这是典型的「版本耦合的持久化格式」。",
    fix: "配置词法只用与版本无关的稳定 token（classic / standard / casual / expert）。旧别名保留在一个显式的 LEGACY_ALIASES 表里，命中时打一条 warn 日志说明「此别名将在 2.0 移除」。枚举改名 MODERN / CLASSIC。",
    probe: "grep -rn '\"1\\.1\\.0\"\\|MODERN_1_1_0\\|modern_1_1_0' --include=*.java src/main",
  },
  {
    id: "CODEC-02",
    path: "codec",
    severity: "med",
    title: "同一份配置里两个 token 解析器的容错方向相反",
    where: [
      "CostTableDataset.fromToken(raw)：任何未识别输入 → MODERN_1_1_0（fail-open）",
      "Preset.fromToken(raw)：未识别输入 → null（fail-closed）",
    ],
    evidence:
      "fromToken 只匹配 \"classic_1_0_3\" / \"1.0.3\"，其余一律返回 MODERN，没有日志、没有 warn。",
    impact:
      "把 `\"classic_1_0_3\"` 拼成 `\"classsic_1_0_3\"` 会静默换成现代价格表——玩家看到的是「配置没生效」，而不是「配置写错了」。同一个文件里 Preset 的拼写错误却会被拒绝，两种行为不一致，用户无法建立稳定的心智模型。",
    fix: "统一 fail-closed：未识别 token 返回 Optional.empty() / null，由调用方回退到默认值并 LOGGER.warn 出「收到的原始字符串 + 可接受值列表」。仓库已经有 ConfigurationSafetyTest，正好把这条断言加进去。",
  },
  {
    id: "CODEC-03",
    path: "codec",
    severity: "high",
    title: "overrides 阶梯零校验，而消费方在第一个不满足处 break",
    where: [
      "BookshelfProgression.requiredBookshelvesForDirectTier(Config,…)：`return Math.max(0, ladder.get(targetLevel - 1))`",
      "BookshelfProgression.maxUnlockedDirectTier：for lvl=2..M，`if (shelves >= req) unlocked = lvl; else break;`",
      "shelf_gates.json → direct_upgrade_gates.overrides",
    ],
    evidence:
      "解析侧（BookshelfProgression.java 第 355–386 行）只把 JSON 数组复制成 List<Integer>，不检查单调性、不检查上界、不检查长度是否覆盖 maxLevel。",
    impact:
      "三个可达故障：① 非单调阶梯（如 `[0,5,3,20,38]`）配合 break → 玩家有 38 个书架却永久停在 II 级；② 阶梯值 > max_direct_bookshelves（如 999）→ 该等级永久不可达，且没有任何提示；③ 阶梯短于 maxLevel → 前半段查表、后半段回落到 gamma 曲线，两个来源在接缝处也可能非单调。全部是静默的。",
    fix: "fromJson 里校验：严格不减、每项 ∈ [0, maxDirectBookshelves]、长度 == 该魔咒 maxLevel（或显式声明「只覆盖前 k 级」）。任一不满足 → warn + 丢弃该条 override 回落曲线。另外把 maxUnlockedDirectTier 的 break 换成「取所有满足 req 的最大 lvl」，让消费侧对非单调输入也稳健。",
  },
  {
    id: "CODEC-04",
    path: "codec",
    severity: "low",
    title: "shelf_gates.json 的 _comment 宣称的里程碑在该文件里不存在",
    where: ["data/…/chiseled_enchanting_table/shelf_gates.json 第 2 行"],
    evidence:
      "_comment 写「unified 12 / 32 / 38 milestones」，但 depleted_tome_gradients 块里只有 tier1=12、tier2=32、tier3_qualifying_enchantments=6、batch=64——没有 38。38 属于隔壁的 direct_upgrade_gates.max_bookshelves 与 library_resonance 的 tome_regen_tier1_shelves。",
    impact:
      "数据包作者读 _comment 会以为改这一个块就能移动三个里程碑，实际只会移动两个。注释与数据不同源，且没有任何 CI 门校验注释里的数字。",
    fix: "_comment 只描述本文件内实际存在的键；跨文件的里程碑关系写进 docs/WIKI.md 的单一小节，并让 compat_check.py 断言「注释里出现的数字必须能在同文件找到」。",
  },
  {
    id: "CODEC-05",
    path: "codec",
    severity: "med",
    title: "价格表 payload 的大小控制建立在手工估算常数上，没有真实编码长度回退",
    where: [
      "PayloadLimits：ESTIMATED_HEADER_BYTES=8_192、ESTIMATED_BYTES_PER_ROW=96、ESTIMATED_BYTES_PER_STACK=96、MAX_ESTIMATED_PAYLOAD_BYTES=900_000",
      "PayloadLimits.estimateStackBytes：patch.size()*48、customData.toString().length()*2、name.length()*4、lore 每行 24+len*4",
    ],
    evidence:
      "注释自己承认这是「conservative byte estimate」，超预算就截断并把表标记为 incomplete。原版自定义 payload 的硬上限是 1 MiB（1048576），估算预算取 900 000，余量 ~14%。",
    impact:
      "两个方向都会错：估算偏低 → 真实编码仍超 1 MiB → 连接被踢（不是截断）；估算偏高 →  unnecessarily 截断，客户端价格表显示不全而玩家无从知道原因。自定义数据组件（CUSTOM_DATA 的大 NBT、长 CUSTOM_NAME、多行 LORE）正是估算误差最大的地方，而这些恰恰是数据包作者最可能塞进去的东西。",
    fix: "发送前用一次「写到丢弃缓冲」的真实编码测长（vanilla 的 RegistryFriendlyByteBuf 可以直接编码到一个 netty Unpooled buffer 拿 writerIndex），只在真实长度超限时才逐级降级：先丢组件重的 cost stack，再丢行，最后回落到「仅 ID+等级」的精简表。估算常数保留为快速预筛即可。",
  },
  {
    id: "CODEC-06",
    path: "codec",
    severity: "high",
    title: "24 张原版箱子战利品表的概率/数量硬编码在 Java 里，与 loot_injections.json 并存为两套真相源",
    where: [
      "DepletedTomeWorldMechanics.EXACT_CHEST_SPECS（Map.ofEntries，24 条）",
      "同方法内的前缀兜底：chests/trial_chambers/ → 0.28F；chests/village/ → 0.10F",
      "对照：data/…/loot_injections.json（数据驱动，由 scripts/import_upstream_loot.py 生成，_schema_version: 1）",
    ],
    evidence:
      "initChestLootInjection 用 `if (!source.isBuiltin()) return;` 守卫——即数据包**无法**覆盖这些硬编码概率；而 loot_injections.json 走的是另一条 LootRegistry 路径，是数据驱动的。",
    impact:
      "① 双真相源：同一件事（往原版箱子里塞本 mod 的东西）有两套机制，读者必须同时理解两套才知道最终掉落。② 版本脆弱：Mojang 一旦重命名或新增 chests/* 路径（新版本新结构是常态），Java 表静默失配，没有告警。③ `!source.isBuiltin()` 让整合包作者无法修正——而这正是 pack_policy.json 宣称要服务的场景。④ WIKI 第 173 行把 S/A/B 三档概率逐条列了出来，文档又成了第三份副本。",
    fix: "把 EXACT_CHEST_SPECS 迁进 loot_injections.json（新增 `chest_spawn_specs` 段），保留前缀兜底作为 schema 里的 `prefix_rules`；BundledDefaults 生成器把它纳入单一真相源纪律；去掉 isBuiltin 守卫或改成「数据包优先，内置兜底」。WIKI 的表格改为由脚本从 JSON 渲染。",
    probe:
      "grep -n 'Map.entry(\"chests/' src/main/java/chiseled_enchanting_table/mechanics/loot/DepletedTomeWorldMechanics.java | wc -l",
  },

  // ----------------------------------------------------------------- 03 NET
  {
    id: "NET-01",
    path: "net",
    severity: "med",
    title: "16 个协议 revision 全靠手写常量枚举，且命名已经与现实脱节",
    where: [
      "EnchantingProtocol：LEGACY_COST_TYPE、PREVIOUS_COST_TYPE(=revision_4)、REVISION_5..15_COST_TYPE",
      "LEGACY_COST_PROBES（revision 1/2/3 只在列表里内联 new，没有常量）",
      "LEGACY_APPLY_PROBES（revision 9..15 内联 new）",
    ],
    evidence:
      "REVISION = \"26_1_2_revision_16\"。12 个具名常量 + 2 个列表 + 若干内联 Type 构造，四处需要手工保持同步；名为 PREVIOUS_COST_TYPE 的常量指向 revision_4，在第 16 版上早已不是「previous」。",
    impact:
      "每次改线格式要动 4 处；漏掉一个 probe，握手就会「放过一个不兼容的对端」，然后在第一次真实解码时抛出原始 decode 错误而不是优雅断线——这正是注释里 Probe retirement policy 想避免的结局。命名脱节则让新贡献者误判哪个是「上一个」版本。",
    fix: "改成生成式：`static final List<String> COST_REVISIONS = …`，probe 列表由 `COST_REVISIONS.stream().map(r -> new Type<>(id(r))).toList()` 生成；当前 revision 用一个 int 常量 + `id(base, rev)` 函数。命名统一为 REVISION_N，删除 PREVIOUS/LEGACY 这种相对时间词。同时把「probe 退休政策」写成一条 CI 断言：任何已发布 tag 里注册过的 channel id 必须仍在列表中。",
  },
  {
    id: "NET-02",
    path: "net",
    severity: "med",
    title: "断线文案把 Minecraft 版本号硬编码进字符串，且 11 种语言只有一条 fallback",
    where: [
      "EnchantingProtocol.MISMATCH_MESSAGE：\"Install the same current Minecraft 26.1.2 build on both client and server…\"",
      "stackSizeMismatchComponent 的 fallback：硬编码路径 \"config/chiseled_enchanting_table.json\"",
    ],
    evidence:
      "两处都通过 Component.translatableWithFallback 提供，所以本地化机制是对的；但 fallback 文本里的 26.1.2 与配置路径是字面量。",
    impact:
      "换 MC 版本（或这条分支被同步到 26.3）时，玩家看到的断线理由会当众说谎——而断线理由恰恰是用户唯一能读到的诊断信息。11 种语言里只有 zh_cn/zh_tw 可能真的翻译了这条 key，其余 9 种会读到英文 fallback 里的旧版本号。",
    fix: "版本号由 processResources 从 gradle.properties 的 minecraft_version 注入（build.gradle 已经在对 fabric.mod.json 做同样的 expand）；配置路径抽成常量并在 lang 里作为一个参数位。",
  },
  {
    id: "NET-03",
    path: "net",
    severity: "med",
    title: "能力握手在比较之前就把对端上报值钳位，掩盖了真正的超范围配置",
    where: [
      "EnchantingProtocol.Capability 紧凑构造器：enchantedBookStackSize = Math.max(1, Math.min(64, …))",
      "EnchantCostSync.init 的 Capability receiver → stackSizeIncompatible(serverStack, payload.enchantedBookStackSize())",
    ],
    evidence:
      "解码即钳位，随后参与兼容性比较的都是钳位后的值。",
    impact:
      "今天上限 64 与配置上限一致所以无害；一旦配置允许 >64（或某一侧被整合包改大），对端的 128 会被解码成 64，与本地 64 判定「兼容」→ 握手放行 → 两侧对同一物品的堆叠语义分叉，表现为随机的物品丢失/复制，而不是清晰的断线理由。钳位把「可诊断的不兼容」变成了「不可诊断的数据损坏」。",
    fix: "解码时保留原值（只做 VarInt 的负数/超大防御），把钳位放到「本地应用配置」那一步；比较用原值，并在 mismatch 组件里报出真实的两个数字。",
  },
  {
    id: "NET-04",
    path: "net",
    severity: "med",
    title: "铁砧修理费的 client/server 判定走 ThreadLocal，越界调用时静默回落到服务端配置",
    where: [
      "RemoveXpCostScaling：ThreadLocal<Boolean> CET_CLIENT_ANVIL_SIDE，仅在 @WrapMethod(createResult) 内设置",
      "@Inject(calculateIncreasedRepairCost, HEAD, cancellable) 里读取；为 null 时打一条一次性 debug 日志并回落到 ChiseledEnchantingTableData.runtimeConfiguration()",
    ],
    evidence:
      "代码自己知道这个通道可能没被设置（AtomicBoolean CET_LOGGED_UNSCOPED_ANVIL_CALL + debug 日志），但没有 fail-closed。",
    impact:
      "任何不经过 createResult 的调用路径（原版未来版本的新路径、其它 mod 主动调用、以及 createResult 之外的重算）都会拿到**服务端**配置来决定**客户端**的显示。单人游戏里两侧配置可能不同（离线客户端配置 vs 服务器配置），于是「Too Expensive!」的预览与实际结算分叉。debug 级别日志在生产环境默认不可见，问题会完全无声。",
    fix: "改成显式参数传递（若原版签名允许）或以 menu 实例字段记录 side（在 <init> 里用 player.level().isClientSide() 一次性确定，因为一个 menu 实例只属于一侧）；把一次性日志升到 warn 并附带 stack trace 采样，让越界调用可被发现。",
    versionBound: "calculateIncreasedRepairCost 的方法名/静态性是 26.1.2 特定假设；defaultRequire=1 意味着一旦改名即启动崩溃。",
  },
  {
    id: "NET-05",
    path: "net",
    severity: "low",
    title: "S2C 去重缓存用无同步的 WeakHashMap，且 value 持有 ItemStack",
    where: ["EnchantCostSync.LAST_DISPLAYS = new WeakHashMap<ServerPlayer, List<TransformationDisplay>>()"],
    evidence:
      "EnchantingNetworking 里的三个限流 Map 都在 DISCONNECT / SERVER_STOPPED 显式清理（注释写明了这条纪律），但 LAST_DISPLAYS 依赖弱引用 + WeakHashMap 的惰性清理。",
    impact:
      "WeakHashMap 只在被访问时清理 stale entry；长期运行的服务器上，已断开玩家的 List<TransformationDisplay>（内含 ItemStack 副本）可能在 map 里滞留到下一次访问。量级不大，但与同仓库另外三个 Map 的显式生命周期纪律不一致——不一致本身就是风险。",
    fix: "统一改成 UUID 键 + 在 ServerPlayConnectionEvents.DISCONNECT 里 remove，与 EnchantingNetworking 的写法对齐；或直接换成 ConcurrentHashMap。",
  },
  {
    id: "NET-GOOD",
    path: "net",
    severity: "good",
    title: "服务端权威性与限流做得扎实，应当保留",
    where: [
      "EnchantmentApplication.apply：先校验 enchantable 非空/count==1、enchantment 存在、level ∈ [1, maxLevel]、canEnchant、existingSameLevel < 请求等级、再查 unlocked_enchantements 白名单、再 canQueue 准入、最后才扣费",
      "EnchantingNetworking：MAX_APPLIES_PER_TICK=8、MAX_ACTIONS_PER_TICK=6，packed tick<<16|count 的每 tick 突发守卫，且三张表都在 DISCONNECT/SERVER_STOPPED 清理",
      "PayloadLimits.readBoundedCount：负数与超限都抛异常，注释明确「never treat negative counts as empty」",
    ],
    evidence:
      "客户端发来的 enchantment_id 从不被信任为「可用」：即使付得起 resolveXpRequirement 的价格，不在 unlocked_enchantements / 不匹配当前 Treasure Epiphany 就 return false。旧客户端只发 ENCHANTMENT 类型时，服务端用 ChiseledEnchantingTableData.isTransformation 自己重新路由。",
    impact:
      "这一层是本次审计中最经得起推敲的部分：先校验后扣费、扣费与产出在同一方法内原子完成、所有集合读取都有显式上界。审计中未发现可绕过的服务端校验缺口。",
    fix: "保持。建议把「校验顺序」写成一份 docs/SECURITY.md 的不变式清单，让后续修改不会无意中把扣费提前。",
  },

  // ----------------------------------------------------------------- 04 GUI
  {
    id: "GUI-01",
    path: "gui",
    severity: "high",
    title: "配置界面搜索框是手写的，缺少光标、选区、粘贴与光标移动",
    where: ["ChiseledEnchantingConfigScreen.charTyped / keyPressed（第 2057–2130 行）"],
    evidence:
      "charTyped 里 `if (cp >= 32 && cp != 127 && this.searchQuery.length() < 40) setSearchQuery(this.searchQuery + Character.toString(cp))`；keyPressed 只处理 ESCAPE / BACKSPACE / DELETE / RETURN，末尾无条件 `return true`。仓库里已经 shipped `search_box.png` 与 `search_box_focus.png` 贴图，但没有使用 vanilla EditBox。",
    impact:
      "没有 Ctrl+V 粘贴（搜索一个长魔咒名必须逐字敲）、没有左右/Home/End 光标移动、没有选区替换、没有按键重复。40 字符上限是硬编码魔数，且 `String.length()` 数的是 UTF-16 code unit——一个星平面字符占 2，实际上限会浮动。",
    fix: "改用 vanilla EditBox（它自带光标、选区、粘贴、重复、IME 组合），把 40 抽成命名常量并改按 codePointCount 计数；贴图仍可用现有的 search_box*.png 作为背景。",
  },
  {
    id: "GUI-02",
    path: "gui",
    severity: "high",
    title: "退格用 substring 截尾，会切断代理对——对 CJK 用户是可达路径",
    where: ["ChiseledEnchantingConfigScreen.keyPressed：setSearchQuery(this.searchQuery.substring(0, this.searchQuery.length() - 1))"],
    evidence:
      "按 UTF-16 unit 截掉最后一个 char，而不是最后一个 code point。",
    impact:
      "删除 emoji 或 CJK 扩展 B 汉字（如 𠀀、𩸽）时会留下一个孤立的高位代理项，后续再拼接 `Character.toString(cp)` 会产生非法字符串，渲染为方框或触发字体回退异常。本 mod 唯一 100% 翻译的语言是 zh_cn/zh_tw，恰好是最可能输入这类字符的用户群；而 GUI-06 又证明界面里确实存在星平面字符（🔒）。",
    fix: "用 `searchQuery.offsetByCodePoints(searchQuery.length(), -1)` 或正则去掉末尾一个 code point；同时把 charTyped 的长度判定改为 codePointCount。",
  },
  {
    id: "GUI-03",
    path: "gui",
    severity: "med",
    title: "搜索框聚焦时无条件吞掉所有按键",
    where: ["ChiseledEnchantingConfigScreen.keyPressed：searchFocused 分支末尾 `return true;`"],
    evidence:
      "该分支只显式处理 ESC/BACKSPACE/DELETE/RETURN，其余按键（含 Ctrl+V、F1–F12、E、Esc 的游戏菜单语义）全部落到 `return true`。",
    impact:
      "用户在搜索框里按 Ctrl+V 没有任何反馈（既没粘贴也没提示），F11 全屏、F3 调试等系统级快捷键也失效。模态界面吞键是合理设计，但「吞掉且不告知」会让用户以为键盘坏了。",
    fix: "分支末尾改为：可打印字符交给 charTyped、已知快捷键显式处理、其余 `return super.keyPressed(event)`；或至少在吞掉 Ctrl+V 时播一次否定音并闪一下搜索框边框。",
  },
  {
    id: "GUI-04",
    path: "gui",
    severity: "low",
    title: "charTyped 不转发给列表控件，而 keyPressed 转发——输入路由不对称",
    where: [
      "ChiseledEnchantingTableScreen.keyPressed：configOverlay → grimoireOverlay → scrollContainer → super",
      "ChiseledEnchantingTableScreen.charTyped：configOverlay → grimoireOverlay → super（缺 scrollContainer）",
    ],
    evidence:
      "类注释写的是「while configOverlay/grimoireOverlay is open, EVERY input callback is forwarded to it」——注释只承诺了覆盖层，但两个方法在非覆盖层路径上的行为确实不一致。",
    impact:
      "当前 EnchantementListWidget 没有文本输入，所以是潜伏问题而非现网故障。但它是一个陷阱：任何人给列表加一个筛选框（这是很自然的需求）都会发现「键盘按键能收到、字符收不到」，而 IME 组合输入只走 charTyped——中文用户会完全打不出字。",
    fix: "补上 `if (this.scrollContainer.charTyped(event)) return true;`，与 keyPressed 对称。顺手把类注释里的「EVERY input callback」落实为一条可检查的清单。",
  },
  {
    id: "GUI-05",
    path: "gui",
    severity: "med",
    title: "模态覆盖层的退出依赖约定而非机制",
    where: [
      "ChiseledEnchantingTableScreen.keyPressed / charTyped：覆盖层非空时丢弃其返回值并 `return true`",
      "注释：「ESC-to-close is each overlay's own responsibility (its onClose clears the field via callback)」",
    ],
    evidence:
      "两个现有覆盖层都处理了 ESC（ChiseledEnchantingConfigScreen 与 ArcaneGrimoireScreen 各自 `if (key == KEY_ESCAPE) { onClose(); return true; }`），所以今天没有软锁。",
    impact:
      "父界面永远不会走到 `super.keyPressed`，也就永远不会触发 vanilla 的 keyInventory/ESC 关屏逻辑。任何新增覆盖层只要忘记处理 ESC，玩家就被软锁在界面里：关不掉、也打不开游戏菜单，只能强退。这是一条没有护栏的悬崖。",
    fix: "把「处理 ESC」从约定升级为机制：父界面在覆盖层非空且按键为 ESC 时，先让覆盖层处理，若覆盖层返回 false 则由父界面调用其 onClose()；或让覆盖层实现一个 `Overlay#onEscape()` 契约方法，父界面无条件调用它。",
  },
  {
    id: "GUI-06",
    path: "gui",
    severity: "high",
    title: "用星平面 emoji 🔒 作为「不可编辑」标记，原版字体渲染不出来",
    where: [
      "ChiseledEnchantingConfigScreen 第 1224 行：`String scopeGlyph = (!editable ? \"\\uD83D\\uDD12\" : \"\") + avail.effectScope().glyph();`",
      "第 1480 行：`lines.add(Component.literal(\"\\uD83D\\uDD12 \")…)`",
    ],
    evidence:
      "同一个枚举 EffectScope 里的三个 glyph 是 ●(U+25CF)、◆(U+25C6)、▲(U+25B2)——都在 BMP，原版 unifont 回退能渲染，注释还特意说明「Dual-coded geometric glyph so badges never rely on color alone」。但 🔒 是 U+1F512，超出 BMP。",
    impact:
      "原版默认字体（含 unifont 回退提供者）不覆盖 U+1F512 → 玩家看到的是缺字方块，恰好出现在「这一项被锁定、你改不了」这个最需要传达清楚的语义上。仓库里已经 shipped `toggle_locked.png`、`btn_plaque_disabled.png`、`micro_btn_disabled.png`，正确资源是现成的。",
    fix: "换成已有的 locked 贴图（在 GUI 里 blit 一个 8×8 图标），或退而用 BMP 内的几何字符（如 ▨ / ⊘ / ●加删除线），与 EffectScope 现有 glyph 家族保持一致。",
    probe: "grep -rn 'uD83D' --include=*.java src/client",
  },
  {
    id: "GUI-07",
    path: "gui",
    severity: "low",
    title: "域热键 1..7 + Rule Trace 8 的映射没有防冲突护栏",
    where: ["ChiseledEnchantingConfigScreen.keyPressed：`int catIdx = key - InputConstants.KEY_1;` 与前置的 `if (key == KEY_8)`"],
    evidence:
      "CategoryId 当前恰好 7 个（BOOKSHELVES / EXPERIENCE_ECONOMY / TOME_DURABILITY / EPIPHANY / CLEANSE_TRANSMUTE / WORLD_LOOT / GENERAL），第 242 行也写着 `CategoryId.values().length + 1; // 7 domains + Rule Trace`，所以今天是自洽的。",
    impact:
      "新增第 8 个配置域时，KEY_8 的判断在 catIdx 之前，新域会被 Rule Trace 静默抢占热键，界面上却照常画出第 9 个 rail tab——一个「看得到点得到但没有快捷键」的域。没有任何编译期或运行期检查。",
    fix: "把热键映射抽成一张显式表（CategoryId → KeyCode），并在启动时断言「表大小 == values().length 且无重复键」；或让 Rule Trace 用一个非数字键（如 TAB / R）。",
  },

  // --------------------------------------------------------------- 05 MIXIN
  {
    id: "MIXIN-01",
    path: "mixin",
    severity: "crit",
    title: "removeItemNoUpdate 覆写把「取走整格」改成了「取走 1 个」——而本 mod 让附魔书堆叠到 64",
    where: [
      "mixin/bookshelf/LockedBookContainerMixin.java：@Override public ItemStack removeItemNoUpdate(int slot) { … return self.removeItem(slot, 1); }",
      "注释标记为 Audit MIXIN-02「closes the removeItemNoUpdate extraction path fail-closed」",
    ],
    evidence:
      "原版 Container#removeItemNoUpdate 的语义是取走该格的**全部**物品且不标记变更（Fabric 官方文档与 NeoForge 文档一致写作 `ContainerHelper.takeItem(this.getItems(), slot)` / “Removes all items from a container slot”）。本 mod 同时通过 DefaultItemComponentEvents 把 Items.ENCHANTED_BOOK 的 MAX_STACK_SIZE 提到 64。",
    impact:
      "任何走 removeItemNoUpdate 的路径（结构模板保存、BlockEntity → ItemStack 序列化取物、第三方 mod 的容器搬运/自动化）在一个装着 64 本附魔书的雕纹书架格上只会拿走 1 本，留下 63 本。更糟的是它调用的是 removeItem，**会**触发 setChanged() 与雕纹书架 blockstate 占用位更新——与方法名承诺的 “NoUpdate” 完全相反，可能导致无谓的方块更新/比较器脉冲。这是一次「审计驱动的修复引入了比原问题更隐蔽的新缺陷」。",
    fix: "改为 `int n = self.getItem(slot).getCount(); return self.removeItem(slot, n);`（保留锁定检查在前）；如果确实需要「不触发 update」的语义，应直接操作底层 items 列表并单独同步 blockstate，而不是复用 removeItem。同时补一条针对堆叠 >1 的回归断言。",
    probe:
      "grep -n -A6 'removeItemNoUpdate' src/main/java/chiseled_enchanting_table/mixin/bookshelf/LockedBookContainerMixin.java",
    versionBound: "该 mixin 之所以存在，是因为 ChiseledBookShelfBlockEntity 继承的是接口默认方法而非自身字节码方法——这一前提本身就是版本敏感的。",
  },
  {
    id: "MIXIN-02",
    path: "mixin",
    severity: "high",
    title: "同一个 AnvilMenu.createResult 被两个 @WrapMethod 包裹，嵌套顺序未声明",
    where: [
      "mixin/anvil/RemoveEnchantMerge.cet$wrapCreateResult",
      "mixin/anvil/RemoveXpCostScaling.cet$trackAnvilSide",
      "chiseled-enchanting-table-port.mixins.json 中两者同列 mixins 数组，无 priority 声明",
    ],
    evidence:
      "一个 wrap 修改 inputSlots 里左槽附魔书的 count（1 ↔ savedLeftCount），另一个 wrap 设置/复位 ThreadLocal 的 client/server side；两者都包裹同一个方法，且 cet$filterSameLevelMerge 会在 wrap 结束后再次读写 resultSlots。",
    impact:
      "MixinExtras 的 wrap 链允许嵌套，但**顺序未显式声明**。顺序反转会改变语义：如果 side-tracking 的 wrap 在外层，count 归一化发生在 ThreadLocal 已复位之后，`calculateIncreasedRepairCost` 可能看到错误的 side；如果 count 归一化在外层，则 filterSameLevelMerge 会在 side 已复位后才跑，读到的是服务端配置。这类 bug 不会崩溃，只会让「同等级书合并拦截」在某些客户端上偶发失效。",
    fix: "合并成**一个** wrap（两处逻辑本来就属于同一件事：让堆叠附魔书在铁砧里表现正确），或显式声明 mixin priority / 用 @WrapOperation 把两者挂到不同的注入点上，让顺序成为可读的、被 CI 检查的事实。",
  },
  {
    id: "MIXIN-03",
    path: "mixin",
    severity: "med",
    title: "原地修改真实输入 stack 的计数，再靠引用同一性恢复",
    where: ["RemoveEnchantMerge.cet$wrapCreateResult：left.setCount(1) … finally { if (current == left && …) current.setCount(savedLeftCount); }"],
    evidence:
      "注释记录了这段代码的历史（原来是 HEAD/RETURN 注入对，异常会永久把玩家的堆叠缩成 1），现在已经是 try/finally + 方法局部变量，比之前好很多。但恢复条件仍是引用同一性 `current == left`。",
    impact:
      "若原版或其它 mod 在 createResult 内**替换**了 0 号槽的内容（setItem 而非 setCount），身份比较失败 → 不恢复。此时 stack 已被替换，风险确实较低；但若替换发生在 setCount(1) 之后、finally 之前，且新 stack 恰好是同一对象（例如 copy 后被放回），恢复逻辑会把计数写到一个语义已经改变的 stack 上。属于「正确性依赖调用方不改槽位」的隐含假设。",
    fix: "不要改真实 stack：用 `left.copyWithCount(1)` 构造一个临时视图，通过 @WrapOperation 把 createResult 内部读取 inputSlots.getItem(0) 的那次调用替换掉。这样原始 stack 全程不被触碰，也不需要 finally 恢复。",
  },
  {
    id: "MIXIN-04",
    path: "mixin",
    severity: "med",
    title: "build.gradle 的「活跃 mixin 清单」列出了两个不存在的类",
    where: [
      "build.gradle sourceSets.main.java 注释：「mixin/enchanting_table/DisableBookEnchanting, AnvilMenuMixin, AnvilScreenMixin, RemoveXpCostScaling」",
      "实际 mixins 配置只有 13 项，源码树里只有 anvil/RemoveEnchantMerge 与 anvil/RemoveXpCostScaling",
    ],
    evidence:
      "`AnvilMenuMixin` / `AnvilScreenMixin` 在 src 与 chiseled-enchanting-table-port.mixins.json 中都不存在；同一段注释还把 RemoveXpCostScaling 与「routes same-level book combines to the table」的行为描述绑在一起，而后者实际由 RemoveEnchantMerge 承担。",
    impact:
      "构建脚本里的这段注释是贡献者判断「哪些 mixin 是活的」的入口，而它与真实配置漂移了。ci_static_checks.py 的 mixin 门只校验「配置里列出的类能否解析」和「注册的 mixin 是否被排除」，不校验「文档/注释提到的类是否存在」——所以门是绿的。",
    fix: "删掉这段手写清单，改为在注释里指向 chiseled-enchanting-table-port.mixins.json 作为唯一真相源；或给 ci_static_checks.py 加一条：扫描 build.gradle / docs 里出现的 `mixin/…` 路径，断言其对应类存在。",
    probe:
      "grep -c 'AnvilMenuMixin\\|AnvilScreenMixin' build.gradle; find src -name 'AnvilMenuMixin.java' -o -name 'AnvilScreenMixin.java' | wc -l",
  },
  {
    id: "MIXIN-05",
    path: "mixin",
    severity: "med",
    title: "任何「有书的雕纹书架」都进入随机刻，缺少收敛策略",
    where: [
      "mixin/bookshelf/AddRandomTick.isRandomlyTicking：任一 SLOT_OCCUPIED_PROPERTIES 为 true 即返回 true",
      "block/ChiseledBookshelfTick.triggerParticleAndSoundIfEnchantedBook",
      "TomeParticleEffects：MAX_ACTIVE_BURSTS=48，每 tick 每个 burst 发 2 个粒子",
    ],
    evidence:
      "scan_volume 是 7×5×7（水平半径 3、垂直半径 2）= 343 格；MAX_SCAN_VOLUME_BLOCKS=4096、MAX_SCAN_HORIZONTAL_RADIUS=8 说明配置允许更大范围。",
    impact:
      "一座满配书库最多 342 个书架全部进入随机刻队列，服务器每 tick 的随机刻抽样里会稳定出现它们；粒子端最坏 ~96 个 S2C 粒子/tick。多人服务器若有多座书库，成本线性叠加。注释说「empty decorative shelves incur zero chunk random-tick cost」是对的，但没有回答「满架时成本是多少」。",
    fix: "把随机刻改为「仅在附魔台 scan_volume 内且该附魔台被打开/附近有玩家时」才生效（可用 BlockEntity 的 tick 而非方块随机刻），或把粒子/音效触发从随机刻迁到附魔台 BlockEntity 的 1 秒实时刷新循环里——WIKI 说界面打开时已经有 1 秒内实时刷新，那条路径本来就在扫描书架。",
  },
  {
    id: "MIXIN-06",
    path: "mixin",
    severity: "med",
    title: "砂轮结果槽被替换成一个只转发三个方法的包装 Slot",
    where: ["mixin/grindstone/GrindstoneBookDepleteMixin.cet$wrapGrindstoneResultSlot（<init> RETURN 处 this.slots.set(RESULT_SLOT, wrapped)）"],
    evidence:
      "包装类只覆写 mayPlace / mayPickup / onTake；未转发 onQuickCraft(ItemStack,ItemStack)、onQuickCraft(ItemStack)、getMaxStackSize、setChanged、mayPlace 之外的委托；并直接写 public 字段 `wrapped.index = delegate.index`。注释提到 Audit MX-05 已经改成从 delegate 派生 container 与 index（不再硬编码槽位 2），这一步是对的。",
    impact:
      "① Shift 点击批量移动时，原版 result slot 的 onQuickCraft 语义丢失（对可堆叠产物尤其明显，而本 mod 的主题正是可堆叠附魔书）。② 任何在构造期捕获原 Slot 引用的 mod 会拿到失效对象。③ getMaxStackSize 未转发 → 结果槽的堆叠上限走默认值而非 delegate 的值。",
    fix: "用 MixinExtras 的 @WrapOperation 精确包裹原版 result slot 的 onTake，而不是替换整个 Slot 实例；若必须替换，则把 Slot 的全部可覆写方法都转发给 delegate（写成一个新的 DelegatingSlot 基类，供 JEI/REI 之外的复用）。",
  },
  {
    id: "MIXIN-07",
    path: "mixin",
    severity: "med",
    title: "村民交易净化挂在 getOffers() RETURN，热路径上无缓存",
    where: [
      "mixin/villager/VillagerInfinitySanitizeMixin → ChiseledEnchantingTable.sanitizeVillagerInfinityOffers",
      "每次调用：registryAccess().lookup(ENCHANTMENT) + 遍历 offers + ItemStack.copy() + EnchantmentHelper.updateEnchantments + new MerchantOffer(…)",
    ],
    evidence:
      "注释解释得很清楚：从 UseEntityCallback 移到 getOffers() RETURN 是为了覆盖「生成时就有 offer」的流浪商人与被其它 mod 程序化打开的交易界面——这个动机是对的。注释只承诺「The rewrite is idempotent」，没有承诺便宜。",
    impact:
      "getOffers() 在村民 AI 与交易刷新路径上是热方法。一个有几十位图书管理员的村庄，每 tick 都可能触发多次完整的 offers 重建（含 ItemStack 拷贝与组件写入）。幂等 ≠ 无分配。",
    fix: "加一层「已净化」标记：净化后在 offer 的 result 上打一个本 mod 的 CUSTOM_DATA 标记（或维护一个 per-villager 的 IdentityHashMap<MerchantOffers, Boolean> 缓存，随 offers 实例变化失效），后续调用直接短路。另外把 lookup(ENCHANTMENT) 提到循环外（现在已经在外层，确认即可）。",
  },

  // ---------------------------------------------------------------- 06 DEAD
  {
    id: "DEAD-01",
    path: "dead",
    severity: "high",
    title: "一个 MC 26.3 专属的 Iris workaround 被搬进了 26.1.2 分支，并硬编码两条贴图路径",
    where: [
      "src/client/…/compat/IrisGlintPreload.java",
      "类注释：「Workaround for an Iris / MC 26.3 hand-render crash … which the new render backend rejects」",
      "硬编码：textures/misc/enchanted_glint_item.png、textures/misc/enchanted_glint_armor.png",
    ],
    evidence:
      "gradle.properties 明确 minecraft_version=26.1.2，并注明「26.3 branch moved to loader 0.19.5 / Fabric API 0.162.0+26.3 / Loom 1.17 because that Minecraft line needs them」。也就是说这段代码的适用版本与本分支的目标版本不是同一个。",
    impact:
      "① 如果该崩溃只存在于 26.3 的新渲染后端，那它在 26.1.2 上是纯开销：注册后每个客户端 tick 都跑一次检查，且永不注销。② 两条贴图路径是版本敏感的 Identifier；若 26.1.2 上路径不同，preload 静默失败（最好情况）或触发 texture manager 告警（最坏情况）。③ `private static boolean warned;` 是非 volatile 的静态可变状态。④ 它让「26.1.2 分支到底同步了多少 26.3 的东西」这件事变得不可判定——SYNC_FROM_26_3_REPORT.md 是唯一的线索。",
    fix: "要么删掉（并在 docs/reports/SYNC_FROM_26_3_REPORT.md 里记一条「已评估、26.1.2 不需要」），要么加运行时守卫：`FabricLoader.getInstance().isModLoaded(\"iris\") && SharedConstants.getCurrentVersion().id().equals(\"26.3\")`；贴图路径改为通过 TextureAtlas/已知常量查询而不是字面量，并在解析失败时降级为 no-op + 一次性 warn。",
    probe: "grep -n '26\\.3' src/client/java/chiseled_enchanting_table/compat/IrisGlintPreload.java",
  },
  {
    id: "DEAD-02",
    path: "dead",
    severity: "low",
    title: "空的 EntityRegistry.init()、无人实现的 shim 方法、以及只被列表引用的 11 个 probe 常量",
    where: [
      "EntityRegistry.init() { }（见 API-03）",
      "com.terraformersmc.modmenu.api.ModMenuApi#attachModpackBadges（无实现者，真实 API 中亦不存在）",
      "EnchantingProtocol.REVISION_5..15_COST_TYPE：仅被 LEGACY_COST_PROBES 引用，从不注册解码器",
    ],
    evidence:
      "probe 常量「只查询不解码」是**刻意设计**（注释写明：绝不在 legacy channel 上注册解码器，因为老服务器可能在客户端 JOIN 回调能断开它之前就发出 join-time 包）。所以这不是缺陷，而是 11 个 public 常量的可见性过宽。",
    impact:
      "真正的成本是认知负担：新贡献者看到 11 个 public 的 CustomPacketPayload.Type 常量，无法从类型系统判断哪些能解码、哪些只能探测，只能靠注释。而 attachModpackBadges 是纯粹的死重量加误导。",
    fix: "把 probe 常量降为 package-private，只暴露 LEGACY_COST_PROBES / LEGACY_APPLY_PROBES 两个列表（如果 NET-01 的生成式重构落地，这些常量会自然消失）；删除 attachModpackBadges；处理 API-03。",
  },
  {
    id: "DEAD-03",
    path: "dead",
    severity: "med",
    title: "一个 public 重载只在生产路径之外被使用，却携带与主路径不同的真相源",
    where: [
      "InscriptionRitualMechanics.computeApplicabilityFactor(Identifier, int supportedItemCount, int anvilWeight)",
      "生产路径 EnchantmentApplication:159 用的是 (Identifier, Holder<Enchantment>) 重载",
    ],
    evidence:
      "3 参重载的实现是 `return computeApplicabilityFactor(id, count, weight, HIGH_APPLICABILITY_IDS.contains(id));`——完全绕过 #chiseled_enchanting_table:broad_applicability 标签。",
    impact:
      "见 COUP-01：这是一个「看起来能用、结果不同」的公共入口。测试与第三方（以及未来的 JEI/REI 成本预览）如果调它，会得到与真实游戏不同的普适度系数，而两边都不会报错。",
    fix: "删掉 3 参 public 重载，或让它接受一个 boolean broadTagged 参数由调用方显式给出（现在的 4 参 private 版本已经是这个形状）；同时删除 HIGH_APPLICABILITY_IDS（COUP-01）。",
  },

  // ------------------------------------------------------------ 07 COUPLING
  {
    id: "COUP-01",
    path: "coupling",
    severity: "high",
    title: "双真相源：硬编码的 10 个魔咒 ID 与数据包标签内容重叠但不相等",
    where: [
      "InscriptionRitualMechanics.HIGH_APPLICABILITY_IDS = Set.of(protection, sharpness, efficiency, fortune, looting, power, silk_touch, wind_burst, breach, density)",
      "data/…/tags/enchantment/broad_applicability.json = 同 10 项 + unbreaking + mending + #minecraft:curse",
      "computeApplicabilityFactor 的 keystone 判定：`broadApplicabilityTagged || HIGH_APPLICABILITY_IDS.contains(enchantmentId)`",
    ],
    evidence:
      "两份名单在 10 个 ID 上重合，标签多出 unbreaking / mending / curse 三项——而 unbreaking 与 mending 在 keystone 分支里另有专门的 1.32 / 1.55 系数，所以「多出三项」看起来像是有意为之，实际上是因为 `||` 把硬编码集合又并了回来。",
    impact:
      "数据包作者从标签里**删掉**某个魔咒（例如想让 protection 不再享受 keystone 加成），只要它还在 HIGH_APPLICABILITY_IDS 里，keystone 1.20 依旧生效。「数据驱动」的承诺在这里不成立，而且失效方向是安静的：没有任何日志说明「这个 ID 同时来自两个源」。仓库为 BundledDefaults 建立了「JSON 是唯一真相源 + CI 逐字节校验」的纪律，却没有把同一纪律应用到这份硬编码名单。",
    fix: "删除 HIGH_APPLICABILITY_IDS，keystone 判定只查标签；unbreaking/mending 的专门系数改成标签内的显式分级（例如 broad_applicability / keystone_major / keystone_minor 三个标签，或 JSON 里的 id→系数映射）。若为了兼容必须保留硬编码集合，则启动时打一次 diff 日志，明确列出「同时出现在两个源」与「只出现在一个源」的 ID。",
    probe:
      "python3 -c \"import json;print(len(set(json.load(open('src/main/resources/data/chiseled_enchanting_table/tags/enchantment/broad_applicability.json'))['values'])))\"",
  },
  {
    id: "COUP-02",
    path: "coupling",
    severity: "high",
    title: "LibraryResonance.Config 是 50 个位置参数的 record（22 个 double + 20 个 int）",
    where: ["mechanics/resonance/LibraryResonance.java 第 47–92 行的 record header，以及至少 4 处按位置传参的构造点"],
    evidence:
      "实测组件构成：double 22、int 20、boolean 4、List<Integer> 1、ConsumptionMode 1、DepleteBehavior 1、ScapegoatPricing 1 = 50。相邻参数大量同类型，例如 epiphanyTier2ScoreDivisor / epiphanyTier2MasteryBonus / epiphanyTierPlusMaxProb / epiphanyTierPlusScoreDivisor / epiphanyTierPlusMasteryBonus 连续五个 double。",
    impact:
      "把任意两个相邻 double 或 int 传反，编译通过、测试（如果不逐字段断言）通过、游戏照跑，只是平衡数值悄悄变了。这类缺陷的表现形式是「玩家说某个数值感觉不对」，几乎无法定位。50 个位置参数也让任何新增旋钮变成一次全仓库的构造点改动。",
    fix: "library_resonance.json 本来就是分组的（wooden_bookshelves / chiseled_mastery / tome_pages / wild_book_wear / epiphany_affinity / ritual / ritual.wait_curve / crossline_slip）——Java 侧却把它拍平了。按同样的分组拆成嵌套 record，并给整个 Config 写一个 Codec（RecordCodecBuilder 自带字段名，天然消除位置错误），fromJson 改为 codec.parse。这一步同时能删掉 Config.intOr / Config.doubleOr 这些手写 JSON 取值辅助。",
  },
  {
    id: "COUP-03",
    path: "coupling",
    severity: "high",
    title: "一个配置项成了四个不相关旋钮的隐式乘数，且缩放不对称；木架折扣不受总上限约束",
    where: [
      "ChiseledEnchantingTableData.applyRuntimeConfig 第 900–930 行",
      "masteryScale = totalDisc > defaultTotalDisc ? totalDisc/defaultTotalDisc : 1.0",
      "globalDiscCap = min(totalDisc, round(lr.maxGlobalMasteryDiscountPercent() * masteryScale))",
      "specDiscCap = min(totalDisc, round(lr.maxSpecificEnchantBonusPercent() * masteryScale))",
      "globalMasteryMultiplier() * masteryScale",
      "woodDisc = cfg.maxWoodenDiscountPercent()（未被 totalDisc 钳制）",
    ],
    evidence:
      "默认 totalDisc=40、defaultTotalDisc=40 → masteryScale=1.0，今天一切正常。把 max_total_xp_discount_percent 改成 60：globalDiscCap 20→30、specDiscCap 15→23、globalMasteryMultiplier 1.25→1.875。改成 10：masteryScale 仍是 1.0（不上调就不下调），globalDiscCap=min(10,20)=10、specDiscCap=min(10,15)=10，而 woodDisc 保持 15 > totalDisc 10。",
    impact:
      "① 隐式乘数：数据包作者改「总上限」时，不会预期「全局掌握倍率」也跟着 +50%。四个旋钮之间没有一处文档说明这层关系。② 不对称：上调会放大、下调不缩回，导致同一份数据包在不同方向的直觉完全相反。③ woodDisc 不参与钳制：max_wooden_discount_percent > max_total_xp_discount_percent 时，木架轨道可以突破「总上限」，而 GUI/JEI/REI/grimoire 五处显示的都是 maxTotalXpDiscountPercent() → 显示 −10%、实际扣 −15%。④ 代码注释自己记录了同一类 bug 曾经真实发生（1.0.3 Classic 的「额外 −15%（共 −0%）」），当时的修法是「在源头把子封顶全部清零」——那是针对一个具体 profile 的补丁，没有解决「同一个折扣数字存在于四处」的结构问题。",
    fix: "删掉隐式 masteryScale，要求数据包显式给出每个子上限，并在 fromJson 里校验不变式：woodDisc ≤ totalDisc、globalDiscCap ≤ totalDisc、baseDiscCap ≤ totalDisc、specDiscCap ≤ totalDisc；任一违反 → warn + 钳到 totalDisc（钳的是 woodDisc，而不是放过它）。若确实需要「总上限联动」，把它做成一个显式布尔开关 `scale_subcaps_with_total`，默认 false。",
  },
  {
    id: "COUP-04",
    path: "coupling",
    severity: "med",
    title: "四个互不解释的「书架天花板」：38 / 42 / 45，而扫描域理论上限是 342",
    where: [
      "shelf_gates.json：direct_upgrade_gates.max_bookshelves = 38、two_level_max_bookshelves = 22",
      "library_resonance.json：wooden_bookshelves.max_discount_bookshelves = 45、chiseled_mastery.tome_regen_tier1_shelves = 38、tome_regen_tier2_shelves = 42、crossline_shelf_tier3_count = 42、ritual.shelf_load_reference = 42.0",
      "BookshelfProgression.MAX_SCAN_VOLUME_BLOCKS = 4096、MAX_SCAN_HORIZONTAL_RADIUS = 8",
    ],
    evidence:
      "README 只说「along 0..38 shelves」；WIKI 在三节里分别给出 38（直附满级）、42（温养 tier2 / crossline tier3 / 负载参考）、45（木架减免满额）。7×5×7 = 343 格，去掉附魔台本身最多 342 个书架——三个数字都远未触及物理上限。",
    impact:
      "这不是 bug，是**缺少一处解释**。玩家/整合包作者面对三个天花板时无法判断：45 是不是笔误？42 和 38 谁先到达？把 max_discount_bookshelves 调到 38 会破坏什么？文档分散在三个小节，没有任何一处并排说明。COUP-03 的隐式乘数又恰好以其中一个（40）为基准，进一步放大了理解成本。",
    fix: "在 WIKI 增加一张「书架阈值总表」：阈值 / 作用机制 / 出处 JSON 键 / 到达难度，并说明三档为何不同（例如 38 = 直附满级锚点，42 = 大书库冲刺档，45 = 减免满额，刻意让减免最后到达以避免「满减免 + 满档」同时出现）。同时把这张表由脚本从 JSON 渲染，避免第四份手抄副本。",
  },
  {
    id: "COUP-05",
    path: "coupling",
    severity: "med",
    title: "双轨书库的 W/C 划分依赖原版标签的当前内容，而不是本 mod 的强制约束",
    where: [
      "data/chiseled_enchanting_table/tags/block/regular_bookshelves.json：values = [\"#minecraft:enchantment_power_provider\"]（全部）",
      "docs/WIKI.md 第 83 行断言：「minecraft:bookshelf 及 #chiseled_enchanting_table:regular_bookshelves（**不含任何雕纹书架**）」",
    ],
    evidence:
      "regular_bookshelves 标签的内容 100% 等于原版 enchantment_power_provider。「不含雕纹书架」是原版标签**当前**内容的偶然结果，代码里没有一条排除规则。",
    impact:
      "整套「普通书架 W / 雕纹书架 C」双轨设计、W 的直附曲线、C 的母本温养、以及 S_广义 = W + C 的负载计算，都建立在「W 与 C 不相交」这个前提上。一旦 Mojang 在未来版本把 chiseled_bookshelf 加入 enchantment_power_provider（这在语义上完全合理——雕纹书架本来就装着书），或者任何数据包这么做，W 与 C 会同时计入同一个方块，双轨机制静默坍塌：一个雕纹书架既提供直附档位又提供母本温养，而且没有任何告警。",
    fix: "在 regular_bookshelves 的判定里显式排除 `Blocks.CHISELED_BOOKSHELF`（或排除本 mod 认定的「书架容器类」方块集合），把「W ∩ C = ∅」从偶然事实变成代码保证；同时在启动时做一次自检：若某方块同时在两个集合里，warn 并列出。WIKI 的断言应改为「本 mod 强制排除雕纹书架」而不是描述原版标签内容。",
  },
  {
    id: "COUP-06",
    path: "coupling",
    severity: "med",
    title: "god-class 拆分只搬走了 networking，四个巨型文件仍在 2000–3100 行",
    where: [
      "menu/ChiseledEnchantingTableScreenHandler.java — 3088 行",
      "data/ChiseledEnchantingTableData.java — 3065 行",
      "client/gui/ChiseledEnchantingTableScreen.java — 2406 行",
      "client/gui/config/ChiseledEnchantingConfigScreen.java — 2191 行",
      "config/ModRuntimeConfig.java — 1887 行",
    ],
    evidence:
      "EnchantingNetworking 的类注释写明它是「Extracted verbatim from ChiseledEnchantingTableScreenHandler#init() (god-class split, 2026-10-24 audit)」——拆分方向是对的，但只完成了一层。全仓库 44,031 行 Java，前 5 个文件占 12,637 行（28.7%）。",
    impact:
      "ScreenHandler 同时承担：容器/槽位、定价解析、仪式队列、顿悟状态、冻结/重roll、净化页解锁、准入队列、live shelf 同步。COUP-03 那段「一个配置项驱动四个旋钮」的逻辑就住在 Data 类里而不是 resonance 类里，正是这种边界模糊的结果。任何一次改动的爆炸半径都很大，而测试无法覆盖 client 源集（见怀疑页第 2 条）。",
    fix: "按已有命名继续拆：MenuPricing / RitualQueue / EpiphanyState / CleanseUnlock / ShelfScanner 五个协作对象，ScreenHandler 只保留槽位与派发。Data 类里的 applyRuntimeConfig 那段折扣重算逻辑（COUP-03）应该搬进 LibraryResonance，与它的 Config 住在一起。",
  },
  {
    id: "COUP-07",
    path: "coupling",
    severity: "high",
    title: "雕纹书架粒子位置硬编码槽位几何，且完全忽略方块朝向",
    where: [
      "mechanics/resonance/TomeParticleEffects.burst：x = shelfPos.getX() + 0.1875 + (s % 3) * 0.3125；y = shelfPos.getY() + (s < 3 ? 0.72 : 0.28)；z = shelfPos.getZ() + 0.5；int s = Math.max(0, Math.min(5, slot))",
      "注释：「Book position inside its shelf: slot 0..5 maps to the 3x2 chiseled-shelf grid」",
    ],
    evidence:
      "计算里没有任何一处读取 BlockState 的 FACING 属性；z 固定 +0.5，x/y 固定按 3×2 网格推算。原版雕纹书架有按朝向计算的槽位命中向量（ChiseledBookShelfBlock 一侧的 hit-slot / SLOT_OCCUPIED_PROPERTIES 配套逻辑），本 mod 的 AddRandomTick 已经引用了 SLOT_OCCUPIED_PROPERTIES，说明这些常量是可达的。",
    impact:
      "四个水平朝向中只有一个（+Z 面）会得到正确的粒子位置；其余三个朝向的粒子会出现在方块的错误一侧、甚至方块内部或空气中。玩家看到的是「锁定/充能特效从书架背面冒出来」，而这正是母本温养系统唯一的空间反馈。硬编码的 0.1875 / 0.3125 / 0.72 / 0.28 也意味着原版一旦调整书架模型或槽位布局，这些数字全部失效且不会报错。",
    fix: "改用原版按 facing 计算的槽位向量（或自己按 FACING 做一次坐标旋转：先算 +Z 面局部坐标，再用 facing 的旋转变换到世界坐标）；四个几何常数抽成命名常量并注明它们对应 3×2 网格的哪个边距，最好由 BlockState 属性推导而非字面量。",
  },

  // --------------------------------------------------------------- 08 BALANCE
  {
    id: "BAL-01",
    path: "balance",
    severity: "med",
    title: "决定精华返还的稀有度倍率是四个不可调的硬编码常数",
    where: [
      "mechanics/enchanting/DisenchantmentApplication.rarityMultiplier：`Math.min(1.45, Math.max(1.00, 1.0 + 0.18 * Math.log(anvilCost)))`，treasure 再 `*= 1.15`",
      "同类：CONSERVATION_SAFETY_MARGIN_POINTS = 5",
    ],
    evidence:
      "周边所有旋钮（wear、waiver、mastery、crossline、ritual、wait_curve）都在 library_resonance.json 里，由 BundledDefaults 生成、CI 逐字节校验；唯独 rarityMultiplier 的 1.45 / 1.00 / 0.18 / 1.15 与守恒安全边际 5 是 Java 字面量。",
    impact:
      "守恒等式 `V[k] − V[j] ≤ Cost_min(j→k)` 是 README 的核心卖点，而它的两端都受这些常数影响：V 由 essencePotential（吃 rarityMultiplier）算出，Cost_min 由价格表算出。数据包作者调了价格表却发现守恒边界不动，因为另一半在 Java 里。安全边际 5 点更是「保守多少」的唯一旋钮，却不可配置、不进 payload 同步、不在 GUI 配置里出现。",
    fix: "把 rarityMultiplier 的四个常数与 CONSERVATION_SAFETY_MARGIN_POINTS 迁进 library_resonance.json 的一个新段（例如 `essence_valuation`），纳入 BundledDefaults 生成与 CI 校验；GUI 配置的 EXPERIENCE_ECONOMY 域里给它们两个条目。",
  },
  {
    id: "BAL-02",
    path: "balance",
    severity: "med",
    title: "普适度的「物品广度」参考值 24 硬编码，会随原版新增可附魔物品而饱和",
    where: ["InscriptionRitualMechanics.computeApplicabilityFactor：`1.0 + 0.42 * Mth.clamp((supportedItemCount - 1) / 24.0, 0.0, 1.0)`"],
    evidence:
      "同时存在一个数据驱动的邻居：BundledDefaults.CROSSLINE_BROAD_APPLICABILITY_MIN_ITEMS = 12（来自 library_resonance.json 的 crossline_slip 段）——说明「按支持物品数打分」这件事本来就有可配置的先例。",
    impact:
      "24 是「一个魔咒能附到多少种物品算满广度」的参考值。原版每增加一类可附魔物品（26.x 线已经出现过锤、矛这类新工具），supportedItems().size() 的分布就整体上移，breadth 项更早撞到 1.42 的上限，普适度区分度逐渐消失——而且是**跨版本静默**消失，因为 24 不在任何 JSON 里。对整合包（可能新增几十种可附魔物品）影响更大。",
    fix: "把 24 提为 `applicability_item_breadth_reference`（进 library_resonance.json + BundledDefaults），并考虑改成按注册表统计的相对值（例如所有魔咒 supportedItems().size() 的中位数或 P90），让它随版本/整合包自适应；至少在启动时打一条日志输出当前注册表下的实际分布，方便校准。",
  },
  {
    id: "BAL-03",
    path: "balance",
    severity: "low",
    title: "keystone 与 rarityBoost 的档位系数全部硬编码，与 BundledDefaults 纪律相反",
    where: [
      "computeApplicabilityFactor：keystone 1.55（infinity/mending）、1.32（unbreaking）、1.20（broad）；总钳位 [1.0, 2.35]",
      "rarityBoost：anvilWeight ≤1 → 1.18、≤2 → 1.12、≤5 → 1.05、else 1.0",
    ],
    evidence:
      "infinity / mending / unbreaking 三个 ID 也是字面量常量（MasterTomeWear.INFINITY_ENCHANTMENT_ID、MENDING_ID、UNBREAKING_ID），而不是标签——尽管仓库已经有 wear_immune / crossline_excluded 两个标签在用同样的语义。",
    impact:
      "普适度系数直接乘进仪式等待时长（computeSingleEnchantWaitTicks 的入参），也就是玩家实际要等多久。一个「等多久」的核心曲线，其四个档位系数与三个魔咒身份都不可配置、不可见、不同步。整合包想让 mending 不再享受 1.55 的 keystone 加成，唯一办法是改代码。",
    fix: "keystone 分级改用标签（keystone_major / keystone_minor / broad）或 JSON 里的 id→系数映射；四个档位系数与 [1.0, 2.35] 钳位进 library_resonance.json 的 ritual 段。",
  },
  {
    id: "BAL-04",
    path: "balance",
    severity: "info",
    title: "顿悟概率曲线的参数关系需要一句解释：tier+ 的上限低于 tier2",
    where: [
      "treasure_epiphany.json：base_chance 0.28、chance_per_extra_bookshelf 0.008、chance_per_master_tome 0.022、max_chance 0.90、min_regular_bookshelves 32、cycle_ticks 12000、freeze_duration_ticks 24000、max_freeze_ticks 72000、freeze_xp_levels 1、reroll_xp_levels 2",
      "library_resonance.json：epiphany_tier2_max_prob 0.65、epiphany_tier_plus_max_prob 0.5（后者更低）",
    ],
    evidence:
      "32 架门槛处 extra=0 → 0.28；每本母本 +0.022，约 28 本母本即封顶 0.90（0.28+28×0.022=0.896）。冻结 20 分钟只要 1 级经验 + 一份材料选项（含 2× 哭泣黑曜石），重roll 2 级；刷新周期 10 分钟，冻结上限 60 分钟。",
    impact:
      "两点值得作者确认而非修改：① tier_plus 的 max_prob（0.5）低于 tier2（0.65），若二者作用在同一个概率量上则与「更高档更强」的直觉相反；若作用在不同量上（例如 tier+ 是「多出一个额外槽」的概率），JSON 里没有任何注释说明，library_resonance.json 只有一条 `_epiphany_tier_plus_score_divisor_note` 解释了 divisor 而没解释 max_prob。② 冻结/重roll 的价格（1–2 级）与宝藏本身的价格（18–28 级）差一个数量级，配合 10 分钟周期与 60 分钟冻结上限，理性策略是「反复冻结 + 重roll 刷到想要的宝藏」，这会让 0.90 的概率上限形同虚设。",
    fix: "给两个 max_prob 各加一条 `_note`（仓库已经有这个惯例）说明它们作用在哪个量上；若确认冻结/重roll 应该更贵，把 freeze_xp_levels 与 reroll_xp_levels 提进与 default_xp_levels 同一量级（例如 4 / 6），或让重roll 消耗随本周期已重roll 次数递增。",
  },
  {
    id: "BAL-05",
    path: "balance",
    severity: "med",
    title: "村民 Infinity 净化把结果换成 Power I，但保留原价、原经验、原需求",
    where: ["ChiseledEnchantingTable.sanitizeVillagerInfinityOffers：new MerchantOffer(getItemCostA, getItemCostB, sanitizedResult, getUses, getMaxUses, getXp, getPriceMultiplier, getDemand) + setSpecialPriceDiff"],
    evidence:
      "注释解释动机很充分：从 UseEntityCallback 移到 getOffers() 是为了覆盖流浪商人与被程序化打开的交易界面；「Replace Infinity with Power I when that leaves zero enchantments」是为了不让 offer 变成一本空书。",
    impact:
      "玩家付出的是 Infinity 书的绿宝石价（原版图书管理员 Infinity 通常 20+ 绿宝石），拿到的是一本 Power I。除错动机正确外，经济上是单方面没收，而界面上没有任何提示说明「这本原本会是 Infinity」。WIKI 里也找不到这一条（第 190 行只讲了本 mod 自己的图书管理员要价曲线）。",
    fix: "两个方向选一个：① 让替换后的 offer 同时把价格/经验按 Power I 的市场价重算（保留 priceMultiplier 与 demand 的玩家个体差异即可）；② 保留原价但在结果的 lore 里加一条可翻译说明（「这本贸易已被雕纹附魔台规则改写」），并写进 WIKI 与 advancement 描述。当前状态是「机制生效、信息缺失」。",
  },
  {
    id: "BAL-GOOD",
    path: "balance",
    severity: "good",
    title: "核心曲线的「文档 ↔ 数据 ↔ 实现」三方核对全部通过",
    where: [
      "直附阶梯：WIKI 第 92–97 行的 round(38·((L−1)/(M−1))^1.25) 与 BookshelfProgression.requiredBookshelvesForDirectTier 一致",
      "M=5 → [0,7,16,27,38]、M=4 → [0,10,23,38]、M=3 → [0,16,38]：逐项复算通过",
      "HALF_CEIL：`(clampedMax + 1) / 2` 等价于 ceil(M/2)，与 README 的 ceil(maxLevel/2) 一致",
      "木架减免：WIKI 第 99 行 round(1% + 14%·clamp((W−3)/42)) 与 min_discount_bookshelves=3 / max=45 / max_percent=15 一致",
      "母本温养：7200/3600/1200 秒 ↔ 6/3/1 游戏日（1 游戏日 = 24000 tick = 1200 秒）↔ 72000/36000/… tick，WIKI 第 109–111 行全部对得上",
      "仪式等待：max_single_wait_seconds 300 = 5 分钟 = 6000 tick，与 WIKI 第 115 行一致",
    ],
    evidence:
      "本次审计对 WIKI 里所有可核对的数值公式做了独立复算（含 (3/4)^1.25 = 0.69797 → ×38 = 26.52 → round 27 这一步），未发现任何一处与 shipped JSON 或 Java 实现矛盾。",
    impact:
      "这一层的文档质量明显高于同类项目：公式写成了可复算的形式而不是模糊描述，JSON 键名与文档术语基本对应，BundledDefaults 的生成器 + CI 逐字节校验真正消除了「Java DEFAULT 与 JSON 漂移」这一类缺陷。审计中发现的数值问题（COUP-03 / BAL-01..03）全部集中在**未被这套纪律覆盖的角落**，而不是纪律本身失效。",
    fix: "把这条纪律扩展到 BAL-01/02/03 与 CODEC-06 列出的硬编码区，数值层的可信度就能从「核心曲线可信」升级为「全量可信」。",
  },
];

export const REPO_META = {
  name: "chiseled-enchanting-table-26.1.2-source",
  branch: "arena/b99a37c2-chiseled-enchanting-table-26-1",
  owner: "q14433686-arch",
  upstream: "Sacramentix/chiseled-enchanting-table",
  modVersion: "1.1.0",
  mcVersion: "26.1.2",
  loader: "Fabric Loader >=0.19.3",
  fabricApi: "0.151.0+26.1.2",
  java: ">=25",
  protocolRevision: "26_1_2_revision_16",
  locJava: 44031,
  javaFiles: 108,
  jsonFiles: 86,
  mixins: 13,
  langKeys: 959,
  langFiles: 11,
  advancements: 29,
  configRecordComponents: 50,
  top5Share: "28.7%",
};

export function findingsByPath(p: PathKey) {
  return FINDINGS.filter((f) => f.path === p);
}

export function countBySeverity() {
  const out: Record<Severity, number> = {
    crit: 0,
    high: 0,
    med: 0,
    low: 0,
    info: 0,
    good: 0,
  };
  for (const f of FINDINGS) out[f.severity]++;
  return out;
}
