export interface LangRow {
  code: string;
  name: string;
  keys: number;
  identical: number;
  translated: number;
  note: string;
}

/**
 * Measured on the branch snapshot: for every one of the 959 keys, compare the
 * value in each locale against en_us.json byte-for-byte. "identical" = the value
 * is the English string, i.e. the locale file declares the key but does not
 * translate it. Vanilla's per-key fallback therefore never fires.
 */
export const LANG_TABLE: LangRow[] = [
  { code: "zh_cn", name: "简体中文", keys: 959, identical: 0, translated: 959, note: "唯一 100% 翻译；口语化质量高（「自己挑附魔，不再看脸」）" },
  { code: "zh_tw", name: "繁體中文", keys: 959, identical: 44, translated: 915, note: "95.4% 翻译；未译的 44 条含 JEI 说明、秘典 ch3/diag、母本面板 4 条" },
  { code: "ja_jp", name: "日本語", keys: 959, identical: 540, translated: 419, note: "43.7% 翻译" },
  { code: "ko_kr", name: "한국어", keys: 959, identical: 575, translated: 384, note: "40.1% 翻译" },
  { code: "ru_ru", name: "Русский", keys: 959, identical: 660, translated: 299, note: "31.2% 翻译" },
  { code: "es_es", name: "Español", keys: 959, identical: 661, translated: 298, note: "31.1% 翻译" },
  { code: "de_de", name: "Deutsch", keys: 959, identical: 662, translated: 297, note: "31.0% 翻译" },
  { code: "fr_fr", name: "Français", keys: 959, identical: 662, translated: 297, note: "31.0% 翻译" },
  { code: "pt_br", name: "Português (BR)", keys: 959, identical: 665, translated: 294, note: "30.7% 翻译" },
  { code: "it_it", name: "Italiano", keys: 959, identical: 671, translated: 288, note: "30.0% 翻译" },
];

export const ZH_TW_UNTRANSLATED_SAMPLE = [
  "jei.chiseled_enchanting_table.info.station",
  "jei.chiseled_enchanting_table.info.bookshelf",
  "gui.chiseled_enchanting_table.grimoire.ch3.t3",
  "gui.chiseled_enchanting_table.grimoire.diag.ch5_r3",
  "gui.chiseled_enchanting_table.tomes.panel_regen_gap",
  "gui.chiseled_enchanting_table.tomes.panel_regen_max",
  "gui.chiseled_enchanting_table.tomes.panel_shelves",
  "gui.chiseled_enchanting_table.tomes.tip_unlock",
];

export interface TextFinding {
  id: string;
  axis: "readability" | "accuracy" | "identity";
  severity: "crit" | "high" | "med" | "low" | "good";
  layer: string;
  title: string;
  detail: string;
  evidence: string;
  fix: string;
}

export const AXIS_META = {
  readability: {
    zh: "易读性",
    en: "Readability",
    color: "#43c59e",
    verdict: "合格，仍可再进一步",
    desc: "句子是否好读、术语是否可扫读、长说明是否分层、有没有把机制讲清楚。",
  },
  accuracy: {
    zh: "准确性",
    en: "Accuracy",
    color: "#ffa24d",
    verdict: "存在可验证的错项",
    desc: "文本说的事与代码/数据实际做的事是否一致，数字是否会腐坏。",
  },
  identity: {
    zh: "同一性",
    en: "Consistency",
    color: "#a46ee5",
    verdict: "最需要投入的一条轴",
    desc: "同一个东西在 README / WIKI / GUI / JEI / 配置界面里是否叫同一个名字、用同一种写法。",
  },
} as const;

export const TEXT_FINDINGS: TextFinding[] = [
  {
    id: "TXT-01",
    axis: "accuracy",
    severity: "crit",
    layer: "游戏内文本 · 11 个 lang 文件",
    title: "「11 种语言」的说法与实际内容不符：9 个语言包有 56%–70% 的条目就是英文原文",
    detail:
      "README 写「In-game text ships in eleven languages … (missing keys fall back to English per key, as in vanilla)」，fabric.mod.json 写「localized across all 11 shipped languages」，CI 的 lang 门输出「lang parity ok (959 keys across en_us + 10 language(s))」。逐条实测后：de/es/fr/it/pt/ru 六个语言包约 69% 的条目与 en_us 逐字节相同，ja/ko 约 56%–60%。真正的完成度是「2 种语言（zh_cn 100%、zh_tw 95.4%）+ 9 个部分翻译的语言包」。",
    evidence:
      "关键机制：因为这些 key **存在**且值**非空**，vanilla 的 per-key 回退永远不会触发。玩家不会看到「缺翻译」的信号，只会看到英文——这比缺 key 更难被发现，也更难被贡献者认领。而 ci_static_checks.py 第 220 行明确写着「A translated value that is byte-identical to English is allowed (some strings really are the same), so only an empty value is treated as an unfinished translation」——门是绿的，绿灯的语义与 README 的宣称不是同一件事。",
    fix:
      "两步，都很便宜：① 把 lang 门从「key parity」升级为「key parity + 非英文比例阈值 + 占位符同构」，纯 Python、零依赖，能立刻把这条变成红灯（阈值可设为 warn 而非 fail，先让它可见）；② README 的措辞改为「ships 11 locale files; zh_CN/zh_TW complete, the other nine partially translated (30–44%) — contributions welcome」，并在 docs/ 下加一张翻译进度表由脚本生成。宣称与现状对齐之后，这条就不再是准确性问题，而变成一张公开的招募表。",
  },
  {
    id: "TXT-02",
    axis: "accuracy",
    severity: "high",
    layer: "游戏内文本 · JEI/REI 说明",
    title: "同一条 JEI 说明在 en_us 与 zh_cn 里讲的是两件不同的事，且占位符不同构",
    detail:
      "key = jei.chiseled_enchanting_table.info.station。en_us 用了 %1$s、%2$s、%3$s 三个参数，结构是「Targeted Enchanting Table 总述 + 木质书架条目 + 雕纹书架条目 + Cleanse Tab 条目」；zh_cn 只用了 %1$s、%2$s，结构是「一句口号 + 雕纹书架条目 + 升级折抵说明 + 去除附魔退款说明」。",
    evidence:
      "具体差异：① 第三个参数（Treasure Epiphany 的书架门槛 %3$s）在中文里被整条丢弃——Java 的 Formatter 对未使用的定位参数不报错，所以这是静默的；② 中文少了「木质书架」与「Cleanse Tab」两条，多了「升级折抵」与「退款」两条；③ 中文的口号「自己挑附魔，不再看脸」在英文里没有对应。结果是：装了 JEI 的中文玩家与英文玩家读到的是两份不同完整度的说明，而两边都读不出自己少了什么。",
    fix:
      "把这条 key 拆成语义单元（一个总述 + N 个 bullet），每个 bullet 一个独立 key，参数个数在各语言间强制一致；给 lang 门加一条「占位符集合必须与 en_us 同构」的断言（正则提取 %[0-9]*\\$?[sdf] 后比较集合，纯 Python 十行）。口号这类「不承载信息」的句子应该独立成 key，不要与信息条目混在同一条里。",
  },
  {
    id: "TXT-03",
    axis: "identity",
    severity: "high",
    layer: "跨层 · README / WIKI / 物品 ID / JEI",
    title: "一个物品最多有 3 个英文名 + 2 个中文名，JEI 搜索与 Wiki 检索都会因此漏掉它",
    detail:
      "四组实例：① Depleted Tome = 「褪魔残卷」，各处基本一致；② Master Tome = 「母本」（WIKI）/ 「Template Books」（en_us 的 JEI 文案）/ `master_tome`（配置键）——同一物三个名；③ 秘典 = 「纂刻秘典 / Chiseled Grimoire」（README Concept 段）/ 「Arcane Grimoire」（物品 ID arcane_grimoire、类名 ArcaneGrimoireItem/Screen）/ 「秘典」（WIKI）；④ 催化剂 = 「Arcane Synthesis Crystal」（README Concept 段）/ 「秘法凝晶」（WIKI 与 gradle.properties 的 Arcane Condensate）/ `arcane_catalyst`（物品 ID）。",
    evidence:
      "README 的 Concept 段在同一段落里先后用了 Chiseled Grimoire、Depleted Tome、Cleansing Grit、Arcane Synthesis Crystal 四个名字，其中两个与物品 ID 不一致；WIKI 用「秘法凝晶」，gradle.properties 的版本说明用「Arcane Condensate」，而物品注册名是 arcane_catalyst。配置界面的规则溯源卡片（ChiseledEnchantingConfigScreen 第 1775–1778 行）又是另一套术语。",
    fix:
      "建立一张 docs/GLOSSARY.md 术语表：canonical 英文名 / canonical 中文名 / 物品或配置 ID / 允许的别名 / 禁止的别名，作为唯一真相源。然后：① lang 文件里的所有出现改为 canonical；② README/WIKI 由脚本检查是否出现「禁止的别名」；③ JEI/REI 的搜索关键词里显式加入别名（这样玩家搜 Template Book 也能找到母本）。这张表同时能解决 TXT-10 的写法不统一。",
  },
  {
    id: "TXT-04",
    axis: "accuracy",
    severity: "med",
    layer: "文档 · fabric.mod.json",
    title: "port_notes 说「complete 10-advancement progression」，仓库里有 29 个 advancement",
    detail:
      "fabric.mod.json 的 custom[\"chiseled_enchanting_table:port_notes\"] 写「complete 10-advancement progression localized across all 11 shipped languages」。实际 data/…/advancement/ 下有 29 个 JSON（含 root 与 craft，另有 2 个 recipe 解锁 advancement 在 recipes/ 子目录）。",
    evidence:
      "`ls src/main/resources/data/chiseled_enchanting_table/advancement/*.json | grep -v recipes | wc -l` → 29。同一句话里的「localized across all 11 shipped languages」也受 TXT-01 影响：advancement 的 title/description 恰好在 zh_tw 之外的 9 个语言里大概率是英文。",
    fix:
      "把具体数字去掉（数字会腐坏，改成「完整进度线」即可），或让 consistency.yml 增加一条「port_notes 里出现的数字必须与仓库实际计数一致」的门——仓库已经有一条「version gate for bumped one place, forgot the other four」，同一机制可以直接扩展。",
  },
  {
    id: "TXT-05",
    axis: "accuracy",
    severity: "high",
    layer: "文档 · README 首屏",
    title: "README 说普通书架「12+ 架起给经验减免」，数据与 WIKI 都是 3 架起；12 是另一个机制的门槛",
    detail:
      "README Concept 段：Regular Bookshelves「grant XP reduction starting at 12+ shelves」。library_resonance.json：min_discount_bookshelves = 3、max_discount_bookshelves = 45、max_wooden_discount_percent = 15。WIKI 第 83/98 行：「普通书架基础减免（满 3 起、满 45 达 −15%）」。",
    evidence:
      "12 这个数在数据里确实存在，但属于完全不同的机制：shelf_gates.json 的 depleted_tome_gradients.tier1_bookshelves = 12 —— 即「12 架起，褪魔残卷还原免经验」。README 把两个机制的门槛混成了一句话。WIKI 第 76 行同样把两者并列（「木书架减免(-15%)」与「附魔台内残卷减耗(12/32)」），说明作者是清楚区分的，只有 README 首屏写错了。",
    fix:
      "README 的这句改成「grant XP reduction from 3 shelves (up to −15% at 45)」，并把 12/32 的残卷里程碑留在它自己的 bullet 里。首屏是绝大多数人唯一会读的一段，这里的准确性权重最高。",
  },
  {
    id: "TXT-06",
    axis: "identity",
    severity: "med",
    layer: "文档 · README / WIKI",
    title: "书架天花板有 38 / 42 / 45 三个，README 只提 38，WIKI 分散在三节",
    detail:
      "README 说升级「along 0..38 shelves」，全文没有 42 与 45。WIKI 在第 83 行给 45（减免满额）、第 109–111 行给 38/42（温养分段）、第 115 行给 32（等待触发）。审计页的 COUP-04 从代码角度记了同一条；这里记的是它的文本表现。",
    evidence:
      "三处数字都真实存在于 shipped JSON，都可达（7×5×7 扫描域最多 342 个书架），但没有任何一处文本并排解释「为什么是三个不同的数、谁先到达、调整其中一个会影响什么」。",
    fix:
      "在 WIKI 增设一张「书架阈值总表」（阈值 / 机制 / JSON 键出处 / 到达难度 / 调整建议），README 首屏用一句话指向它。表格由脚本从 shelf_gates.json + library_resonance.json 渲染，避免出现第四份手抄副本——本仓库已经有 gen_bundled_defaults.py 这个成功先例。",
  },
  {
    id: "TXT-07",
    axis: "accuracy",
    severity: "med",
    layer: "代码注释 · Javadoc",
    title: "BookshelfProgression 的类注释把 maxLevel=2 的阶梯写成 [0, 38]，实现与数据都是 22",
    detail:
      "类注释第 29–31 行：「{@code [0, 7, 16, 27, 38]} for maxLevel = 5, {@code [0, 10, 23, 38]} for maxLevel = 4, {@code [0, 16, 38]} for maxLevel = 3, {@code [0, 38]} for maxLevel = 2」。",
    evidence:
      "实现（requiredBookshelvesForDirectTier，第 508–510 行）对 M==2 用 `Math.min(cfg.maxDirectBookshelves(), cfg.twoLevelMaxBookshelves())` = min(38, 22) = 22；shelf_gates.json 是 two_level_max_bookshelves = 22；WIKI 第 91–92 行也明确写「MAX = 2 为 22 架」，并解释了动机（避免 I → II 一步跳满 38 架）。四方里只有 Javadoc 是错的。",
    fix:
      "改正为 [0, 22]，并把这段阶梯示例改成由测试生成/断言（AuditMechanicsTest 或 EconomyAndConfigVerificationTest 里加一条「注释中列出的四个阶梯与实现输出一致」的用例太难，退一步：把这四组阶梯写成一张表放进 WIKI，Javadoc 只指向 WIKI）。文档层级越少，漂移面越小。",
  },
  {
    id: "TXT-08",
    axis: "accuracy",
    severity: "med",
    layer: "GUI 文案 · 断线理由",
    title: "断线理由硬编码了 Minecraft 版本号与配置文件路径，且只有一条英文 fallback",
    detail:
      "EnchantingProtocol.MISMATCH_MESSAGE：「Install the same current Minecraft 26.1.2 build on both client and server (version labels alone are not enough).」；stackSizeMismatchComponent 的 fallback 里写死「Restart after matching config/chiseled_enchanting_table.json.」。",
    evidence:
      "两条都通过 Component.translatableWithFallback 提供，本地化机制本身是对的（disconnect.chiseled_enchanting_table.protocol_mismatch / .book_stack_mismatch 两个 key）。问题在 fallback 字面量里的 26.1.2 与配置路径：gradle.properties 的 minecraft_version 已经是可注入的单一真相源，build.gradle 也已经在对 fabric.mod.json 做 expand，但这条字符串没有走同一条路。",
    fix:
      "processResources 里对包含这条常量的资源/生成的 BuildInfo 类做同样的 expand；配置路径抽成常量并作为 translatable 的参数位。另外建议给这两条 key 在 zh_cn/zh_tw 里补上翻译——断线理由是玩家在最沮丧的时刻读到的文字，也是最值得翻译的文字。",
  },
  {
    id: "TXT-09",
    axis: "identity",
    severity: "med",
    layer: "GUI 文案 · 配置界面规则溯源",
    title: "配置界面用 Component.literal(\"1.0.3: \") / (\"1.1.0: \") 作为标签，版本号写死在 UI 里且不进 lang",
    detail:
      "ChiseledEnchantingConfigScreen 第 1775–1778 行的规则溯源卡片 tooltip：先 `Component.literal(\"1.0.3: \")` 接 classicSummaryKey()，再 `Component.literal(\"1.1.0: \")` 接 modernSummaryKey()。",
    evidence:
      "三层问题叠加：① 版本号是字面量，1.2.0 发布后「1.1.0:」这个标签会指着一份已经变了的内容（modernSummaryKey 会更新，标签不会）；② 这两个前缀不在 lang 文件里，11 个语言全都不翻译它——中文用户看到的是英文半角冒号「1.0.3:」后面跟一句中文；③ 它与 CODEC-01 是同一个病根的两个症状：版本号被当成语义词汇使用。",
    fix:
      "改用与版本无关的语义词：`Component.translatable(\"config.chiseled_enchanting_table.trace.classic\")` → 「经典档（1.0.3 基线）」与「标准档（当前）」，把版本号作为参数从 BuildInfo 注入，只在需要时出现。这样标签本身进了 lang 文件，11 个语言可以各自决定要不要显示版本号。",
  },
  {
    id: "TXT-10",
    axis: "identity",
    severity: "low",
    layer: "跨层 · 写法规范",
    title: "同一份文档内混用多种写法：7×5×7 / 7x5x7、0..38 / 1–3、大小写、标点",
    detail:
      "实例：README 的 Concept 段用 `7×5×7`（U+00D7 乘号），Installation 段之外的一些报告用 `7x5x7`（字母 x）；数值区间一会儿 `0..38`（双点）、一会儿 `1–3`（en dash）、一会儿 `32+`（加号）、一会儿 `≥ 32`（WIKI 用数学符号）；「Chiseled Bookshelf / chiseled bookshelf」「Enchanted Book / enchanted book」大小写不统一；WIKI 用全角「」与 $LaTeX$，README 用行内代码反引号。",
    evidence:
      "这些都不影响理解——所以它们属于「易读性合格但同一性不足」的典型症状：读者不会读错，但会持续感到文本来自多个人/多个时期。对本项目尤其明显，因为文本确实来自多次同步（1.0.3 基线 → 26.3 sync → 1.1.0 overhaul → arena 分支快照）。",
    fix:
      "在 GLOSSARY.md 里附一节「写法规范」：区间统一 `0–38`（en dash）或统一 `0..38`（选一个）、维度统一 `7×5×7`、阈值统一 `≥ 32`、专有名词统一首字母大写。然后加一条 lint（Python 正则即可）扫 *.md 与 *.json 的 _comment，报出违规写法为 warn。",
  },
  {
    id: "TXT-11",
    axis: "readability",
    severity: "good",
    layer: "全局 · 应当明确肯定",
    title: "易读性确实合格，且有若干做法明显优于同类项目",
    detail:
      "六项可验证的优点：① 959 个 key 在 11 个文件里全部非空、无字面 \\n（CI 有专门的门在管这件事）；② Component.translatableWithFallback 用得规范，断线理由与堆叠不匹配都有 fallback；③ zh_cn 是唯一 100% 翻译的语言包，且译文是口语化的重写而非直译（「自己挑附魔，不再看脸」「不再看脸」这种表达比英文原文更好读）；④ WIKI 的数值公式写成可复算的形式，本次审计逐项复算全部通过（见审计页 BAL-GOOD）；⑤ 类注释普遍交代「为什么」而不只是「做什么」，RemoveEnchantMerge、VillagerInfinitySanitizeMixin、GrindstoneBookDepleteMixin 三处注释都记录了历史缺陷与修法动机，这是很稀缺的文档形态；⑥ EffectScope 的 glyph 设计注释明确写「Dual-coded geometric glyph so badges never rely on color alone」——无障碍意识。",
    evidence:
      "同时，仓库自己建立了 docs/DOCUMENTATION_INDEX.md、CURRENT_BASELINE.md、NEXT_TASK.md、TODO.md 与 21 份 docs/reports/，并在 ci_static_checks.py 的 Tier D 里主动检查 markdown 悬空链接（并且诚实地把「docs/COMPATIBILITY.md 与 P19 报告被引用但不存在」记为 warn 而非隐藏）。",
    fix:
      "建议只有一条：把这份「解释为什么」的注释纪律从 Java 类注释扩展到 JSON 的 _comment 与 README 的机制段落——CODEC-04 与 BAL-04 都是「JSON 里少了一句为什么」造成的。已有的 `_epiphany_tier_plus_score_divisor_note` 就是正确样板，值得推广成惯例。",
  },
  {
    id: "TXT-12",
    axis: "readability",
    severity: "med",
    layer: "文档 · 体量与入口",
    title: "5758 行文档、21 份报告，但缺少一张「我该读哪一份」的决策图",
    detail:
      "docs/ 下：WIKI.md 314 行、EXTENDING.md 264 行、CHANGELOG_HISTORY.md 253 行、DOCUMENTATION_INDEX.md 124 行、reports/ 21 份共约 3000 行；根目录 README 130 行、CURRENT_BASELINE.md 361 行、CHANGELOG.md 514 行、NEXT_TASK.md 231 行、TODO.md 49 行。合计 5758 行。",
    evidence:
      "DOCUMENTATION_INDEX.md 存在（124 行），这是对的。但入口分散：README 指向 WIKI，WIKI 指向 reports，CURRENT_BASELINE 指向 CHANGELOG_HISTORY，NEXT_TASK 与 TODO 并存（两份都在描述「接下来做什么」）。一个新贡献者要判断「我改平衡数值该读哪三份」需要跳四五次。",
    fix:
      "在 DOCUMENTATION_INDEX.md 顶部加一张按角色的 3 行表：玩家 → WIKI；整合包/服务端 → WIKI §配置 + EXTENDING；贡献者 → CURRENT_BASELINE + 对应 reports/Pxx + NEXT_TASK。并把 TODO.md 合并进 NEXT_TASK.md（两份「接下来做什么」必然漂移）。",
  },
];

export const TEXT_SCORES = [
  { axis: "readability" as const, score: 78, note: "合格：译文质量与注释纪律都好；扣分在文档入口与体量管理" },
  { axis: "accuracy" as const, score: 46, note: "有可验证错项：11 语言宣称、README 12 架、port_notes 10 个进度、Javadoc [0,38]" },
  { axis: "identity" as const, score: 41, note: "最弱：一物多名（最多 3 英 + 2 中）、三个书架天花板无并排解释、写法混用" },
];
