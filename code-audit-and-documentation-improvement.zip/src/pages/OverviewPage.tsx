import { useEffect, useMemo, useState } from "react";
import { cn } from "../utils/cn";
import {
  FINDINGS,
  PATHS,
  REPO_META,
  SEV_META,
  countBySeverity,
  type Severity,
} from "../data/findings";
import { Code, Meter, Reveal, Rule, SectionHead, SevBar, SevPill, Stat } from "../components/ui";
import type { Route } from "../components/Nav";

/* ------------------------------------------------------- 7x5x7 shelf scan */

const COLS = 7;
const ROWS = 5;

interface Cell {
  kind: "table" | "wood" | "chiseled" | "empty" | "air";
  slot?: number;
}

function buildFace(seed: number): Cell[] {
  const rnd = (i: number) => {
    const x = Math.sin(seed * 12.9898 + i * 78.233) * 43758.5453;
    return x - Math.floor(x);
  };
  const cells: Cell[] = [];
  for (let i = 0; i < COLS * ROWS; i++) {
    const c = i % COLS;
    const r = Math.floor(i / COLS);
    const center = c === 3 && r === 2;
    if (center) {
      cells.push({ kind: "table" });
      continue;
    }
    const d = Math.max(Math.abs(c - 3), Math.abs(r - 2));
    const v = rnd(i);
    if (d === 1) cells.push({ kind: v > 0.16 ? "chiseled" : "air", slot: Math.floor(v * 6) });
    else if (d === 2) cells.push({ kind: v > 0.42 ? "wood" : v > 0.22 ? "empty" : "air" });
    else cells.push({ kind: v > 0.66 ? "wood" : v > 0.5 ? "empty" : "air" });
  }
  return cells;
}

const CELL_STYLE: Record<Cell["kind"], { bg: string; bd: string; glow: string }> = {
  table: { bg: "#a46ee5", bd: "#cba6ff", glow: "0 0 16px #a46ee5" },
  chiseled: { bg: "#2b519c", bd: "#6fa0f0", glow: "0 0 9px #3d6fd1" },
  wood: { bg: "#7a5326", bd: "#d99b38", glow: "0 0 7px #d99b3866" },
  empty: { bg: "#221a38", bd: "#3a2c5c", glow: "none" },
  air: { bg: "transparent", bd: "#241c3a", glow: "none" },
};

function ShelfScan() {
  const [seed, setSeed] = useState(1);
  const [pulse, setPulse] = useState(0);
  const cells = useMemo(() => buildFace(seed), [seed]);

  useEffect(() => {
    const t = setInterval(() => setPulse((p) => (p + 1) % (COLS * ROWS)), 130);
    return () => clearInterval(t);
  }, []);

  const wood = cells.filter((c) => c.kind === "wood").length;
  const chis = cells.filter((c) => c.kind === "chiseled").length;

  return (
    <div className="plate relative overflow-hidden rounded-xl p-4 sm:p-5">
      <div className="mb-3.5 flex flex-wrap items-baseline justify-between gap-2">
        <div>
          <div className="font-mono text-[10px] tracking-[0.24em] text-parchment-faint uppercase">
            scan_volume · live
          </div>
          <div className="font-cjk-display mt-0.5 text-[15px] font-bold text-parchment">
            7 × 5 × 7 书架扫描域
          </div>
        </div>
        <button
          type="button"
          onClick={() => setSeed((s) => s + 1)}
          className="group rounded border border-lapis-400/25 bg-lapis-500/10 px-2.5 py-1 font-mono text-[10px] tracking-[0.12em] text-lapis-300 uppercase transition-all hover:border-amethyst-400/60 hover:bg-amethyst-400/15 hover:text-amethyst-300 active:scale-95"
        >
          rescan ⟳
        </button>
      </div>

      <div className="relative">
        <div
          className="grid gap-[3px]"
          style={{ gridTemplateColumns: `repeat(${COLS}, minmax(0,1fr))` }}
        >
          {cells.map((c, i) => {
            const s = CELL_STYLE[c.kind];
            const isPulse = i === pulse;
            return (
              <div
                key={i}
                className={cn(
                  "relative aspect-square rounded-[3px] border transition-all duration-300",
                  isPulse && "scale-[1.06]",
                )}
                style={{
                  background: s.bg,
                  borderColor: isPulse ? "#ece6f8" : s.bd,
                  boxShadow: isPulse ? `0 0 14px ${s.bd}` : s.glow,
                  opacity: c.kind === "air" ? 0.55 : 1,
                }}
              >
                {c.kind === "chiseled" && (
                  <span className="absolute inset-0 grid grid-cols-3 grid-rows-2 gap-[1px] p-[2px]">
                    {Array.from({ length: 6 }, (_, k) => (
                      <i
                        key={k}
                        className="rounded-[1px]"
                        style={{
                          background:
                            k <= (c.slot ?? 3) ? "rgba(203,166,255,0.75)" : "rgba(255,255,255,0.07)",
                        }}
                      />
                    ))}
                  </span>
                )}
                {c.kind === "table" && (
                  <span className="anim-pulse-ring absolute inset-[22%] rounded-full bg-obsidian-950/70" />
                )}
              </div>
            );
          })}
        </div>
        <div className="pointer-events-none absolute inset-0 overflow-hidden rounded">
          <div
            className="anim-scanline absolute inset-x-0 h-8"
            style={{
              background:
                "linear-gradient(180deg, transparent, rgba(157,192,255,0.16) 45%, rgba(203,166,255,0.28) 50%, rgba(157,192,255,0.16) 55%, transparent)",
            }}
          />
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3">
        <Meter label="普通书架 W" value={wood} max={COLS * ROWS} color="#d99b38" right={`${wood} 面`} />
        <Meter label="雕纹书架 C（有书）" value={chis} max={COLS * ROWS} color="#6fa0f0" right={`${chis} 面`} />
      </div>

      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5 border-t border-lapis-400/12 pt-3 font-mono text-[10px] tracking-wide text-parchment-faint">
        {[
          ["#d99b38", "wood · 直附档位 / −15% 减免"],
          ["#6fa0f0", "chiseled · 母本温养 / −40%"],
          ["#a46ee5", "table · 雕纹附魔台"],
          ["#3a2c5c", "empty / air"],
        ].map(([c, l]) => (
          <span key={l} className="inline-flex items-center gap-1.5">
            <i className="h-2 w-2 rounded-[2px]" style={{ background: c }} />
            {l}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ ticker */

function Ticker() {
  const items = [
    "MIXIN-01 removeItemNoUpdate 把「取走整格」改成「取走 1 个」 · 附魔书堆叠上限 64",
    "TXT-01 9 个语言包 56%–70% 的条目与 en_us 逐字节相同 · CI lang 门显式允许",
    "COUP-01 HIGH_APPLICABILITY_IDS 硬编码 10 个魔咒 ID · 与 broad_applicability 标签重叠但不相等",
    "COUP-02 LibraryResonance.Config = 50 个位置参数（22 double / 20 int）",
    "GUI-06 U+1F512 🔒 超出 BMP · 原版 unifont 回退渲染为缺字方块",
    "CODEC-06 24 张原版箱表概率硬编码 · 且 !source.isBuiltin() 使数据包无法覆盖",
    "DEAD-01 IrisGlintPreload 的注释写的是 MC 26.3 · 本分支目标是 26.1.2",
    "COUP-07 书架粒子几何硬编码 · 完全忽略 FACING，四个朝向只有一个正确",
    "BAL-GOOD WIKI 全部可复算公式逐项核对通过 · [0,7,16,27,38] / ceil(M/2) / 7200s↔6 游戏日",
    "NET-GOOD 服务端先校验后扣费 · 每 tick 突发守卫 8/6 · 负数计数一律抛异常",
  ];
  const row = [...items, ...items];
  return (
    <div className="relative overflow-hidden border-y border-lapis-400/14 bg-obsidian-950/55 py-2">
      <div className="anim-ticker flex w-max gap-10 whitespace-nowrap">
        {row.map((t, i) => (
          <span key={i} className="flex items-center gap-3 font-mono text-[11px] text-parchment-faint">
            <i className="h-1 w-1 shrink-0 rounded-full bg-amethyst-400/70" />
            {t}
          </span>
        ))}
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-obsidian-950 to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-obsidian-950 to-transparent" />
    </div>
  );
}

/* -------------------------------------------------------------------- page */

const DOSSIER: [string, string][] = [
  ["repository", `${REPO_META.owner}/${REPO_META.name}`],
  ["branch", REPO_META.branch],
  ["upstream", `${REPO_META.upstream}（MIT）`],
  ["mod_version", REPO_META.modVersion],
  ["target", `Minecraft ${REPO_META.mcVersion}`],
  ["toolchain", `${REPO_META.loader} · API ${REPO_META.fabricApi} · Java ${REPO_META.java}`],
  ["protocol", REPO_META.protocolRevision],
  ["scope", `${REPO_META.javaFiles} java · ${REPO_META.locJava.toLocaleString()} LOC · ${REPO_META.jsonFiles} json · ${REPO_META.mixins} mixins`],
];

export default function OverviewPage({ go }: { go: (r: Route) => void }) {
  const counts = countBySeverity();
  const order: Severity[] = ["crit", "high", "med", "low", "info", "good"];
  const total = FINDINGS.length;
  const top = useMemo(
    () =>
      [...FINDINGS]
        .sort((a, b) => SEV_META[a.severity].rank - SEV_META[b.severity].rank)
        .slice(0, 6),
    [],
  );

  return (
    <>
      {/* ============ opening: the audit console, not a centered hero ============ */}
      <section className="relative mx-auto max-w-[1400px] px-4 pt-24 pb-10 sm:px-7 sm:pt-28">
        <div className="grid items-start gap-8 lg:grid-cols-[minmax(0,1fr)_minmax(0,0.86fr)] lg:gap-12">
          {/* left: dossier + headline */}
          <div>
            <Reveal>
              <div className="mb-5 flex flex-wrap items-center gap-2.5">
                <span className="inline-flex items-center gap-2 rounded-full border border-amethyst-400/35 bg-amethyst-400/10 px-3 py-1 font-mono text-[10px] tracking-[0.2em] text-amethyst-300 uppercase">
                  <i className="h-1.5 w-1.5 rounded-full bg-amethyst-400 anim-pulse-ring" />
                  independent source audit
                </span>
                <span className="font-mono text-[10.5px] tracking-[0.14em] text-parchment-faint uppercase">
                  unofficial community port · not upstream
                </span>
              </div>
            </Reveal>

            <Reveal delay={70}>
              <h1 className="font-cjk-display engraved text-[clamp(2.6rem,7.2vw,5.1rem)] leading-[0.98] font-black tracking-[-0.01em] text-parchment">
                <span className="text-parchment-dim/75">雕纹</span>
                <span className="relative ml-2 inline-block text-lapis-300">
                  审计台
                  <span
                    aria-hidden
                    className="absolute -bottom-1 left-0 h-[3px] w-full origin-left"
                    style={{
                      background:
                        "repeating-linear-gradient(90deg,#a46ee5 0 10px,transparent 10px 15px,#3d6fd1 15px 25px,transparent 25px 30px)",
                      opacity: 0.85,
                    }}
                  />
                </span>
              </h1>
              <p className="mt-6 font-display text-[clamp(0.78rem,1.5vw,1rem)] tracking-[0.3em] text-lapis-300/85 uppercase">
                Chiseled Enchanting Table · 26.1.2
              </p>
            </Reveal>

            <Reveal delay={140}>
              <p className="mt-6 max-w-2xl text-[15px] leading-[1.85] text-parchment-dim">
                对 <Code>arena/b99a37c2</Code> 分支快照的{" "}
                <span className="text-parchment">{REPO_META.locJava.toLocaleString()}</span> 行
                Java 与 <span className="text-parchment">{REPO_META.jsonFiles}</span> 份数据文件做的独立复核：
                沿<span className="text-lapis-300">源码 API</span>、
                <span className="text-lapis-300">数据编解码</span>、
                <span className="text-lapis-300">网络同步</span>、
                <span className="text-lapis-300">GUI 输入</span>、
                <span className="text-lapis-300">Mixin 注入</span>、
                <span className="text-lapis-300">死代码</span>、
                <span className="text-lapis-300">耦合风险</span>七条路径逐条追，
                外加数值与机制设计的合理性；再单开两页处理
                <span className="text-amethyst-300">文本的易读性 / 准确性 / 同一性</span>与
                <span className="text-emerald-glow">中肯的怀疑和建议</span>。
              </p>
            </Reveal>

            <Reveal delay={200}>
              <dl className="mt-7 overflow-hidden rounded-lg border border-lapis-400/15 bg-obsidian-900/55">
                {DOSSIER.map(([k, v], i) => (
                  <div
                    key={k}
                    className={cn(
                      "grid grid-cols-[112px_minmax(0,1fr)] gap-3 px-3.5 py-[7px] transition-colors hover:bg-lapis-500/8 sm:grid-cols-[148px_minmax(0,1fr)]",
                      i > 0 && "border-t border-lapis-400/8",
                    )}
                  >
                    <dt className="font-mono text-[10px] tracking-[0.12em] text-parchment-faint uppercase">
                      {k}
                    </dt>
                    <dd className="min-w-0 font-mono text-[11px] break-all text-lapis-300/90">{v}</dd>
                  </div>
                ))}
              </dl>
            </Reveal>

            <Reveal delay={260}>
              <div className="mt-6 flex flex-wrap gap-3">
                {[
                  { r: "audit" as Route, zh: "进入七路径审计", en: `${total} findings`, c: "#6fa0f0" },
                  { r: "text" as Route, zh: "文本三重审查", en: "readability · accuracy · identity", c: "#a46ee5" },
                  { r: "doubt" as Route, zh: "怀疑与建议", en: "8 doubts · 21 suggestions", c: "#43c59e" },
                ].map((b) => (
                  <button
                    key={b.r}
                    type="button"
                    onClick={() => {
                      go(b.r);
                      window.scrollTo({ top: 0, behavior: "smooth" });
                    }}
                    className="plate plate-hover group relative overflow-hidden rounded-lg px-5 py-3 text-left"
                  >
                    <span
                      className="absolute inset-y-0 left-0 w-[2px] transition-all duration-400 group-hover:w-[3px]"
                      style={{ background: b.c, boxShadow: `0 0 14px ${b.c}` }}
                    />
                    <span className="block font-cjk-display text-[14.5px] font-bold text-parchment">
                      {b.zh}
                    </span>
                    <span className="mt-0.5 block font-mono text-[10px] tracking-[0.1em] text-parchment-faint uppercase">
                      {b.en} →
                    </span>
                  </button>
                ))}
              </div>
            </Reveal>
          </div>

          {/* right: the live shelf scan */}
          <Reveal delay={120} className="lg:sticky lg:top-24">
            <ShelfScan />
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-2">
              <Stat value={total} label="审计条目总数" accent="#6fa0f0" sub="8 paths" />
              <Stat value={counts.crit + counts.high} label="严重 + 高危" accent="#ffa24d" sub="actionable now" />
              <Stat value="3" label="宣称与现实不符" accent="#a46ee5" sub="TXT-01 / 04 / 05" />
              <Stat value="2" label="明确做得好" accent="#43c59e" sub="NET-GOOD / BAL-GOOD" />
            </div>
          </Reveal>
        </div>
      </section>

      <Ticker />

      {/* ============================== severity ledger ======================= */}
      <section className="mx-auto max-w-[1400px] px-4 py-14 sm:px-7">
        <SectionHead
          idx="§0"
          zh="严重度总账"
          en="Severity ledger"
          accent="#ffa24d"
          blurb="按严重度归并的分布。两条 good 是刻意保留的：审计只报缺陷会失真，做对的部分同样需要被写下来，否则下一次重构会把它一起改掉。"
        />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
          {order.map((s, i) => {
            const m = SEV_META[s];
            return (
              <Reveal key={s} delay={i * 55}>
                <div className="plate plate-hover group h-full overflow-hidden rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-[10px] tracking-[0.18em] uppercase" style={{ color: m.color }}>
                      {s}
                    </span>
                    <span
                      className="tnum font-display text-[2rem] leading-none font-bold transition-transform duration-400 group-hover:scale-110"
                      style={{ color: m.color }}
                    >
                      {counts[s]}
                    </span>
                  </div>
                  <div className="mt-2 font-cjk-display text-[13px] font-bold text-parchment">{m.zh}</div>
                  <div className="mt-3">
                    <Meter value={counts[s]} max={Math.max(4, total / 3)} color={m.color} height={5} />
                  </div>
                  <div className="mt-3 space-y-1">
                    {FINDINGS.filter((f) => f.severity === s)
                      .slice(0, 4)
                      .map((f) => (
                        <div key={f.id} className="font-mono text-[9.5px] tracking-wide text-parchment-faint">
                          {f.id}
                        </div>
                      ))}
                    {counts[s] > 4 && (
                      <div className="font-mono text-[9.5px] text-parchment-faint/70">
                        +{counts[s] - 4} more
                      </div>
                    )}
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* ================================ path index ========================== */}
      <section className="mx-auto max-w-[1400px] px-4 py-14 sm:px-7">
        <SectionHead
          idx="§1"
          zh="七条审计路径 + 数值设计"
          en="Audit paths"
          accent="#6fa0f0"
          blurb="每条路径回答一个不同的问题：会不会崩、会不会分叉、会不会被绕过、会不会改不动。点击任一路径直接跳到审计页对应小节。"
        />
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {PATHS.map((p, i) => {
            const list = FINDINGS.filter((f) => f.path === p.key);
            const worst = list.reduce<Severity | null>(
              (acc, f) => (acc === null || SEV_META[f.severity].rank < SEV_META[acc].rank ? f.severity : acc),
              null,
            );
            return (
              <Reveal key={p.key} delay={i * 45}>
                <button
                  type="button"
                  onClick={() => {
                    go("audit");
                    setTimeout(() => {
                      document.getElementById(`path-${p.key}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
                    }, 90);
                  }}
                  className="plate plate-hover group relative h-full w-full overflow-hidden rounded-lg p-4 text-left"
                >
                  <span
                    className="absolute inset-x-0 top-0 h-[2px] origin-left scale-x-0 transition-transform duration-500 group-hover:scale-x-100"
                    style={{ background: p.accent, boxShadow: `0 0 12px ${p.accent}` }}
                  />
                  <div className="flex items-start justify-between gap-3">
                    <span className="font-mono text-[10px] tracking-[0.24em]" style={{ color: p.accent }}>
                      {p.idx}
                    </span>
                    <span
                      className="grid h-8 w-8 shrink-0 place-items-center rounded-md border text-[15px] transition-all duration-400 group-hover:scale-110"
                      style={{ color: p.accent, borderColor: `${p.accent}44`, background: `${p.accent}12` }}
                    >
                      {p.glyph}
                    </span>
                  </div>
                  <h3 className="font-cjk-display mt-3 text-[17px] leading-tight font-bold text-parchment">
                    {p.zh}
                  </h3>
                  <div className="mt-0.5 font-mono text-[9.5px] tracking-[0.14em] text-parchment-faint uppercase">
                    {p.en}
                  </div>
                  <p className="mt-2.5 text-[12px] leading-relaxed text-parchment-dim">{p.blurb}</p>
                  <div className="mt-3.5 flex items-center justify-between border-t border-white/6 pt-3">
                    <span className="tnum font-mono text-[11px] text-parchment-dim">
                      {list.length} 条
                    </span>
                    {worst && <SevPill sev={worst} showDot={false} />}
                  </div>
                </button>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* ================================ top findings ======================== */}
      <section className="mx-auto max-w-[1400px] px-4 py-14 sm:px-7">
        <SectionHead
          idx="§2"
          zh="先看这六条"
          en="Highest signal first"
          accent="#ff6b6b"
          blurb="按严重度与「修复成本 ÷ 风险」排序。第一条是一行代码，最后一条也是一行文本——审计里最贵的往往不是最难的那条。"
        />
        <ol className="space-y-2.5">
          {top.map((f, i) => {
            const m = SEV_META[f.severity];
            return (
              <Reveal as="li" key={f.id} delay={i * 60}>
                <button
                  type="button"
                  onClick={() => {
                    go("audit");
                    setTimeout(() => {
                      document.getElementById(`finding-${f.id}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
                    }, 90);
                  }}
                  className="plate plate-hover group grid w-full grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-4 rounded-lg px-4 py-3.5 text-left"
                >
                  <span
                    className="tnum font-display text-[1.6rem] leading-none font-bold opacity-35 transition-opacity group-hover:opacity-90"
                    style={{ color: m.color }}
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="min-w-0">
                    <span className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-[10.5px] tracking-[0.14em]" style={{ color: m.color }}>
                        {f.id}
                      </span>
                      <SevBar sev={f.severity} />
                    </span>
                    <span className="font-cjk-display mt-1 block text-[14.5px] leading-snug font-bold text-parchment">
                      {f.title}
                    </span>
                    <span className="mt-1 block truncate font-mono text-[10.5px] text-parchment-faint">
                      {f.where[0]}
                    </span>
                  </span>
                  <span className="hidden shrink-0 text-parchment-faint transition-all group-hover:translate-x-1 group-hover:text-lapis-300 sm:block">
                    →
                  </span>
                </button>
              </Reveal>
            );
          })}
        </ol>
      </section>

      {/* ================================ how to verify ======================= */}
      <section className="mx-auto max-w-[1400px] px-4 pt-6 pb-20 sm:px-7">
        <Reveal>
          <div className="plate relative overflow-hidden rounded-xl p-5 sm:p-7">
            <div className="pointer-events-none absolute -top-16 -right-16 h-52 w-52 rounded-full bg-amethyst-400/10 blur-3xl" />
            <div className="grid gap-7 md:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)]">
              <div>
                <div className="font-mono text-[10px] tracking-[0.24em] text-emerald-glow uppercase">
                  methodology
                </div>
                <h3 className="font-cjk-display engraved mt-2 text-[clamp(1.3rem,2.6vw,1.85rem)] leading-tight font-bold text-parchment">
                  每条结论都可以被复核
                </h3>
                <p className="mt-3 text-[13.5px] leading-relaxed text-parchment-dim">
                  审计基于分支快照的完整源码树（<Code>tar.gz</Code> 拉取后本地静态阅读），
                  不依赖任何运行时。所有带数字的断言都做了独立复算：
                  WIKI 的直附阶梯 <Code>[0,7,16,27,38]</Code>、<Code>ceil(M/2)</Code> 的
                  整数实现 <Code>(M+1)/2</Code>、木架减免公式、母本温养的
                  <Code>7200/3600/1200 秒 ↔ 6/3/1 游戏日</Code> 换算、以及 11 个语言包
                  959 个 key 的逐条比对，全部由脚本重跑而非目测。
                </p>
                <Rule className="my-5" color="#43c59e" />
                <p className="text-[13px] leading-relaxed text-parchment-dim">
                  <span className="text-emerald-glow">同时明确了审计的边界：</span>
                  没有 JDK、没有 Minecraft 运行时、没有 Fabric 开发环境，因此
                  <span className="text-parchment">无法验证 mixin 目标在 26.1.2 上的真实签名</span>、
                  无法验证渲染结果、无法跑测试。凡是依赖这三者的判断都标注了置信度与
                  「如何验证」，而不是当作事实陈述。这一点在
                  <button
                    type="button"
                    onClick={() => go("doubt")}
                    className="link-underline mx-1 text-amethyst-300 hover:text-amethyst-400"
                  >
                    怀疑与建议
                  </button>
                  页被反过来用作第一条怀疑。
                </p>
              </div>
              <div className="space-y-3">
                {[
                  {
                    t: "复算直附阶梯",
                    c: "python3 -c \"f=lambda L,M:round(38*((L-1)/(M-1))**1.25);print([f(l,5) for l in range(1,6)])\"\n# [0, 7, 16, 27, 38]  ← 与 WIKI 第 96 行一致",
                  },
                  {
                    t: "比对 11 个语言包与 en_us",
                    c: "for f in src/client/resources/assets/chiseled_enchanting_table/lang/*.json; do \\\n  python3 -c \"import json,sys;e=json.load(open('…/en_us.json'));d=json.load(open('$f'));\\\nprint('$f', sum(1 for k in e if d.get(k)==e[k]), '/', len(e))\"; done",
                  },
                  {
                    t: "确认 removeItemNoUpdate 的语义偏差",
                    c: "grep -n -A6 'removeItemNoUpdate' \\\n  src/main/java/chiseled_enchanting_table/mixin/bookshelf/LockedBookContainerMixin.java\n# → return self.removeItem(slot, 1);   原版语义为 takeItem(整格)",
                  },
                ].map((x) => (
                  <div key={x.t} className="overflow-hidden rounded-lg border border-lapis-400/15 bg-obsidian-950/70">
                    <div className="border-b border-lapis-400/12 bg-obsidian-850/60 px-3 py-1.5 font-mono text-[10px] tracking-[0.16em] text-parchment-faint uppercase">
                      {x.t}
                    </div>
                    <pre className="overflow-x-auto px-3 py-2.5 font-mono text-[10.5px] leading-[1.7] text-lapis-300/85">
                      {x.c}
                    </pre>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Reveal>
      </section>
    </>
  );
}
