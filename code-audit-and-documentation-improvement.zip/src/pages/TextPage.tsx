import { useMemo, useState } from "react";
import { cn } from "../utils/cn";
import {
  AXIS_META,
  LANG_TABLE,
  TEXT_FINDINGS,
  TEXT_SCORES,
  ZH_TW_UNTRANSLATED_SAMPLE,
  type TextFinding,
} from "../data/textAudit";
import { Code, CodeBlock, Meter, Reveal, Rule, SevPill, Tag } from "../components/ui";
import type { Severity } from "../data/findings";

const SEV_COLOR: Record<TextFinding["severity"], string> = {
  crit: "#ff6b6b",
  high: "#ffa24d",
  med: "#ffd66b",
  low: "#7fd6a8",
  good: "#43c59e",
};

/* ------------------------------------------------- locale coverage chart */

function LocaleChart() {
  const [hover, setHover] = useState<string | null>(null);
  const rows = LANG_TABLE;
  const max = 959;

  return (
    <div className="plate overflow-hidden rounded-xl">
      <div className="flex flex-wrap items-end justify-between gap-3 border-b border-lapis-400/14 px-4 py-3.5 sm:px-5">
        <div>
          <div className="font-mono text-[10px] tracking-[0.22em] text-amethyst-400 uppercase">
            measured · 959 keys × 11 locales
          </div>
          <h3 className="font-cjk-display mt-1 text-[17px] font-bold text-parchment">
            每个语言包里，有多少条其实就是英文
          </h3>
        </div>
        <div className="flex items-center gap-4 font-mono text-[10px] tracking-wide">
          <span className="inline-flex items-center gap-1.5 text-emerald-glow">
            <i className="h-2 w-4 rounded-[2px] bg-emerald-glow" />
            真正翻译
          </span>
          <span className="inline-flex items-center gap-1.5 text-sev-crit">
            <i className="h-2 w-4 rounded-[2px] bg-[repeating-linear-gradient(45deg,#ff6b6b_0_3px,#7a2c33_3px_6px)]" />
            与 en_us 逐字节相同
          </span>
        </div>
      </div>

      <div className="space-y-[7px] px-4 py-4 sm:px-5">
        {rows.map((r, i) => {
          const tp = (r.translated / max) * 100;
          const same = (r.identical / max) * 100;
          const active = hover === r.code;
          return (
            <Reveal key={r.code} delay={i * 40}>
              <div
                onMouseEnter={() => setHover(r.code)}
                onMouseLeave={() => setHover(null)}
                className={cn(
                  "grid grid-cols-[74px_minmax(0,1fr)_62px] items-center gap-3 rounded px-1.5 py-1 transition-colors sm:grid-cols-[104px_minmax(0,1fr)_72px]",
                  active && "bg-lapis-500/8",
                )}
              >
                <div className="min-w-0">
                  <div className="font-mono text-[11px] tracking-[0.06em] text-parchment">{r.code}</div>
                  <div className="hidden truncate font-cjk-display text-[10px] text-parchment-faint sm:block">
                    {r.name}
                  </div>
                </div>

                <div className="relative h-[15px] overflow-hidden rounded-[3px] bg-obsidian-800">
                  <div
                    className="absolute inset-y-0 left-0 transition-all duration-500"
                    style={{
                      width: `${tp}%`,
                      background:
                        r.identical === 0
                          ? "linear-gradient(90deg,#2f8f70,#43c59e)"
                          : "linear-gradient(90deg,#2b519c,#43c59e)",
                      boxShadow: active ? "0 0 12px -2px #43c59e" : "none",
                    }}
                  />
                  <div
                    className="absolute inset-y-0 transition-all duration-500"
                    style={{
                      left: `${tp}%`,
                      width: `${same}%`,
                      background:
                        "repeating-linear-gradient(45deg, rgba(255,107,107,.55) 0 3px, rgba(122,44,51,.5) 3px 6px)",
                    }}
                  />
                  <div className="absolute inset-0 grid grid-cols-[repeat(10,1fr)]">
                    {Array.from({ length: 9 }, (_, k) => (
                      <i key={k} className="border-r border-obsidian-950/45" />
                    ))}
                  </div>
                </div>

                <div className="tnum text-right font-mono text-[11px]" style={{ color: r.identical === 0 ? "#43c59e" : r.identical > 500 ? "#ff6b6b" : "#ffd66b" }}>
                  {((r.translated / max) * 100).toFixed(1)}%
                </div>
              </div>
            </Reveal>
          );
        })}
      </div>

      <div className="border-t border-lapis-400/14 bg-obsidian-950/50 px-4 py-3.5 sm:px-5">
        <p className="text-[12.5px] leading-relaxed text-parchment-dim">
          {hover
            ? LANG_TABLE.find((r) => r.code === hover)?.note
            : "把鼠标移到任一行看备注。10 个语言包的 key 数全部是 959、全部非空——所以 CI 的「lang parity ok」是真的；它只是没有衡量「翻译了没有」。"}
        </p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------- axis score rings */

function AxisRing({
  axis,
  score,
  note,
  delay,
}: {
  axis: keyof typeof AXIS_META;
  score: number;
  note: string;
  delay: number;
}) {
  const m = AXIS_META[axis];
  const R = 46;
  const C = 2 * Math.PI * R;
  return (
    <Reveal delay={delay}>
      <div className="plate plate-hover group h-full rounded-xl p-5">
        <div className="flex items-center gap-4">
          <svg viewBox="0 0 110 110" className="h-[104px] w-[104px] shrink-0 -rotate-90">
            <circle cx="55" cy="55" r={R} fill="none" stroke="rgba(236,230,248,0.08)" strokeWidth="8" />
            <circle
              cx="55"
              cy="55"
              r={R}
              fill="none"
              stroke={m.color}
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={C}
              strokeDashoffset={C - (C * score) / 100}
              style={{
                filter: `drop-shadow(0 0 6px ${m.color}88)`,
                transition: "stroke-dashoffset 1.4s cubic-bezier(.16,1,.3,1)",
              }}
            />
          </svg>
          <div className="min-w-0">
            <div className="font-mono text-[10px] tracking-[0.2em] uppercase" style={{ color: m.color }}>
              {m.en}
            </div>
            <div className="font-cjk-display mt-0.5 text-[24px] leading-none font-black text-parchment">
              {m.zh}
            </div>
            <div className="tnum mt-2 font-display text-[2rem] leading-none font-bold" style={{ color: m.color }}>
              {score}
              <span className="text-[0.9rem] opacity-50">/100</span>
            </div>
          </div>
        </div>
        <Rule className="my-4" color={m.color} />
        <div className="mb-2 inline-flex rounded border px-2 py-[2px] font-mono text-[10px] tracking-[0.1em]"
          style={{ color: m.color, borderColor: `${m.color}44`, background: `${m.color}10` }}
        >
          {m.verdict}
        </div>
        <p className="text-[12.5px] leading-relaxed text-parchment-dim">{m.desc}</p>
        <p className="mt-2.5 text-[12.5px] leading-relaxed text-parchment">{note}</p>
      </div>
    </Reveal>
  );
}

/* ------------------------------------------------------ the station diff */

const EN_STATION = [
  { t: "Targeted Enchanting Table: Insert gear or a book and pick the exact enchantment you want — no random rolling.", ph: [], k: "总述" },
  { t: "• Wooden Bookshelves: Raise max upgrade tiers, cut XP costs & unlock Treasure Epiphany at %3$s+ shelves.", ph: ["%3$s"], k: "普通书架" },
  { t: "• Chiseled Bookshelves within %1$s: Hold Enchanted Books as Template Books for instant tier access & 1–3 Lv XP mode (%2$s charges per level before stepping down).", ph: ["%1$s", "%2$s"], k: "雕纹书架" },
  { t: "• Cleanse Tab: Refund XP by clearing/stepping down traits, remove 1 unwanted trait, or purge curses.", ph: [], k: "去除附魔" },
];

const ZH_STATION = [
  { t: "自己挑附魔，不再看脸。", ph: [], k: "口号" },
  { t: "把附魔书放进附魔台周围 %1$s 的雕纹书架，就能照着它附魔，每次只扣 1–3 级经验（每级 %2$s 点充能，用完降一级）。", ph: ["%1$s", "%2$s"], k: "雕纹书架" },
  { t: "升级已有附魔时，之前付过的材料和经验会自动折抵，只补差价。", ph: [], k: "升级折抵" },
  { t: "在「去除附魔」页清附魔：本台附上去的全额退经验，别处来的按折扣退；被覆盖掉的冲突附魔也会退回差额。", ph: [], k: "去除附魔" },
];

function StationDiff() {
  const enPh = ["%1$s", "%2$s", "%3$s"];
  const zhPh = ["%1$s", "%2$s"];
  return (
    <div className="plate overflow-hidden rounded-xl">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-lapis-400/14 px-4 py-3 sm:px-5">
        <div className="font-mono text-[10.5px] tracking-[0.14em] break-all text-lapis-300">
          jei.chiseled_enchanting_table.info.station
        </div>
        <Tag color="#ffa24d">占位符不同构 · %3$s 丢失</Tag>
      </div>
      <div className="grid md:grid-cols-2">
        {[
          { code: "en_us", rows: EN_STATION, color: "#6fa0f0", ph: enPh },
          { code: "zh_cn", rows: ZH_STATION, color: "#43c59e", ph: zhPh },
        ].map((c, ci) => (
          <div key={c.code} className={cn("p-4 sm:p-5", ci === 0 && "md:border-r md:border-lapis-400/12")}>
            <div className="mb-3 flex items-center justify-between">
              <span className="font-mono text-[11px] tracking-[0.14em]" style={{ color: c.color }}>
                {c.code}
              </span>
              <span className="flex gap-1">
                {enPh.map((p) => {
                  const has = c.ph.includes(p);
                  return (
                    <span
                      key={p}
                      className="rounded border px-1.5 py-[1px] font-mono text-[9.5px]"
                      style={{
                        color: has ? c.color : "#ff6b6b",
                        borderColor: has ? `${c.color}44` : "#ff6b6b55",
                        background: has ? `${c.color}10` : "#ff6b6b10",
                        textDecoration: has ? "none" : "line-through",
                      }}
                    >
                      {p}
                    </span>
                  );
                })}
              </span>
            </div>
            <ol className="space-y-2">
              {c.rows.map((r) => (
                <li key={r.t} className="group rounded border border-white/6 bg-obsidian-950/45 px-3 py-2 transition-colors hover:border-lapis-400/30">
                  <div className="mb-1 font-mono text-[9.5px] tracking-[0.14em] text-parchment-faint uppercase">
                    {r.k}
                    {r.ph.length > 0 && <span className="ml-2 text-lapis-400">{r.ph.join(" ")}</span>}
                  </div>
                  <div className="text-[12.5px] leading-relaxed text-parchment-dim">{r.t}</div>
                </li>
              ))}
            </ol>
          </div>
        ))}
      </div>
      <div className="border-t border-lapis-400/14 bg-obsidian-950/55 px-4 py-3.5 sm:px-5">
        <p className="text-[12.5px] leading-relaxed text-parchment-dim">
          <span className="text-sev-crit">中文丢了「木质书架」与「Cleanse Tab」两条，</span>
          <span className="text-sev-crit">也丢了第三个参数（宝藏顿悟门槛）；</span>
          同时多了英文没有的「升级折抵」与「退款规则」两条。
          Java 的 <Code>Formatter</Code> 对未使用的定位参数不报错，所以这是静默的——
          装 JEI 的中文玩家与英文玩家读到的是两份不同完整度的说明，而两边都读不出自己少了什么。
        </p>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------ glossary */

const GLOSSARY = [
  {
    thing: "装着附魔书、可反复使用的雕纹书架母本",
    names: [
      ["Master Tome", "WIKI / 代码术语"],
      ["母本", "WIKI 中文"],
      ["Template Book", "en_us 的 JEI 文案"],
      ["master_tome", "library_resonance.json 键前缀"],
    ],
    canonical: "Master Tome / 母本",
  },
  {
    thing: "可交互的图文手册物品",
    names: [
      ["纂刻秘典 / Chiseled Grimoire", "README Concept 段"],
      ["Arcane Grimoire", "物品 ID arcane_grimoire"],
      ["秘典", "WIKI"],
      ["ArcaneGrimoireItem / Screen", "类名"],
    ],
    canonical: "Arcane Grimoire / 秘典",
  },
  {
    thing: "顿悟宝藏的高价替代材料",
    names: [
      ["Arcane Synthesis Crystal", "README Concept 段"],
      ["秘法凝晶", "WIKI"],
      ["Arcane Condensate", "gradle.properties 版本说明"],
      ["arcane_catalyst", "物品 ID"],
    ],
    canonical: "Arcane Catalyst / 秘法催化",
  },
  {
    thing: "书架扫描域的尺寸写法",
    names: [
      ["7×5×7", "README（U+00D7 乘号）"],
      ["7x5x7", "部分 report（字母 x）"],
      ["horizontal_radius 3 / vertical_radius 2", "shelf_gates.json"],
      ["343 格（去附魔台 342）", "推导值，文档中未出现"],
    ],
    canonical: "7×5×7",
  },
  {
    thing: "数值区间的写法",
    names: [
      ["0..38", "README / Javadoc（双点）"],
      ["1–3", "JEI 文案（en dash）"],
      ["32+", "README（加号）"],
      ["≥ 32", "WIKI（数学符号）"],
    ],
    canonical: "选一种并全局统一",
  },
];

/* --------------------------------------------------------------- page */

export default function TextPage() {
  const [axis, setAxis] = useState<"all" | keyof typeof AXIS_META>("all");

  const list = useMemo(
    () => TEXT_FINDINGS.filter((f) => axis === "all" || f.axis === axis),
    [axis],
  );

  return (
    <div className="relative mx-auto max-w-[1400px] px-4 pt-24 pb-24 sm:px-7 sm:pt-28">
      <Reveal>
        <div className="mb-3 flex items-center gap-3">
          <span className="font-mono text-[11px] tracking-[0.3em] text-amethyst-400">WORDING</span>
          <span className="h-px flex-1 bg-gradient-to-r from-amethyst-400/50 to-transparent" />
          <span className="font-mono text-[11px] text-parchment-faint">
            959 keys × 11 locales · 5,758 行文档
          </span>
        </div>
        <h1 className="font-cjk-display engraved text-[clamp(2rem,5vw,3.4rem)] leading-[1.05] font-black text-parchment">
          文字的三重审查
        </h1>
        <p className="mt-4 max-w-3xl text-[14.5px] leading-[1.85] text-parchment-dim">
          用户给的判断是「整体来说易读性是合格的，但实在可以再努力一下」——这个判断经复核成立，
          而且可以说得更精确：<span className="text-emerald-glow">易读性合格</span>、
          <span className="text-sev-high">准确性有可验证的错项</span>、
          <span className="text-amethyst-300">同一性是最弱的一条轴</span>。
          这一页把三条轴分开量，各自给出证据与修法，
          范围覆盖 <span className="text-parchment">说明文本（README / WIKI / fabric.mod.json）</span>、
          <span className="text-parchment">UI 内文本（lang 文件 / GUI 字面量 / 断线理由）</span>与
          <span className="text-parchment">文档内文本（21 份 report / CHANGELOG / 代码注释）</span>。
        </p>
      </Reveal>

      {/* three axes */}
      <div className="mt-9 grid gap-4 lg:grid-cols-3">
        {TEXT_SCORES.map((s, i) => (
          <AxisRing key={s.axis} axis={s.axis} score={s.score} note={s.note} delay={i * 90} />
        ))}
      </div>

      {/* locale chart */}
      <section className="mt-16">
        <Reveal>
          <div className="mb-5 flex flex-wrap items-end gap-x-5 gap-y-2">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-lg border border-sev-crit/40 bg-sev-crit/10 text-[22px] text-sev-crit">
              文
            </span>
            <div>
              <div className="font-mono text-[10.5px] tracking-[0.26em] text-sev-crit">TXT-01</div>
              <h2 className="font-cjk-display engraved text-[clamp(1.35rem,3vw,2rem)] leading-tight font-bold text-parchment">
                「11 种语言」到底有多少种
              </h2>
            </div>
          </div>
        </Reveal>

        <div className="grid gap-4 xl:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
          <LocaleChart />

          <div className="space-y-4">
            <Reveal delay={80}>
              <div className="plate rounded-xl p-5">
                <div className="font-mono text-[10px] tracking-[0.22em] text-gold-glow uppercase">
                  what the CI gate says
                </div>
                <CodeBlock className="mt-3" label="scripts/ci_static_checks.py · check_lang_parity">
{`# A translated value that is byte-identical to English is
# allowed (some strings really are the same), so only an
# *empty* value is treated as an unfinished translation.
for key in sorted(keys & reference_keys):
    if isinstance(data[key], str) and not data[key].strip():
        fail(f"{name}: lang key '{key}' is empty")

note(f"lang parity ok ({len(reference_keys)} keys across "
     f"en_us + {len(others)} language(s))")`}
                </CodeBlock>
                <p className="mt-3.5 text-[12.5px] leading-relaxed text-parchment-dim">
                  门本身写得对，注释也诚实。问题是它衡量的是
                  <span className="text-parchment">「key 在不在、值空不空」</span>，
                  而 README 宣称的是<span className="text-parchment">「in-game text ships in eleven languages」</span>。
                  两个命题不是一回事，而绿灯属于前者。
                </p>
              </div>
            </Reveal>

            <Reveal delay={140}>
              <div className="plate rounded-xl p-5">
                <div className="font-mono text-[10px] tracking-[0.22em] text-sev-high uppercase">
                  why it stays invisible
                </div>
                <p className="mt-3 text-[13px] leading-[1.8] text-parchment-dim">
                  因为这些 key <span className="text-parchment">存在</span>且值
                  <span className="text-parchment">非空</span>，vanilla 的 per-key 回退
                  <span className="text-sev-crit">永远不会触发</span>。
                  玩家不会看到「缺翻译」的任何信号，只会看到英文；
                  翻译者打开 Crowdin/文件也看不到待办条目。
                  <span className="text-parchment">这比缺 key 更难发现，也更难被认领。</span>
                </p>
                <Rule className="my-4" />
                <div className="font-mono text-[10px] tracking-[0.2em] text-parchment-faint uppercase">
                  zh_tw 未译的 44 条（节选）
                </div>
                <ul className="mt-2.5 space-y-1">
                  {ZH_TW_UNTRANSLATED_SAMPLE.map((k) => (
                    <li key={k} className="font-mono text-[10.5px] break-all text-lapis-300/80">
                      <span className="mr-1.5 text-sev-crit">·</span>
                      {k}
                    </li>
                  ))}
                  <li className="font-mono text-[10.5px] text-parchment-faint">… 共 44 条</li>
                </ul>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* station diff */}
      <section className="mt-16">
        <Reveal>
          <div className="mb-5 flex flex-wrap items-end gap-x-5 gap-y-2">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-lg border border-sev-high/40 bg-sev-high/10 text-[22px] text-sev-high">
              ⇄
            </span>
            <div>
              <div className="font-mono text-[10.5px] tracking-[0.26em] text-sev-high">TXT-02</div>
              <h2 className="font-cjk-display engraved text-[clamp(1.35rem,3vw,2rem)] leading-tight font-bold text-parchment">
                同一条说明，两种语言讲的是两件事
              </h2>
            </div>
          </div>
        </Reveal>
        <Reveal delay={60}>
          <StationDiff />
        </Reveal>
      </section>

      {/* glossary divergence */}
      <section className="mt-16">
        <Reveal>
          <div className="mb-5 flex flex-wrap items-end gap-x-5 gap-y-2">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-lg border border-amethyst-400/40 bg-amethyst-400/10 text-[22px] text-amethyst-300">
              名
            </span>
            <div>
              <div className="font-mono text-[10.5px] tracking-[0.26em] text-amethyst-400">TXT-03 / TXT-10</div>
              <h2 className="font-cjk-display engraved text-[clamp(1.35rem,3vw,2rem)] leading-tight font-bold text-parchment">
                一个东西有几个名字
              </h2>
            </div>
            <p className="w-full max-w-3xl text-[13px] leading-relaxed text-parchment-dim sm:w-auto sm:flex-1">
              同一性问题最具体的形态：玩家按 WIKI 的名字去 JEI 里搜，搜不到；
              按 README 的名字去问，得到另一个答案。下表每一行的四种写法都在仓库里真实存在。
            </p>
          </div>
        </Reveal>

        <div className="space-y-2.5">
          {GLOSSARY.map((g, i) => (
            <Reveal key={g.thing} delay={i * 55}>
              <div className="plate plate-hover grid gap-4 rounded-lg p-4 md:grid-cols-[minmax(0,1fr)_auto] md:items-center sm:p-5">
                <div className="min-w-0">
                  <div className="text-[12.5px] leading-relaxed text-parchment-dim">{g.thing}</div>
                  <div className="mt-2.5 flex flex-wrap gap-1.5">
                    {g.names.map(([n, src]) => (
                      <span
                        key={n}
                        className="group inline-flex items-baseline gap-1.5 rounded border border-lapis-400/22 bg-lapis-500/8 px-2 py-[3px] transition-colors hover:border-amethyst-400/50 hover:bg-amethyst-400/12"
                      >
                        <span className="font-mono text-[11px] text-parchment">{n}</span>
                        <span className="font-mono text-[9px] tracking-wide text-parchment-faint">← {src}</span>
                      </span>
                    ))}
                  </div>
                </div>
                <div className="shrink-0 md:text-right">
                  <div className="font-mono text-[9.5px] tracking-[0.18em] text-parchment-faint uppercase">
                    should be
                  </div>
                  <div className="font-cjk-display mt-1 text-[14px] font-bold text-emerald-glow">
                    {g.canonical}
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* findings */}
      <section className="mt-16">
        <Reveal>
          <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="font-mono text-[10.5px] tracking-[0.26em] text-lapis-400">ALL</div>
              <h2 className="font-cjk-display engraved text-[clamp(1.35rem,3vw,2rem)] leading-tight font-bold text-parchment">
                全部 {TEXT_FINDINGS.length} 条文本条目
              </h2>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {(["all", "readability", "accuracy", "identity"] as const).map((a) => {
                const on = axis === a;
                const c = a === "all" ? "#9dc0ff" : AXIS_META[a].color;
                return (
                  <button
                    key={a}
                    type="button"
                    onClick={() => setAxis(a)}
                    className={cn(
                      "rounded-full border px-3 py-1 font-mono text-[10.5px] tracking-[0.1em] uppercase transition-all duration-300 active:scale-95",
                    )}
                    style={{
                      color: on ? "#0b0813" : c,
                      borderColor: `${c}${on ? "ff" : "55"}`,
                      background: on ? c : `${c}12`,
                      boxShadow: on ? `0 0 14px -2px ${c}` : "none",
                    }}
                  >
                    {a === "all" ? `全部 ${TEXT_FINDINGS.length}` : `${AXIS_META[a].zh} ${TEXT_FINDINGS.filter((f) => f.axis === a).length}`}
                  </button>
                );
              })}
            </div>
          </div>
        </Reveal>

        <div className="space-y-2.5">
          {list.map((f, i) => {
            const c = SEV_COLOR[f.severity];
            const ax = AXIS_META[f.axis];
            return (
              <Reveal key={f.id} delay={Math.min(i, 6) * 45}>
                <article
                  id={`finding-${f.id}`}
                  className="plate group relative scroll-mt-28 overflow-hidden rounded-lg p-4 pl-5 transition-all duration-400 hover:border-lapis-400/40 sm:p-5 sm:pl-6"
                  style={{ borderColor: `${c}2e` }}
                >
                  <span
                    className="absolute inset-y-0 left-0 w-[2.5px]"
                    style={{ background: `linear-gradient(180deg, ${c}, ${ax.color})`, boxShadow: `0 0 14px -3px ${c}` }}
                  />
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-[11px] tracking-[0.1em]" style={{ color: c }}>
                      {f.id}
                    </span>
                    <SevPill sev={f.severity as Severity} />
                    <Tag color={ax.color}>{ax.zh}</Tag>
                    <span className="font-mono text-[10px] tracking-wide text-parchment-faint">{f.layer}</span>
                  </div>
                  <h3 className="font-cjk-display mt-2.5 text-[16px] leading-snug font-bold text-parchment transition-colors group-hover:text-white">
                    {f.title}
                  </h3>
                  <div className="mt-3 grid gap-4 lg:grid-cols-2">
                    <div>
                      <div className="mb-1.5 font-mono text-[9.5px] tracking-[0.18em] text-parchment-faint uppercase">
                        detail
                      </div>
                      <p className="text-[13px] leading-[1.8] text-parchment-dim">{f.detail}</p>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <div className="mb-1.5 font-mono text-[9.5px] tracking-[0.18em] text-gold-glow uppercase">
                          evidence
                        </div>
                        <p className="text-[13px] leading-[1.8] text-parchment-dim">{f.evidence}</p>
                      </div>
                      <div>
                        <div className="mb-1.5 font-mono text-[9.5px] tracking-[0.18em] text-emerald-glow uppercase">
                          fix
                        </div>
                        <p className="text-[13px] leading-[1.8] text-parchment">{f.fix}</p>
                      </div>
                    </div>
                  </div>
                </article>
              </Reveal>
            );
          })}
        </div>
      </section>

      {/* the one cheap fix */}
      <section className="mt-16">
        <Reveal>
          <div className="plate relative overflow-hidden rounded-xl p-5 sm:p-7">
            <div className="pointer-events-none absolute -bottom-20 -left-16 h-56 w-56 rounded-full bg-emerald-glow/10 blur-3xl" />
            <div className="grid gap-7 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
              <div>
                <div className="font-mono text-[10px] tracking-[0.24em] text-emerald-glow uppercase">
                  the cheapest high-value fix
                </div>
                <h3 className="font-cjk-display engraved mt-2 text-[clamp(1.3rem,2.6vw,1.85rem)] leading-tight font-bold text-parchment">
                  30 行 Python，把这一页从「不可见」变成红灯
                </h3>
                <p className="mt-3 text-[13.5px] leading-[1.85] text-parchment-dim">
                  现有的 <Code>check_lang_parity</Code> 已经在遍历所有 locale 的所有 key，
                  只需要在同一个循环里加两条断言：非英文比例阈值（warn）与占位符同构（fail）。
                  不需要 JDK、不需要网络、不需要 Minecraft——
                  完全落在这个仓库已经建立的「静态门跑在秒级」的约束里。
                </p>
                <p className="mt-3 text-[13px] leading-[1.85] text-parchment-dim">
                  这一步的价值不止于抓住 TXT-01/02：它把「翻译完成度」变成一个
                  <span className="text-parchment">持续可见的数字</span>，
                  之后任何贡献者提交一份翻译，CI 会立刻告诉他覆盖了百分之几。
                  招募翻译最有效的方式是让缺口可见。
                </p>
              </div>
              <CodeBlock label="建议追加到 scripts/ci_static_checks.py">
{`import re
PLACEHOLDER = re.compile(r"%(\\d+\\$)?[sdf]")

def check_lang_depth(reference: dict) -> None:
    warn_threshold = 0.20          # 允许 20% 逐字节相同
    for name in other_locales:
        data = read_json(os.path.join(LANG_DIR, name))
        same = [k for k, v in data.items()
                if k in reference and isinstance(v, str)
                and v == reference[k]
                and re.search(r"[A-Za-z]{4}", v)]
        ratio = len(same) / max(1, len(data))
        if ratio > warn_threshold:
            warn(f"{name}: {len(same)}/{len(data)} values are "
                 f"byte-identical to en_us ({ratio:.0%} untranslated)")
        # 占位符必须与 en_us 同构（集合，不是顺序）
        for k, v in data.items():
            if k in reference and isinstance(v, str):
                a = set(PLACEHOLDER.findall(reference[k]))
                b = set(PLACEHOLDER.findall(v))
                if a != b:
                    fail(f"{name}: '{k}' placeholders {sorted(b)} "
                         f"!= en_us {sorted(a)}")`}
              </CodeBlock>
            </div>
            <div className="mt-5 flex flex-wrap items-center gap-3 border-t border-white/8 pt-4">
              <Meter value={9} max={11} color="#ff6b6b" label="需要这条门才能变可见的语言包" right="9 / 11" />
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
