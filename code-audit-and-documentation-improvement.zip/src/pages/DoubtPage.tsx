import { useMemo, useState } from "react";
import { cn } from "../utils/cn";
import { DOUBTS, SUGGESTIONS, VERDICT, type Doubt } from "../data/skepticism";
import { Code, Meter, Reveal, Rule, Tag } from "../components/ui";
import type { Route } from "../components/Nav";

const STANCE = {
  strong: { zh: "强怀疑", color: "#ff6b6b", bars: 3, en: "strong" },
  moderate: { zh: "中等怀疑", color: "#ffa24d", bars: 2, en: "moderate" },
  mild: { zh: "轻度怀疑", color: "#ffd66b", bars: 1, en: "mild" },
} as const;

const PRIO = {
  P0: { color: "#ff6b6b", zh: "先做", note: "≤1 天，覆盖 1 条严重 + 4 条高危 + 全部 3 条宣称不符" },
  P1: { color: "#ffa24d", zh: "尽快", note: "数天，消除双真相源与静默失效路径" },
  P2: { color: "#ffd66b", zh: "排期", note: "结构性重构，收益随时间放大" },
  P3: { color: "#7fd6a8", zh: "长期", note: "打磨与防未来腐坏" },
} as const;

/* ------------------------------------------------------------- one doubt */

function DoubtCard({ d, i }: { d: Doubt; i: number }) {
  const s = STANCE[d.stance];
  const [open, setOpen] = useState(i < 2);

  return (
    <Reveal delay={Math.min(i, 5) * 60}>
      <article
        className="plate group relative overflow-hidden rounded-xl transition-all duration-400"
        style={{ borderColor: open ? `${s.color}3d` : undefined }}
      >
        <span
          className="absolute inset-y-0 left-0 w-[3px] transition-all duration-500"
          style={{ background: s.color, boxShadow: open ? `0 0 18px -2px ${s.color}` : "none", opacity: open ? 1 : 0.5 }}
        />

        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          className="flex w-full items-start gap-4 px-4 py-4 pl-6 text-left sm:px-6 sm:pl-8"
          aria-expanded={open}
        >
          <span className="mt-[2px] shrink-0">
            <span className="flex items-end gap-[3px]" title={s.zh}>
              {[0, 1, 2].map((k) => (
                <i
                  key={k}
                  className="w-[4px] rounded-[1px] transition-all duration-500"
                  style={{
                    height: 6 + k * 5,
                    background: k < s.bars ? s.color : "rgba(236,230,248,0.14)",
                    boxShadow: k < s.bars ? `0 0 8px ${s.color}88` : "none",
                  }}
                />
              ))}
            </span>
          </span>

          <span className="min-w-0 flex-1">
            <span className="flex flex-wrap items-center gap-2">
              <span className="font-mono text-[10.5px] tracking-[0.14em]" style={{ color: s.color }}>
                {d.id} · {s.en}
              </span>
              <Tag color={s.color}>{s.zh}</Tag>
            </span>
            <span className="font-cjk-display mt-2 block text-[16.5px] leading-snug font-bold text-parchment transition-colors group-hover:text-white sm:text-[18px]">
              {d.title}
            </span>
          </span>

          <span
            className={cn(
              "mt-1 grid h-6 w-6 shrink-0 place-items-center rounded border text-[11px] transition-transform duration-400",
              open ? "rotate-45" : "group-hover:rotate-90",
            )}
            style={{ color: s.color, borderColor: `${s.color}44`, background: `${s.color}10` }}
          >
            +
          </span>
        </button>

        <div
          className="grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(.16,1,.3,1)]"
          style={{ gridTemplateRows: open ? "1fr" : "0fr" }}
        >
          <div className="overflow-hidden">
            <div className="space-y-4 border-t border-white/6 px-4 pt-4 pb-5 pl-6 sm:px-6 sm:pl-8">
              <Row label="作者怎么说" color="#9dc0ff">
                <p className="text-[13.5px] leading-[1.85] text-parchment-dim">{d.claim}</p>
              </Row>
              <Row label="为什么怀疑" color={s.color}>
                <p className="text-[13.5px] leading-[1.85] text-parchment-dim">{d.why}</p>
              </Row>
              <Row label="反面证据（中肯的部分）" color="#43c59e">
                <p className="text-[13.5px] leading-[1.85] text-parchment-dim">{d.counterEvidence}</p>
              </Row>
              <Row label="怎么验证" color="#d99b38">
                <p className="text-[13.5px] leading-[1.85] text-parchment">{d.testIt}</p>
              </Row>
            </div>
          </div>
        </div>
      </article>
    </Reveal>
  );
}

function Row({ label, color, children }: { label: string; color: string; children: React.ReactNode }) {
  return (
    <div className="grid gap-2 sm:grid-cols-[148px_minmax(0,1fr)]">
      <div className="pt-[3px] font-mono text-[10px] tracking-[0.14em] uppercase" style={{ color }}>
        {label}
      </div>
      <div className="min-w-0">{children}</div>
    </div>
  );
}

/* ------------------------------------------------------------------ page */

export default function DoubtPage({ go }: { go: (r: Route) => void }) {
  const [prio, setPrio] = useState<Set<string>>(new Set());
  const toggle = (p: string) =>
    setPrio((prev) => {
      const n = new Set(prev);
      n.has(p) ? n.delete(p) : n.add(p);
      return n;
    });

  const list = useMemo(
    () => SUGGESTIONS.filter((s) => prio.size === 0 || prio.has(s.priority)),
    [prio],
  );

  const byPrio = useMemo(() => {
    const m: Record<string, number> = { P0: 0, P1: 0, P2: 0, P3: 0 };
    SUGGESTIONS.forEach((s) => m[s.priority]++);
    return m;
  }, []);

  return (
    <div className="relative mx-auto max-w-[1400px] px-4 pt-24 pb-24 sm:px-7 sm:pt-28">
      <Reveal>
        <div className="mb-3 flex items-center gap-3">
          <span className="font-mono text-[11px] tracking-[0.3em] text-emerald-glow">DOUBTS</span>
          <span className="h-px flex-1 bg-gradient-to-r from-emerald-glow/50 to-transparent" />
          <span className="font-mono text-[11px] text-parchment-faint">
            {DOUBTS.length} doubts · {SUGGESTIONS.length} suggestions
          </span>
        </div>
        <h1 className="font-cjk-display engraved text-[clamp(2rem,5vw,3.4rem)] leading-[1.05] font-black text-parchment">
          中肯的怀疑，与建议
        </h1>
        <p className="mt-4 max-w-3xl text-[14.5px] leading-[1.85] text-parchment-dim">
          「中肯」的具体做法是：每一条怀疑都自带一段
          <span className="text-emerald-glow">反面证据</span>——
          即仓库里已经做对了什么、为什么作者的选择在当时的约束下是合理的，
          以及一条<span className="text-gold-glow">可执行的验证方法</span>。
          怀疑如果不能被验证，就只是情绪；反面证据如果没有，就不是中肯。
        </p>
      </Reveal>

      {/* verdict */}
      <Reveal delay={80}>
        <div className="plate relative mt-8 overflow-hidden rounded-xl p-5 sm:p-7">
          <div className="pointer-events-none absolute -top-24 right-0 h-64 w-64 rounded-full bg-lapis-500/12 blur-3xl" />
          <div className="grid gap-6 lg:grid-cols-3">
            <div>
              <div className="font-mono text-[10px] tracking-[0.24em] text-lapis-400 uppercase">
                what is genuinely good
              </div>
              <p className="mt-3 text-[13.5px] leading-[1.85] text-parchment-dim">{VERDICT.summary}</p>
            </div>
            <div>
              <div className="font-mono text-[10px] tracking-[0.24em] text-sev-high uppercase">
                where the risk compounds
              </div>
              <p className="mt-3 text-[13.5px] leading-[1.85] text-parchment-dim">{VERDICT.risk}</p>
            </div>
            <div>
              <div className="font-mono text-[10px] tracking-[0.24em] text-emerald-glow uppercase">
                bottom line
              </div>
              <p className="mt-3 text-[13.5px] leading-[1.85] text-parchment">{VERDICT.bottomLine}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => {
                    go("audit");
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                  className="rounded-md border border-lapis-400/35 bg-lapis-500/12 px-3 py-1.5 font-mono text-[10.5px] tracking-[0.12em] text-lapis-300 uppercase transition-all hover:border-lapis-300/70 hover:bg-lapis-500/22 active:scale-95"
                >
                  查看逐条证据 →
                </button>
                <button
                  type="button"
                  onClick={() => {
                    go("text");
                    window.scrollTo({ top: 0, behavior: "smooth" });
                  }}
                  className="rounded-md border border-amethyst-400/35 bg-amethyst-400/12 px-3 py-1.5 font-mono text-[10.5px] tracking-[0.12em] text-amethyst-300 uppercase transition-all hover:border-amethyst-300/70 hover:bg-amethyst-400/22 active:scale-95"
                >
                  文本三重审查 →
                </button>
              </div>
            </div>
          </div>
        </div>
      </Reveal>

      {/* doubts */}
      <section className="mt-16">
        <Reveal>
          <div className="mb-5 flex flex-wrap items-end gap-x-5 gap-y-2">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-lg border border-sev-crit/40 bg-sev-crit/10 text-[22px] text-sev-crit">
              ?
            </span>
            <div>
              <div className="font-mono text-[10.5px] tracking-[0.26em] text-sev-crit">PART I</div>
              <h2 className="font-cjk-display engraved text-[clamp(1.35rem,3vw,2rem)] leading-tight font-bold text-parchment">
                八条怀疑
              </h2>
            </div>
            <div className="flex gap-3 sm:ml-auto">
              {(Object.keys(STANCE) as (keyof typeof STANCE)[]).map((k) => (
                <span key={k} className="inline-flex items-center gap-1.5 font-mono text-[10px]" style={{ color: STANCE[k].color }}>
                  <span className="flex items-end gap-[2px]">
                    {[0, 1, 2].map((b) => (
                      <i
                        key={b}
                        className="w-[3px] rounded-[1px]"
                        style={{
                          height: 4 + b * 4,
                          background: b < STANCE[k].bars ? STANCE[k].color : "rgba(236,230,248,0.16)",
                        }}
                      />
                    ))}
                  </span>
                  {STANCE[k].zh} ×{DOUBTS.filter((d) => d.stance === k).length}
                </span>
              ))}
            </div>
          </div>
        </Reveal>

        <div className="space-y-3">
          {DOUBTS.map((d, i) => (
            <DoubtCard key={d.id} d={d} i={i} />
          ))}
        </div>
      </section>

      {/* suggestions */}
      <section className="mt-20">
        <Reveal>
          <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
            <div className="flex flex-wrap items-end gap-x-5 gap-y-2">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-lg border border-emerald-glow/40 bg-emerald-glow/10 text-[22px] text-emerald-glow">
                !
              </span>
              <div>
                <div className="font-mono text-[10.5px] tracking-[0.26em] text-emerald-glow">PART II</div>
                <h2 className="font-cjk-display engraved text-[clamp(1.35rem,3vw,2rem)] leading-tight font-bold text-parchment">
                  二十一条建议，按投入产出排序
                </h2>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {(Object.keys(PRIO) as (keyof typeof PRIO)[]).map((p) => {
                const on = prio.has(p);
                const c = PRIO[p].color;
                return (
                  <button
                    key={p}
                    type="button"
                    onClick={() => toggle(p)}
                    className="rounded-full border px-3 py-1 font-mono text-[10.5px] tracking-[0.1em] uppercase transition-all duration-300 active:scale-95"
                    style={{
                      color: on ? "#0b0813" : c,
                      borderColor: `${c}${on ? "ff" : "55"}`,
                      background: on ? c : `${c}12`,
                      boxShadow: on ? `0 0 14px -2px ${c}` : "none",
                    }}
                  >
                    {p} · {byPrio[p]}
                  </button>
                );
              })}
            </div>
          </div>
        </Reveal>

        <Reveal delay={50}>
          <div className="mb-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {(Object.keys(PRIO) as (keyof typeof PRIO)[]).map((p) => (
              <div key={p} className="plate rounded-lg px-4 py-3">
                <div className="flex items-baseline justify-between">
                  <span className="font-display text-[1.35rem] leading-none font-bold" style={{ color: PRIO[p].color }}>
                    {p}
                  </span>
                  <span className="tnum font-mono text-[11px] text-parchment-faint">{byPrio[p]} 条</span>
                </div>
                <div className="font-cjk-display mt-1.5 text-[13px] font-bold text-parchment">{PRIO[p].zh}</div>
                <div className="mt-2">
                  <Meter value={byPrio[p]} max={6} color={PRIO[p].color} height={4} />
                </div>
                <p className="mt-2 text-[11px] leading-relaxed text-parchment-faint">{PRIO[p].note}</p>
              </div>
            ))}
          </div>
        </Reveal>

        <ol className="space-y-2.5">
          {list.map((s, i) => {
            const c = PRIO[s.priority].color;
            return (
              <Reveal as="li" key={s.id} delay={Math.min(i, 8) * 40}>
                <div className="plate plate-hover group grid gap-4 rounded-lg p-4 sm:grid-cols-[auto_minmax(0,1fr)] sm:p-5">
                  <div className="flex items-start gap-3 sm:flex-col sm:items-center sm:gap-2">
                    <span
                      className="grid h-11 w-11 shrink-0 place-items-center rounded-lg border font-display text-[15px] font-bold transition-transform duration-400 group-hover:scale-110"
                      style={{ color: c, borderColor: `${c}4d`, background: `${c}12`, boxShadow: `0 0 18px -8px ${c}` }}
                    >
                      {s.priority}
                    </span>
                    <span className="font-mono text-[10px] tracking-[0.12em] text-parchment-faint sm:text-center">
                      {s.id}
                    </span>
                  </div>

                  <div className="min-w-0">
                    <h3 className="font-cjk-display text-[15.5px] leading-snug font-bold text-parchment">
                      {s.title}
                    </h3>
                    <p className="mt-2 text-[13px] leading-[1.8] text-parchment-dim">{s.what}</p>
                    <div className="mt-3 grid gap-2.5 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
                      <div className="flex flex-wrap items-center gap-1.5">
                        <span className="font-mono text-[9.5px] tracking-[0.16em] text-parchment-faint uppercase">
                          对应条目
                        </span>
                        {s.refs.map((r) => {
                          const isTxt = r.startsWith("TXT");
                          const isD = r.startsWith("D-");
                          return (
                            <button
                              key={r}
                              type="button"
                              onClick={() => {
                                go(isTxt ? "text" : isD ? "doubt" : "audit");
                                if (!isD)
                                  setTimeout(
                                    () =>
                                      document
                                        .getElementById(isTxt ? `finding-${r}` : `finding-${r}`)
                                        ?.scrollIntoView({ behavior: "smooth", block: "center" }),
                                    100,
                                  );
                              }}
                              className="rounded border px-1.5 py-[1px] font-mono text-[10px] tracking-[0.06em] transition-all hover:brightness-150"
                              style={{
                                color: isTxt ? "#a46ee5" : isD ? "#ffd66b" : "#9dc0ff",
                                borderColor: isTxt ? "#a46ee53d" : isD ? "#ffd66b3d" : "#9dc0ff3d",
                                background: isTxt ? "#a46ee50f" : isD ? "#ffd66b0f" : "#9dc0ff0f",
                              }}
                            >
                              {r} ↗
                            </button>
                          );
                        })}
                      </div>
                      <div className="rounded border border-emerald-glow/25 bg-emerald-glow/8 px-2.5 py-1.5 text-[11px] leading-relaxed text-emerald-glow/90">
                        <span className="font-mono text-[9.5px] tracking-[0.14em] uppercase opacity-70">cost · </span>
                        {s.cost}
                      </div>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </ol>
      </section>

      {/* the five things */}
      <section className="mt-20">
        <Reveal>
          <div className="plate relative overflow-hidden rounded-xl p-5 sm:p-7">
            <div className="pointer-events-none absolute inset-0 glint-sweep opacity-60" />
            <div className="relative">
              <div className="font-mono text-[10px] tracking-[0.24em] text-amethyst-400 uppercase">
                if you only do five things
              </div>
              <h3 className="font-cjk-display engraved mt-2 text-[clamp(1.4rem,3vw,2.1rem)] leading-tight font-bold text-parchment">
                不到一天的工作量，覆盖最贵的风险
              </h3>
              <Rule className="my-5" color="#a46ee5" />
              <ol className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
                {SUGGESTIONS.slice(0, 5).map((s, i) => (
                  <li key={s.id} className="group relative rounded-lg border border-lapis-400/18 bg-obsidian-950/55 p-4 transition-all duration-400 hover:-translate-y-1 hover:border-amethyst-400/45">
                    <span className="tnum font-display text-[2rem] leading-none font-bold text-amethyst-400/30 transition-colors group-hover:text-amethyst-400/80">
                      {i + 1}
                    </span>
                    <div className="font-cjk-display mt-2 text-[13.5px] leading-snug font-bold text-parchment">
                      {s.title}
                    </div>
                    <div className="mt-2 font-mono text-[10px] tracking-[0.1em] text-emerald-glow/80">
                      {s.refs.join(" · ")}
                    </div>
                  </li>
                ))}
              </ol>
              <p className="mt-6 max-w-4xl text-[13.5px] leading-[1.85] text-parchment-dim">
                这五条加起来不到一天：
                <Code>removeItemNoUpdate</Code> 的一行语义修正、
                两处 <Code>\uD83D\uDD12</Code> 换成仓库里已经 shipped 的贴图、
                约 30 行 Python 的 lang 门升级、README 首屏与 fabric.mod.json 的两处数字、
                以及配置 token 去版本化。
                它们覆盖了本次审计里 <span className="text-sev-crit">1 条严重</span>、
                <span className="text-sev-high"> 4 条高危</span>，以及
                <span className="text-amethyst-300">全部三条「宣称与现实不符」</span>——
                而这三条恰好是最伤信任的，因为它们不需要玩游戏就能被发现。
              </p>
            </div>
          </div>
        </Reveal>
      </section>

      {/* closing note */}
      <Reveal delay={60}>
        <div className="mt-10 rounded-xl border border-white/8 bg-obsidian-900/45 p-5 sm:p-6">
          <div className="font-mono text-[10px] tracking-[0.24em] text-parchment-faint uppercase">
            a closing note on fairness
          </div>
          <p className="mt-3 text-[13.5px] leading-[1.9] text-parchment-dim">
            最后一点必须说清楚：这个仓库的开发条件<span className="text-parchment">异常艰苦</span>——
            没有 JDK、连不上 <Code>maven.fabricmc.net</Code>、每次编译都要靠 GitHub Actions 再把日志推回分支，
            连 Actions 的日志 blob 都从沙箱里取不到。在这样的约束下，作者仍然建立了
            生成式单一真相源、逐字节 CI 校验、版本化协议通道、11 个语言包的 key 完整性门、
            markdown 悬空链接的 warn 门，以及 21 份记录了每一次失败与教训的报告。
            本页的每一条怀疑都应该放在这个背景下读：
            <span className="text-emerald-glow">它们说的是「再往前一步能到哪里」，不是「现在做得差」。</span>
            事实上，本次审计里所有严重与高危条目，成因几乎都不是能力问题，
            而是<span className="text-parchment">验证手段的缺失</span>——
            而验证手段的缺失，正是那个沙箱直接造成的。
          </p>
        </div>
      </Reveal>
    </div>
  );
}
