import { useMemo, useState } from "react";
import { cn } from "../utils/cn";
import {
  FINDINGS,
  PATHS,
  SEV_META,
  type Finding,
  type Severity,
} from "../data/findings";
import { Code, CodeBlock, Reveal, SevPill, Tag } from "../components/ui";

/* ------------------------------------------------------------- one finding */

function FindingCard({ f, i }: { f: Finding; i: number }) {
  const [open, setOpen] = useState(f.severity === "crit" || f.severity === "good");
  const m = SEV_META[f.severity];
  const path = PATHS.find((p) => p.key === f.path)!;

  return (
    <Reveal as="article" delay={Math.min(i, 6) * 45} className="scroll-mt-28">
      <div
        id={`finding-${f.id}`}
        className="plate group relative overflow-hidden rounded-lg transition-all duration-400"
        style={open ? { borderColor: `${m.color}44` } : undefined}
      >
        <span
          className="absolute inset-y-0 left-0 w-[2.5px] transition-all duration-500"
          style={{
            background: `linear-gradient(180deg, ${m.color}, ${path.accent})`,
            boxShadow: open ? `0 0 16px -2px ${m.color}` : "none",
            opacity: open ? 1 : 0.55,
          }}
        />

        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          className="flex w-full items-start gap-4 px-4 py-4 pl-5 text-left sm:px-5 sm:pl-6"
          aria-expanded={open}
        >
          <span className="mt-[3px] shrink-0 font-mono text-[11px] tracking-[0.1em]" style={{ color: m.color }}>
            {f.id}
          </span>

          <span className="min-w-0 flex-1">
            <span className="flex flex-wrap items-center gap-2">
              <SevPill sev={f.severity} />
              <Tag color={path.accent}>{path.zh}</Tag>
              {f.versionBound && <Tag color="#ffa24d">版本敏感</Tag>}
            </span>
            <span className="font-cjk-display mt-2 block text-[15.5px] leading-snug font-bold text-parchment transition-colors group-hover:text-white sm:text-[16.5px]">
              {f.title}
            </span>
            <span className="mt-1.5 block font-mono text-[10.5px] leading-relaxed break-all text-parchment-faint">
              {f.where[0]}
            </span>
          </span>

          <span
            className={cn(
              "mt-1 grid h-6 w-6 shrink-0 place-items-center rounded border text-[11px] transition-all duration-400",
              open ? "rotate-45" : "rotate-0 group-hover:rotate-90",
            )}
            style={{ color: m.color, borderColor: `${m.color}44`, background: `${m.color}10` }}
          >
            +
          </span>
        </button>

        <div
          className="grid transition-[grid-template-rows] duration-500 ease-[cubic-bezier(.16,1,.3,1)]"
          style={{ gridTemplateRows: open ? "1fr" : "0fr" }}
        >
          <div className="overflow-hidden">
            <div className="space-y-4 border-t border-white/6 px-4 pt-4 pb-5 pl-5 sm:px-5 sm:pl-6">
              {f.where.length > 1 && (
                <Block label="位置" color="#9dc0ff">
                  <ul className="space-y-1">
                    {f.where.map((w) => (
                      <li key={w} className="flex gap-2 font-mono text-[11px] leading-relaxed break-all text-lapis-300/85">
                        <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-lapis-400/60" />
                        {w}
                      </li>
                    ))}
                  </ul>
                </Block>
              )}

              <Block label="证据" color="#d99b38">
                <p className="text-[13.5px] leading-[1.8] text-parchment-dim">{f.evidence}</p>
              </Block>

              <Block label="影响" color={m.color}>
                <p className="text-[13.5px] leading-[1.8] text-parchment-dim">{f.impact}</p>
              </Block>

              {f.versionBound && (
                <Block label="版本相关性" color="#ffa24d">
                  <p className="text-[13px] leading-[1.8] text-parchment-dim">{f.versionBound}</p>
                </Block>
              )}

              <Block label="建议" color="#43c59e">
                <p className="text-[13.5px] leading-[1.8] text-parchment">{f.fix}</p>
              </Block>

              {f.probe && (
                <CodeBlock label="复核命令 · 可在仓库根目录直接运行">{f.probe}</CodeBlock>
              )}
            </div>
          </div>
        </div>
      </div>
    </Reveal>
  );
}

function Block({
  label,
  color,
  children,
}: {
  label: string;
  color: string;
  children: React.ReactNode;
}) {
  return (
    <div className="grid gap-2 sm:grid-cols-[64px_minmax(0,1fr)]">
      <div
        className="pt-[3px] font-mono text-[10px] tracking-[0.16em] uppercase"
        style={{ color }}
      >
        {label}
      </div>
      <div className="min-w-0">{children}</div>
    </div>
  );
}

/* ------------------------------------------------------------------- page */

const SEV_ORDER: Severity[] = ["crit", "high", "med", "low", "info", "good"];

export default function AuditPage() {
  const [sevFilter, setSevFilter] = useState<Set<Severity>>(new Set());
  const [q, setQ] = useState("");

  const toggleSev = (s: Severity) =>
    setSevFilter((prev) => {
      const n = new Set(prev);
      n.has(s) ? n.delete(s) : n.add(s);
      return n;
    });

  const visible = useMemo(
    () =>
      FINDINGS.filter((f) => {
        if (sevFilter.size && !sevFilter.has(f.severity)) return false;
        if (q.trim()) {
          const hay = (f.id + f.title + f.evidence + f.impact + f.fix + f.where.join(" ")).toLowerCase();
          if (!hay.includes(q.trim().toLowerCase())) return false;
        }
        return true;
      }),
    [sevFilter, q],
  );

  const counts = useMemo(() => {
    const c: Record<Severity, number> = { crit: 0, high: 0, med: 0, low: 0, info: 0, good: 0 };
    FINDINGS.forEach((f) => c[f.severity]++);
    return c;
  }, []);

  return (
    <div className="relative mx-auto max-w-[1400px] px-4 pt-24 pb-24 sm:px-7 sm:pt-28">
      {/* head */}
      <Reveal>
        <div className="mb-3 flex items-center gap-3">
          <span className="font-mono text-[11px] tracking-[0.3em] text-lapis-400">AUDIT</span>
          <span className="h-px flex-1 bg-gradient-to-r from-lapis-400/50 to-transparent" />
          <span className="tnum font-mono text-[11px] text-parchment-faint">
            {visible.length} / {FINDINGS.length}
          </span>
        </div>
        <h1 className="font-cjk-display engraved text-[clamp(2rem,5vw,3.4rem)] leading-[1.05] font-black text-parchment">
          七条路径，逐条追到底
        </h1>
        <p className="mt-4 max-w-3xl text-[14.5px] leading-[1.85] text-parchment-dim">
          每一条都写清 <span className="text-lapis-300">位置</span>、
          <span className="text-gold-glow">证据</span>、
          <span className="text-parchment">影响</span> 与{" "}
          <span className="text-emerald-glow">建议</span>；能给出复核命令的都给了。
          两条 <SevPill sev="good" className="align-middle" /> 是刻意保留的正向结论——
          服务端权威模型与 WIKI 数值公式的三方核对，是这份代码里最经得起推敲的部分。
        </p>
      </Reveal>

      {/* sticky filter rail */}
      <div className="sticky top-[52px] z-30 -mx-4 mb-8 border-y border-lapis-400/14 bg-obsidian-950/85 px-4 py-2.5 backdrop-blur-xl sm:-mx-7 sm:px-7">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="mr-1 font-mono text-[10px] tracking-[0.18em] text-parchment-faint uppercase">
              severity
            </span>
            {SEV_ORDER.map((s) => {
              const on = sevFilter.has(s);
              const m = SEV_META[s];
              return (
                <button
                  key={s}
                  type="button"
                  onClick={() => toggleSev(s)}
                  className={cn(
                    "rounded-full border px-2.5 py-[3px] font-mono text-[10px] tracking-[0.1em] uppercase transition-all duration-300 active:scale-95",
                    on ? "text-obsidian-950" : "hover:brightness-125",
                  )}
                  style={{
                    color: on ? "#0b0813" : m.color,
                    borderColor: `${m.color}${on ? "ff" : "55"}`,
                    background: on ? m.color : `${m.color}12`,
                    boxShadow: on ? `0 0 14px -2px ${m.color}` : "none",
                  }}
                >
                  {m.zh} {counts[s]}
                </button>
              );
            })}
            {sevFilter.size > 0 && (
              <button
                type="button"
                onClick={() => setSevFilter(new Set())}
                className="ml-1 font-mono text-[10px] text-parchment-faint underline decoration-dotted hover:text-parchment"
              >
                clear
              </button>
            )}
          </div>

          <label className="ml-auto flex items-center gap-2 rounded-md border border-lapis-400/20 bg-obsidian-900/70 px-2.5 py-1 transition-colors focus-within:border-amethyst-400/60">
            <span className="font-mono text-[11px] text-parchment-faint">⌕</span>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="过滤：ID / 文件 / 关键词"
              className="w-40 bg-transparent font-mono text-[11.5px] text-parchment placeholder:text-parchment-faint/60 focus:outline-none sm:w-56"
            />
            {q && (
              <button
                type="button"
                onClick={() => setQ("")}
                className="font-mono text-[11px] text-parchment-faint hover:text-sev-crit"
              >
                ✕
              </button>
            )}
          </label>
        </div>

        <div className="mt-2 hidden flex-wrap gap-1.5 md:flex">
          {PATHS.map((p) => (
            <a
              key={p.key}
              href={`#path-${p.key}`}
              onClick={(e) => {
                e.preventDefault();
                document.getElementById(`path-${p.key}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
              }}
              className="group inline-flex items-center gap-1.5 rounded border px-2 py-[2px] font-mono text-[10px] tracking-[0.08em] transition-all hover:brightness-150"
              style={{ color: p.accent, borderColor: `${p.accent}33`, background: `${p.accent}0d` }}
            >
              <span className="opacity-60">{p.idx}</span>
              <span className="font-cjk-display text-[11px] tracking-normal">{p.zh}</span>
              <span className="tnum opacity-60">
                {FINDINGS.filter((f) => f.path === p.key).length}
              </span>
            </a>
          ))}
        </div>
      </div>

      {/* sections */}
      <div className="space-y-16">
        {PATHS.map((p) => {
          const list = FINDINGS.filter((f) => f.path === p.key).filter((f) => visible.includes(f));
          const all = FINDINGS.filter((f) => f.path === p.key);
          return (
            <section key={p.key} id={`path-${p.key}`} className="scroll-mt-32">
              <Reveal>
                <div className="mb-5 flex flex-wrap items-end gap-x-5 gap-y-3">
                  <span
                    className="grid h-12 w-12 shrink-0 place-items-center rounded-lg border text-[22px]"
                    style={{ color: p.accent, borderColor: `${p.accent}44`, background: `${p.accent}10` }}
                  >
                    {p.glyph}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                      <span className="font-mono text-[10.5px] tracking-[0.26em]" style={{ color: p.accent }}>
                        {p.idx}
                      </span>
                      <h2 className="font-cjk-display engraved text-[clamp(1.35rem,3vw,2rem)] leading-tight font-bold text-parchment">
                        {p.zh}
                      </h2>
                      <span className="font-mono text-[10px] tracking-[0.18em] text-parchment-faint uppercase">
                        {p.en}
                      </span>
                    </div>
                    <p className="mt-1.5 max-w-3xl text-[13px] leading-relaxed text-parchment-dim">
                      {p.blurb}
                    </p>
                  </div>
                  <div className="tnum shrink-0 rounded-lg border px-3 py-2 text-center"
                    style={{ borderColor: `${p.accent}33`, background: `${p.accent}0d` }}
                  >
                    <div className="font-display text-[1.5rem] leading-none font-bold" style={{ color: p.accent }}>
                      {all.length}
                    </div>
                    <div className="mt-1 font-mono text-[9px] tracking-[0.16em] text-parchment-faint uppercase">
                      findings
                    </div>
                  </div>
                </div>
                <div className="mb-5 h-px w-full" style={{ background: `linear-gradient(90deg, ${p.accent}66, transparent)` }} />
              </Reveal>

              {list.length === 0 ? (
                <p className="rounded-lg border border-dashed border-white/12 px-4 py-6 text-center font-mono text-[11.5px] text-parchment-faint">
                  当前筛选下这条路径没有条目 · 共 {all.length} 条
                </p>
              ) : (
                <div className="space-y-2.5">
                  {list.map((f, i) => (
                    <FindingCard key={f.id} f={f} i={i} />
                  ))}
                </div>
              )}
            </section>
          );
        })}
      </div>

      {/* hardcode ledger */}
      <section className="mt-20 scroll-mt-28" id="hardcode-ledger">
        <Reveal>
          <div className="mb-5 flex flex-wrap items-end gap-x-5 gap-y-2">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-lg border border-sev-high/40 bg-sev-high/10 text-[22px] text-sev-high">
              ⌗
            </span>
            <div>
              <div className="font-mono text-[10.5px] tracking-[0.26em] text-sev-high">09</div>
              <h2 className="font-cjk-display engraved text-[clamp(1.35rem,3vw,2rem)] leading-tight font-bold text-parchment">
                硬编码总账
              </h2>
            </div>
            <p className="w-full max-w-3xl text-[13px] leading-relaxed text-parchment-dim sm:w-auto sm:flex-1">
              用户特别问到「可能不应该硬编码的地方」。这张表把所有在 Java 里以字面量形式存在、
              而按其性质本应由数据包/构建期注入/常量集中管理的值列在一起——
              注意仓库<span className="text-emerald-glow">已经有</span>一套做得很好的机制
              （<Code>BundledDefaults</Code> 由 JSON 生成 + CI 逐字节校验），
              下表全部是<span className="text-parchment">这套机制没有覆盖到</span>的部分。
            </p>
          </div>
        </Reveal>

        <Reveal delay={80}>
          <div className="overflow-x-auto rounded-lg border border-lapis-400/15">
            <table className="w-full min-w-[820px] border-collapse text-left">
              <thead>
                <tr className="bg-obsidian-850/80 font-mono text-[10px] tracking-[0.16em] text-parchment-faint uppercase">
                  <th className="px-3.5 py-2.5 font-medium">硬编码值</th>
                  <th className="px-3.5 py-2.5 font-medium">所在文件</th>
                  <th className="px-3.5 py-2.5 font-medium">本该在哪里</th>
                  <th className="px-3.5 py-2.5 font-medium">条目</th>
                </tr>
              </thead>
              <tbody className="font-mono text-[11px]">
                {[
                  ["24 张 chests/* 战利品表 ID + 概率 + 数量", "DepletedTomeWorldMechanics.EXACT_CHEST_SPECS", "loot_injections.json（新增 chest_spawn_specs 段）", "CODEC-06"],
                  ["10 个魔咒 ID（protection / sharpness / …）", "InscriptionRitualMechanics.HIGH_APPLICABILITY_IDS", "#chiseled_enchanting_table:broad_applicability（已存在）", "COUP-01"],
                  ["1.45 · 1.00 · 0.18 · 1.15（稀有度倍率）", "DisenchantmentApplication.rarityMultiplier", "library_resonance.json（新增 essence_valuation 段）", "BAL-01"],
                  ["5（守恒安全边际）", "DisenchantmentApplication.CONSERVATION_SAFETY_MARGIN_POINTS", "同上，并在 GUI 的 EXPERIENCE_ECONOMY 域可见", "BAL-01"],
                  ["0.42 · 24.0 · 2.35（普适度广度参考与钳位）", "InscriptionRitualMechanics.computeApplicabilityFactor", "library_resonance.json / ritual 段", "BAL-02"],
                  ["1.55 · 1.32 · 1.20 · 1.18 · 1.12 · 1.05（keystone / rarity 档位）", "同上", "分级标签或 JSON 的 id→系数映射", "BAL-03"],
                  ["0.1875 · 0.3125 · 0.72 · 0.28 · 0.5（槽位几何，忽略 FACING）", "TomeParticleEffects.burst", "由 BlockState 的朝向 + 原版槽位向量推导", "COUP-07"],
                  ["64（附魔书堆叠上限，3 处独立写死）", "ChiseledEnchantingTable / EnchantingProtocol.Capability / Preset.applyTo", "单一常量或 BundledDefaults", "API-05"],
                  ["\"1.1.0\" / \"1.0.3\"（配置 token 与枚举名）", "ModRuntimeConfig.Preset.fromToken / CostTableDataset", "与版本无关的稳定 token + LEGACY_ALIASES", "CODEC-01"],
                  ["\"Minecraft 26.1.2\"（断线理由）", "EnchantingProtocol.MISMATCH_MESSAGE", "processResources 从 gradle.properties 注入", "NET-02 / TXT-08"],
                  ["\"1.0.3: \" / \"1.1.0: \"（GUI 溯源标签）", "ChiseledEnchantingConfigScreen:1775-1778", "lang key + BuildInfo 参数", "TXT-09"],
                  ["16 个 revision 常量 + 2 个 probe 列表", "EnchantingProtocol", "一个 int + id(base, rev) 生成函数", "NET-01"],
                  ["textures/misc/enchanted_glint_{item,armor}.png", "IrisGlintPreload（且注释写的是 MC 26.3）", "运行时查询 / 版本守卫，或直接删除", "DEAD-01"],
                  ["40（搜索框长度上限，按 UTF-16 unit 计）", "ChiseledEnchantingConfigScreen.charTyped", "命名常量 + codePointCount", "GUI-01"],
                  ["🔒 U+1F512（超出 BMP，渲染为缺字方块）", "ChiseledEnchantingConfigScreen:1224,1480", "已 shipped 的 toggle_locked.png", "GUI-06"],
                  ["900_000 / 8_192 / 96（payload 字节估算）", "PayloadLimits", "发送前真实编码测长 + 逐级降级", "CODEC-05"],
                ].map(([v, w, s, id], i) => (
                  <tr
                    key={id + i}
                    className={cn(
                      "border-t border-lapis-400/8 align-top transition-colors hover:bg-lapis-500/8",
                      i % 2 === 1 && "bg-obsidian-900/35",
                    )}
                  >
                    <td className="px-3.5 py-2.5 text-[11px] leading-relaxed text-parchment">{v}</td>
                    <td className="px-3.5 py-2.5 text-[10.5px] leading-relaxed break-all text-lapis-300/80">{w}</td>
                    <td className="px-3.5 py-2.5 text-[10.5px] leading-relaxed text-emerald-glow/85">{s}</td>
                    <td className="px-3.5 py-2.5 whitespace-nowrap text-[10px] text-sev-high">{id}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <p className="mt-4 text-[13px] leading-relaxed text-parchment-dim">
            <span className="text-gold-glow">一个判据：</span>
            如果这个值改动后，整合包作者或服务器管理员<span className="text-parchment">必须等一次 CI + 一次 release</span>{" "}
            才能拿到，它就属于「不该硬编码」。上表 16 行里有 11 行符合这个判据；
            剩下 5 行（payload 估算常数、搜索框上限、断线文案里的版本号、协议 revision 列表、粒子几何）
            属于「该集中管理但不必数据化」——把它们收进单一常量/生成函数即可。
          </p>
        </Reveal>
      </section>
    </div>
  );
}
