import { useEffect } from "react";
import Ambient from "./components/Ambient";
import Nav, { useRoute } from "./components/Nav";
import OverviewPage from "./pages/OverviewPage";
import AuditPage from "./pages/AuditPage";
import TextPage from "./pages/TextPage";
import DoubtPage from "./pages/DoubtPage";
import { REPO_META } from "./data/findings";

function Footer() {
  return (
    <footer className="relative z-10 border-t border-lapis-400/14 bg-obsidian-950/70">
      <div className="mx-auto max-w-[1400px] px-4 py-9 sm:px-7">
        <div className="grid gap-7 md:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)_minmax(0,1fr)]">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="grid h-7 w-7 place-items-center rounded border border-amethyst-400/40 font-display text-[13px] text-lapis-300">
                ᛝ
              </span>
              <span className="font-display text-[12.5px] font-bold tracking-[0.16em] text-parchment uppercase">
                Chiseled Audit
              </span>
            </div>
            <p className="mt-3 max-w-md text-[12.5px] leading-relaxed text-parchment-faint">
              独立第三方源码审计。与{" "}
              <span className="text-parchment-dim">{REPO_META.upstream}</span> 及{" "}
              <span className="text-parchment-dim">{REPO_META.owner}</span>{" "}
              均无隶属关系；被审计项目本身也是非官方社区移植。所有结论均可用页内给出的命令在仓库根目录复核。
            </p>
          </div>

          <div>
            <div className="font-mono text-[10px] tracking-[0.2em] text-parchment-faint uppercase">
              audited snapshot
            </div>
            <dl className="mt-3 space-y-1.5 font-mono text-[11px]">
              {[
                ["branch", REPO_META.branch],
                ["mod_version", REPO_META.modVersion],
                ["target", `Minecraft ${REPO_META.mcVersion}`],
                ["protocol", REPO_META.protocolRevision],
              ].map(([k, v]) => (
                <div key={k} className="flex gap-2">
                  <dt className="shrink-0 text-parchment-faint">{k}</dt>
                  <dd className="min-w-0 break-all text-lapis-300/85">{v}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div>
            <div className="font-mono text-[10px] tracking-[0.2em] text-parchment-faint uppercase">
              scope & limits
            </div>
            <ul className="mt-3 space-y-1.5 text-[12px] leading-relaxed text-parchment-faint">
              <li>· 静态阅读，无 JDK / 无 Minecraft 运行时</li>
              <li>· mixin 目标签名未在 26.1.2 上验证</li>
              <li>· 渲染结果与测试执行未验证</li>
              <li>· 数值公式全部独立复算</li>
              <li>· 11 × 959 条 lang 值逐条比对</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 flex flex-wrap items-center justify-between gap-3 border-t border-white/6 pt-5 font-mono text-[10px] tracking-[0.12em] text-parchment-faint uppercase">
          <span>
            {REPO_META.javaFiles} java · {REPO_META.locJava.toLocaleString()} loc ·{" "}
            {REPO_META.jsonFiles} json · {REPO_META.mixins} mixins · {REPO_META.langKeys} keys ×{" "}
            {REPO_META.langFiles} locales
          </span>
          <a
            href="https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/tree/arena%2Fb99a37c2-chiseled-enchanting-table-26-1"
            target="_blank"
            rel="noreferrer noopener"
            className="link-underline hover:text-emerald-glow"
          >
            view the audited branch ↗
          </a>
        </div>
      </div>
    </footer>
  );
}

export default function App() {
  const [route, go] = useRoute();

  useEffect(() => {
    const titles: Record<string, string> = {
      overview: "雕纹审计台 · Chiseled Enchanting Table 26.1.2 源码审计",
      audit: "七路径审计 · 雕纹审计台",
      text: "文本三重审查 · 雕纹审计台",
      doubt: "怀疑与建议 · 雕纹审计台",
    };
    document.title = titles[route] ?? titles.overview;
  }, [route]);

  return (
    <div className="relative min-h-screen">
      <Ambient />
      <Nav route={route} go={go} />

      <main className="relative z-10" key={route}>
        {route === "overview" && <OverviewPage go={go} />}
        {route === "audit" && <AuditPage />}
        {route === "text" && <TextPage />}
        {route === "doubt" && <DoubtPage go={go} />}
      </main>

      <div className="relative z-10">
        <Footer />
      </div>
    </div>
  );
}
