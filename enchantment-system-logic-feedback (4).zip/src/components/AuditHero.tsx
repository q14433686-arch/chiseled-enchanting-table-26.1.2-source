import { motion } from "framer-motion";
import {
  ShieldAlert,
  Code2,
  Scale,
  FileWarning,
  ExternalLink,
  GitBranch,
  ChevronDown,
} from "lucide-react";

const SUMMARY_CARDS = [
  {
    icon: ShieldAlert,
    badge: "P0 · 实锤漏洞 × 3",
    title: "原版魔咒正收益刷经验",
    desc: "冰霜行者 I⇄II 单轮净赚 +12pt、火焰附加/击退 +6pt、迅捷潜行 II⇄III +4pt；compat_check.py 因内嵌过时公式且漏检增量路径而误判绿灯。",
    tone: "#f08cc8",
    href: "#arbitrage",
  },
  {
    icon: Scale,
    badge: "P0 · 核心机制击穿",
    title: "双轨越界 & 残卷未去重",
    desc: "withWoodenShelfBoost 把 38 木架直通白板满级，架空雕纹书架母本；残卷梯度三未按魔咒去重，6 本 0 架刻出的「击退 I」即可白嫖免费档。",
    tone: "#e8c37c",
    href: "#mechanism",
  },
  {
    icon: Code2,
    badge: "P0–P2 · 硬编码 × 10",
    title: "标签分裂与常数锁死",
    desc: "粒子认 #enchantment_power_provider 但算力写死 Blocks.BOOKSHELF；JEI 绕过 S2C 同步；附魔书 64 堆叠无开关；未冻结拆台污染堆叠。",
    tone: "#7ee8dc",
    href: "#hardcode",
  },
  {
    icon: FileWarning,
    badge: "P2–P3 · 漂移 × 5",
    title: "文档、JEI 与数据包脱节",
    desc: "CHANGELOG 承诺的纯原版单洗替代在 JSON 中并不存在且被 CI 锁死；JEI 将附魔书全洗产物错标为普通书而非褪魔残卷。",
    tone: "#a18cff",
    href: "#drift",
  },
];

const AuditHero = () => (
  <header className="relative min-h-[92svh] flex flex-col justify-between overflow-hidden pt-20">
    <div className="absolute inset-0 grid-paper" />
    <div
      className="absolute inset-0 pointer-events-none"
      style={{
        background:
          "radial-gradient(1000px 500px at 50% 14%, rgba(240,140,200,0.13), transparent 65%), radial-gradient(800px 460px at 85% 85%, rgba(126,232,220,0.08), transparent 60%)",
      }}
    />

    <div className="relative z-10 max-w-6xl mx-auto w-full px-6 md:px-10 pt-8 pb-10">
      {/* Branch pill */}
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex flex-wrap items-center gap-3 mb-7"
      >
        <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-sm bg-inkd/12 border border-inkd/35 font-code text-[11px] text-inkd tracking-wider">
          <GitBranch size={13} />
          arena/d0fffdab-chiseled-enchanting-table-26-1
        </span>
        <span className="font-code text-[11px] text-mute tracking-widest">
          MC 26.1.2 · JAVA 25 · 全仓源码与数据包逐行审计报告
        </span>
        <a
          href="https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/tree/arena%2Fd0fffdab-chiseled-enchanting-table-26-1"
          target="_blank"
          rel="noreferrer"
          className="ml-auto inline-flex items-center gap-1.5 font-code text-[11px] text-gild hover:underline"
        >
          查看被审分支源码
          <ExternalLink size={12} />
        </a>
      </motion.div>

      {/* Main Headline */}
      <motion.h1
        initial={{ opacity: 0, y: 26 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.85, delay: 0.08, ease: [0.22, 1, 0.36, 1] }}
        className="font-display font-black leading-[1.08] text-parch"
        style={{ fontSize: "clamp(2.4rem, 6.4vw, 5.2rem)" }}
      >
        工程完成度很高，
        <br />
        但有<span className="text-inkd">三道硬伤</span>必须拦在合入前。
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="mt-6 max-w-3xl text-sm md:text-[15.5px] leading-8 text-mute font-light"
      >
        我们对分支 <span className="font-code text-parch text-xs">arena/d0fffdab</span> 的全部核心类
        （<span className="font-code text-xs text-tealw">XpCostConversion</span>、
        <span className="font-code text-xs text-tealw">DisenchantmentApplication</span>、
        <span className="font-code text-xs text-tealw">BookshelfProgression</span>、
        <span className="font-code text-xs text-tealw">ChiseledEnchantingTableBlock</span>、
        <span className="font-code text-xs text-tealw">ScreenHandler</span>、
        <span className="font-code text-xs text-tealw">TransformationQueryIndex</span> 及
        <span className="font-code text-xs text-tealw">compat_check.py</span>）做了静态走查与精确数值建模。
        双页签 UI、S2C 同步骨架与相对品阶抽象底子都很扎实，但在<span className="text-parch font-medium">增量升阶与降级对偶守恒</span>、
        <span className="text-parch font-medium">木书架越界直附</span>、<span className="text-parch font-medium">残卷高阶词条去重</span>与
        <span className="text-parch font-medium">跨模组标签硬编码</span>上存在实锤漏洞。
      </motion.p>

      {/* 4 Anchor Cards */}
      <div className="mt-11 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {SUMMARY_CARDS.map((c, idx) => (
          <motion.a
            key={c.title}
            href={c.href}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.28 + idx * 0.08 }}
            className="group pixelframe bg-vellum/70 border p-5 flex flex-col justify-between hover:bg-vellum2/85 hover:-translate-y-1 transition-all duration-300"
            style={{ borderColor: `${c.tone}38` }}
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-3">
                <span
                  className="font-code text-[10px] px-2 py-0.5 rounded-sm tracking-wider"
                  style={{
                    color: c.tone,
                    background: `${c.tone}14`,
                    border: `1px solid ${c.tone}38`,
                  }}
                >
                  {c.badge}
                </span>
                <c.icon
                  size={17}
                  style={{ color: c.tone }}
                  className="group-hover:scale-110 transition-transform"
                />
              </div>
              <p className="font-display font-bold text-lg text-parch mb-2">{c.title}</p>
              <p className="text-[12px] leading-5.5 text-mute font-light">{c.desc}</p>
            </div>
            <span
              className="mt-4 font-code text-[10.5px] tracking-widest opacity-75 group-hover:opacity-100"
              style={{ color: c.tone }}
            >
              定位代码与验证 →
            </span>
          </motion.a>
        ))}
      </div>
    </div>

    <motion.div
      className="relative z-10 flex justify-center pb-6"
      animate={{ y: [0, 7, 0] }}
      transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
    >
      <ChevronDown size={18} className="text-faint" />
    </motion.div>
  </header>
);

export default AuditHero;
