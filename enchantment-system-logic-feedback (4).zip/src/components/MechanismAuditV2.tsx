import { useMemo, useState } from "react";
import { CheckCircle2, TriangleAlert, Library, Zap, Gauge } from "lucide-react";
import {
  directShelfRequirement,
  shelfGateStats,
  scanVolume,
  TRANSFORMATION_XP_EXAMPLES,
  currentTransformationXp,
  RESOLVED_SINCE_LAST_REVIEW,
} from "../lib/currentReview";
import { SectionHead, Reveal, Slider, Chip } from "./ui";

const MechanismAuditV2 = () => {
  const [maxLevel, setMaxLevel] = useState(255);
  const [shelfCount, setShelfCount] = useState(1);
  const [horizontalRadius, setHorizontalRadius] = useState(3);
  const [verticalRadius, setVerticalRadius] = useState(2);

  const gateStats = useMemo(() => shelfGateStats(maxLevel), [maxLevel]);
  const unlocked = useMemo(() => {
    let highest = 1;
    for (let level = 2; level <= maxLevel; level++) {
      if (directShelfRequirement(level, maxLevel) <= shelfCount) highest = level;
      else break;
    }
    return highest;
  }, [maxLevel, shelfCount]);
  const currentScanCells = scanVolume(horizontalRadius, verticalRadius);
  const maxScanCells = scanVolume(16, 16);

  return (
    <section id="mechanism" className="relative max-w-6xl mx-auto px-6 md:px-10 py-20 md:py-32">
      <SectionHead
        numeral="复贰"
        kicker="MECHANISM REVIEW · FIXES VERIFIED, EDGES REMAIN"
        accent="#e8c37c"
        title={<>核心机制多数已闭合，<span className="text-gild">边界值需再定义</span></>}
        blurb="本次审查没有把上一轮已经修好的问题继续当作漏洞。下面聚焦仍会影响模组服主、第三方高等级附魔与服务器性能的边界：38 个离散书架状态如何映射到 255 级、扫描半径是否安全，以及置换 XP 如何与宣传的量产规则一致。"
      />

      {/* Resolved findings */}
      <Reveal>
        <div className="pixelframe bg-gradient-to-br from-[#122219] to-vellum border border-xp/25 p-6 md:p-8 mb-9">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-5">
            <p className="font-code text-[11px] tracking-[0.28em] text-xp flex items-center gap-2">
              <CheckCircle2 size={14} /> PREVIOUS REVIEW · 已修复项确认
            </p>
            <a
              className="font-code text-[10px] text-tealw hover:underline"
              href="https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/commit/2f6979bce2c5bc874cf4201cbc8bf7fa082a4b73"
              target="_blank"
              rel="noreferrer"
            >
              修复提交 2f6979b →
            </a>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {RESOLVED_SINCE_LAST_REVIEW.map((item) => (
              <div key={item.title} className="rounded-sm bg-obsidian/55 border border-xp/13 p-4">
                <p className="text-[12.5px] font-medium text-parch mb-1.5">{item.title}</p>
                <p className="text-[11.5px] leading-5 text-mute font-light">{item.detail}</p>
              </div>
            ))}
          </div>
        </div>
      </Reveal>

      <div className="grid lg:grid-cols-2 gap-6 mb-9">
        {/* Shelf curve edge */}
        <Reveal>
          <div className="pixelframe bg-vellum/75 border border-inkd/25 overflow-hidden h-full">
            <div className="px-6 py-4 border-b border-arcane/12 flex items-center justify-between gap-2">
              <p className="font-code text-[11px] tracking-[0.22em] text-inkd flex items-center gap-2">
                <Library size={14} /> EDGE 01 · 38 架映射 255 级
              </p>
              <Chip tone="#f08cc8">Strictly increasing 不可能</Chip>
            </div>
            <div className="p-6 space-y-6">
              <p className="text-[12.5px] leading-6 text-mute font-light">
                每个等级对应的书架需求被压在 0..38。maxLevel=255 有 255 个等级，但只有 39 个整数门槛状态，
                数学上不可能让每一级都得到严格递增的书架数。当前的 <span className="font-code text-inkd">minAllowed / maxAllowed</span>
                clamp 会把大段等级挤到同一档，而不是均匀地按书架成长分组。
              </p>
              <div className="grid sm:grid-cols-2 gap-5">
                <Slider label="附魔 maxLevel" value={maxLevel} min={2} max={255} onChange={setMaxLevel} format={(v) => `M=${v}`} accent="#a18cff" />
                <Slider label="普通书架数量" value={shelfCount} min={0} max={38} onChange={setShelfCount} format={(v) => `${v} 架`} accent="#e8c37c" />
              </div>
              <div className="grid grid-cols-3 gap-2">
                {[1, 2, 3].map((level) => (
                  <div key={level} className="rounded-sm bg-obsidian/60 border border-arcane/12 p-3 text-center">
                    <p className="font-code text-[9px] text-faint">等级 {level}</p>
                    <p className="font-display text-xl font-black text-parch">{directShelfRequirement(level, maxLevel)} 架</p>
                  </div>
                ))}
              </div>
              <div className="pixelframe bg-obsidian/70 border border-inkd/28 p-4 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-code text-[10px] text-mute">当前只摆 {shelfCount} 架，最高直升</p>
                  <p className="font-display text-2xl font-black text-inkd">Level {unlocked} / {maxLevel}</p>
                </div>
                <div className="text-right">
                  <p className="font-code text-[10px] text-mute">需求曲线可用门槛</p>
                  <p className="font-display text-2xl font-black text-gild">{gateStats.uniqueGateCount} / {gateStats.statesAvailable}</p>
                </div>
              </div>
              {maxLevel > 39 && gateStats.largestGroup && (
                <p className="text-[11.5px] leading-5.5 text-faint">
                  最大同档：{gateStats.largestGroup.count} 个等级共用 {gateStats.largestGroup.shelves} 架门槛
                  （Level {gateStats.largestGroup.first}–{gateStats.largestGroup.last}）。建议改成“每一档解锁等级区间”的 inverse curve，而非承诺逐级解锁。
                </p>
              )}
            </div>
          </div>
        </Reveal>

        {/* Scan volume */}
        <Reveal delay={0.08}>
          <div className="pixelframe bg-vellum/75 border border-gild/25 overflow-hidden h-full">
            <div className="px-6 py-4 border-b border-arcane/12 flex items-center justify-between gap-2">
              <p className="font-code text-[11px] tracking-[0.22em] text-gild flex items-center gap-2">
                <Gauge size={14} /> EDGE 02 · 配置化扫描体积
              </p>
              <Chip tone="#e8c37c">默认 244 格是安全的</Chip>
            </div>
            <div className="p-6 space-y-6">
              <p className="text-[12.5px] leading-6 text-mute font-light">
                `shelf_gates.json` 允许水平/垂直半径各到 16。最大体积为 35,936 个方块；自定义半径时，
                `animateTick` 每次重新分配 BlockPos 列表，菜单 live refresh 每秒执行扫描，且一次 live snapshot 会重复计算 ShelfPower。
                这对默认 3×2 半径无害，但给整合包留下了一个可配置的 tick/GC 放大器。
              </p>
              <div className="grid sm:grid-cols-2 gap-5">
                <Slider label="水平半径（X/Z）" value={horizontalRadius} min={1} max={16} onChange={setHorizontalRadius} format={(v) => `±${v}`} accent="#e8c37c" />
                <Slider label="垂直半径（Y）" value={verticalRadius} min={0} max={16} onChange={setVerticalRadius} format={(v) => `±${v}`} accent="#a18cff" />
              </div>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="rounded-sm bg-obsidian/65 border border-xp/20 p-3">
                  <p className="font-code text-[9px] text-faint">当前单次扫描</p>
                  <p className="font-display text-2xl font-black text-xp">{currentScanCells.toLocaleString()}</p>
                </div>
                <div className="rounded-sm bg-obsidian/65 border border-gild/20 p-3">
                  <p className="font-code text-[9px] text-faint">默认 3×2</p>
                  <p className="font-display text-2xl font-black text-gild">{scanVolume(3, 2)}</p>
                </div>
                <div className="rounded-sm bg-obsidian/65 border border-inkd/20 p-3">
                  <p className="font-code text-[9px] text-faint">配置上限</p>
                  <p className="font-display text-2xl font-black text-inkd">{maxScanCells.toLocaleString()}</p>
                </div>
              </div>
              <div className="flex items-start gap-2.5 text-[11px] leading-5 text-faint">
                <TriangleAlert size={13} className="shrink-0 mt-0.5 text-gild" />
                建议：限制总扫描格数、缓存 offsets、合并 shelfPower/unlocked 两次扫描；粒子只从抽样后的附近位置生成。
              </div>
            </div>
          </div>
        </Reveal>
      </div>

      {/* Transformation mismatch */}
      <Reveal>
        <div className="pixelframe bg-vellum/75 border border-inkd/25 overflow-hidden">
          <div className="px-6 py-4 border-b border-arcane/12 flex flex-wrap items-center justify-between gap-2">
            <p className="font-code text-[11px] tracking-[0.25em] text-inkd flex items-center gap-2">
              <Zap size={14} /> EDGE 03 · Item transformation XP cost 语义复核
            </p>
            <Chip tone="#f08cc8">WIKI 量产表 ≠ 当前 Converter</Chip>
          </div>
          <div className="p-6">
            <p className="text-[12.5px] leading-6 text-mute font-light mb-5">
              `forTransformation` 当前返回 `deductedLevels = max(min_player_level, round(xp_cost × (1−discount)))`，
              并把 `requiredLevel` 也设为相同值。于是 `min_player_level` 不只是准入门槛，也变成最少扣费；
              `xp_cost` 8/10/12 会直接扣 8/10/12 级。与 WIKI 的绿球量产转换（金苹果 2 级、三叉戟 3 级、图腾 3 级）不符。
            </p>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[720px] border-collapse text-left">
                <thead>
                  <tr className="font-code text-[10px] text-faint border-b border-arcane/15">
                    <th className="py-2 pr-3 font-normal">置换</th>
                    <th className="py-2 px-3 font-normal">JSON raw / min</th>
                    <th className="py-2 px-3 font-normal">当前代码门槛 / 扣费</th>
                    <th className="py-2 pl-3 font-normal">WIKI 声称门槛 / 扣费</th>
                  </tr>
                </thead>
                <tbody>
                  {TRANSFORMATION_XP_EXAMPLES.map((row) => {
                    const actual = currentTransformationXp(row.rawCost, row.minPlayerLevel);
                    return (
                      <tr key={row.id} className="border-b border-arcane/8 text-[12px]">
                        <td className="py-3 pr-3 text-parch">{row.name}</td>
                        <td className="py-3 px-3 font-code text-mute">{row.rawCost} / {row.minPlayerLevel}</td>
                        <td className="py-3 px-3 font-code text-inkd">Lv.{actual.requiredLevel} / {actual.deductedLevels} 级</td>
                        <td className="py-3 pl-3 font-code text-xp">Lv.{row.wikiLevel} / {row.wikiDeduct} 级</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <p className="mt-4 text-[11.5px] leading-5.5 text-faint">
              先决定目标语义：如果当前实现是有意改成“每条置换按 rawCost 扣等级”，就更新 WIKI/徽标并重配价格；若仍是 Mass Production，则将最低玩家等级与扣除等级拆成两个字段，重建转换公式。
            </p>
          </div>
        </div>
      </Reveal>
    </section>
  );
};

export default MechanismAuditV2;