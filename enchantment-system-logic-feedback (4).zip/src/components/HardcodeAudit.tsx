import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Code2,
  FileWarning,
  CheckSquare,
  ChevronDown,
  FileCode2,
} from "lucide-react";
import {
  HARDCODE_FINDINGS,
  DRIFT_ROWS,
  type AuditCategory,
  type Severity,
} from "../lib/repoAudit";
import { SectionHead, Reveal, Chip } from "./ui";

const SEV_COLOR: Record<Severity, string> = {
  P0: "#f08cc8",
  P1: "#e8c37c",
  P2: "#7ee8dc",
  P3: "#9c93bd",
};

const CAT_LABELS: { id: "all" | AuditCategory; label: string }[] = [
  { id: "all", label: "全部 (10)" },
  { id: "hardcode", label: "常数/规则硬编码" },
  { id: "compat", label: "跨模组兼容隐患" },
  { id: "sync", label: "网络同步与 JEI" },
  { id: "docs", label: "多处重复与本地化" },
];

const MERGE_CHECKLIST = [
  {
    pri: "MUST FIX · 阻断合入",
    tone: "#f08cc8",
    items: [
      "修复 XpCostConversion#forIncrementalMasterTomeEnchant 与 DisenchantmentApplication#refundForStepDown 的单步倒挂（压平势能曲线至 22/28·r^1.25 或在 refundForStepDown 增加对偶硬钳制），并同步修正 compat_check.py 的假公式与单步断言。",
      "拆分 ChiseledEnchantingTableBlock#withWoodenShelfBoost：白板初刻恢复 ceil(M/2) 上限，0..38 普通书架阶梯仅放行「目标已带 L_cur >= 1 同种魔咒的直接升阶」与「附魔书材料研究升级」。",
      "修复残卷梯度三计数：改为基于已去重的 storedMasterLevels 统计不同魔咒种类数，且对 maxLevel == 2 要求 L == 2 满级才计入。",
      "修复 calculateShelfPower() L287：将 Blocks.BOOKSHELF 改为 #minecraft:enchantment_power_provider（排除雕纹书架），消除与粒子动画的标签分裂。",
    ],
  },
  {
    pri: "SHOULD FIX · 强烈建议同批处理",
    tone: "#e8c37c",
    items: [
      "修复 TransformationQueryIndex#build：全洗附魔书产物改为 BlockRegistry.DEPLETED_TOME，单洗与祛咒优先读取 SyncedEnchantmentCosts.find(...)，正确标记 serverCosts。",
      "修复 ChiseledEnchantingTableBlockEntity#collectImplicitComponents：仅在 rem > 0L（处于付费冻结期）时写入 CUSTOM_DATA，消除日常拆台后的物品堆叠污染。",
      "放开 compat_check.py 对 targeted_strip 必须含 cleansing_grit 的死锁断言，补齐 CHANGELOG 承诺的单颗秘法凝晶或纯原版替代选项，并统一 WIKI §8 的 4/2 材料数。",
      "为 Items.ENCHANTED_BOOK 的 64 堆叠修改提供启动配置开关（默认 64，允许整合包服主调回 1 以兼容不识别堆叠附魔书的第三方机器）。",
    ],
  },
  {
    pri: "NICE TO HAVE · 数据驱动演进",
    tone: "#7ee8dc",
    items: [
      "将 LibraryResonance 的 12..32 区间、权重系数及增量折扣 -20%/-10% 迁入数据包，并在服务端执行附魔/转化时复验实时书架数防止开界面拆书架白嫖。",
      "EnchantCostTablePayload 改用稳定字符串 token() 与 ItemStack.OPTIONAL_STREAM_CODEC，并按魔咒实际标签裁剪无效条目。",
    ],
  },
];

const HardcodeAudit = () => {
  const [cat, setCat] = useState<"all" | AuditCategory>("all");
  const [openId, setOpenId] = useState<string>("HC-01");

  const filtered = HARDCODE_FINDINGS.filter((f) => cat === "all" || f.category === cat);

  return (
    <>
      <section id="hardcode" className="relative max-w-6xl mx-auto px-6 md:px-10 py-20 md:py-32">
        <div
          className="absolute top-36 -left-20 font-display font-black text-[15rem] leading-none select-none pointer-events-none opacity-[0.035]"
          aria-hidden
        >
          码
        </div>

        <SectionHead
          numeral="审叁"
          kicker="HARDCODING & COMPATIBILITY SCAN · 10 SITES"
          accent="#7ee8dc"
          title={
            <>
              不当硬编码清查：<span className="text-tealw">十处源码定位</span>
            </>
          }
          blurb="本模组的核心卖点是「全数据包驱动 + 100% 第三方模组兼容」。以下十处代码仍在 Java、网络包或静态检查脚本里写死了原版方块、常数、物品 ID 或枚举序号，逐条给出定位与重构方案。"
        />

        {/* 过滤器 */}
        <Reveal>
          <div className="flex flex-wrap gap-2 mb-6">
            {CAT_LABELS.map((c) => (
              <button
                key={c.id}
                onClick={() => setCat(c.id)}
                className="px-3.5 py-2 rounded-sm font-code text-xs border transition-all cursor-pointer"
                style={{
                  color: cat === c.id ? "#0a0913" : "#7ee8dc",
                  background: cat === c.id ? "#7ee8dc" : "rgba(126,232,220,0.06)",
                  borderColor: "rgba(126,232,220,0.35)",
                }}
              >
                {c.label}
              </button>
            ))}
          </div>
        </Reveal>

        {/* 手风琴列表 */}
        <div className="space-y-3">
          {filtered.map((item) => {
            const expanded = openId === item.id;
            const tone = SEV_COLOR[item.severity];
            return (
              <div
                key={item.id}
                className="pixelframe bg-vellum/70 border transition-colors"
                style={{
                  borderColor: expanded ? `${tone}66` : "rgba(161,140,255,0.14)",
                }}
              >
                <button
                  onClick={() => setOpenId(expanded ? "" : item.id)}
                  className="w-full text-left px-5 md:px-7 py-4 flex items-center gap-3 md:gap-4 cursor-pointer"
                >
                  <span
                    className="font-code text-[11px] font-bold px-2 py-0.5 rounded-sm shrink-0"
                    style={{
                      color: tone,
                      background: `${tone}15`,
                      border: `1px solid ${tone}44`,
                    }}
                  >
                    {item.severity} · {item.id}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm md:text-[15px] text-parch truncate">
                      {item.title}
                    </p>
                    <p className="font-code text-[10.5px] text-faint truncate mt-0.5">
                      {item.file} — {item.symbol}
                    </p>
                  </div>
                  <ChevronDown
                    size={16}
                    className="text-mute shrink-0 transition-transform duration-300"
                    style={{ transform: expanded ? "rotate(180deg)" : "rotate(0deg)" }}
                  />
                </button>

                <AnimatePresence initial={false}>
                  {expanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25 }}
                      className="overflow-hidden"
                    >
                      <div className="px-5 md:px-7 pb-6 pt-2 border-t border-arcane/10 space-y-4">
                        <p className="text-[13px] leading-6.5 text-mute font-light">
                          {item.summary}
                        </p>

                        <div className="grid lg:grid-cols-2 gap-3">
                          <div className="rounded-sm bg-obsidian/85 border border-inkd/25 p-4 overflow-x-auto">
                            <p className="font-code text-[10px] text-inkd mb-2 flex items-center gap-1.5">
                              <FileCode2 size={12} /> 分支现状源码
                            </p>
                            <pre className="font-code text-[11px] leading-5 text-parch/90 whitespace-pre-wrap">
                              {item.badCode}
                            </pre>
                          </div>
                          <div className="rounded-sm bg-obsidian/85 border border-xp/25 p-4 overflow-x-auto">
                            <p className="font-code text-[10px] text-xp mb-2 flex items-center gap-1.5">
                              <Code2 size={12} /> 建议去硬编码重构
                            </p>
                            <pre className="font-code text-[11px] leading-5 text-xp/95 whitespace-pre-wrap">
                              {item.goodCode}
                            </pre>
                          </div>
                        </div>

                        <p className="font-code text-[11px] text-gild/90">
                          实战影响：{item.impact}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </section>

      {/* 文档漂移 & 合入清单 */}
      <section id="drift" className="relative max-w-6xl mx-auto px-6 md:px-10 py-20 md:py-28">
        <SectionHead
          numeral="审肆"
          kicker="DOC-VS-CODE DRIFT & ACTIONABLE ROADMAP"
          accent="#a18cff"
          title={
            <>
              文档漂移对照与<span className="text-arcane">合入前整改单</span>
            </>
          }
          blurb="仓库内已配有 consistency.yml 检查版本号一致，但机制文案与 JSON 数据包之间出现了五处明显漂移。下方一并给出按优先级排序的 PR 修改清单。"
        />

        {/* 漂移对照表 */}
        <Reveal>
          <div className="pixelframe bg-vellum/70 border border-arcane/20 overflow-hidden mb-12">
            <div className="px-6 py-4 border-b border-arcane/12 flex items-center justify-between">
              <p className="font-code text-[11px] tracking-[0.28em] text-arcane flex items-center gap-2">
                <FileWarning size={13} /> SOURCE-OF-TRUTH DRIFT MATRIX · 五处实测不一致
              </p>
              <Chip tone="#e8c37c">建议纳入 compat_check.py 校验</Chip>
            </div>
            <div className="divide-y divide-arcane/10">
              {DRIFT_ROWS.map((r) => (
                <div
                  key={r.topic}
                  className="p-5 md:px-6 grid md:grid-cols-12 gap-3 items-start text-[12.5px]"
                >
                  <div className="md:col-span-2">
                    <p className="font-medium text-parch">{r.topic}</p>
                    <p className="font-code text-[10px] text-faint mt-0.5">{r.docSource}</p>
                  </div>
                  <div className="md:col-span-4 text-mute font-light">
                    <span className="font-code text-[10px] text-gild block mb-0.5">文档/界面声称</span>
                    {r.docClaim}
                  </div>
                  <div className="md:col-span-4 text-mute font-light">
                    <span className="font-code text-[10px] text-tealw block mb-0.5">源码/JSON 实装</span>
                    {r.actualCode}
                  </div>
                  <div className="md:col-span-2 md:text-right">
                    <Chip tone="#f08cc8">{r.verdict}</Chip>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        {/* 合入前修复路线图 */}
        <div className="grid lg:grid-cols-3 gap-4">
          {MERGE_CHECKLIST.map((group, idx) => (
            <Reveal key={group.pri} delay={idx * 0.07}>
              <div
                className="pixelframe bg-abyss/85 border p-6 h-full"
                style={{ borderColor: `${group.tone}38` }}
              >
                <p
                  className="font-code text-[11px] tracking-[0.22em] mb-4 flex items-center gap-2"
                  style={{ color: group.tone }}
                >
                  <CheckSquare size={14} /> {group.pri}
                </p>
                <ul className="space-y-3.5">
                  {group.items.map((it, k) => (
                    <li
                      key={k}
                      className="flex gap-2.5 text-[12px] leading-5.5 text-mute font-light"
                    >
                      <span
                        className="font-code text-[10px] mt-1 shrink-0 font-bold"
                        style={{ color: group.tone }}
                      >
                        {String(k + 1).padStart(2, "0")}
                      </span>
                      <span>{it}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
};

export default HardcodeAudit;
