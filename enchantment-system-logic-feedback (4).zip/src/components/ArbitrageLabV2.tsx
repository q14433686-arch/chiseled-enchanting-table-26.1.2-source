import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ShieldCheck, Calculator, Gauge } from "lucide-react";
import {
  XP_MODE_PRESETS,
  calculateXpLoop,
  incrementalMasterCost,
  xpCostAtProgress,
  xpCostAtZeroProgress,
  levelAfterPointDebit,
} from "../lib/currentReview";
import { ROMAN } from "../lib/enchant";
import { SectionHead, Reveal, FormulaCard, Slider, Chip } from "./ui";

const ArbitrageLabV2 = () => {
  const [presetId, setPresetId] = useState("frost");
  const [maxLevel, setMaxLevel] = useState(2);
  const [from, setFrom] = useState(1);
  const [anvilCost, setAnvilCost] = useState(4);
  const [treasure, setTreasure] = useState(true);
  const [discount, setDiscount] = useState(40);
  const [rawTargetCost, setRawTargetCost] = useState(10);
  const [playerLevel, setPlayerLevel] = useState(30);
  const [progress, setProgress] = useState(99);
  const [levelCharge, setLevelCharge] = useState(1);

  const target = Math.min(maxLevel, from + 1);
  const loop = useMemo(
    () => calculateXpLoop(maxLevel, from, target, anvilCost, treasure, discount, 0.85, rawTargetCost),
    [maxLevel, from, target, anvilCost, treasure, discount, rawTargetCost],
  );
  const actualCreditCost = incrementalMasterCost(from, target, maxLevel, discount, 0.85, rawTargetCost);
  const declaredCreditCost = incrementalMasterCost(from, target, maxLevel, discount, 0.35, rawTargetCost);

  const pointDebit = xpCostAtZeroProgress(playerLevel, levelCharge);
  const afterDebit = levelAfterPointDebit(playerLevel, progress / 100, pointDebit);

  const applyPreset = (id: string) => {
    const preset = XP_MODE_PRESETS.find((entry) => entry.id === id);
    if (!preset) return;
    setPresetId(id);
    setMaxLevel(preset.max);
    setFrom(preset.from);
    setAnvilCost(preset.anvil);
    setTreasure(preset.treasure);
    setRawTargetCost(preset.rawCost);
  };

  return (
    <section id="arbitrage" className="relative max-w-6xl mx-auto px-6 md:px-10 py-20 md:py-32">
      <SectionHead
        numeral="复一"
        kicker="RECHECK · XP CONSERVATION"
        accent="#8df0a4"
        title={<>上轮套利点已修：<span className="text-xp">默认模型净消耗</span></>}
        blurb="这次不沿用旧的 +XP 结论。提交 2f6979b 把退魔势能按每个等级的母本增量最低 XP 成本逐步钳制；我按最新 Java 公式重新复算了常见原版循环，均不再正收益。现在的问题是配置/校验是否真在验证同一套公式，以及“扣等级”的实际进度语义。"
      />

      <Reveal>
        <div className="pixelframe bg-gradient-to-br from-[#122219] to-vellum border border-xp/25 p-6 md:p-8 mb-8">
          <div className="flex items-start gap-4">
            <ShieldCheck className="text-xp shrink-0 mt-1" size={22} />
            <div className="flex-1">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-display text-xl font-bold text-parch">当前默认公式的循环对账</p>
                <Chip tone="#8df0a4">本轮静态复算：无正收益</Chip>
              </div>
              <p className="mt-2 text-[13px] leading-6 text-mute font-light">
                在 `M=2..255` 的可测试等级范围、多个 anvilCost / 宝藏标记下复刻势能表；潜在返还 V(k)-V(a)
                被母本增量花费逐阶限制。滑动下方参数可查看一个真实循环。5 XP 安全边际保证这条路径不会打平或转正。
              </p>
            </div>
          </div>
        </div>
      </Reveal>

      <div className="grid lg:grid-cols-5 gap-6 mb-10">
        <Reveal className="lg:col-span-2 space-y-6">
          <FormulaCard
            tone="#8df0a4"
            title="当前实现 · 逐步归纳势能"
            rows={[
              { lhs: "增量 XP", rhs: "XpCostConversion.forIncremental(a→k, rawTargetCost)" },
              { lhs: "势能上限", rhs: "V(k) ≤ min(fullCost(k), V(a)+stepCost(a→k)−5)" },
              { lhs: "当前 V", rhs: "round(scale × 34/48 × rarity × (k/M)^1.65)" },
              { lhs: "稀有倍率", rhs: "clamp(1+0.18·ln(anvilCost), 1, 1.45) × 1.15(宝藏)" },
              { lhs: "scale", rhs: "datapack clamp 0..1；提高返还倍率会被拒绝" },
            ]}
          />
          <div className="pixelframe bg-abyss/75 border border-gild/20 p-6">
            <p className="font-code text-[11px] tracking-[0.22em] text-gild mb-3">本例循环净损益</p>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div>
                <p className="font-code text-[10px] text-mute">升阶最小扣 XP</p>
                <p className="font-display text-2xl font-black text-gild">-{loop.spend}</p>
              </div>
              <div>
                <p className="font-code text-[10px] text-mute">降级返还</p>
                <p className="font-display text-2xl font-black text-xp">+{loop.refund}</p>
              </div>
              <div>
                <p className="font-code text-[10px] text-mute">净变化</p>
                <p className="font-display text-2xl font-black text-xp">-{loop.net}</p>
              </div>
            </div>
            <p className="text-[11px] leading-5 text-faint mt-3">
              负数表示 XP 净支出；当前环节会留下至少 5 点 XP + 材料消耗，不是可无限循环的经验源。
            </p>
          </div>
        </Reveal>

        <Reveal className="lg:col-span-3" delay={0.08}>
          <div className="pixelframe bg-vellum/75 border border-xp/20 overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 px-6 py-4 border-b border-arcane/12">
              <p className="font-code text-[11px] tracking-[0.25em] text-xp flex items-center gap-2">
                <Calculator size={13} /> CURRENT FORMULA LAB · 当前分支公式
              </p>
              <Chip tone="#9c93bd">γ bookshelf = 1.25</Chip>
            </div>
            <div className="p-6 md:p-7 space-y-6">
              <div className="grid sm:grid-cols-2 gap-2">
                {XP_MODE_PRESETS.map((entry) => (
                  <button
                    key={entry.id}
                    onClick={() => applyPreset(entry.id)}
                    className="text-left px-3.5 py-2 rounded-sm border transition-all cursor-pointer"
                    style={{
                      background: presetId === entry.id ? "rgba(141,240,164,0.12)" : "rgba(10,9,19,0.5)",
                      borderColor: presetId === entry.id ? "#8df0a877" : "rgba(161,140,255,0.14)",
                    }}
                  >
                    <p className="text-[12.5px] text-parch">{entry.name}</p>
                    <p className="font-code text-[10px] text-faint mt-0.5">
                      M={entry.max} · anvilCost={entry.anvil} · {entry.treasure ? "treasure" : "non-treasure"}
                    </p>
                  </button>
                ))}
              </div>

              <div className="grid sm:grid-cols-2 gap-5">
                <Slider label="maxLevel" value={maxLevel} min={2} max={10} onChange={setMaxLevel} format={(v) => `M=${v}`} accent="#a18cff" />
                <Slider
                  label={`测试相邻等级（${ROMAN[Math.min(from, ROMAN.length - 1)]} → ${ROMAN[Math.min(target, ROMAN.length - 1)]}）`}
                  value={from}
                  min={1}
                  max={Math.max(1, maxLevel - 1)}
                  onChange={setFrom}
                  format={(v) => `${v} → ${v + 1}`}
                  accent="#e8c37c"
                />
                <Slider label="anvilCost" value={anvilCost} min={1} max={30} onChange={setAnvilCost} accent="#7ee8dc" />
                <Slider label="有效经验减免" value={discount} min={0} max={40} onChange={setDiscount} format={(v) => `−${v}%`} accent="#8df0a4" />
                <Slider label="目标等级 raw XP cost" value={rawTargetCost} min={0} max={30} onChange={setRawTargetCost} format={(v) => `${v}`} accent="#f08cc8" />
              </div>

              <div className="grid sm:grid-cols-2 gap-3">
                <div className="rounded-sm bg-obsidian/65 border border-arcane/15 p-4">
                  <p className="font-code text-[10px] text-mute mb-1">当前实际 credit=0.85 · raw={rawTargetCost}</p>
                  <p className="font-display text-2xl font-black text-gild">-{actualCreditCost.xp} XP</p>
                  <p className="font-code text-[10px] text-faint">门槛 Lv.{actualCreditCost.threshold} · 扣 {actualCreditCost.tier} 级</p>
                </div>
                <div className="rounded-sm bg-obsidian/65 border border-inkd/20 p-4">
                  <p className="font-code text-[10px] text-mute mb-1">JSON 声明 credit=0.35 · raw={rawTargetCost}</p>
                  <p className="font-display text-2xl font-black text-inkd">-{declaredCreditCost.xp} XP</p>
                  <p className="font-code text-[10px] text-faint">门槛 Lv.{declaredCreditCost.threshold} · 扣 {declaredCreditCost.tier} 级</p>
                </div>
              </div>

              <div className="text-[11.5px] leading-5.5 text-mute border-t border-arcane/10 pt-4">
                <span className="text-gild font-medium">这个循环目前安全，但调参没生效：</span>
                LibraryResonance JSON 的 incremental_threshold_credit_factor=0.35 未被当前扁平根键解析器读取，实际默认 0.85。
                势能计算与当前实际 XP floor 使用同一个 activeConfig，所以默认数据下仍闭合；但价格曲线不等于随包 JSON/Wiki 所表达的平衡。
              </div>
            </div>
          </div>
        </Reveal>
      </div>

      {/* Level progress semantics */}
      <Reveal>
        <div className="pixelframe bg-vellum/70 border border-inkd/25 overflow-hidden">
          <div className="px-6 py-4 border-b border-arcane/12 flex flex-wrap items-center justify-between gap-2">
            <p className="font-code text-[11px] tracking-[0.25em] text-inkd flex items-center gap-2">
              <Gauge size={13} /> XP LEVEL SEMANTICS · 进度条核对器
            </p>
            <Chip tone="#e8c37c">点数扣除 ≠ 原版 giveExperienceLevels</Chip>
          </div>
          <div className="p-6 md:p-7 grid lg:grid-cols-5 gap-6 items-center">
            <div className="lg:col-span-2 grid sm:grid-cols-2 gap-5">
              <Slider label="当前玩家等级" value={playerLevel} min={5} max={40} onChange={setPlayerLevel} format={(v) => `Lv.${v}`} accent="#a18cff" />
              <Slider label="当前经验条进度" value={progress} min={0} max={99} onChange={setProgress} format={(v) => `${v}%`} accent="#f08cc8" />
              <div className="sm:col-span-2">
                <Slider label="徽标声称扣除等级数" value={levelCharge} min={1} max={3} onChange={setLevelCharge} format={(v) => `${v} 级`} accent="#e8c37c" />
              </div>
            </div>
            <div className="lg:col-span-3 grid sm:grid-cols-3 gap-3">
              <div className="pixelframe bg-obsidian/65 border border-arcane/15 p-4 text-center">
                <p className="font-code text-[10px] text-mute">当前代码扣 XP 点数</p>
                <p className="font-display text-2xl font-black text-gild">-{xpCostAtZeroProgress(playerLevel, levelCharge)}</p>
                <p className="font-code text-[10px] text-faint">不读取经验条 progress</p>
              </div>
              <div className="pixelframe bg-obsidian/65 border border-tealw/20 p-4 text-center">
                <p className="font-code text-[10px] text-mute">保留进度比例应扣</p>
                <p className="font-display text-2xl font-black text-tealw">-{xpCostAtProgress(playerLevel, progress / 100, levelCharge)}</p>
                <p className="font-code text-[10px] text-faint">按目标等级重建同百分比</p>
              </div>
              <motion.div
                key={`${afterDebit.level}-${afterDebit.progress}`}
                initial={{ scale: 0.97 }}
                animate={{ scale: 1 }}
                className="pixelframe bg-inkd/7 border border-inkd/25 p-4 text-center"
              >
                <p className="font-code text-[10px] text-mute">当前实现实际落点</p>
                <p className="font-display text-2xl font-black text-inkd">Lv.{afterDebit.level}</p>
                <div className="mt-2 h-2 bg-obsidian rounded-full overflow-hidden">
                  <div className="h-full bg-inkd" style={{ width: `${Math.round(afterDebit.progress * 100)}%` }} />
                </div>
                <p className="font-code text-[10px] text-faint mt-1">经验条 {Math.round(afterDebit.progress * 100)}%</p>
              </motion.div>
            </div>
          </div>
          <div className="px-6 pb-5 text-[11.5px] leading-5.5 text-mute">
            例：Lv.30、经验条 99%、扣 1 级，当前函数扣 107 点，玩家仍停留 Lv.30（约 3.5%），因此仍满足 Lv.30 的门槛；原版按等级扣费则应到 Lv.29 并保留 99%。这不会创造 XP，但会改变最低门槛下可连续量产次数。需要明确选定“扣等级”还是“扣固定点数”，再同步 badge 与 WIKI。
          </div>
        </div>
      </Reveal>
    </section>
  );
};

export default ArbitrageLabV2;