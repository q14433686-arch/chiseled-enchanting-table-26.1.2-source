import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { FileCode2, CheckSquare, ChevronDown, FileWarning } from "lucide-react";
import { CURRENT_FINDINGS, CURRENT_DRIFT, type ReviewFinding, type ReviewPriority } from "../lib/currentReview";
import { SectionHead, Reveal, Chip } from "./ui";

const PRIORITY_COLOR: Record<ReviewPriority, string> = {
  P1: "#f08cc8",
  P2: "#e8c37c",
  INFO: "#7ee8dc",
};

const FILTERS = ["全部", "配置", "经验与数值", "兼容与性能"] as const;
type Filter = (typeof FILTERS)[number];

function matchesFilter(finding: ReviewFinding, filter: Filter) {
  if (filter === "全部") return true;
  if (filter === "配置") return finding.id.startsWith("CFG") || finding.id.startsWith("JEI");
  if (filter === "经验与数值") return finding.id.startsWith("XP") || finding.id.startsWith("SHELF");
  return finding.id.startsWith("PERF") || finding.id.startsWith("TEST") || finding.id.startsWith("JEI");
}

const NEXT_STEPS = [
  {
    title: "P1 · 先修数据解析",
    tone: "#f08cc8",
    items: [
      "统一 library_resonance.json 与 LibraryResonance.Config.fromJson 的嵌套/扁平 schema；做解析后的 Config 快照测试，确认木架上限、母本权重、credit 系数在运行时等于 JSON。",
      "明确 transformation 的 XP 单位：将 player gate、扣除等级/点数拆分字段；同步更新 WIKI、JEI/REI tooltip 与绿色/紫色 badge。",
      "决定点数扣费还是等级扣费。若文案承诺保留 bar%，按 start/end progress 算点数差，或对 vanillaTierMode 直接使用 giveExperienceLevels。",
    ],
  },
  {
    title: "P1 · 让经济证明与运行代码共用一套模型",
    tone: "#e8c37c",
    items: [
      "Python 现有势能/增量公式与 Java 参数不同；从同一测试向量导出 Java/Python 黄金数据，禁止各自复制一套“近似证明”。",
      "静态 CI 补齐 M=21..255 的增量路径；Java runtime self-check 除 full wipe 外，也校验每个 a→k 的 V(k)-V(a) <= minIncrementalCost。",
      "升级势能表实现可复用/缓存：runtime reload 校验与 255 级退魔菜单反复计算共享一次 V[0..M]，避免每一行重建前缀表。",
    ],
  },
  {
    title: "P2 · 固化高等级与大范围边界",
    tone: "#7ee8dc",
    items: [
      "给 maxLevel>39 明确分档规则；以 shelf count 反算 unlocked tier，避免当前 M=255 的 level 2..218 全挤在 1 架。",
      "限制 scan_volume 总格数并缓存 offsets；computeLiveShelfState 只做一份 ShelfPower scan，动画使用受预算控制的采样点。",
      "将零 XP 邻级降级行显示为“0 XP”，或使用定点精度累计小数；不应直接强制每步 +1 XP，以免击穿安全上界。",
    ],
  },
];

const HardcodeAuditV2 = () => {
  const [filter, setFilter] = useState<Filter>("全部");
  const [openId, setOpenId] = useState("CFG-01");
  const visible = CURRENT_FINDINGS.filter((finding) => matchesFilter(finding, filter));

  return (
    <>
      <section id="hardcode" className="relative max-w-6xl mx-auto px-6 md:px-10 py-20 md:py-32">
        <SectionHead
          numeral="复叁"
          kicker="CURRENT OPEN FINDINGS · 9 ITEMS"
          accent="#7ee8dc"
          title={<>当前仍待处理的<span className="text-tealw">数据、机制与硬编码</span></>}
          blurb="上一轮列出的十处硬编码中，多项已在修复提交中处理（书架标签、堆叠配置、tag 输入、物品数据、未冻结方块组件）。这里仅保留对当前 HEAD 仍有效、或在新实现中出现的发现，避免把已修复问题重复当成现状。"
        />

        <Reveal>
          <div className="flex flex-wrap gap-2 mb-6">
            {FILTERS.map((item) => (
              <button
                key={item}
                onClick={() => setFilter(item)}
                className="px-3.5 py-2 rounded-sm font-code text-xs border transition-all cursor-pointer"
                style={{
                  color: filter === item ? "#0a0913" : "#7ee8dc",
                  background: filter === item ? "#7ee8dc" : "rgba(126,232,220,0.06)",
                  borderColor: "rgba(126,232,220,0.35)",
                }}
              >
                {item}
              </button>
            ))}
          </div>
        </Reveal>

        <div className="space-y-3">
          {visible.map((finding) => (
            <FindingRow
              key={finding.id}
              finding={finding}
              expanded={openId === finding.id}
              onClick={() => setOpenId(openId === finding.id ? "" : finding.id)}
            />
          ))}
        </div>
      </section>

      <section id="drift" className="relative max-w-6xl mx-auto px-6 md:px-10 py-20 md:py-28">
        <SectionHead
          numeral="复肆"
          kicker="DOC / JSON / RUNTIME · SOURCE-OF-TRUTH MATRIX"
          accent="#a18cff"
          title={<>文档、数据包、运行时的<span className="text-arcane">真值漂移</span></>}
          blurb="建议把这些一致性关系纳入 compat_check.py：JSON 必须解析为预期 Config；WIKI 的公式/成本表必须从同一数据源生成，而非手写另一套版本。"
        />

        <Reveal>
          <div className="pixelframe bg-vellum/70 border border-arcane/20 overflow-hidden mb-12">
            <div className="px-6 py-4 border-b border-arcane/12 flex items-center justify-between gap-2">
              <p className="font-code text-[11px] tracking-[0.25em] text-arcane flex items-center gap-2">
                <FileWarning size={13} /> SIX SOURCE-OF-TRUTH CHECKS
              </p>
              <Chip tone="#e8c37c">6 项需对齐</Chip>
            </div>
            <div className="divide-y divide-arcane/10">
              {CURRENT_DRIFT.map((row) => (
                <div key={row.topic} className="p-5 md:px-6 grid md:grid-cols-12 gap-3 items-start text-[12.5px]">
                  <p className="md:col-span-2 font-medium text-parch">{row.topic}</p>
                  <p className="md:col-span-4 text-mute font-light">
                    <span className="block font-code text-[10px] text-gild mb-1">文档 / JSON 声明</span>
                    {row.doc}
                  </p>
                  <p className="md:col-span-4 text-mute font-light">
                    <span className="block font-code text-[10px] text-tealw mb-1">代码实际行为</span>
                    {row.runtime}
                  </p>
                  <div className="md:col-span-2 md:text-right">
                    <Chip tone={row.tone}>{row.status}</Chip>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        <div className="grid lg:grid-cols-3 gap-4">
          {NEXT_STEPS.map((group, index) => (
            <Reveal key={group.title} delay={index * 0.07}>
              <div className="pixelframe bg-abyss/85 border p-6 h-full" style={{ borderColor: `${group.tone}38` }}>
                <p className="font-code text-[11px] tracking-[0.2em] mb-4 flex items-center gap-2" style={{ color: group.tone }}>
                  <CheckSquare size={14} /> {group.title}
                </p>
                <ul className="space-y-3.5">
                  {group.items.map((item, i) => (
                    <li key={i} className="flex gap-2.5 text-[12px] leading-5.5 text-mute font-light">
                      <span className="font-code text-[10px] mt-1 shrink-0" style={{ color: group.tone }}>
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </>
  );
};

const FindingRow = ({
  finding,
  expanded,
  onClick,
}: {
  finding: ReviewFinding;
  expanded: boolean;
  onClick: () => void;
}) => {
  const tone = PRIORITY_COLOR[finding.priority];
  return (
    <div className="pixelframe bg-vellum/70 border transition-colors" style={{ borderColor: expanded ? `${tone}66` : "rgba(161,140,255,0.14)" }}>
      <button onClick={onClick} className="w-full text-left px-5 md:px-7 py-4 flex items-center gap-3 md:gap-4 cursor-pointer">
        <span className="font-code text-[11px] font-bold px-2 py-0.5 rounded-sm shrink-0" style={{ color: tone, background: `${tone}15`, border: `1px solid ${tone}44` }}>
          {finding.priority} · {finding.id}
        </span>
        <div className="flex-1 min-w-0">
          <p className="font-medium text-sm md:text-[15px] text-parch truncate">{finding.title}</p>
          <p className="font-code text-[10.5px] text-faint truncate mt-0.5">{finding.location}</p>
        </div>
        <ChevronDown size={16} className="text-mute shrink-0 transition-transform duration-300" style={{ transform: expanded ? "rotate(180deg)" : "rotate(0deg)" }} />
      </button>
      <AnimatePresence initial={false}>
        {expanded && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }} className="overflow-hidden">
            <div className="px-5 md:px-7 pb-6 pt-2 border-t border-arcane/10 space-y-3">
              <div className="flex items-center gap-2 font-code text-[10px] tracking-[0.18em]" style={{ color: tone }}>
                <FileCode2 size={12} /> {finding.category}
              </div>
              <p className="text-[13px] leading-6.5 text-mute font-light">{finding.issue}</p>
              <div className="rounded-sm bg-obsidian/80 border border-arcane/12 p-4">
                <p className="font-code text-[10px] text-gild mb-1.5">源码与数值证据</p>
                <p className="text-[12px] leading-5.5 text-parch/90 font-light">{finding.evidence}</p>
              </div>
              <div className="rounded-sm bg-xp/5 border border-xp/20 p-4">
                <p className="font-code text-[10px] text-xp mb-1.5">建议修复</p>
                <p className="text-[12px] leading-5.5 text-mute font-light">{finding.recommendation}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default HardcodeAuditV2;