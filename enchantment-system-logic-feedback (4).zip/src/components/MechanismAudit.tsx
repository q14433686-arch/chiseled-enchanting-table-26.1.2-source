import { useState } from "react";
import {
  GitFork,
  BookCopy,
  Layers,
  RefreshCwOff,
  Check,
  X,
  ArrowRight,
} from "lucide-react";
import { SectionHead, Reveal, Chip } from "./ui";

interface ShelfSlotBook {
  id: string;
  label: string;
  enchId: string;
  level: number;
  maxLevel: number;
  note: string;
}

const SHELF_TEST_CASES: {
  id: string;
  title: string;
  subtitle: string;
  books: ShelfSlotBook[];
}[] = [
  {
    id: "knockback_spam",
    title: "漏洞复现 A · 塞 6 本 0 书架刻出的「击退 I」",
    subtitle: "击退 maxLevel=2，因此 MAX-1 = 1！总成本仅 18 青金石，0 个高阶母本",
    books: Array.from({ length: 6 }, (_, i) => ({
      id: `kb-${i}`,
      label: "击退 I",
      enchId: "minecraft:knockback",
      level: 1,
      maxLevel: 2,
      note: "0 架入门书",
    })),
  },
  {
    id: "dup_sharp",
    title: "漏洞复现 B · 量产 6 本同款「锋利 IV」塞满一架",
    subtitle: "单种魔咒复制 6 份，馆藏多样性实为 1 种",
    books: Array.from({ length: 6 }, (_, i) => ({
      id: `sh-${i}`,
      label: "锋利 IV",
      enchId: "minecraft:sharpness",
      level: 4,
      maxLevel: 5,
      note: "同种重复",
    })),
  },
  {
    id: "legit_library",
    title: "正当毕业馆藏 · 6 种不同毕业/准毕业母本",
    subtitle: "锋利 V、保护 IV、效率 V、时运 III、经验修补、火焰附加 II",
    books: [
      { id: "l1", label: "锋利 V", enchId: "minecraft:sharpness", level: 5, maxLevel: 5, note: "5/5" },
      { id: "l2", label: "保护 IV", enchId: "minecraft:protection", level: 4, maxLevel: 4, note: "4/4" },
      { id: "l3", label: "效率 V", enchId: "minecraft:efficiency", level: 5, maxLevel: 5, note: "5/5" },
      { id: "l4", label: "时运 III", enchId: "minecraft:fortune", level: 3, maxLevel: 3, note: "3/3" },
      { id: "l5", label: "经验修补", enchId: "minecraft:mending", level: 1, maxLevel: 1, note: "1/1" },
      { id: "l6", label: "火焰附加 II", enchId: "minecraft:fire_aspect", level: 2, maxLevel: 2, note: "2/2" },
    ],
  },
];

const MechanismAudit = () => {
  const [caseId, setCaseId] = useState("knockback_spam");
  const [batchCount, setBatchCount] = useState(1);

  const activeCase = SHELF_TEST_CASES.find((c) => c.id === caseId)!;

  // 分支现状逻辑：不去重 + L >= max(1, M - 1)
  const branchQualifyingCount = activeCase.books.filter(
    (b) => b.level >= Math.max(1, b.maxLevel - 1),
  ).length;

  // 建议修复逻辑：按 enchId 去重 + (M==1 ? L>=1 : M==2 ? L>=2 : L>=M-1)
  const distinctValid = new Set(
    activeCase.books
      .filter((b) => {
        if (b.maxLevel <= 1) return b.level >= 1;
        if (b.maxLevel === 2) return b.level >= 2;
        return b.level >= b.maxLevel - 1;
      })
      .map((b) => b.enchId),
  ).size;

  const paperPerBatch = 4; // item_transformations.json: count = 4
  const unitPaper = (paperPerBatch / batchCount).toFixed(2);

  return (
    <section id="mechanism" className="relative max-w-6xl mx-auto px-6 md:px-10 py-20 md:py-32">
      <div
        className="absolute top-36 -right-16 font-display font-black text-[15rem] leading-none select-none pointer-events-none opacity-[0.035]"
        aria-hidden
      >
        衡
      </div>

      <SectionHead
        numeral="审贰"
        kicker="MECHANISM & BALANCE AUDIT · 4 DESIGN COLLISIONS"
        accent="#e8c37c"
        title={
          <>
            机制与数值合理性：<span className="text-gild">四处边界失守</span>
          </>
        }
        blurb="除了经验套利，当前分支在落实「38 书架升阶」与「残卷三梯度」时，把两条原本正交的成长轴混在了一起，并在计数去重、批量单价与容器状态刷新上留下了明显的绕过路径。"
      />

      {/* 机制问题 1：withWoodenShelfBoost 越界 */}
      <Reveal>
        <div className="pixelframe bg-vellum/75 border border-gild/30 p-6 md:p-8 mb-8">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-5">
            <p className="font-code text-[11px] tracking-[0.28em] text-gild flex items-center gap-2">
              <GitFork size={14} /> 冲突 01 · ChiseledEnchantingTableBlock#withWoodenShelfBoost (L235 vs L314)
            </p>
            <Chip tone="#f08cc8">P0 · 架空雕纹书架母本定位</Chip>
          </div>

          <h3 className="font-display text-xl md:text-2xl font-bold text-parch mb-3">
            38 个普通木书架被直接注入了 <span className="font-code text-inkd">unlocked_enchantements</span>，白板装备可一步直附满级！
          </h3>
          <p className="text-[13.5px] leading-7 text-mute font-light mb-6">
            同文件第 <span className="font-code text-parch">235 行注释</span> 与{" "}
            <span className="font-code text-parch">README.md</span> 仍写着「普通木书架只推到中阶上限{" "}
            <span className="font-code text-arcane">ceil(maxLevel / 2)</span>，毕业阶必须靠雕纹书架母本」。
            但第 <span className="font-code text-parch">314 行</span> 却把{" "}
            <span className="font-code text-inkd">maxUnlockedDirectTier</span>（直通 MAX）塞进了基础解锁池！
            结果玩家只需摆 38 个橡木书架（牛棚+甘蔗田即可量产），就能把<span className="text-parch">白板钻石剑直接 0→锋利 V、白板镐直接 0→时运 III + 效率 V</span>，
            既不需要培养升阶附魔书，也不需要寻找母本放入雕纹书架——雕纹书架从「高阶解锁核心」沦为「省几级经验的可选挂件」。
          </p>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="rounded-sm bg-obsidian/70 border border-inkd/25 p-5">
              <p className="font-code text-[11px] text-inkd mb-2 flex items-center gap-1.5">
                <X size={13} /> 当前分支行为（路线混同）
              </p>
              <p className="text-[12.5px] leading-6 text-mute font-light">
                38 木书架 ⟹ 白板装备/普通书直接出现 <span className="text-parch">I ~ MAX 全部词条</span>。
                玩家无需经过 I→II→III→IV→V 升阶，更无需造雕纹书架存母本。
              </p>
            </div>
            <div className="rounded-sm bg-obsidian/70 border border-xp/25 p-5">
              <p className="font-code text-[11px] text-xp mb-2 flex items-center gap-1.5">
                <Check size={13} /> 应有职责拆分（三轨各司其职）
              </p>
              <p className="text-[12.5px] leading-6 text-mute font-light">
                ① <span className="text-parch">白板初刻 (0→L)</span>：木书架仍封顶{" "}
                <span className="font-code text-xp">⌈M/2⌉</span>；②{" "}
                <span className="text-parch">已有词条直升 (L_cur→L_new)</span>：由{" "}
                <span className="font-code text-xp">0..38</span> 阶梯解锁至 MAX；③{" "}
                <span className="text-parch">雕纹母本</span>：独享白板一步直附满级 + 量产绿球扣级！
              </p>
            </div>
          </div>
        </div>
      </Reveal>

      {/* 机制问题 2：残卷梯度三交互打靶 */}
      <div className="grid lg:grid-cols-5 gap-6 mb-8">
        <Reveal className="lg:col-span-3">
          <div className="pixelframe bg-vellum/75 border border-tealw/25 p-6 md:p-7 h-full">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
              <p className="font-code text-[11px] tracking-[0.25em] text-tealw flex items-center gap-2">
                <BookCopy size={14} /> 冲突 02 · 残卷梯度三高阶计数漏洞验证
              </p>
              <Chip tone="#f08cc8">P0 · 击退 I 混充高阶 + 未去重</Chip>
            </div>

            <p className="text-[13px] leading-6 text-mute font-light mb-5">
              <span className="font-code text-parch">calculateShelfPower() L291</span> 对每个雕纹书架累加{" "}
              <span className="font-code text-inkd">countQualifyingHighTierEnchantmentsInShelf</span>，
              既未按魔咒 ID 去重，又套用了 <span className="font-code text-inkd">L ≥ max(1, M−1)</span>：
              当 <span className="font-code text-parch">M = 2</span>（击退/火焰附加/冲击）时，
              <span className="text-inkd font-medium">MAX − 1 = 1 级</span>！点击切换下方三种摆法看判定差异：
            </p>

            <div className="space-y-2 mb-5">
              {SHELF_TEST_CASES.map((tc) => (
                <button
                  key={tc.id}
                  onClick={() => setCaseId(tc.id)}
                  className="w-full text-left px-4 py-2.5 rounded-sm border transition-all cursor-pointer"
                  style={{
                    background: caseId === tc.id ? "rgba(126,232,220,0.12)" : "rgba(10,9,19,0.5)",
                    borderColor: caseId === tc.id ? "#7ee8dc77" : "rgba(161,140,255,0.14)",
                  }}
                >
                  <p className="text-[12.5px] font-medium text-parch">{tc.title}</p>
                  <p className="font-code text-[10px] text-faint mt-0.5">{tc.subtitle}</p>
                </button>
              ))}
            </div>

            {/* 6 槽雕纹书架视觉 */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 mb-5">
              {activeCase.books.map((b) => (
                <div
                  key={b.id}
                  className="rounded-sm bg-obsidian/80 border border-arcane/20 p-2.5 text-center"
                >
                  <p className="font-display font-bold text-xs text-parch">{b.label}</p>
                  <p className="font-code text-[9.5px] text-faint mt-1">{b.note}</p>
                </div>
              ))}
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              <div className="pixelframe bg-obsidian/70 border border-inkd/30 p-4">
                <p className="font-code text-[10px] text-mute">分支现状判定 (不去重 + M−1)</p>
                <p className="font-display text-2xl font-black text-inkd mt-1">
                  H = {branchQualifyingCount} / 6 →{" "}
                  {branchQualifyingCount >= 6 ? "直接免费！" : "未达标"}
                </p>
              </div>
              <div className="pixelframe bg-obsidian/70 border border-xp/30 p-4">
                <p className="font-code text-[10px] text-mute">建议修复判定 (按 ID 去重 + M=2 须满级)</p>
                <p className="font-display text-2xl font-black text-xp mt-1">
                  H = {distinctValid} / 6 → {distinctValid >= 6 ? "合规免费" : "拦截白嫖"}
                </p>
              </div>
            </div>
          </div>
        </Reveal>

        {/* 机制问题 3 & 4 */}
        <Reveal className="lg:col-span-2 space-y-6" delay={0.08}>
          {/* 批次单价断层 */}
          <div className="pixelframe bg-vellum/75 border border-arcane/20 p-6">
            <p className="font-code text-[11px] tracking-[0.22em] text-arcane flex items-center gap-2 mb-3">
              <Layers size={14} /> 冲突 03 · 空白覆写 8 倍单价断层
            </p>
            <p className="text-[12.5px] leading-6 text-mute font-light mb-4">
              <span className="font-code text-parch">ItemTransformationApplication#apply</span>{" "}
              只扣一次单份耗材（<span className="font-code">4× 纸</span>），却按{" "}
              <span className="font-code">input.getCount()</span> 返还 1~8 本普通书：
            </p>

            <div className="mb-3">
              <div className="flex justify-between text-xs mb-1.5">
                <span className="text-mute">上槽放入残卷数量</span>
                <span className="font-code text-gild">{batchCount} 本</span>
              </div>
              <input
                type="range"
                min={1}
                max={8}
                value={batchCount}
                onChange={(e) => setBatchCount(Number(e.target.value))}
                className="slider w-full"
              />
            </div>

            <div className="rounded-sm bg-obsidian/70 border border-arcane/15 p-3.5 flex items-center justify-between text-xs">
              <div>
                <p className="text-mute">总耗材固定 4 张纸</p>
                <p className="font-code text-[10.5px] text-faint mt-0.5">
                  原版造 1 本书 = 3 纸 + 1 皮革
                </p>
              </div>
              <ArrowRight size={14} className="text-faint" />
              <div className="text-right">
                <p
                  className="font-code text-base font-bold"
                  style={{ color: batchCount === 1 ? "#f08cc8" : "#8df0a4" }}
                >
                  {unitPaper} 纸 / 本
                </p>
                <p className="font-code text-[10px] text-faint">
                  {batchCount === 1 ? "比造新书还亏！" : `净省 ${batchCount * 3 - 4} 纸 + ${batchCount} 皮革`}
                </p>
              </div>
            </div>
          </div>

          {/* 静态快照 + M=2 断层 */}
          <div className="pixelframe bg-abyss/80 border border-arcane/15 p-6 space-y-4">
            <p className="font-code text-[11px] tracking-[0.22em] text-gild flex items-center gap-2">
              <RefreshCwOff size={14} /> 冲突 04 · 菜单快照陈旧 & M=2 跳崖
            </p>
            <p className="text-[12.5px] leading-6 text-mute font-light">
              <span className="text-parch font-medium">① 打开菜单后拆书架不失效：</span>
              <span className="font-code text-tealw">regularBookshelves</span> 与{" "}
              <span className="font-code text-tealw">storedMasterLevels</span> 在右键开台瞬间固化为{" "}
              <span className="font-code">ScreenHandler</span> 的 <span className="font-code">final</span>{" "}
              字段。联机队友或漏斗抽走母本/拆光书架后，只要不关界面仍可无限白嫖满共鸣与免费残卷转化。
            </p>
            <p className="text-[12.5px] leading-6 text-mute font-light">
              <span className="text-parch font-medium">② M=2 阶梯 0→38 跳崖：</span>
              击退/火焰附加 II 直接要求 38 架（与锋利 V 同级），但双书合并 0 架即可把两本 I 合成 II，导致 M=2 的直升阶梯在实战中无人问津。
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default MechanismAudit;
