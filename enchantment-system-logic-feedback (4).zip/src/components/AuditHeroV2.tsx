import { motion } from "framer-motion";
import { ShieldCheck, AlertTriangle, FileCode2, GitBranch, ExternalLink, ChevronDown } from "lucide-react";
import { BRANCH_INFO } from "../lib/currentReview";

const CARDS = [
  {
    icon: ShieldCheck,
    tag: "上轮 P0 · 已修复",
    title: "XP 刷取循环已闭合",
    body: "当前降级势能逐阶受真实母本增量成本约束；本次复算的原版魔咒无正收益循环。",
    tone: "#8df0a4",
    href: "#arbitrage",
  },
  {
    icon: AlertTriangle,
    tag: "P1 · 配置实效",
    title: "共鸣 JSON 没有按声明生效",
    body: "文件采用嵌套对象，Java 却从根节点读取扁平键，服主调参会静默落回不同默认值。",
    tone: "#f08cc8",
    href: "#hardcode",
  },
  {
    icon: FileCode2,
    tag: "P1 · 机制 / 文档",
    title: "置换经验语义已偏离 WIKI",
    body: "xp_cost 现在直接成为扣级数，min_player_level 也被当成最低扣费等级。",
    tone: "#e8c37c",
    href: "#mechanism",
  },
  {
    icon: GitBranch,
    tag: "P1 · 兼容边界",
    title: "255 级附魔的书架阶梯塌缩",
    body: "38 个架位无法为 255 级提供逐级门槛；当前钳制让 217 个等级都落在 1 架。",
    tone: "#7ee8dc",
    href: "#mechanism",
  },
];

const AuditHeroV2 = () => (
  <header className="relative min-h-[92svh] flex flex-col justify-between overflow-hidden pt-20">
    <div className="absolute inset-0 grid-paper" />
    <div
      className="absolute inset-0 pointer-events-none"
      style={{
        background:
          "radial-gradient(1000px 520px at 50% 16%, rgba(126,232,220,0.11), transparent 65%), radial-gradient(780px 440px at 82% 88%, rgba(240,140,200,0.08), transparent 60%)",
      }}
    />

    <div className="relative z-10 max-w-6xl mx-auto w-full px-6 md:px-10 pt-8 pb-10">
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex flex-wrap items-center gap-3 mb-7"
      >
        <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-sm bg-arcane/10 border border-arcane/35 font-code text-[11px] text-arcane tracking-wider">
          <GitBranch size={13} /> {BRANCH_INFO.branch}
        </span>
        <span className="font-code text-[11px] text-mute tracking-widest">HEAD {BRANCH_INFO.head} · MC 26.1.2</span>
        <a
          href={`https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/tree/${BRANCH_INFO.branch.split("/").join("%2F")}`}
          target="_blank"
          rel="noreferrer"
          className="ml-auto inline-flex items-center gap-1.5 font-code text-[11px] text-gild hover:underline"
        >
          打开被审分支 <ExternalLink size={12} />
        </a>
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 26 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.85, delay: 0.08, ease: [0.22, 1, 0.36, 1] }}
        className="font-display font-black leading-[1.08] text-parch"
        style={{ fontSize: "clamp(2.35rem, 6.3vw, 5.1rem)" }}
      >
        上轮硬伤大多已修。
        <br />
        这一轮重点是<span className="text-gild">配置实效</span>与
        <span className="text-inkd"> XP 语义</span>。
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="mt-6 max-w-3xl text-sm md:text-[15px] leading-8 text-mute font-light"
      >
        已按最新 HEAD 重新检查。功能修复提交 <span className="font-code text-tealw">{BRANCH_INFO.functionalFix}</span>{" "}
        已解决上一轮指出的增量升阶/降阶正收益循环、白板直附越级、残卷计数去重、木书架标签、批量覆写计价与实时书架刷新。
        这些不再作为当前漏洞报告。仍需关注的是：配置文件解析形状与实际代码不匹配、物品置换扣级偏离 Wiki、XP 条进度语义变化，以及高等级附魔的门槛压缩和性能上界。
      </motion.p>

      <div className="mt-11 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {CARDS.map((c, i) => (
          <motion.a
            key={c.title}
            href={c.href}
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, delay: 0.28 + i * 0.08 }}
            className="group pixelframe bg-vellum/70 border p-5 flex flex-col justify-between hover:bg-vellum2/85 hover:-translate-y-1 transition-all duration-300"
            style={{ borderColor: `${c.tone}38` }}
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-3">
                <span
                  className="font-code text-[10px] px-2 py-0.5 rounded-sm tracking-wider"
                  style={{ color: c.tone, background: `${c.tone}14`, border: `1px solid ${c.tone}38` }}
                >
                  {c.tag}
                </span>
                <c.icon size={17} style={{ color: c.tone }} className="group-hover:scale-110 transition-transform" />
              </div>
              <p className="font-display font-bold text-lg text-parch mb-2">{c.title}</p>
              <p className="text-[12px] leading-5.5 text-mute font-light">{c.body}</p>
            </div>
            <span className="mt-4 font-code text-[10.5px] tracking-widest opacity-75 group-hover:opacity-100" style={{ color: c.tone }}>
              查看源码定位 →
            </span>
          </motion.a>
        ))}
      </div>
    </div>

    <motion.div
      className="relative z-10 flex justify-center pb-6"
      animate={{ y: [0, 7, 0] }}
      transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
    >
      <ChevronDown size={18} className="text-faint" />
    </motion.div>
  </header>
);

export default AuditHeroV2;