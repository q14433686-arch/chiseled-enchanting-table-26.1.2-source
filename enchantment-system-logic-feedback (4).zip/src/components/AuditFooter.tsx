import { ExternalLink, GitCommitHorizontal, ShieldCheck } from "lucide-react";
import { Reveal } from "./ui";
import { BRANCH_INFO } from "../lib/currentReview";

const AuditFooter = () => (
  <footer className="border-t border-arcane/12">
    <Reveal>
      <div className="max-w-6xl mx-auto px-6 md:px-10 py-12 flex flex-col md:flex-row items-start md:items-center justify-between gap-5">
        <div>
          <p className="font-display font-bold text-parch text-lg">复审结论：旧 P0 已闭合，当前应优先对齐配置与 XP 语义。</p>
          <p className="font-code text-[10.5px] text-faint mt-2 tracking-wider">
            {BRANCH_INFO.branch} · HEAD {BRANCH_INFO.head} · 以仓库当前源码为准
          </p>
        </div>
        <div className="flex flex-wrap gap-3">
          <a
            href={`https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/tree/${BRANCH_INFO.branch.split("/").join("%2F")}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 pixelframe bg-arcane-deep/20 border border-arcane/35 text-parch font-code text-[11px] hover:bg-arcane-deep/35 transition-colors"
          >
            查看当前分支 <ExternalLink size={12} />
          </a>
          <a
            href={`https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/commit/${BRANCH_INFO.functionalFix}`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 pixelframe bg-transparent border border-xp/25 text-xp font-code text-[11px] hover:border-xp/55 transition-colors"
          >
            <GitCommitHorizontal size={13} /> 已修复提交 {BRANCH_INFO.functionalFix}
          </a>
        </div>
      </div>
      <div className="max-w-6xl mx-auto px-6 md:px-10 pb-7 flex items-center gap-2 text-faint">
        <ShieldCheck size={12} className="text-xp/65" />
        <span className="font-code text-[10px] tracking-wider">源码静态复核 + 本地数值复算；未运行 Minecraft 客户端进行实机验证。</span>
      </div>
    </Reveal>
  </footer>
);

export default AuditFooter;