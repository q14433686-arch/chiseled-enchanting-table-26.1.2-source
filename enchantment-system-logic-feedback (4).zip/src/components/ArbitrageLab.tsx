import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { AlertOctagon, CheckCircle2, Bug, Wrench, Calculator } from "lucide-react";
import {
  ARBITRAGE_PRESETS,
  branchForIncrementalMasterTome,
  branchForMasterTomeEnchant,
  branchRefundForStepDown,
  branchEssencePotential,
  compatScriptFakeMinPoints,
  xpNeededToReachNextLevelFrom,
} from "../lib/repoAudit";
import { ROMAN } from "../lib/enchant";
import { SectionHead, Reveal, FormulaCard, Slider, Chip } from "./ui";

const ArbitrageLab = () => {
  const [presetId, setPresetId] = useState("frost_walker");
  const [maxLevel, setMaxLevel] = useState(2);
  const [fromLevel, setFromLevel] = useState(1);
  const [anvilCost, setAnvilCost] = useState(4);
  const [isTreasure, setIsTreasure] = useState(true);
  const [discount, setDiscount] = useState(40);
  const [scale, setScale] = useState(100);
  const [applyFix, setApplyFix] = useState(false);

  const safeFrom = Math.max(1, Math.min(maxLevel - 1, fromLevel));
  const toLevel = Math.min(maxLevel, safeFrom + 1);

  const applyPreset = (id: string) => {
    const p = ARBITRAGE_PRESETS.find((x) => x.id === id);
    if (!p) return;
    setPresetId(id);
    setMaxLevel(p.maxLevel);
    setFromLevel(p.fromLevel);
    setAnvilCost(p.anvilCost);
    setIsTreasure(p.isTreasure);
  };

  const result = useMemo(() => {
    const sc = scale / 100;
    const inc = branchForIncrementalMasterTome(safeFrom, toLevel, maxLevel, 10, discount);
    const full0 = branchForMasterTomeEnchant(toLevel, maxLevel, 10, discount);
    let full0Points = 0;
    for (let i = 1; i <= full0.tierCost; i++) {
      full0Points += xpNeededToReachNextLevelFrom(Math.max(0, full0.effectiveThreshold - i));
    }

    const curRefund = branchRefundForStepDown(
      toLevel,
      safeFrom,
      maxLevel,
      anvilCost,
      isTreasure,
      sc,
    );
    const curVHi = branchEssencePotential(toLevel, maxLevel, anvilCost, isTreasure, sc);
    const curVLo = branchEssencePotential(safeFrom, maxLevel, anvilCost, isTreasure, sc);
    const fakeScriptMin = compatScriptFakeMinPoints(maxLevel, toLevel);

    // 修复方案：1) baseMax 由 34/48 收敛至 22/28，凸度由 1.65 缓和至 1.25；
    //          2) 母本增量升阶最低门槛不得低于 max(12, round(24 * target/max)) 折后值
    const fixRarity =
      Math.max(1.0, Math.min(1.35, 1.0 + 0.14 * Math.log(Math.max(1, anvilCost)))) *
      (isTreasure ? 1.1 : 1.0);
    const fixBase = maxLevel === 1 ? 22 : 28;
    const fixVHi = Math.max(
      toLevel,
      Math.round(sc * fixBase * fixRarity * Math.pow(toLevel / maxLevel, 1.25)),
    );
    const fixVLo = Math.max(
      safeFrom,
      Math.round(sc * fixBase * fixRarity * Math.pow(safeFrom / maxLevel, 1.25)),
    );
    const fixRefund = Math.max(1, fixVHi - fixVLo);

    const xpSpent = inc.minPointsDeducted;
    const xpGained = applyFix ? fixRefund : curRefund;
    const netDelta = xpGained - xpSpent;

    return {
      inc,
      full0Points,
      curRefund,
      curVHi,
      curVLo,
      fakeScriptMin,
      fixRefund,
      xpSpent,
      xpGained,
      netDelta,
      exploitable: netDelta > 0,
    };
  }, [safeFrom, toLevel, maxLevel, anvilCost, isTreasure, discount, scale, applyFix]);

  return (
    <section id="arbitrage" className="relative max-w-6xl mx-auto px-6 md:px-10 py-20 md:py-32">
      <div
        className="absolute top-36 -left-20 font-display font-black text-[15rem] leading-none select-none pointer-events-none opacity-[0.035]"
        aria-hidden
      >
        漏
      </div>

      <SectionHead
        numeral="审壹"
        kicker="P0 EXPLOIT · INCREMENTAL vs STEP-DOWN ARBITRAGE"
        accent="#f08cc8"
        title={
          <>
            实锤套利：升一级扣 <span className="text-gild">35pt</span>，降一级返{" "}
            <span className="text-inkd">47pt</span>
          </>
        }
        blurb="CHANGELOG 与 compat_check.py 均宣称「已数学证明即使在 -40% 共鸣下退魔返还也严格低于母本重附成本」。这个证明对 0→L 全量铭刻成立，却漏掉了同一提交新增的 L-1→L「母本增量升阶」！凸势能把 68% 的返还集中在最后一级，而增量升阶却把扣级砍到了 1 级。"
      />

      {/* 为什么 CI 没抓出来 */}
      <Reveal>
        <div className="pixelframe bg-gradient-to-br from-[#2a1424] to-vellum border border-inkd/35 p-6 md:p-8 mb-8">
          <div className="flex items-start gap-4">
            <Bug className="text-inkd shrink-0 mt-1" size={22} />
            <div className="space-y-3">
              <p className="font-display text-lg md:text-xl font-bold text-parch">
                为什么 <span className="font-code text-inkd text-base">scripts/compat_check.py</span> 跑出了假绿灯？
              </p>
              <div className="grid md:grid-cols-2 gap-4 text-[12.5px] leading-6 text-mute font-light">
                <div className="rounded-sm bg-obsidian/65 border border-inkd/20 p-4">
                  <p className="font-code text-[11px] text-inkd mb-1.5">
                    原因 1 · 校验脚本硬编码了过时的假公式（L471）
                  </p>
                  <p>
                    Python 写的是 <span className="font-code text-parch">raw_req = round(8 + 22 * r)</span>，
                    算出最低消耗 <span className="font-code text-parch">{result.fakeScriptMin} pt</span>；
                    而 Java <span className="font-code text-tealw">XpCostConversion.java L80</span> 实际是{" "}
                    <span className="font-code text-parch">round(30 * r)</span>，两者早已漂移！
                  </p>
                </div>
                <div className="rounded-sm bg-obsidian/65 border border-inkd/20 p-4">
                  <p className="font-code text-[11px] text-inkd mb-1.5">
                    原因 2 · 只测了 0→L 全洗，完全漏测 L-1⇄L 单步循环
                  </p>
                  <p>
                    <span className="font-code text-tealw">forIncrementalMasterTomeEnchant</span> 对单步升级恒定只扣{" "}
                    <span className="font-code text-parch">tierCost = 1 级</span> 且再打{" "}
                    <span className="font-code text-parch">1 - 0.35·credit</span> 门槛折；而{" "}
                    <span className="font-code text-tealw">r^1.65</span> 凸函数在顶层斜率最陡，一升一降直接倒挂！
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Reveal>

      <div className="grid lg:grid-cols-5 gap-6">
        {/* 左侧真实源码公式 */}
        <Reveal className="lg:col-span-2 space-y-6">
          <FormulaCard
            tone="#f08cc8"
            title="分支实装公式 · 逐字对照"
            rows={[
              { lhs: "增量扣级", rhs: "delta/M ≤ 0.5001 ⟹ 恒扣 1 级" },
              { lhs: "增量门槛", rhs: "round(30·(1 − 0.35·L_cur/L_new)) × 0.6" },
              { lhs: "退魔势能 V", rhs: "round(48 · rarity · r^1.65) (M≥2)" },
              { lhs: "rarity", rhs: "clamp(1 + 0.18·ln(anvil), 1, 1.45) × 1.15(宝藏)" },
              { lhs: "单步返还", rhs: "V(L_new) − V(L_cur)（台面喷出经验球）" },
            ]}
          />

          <div className="pixelframe bg-abyss/75 border border-arcane/15 p-6 space-y-3">
            <p className="flex items-center gap-2 font-code text-[11px] tracking-[0.25em] text-xp">
              <Wrench size={13} /> 根治方案（两选一或组合）
            </p>
            <p className="text-[12.5px] leading-6 text-mute font-light">
              <span className="text-parch font-medium">① 压平退魔凸度并下调顶值：</span>将{" "}
              <span className="font-code text-xp">baseMax</span> 从 <span className="font-code">34 / 48</span> 调至{" "}
              <span className="font-code text-xp">22 / 28</span>，指数从{" "}
              <span className="font-code">1.65</span> 降至 <span className="font-code text-xp">1.25</span>，
              消除顶层斜率暴涨。
            </p>
            <p className="text-[12.5px] leading-6 text-mute font-light">
              <span className="text-parch font-medium">② 守恒硬钳制（最稳）：</span>在{" "}
              <span className="font-code text-tealw">refundForStepDown</span> 末尾直接钳制{" "}
              <span className="font-code text-xp">
                min(rawRefund, minPossibleIncrementalCost(L_cur, L_new) - 5)
              </span>
              ，从代数上杜绝任何模组参数组合出正收益！
            </p>
          </div>
        </Reveal>

        {/* 右侧交互验证台 */}
        <Reveal className="lg:col-span-3" delay={0.08}>
          <div className="pixelframe bg-vellum/75 border border-inkd/25 overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 px-6 py-4 border-b border-arcane/12">
              <p className="font-code text-[11px] tracking-[0.28em] text-inkd flex items-center gap-2">
                <Calculator size={13} /> LIVE EXPLOIT VERIFIER · 分支公式实测台
              </p>
              <button
                onClick={() => setApplyFix((v) => !v)}
                className="px-3 py-1 rounded-sm font-code text-[11px] border transition-all cursor-pointer"
                style={{
                  color: applyFix ? "#0a0913" : "#8df0a4",
                  background: applyFix ? "#8df0a4" : "rgba(141,240,164,0.08)",
                  borderColor: "#8df0a466",
                }}
              >
                {applyFix ? "✓ 已预览修复参数 (22/28, r^1.25)" : "点击预览修复后曲线"}
              </button>
            </div>

            <div className="p-6 md:p-7 space-y-6">
              {/* 预设 */}
              <div className="grid sm:grid-cols-2 gap-2">
                {ARBITRAGE_PRESETS.map((p) => {
                  const active = presetId === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => applyPreset(p.id)}
                      className="text-left px-3.5 py-2.5 rounded-sm border transition-all cursor-pointer"
                      style={{
                        background: active ? "rgba(240,140,200,0.14)" : "rgba(10,9,19,0.5)",
                        borderColor: active ? "#f08cc888" : "rgba(161,140,255,0.14)",
                      }}
                    >
                      <p className="text-[12.5px] font-medium text-parch">{p.name}</p>
                      <p className="font-code text-[10px] text-faint mt-0.5">{p.sub}</p>
                    </button>
                  );
                })}
              </div>

              {/* 滑块 */}
              <div className="grid sm:grid-cols-2 gap-5">
                <Slider
                  label="魔咒最高等级 maxLevel"
                  value={maxLevel}
                  min={2}
                  max={8}
                  onChange={(v) => {
                    setPresetId("custom");
                    setMaxLevel(v);
                    setFromLevel(Math.max(1, v - 1));
                  }}
                  format={(v) => `M = ${v}`}
                  accent="#a18cff"
                />
                <Slider
                  label={`测试单步区间（${ROMAN[safeFrom]} ⇄ ${ROMAN[toLevel]}）`}
                  value={safeFrom}
                  min={1}
                  max={Math.max(1, maxLevel - 1)}
                  onChange={(v) => {
                    setPresetId("custom");
                    setFromLevel(v);
                  }}
                  format={(v) => `${ROMAN[v]} ⇄ ${ROMAN[v + 1]}`}
                  accent="#e8c37c"
                />
                <Slider
                  label="Enchantment#getAnvilCost()"
                  value={anvilCost}
                  min={1}
                  max={16}
                  onChange={(v) => {
                    setPresetId("custom");
                    setAnvilCost(v);
                  }}
                  format={(v) => `${v}`}
                  accent="#7ee8dc"
                />
                <Slider
                  label="书库共鸣减免 (0%..40%)"
                  value={discount}
                  min={0}
                  max={40}
                  onChange={setDiscount}
                  format={(v) => `−${v}%`}
                  accent="#8df0a4"
                />
              </div>

              <div className="flex flex-wrap items-center gap-4">
                <button
                  onClick={() => {
                    setPresetId("custom");
                    setIsTreasure((v) => !v);
                  }}
                  className="px-3 py-1.5 rounded-sm font-code text-[11px] border cursor-pointer"
                  style={{
                    color: isTreasure ? "#e8c37c" : "#9c93bd",
                    borderColor: isTreasure ? "#e8c37c66" : "#6f659a44",
                    background: isTreasure ? "rgba(232,195,124,0.1)" : "transparent",
                  }}
                >
                  #minecraft:treasure = {String(isTreasure)}
                </button>
                <div className="flex-1 min-w-[180px]">
                  <Slider
                    label="disenchanting.json: xp_refund_scale"
                    value={scale}
                    min={50}
                    max={150}
                    onChange={setScale}
                    format={(v) => `${(v / 100).toFixed(2)}×`}
                    accent="#f08cc8"
                  />
                </div>
              </div>

              {/* 三栏对账 */}
              <div className="grid sm:grid-cols-3 gap-3 pt-1">
                <div className="pixelframe bg-obsidian/70 border border-arcane/15 p-4">
                  <p className="font-code text-[10px] text-mute mb-1">
                    ① 母本增量升阶 ({ROMAN[safeFrom]}→{ROMAN[toLevel]})
                  </p>
                  <p className="font-display text-3xl font-black text-gild">
                    -{result.xpSpent} <span className="text-xs font-code text-mute">pt</span>
                  </p>
                  <p className="font-code text-[10px] text-faint mt-1.5">
                    门槛 Lv.{result.inc.effectiveThreshold} · 仅扣 {result.inc.tierCost} 级
                  </p>
                </div>

                <div className="pixelframe bg-obsidian/70 border border-arcane/15 p-4">
                  <p className="font-code text-[10px] text-mute mb-1">
                    ② 退魔页降级 ({ROMAN[toLevel]}→{ROMAN[safeFrom]})
                  </p>
                  <p className="font-display text-3xl font-black text-xp">
                    +{result.xpGained} <span className="text-xs font-code text-mute">pt</span>
                  </p>
                  <p className="font-code text-[10px] text-faint mt-1.5">
                    0 材料 · V({toLevel})−V({safeFrom}) 经验球
                  </p>
                </div>

                <motion.div
                  key={`${result.netDelta}-${applyFix}`}
                  initial={{ scale: 0.96 }}
                  animate={{ scale: 1 }}
                  className="pixelframe p-4 border"
                  style={{
                    background: result.exploitable
                      ? "rgba(240,140,200,0.12)"
                      : "rgba(141,240,164,0.08)",
                    borderColor: result.exploitable ? "#f08cc877" : "#8df0a455",
                  }}
                >
                  <p className="font-code text-[10px] text-mute mb-1">③ 单轮循环净损益</p>
                  <p
                    className="font-display text-3xl font-black"
                    style={{ color: result.exploitable ? "#f08cc8" : "#8df0a4" }}
                  >
                    {result.netDelta > 0 ? `+${result.netDelta}` : result.netDelta}{" "}
                    <span className="text-xs font-code text-mute">pt</span>
                  </p>
                  <p className="font-code text-[10px] mt-1.5 flex items-center gap-1">
                    {result.exploitable ? (
                      <span className="text-inkd flex items-center gap-1">
                        <AlertOctagon size={11} /> 1 材料换 +{result.netDelta}XP + 修补全身
                      </span>
                    ) : (
                      <span className="text-xp flex items-center gap-1">
                        <CheckCircle2 size={11} /> 净消耗沉淀 · 守恒成立
                      </span>
                    )}
                  </p>
                </motion.div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-code text-faint border-t border-arcane/10 pt-3">
                <span>
                  对照：0→{ROMAN[toLevel]} 全量母本铭刻最低扣 {result.full0Points} pt（所以全洗不刷，唯独单步升降级倒挂）
                </span>
                <Chip tone={result.exploitable ? "#f08cc8" : "#8df0a4"}>
                  {result.exploitable ? "EXPLOIT CONFIRMED" : "GUARDED"}
                </Chip>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default ArbitrageLab;
