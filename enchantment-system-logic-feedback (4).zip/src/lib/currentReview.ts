// Current-HEAD review for the requested arena branch.
// Functional fixes landed in 2f6979b; HEAD a45d319e only adds CI reports.

export type ReviewPriority = "P1" | "P2" | "INFO";

export interface ReviewFinding {
  id: string;
  priority: ReviewPriority;
  category: string;
  title: string;
  location: string;
  issue: string;
  evidence: string;
  recommendation: string;
}

export const BRANCH_INFO = {
  branch: "arena/d0fffdab-chiseled-enchanting-table-26-1",
  head: "a45d319e",
  functionalFix: "2f6979b",
  functionalFixTitle: "fix(economy,mechanics,data): resolve all ZIP audit vulnerabilities",
};

export const RESOLVED_SINCE_LAST_REVIEW = [
  {
    title: "升级 / 降级 XP 对偶套利",
    detail:
      "改为逐阶计算 V(k)，并在势能表生成时同时受完整铭刻成本与每一条增量升阶成本约束；以当前默认配置复算，锋利/冰霜行者/迅捷潜行均不再出现 XP 正收益循环。",
  },
  {
    title: "白板直附越过半级上限",
    detail:
      "新增 HALF_CEIL blank cap；木书架 38 阶梯只用于已带有该词条的装备直升与附魔书研究，雕纹母本路线独立保留。",
  },
  {
    title: "残卷免费档复制同一词条、M=2 误判 MAX−1",
    detail:
      "免费档改按去重后的 Master Tome map 计不同魔咒；M=2 必须满级，M=1 自动按 I 级合格。",
  },
  {
    title: "普通书架只识别原版书架、覆写批次套利",
    detail:
      "普通书架改走 regular_bookshelves 标签 / 原版附魔供能标签；空白覆写增加 8/64 批次档并按批线性缩放材料与经验。",
  },
  {
    title: "拆台掉落携带无用随机种子、改书架无法刷新",
    detail:
      "未冻结时不再写入 CUSTOM_DATA；菜单服务端定时重扫并在执行操作前刷新书架状态。",
  },
  {
    title: "退魔替代耗材、物品标签与书堆叠配置",
    detail:
      "退魔配置现在含秘法凝晶独立方案及纯原版替代；置换支持输入标签和 min_player_level 字段；附魔书堆叠上限有启动配置。",
  },
];

export const CURRENT_FINDINGS: ReviewFinding[] = [
  {
    id: "CFG-01",
    priority: "P1",
    category: "数据包配置未生效",
    title: "library_resonance.json 的嵌套 schema 与 Java 解析器完全不匹配",
    location:
      "data/.../library_resonance.json · mechanics/resonance/LibraryResonance.java#Config.fromJson",
    issue:
      "JSON 把设置放在 wooden_bookshelves / chiseled_mastery / epiphany_affinity 三个嵌套对象内；Java 却只从 root 读取 min_discount_bookshelves、max_wooden_discount_percent、mastery_unit_exponent 等扁平键。当前随包 JSON 的绝大多数参数会被静默忽略，运行时落到 Config.DEFAULT。",
    evidence:
      "例如 JSON 宣告木架减免上限 12%（W=32 封顶）、全局母本上限 13%、base 上限 25%、incremental_threshold_credit_factor=0.35；当前 DEFAULT 则是 maxDiscountBookshelves=38、maxWooden=15%、maxGlobal=20%、maxBase=35%、credit=0.85。JSON 的 0.45r+0.55r² 权重也未被实现，Java 实际使用 r^1.25。",
    recommendation:
      "选定一份 schema 并统一：要么把 JSON 扁平化以匹配现解析器，要么让 fromJson 明确解析三个子对象，并增加 JSON→Config 的 golden test。加载时记录最终生效配置，避免静默退回默认值。",
  },
  {
    id: "XP-01",
    priority: "P1",
    category: "经验价格与文档漂移",
    title: "物品置换 xp_cost 被当作“扣除等级数”，min_player_level 也变成了扣费下限",
    location: "mechanics/enchanting/XpCostConversion.java#forTransformation · item_transformations.json",
    issue:
      "forTransformation 将 deducted=max(configuredMinPlayerLevel, round(xp_cost×(1−discount)))，再把 deducted 同时写入 requiredLevel 与 deductedLevels。字段 min_player_level 因此不只是门槛，也会强制扣至少这么多等级；xp_cost=8 就扣 8 级，而不是把 8 映射为原版量产模式的 2 级。",
    evidence:
      "现随包值会得到：附魔之瓶 xp_cost=2/min_player_level=3 → 门槛 Lv.3、扣 3 级；附魔金苹果 8 → Lv.8/扣 8；回响碎片 5 → Lv.5/扣 5；三叉戟 10 → Lv.10/扣 10；图腾 12 → Lv.12/扣 12。WIKI §4/§8 仍分别宣称 Lv.5/1、Lv.20/2、Lv.12/2、Lv.25/3、Lv.30/3。",
    recommendation:
      "拆开 JSON/模型字段：required_player_level（只校验门槛）与 deducted_levels（实际等级扣除），或明确 xp_cost 的单位并设计独立映射。保持 UI 的 XP badge、JEI/REI 和 WIKI 使用同一解析结果。",
  },
  {
    id: "XP-02",
    priority: "P1",
    category: "经验条进度语义",
    title: "vanillaTierMode 只影响图标；扣费忽略进度条，无法实现文档承诺的“保留百分比”",
    location: "mechanics/enchanting/XpCostConversion.java#deductXp / #pointsForLevelCost",
    issue:
      "所有 XP 模式最终都走 giveExperiencePoints(-pointsForLevelCost(...))；vanillaTierMode 没有参与扣除分支，pointsForLevelCost 也完全不读取 player.experienceProgress。因而绿色“扣 1/2/3 级”徽标表示的并非原版 giveExperienceLevels(-n) 行为，进度条不会按比例保留。",
    evidence:
      "以 Lv.30、进度 99%、扣 1 级为例：方法固定扣 xpPointsForLevel(29)=107；当前进度约有 0.99×112=110.88 点，扣后仍显示 Lv.30（约 3.9/112 进度），同一最低门槛可能继续执行一次。原版扣 1 级并保留 99% 进度应落到 Lv.29、99%。这不是 XP 净生成，但会改变等级门槛下的量产次数。",
    recommendation:
      "若目标真是原版等级语义：vanillaTierMode 使用 giveExperienceLevels(-n)；若目标是点数语义：纳入当前进度计算精确点数，并把徽标/提示改成 XP points，删除“保留经验条百分比”的文案。",
  },
  {
    id: "TEST-01",
    priority: "P1",
    category: "经济证明与 CI 漂移",
    title: "compat_check.py 没有复刻 Java 实际势能公式，也没有穷举 M=1..255 的增量路径",
    location: "scripts/compat_check.py#check_disenchanting_and_anti_arbitrage · DisenchantmentApplication#verifyRuntimeConservation",
    issue:
      "修复提交宣称对 M=1..255 做严格数学证明，但 CI 实际只跑 M=1..19、30、64、127、150、255；增量比较又只在 M<=20 执行。更重要的是，Python 与 Java 两边公式参数不同，绿灯不能代表审计的是正在运行的实现。",
    evidence:
      "Java 增量扣级阈值来自 vanillaTierDeduction（0.40/0.75 分界，允许 1/2/3 级），门槛为 8+22×max(0.15,targetFraction−credit×prevFraction)；Python 用 0.50 二分 1/2 级、6+20×targetFraction。Java 势能系数为 34/48、稀有倍率 1.45×1.15；Python 表用 30/40、1.30×1.12。运行时 self-check 本身也只核验完整 0→k 成本，没有断言所有 a→k 增量不等式。",
    recommendation:
      "把公式抽成可共享的纯函数 / 测试向量，CI 对实际运行算法生成势能表并断言所有 0<=a<k<=M 的 refund <= minPointsRequired(a→k)−margin；增加 M=20..255 的覆盖，避免保留两个不同版本的“证明”。",
  },
  {
    id: "SHELF-01",
    priority: "P1",
    category: "高等级模组附魔兼容性",
    title: "38 个书架不足以给 maxLevel=255 的每一级一个严格递增门槛；当前 clamp 让 1 架解锁 217 级",
    location: "mechanics/resonance/BookshelfProgression.java#requiredBookshelvesForDirectTier",
    issue:
      "当前公式在 cap 小于级数时用 minAllowed/maxAllowed 硬钳整数门槛。随着 M 超过 39，许多等级不可避免地共用同一门槛；当前钳制尤其把很长的低级段压在 1 架。",
    evidence:
      "按当前默认 gamma=1.25、anchor=38 精确复算：M=255 只有 39 个不同门槛，等级 II–CCXVIII（II–218，共 217 级）都要求 1 个普通书架；再往后每级才逐渐升门槛。compat_check 的单调性用例只测到 maxLevel=25，因此不会发现此情况。",
    recommendation:
      "不要宣称 M=1..255 每级都有严格递增书架数（数学上不可能：39 个门槛状态不足以映射 255 个等级）。改成按书架数反算可解锁层级、明确允许每档解锁多级，并在 UI 标注“本档解锁 I–N”；为 M=40/100/255 加行为测试。",
  },
  {
    id: "PERF-01",
    priority: "P2",
    category: "数据包可配置范围 / 性能",
    title: "scan_volume 半径允许到 16，动态半径路径会每帧分配并扫描 35,936 个方块",
    location: "BookshelfProgression.Config.fromJson · ChiseledEnchantingTableBlock#animateTick · ScreenHandler#refreshLiveShelfState",
    issue:
      "配置允许 horizontal_radius=16、vertical_radius=16；每台附魔台的空间检查体积可达 33×33×33−1=35,936 格。非默认半径时 animateTick 每次调用 getScanOffsets 都重新创建整张 BlockPos 列表；菜单每秒做 live refresh，而 computeLiveShelfState 又分别计算 shelfPower 与 unlocked enchantments，重复扫描。",
    evidence:
      "最大配置下客户端动画路径每秒最多创建/访问约 71.9 万个位置（20 tick/s × 35,936）；每个打开的菜单每秒至少做双份 35,936 格扫描。多个表/玩家或资源包把范围设大时会引入显著 GC 与 tick 延迟。默认 7×5×7（244 格）不受影响。",
    recommendation:
      "将扫描体积设总格数上限，缓存按半径组合生成的 offsets，并让 computeLiveShelfState 复用一次 ShelfPower 结果；动画粒子采样应使用固定小预算，而非遍历完整体积。",
  },
  {
    id: "JEI-01",
    priority: "P2",
    category: "服务器配置同步 / 查询器",
    title: "JEI/REI 的退魔预览仍用 sharpness III 本地成本，却标记为 serverCosts=true",
    location: "compat/TransformationQueryIndex.java#build",
    issue:
      "全洗结果现已正确展示 depleted_tome，XP 预览也读取同步的 refund scale；但定向洗与祛诅咒伪配方仍硬编码 sharpness(III, M=5)，从客户端 ChiseledEnchantingTableData 读成本，并将 serverCosts 直接写 true。",
    evidence:
      "专用服改 targeted_strip / curse_purge 的 xp_cost、耗材数量或替代 bundle 后，JEI/REI 仍显示 sharpness 样本成本；serverCosts=true 会让 Viewer 将其作为服务器权威数据展示。",
    recommendation:
      "优先读取 SyncedEnchantmentCosts.find(type, sampleId, level)，区分“公式示例”与“精确配方”；无法显示任意目标词条时，改显示数据包公式/成本范围，不要用真实配方样式伪装为精确数据。",
  },
  {
    id: "SYNC-01",
    priority: "P2",
    category: "专用服数据包同步",
    title: "LibraryResonance 配置虽放入 S2C 包，XP 纯函数仍从本地 activeConfig 读取",
    location:
      "compat/SyncedEnchantmentCosts.java#libraryResonanceConfig · XpCostConversion.java · DisenchantmentApplication.java",
    issue:
      "payload 已同步 LibraryResonance.Config，ScreenHandler 的木架/减免计算也会取服务器副本；但增量 XP 仍从 LibraryResonance.activeConfig() 读取 incrementalStepCreditFactor/maxTotalDiscount，退魔势能上限也从 activeConfig() 读取 maxTotalXpDiscountPercent。专用服仅服务器覆盖数据包时，客户端预览可能采用另一组公式。",
    evidence:
      "SyncedEnchantmentCosts.libraryResonanceConfig() 明确返回 S2C payload；XpCostConversion.forIncrementalMasterTomeEnchant 与 clampDiscount、DisenchantmentApplication.essencePotentialFromParams 却直接调用 LibraryResonance.activeConfig()。当前随包 JSON 的 schema 未生效暂时掩盖了这条分歧；若修好 JSON 解析后，服务端 flat override 将让客户端 tooltip/JEI 和服务器执行值分叉。",
    recommendation:
      "让公式接受显式 Config 参数，并由 ScreenHandler 在 server/client 两侧传入权威副本；或在客户端复算时使用 SyncedEnchantmentCosts.libraryResonanceConfig()，不要在 shared math 中隐式读取本地数据管理器。",
  },
  {
    id: "XP-03",
    priority: "P2",
    category: "经验返还粒度",
    title: "maxLevel=255 时整型势能量化会令很多相邻降级返还 0 XP",
    location: "mechanics/enchanting/DisenchantmentApplication.java#essencePotentialFromParams",
    issue:
      "V 基于相对等级、总尺度约 48 点并最终 round 到整数。对 255 级附魔，单级的平均势能增量远小于 1 点；当前实现允许 V(k)=V(k−1)，所以“降一级返还经验”的行可能完全不产经验。",
    evidence:
      "当前默认参数下 M=255 的低阶势能表在若干连续等级上保持 0；高阶也有大量相邻等级差为 0。大跨度降级仍按总势能差返还，不会套利，但细粒度体验与“自动支持 1..255”文案存在落差。",
    recommendation:
      "接受并显式显示“本级返还 0 XP”，或用更高精度定点势能/残余小数累积；不要简单把每步最低返还钳到 1 XP，否则会破坏已建立的增量成本上界。",
  },
];

export interface DriftItem {
  topic: string;
  doc: string;
  runtime: string;
  status: string;
  tone: string;
}

export const CURRENT_DRIFT: DriftItem[] = [
  {
    topic: "Library Resonance 配置",
    doc: "JSON 使用 nested wooden_bookshelves / chiseled_mastery / epiphany_affinity，并在 Wiki 声称数据包可调",
    runtime: "Config.fromJson 只读取 root 扁平键；当前 JSON 大部分值被忽略，实际走 Java DEFAULT",
    status: "确认漂移 · P1",
    tone: "#f08cc8",
  },
  {
    topic: "置换经验模式",
    doc: "WIKI §4/§8：置换绿球量产，仅扣 1–3 级并单独设最低门槛",
    runtime: "forTransformation 把 xp_cost 直接作为 deductedLevels，并将 min_player_level 也并入扣费下限",
    status: "确认漂移 · P1",
    tone: "#f08cc8",
  },
  {
    topic: "经验条百分比",
    doc: "WIKI §4：mass-production 扣级后保留经验条进度百分比",
    runtime: "deductXp 对所有模式 giveExperiencePoints；pointsForLevelCost 不读取 experienceProgress",
    status: "确认漂移 · P1",
    tone: "#e8c37c",
  },
  {
    topic: "高 maxLevel 阶梯",
    doc: "WIKI：maxLevel=1..255 均严格单调递增，38 架解锁 MAX",
    runtime: "38 个书架增量状态最多 39 个门槛；M=255 时 217 个等级同为 1 架门槛",
    status: "算法边界未文档化 · P1",
    tone: "#7ee8dc",
  },
  {
    topic: "无套利 CI 证明",
    doc: "功能提交声称按 M=1..255 做严格归纳证明",
    runtime: "Python 参数/公式不同于 Java；仅稀疏测试 M，且 step 检查仅覆盖 M<=20",
    status: "验证器不等价 · P1",
    tone: "#a18cff",
  },
  {
    topic: "专用服共鸣参数同步",
    doc: "成本 payload 包含 LibraryResonance.Config，供客户端显示服务器真实规则",
    runtime: "部分共享 XP/退魔公式仍读客户端本地 LibraryResonance.activeConfig()",
    status: "存在潜在预览分叉 · P2",
    tone: "#e8c37c",
  },
];

export const XP_MODE_PRESETS = [
  { id: "frost", name: "冰霜行者 I→II", max: 2, from: 1, to: 2, anvil: 4, treasure: true, rawCost: 10 },
  { id: "fire", name: "火焰附加 I→II", max: 2, from: 1, to: 2, anvil: 4, treasure: false, rawCost: 10 },
  { id: "swift", name: "迅捷潜行 II→III", max: 3, from: 2, to: 3, anvil: 8, treasure: true, rawCost: 11 },
  { id: "sharp", name: "锋利 IV→V", max: 5, from: 4, to: 5, anvil: 1, treasure: false, rawCost: 10 },
];

export function xpPointsForLevel(level: number): number {
  if (level >= 30) return 112 + (level - 30) * 9;
  if (level >= 15) return 37 + (level - 15) * 5;
  return 7 + Math.max(0, level) * 2;
}

export function minPointsForLevelCost(requiredLevel: number, deductedLevels: number): number {
  const start = Math.max(requiredLevel, deductedLevels);
  let points = 0;
  for (let i = 0; i < deductedLevels; i++) points += xpPointsForLevel(start - 1 - i);
  return points;
}

export function masterTierCost(level: number, maxLevel: number): number {
  const max = Math.max(1, maxLevel);
  if (max <= 1) return 3;
  const r = Math.max(1, Math.min(level, max)) / max;
  return r <= 0.4 ? 1 : r <= 0.75 ? 2 : 3;
}

export function incrementalMasterCost(
  existing: number,
  target: number,
  maxLevel: number,
  discount = 40,
  credit = 0.85,
  rawTargetCost = 0,
): { tier: number; threshold: number; xp: number } {
  const max = Math.max(1, maxLevel);
  const delta = Math.max(1, target - Math.max(0, existing));
  const tier = masterTierCost(delta, max);
  const targetFraction = Math.min(max, target) / max;
  const prevFraction = Math.min(max, Math.max(0, existing)) / max;
  const remaining = Math.max(0.15, targetFraction - credit * prevFraction);
  const minStep = Math.max(tier, Math.round(8 + 22 * remaining));
  const scaledRaw = rawTargetCost > 0
    ? Math.max(tier, Math.round(rawTargetCost * (targetFraction <= 0 ? 1 : remaining / targetFraction)))
    : minStep;
  const raw = Math.max(minStep, scaledRaw);
  const threshold = Math.max(tier, Math.round(raw * (1 - discount / 100)));
  return { tier, threshold, xp: minPointsForLevelCost(threshold, tier) };
}

export function fullMasterCost(level: number, maxLevel: number, discount = 40): { tier: number; threshold: number; xp: number } {
  const max = Math.max(1, maxLevel);
  const tier = masterTierCost(level, max);
  const r = Math.max(1, Math.min(level, max)) / max;
  const raw = Math.max(tier, Math.round(8 + 22 * r));
  const threshold = Math.max(tier, Math.round(raw * (1 - discount / 100)));
  return { tier, threshold, xp: minPointsForLevelCost(threshold, tier) };
}

export function potentialTable(
  maxLevel: number,
  anvilCost: number,
  treasure: boolean,
  discount = 40,
  credit = 0.85,
): number[] {
  const max = Math.max(1, maxLevel);
  const rarity = Math.min(1.45, Math.max(1, 1 + 0.18 * Math.log(Math.max(1, anvilCost)))) * (treasure ? 1.15 : 1);
  const base = max === 1 ? 34 : 48;
  const v = Array(max + 1).fill(0) as number[];
  for (let k = 1; k <= max; k++) {
    const desired = Math.round(base * rarity * Math.pow(k / max, 1.65));
    let cap = Math.max(0, fullMasterCost(k, max, discount).xp - 5);
    for (let a = 1; a < k; a++) {
      const step = incrementalMasterCost(a, k, max, discount, credit).xp;
      cap = Math.min(cap, Math.max(0, v[a] + step - 5));
    }
    v[k] = Math.max(v[k - 1], Math.min(desired, cap));
  }
  return v;
}

export function calculateXpLoop(
  maxLevel: number,
  fromLevel: number,
  targetLevel: number,
  anvilCost: number,
  treasure: boolean,
  discount = 40,
  credit = 0.85,
  rawTargetCost = 0,
) {
  const v = potentialTable(maxLevel, anvilCost, treasure, discount, credit);
  const spend = incrementalMasterCost(fromLevel, targetLevel, maxLevel, discount, credit, rawTargetCost).xp;
  const refund = v[Math.min(maxLevel, targetLevel)] - v[Math.min(maxLevel, fromLevel)];
  return { spend, refund, net: spend - refund, v };
}

export function directShelfRequirement(
  level: number,
  maxLevel: number,
  gamma = 1.25,
  anchor = 38,
): number {
  const max = Math.max(1, maxLevel);
  const target = Math.max(1, Math.min(max, level));
  if (max <= 1 || target <= 1) return 0;
  if (target >= max) return anchor;
  const progress = (target - 1) / (max - 1);
  const raw = Math.floor(anchor * Math.pow(progress, gamma) + 0.5);
  const minAllowed = Math.min(anchor - 1, target - 1);
  const maxAllowed = Math.max(1, anchor - (max - target));
  return Math.max(Math.min(minAllowed, maxAllowed), Math.min(raw, maxAllowed));
}

export function shelfGateStats(maxLevel: number, gamma = 1.25, anchor = 38) {
  const gates = Array.from({ length: Math.max(1, maxLevel) }, (_, i) =>
    directShelfRequirement(i + 1, maxLevel, gamma, anchor),
  );
  const groups = new Map<number, { first: number; last: number; count: number }>();
  gates.forEach((gate, index) => {
    const found = groups.get(gate);
    if (found) {
      found.last = index + 1;
      found.count++;
    } else {
      groups.set(gate, { first: index + 1, last: index + 1, count: 1 });
    }
  });
  const largestGroup = [...groups.entries()].sort((a, b) => b[1].count - a[1].count)[0];
  return {
    gates,
    uniqueGateCount: groups.size,
    largestGroup: largestGroup ? { shelves: largestGroup[0], ...largestGroup[1] } : null,
    statesAvailable: anchor + 1,
  };
}

export function scanVolume(horizontalRadius: number, verticalRadius: number): number {
  return Math.max(0, (2 * horizontalRadius + 1) ** 2 * (2 * verticalRadius + 1) - 1);
}

export const TRANSFORMATION_XP_EXAMPLES = [
  { id: "blank_overwrite", name: "残卷 → 书", rawCost: 1, minPlayerLevel: 1, wikiLevel: 1, wikiDeduct: 1 },
  { id: "experience_bottle", name: "玻璃瓶 → 附魔之瓶", rawCost: 2, minPlayerLevel: 3, wikiLevel: 5, wikiDeduct: 1 },
  { id: "echo_shard", name: "紫水晶 → 回响碎片", rawCost: 5, minPlayerLevel: 1, wikiLevel: 12, wikiDeduct: 2 },
  { id: "enchanted_golden_apple", name: "金苹果 → 附魔金苹果", rawCost: 8, minPlayerLevel: 1, wikiLevel: 20, wikiDeduct: 2 },
  { id: "trident", name: "钻石剑 → 三叉戟", rawCost: 10, minPlayerLevel: 1, wikiLevel: 25, wikiDeduct: 3 },
  { id: "totem_of_undying", name: "绿宝石块 → 不死图腾", rawCost: 12, minPlayerLevel: 1, wikiLevel: 30, wikiDeduct: 3 },
];

export function currentTransformationXp(rawCost: number, minPlayerLevel: number, discount = 0) {
  if (rawCost <= 0) return { requiredLevel: 0, deductedLevels: 0 };
  const deductedLevels = Math.max(
    Math.max(1, minPlayerLevel),
    Math.round(rawCost * (1 - Math.max(0, Math.min(40, discount)) / 100)),
  );
  return { requiredLevel: deductedLevels, deductedLevels };
}

export function xpTotalAtLevel(level: number): number {
  const safe = Math.max(0, level);
  let sum = 0;
  for (let l = 0; l < safe; l++) sum += xpPointsForLevel(l);
  return sum;
}

export function xpCostAtProgress(level: number, progress: number, levelCost: number): number {
  const target = Math.max(0, level - levelCost);
  const currentTotal = xpTotalAtLevel(level) + Math.round(progress * xpPointsForLevel(level));
  const targetTotal = xpTotalAtLevel(target) + Math.round(progress * xpPointsForLevel(target));
  return Math.max(0, currentTotal - targetTotal);
}

export function xpCostAtZeroProgress(level: number, levelCost: number): number {
  const target = Math.max(0, level - levelCost);
  return Math.max(0, xpTotalAtLevel(level) - xpTotalAtLevel(target));
}

export function levelAfterPointDebit(level: number, progress: number, points: number) {
  const currentTotal = xpTotalAtLevel(level) + Math.round(progress * xpPointsForLevel(level));
  const remaining = Math.max(0, currentTotal - points);
  let nextLevel = 0;
  while (xpTotalAtLevel(nextLevel + 1) <= remaining && nextLevel < 500) nextLevel++;
  const barWidth = xpPointsForLevel(nextLevel);
  const nextProgress = (remaining - xpTotalAtLevel(nextLevel)) / Math.max(1, barWidth);
  return { level: nextLevel, progress: Math.max(0, Math.min(1, nextProgress)) };
}