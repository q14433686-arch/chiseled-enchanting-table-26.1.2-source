// ─────────────────────────────────────────────────────────────
// 分支源码精确复刻与审查数据库
// Target: q14433686-arch/chiseled-enchanting-table-26.1.2-source
// Branch: arena/d0fffdab-chiseled-enchanting-table-26-1
// ─────────────────────────────────────────────────────────────

export type Severity = "P0" | "P1" | "P2" | "P3";
export type AuditCategory = "hardcode" | "compat" | "economy" | "sync" | "docs";

/** 原版每级所需经验点数 — 1:1 复刻 XpCostConversion#xpNeededToReachNextLevelFrom */
export function xpNeededToReachNextLevelFrom(level: number): number {
  if (level < 16) return 2 * level + 7;
  if (level < 31) return 5 * level - 38;
  return 9 * level - 158;
}

/** 1:1 复刻 XpCostConversion#forMasterTomeEnchant */
export function branchForMasterTomeEnchant(
  level: number,
  maxLevel: number,
  rawBaseXpCost: number,
  discountPercent: number,
) {
  const safeMax = Math.max(1, maxLevel);
  const safeLvl = Math.max(1, Math.min(safeMax, level));
  let tierCost: number;
  let rawThreshold: number;
  if (safeMax === 1) {
    tierCost = rawBaseXpCost >= 10 ? 3 : 2;
    rawThreshold = tierCost === 3 ? 30 : 20;
  } else {
    const r = safeLvl / safeMax;
    tierCost = r <= 0.4001 ? 1 : r < 0.7999 ? 2 : 3;
    rawThreshold = Math.max(tierCost, Math.min(30, Math.round(30 * r)));
  }
  const clampedDisc = Math.max(0, Math.min(40, discountPercent));
  const effectiveThreshold =
    clampedDisc > 0
      ? Math.max(tierCost, Math.round((rawThreshold * (100 - clampedDisc)) / 100))
      : rawThreshold;
  return { tierCost, rawThreshold, effectiveThreshold };
}

/** 1:1 复刻 XpCostConversion#forIncrementalMasterTomeEnchant */
export function branchForIncrementalMasterTome(
  existingLevel: number,
  targetLevel: number,
  maxLevel: number,
  rawBaseXpCost: number,
  discountPercent: number,
) {
  const full = branchForMasterTomeEnchant(targetLevel, maxLevel, rawBaseXpCost, 0);
  const safeMax = Math.max(1, maxLevel);
  const delta = Math.max(1, targetLevel - existingLevel);
  const deltaRatio = delta / safeMax;
  const tierCost = deltaRatio <= 0.5001 ? 1 : 2;
  const progressCredit = Math.max(0, Math.min(0.85, existingLevel / Math.max(1, targetLevel)));
  const rawThreshold = Math.max(
    tierCost,
    Math.round(full.rawThreshold * (1 - 0.35 * progressCredit)),
  );
  const clampedDisc = Math.max(0, Math.min(40, discountPercent));
  const effectiveThreshold =
    clampedDisc > 0
      ? Math.max(tierCost, Math.round((rawThreshold * (100 - clampedDisc)) / 100))
      : rawThreshold;

  // 玩家恰好在门槛等级 (progress = 0) 执行 giveExperienceLevels(-tierCost) 实际扣除的经验点数
  let minPointsDeducted = 0;
  for (let i = 1; i <= tierCost; i++) {
    minPointsDeducted += xpNeededToReachNextLevelFrom(Math.max(0, effectiveThreshold - i));
  }
  return { tierCost, rawThreshold, effectiveThreshold, minPointsDeducted };
}

/** 1:1 复刻 DisenchantmentApplication#essencePotential */
export function branchEssencePotential(
  level: number,
  maxLevel: number,
  anvilCost: number,
  isTreasure: boolean,
  scale = 1.0,
): number {
  if (level <= 0 || scale <= 0) return 0;
  const safeMax = Math.max(1, maxLevel);
  const clampedLevel = Math.min(level, safeMax);
  const r = Math.max(0, Math.min(1, clampedLevel / safeMax));
  const safeAnvil = Math.max(1, anvilCost);
  const rarityFactor =
    Math.max(1.0, Math.min(1.45, 1.0 + 0.18 * Math.log(safeAnvil))) * (isTreasure ? 1.15 : 1.0);
  const baseMax = safeMax === 1 ? 34.0 : 48.0;
  const raw = Math.round(scale * baseMax * rarityFactor * Math.pow(r, 1.65));
  return Math.max(clampedLevel, raw);
}

/** 1:1 复刻 DisenchantmentApplication#refundForStepDown */
export function branchRefundForStepDown(
  currentLevel: number,
  targetLevel: number,
  maxLevel: number,
  anvilCost: number,
  isTreasure: boolean,
  scale = 1.0,
): number {
  if (currentLevel <= targetLevel || currentLevel <= 0) return 0;
  const curV = branchEssencePotential(currentLevel, maxLevel, anvilCost, isTreasure, scale);
  const nextV =
    targetLevel <= 0
      ? 0
      : branchEssencePotential(targetLevel, maxLevel, anvilCost, isTreasure, scale);
  return Math.max(1, curV - nextV);
}

/** 1:1 复刻 compat_check.py 第 467 行的过时假公式（用于揭示为何 CI 漏检套利） */
export function compatScriptFakeMinPoints(maxLevel: number, targetLevel: number): number {
  const cappedMax = Math.max(1, maxLevel);
  const lvl = Math.max(1, Math.min(targetLevel, cappedMax));
  const tier =
    cappedMax <= 1 ? 3 : lvl / cappedMax <= 0.4 ? 1 : lvl / cappedMax <= 0.75 ? 2 : 3;
  const rawReq = Math.max(tier, Math.round(8 + 22 * (lvl / cappedMax)));
  const req = Math.max(tier, Math.round(rawReq * 0.6));
  let pts = 0;
  for (let l = req - 1; l > req - tier - 1; l--) {
    pts += xpNeededToReachNextLevelFrom(Math.max(0, l));
  }
  return pts;
}

/** 1:1 复刻 BookshelfProgression#requiredBookshelvesForDirectTier */
export function branchRequiredShelves(targetLevel: number, maxLevel: number, gamma = 1.11, anchor = 38): number {
  const safeMax = Math.max(1, maxLevel);
  const safeTarget = Math.max(1, Math.min(safeMax, targetLevel));
  if (safeMax <= 1 || safeTarget <= 1) return 0;
  if (safeTarget >= safeMax) return anchor;
  const progress = (safeTarget - 1) / (safeMax - 1);
  const raw = Math.round(anchor * Math.pow(progress, gamma));
  const minAllowed = Math.min(anchor - 1, safeTarget - 1);
  const maxAllowed = Math.max(1, anchor - (safeMax - safeTarget));
  return Math.max(Math.min(minAllowed, maxAllowed), Math.min(raw, maxAllowed));
}

export interface ArbitragePreset {
  id: string;
  name: string;
  sub: string;
  maxLevel: number;
  fromLevel: number;
  toLevel: number;
  anvilCost: number;
  isTreasure: boolean;
  isVanilla: boolean;
}

export const ARBITRAGE_PRESETS: ArbitragePreset[] = [
  {
    id: "frost_walker",
    name: "冰霜行者 I ⇄ II",
    sub: "原版宝藏 · M=2 · anvilCost=4",
    maxLevel: 2,
    fromLevel: 1,
    toLevel: 2,
    anvilCost: 4,
    isTreasure: true,
    isVanilla: true,
  },
  {
    id: "fire_aspect",
    name: "火焰附加 / 击退 / 冲击 I ⇄ II",
    sub: "原版常规 · M=2 · anvilCost=4",
    maxLevel: 2,
    fromLevel: 1,
    toLevel: 2,
    anvilCost: 4,
    isTreasure: false,
    isVanilla: true,
  },
  {
    id: "swift_sneak",
    name: "迅捷潜行 / 灵魂疾行 II ⇄ III",
    sub: "原版宝藏 · M=3 · anvilCost=8",
    maxLevel: 3,
    fromLevel: 2,
    toLevel: 3,
    anvilCost: 8,
    isTreasure: true,
    isVanilla: true,
  },
  {
    id: "wind_burst",
    name: "风爆 II ⇄ III",
    sub: "原版宝藏 · M=3 · anvilCost=4",
    maxLevel: 3,
    fromLevel: 2,
    toLevel: 3,
    anvilCost: 4,
    isTreasure: true,
    isVanilla: true,
  },
  {
    id: "sharpness",
    name: "锋利 IV ⇄ V（对照：无套利）",
    sub: "原版常规 · M=5 · anvilCost=1",
    maxLevel: 5,
    fromLevel: 4,
    toLevel: 5,
    anvilCost: 1,
    isTreasure: false,
    isVanilla: true,
  },
  {
    id: "modded_m2",
    name: "第三方高稀宝藏 I ⇄ II",
    sub: "模组常见 · M=2 · anvilCost=8",
    maxLevel: 2,
    fromLevel: 1,
    toLevel: 2,
    anvilCost: 8,
    isTreasure: true,
    isVanilla: false,
  },
];

export interface HardcodeFinding {
  id: string;
  severity: Severity;
  category: AuditCategory;
  title: string;
  file: string;
  symbol: string;
  summary: string;
  badCode: string;
  goodCode: string;
  impact: string;
}

export const HARDCODE_FINDINGS: HardcodeFinding[] = [
  {
    id: "HC-01",
    severity: "P0",
    category: "compat",
    title: "书架方块判定硬编码 Blocks.BOOKSHELF，与同文件粒子标签分裂",
    file: "block/ChiseledEnchantingTableBlock.java",
    symbol: "calculateShelfPower() L287 vs animateTick() L103",
    summary:
      "粒子动画检查 #minecraft:enchantment_power_provider，但实际算力统计却硬编码 Blocks.BOOKSHELF。装有 Quark / Supplementaries / BoP 变种木书架时，书架狂飘符文粒子欺骗玩家已生效，实际普通书架计数为 0。",
    badCode: `// animateTick() L103 — 认标签
boolean activeShelf = shelfState.is(BlockTags.ENCHANTMENT_POWER_PROVIDER) ...;
// calculateShelfPower() L287 — 却写死原版橡木书架！
if (nearbyState.is(Blocks.BOOKSHELF)) {
    regularBookshelves++;
}`,
    goodCode: `// 统一走自定义标签（默认 include #minecraft:enchantment_power_provider）
if (nearbyState.is(ModBlockTags.REGULAR_BOOKSHELVES)
    && !nearbyState.is(Blocks.CHISELED_BOOKSHELF)) {
    regularBookshelves++;
}`,
    impact: "所有云杉/深色橡木/竹制/模组魔法书架在 0..38 阶梯、32 顿悟、8/18 残卷梯度中全部失效。",
  },
  {
    id: "HC-02",
    severity: "P1",
    category: "sync",
    title: "JEI/REI 退魔条目硬编码样本、绕过 S2C 同步，且全洗产物写错为普通书",
    file: "compat/TransformationQueryIndex.java",
    symbol: "build() L108–137",
    summary:
      "EnchantCostTablePayload 已将全表退魔与祛咒耗材同步到客户端，但配方查询索引却硬编码 sharpness(3,5) 直接读客户端本地 ChiseledEnchantingTableData，还把 serverCosts 硬塞为 true；同时全洗产物写成了 Items.BOOK（实际为 depleted_tome）。",
    badCode: `Identifier sampleId = Identifier.withDefaultNamespace("sharpness");
results.add(new Entry(DISENCHANT_ALL_ID, 1,
    new ItemStack(Items.ENCHANTED_BOOK), List.of(),
    new ItemStack(Items.BOOK), // 错！实装产出 DEPLETED_TOME
    XpRequirement.refund(24), true)); // 绕过 SyncedEnchantmentCosts 却谎称 serverCosts=true`,
    goodCode: `var syncedStrip = SyncedEnchantmentCosts.find(OptionType.STRIP_SINGLE_ENCHANTMENT, sampleId, 3);
results.add(new Entry(DISENCHANT_ALL_ID, 1,
    new ItemStack(Items.ENCHANTED_BOOK), List.of(),
    new ItemStack(BlockRegistry.DEPLETED_TOME),
    XpRequirement.refund(scaledPreview), syncedStrip.isPresent()));`,
    impact: "专用服修改 disenchanting.json 后客户端 JEI/REI 完全不更新，且误导玩家以为全洗附魔书直接得普通书。",
  },
  {
    id: "HC-03",
    severity: "P1",
    category: "hardcode",
    title: "书库共鸣、增量折扣与势能公式全部常数硬编码在 Java 类中",
    file: "mechanics/resonance/LibraryResonance.java · XpCostConversion.java",
    symbol: "MIN_DISCOUNT_BOOKSHELVES=12 / baseMax=48 / 0.35f / -20%/-10%",
    summary:
      "木书架减免起算点 12..32、封顶 12%/13%/15%/40%、母本引导材料折减 -20%/-10%、增量门槛系数 0.35f、退魔势能 baseMax=34/48 与指数 1.65 全部写死在代码，数据包无法覆写。",
    badCode: `public static final int MIN_DISCOUNT_BOOKSHELVES = 12;
public static final int MAX_WOODEN_DISCOUNT_PERCENT = 12;
double baseMax = maxLevel == 1 ? 34.0 : 48.0; // DisenchantmentApplication L74
int rawThreshold = Math.round(full.rawRequiredLevel() * (1.0f - 0.35f * progressCredit));`,
    goodCode: `// 收拢进 resonance.json & disenchanting.json，随 EnchantCostTablePayload 同步
// 尤其当服主将 shelf_gates 锚点从 38 调至 60 时，木书架减免区间应随之联动`,
    impact: "整合包调整书架梯度后，经验减免封顶位（32）与升阶封顶位（38）脱节；势能曲线也无法热修。",
  },
  {
    id: "HC-04",
    severity: "P1",
    category: "compat",
    title: "无条件硬编码修改原版附魔书堆叠上限为 64，缺少配置开关",
    file: "ChiseledEnchantingTable.java",
    symbol: "onInitialize() L26–30",
    summary:
      "启动时强制将 Items.ENCHANTED_BOOK 的 MAX_STACK_SIZE 改为 64。虽然用 Mixin 修了原版铁砧右槽吞整组书，但第三方模组的祛魔台/图书馆/自动附魔机普遍假设附魔书不可堆叠（直接 setItem(EMPTY)）。",
    badCode: `DefaultItemComponentEvents.MODIFY.register(context ->
    context.modify(Items.ENCHANTED_BOOK, builder ->
        builder.set(DataComponents.MAX_STACK_SIZE, 64)
    )
);`,
    goodCode: `int cap = ModBootstrapConfig.INSTANCE.enchantedBookStackSize(); // 默认 64，可设 1..64
if (cap > 1) {
    DefaultItemComponentEvents.MODIFY.register(...);
}`,
    impact: "与工业/魔法模组联动时存在整组满配附魔书被外模组机器一次性吞没的高危风险，服主无处关闭。",
  },
  {
    id: "HC-05",
    severity: "P1",
    category: "hardcode",
    title: "CI 校验脚本硬编码锁死退魔砂与 38/8/18/6 常数，且内嵌过时假公式",
    file: "scripts/compat_check.py",
    symbol: "check_disenchanting_and_anti_arbitrage() L403–495",
    summary:
      "静态检查强制要求 targeted_strip 每个选项必须含 cleansing_grit（导致纯原版替代与单秘法凝晶方案无法配置），锁死 shelf_gates 数值，且防套利校验写了过时的 8+22*r 公式、漏检了增量升级路径。",
    badCode: `if section_key == "targeted_strip" and "chiseled_enchanting_table:cleansing_grit" not in involved:
    errors.append(...) # 连单颗秘法凝晶都被迫绑 1 个退魔砂才能过 CI！
raw_req = max(tier, round(8 + 22 * (lvl / capped_max))) # 与 Java 真实 30*r 公式不一致！`,
    goodCode: `# 1) 允许 arcane_catalyst 独立作为单件替代，允许纯原版耗材包；
# 2) 从 shelf_gates.json 动态读取锚点校验单调性，而非锁死 == 38；
# 3) 补齐 forIncrementalMasterTomeEnchant(L-1 -> L) 对偶防套利断言。`,
    impact: "直接制造了虚假的“无套利通过”绿灯，并阻碍了 CHANGELOG 承诺的无退魔砂替代配方落地。",
  },
  {
    id: "HC-06",
    severity: "P2",
    category: "hardcode",
    title: "耗材与置换配方不支持 Item Tag（#tag），特殊保底按 ID 硬编码特判",
    file: "data/ChiseledEnchantingTableData.java · XpCostConversion.java",
    symbol: "ItemCostOption / EXP_BOTTLE_TRANSFORM_ID L157",
    summary:
      "ItemCostOption 与 ItemTransformation 仅解析单物品 ID，不支持 #minecraft:planks 或 #c:gems；附魔之瓶最低 Lv.3 门槛在 XpCostConversion 中靠硬编码 ID 特判，自定义经验类置换无法声明保底等级。",
    badCode: `minDiscountedFloor = EXP_BOTTLE_TRANSFORM_ID.equals(transformationId)
    ? Math.max(tierCost, 3) : tierCost;`,
    goodCode: `// 在 item_transformations.json 增加可选字段 "min_player_level": 3
// ItemCostOption 支持 "tag": "#..." 展开为候选栈列表`,
    impact: "数据包扩展自定义置换时无法配置防倒挂等级下限，跨模组矿辞/通用标签材料无法接入。",
  },
  {
    id: "HC-07",
    severity: "P2",
    category: "sync",
    title: "S2C 成本包使用枚举 ordinal() 编码、丢弃物品组件，且全量广播无效组合",
    file: "menu/EnchantCostTablePayload.java",
    symbol: "build() L63–115 · write() L158–218",
    summary:
      "对每个魔咒每级都无条件生成 PURGE_CURSE 与 TREASURE_EPIPHANY 等 6 条记录（锋利 1..5 也发 5 条祛咒成本），用 ordinal() 代替稳定 token()，且 writeStacks 只写 Item+count 丢失 DataComponents。",
    badCode: `buf.writeVarInt(entry.optionType().ordinal()); // 枚举重排即错位
buf.writeIdentifier(BuiltInRegistries.ITEM.getKey(s.getItem()));
buf.writeVarInt(s.getCount()); // 丢弃全部 DataComponents`,
    goodCode: `// 仅按魔咒实际标签（isCurse / isTreasure / maxLevel>=2）按需生成条目（包体积立减 ~45%）
// 使用 ItemStack.OPTIONAL_STREAM_CODEC 与 optionType.token()`,
    impact: "安装大型附魔模组（100+ 魔咒）时进服/重载包膨胀数倍；未来耗材若含药水/组件会静默丢失。",
  },
  {
    id: "HC-08",
    severity: "P2",
    category: "hardcode",
    title: "挖下未冻结的纂刻附魔台仍写入 epiphanySeed，污染物品堆叠",
    file: "block/ChiseledEnchantingTableBlockEntity.java",
    symbol: "collectImplicitComponents() L221–243",
    summary:
      "只要玩家右键打开过一次附魔台，epiphanySeed 即非 0；破坏掉落时不论是否处于冻结状态都会写入 CUSTOM_DATA，导致用过的附魔台再也无法与新合成或其他位置的附魔台堆叠。",
    badCode: `if (this.epiphanySeed != 0 || rem > 0L) {
    CompoundTag tag = new CompoundTag();
    if (this.epiphanySeed != 0) tag.putInt("epiphanySeed", this.epiphanySeed);
    ...
    componentMapBuilder.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
}`,
    goodCode: `// 仅当 rem > 0L（确实处于付费冻结锁定期）时才持久化 seed 与剩余冻结时间！
if (rem > 0L) { ... }`,
    impact: "日常搬家拆台后每个附魔台独占一格背包，属于典型的隐式组件堆叠污染。",
  },
  {
    id: "HC-09",
    severity: "P3",
    category: "hardcode",
    title: "7×5×7 扫描坐标硬编码两遍且 ArrayList 初始容量仍停留在旧版 195",
    file: "block/ChiseledEnchantingTableBlock.java",
    symbol: "POWER_PROVIDER_OFFSETS L56 vs streamLibraryPositions() L254",
    summary:
      "文件顶部已预生成不可变列表 POWER_PROVIDER_OFFSETS（244 格），下方 streamLibraryPositions 却又手写一遍三重循环并用 new ArrayList<>(195) 分配再扩容。",
    badCode: `ArrayList<BlockPos> list = new ArrayList<>(195); // 实际 7*5*7 - 1 = 244 格`,
    goodCode: `// 直接复用 POWER_PROVIDER_OFFSETS.stream().map(origin::offset)`,
    impact: "每次打开附魔台多一次无意义集合扩容与坐标重算，且未来改扫描范围易漏改一处。",
  },
  {
    id: "HC-10",
    severity: "P3",
    category: "docs",
    title: "11 个原版单级/宝藏排除名单三处重复维护，且进度标题仍硬编码英文",
    file: "default_enchantments.json · treasure_epiphany.json · ChiseledEnchantingTableData.java",
    symbol: "builtInExcludedTreasureIds() L232 & data/.../advancement/*.json",
    summary:
      "水下速掘、火矢、精准采集、无限等 11 个 ID 在两份 JSON 与一份 Java 回退中三处重复；同时第三方模组同定位的非 #minecraft:treasure 单级稀有魔咒却在 0 书架直接解锁，形成原版严、模组松的反差。",
    badCode: `// 三处重复罗列 aqua_affinity, flame, multishot, channeling, silk_touch...`,
    goodCode: `// 抽为单一标签 #chiseled_enchanting_table:epiphany_exclusive，默认含这 11 项与 #minecraft:treasure`,
    impact: "数据包作者想把某个魔咒移回常规池时必须同时改两份 JSON，漏改一处即变成两头落空或双倍出现。",
  },
];

export interface DriftRow {
  topic: string;
  docSource: string;
  docClaim: string;
  actualCode: string;
  verdict: string;
}

export const DRIFT_ROWS: DriftRow[] = [
  {
    topic: "木书架推进上限",
    docSource: "README.md · Block.java L236 注释",
    docClaim: "木书架将常规魔咒推进至中阶上限 ceil(maxLevel / 2)，满级须靠雕纹书架母本",
    actualCode: "withWoodenShelfBoost() 直接调用 maxUnlockedDirectTier → 38 木架直接解锁白板满级 MAX",
    verdict: "核心双轨设计被代码击穿",
  },
  {
    topic: "单洗原版替代配方",
    docSource: "CHANGELOG.md L49",
    docClaim: "内置纯原版替代（发光墨囊+石英 / 燧石+骨粉）或单颗秘法凝晶",
    actualCode: "disenchanting.json 全部 4 个选项均强制绑定 cleansing_grit（秘法凝晶也需 +1 退魔砂）",
    verdict: "文档承诺未实装且被 CI 锁死",
  },
  {
    topic: "破除诅咒耗材",
    docSource: "CHANGELOG.md L53",
    docClaim: "2× 退魔砂+恶魂之泪 / 1× 秘法凝晶 / 2× 恶魂之泪+金苹果",
    actualCode: "disenchanting.json 实为 3× 退魔砂+恶魂之泪 / 2× 退魔砂+金苹果 / 1× 秘法凝晶+恶魂之泪",
    verdict: "CHANGELOG 与数据包不一致",
  },
  {
    topic: "全洗附魔书产物",
    docSource: "CHANGELOG.md L45 · TransformationQueryIndex L114",
    docClaim: "单条附魔书全洗直接还原为普通书 Book（JEI/REI 亦显示产出 Book）",
    actualCode: "DisenchantmentApplication L233 统一产出 BlockRegistry.DEPLETED_TOME（褪魔残卷）",
    verdict: "JEI/REI 展示错误产物",
  },
  {
    topic: "空白覆写基础耗材数",
    docSource: "docs/WIKI.md §8 总表",
    docClaim: "3× 纸 / 3× 骨粉 / 3× 青金石 / 1× 墨囊 / 1× 紫水晶碎片",
    actualCode: "item_transformations.json 实为 4× 纸/骨粉/青金石、2× 绿宝石/墨囊/发光墨囊/紫水晶（为了凑偶数减半）",
    verdict: "WIKI §6.3 已改 4/2，§8 漏改",
  },
];
