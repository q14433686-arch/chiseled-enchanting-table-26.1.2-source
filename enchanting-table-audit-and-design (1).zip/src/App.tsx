import { useEffect, useState } from "react";
import { BookOpen, FolderGit2, Sparkle, ArrowUpRight, Asterisk } from "lucide-react";
import { clsx } from "clsx";
import { AuditPage } from "./pages/AuditPage";
import { DebatePage } from "./pages/DebatePage";
import { DoubtsPage } from "./pages/DoubtsPage";
import { WearPage } from "./pages/WearPage";

type PageId = "audit" | "debate" | "doubts" | "wear";

const PAGES: { id: PageId; zh: string; en: string; no: string }[] = [
  { id: "audit", zh: "源码审计", en: "CODE AUDIT", no: "Ⅰ" },
  { id: "debate", zh: "机制答辩", en: "DESIGN DEBATE", no: "Ⅱ" },
  { id: "doubts", zh: "怀疑与谏言", en: "DOUBTS & ADVICE", no: "Ⅲ" },
  { id: "wear", zh: "磨损裁决", en: "WEAR ECONOMY", no: "Ⅳ" },
];

const RUNES = ["✦", "ᚠ", "ᚱ", "ᛟ", "ᛗ", "✧", "ᛉ", "ᚨ"];

function MouseGlow() {
  const [pos, setPos] = useState({ x: -600, y: -600 });
  useEffect(() => {
    let raf = 0;
    const onMove = (e: MouseEvent) => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => setPos({ x: e.clientX, y: e.clientY }));
    };
    window.addEventListener("mousemove", onMove, { passive: true });
    return () => { window.removeEventListener("mousemove", onMove); cancelAnimationFrame(raf); };
  }, []);
  return (
    <div
      className="pointer-events-none fixed z-30 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-[0.13]"
      style={{
        left: pos.x,
        top: pos.y,
        background: "radial-gradient(circle, #8b5cf6 0%, transparent 65%)",
        filter: "blur(30px)",
      }}
    />
  );
}

function FloatingRunes() {
  return (
    <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      {RUNES.map((r, i) => (
        <span
          key={r}
          className="floaty absolute font-serifcn text-arcane/[0.13]"
          style={{
            left: `${(i * 12.5 + 4) % 96}%`,
            top: `${(i * 29 + 12) % 88}%`,
            fontSize: `${26 + (i % 4) * 14}px`,
            animationDelay: `${i * 0.9}s`,
            animationDuration: `${6 + (i % 3) * 2.4}s`,
          }}
        >
          {r}
        </span>
      ))}
    </div>
  );
}

function ScrollProgress() {
  const [p, setP] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const max = h.scrollHeight - h.clientHeight;
      setP(max > 0 ? h.scrollTop / max : 0);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <div className="fixed inset-x-0 top-0 z-50 h-[2px] bg-transparent">
      <div
        className="h-full bg-gradient-to-r from-arcane via-arcane-bright to-xp transition-[width] duration-150"
        style={{ width: `${p * 100}%`, boxShadow: "0 0 12px rgba(139,92,246,0.8)" }}
      />
    </div>
  );
}

export default function App() {
  const [page, setPage] = useState<PageId>("audit");
  const [switching, setSwitching] = useState(false);

  const go = (p: PageId) => {
    if (p === page) return;
    setSwitching(true);
    window.setTimeout(() => {
      setPage(p);
      window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
      setSwitching(false);
    }, 220);
  };

  return (
    <div className="noise relative min-h-screen bg-abyss">
      <MouseGlow />
      <FloatingRunes />
      <ScrollProgress />

      {/* ============ NAV ============ */}
      <nav className="glass fixed inset-x-0 top-0 z-40 border-b border-edge/60">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-6 py-4">
          <div className="flex items-center gap-3">
            <span className="relative flex h-9 w-9 items-center justify-center rounded-lg border border-arcane/40 bg-arcane/15">
              <BookOpen size={16} className="text-arcane-bright" />
              <span className="pulse-glow absolute -right-1 -top-1 h-2 w-2 rounded-full bg-xp" />
            </span>
            <div className="leading-tight">
              <div className="text-[13px] font-bold tracking-wide text-parch">雕纹附魔台 · 审查团</div>
              <div className="font-mono text-[9px] uppercase tracking-[0.28em] text-ash">CET Audit Guild · 26.1.2</div>
            </div>
          </div>

          <div className="ml-auto flex items-center gap-1.5 sm:gap-5">
            {PAGES.map((p) => (
              <button
                key={p.id}
                onClick={() => go(p.id)}
                className={clsx(
                  "nav-tab group flex items-center gap-2 rounded-lg px-2.5 py-2 text-[12px] font-medium text-ash transition-colors hover:text-parch sm:px-3",
                  page === p.id && "active text-parch"
                )}
              >
                <span className={clsx("font-serifcn text-[11px]", page === p.id ? "text-arcane-bright" : "text-ash/50")}>{p.no}</span>
                <span>{p.zh}</span>
                <span className="hidden font-mono text-[8.5px] uppercase tracking-[0.2em] text-ash/50 lg:inline">{p.en}</span>
              </button>
            ))}
            <a
              href="https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/tree/arena%2F0e406cfe-chiseled-enchanting-table-26-1"
              target="_blank"
              rel="noreferrer"
              className="ml-1 hidden items-center gap-1.5 rounded-lg border border-edge bg-ink px-3 py-2 font-mono text-[10.5px] text-ash transition-all hover:border-arcane/50 hover:text-parch sm:flex"
            >
              <FolderGit2 size={13} /> 源仓库 <ArrowUpRight size={11} />
            </a>
          </div>
        </div>
        {/* page switching veil */}
        <div className={clsx("h-[1px] bg-gradient-to-r from-transparent via-arcane to-transparent transition-opacity duration-200", switching ? "opacity-100" : "opacity-0")} />
      </nav>

      {/* ============ CONTENT ============ */}
      <main className={clsx("relative z-10 transition-opacity duration-200", switching && "opacity-0")}>
        {page === "audit" && <AuditPage />}
        {page === "debate" && <DebatePage />}
        {page === "doubts" && <DoubtsPage />}
        {page === "wear" && <WearPage />}
      </main>

      {/* ============ FOOTER ============ */}
      <footer className="relative z-10 border-t border-edge/60 bg-obsidian/80">
        <div className="mx-auto max-w-6xl px-6 py-12">
          <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
            <div>
              <div className="flex items-center gap-2 font-display text-sm font-semibold tracking-wide text-parch">
                <Asterisk size={15} className="text-arcane" /> AUDIT TRAIL
              </div>
              <p className="mt-3 max-w-md text-[12px] leading-relaxed text-ash">
                审查对象：chiseled-enchanting-table-26.1.2-source @ arena/0e406cfe（commit 8c6d8a2）。
                本报告基于该分支快照的静态阅读，全部文件引用与数值均可于仓库内复验；未运行动态测试。
              </p>
            </div>
            <div className="flex flex-wrap gap-x-8 gap-y-3 font-mono text-[10px] uppercase tracking-[0.25em] text-ash/70">
              <span className="flex items-center gap-1.5"><Sparkle size={11} className="text-xp" /> 七路径审计</span>
              <span className="flex items-center gap-1.5"><Sparkle size={11} className="text-arcane-bright" /> 公式级复刻</span>
              <span className="flex items-center gap-1.5"><Sparkle size={11} className="text-gilt" /> 可执行谏言</span>
            </div>
          </div>
          <div className="mt-10 flex flex-col gap-2 border-t border-edge/50 pt-6 font-mono text-[10px] tracking-[0.2em] text-ash/50 sm:flex-row sm:items-center sm:justify-between">
            <span>CET AUDIT GUILD — UNOFFICIAL REVIEW, NOT AFFILIATED WITH SACRAMENTIX</span>
            <span>MINECRAFT 26.3 · FABRIC 0.19.5 · RELEASE 1.1.0</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
