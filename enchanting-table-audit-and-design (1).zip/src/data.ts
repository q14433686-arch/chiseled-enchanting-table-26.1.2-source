/* Content data extracted from the actual repository review.
   Branch: arena/0e406cfe-chiseled-enchanting-table-26-1 (commit 8c6d8a2) */

export type PathFinding = {
  verdict: "strong" | "good" | "mixed" | "risky";
  path: string;
  en: string;
  icon: string;
  summary: string;
  positives: string[];
  issues: {
    sev: "critical" | "high" | "medium" | "low";
    title: string;
    detail: string;
    file: string;
    snippet?: { code: string; title: string; badge?: string };
  }[];
};

export const AUDIT_PATHS: PathFinding[] = [
  {
    verdict: "good",
    path: "源码 API",
    en: "SOURCE-API",
    icon: "Braces",
    summary:
      "面向 Minecraft 26.3 的 API 迁移整体干净：Identifier 全量替换 ResourceLocation，已删除的 per-block codec 不再复原，26.3 战利品 schema 按 \"type\" 分发 + 单数可选条件持有者。MixinExtras 用得规范。残留风险集中在客户端弃用 API 覆写与跨层读配置。",
    positives: [
      "Identifier.fromNamespaceAndPath / withDefaultNamespace / STREAM_CODEC 全线迁移，无 ResourceLocation 残留",
      "mixin 注释明确记录 26.3 适配点（loot 单数 condition holder、ContextIntProviders、Prediction drops）并禁止回退 26.1.2 codec",
      "结构筛选用注册表 Holder 与 TagKey，不用硬编码命名空间列表，第三方附魔天然兼容",
    ],
    issues: [
      {
        sev: "medium",
        title: "客户端仍覆写已弃用 API",
        detail:
          "compile-java.log 明确报告 ChiseledEnchantingTableClient “uses or overrides a deprecated API”。26.3 当前兼容，但等于欠 Mojang 一笔到期未定的债——应排期替换并在 CI 打开 -Xlint:deprecation 收债提醒。",
        file: "src/client/.../ChiseledEnchantingTableClient.java",
      },
      {
        sev: "low",
        title: "DisableBookEnchanting 在 Mixin HEAD 跨层直读数据中心",
        detail:
          "getEnchantmentList 的 HEAD 注入直接调用 ChiseledEnchantingTableData.shelfGatesConfig()。功能正确，但 mixin→god-class 的读依赖让 vanilla EnchantmentMenu 的一生都被数据中心绑定；若数据表 /reload 时序有窗口，mixin 读到的可能是旧表。",
        file: "mixin/enchanting_table/DisableBookEnchanting.java:55",
      },
    ],
  },
  {
    verdict: "mixed",
    path: "数据编解码",
    en: "DATA-CODEC",
    icon: "FileJson",
    summary:
      "解码纪律是这份仓库最硬的部分：PayloadLimits 统一有界读取（集合 ≤65,536、标识符 ≤512 字符、token ≤64、附魔等级 ≤255），R-01 用估算字节预算 900KB 在触碰原版自定义载荷上限前主动截断。真正的软胁不在线上协议，而在「Java 内联回退表 ↔ datapack JSON 默认值」的双真源。",
    positives: [
      "readBoundedCount 拒绝负数并把上限传名到异常信息，解码期即失败，不把脏数据放进业务层",
      "SyncRuntimeConfigPayload 三路 writeUtf 各带 262,144 / 65,536 上限，写读两侧对称 clamp",
      "成本表 builder 超额时标记 incomplete 而非静默丢行",
    ],
    issues: [
      {
        sev: "high",
        title: "默认值双真源：Java 常量 × JSON 十二张表",
        detail:
          "DEFAULT_MAX_DIRECT_BOOKSHELVES=38、12/32/38 里程碑、风化权重 [45,35,15,5]、减免 15/20/35/40 等关键数字同时写死在 Java DEFAULT 记录与 *.json 默认值里。数据包作者只改 JSON 时一切正常；可一旦某次重构动了 Java fallback，两者静默分叉，而 SimpleSynchronousResourceReloadListener 不会报任何警。",
        file: "data/ChiseledEnchantingTableData.java ↔ resources/data/**/shelf_gates.json, library_resonance.json",
      },
      {
        sev: "low",
        title: "TransformationDisplay.write 用 writeInt 而周边一律 VarInt",
        detail: "等级字段 writeInt/readInt，与同记录内其余字段的 writeVarInt 混用。不是 bug，但 wire 格式风格不一徒增审读成本。",
        file: "menu/ChiseledEnchantingMenuPayloads.java:104",
      },
    ],
  },
  {
    verdict: "strong",
    path: "网络同步",
    en: "NET-SYNC",
    icon: "Radar",
    summary:
      "协议卫生是教科书级：所有业务频道带 26_3_revision_9 后缀，旧频道只查询不注册，JOIN 双向 canSend 握手不兼容即礼貌断开；apply/reroll/freeze/skip 四个服务端接收器全部校验容器归属 + stillValid + 仪式会话号。唯一实锤问题是一处会话级静态表的泄漏。",
    positives: [
      "NET-03：OptionType.fromToken 拒绝把攻击者输入回显进日志（只记录长度）",
      "Reopen 接收器：10 tick 节流 + 距离 ≤64.0² + hasChunkAt + block 类型四重校验",
      "配置热更新收发包带 requestId 回执，权限不足/解析失败走 rejected 路径并本地化提示",
    ],
    issues: [
      {
        sev: "medium",
        title: "LAST_REOPEN_TICK 静态 HashMap 永不驱逐",
        detail:
          "Reopen 节流表以 UUID 为键、游戏刻为值，玩家断线后条目留在堆里。十年长跑服也漏不出多少内存，但模式本身是错的：应挂 ServerPlayConnectionEvents.DISCONNECT 清理，否则每新增一个 per-player 静态表都要靠祈祷有人记得放行。",
        file: "menu/ChiseledEnchantingTableScreenHandler.java:53",
        snippet: {
          title: "ChiseledEnchantingTableScreenHandler.java — 节流表无清理钩子",
          badge: "LEAK",
          code: `/** Per-player game-time of the last accepted Reopen payload. */
private static final Map<UUID, Long> LAST_REOPEN_TICK = new HashMap<>();
// …registerGlobalReceiver(…):
Long last = LAST_REOPEN_TICK.get(player.getUUID());
if (last != null && now - last < 10L) return;
LAST_REOPEN_TICK.put(player.getUUID(), now);
// ✗ 玩家退出时无 remove —— UUID 条目永久驻留`,
        },
      },
      {
        sev: "low",
        title: "协议修订号与提示文案硬烧 “26_3”",
        detail:
          "REVISION = \"26_3_revision_9\" 与 MISMATCH_MESSAGE 内含 Minecraft 26.3 字样散在多处。换版本即全网断联是设计意图（频道更名=拒绝静默不兼容），但文案与频道名应集中一处生成。",
        file: "menu/EnchantingProtocol.java",
      },
    ],
  },
  {
    verdict: "good",
    path: "GUI 输入",
    en: "GUI-INPUT",
    icon: "MousePointer2",
    summary:
      "输入面克制：自定义动作只认鼠标左键、右键完整交还原版库存逻辑；配置/魔典覆盖层模态吞键并自行处理 Escape；仪式进行中 apply/祛魔/跳过均有双重闸门。瑕不掩瑜，但覆盖层吞键的写法值得注释。",
    positives: [
      "click 前先判 ContainerInput.QUICK_MOVE 并尊重 Slot.mayPickup —— 仪式锁定期间 ENCHANTABLE_SLOT 拒绝快捷移出",
      "SkipRitual 带 containerId + 仪式 session 号双因子，过期会话点击无效",
      "列表滚动/拖拽问题（M-01/M-04）已修并留档",
    ],
    issues: [
      {
        sev: "low",
        title: "覆盖层在场时 keyPressed/charTyped 无条件 return true",
        detail:
          "configOverlay/grimoireOverlay 打开期间，所有键盘事件无论覆盖层是否消费都被标记为已处理——E 键、物品栏热键静默失效。行为符合模态语义，但正确写法是尊重 overlay 返回值并对未消费事件显式放行或注释说明。",
        file: "gui/ChiseledEnchantingTableScreen.java:512-524",
      },
      {
        sev: "low",
        title: "ScreenHandler 手工镜像 30+ 个 syncedX 字段",
        detail:
          "客户端侧靠 broadcastChanges 时序推进的逐字段镜像，是“客户端显示 ≠ 服务端真值”漂移的多发温床。建议收敛为单个状态 record 整体广播（见谏言页 P2）。",
        file: "menu/ChiseledEnchantingTableScreenHandler.java",
      },
    ],
  },
  {
    verdict: "good",
    path: "Mixin 注入",
    en: "MIXIN",
    icon: "Syringe",
    summary:
      "11 个 mixin、defaultRequire=1、注入点选择克制且多数带“为什么”审计注释。RemoveEnchantMerge 从 HEAD/RETURN 手动恢复栈数（异常即吞书）重构为 @WrapMethod + try/finally——这是本仓库修复水准的代表作。风险不在注入技术，在全局外溢面。",
    positives: [
      "AddRandomTick 只为“有书的雕纹书架”开启随机刻——空装饰书柜零区块开销",
      "GrindstoneBookDepleteMixin 从 delegate 派生 container/index，不硬编码槽位布局（MX-05）",
      "mixin 冲突意识强：铁砧结果清空后显式 broadcastChanges",
    ],
    issues: [
      {
        sev: "high",
        title: "五处全局行为改写默认全开：铁砧×2 / 磨石 / 原版附魔台 / 村民交易",
        detail:
          "RemoveXpCostScaling 把 calculateIncreasedRepairCost 钉成平摊，等于对全游戏“先前工作惩罚”做了全局豁免；sanitizeVillagerInfinityOffers 会重写包括其他模组故意加入的 Infinity 交易。注释对此诚实坦白并给了开关——但默认开，整合包作者会被默认配置偷袭。这是“port 之名、overhaul 之实”的耦合放大器。",
        file: "mixin/anvil/RemoveXpCostScaling.java · ChiseledEnchantingTable.java:77",
      },
      {
        sev: "medium",
        title: "村民交易消毒只钩在右键交互上",
        detail:
          "UseEntityCallback 只在玩家右键实体时改写交易列表；流浪商人刷出瞬间的 offer、其他模组程序化打开交易界面的路径，都在首次交互前赤裸裸暴露 Infinity 书。限制「无限」的防线有一条正门没站岗。",
        file: "ChiseledEnchantingTable.java:67-100",
      },
    ],
  },
  {
    verdict: "risky",
    path: "死代码",
    en: "DEAD-CODE",
    icon: "Skull",
    summary:
      "自审标签里连 DEAD-03（协议探针退役政策）这类“仪式性死代码”都立了规矩——然而就是在这样的纪律下，仍有一段确凿的生成残留混进了 release 分支。它是「部分代码由一次性合并脚本生成」的最小但确凿证据。",
    positives: [
      "legacy 协议探针（rev4–8）明确登记为 query-only，退役政策成文（DEAD-03）",
      "大部分“看似无用”的便捷构造器实际被 NetworkCompatibilityTest 锚住",
    ],
    issues: [
      {
        sev: "high",
        title: "epiphanyMaxSlots 内的恒真死条件（生成残留）",
        detail:
          "外层 if 已保证 regularBookshelves < minBookshelves；return 的条件式里 0.0 >= 0.0 恒真且三元两分支同为 0——等价 return 0，但形式是被内联优化掉的旧双参数守卫残骸。功能无害，审查信誉有损：它说明这段代码从未被人眼第二遍读过。",
        file: "mechanics/resonance/LibraryResonance.java:946-949",
        snippet: {
          title: "LibraryResonance.java — 等价于 return 0 的恒真三元式",
          badge: "DEAD",
          code: `public static int epiphanyMaxSlots(Config cfg, int regularBookshelves, … ) {
    Config c = cfg != null ? cfg : Config.DEFAULT;
    if (regularBookshelves < minBookshelves) {
        // 恒真条件 + 两分支同值：功能 = return 0;，形式 = 合并脚本残留
        return 0.0 >= 0.0 && regularBookshelves < minBookshelves ? 0 : 0;
    }
    double score = epiphanyResonanceScore(c, …);
    …
}`,
        },
      },
      {
        sev: "low",
        title: "TransformationDisplay 4 参便捷构造器在全 src 树无调用",
        detail: "record 自带的三个重载里 4 参版本无人使用（测试只锚 7/8 参）。死代码斤两不大，但协议 record 上的每个重载都是 wire 兼容承诺，该删即删。",
        file: "menu/ChiseledEnchantingMenuPayloads.java:74",
      },
      {
        sev: "low",
        title: "TODO.md 与 CHANGELOG/WIKI 漂移",
        detail: "TODO.md 里 “🚧 rework chest loot table / 钓鱼战利品” 仍标进行中，而 docs 与 CHANGELOG 已宣称对应功能交付。任务看板与交付记录不同步，外部贡献者会读到两套真相。",
        file: "TODO.md ↔ CHANGELOG.md / docs/WIKI.md",
      },
    ],
  },
  {
    verdict: "mixed",
    path: "耦合风险",
    en: "COUPLING",
    icon: "Network",
    summary:
      "三张巨物压住全局：ChiseledEnchantingTableData 2,748 行（数据中心）、ChiseledEnchantingTableScreenHandler 2,612 行（菜单+同步+镜像）、ConfigCatalog/ModRuntimeConfig 1,862 行（配置）。它们彼此引用、被 mixin 反向引用，构成“配置—同步—镜像”铁三角。世界生成五连 mixin 是第二大耦合面。",
    positives: [
      "COUP-04 已有专项：客户端入口的耦合注释表明作者看得见这个问题",
      "JEI/REI 集成全部 compileOnly + 属性开关，绝不硬依赖（沙箱 CI 可逃生）",
      "UseEntityCallback 全局改写配了 restrict_villager_infinity_books 总闸",
    ],
    issues: [
      {
        sev: "medium",
        title: "数据中心既是加载器又是全局查询点",
        detail:
          "mixin（DisableBookEnchanting）、menu、mechanics、block 全部直读 ChiseledEnchantingTableData 静态方法。热重载窗口期的可见性、以及“谁在何时读到哪份表”全靠自觉，是典型的上帝对象。",
        file: "data/ChiseledEnchantingTableData.java (2,748 行)",
      },
      {
        sev: "medium",
        title: "结构生成五连 mixin 与 worldgen 生态的隐性契约",
        detail:
          "StructurePool 投影 / 结构片段标记 / 放置设置 / 区块后处理 / accessor——为了把原版书架替换成雕纹书架并回填书籍，编辑面覆盖世界生成四个生命周期。与 Terraformers 系、YUNG 系结构模组的注入顺序契约没有任何防御性声明。",
        file: "mixin/structure/*.java (5 个)",
      },
    ],
  },
];

/* ---------------- hardcoded values table ---------------- */
export type HardcodeRow = {
  where: string;
  value: string;
  verdict: "ok" | "warn" | "bad";
  note: string;
};

export const HARDCODES: HardcodeRow[] = [
  {
    where: "MasterTomeWear.java:50",
    value: 'INFINITY_ENCHANTMENT_ID = Identifier.withDefaultNamespace("infinity")',
    verdict: "warn",
    note: "磨损免疫只认 minecraft:infinity 一个 ID。其他模组的“无限类”附魔（或内置 Infinity 的命名空间变体）一律磨损——应改为 #chiseled_enchanting_table:wear_immune 标签，让内容侧用数据包决定。",
  },
  {
    where: "BookshelfBookFiller.java:134",
    value: 'BOOKSHELF_BLOCK_ENTITY_ID = "minecraft:chiseled_bookshelf"',
    verdict: "ok",
    note: "结构 NBT 必须与原版模板键一致，属合理硬编码并有注释背书。脆弱点仅在 Mojang 若改名该键——建议在这个常量上挂一个启动期注册表断言。",
  },
  {
    where: "InscriptionRitualMechanics.java",
    value: "WAIT_SHELF_WEIGHT=0.42 / WAIT_TOME_WEIGHT=0.58 / WAIT_LEVEL_FLOOR=0.35（private 常量）",
    verdict: "bad",
    note: "同一文件的 SHELF_LOAD_REFERENCE / TOME_LOAD_REFERENCE 却能被数据包覆盖——仪式等待曲线的三个权重偏偏是私有的，与“全数值数据驱动”的项目主张直接矛盾。",
  },
  {
    where: "PayloadLimits.java",
    value: "65536 / 512 / 64 / 255 / 900_000",
    verdict: "ok",
    note: "防御性魔数的正确写法：全部命名 + 注释说明审计出处（NET-03 / R-01）。",
  },
  {
    where: "EnchantingProtocol.java",
    value: 'REVISION = "26_3_revision_9" · MISMATCH_MESSAGE = "…Minecraft 26.3…"',
    verdict: "warn",
    note: "版本号字符串烧进频道名、断联文案、fabric.mod.json port_notes 三处。每次升版本都是多点位手工同步——应集中到一处常量派生。",
  },
  {
    where: "12 张 datapack JSON ↔ Java DEFAULT 记录",
    value: "38 / 12 / 32 / 15%/20%/35%/40% / [45,35,15,5] / 7200s→3600s→1200s…",
    verdict: "bad",
    note: "所有默认值双份书写。consistency.yml 工作流存在但覆盖面未知；正确解法是构建期从 JSON 生成 Java 常量（codegen），让 JSON 成为唯一真源。",
  },
  {
    where: "enchantment_costs.json / xp.overrides",
    value: '"minecraft:infinity": {"1": 12} —— 经验按等级硬表',
    verdict: "ok",
    note: "成本表本体就是数据文件，覆盖 11 个特例（无限/经验修补 12 级封顶区）。这是硬编码的合法形态：数值属于数据层。",
  },
  {
    where: "BookshelfProgression.java",
    value: "DIRECT_TIER_CURVE_EXPONENT = 1.25 · DEFAULT_MAX_DIRECT_BOOKSHELVES = 38",
    verdict: "warn",
    note: "gamma 与上限有 JSON 覆写口（direct_upgrade_gates.gamma / max_bookshelves），但“每档至少一档”的取整钳制区间 [1, cap-1] 是代码内固定行为，数据包无法表达——对 maxLevel>39 的模组附魔，这条夹逼规则应写进文档。",
  },
];

/* ---------------- 26.1.2 → 26.3 adaptation matrix ---------------- */
export const VERSION_MATRIX = [
  { item: "方块 codec 覆写（26.1.2 存在）", status: "removed-ok", note: "26.3 已删除；源码注释明确“不要还原”，适配正确" },
  { item: "战利品 schema：functions 按 type 分发 + 单数 condition holder", status: "adapted", note: "RemoveEnchantedBooksFunction 等多处注释适配记录" },
  { item: "FriendlyByteBuf 集合助手的移除", status: "adapted", note: "payloads 手工 bounded VarInt 前缀 + 元素循环" },
  { item: "ResourceLocation → Identifier 更名", status: "adapted", note: "全树无一处旧类残留；STREAM_CODEC 直接使用" },
  { item: "客户端弃用 API 覆写", status: "debt", note: "构建日志实锤 deprecated override，替换无排期" },
  { item: "协议频道名 / 仓库名仍咬死版本号", status: "debt", note: "仓库名 26.1.2-source、频道 26_3_revision_9、label 1.1.0——三层时间戳互相矛盾" },
] as const;

export const REPO_STATS = {
  loc: 34277,
  files: 96,
  mainLoc: 21839,
  clientLoc: 10083,
  testLoc: 2355,
  mixins: 11,
  jsonTables: 12,
  auditTags: 40,
  godDataLoc: 2748,
  handlerLoc: 2612,
};
