import { useState } from "react";
import {
  Braces, FileJson, Radar, MousePointer2, Syringe, Skull, Network,
  ChevronDown, ShieldCheck, AlertTriangle, GitCommitHorizontal, Layers3,
  FileCode2, Boxes, Landmark, BadgeCheck, Ban, CheckCircle2, Scale,
} from "lucide-react";
import { clsx } from "clsx";
import { Reveal, SectionHeading, CodeBlock, Badge, Ticker, FileRef, Callout } from "../components/chrome";
import { AUDIT_PATHS, HARDCODES, VERSION_MATRIX, REPO_STATS, type PathFinding } from "../data";

const ICONS: Record<string, typeof Braces> = { Braces, FileJson, Radar, MousePointer2, Syringe, Skull, Network };

const FINDING_COUNTS = (() => {
  const sevs = AUDIT_PATHS.flatMap((p) => p.issues.map((i) => i.sev));
  const n = (s: string) => sevs.filter((x) => x === s).length;
  return [
    { sev: "high" as const, label: "高危", count: n("high") },
    { sev: "medium" as const, label: "中危", count: n("medium") },
    { sev: "low" as const, label: "低危", count: n("low") },
    { sev: "critical" as const, label: "硬编码整改项", count: HARDCODES.filter((h) => h.verdict === "bad").length },
  ];
})();

const VERDICT = {
  strong: { label: "强", sev: "good" as const, icon: ShieldCheck },
  good: { label: "良好", sev: "good" as const, icon: BadgeCheck },
  mixed: { label: "喜忧参半", sev: "high" as const, icon: AlertTriangle },
  risky: { label: "发现污点", sev: "critical" as const, icon: Skull },
};

function PathCard({ p, idx }: { p: PathFinding; idx: number }) {
  const [open, setOpen] = useState(idx === 4 || idx === 1); // 默认展开最有料的两张
  const Icon = ICONS[p.icon] ?? Braces;
  const v = VERDICT[p.verdict];
  return (
    <Reveal delay={idx * 60}>
      <div className={clsx("panel overflow-hidden rounded-2xl", open && "border-arcane/40")}>
        <button
          onClick={() => setOpen(!open)}
          className="flex w-full items-center gap-4 px-5 py-5 text-left md:gap-6 md:px-7"
        >
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-arcane/25 bg-arcane/10 text-arcane-bright">
            <Icon size={19} strokeWidth={1.6} />
          </span>
          <span className="min-w-0 flex-1">
            <span className="flex flex-wrap items-center gap-3">
              <span className="font-serifcn text-lg font-bold text-parch md:text-xl">{p.path}</span>
              <span className="font-mono text-[10px] uppercase tracking-[0.25em] text-ash">{p.en}</span>
            </span>
          </span>
          <Badge sev={v.sev}>{v.label}</Badge>
          <ChevronDown size={18} className={clsx("shrink-0 text-ash transition-transform duration-500", open && "rotate-180 text-arcane-bright")} />
        </button>
        <div className={clsx("grid transition-all duration-500 ease-out", open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0")}>
          <div className="overflow-hidden">
            <div className="border-t border-edge/60 px-5 pb-7 pt-5 md:px-7">
              <p className="max-w-3xl text-[13.5px] leading-relaxed text-parch/75">{p.summary}</p>

              <div className="mt-6 grid gap-6 lg:grid-cols-2">
                <div className="space-y-2.5">
                  <div className="mb-3 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.3em] text-xp">
                    <CheckCircle2 size={13} /> 已做对的
                  </div>
                  {p.positives.map((pos, i) => (
                    <div key={i} className="flex gap-2.5 rounded-lg border border-xp/15 bg-xp/[0.04] px-3.5 py-2.5 text-[12.5px] leading-relaxed text-parch/70">
                      <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-xp" />
                      {pos}
                    </div>
                  ))}
                </div>
                <div className="space-y-4">
                  <div className="mb-1 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.3em] text-blood">
                    <AlertTriangle size={13} /> 发现的问题
                  </div>
                  {p.issues.map((iss, i) => (
                    <div key={i} className="rounded-xl border border-edge/80 bg-ink/60 p-4">
                      <div className="flex flex-wrap items-center gap-2.5">
                        <Badge sev={iss.sev}>{iss.sev}</Badge>
                        <span className="text-[13.5px] font-semibold text-parch">{iss.title}</span>
                      </div>
                      <p className="mt-2 text-[12.5px] leading-relaxed text-parch/65">{iss.detail}</p>
                      <div className="mt-3"><FileRef>{iss.file}</FileRef></div>
                      {iss.snippet && <div className="mt-4"><CodeBlock code={iss.snippet.code} title={iss.snippet.title} badge={iss.snippet.badge} /></div>}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Reveal>
  );
}

export function AuditPage() {
  return (
    <div className="page-enter">
      {/* ================= HERO ================= */}
      <header className="relative overflow-hidden px-6 pb-16 pt-32 md:pt-40">
        <div className="rune-grid absolute inset-0" />
        <div className="pointer-events-none absolute -top-32 left-1/2 h-[480px] w-[820px] -translate-x-1/2 rounded-full bg-arcane/20 blur-[140px]" />
        <div className="relative mx-auto max-w-6xl">
          <Reveal>
            <div className="flex flex-wrap items-center gap-3 font-mono text-[11px] tracking-widest text-ash">
              <span className="rounded-full border border-arcane/30 bg-arcane/10 px-3 py-1 text-arcane-bright">CODE AUDIT</span>
              <span className="hidden sm:inline">仓库审查 · 七条路径 · 数值机制复核</span>
            </div>
          </Reveal>
          <Reveal delay={100}>
            <h1 className="mt-7 font-serifcn text-[13vw] font-black leading-[1.04] tracking-tight text-parch sm:text-7xl md:text-[86px]">
              把这座<span className="text-shimmer">符文图书馆</span>
              <br />
              拆开，逐行读一遍
            </h1>
          </Reveal>
          <Reveal delay={200}>
            <p className="mt-7 max-w-2xl text-[14px] leading-relaxed text-ash md:text-base">
              目标仓库：<span className="text-parch">q14433686-arch / chiseled-enchanting-table-26.1.2-source</span>，分支
              <span className="mx-1.5 rounded border border-edge bg-ink px-1.5 py-0.5 font-mono text-[11px] text-lapis">arena/0e406cfe</span>（构建目标 MC 26.3 · 发布签 1.1.0 · Fabric / Java 25）。
              这是 Sacramentix 原作的高强度非官方移植 + 机制扩展。以下审计只基于该分支真实源码。
            </p>
          </Reveal>
          <Reveal delay={280}>
            <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 font-mono text-[11px] text-ash">
              <span className="flex items-center gap-1.5"><GitCommitHorizontal size={13} className="text-arcane-bright" /> 8c6d8a2</span>
              <span className="flex items-center gap-1.5"><Layers3 size={13} className="text-arcane-bright" /> main 21,839 / client 10,083 / test 2,355 行</span>
              <span className="flex items-center gap-1.5"><Landmark size={13} className="text-arcane-bright" /> 自审标签 NET/MX/H/R/GUI/COUP/DEAD/DATA/BAL 共 40+ 处</span>
            </div>
          </Reveal>

          {/* stats */}
          <div className="mt-14 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-edge bg-edge/60 md:grid-cols-4">
            {[
              { v: REPO_STATS.loc, l: "Java 总行数", s: "", i: FileCode2 },
              { v: REPO_STATS.mixins, l: "Mixin 注入点", s: "", i: Syringe },
              { v: REPO_STATS.jsonTables, l: "数据 JSON 表", s: "", i: Boxes },
              { v: REPO_STATS.auditTags, l: "既有自审标签", s: "+", i: Scale },
            ].map((s, i) => (
              <Reveal key={s.l} delay={i * 80} className="bg-obsidian">
                <div className="group px-5 py-6 transition-colors hover:bg-panel md:px-7">
                  <s.i size={16} className="text-arcane transition-transform duration-500 group-hover:-translate-y-1" strokeWidth={1.5} />
                  <div className="mt-3 font-display text-3xl font-semibold text-parch md:text-4xl">
                    <Ticker value={s.v} suffix={s.s} />
                  </div>
                  <div className="mt-1.5 text-[11px] tracking-wider text-ash">{s.l}</div>
                </div>
              </Reveal>
            ))}
          </div>

          {/* findings ledger */}
          <Reveal delay={360}>
            <div className="mt-6 flex flex-wrap items-center gap-x-7 gap-y-3 rounded-2xl border border-edge bg-obsidian/70 px-6 py-5">
              <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-ash">本报告发现</span>
              {FINDING_COUNTS.map((f) => (
                <span key={f.sev} className="flex items-center gap-2 text-[12px]">
                  <Badge sev={f.sev}>{f.label}</Badge>
                  <span className="font-display text-lg font-semibold text-parch">{f.count}</span>
                </span>
              ))}
              <span className="ml-auto hidden text-[11px] text-ash/70 md:inline">所有条目均附文件行号 · 可复验</span>
            </div>
          </Reveal>
        </div>
      </header>

      {/* ================= 硬编码 ================= */}
      <section className="mx-auto max-w-6xl px-6 py-16 md:py-24">
        <SectionHeading
          index="01"
          zh="硬编码清查：什么该留在代码里，什么不该"
          en="HARDCODE AUDIT"
          desc="判定标准只有一条：这个值是「谁的真相」？协议预算与底层极限属于代码；玩法数值与内容清单属于数据。按此标准，八处样本里有两处踩线、两处留债。"
        />
        <div className="space-y-4">
          {HARDCODES.map((h, i) => (
            <Reveal key={h.where} delay={i * 50}>
              <div className="panel grid gap-4 rounded-xl p-5 md:grid-cols-[minmax(0,260px)_minmax(0,1fr)_minmax(0,1.2fr)] md:items-start md:gap-6">
                <div>
                  <Badge sev={h.verdict === "bad" ? "critical" : h.verdict === "warn" ? "high" : "low"}>
                    {h.verdict === "bad" ? "应迁移" : h.verdict === "warn" ? "留债" : "合理"}
                  </Badge>
                  <div className="mt-2.5 font-mono text-[11px] leading-relaxed text-lapis">{h.where}</div>
                </div>
                <div className="min-w-0 font-mono text-[11.5px] leading-relaxed text-xp/90 [overflow-wrap:anywhere]">{h.value}</div>
                <p className="text-[12.5px] leading-relaxed text-parch/65">{h.note}</p>
              </div>
            </Reveal>
          ))}
        </div>
        <Reveal delay={120} className="mt-8">
          <Callout icon={<Scale size={15} className="text-gilt" />} tone="gilt" title="结论：硬编码密度异常低，但双真源是结构性隐疾">
            全树 "minecraft:" 字面量仅 2 处（均有注释背书），说明作者对硬编码有洁癖。真正的问题不是“写死”，而是<strong className="text-parch">同一默认值在 Java 常量与 12 张 JSON 里各写一份</strong>——改一处忘另一处时不会有任何编译器或运行时报错，只有玩家遇到“数据包没生效”的灵异现象。
          </Callout>
        </Reveal>
      </section>

      {/* ================= 七条路径 ================= */}
      <section className="mx-auto max-w-6xl px-6 py-10 md:py-16">
        <SectionHeading
          index="02"
          zh="七条路径的重新审计"
          en="SEVEN AUDIT PATHS"
          desc="源码 API · 数据编解码 · 网络同步 · GUI 输入 · Mixin 注入 · 死代码 · 耦合风险。每条路径给出结论、证据与问题清单；卡片可展开查看代码级证据。"
        />
        <div className="space-y-4">
          {AUDIT_PATHS.map((p, i) => (
            <PathCard key={p.path} p={p} idx={i} />
          ))}
        </div>
      </section>

      {/* ================= 版本适配矩阵 ================= */}
      <section className="mx-auto max-w-6xl px-6 py-16 md:py-24">
        <SectionHeading
          index="03"
          zh="26.1.2 → 26.3：相应版本的适配与债务"
          en="VERSION DELTA"
          desc="“对于相应版本来说的 BUG”在这个分支上要分两眼看：已适配的 API 断点一个不落，但版本身份本身（仓库名 / 频道名 / 发布签三层时间戳互相矛盾）与客户端弃用 API 是两笔未还的债。"
        />
        <Reveal>
          <div className="overflow-hidden rounded-2xl border border-edge">
            <table className="w-full text-left text-[12.5px]">
              <thead>
                <tr className="border-b border-edge bg-panel font-mono text-[10px] uppercase tracking-[0.25em] text-ash">
                  <th className="px-5 py-3.5 font-medium">适配项</th>
                  <th className="hidden px-5 py-3.5 font-medium sm:table-cell">状态</th>
                  <th className="px-5 py-3.5 font-medium">说明</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-edge/60 bg-obsidian/60">
                {VERSION_MATRIX.map((r) => (
                  <tr key={r.item} className="transition-colors hover:bg-panel/70">
                    <td className="px-5 py-4 text-parch/85">{r.item}</td>
                    <td className="hidden px-5 py-4 sm:table-cell">
                      {r.status === "removed-ok" || r.status === "adapted" ? (
                        <Badge sev="low"><CheckCircle2 size={11} /> {r.status === "removed-ok" ? "已移除" : "已适配"}</Badge>
                      ) : (
                        <Badge sev="high"><Ban size={11} /> 债务</Badge>
                      )}
                    </td>
                    <td className="px-5 py-4 leading-relaxed text-ash">{r.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Reveal>
      </section>

      {/* ================= 总判 ================= */}
      <section className="mx-auto max-w-6xl px-6 pb-24">
        <Reveal>
          <div className="relative overflow-hidden rounded-3xl border border-arcane/25 bg-gradient-to-br from-panel via-obsidian to-abyss p-8 md:p-12">
            <div className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-arcane/15 blur-[90px]" />
            <div className="font-mono text-[10px] uppercase tracking-[0.35em] text-arcane">FINAL VERDICT</div>
            <h3 className="mt-4 max-w-3xl font-serifcn text-2xl font-bold leading-snug text-parch md:text-4xl">
              这不是“会崩”的代码，<br className="hidden md:block" />
              而是三处会慢慢渗水的堤岸。
            </h3>
            <div className="mt-7 grid gap-5 md:grid-cols-3">
              {[
                { t: "生成物与人审的边界", d: "epiphanyMaxSlots 的恒真三元式 + NEXT_TASK.md 自述的 one-shot merge scripts：部分代码由脚本落地后未再被人眼第二遍审读，需要一次“生成残留”专项清扫。" },
                { t: "双真源漂移", d: "Java fallback 常量 ↔ 12 张 JSON 默认值；仓库名 26.1.2 ↔ 构建 26.3 ↔ 协议 26_3_revision_9。所有“两处写一份真相”的地方都在等一次静默分叉。" },
                { t: "全局改写的外溢", d: "铁砧惩罚抹平、原版台拦截、磨石行为、村民交易消毒默认全开——对整合包生态而言，这个 mod 是 overhaul 而非 port，默认策略需要分级。" },
              ].map((c, i) => (
                <div key={c.t} className="rounded-xl border border-edge/70 bg-ink/50 p-5">
                  <div className="font-display text-sm font-semibold text-arcane-bright">0{i + 1} · {c.t}</div>
                  <p className="mt-2.5 text-[12.5px] leading-relaxed text-parch/65">{c.d}</p>
                </div>
              ))}
            </div>
            <p className="mt-8 max-w-3xl text-[13px] leading-relaxed text-ash">
              总体上，协议卫生、有界解码、服务端权威、Mixin 注入纪律远超“移植项目”的平均水平，40+ 条成文的自审标签在同类仓库里罕见。剩余风险全部属于“工程组织学”而非“ correctness ”——它们不会让服务器今晚崩掉，但会在下一个版本、下一个贡献者、下一个整合包里复利。
            </p>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
