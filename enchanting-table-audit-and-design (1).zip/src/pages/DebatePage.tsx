import {
  Quote, Infinity as InfinityIcon, LibraryBig, Gauge, Hourglass, Shuffle,
  Swords, Layers, BookOpenText, Coins, Flame, ScrollText, Compass, Scale as ScaleIcon,
} from "lucide-react";
import { Reveal, SectionHeading, Callout, Badge } from "../components/chrome";
import { DiscountSimulator, TierCurveChart } from "../components/simulators";

export function DebatePage() {
  return (
    <div className="page-enter">
      {/* ================= HERO ================= */}
      <header className="relative overflow-hidden px-6 pb-14 pt-32 md:pt-40">
        <div className="rune-grid absolute inset-0" />
        <div className="pointer-events-none absolute -top-32 left-1/2 h-[480px] w-[820px] -translate-x-1/2 rounded-full bg-xp/10 blur-[140px]" />
        <div className="relative mx-auto max-w-6xl">
          <Reveal>
            <div className="flex flex-wrap items-center gap-3 font-mono text-[11px] tracking-widest text-ash">
              <span className="rounded-full border border-xp/30 bg-xp/10 px-3 py-1 text-xp">DESIGN DEBATE</span>
              <span className="hidden sm:inline">增益与上限 · 超级附魔书 · 机制答辩</span>
            </div>
          </Reveal>
          <Reveal delay={100}>
            <h1 className="mt-7 font-serifcn text-[13vw] font-black leading-[1.04] tracking-tight text-parch sm:text-7xl md:text-[80px]">
              收益给了方向，<br /><span className="text-shimmer">上限给了形状</span>
            </h1>
          </Reveal>
        </div>
      </header>

      {/* ================= 两种论调 ================= */}
      <section className="mx-auto max-w-6xl px-6 pb-20">
        <div className="grid gap-5 md:grid-cols-2">
          <Reveal>
            <div className="panel relative h-full rounded-2xl p-7">
              <Quote size={22} className="text-arcane/60" />
              <blockquote className="mt-4 font-serifcn text-lg font-bold leading-relaxed text-parch md:text-xl">
                “都给「无限」和周围多书架 / 模板书这么大增益了，为什么还要限制单本模板书、多书架、「无限」的增益？这不是自相矛盾吗？”
              </blockquote>
              <div className="mt-5 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.3em] text-ash">
                <span className="rounded border border-edge bg-ink px-2 py-0.5 text-arcane-bright">论调 A</span>
                增益的存在否定了上限的正当性
              </div>
            </div>
          </Reveal>
          <Reveal delay={120}>
            <div className="panel relative h-full rounded-2xl p-7">
              <Quote size={22} className="text-xp/60" />
              <blockquote className="mt-4 font-serifcn text-lg font-bold leading-relaxed text-parch md:text-xl">
                “那我只附魔一本包含「无限」的超级附魔书、上面堆满所有附魔，一次性赚麻，不就完了？”
              </blockquote>
              <div className="mt-5 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.3em] text-ash">
                <span className="rounded border border-edge bg-ink px-2 py-0.5 text-xp">论调 B</span>
                一次性囤积全部价值即可跳关
              </div>
            </div>
          </Reveal>
        </div>
        <Reveal delay={180}>
          <p className="mx-auto mt-10 max-w-3xl text-center text-[14px] leading-loose text-ash">
            两种论调共享同一个前提：<strong className="text-parch">把「增益的存在」误读成「增益无条件的承诺」</strong>。
            下面用仓库里的真实公式与真实数字回答——所有数值均取自 shelf_gates.json / library_resonance.json / enchantment_costs.json 的默认配置与对应 Java 实现。
          </p>
        </Reveal>
      </section>

      {/* ================= 论点一：经济与守恒 ================= */}
      <section className="mx-auto max-w-6xl px-6 py-10">
        <SectionHeading
          index="01"
          zh="对论调 A：上限不是增益的反面，是增益的守恒线"
          en="WHY CAPS EXIST"
          desc="这套 Mod 的经济学骨架是“投入→确定性产出”替代“赌 RNG”。只要产出可无限叠加，任何百分比增益都必须回答一个问题：第 100 个书架还值钱吗？作者的回答是双闸门——边际递减 + 硬性封顶。"
        />

        <div className="grid gap-5 lg:grid-cols-3">
          {[
            {
              icon: Gauge, t: "递减：收益贴现",
              d: "木书架 12–38 架线性爬升到 -15%；藏书馆精通按 ⌊units×1.25⌋ 封顶 -20%；升阶曲线 gamma=1.25 幂律，让“前几级便宜、冲顶昂贵”。",
              tag: "GROWTH SHAPE",
            },
            {
              icon: Compass, t: "封顶：硬顶 40%",
              d: "公共减免（木架+精通）先压进 35% 小顶，加上同种藏书专精（≤15%）之后，再被 40% 总顶钳死。两道闸门，互相独立，全部数据可调。",
              tag: "HARD CEILING",
            },
            {
              icon: ScaleIcon, t: "守恒：封顶的真实原因",
              d: "祛魔返还系数 xp_refund_scale=1.0（本台溯源全额溯返）。若成本贴现无顶，玩家附魔→祛魔循环的净经验将转正——“经验银行”瞬间变“经验印钞机”。40% 是这条守恒线不被击穿的安全距离。",
              tag: "CONSERVATION",
            },
          ].map((c, i) => (
            <Reveal key={c.t} delay={i * 90}>
              <div className="panel h-full rounded-2xl p-6">
                <c.icon size={20} className="text-arcane-bright" strokeWidth={1.5} />
                <h3 className="mt-4 font-serifcn text-lg font-bold text-parch">{c.t}</h3>
                <p className="mt-2.5 text-[12.5px] leading-relaxed text-parch/65">{c.d}</p>
                <div className="mt-4 font-mono text-[9px] uppercase tracking-[0.3em] text-ash/60">{c.tag}</div>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={160} className="mt-10">
          <Callout icon={<InfinityIcon size={15} className="text-arcane-bright" />} tone="arcane" title="“无限”不是福利，是被重新定价的稀缺">
            代码层面，Infinity 被逐出村民交易（检测到即改写为力量 I，且有 restrict 总闸）、只保留探索战利品 / 原版台随机 / 母本拓印三条窄通道；仪式强冲时 Infinity 母本反噬率反而更高（<span className="font-mono text-xp">70%</span> vs 常规 50%）；超载 Infinity 母本（≥5 词条）触发「抄错」降级（≤18%）。<strong className="text-parch">免疫磨损的礼物刚一送出，立刻被三把磨损之外的新锁锁上</strong>——这不是自相矛盾，这是把同一件商品从“耐用度市场”搬到了“时间与风险市场”。
          </Callout>
        </Reveal>

        <Reveal delay={200} className="mt-10">
          <div className="mb-4 flex items-baseline gap-3">
            <Flame size={16} className="text-gilt" />
            <h3 className="font-serifcn text-xl font-bold text-parch">亲手推一遍封顶机 —— 折扣模拟器（公式一比一复刻源码）</h3>
          </div>
          <DiscountSimulator />
        </Reveal>

        <Reveal delay={120} className="mt-10">
          <div className="mb-4 flex items-baseline gap-3">
            <Layers size={16} className="text-lapis" />
            <h3 className="font-serifcn text-xl font-bold text-parch">书架升阶曲线 —— “白板只到半程，满级必须走母本”</h3>
          </div>
          <TierCurveChart />
          <p className="mt-4 max-w-3xl text-[12.5px] leading-relaxed text-ash">
            算法直译自 <span className="font-mono text-[11px] text-lapis">BookshelfProgression.requiredBookshelvesForDirectTier</span>（gamma=1.25，cap=38，含 [1, cap-1] 夹逼）。
            关键点：直附天然停在 <span className="font-mono text-arcane-bright">⌈M/2⌉</span>（HALF_CEIL），想要满级必须经由母本拓印——<strong className="text-parch">单一路线的增益全都被设计成“半程车票”，这才是“单本模板书/多书架增益都有上限”的真正形状</strong>。
          </p>
        </Reveal>
      </section>

      {/* ================= 论点二：超级书 ================= */}
      <section className="mx-auto max-w-6xl px-6 py-16 md:py-24">
        <SectionHeading
          index="02"
          zh="对论调 B：超级附魔书可以造，但“赚麻了”是账目幻觉"
          en="THE SUPER-BOOK FALLACY"
          desc="先承认事实：是的，你确实可以造出一本全词条母本——作者甚至为这一步立了进度里程碑（all_enchant_book / eternal_codex）。但从「造出来」到「真赚到」之间，隔着五重写死在源码里的摩擦。"
        />

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {[
            {
              icon: Hourglass, tag: "摩擦 Ⅰ · 拓印磨损",
              t: "一本书 ≠ 无限次复制",
              d: "母本充能上限 4，拓印一次磨损 2 —— 满充能只支撑 2 次复制；耗尽按 step_down 降阶直至褪魔残卷。图书馆温养可再生：无架 2 小时/次，38 架 1 小时，42 架 20 分钟。Infinity 免磨损，但获取通道被刻意收窄（见上）。",
              n: "max_tome_uses=4 · book_copy_wear_cost=2 · regen 7200s→3600s→1200s",
            },
            {
              icon: LibraryBig, tag: "摩擦 Ⅱ · 仪式队列",
              t: "造书本身收取时间税",
              d: "母本词条 ≥10 或书架过中位数即进入深共鸣仪式：单步等待 ≤5 分钟，排队有界累积。可用 1–15 级经验献祭零风险跳过；也可强冲——失败则以优先级最低的母本为祭品（低等级/少词条/低稀有度优先降级为残卷）。",
              n: "max_single_wait=300s · sacrifice ≤15 lv · rush 反噬 ≤50%（Infinity 70%）",
            },
            {
              icon: Shuffle, tag: "摩擦 Ⅲ · 抄错滑率",
              t: "超载 Infinity 母本会被降级",
              d: "当附近存在带 Infinity 且总词条 ≥5 的母本时，转录滑率按词条数 × 书架数爬升，封顶 ≤18–20%，直接把写入词条降级。源码里这条机制的成就叫“crossline_slip（跨行抄错）”——嘲讽写在了成就 ID 里。",
              n: "min_load=3 · slope 0.035/档 · slip cap ≤18%",
            },
            {
              icon: Swords, tag: "摩擦 Ⅳ · 互斥与适配",
              t: "“所有附魔”物理上无法共存",
              d: "exclusive_set 与 canEnchant 仍然存在：保护系互斥、伤害系互斥，无限与经验修补之外的装载冲突照旧——一本书可以携带冲突词条，但落到装备上的永远只能是一组相容解。",
              n: "EnchantmentApplication.applyFromBook: canEnchant + 冲突覆写退款",
            },
            {
              icon: BookOpenText, tag: "摩擦 Ⅴ · 逐条转移",
              t: "从书到装备，一次只走一条",
              d: "每次应用只转移选定的那一条附魔，其余留在书上；书空则降级为残卷。同级/低级转移直接拒付（M-03），每条仍收经验（无限 12 级/条）与材料（青金石 3→20 枚，幂 1.3；绿宝石 / 紫水晶替代路）。",
              n: "infinity: 12 lv · mending: 12 lv · lapis 3→20 ×1.3",
            },
            {
              icon: Coins, tag: "汇兑成本",
              t: "库存价值 ≠ 流通价值",
              d: "超级书是“库存价值”——词条静静地躺在 NBT 里；装备的“流通价值”只有生效词条才算数。两者之间的汇率，正是上面四重摩擦。设计允许你造奖杯，但刻意不允许“造奖杯=毕业”。",
              n: "成就锚点：all_enchant_book / eternal_codex",
            },
          ].map((c, i) => (
            <Reveal key={c.t} delay={i * 70}>
              <div className="panel group flex h-full flex-col rounded-2xl p-6">
                <div className="flex items-center justify-between">
                  <c.icon size={19} className="text-gilt transition-transform duration-500 group-hover:scale-110" strokeWidth={1.5} />
                  <span className="font-mono text-[9px] uppercase tracking-[0.25em] text-ash/60">{c.tag}</span>
                </div>
                <h3 className="mt-4 font-serifcn text-[17px] font-bold text-parch">{c.t}</h3>
                <p className="mt-2.5 flex-1 text-[12.5px] leading-relaxed text-parch/65">{c.d}</p>
                <div className="mt-4 rounded-lg border border-edge/70 bg-ink/70 px-3 py-2 font-mono text-[10.5px] leading-relaxed text-xp/80">{c.n}</div>
              </div>
            </Reveal>
          ))}
        </div>

        {/* windfall ledger */}
        <Reveal delay={140} className="mt-12">
          <div className="overflow-hidden rounded-2xl border border-edge">
            <div className="border-b border-edge bg-panel px-6 py-4">
              <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.3em] text-ash">
                <ScrollText size={13} /> “一本全词条书”的假想账本 vs 源码账本
              </div>
            </div>
            <div className="grid divide-y divide-edge/60 bg-obsidian/60 md:grid-cols-2 md:divide-x md:divide-y-0">
              <div className="p-6 md:p-8">
                <Badge sev="critical">假想账本</Badge>
                <ul className="mt-4 space-y-3 text-[13px] leading-relaxed text-parch/70">
                  <li className="flex gap-2.5"><span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-blood" />所有词条写进一本书 = 所有词条“归档完毕”</li>
                  <li className="flex gap-2.5"><span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-blood" />书在 = 收益在，可以永久躺赢</li>
                  <li className="flex gap-2.5"><span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-blood" />附到任意装备 = 全词条一键到账</li>
                  <li className="flex gap-2.5"><span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-blood" />因此：限制它 = 与增益自相矛盾</li>
                </ul>
              </div>
              <div className="p-6 md:p-8">
                <Badge sev="low">源码账本（实际结算）</Badge>
                <ul className="mt-4 space-y-3 text-[13px] leading-relaxed text-parch/70">
                  <li className="flex gap-2.5"><span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-xp" />造书阶段已缴税：仪式等待（≤5 分钟/步）+ 献祭或赌博 + 超载抄错（≤18% 降级）</li>
                  <li className="flex gap-2.5"><span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-xp" />持书阶段持续折旧：拓印磨损 2/次、4 充能封顶、再生按小时计</li>
                  <li className="flex gap-2.5"><span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-xp" />变现阶段逐条收费：一词条一经验一材料，冲突词条只能二选一</li>
                  <li className="flex gap-2.5"><span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-xp" />回响阶段反打：同种藏书 ≥4/6 条虽解锁拓印捷径，但风化权重 [45/35/15/5] 让野生书期望 17.8% 变残卷</li>
                </ul>
              </div>
            </div>
          </div>
        </Reveal>
      </section>

      {/* ================= 结语 ================= */}
      <section className="mx-auto max-w-6xl px-6 pb-24">
        <Reveal>
          <div className="relative overflow-hidden rounded-3xl border border-xp/20 bg-gradient-to-br from-panel via-obsidian to-abyss p-8 md:p-12">
            <div className="pointer-events-none absolute -left-20 -top-20 h-72 w-72 rounded-full bg-xp/10 blur-[90px]" />
            <div className="font-mono text-[10px] uppercase tracking-[0.35em] text-xp">CLOSING ARGUMENT</div>
            <h3 className="mt-4 font-serifcn text-2xl font-bold leading-snug text-parch md:text-3xl">
              这不是自相矛盾，<br />这是这个 Mod 的基本法。
            </h3>
            <p className="mt-5 max-w-3xl text-[13.5px] leading-loose text-parch/75">
              “增益给方向、上限给形状”看似一句话修辞，实际是逐行落进代码的：递减靠 gamma=1.25 与 ⌊×1.25⌋，封顶靠 35%→40% 双闸门，时间税靠 300 秒仪式与小时级温养，风险税靠 50%/70% 反噬与 18% 抄错。
              真正喜欢“无限增益无上限”的玩家需要的不是 De-buff，而是一本数值为 0 的 config——而这个 Mod 连这一点都想到了：<span className="font-mono text-[12px] text-lapis">library_resonance.json / shelf_gates.json</span> 里每一道闸门都是数据包可调的。
              <strong className="text-parch">上限存在的意义，恰恰是让“增益”这个词在 40 个书架之后仍然有意义。</strong>
            </p>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
