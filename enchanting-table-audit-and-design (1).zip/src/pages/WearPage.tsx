import { useMemo, useState } from "react";
import { BookCopy, Scissors, Scale, Lightbulb, ArrowRight, Hourglass, Coins, Dna, Gavel } from "lucide-react";
import { clsx } from "clsx";
import { Reveal, SectionHeading, CodeBlock, Badge, Callout, FileRef } from "../components/chrome";

/* ---------------- policy simulator ---------------- */
type Policy = "current" | "inherit" | "priced";

function simulate(policy: Policy, cycles: number, maxUses = 4) {
  // 一轮 = 用满 (maxUses-1) 次好词条 + 1 次替罪羊。
  // 返回：好词条总次数、替罪羊成本（经验级）、好词条掉级次数、等待的再生小时数（无架 2h/充能）
  let good = 0, scapegoatXp = 0, stepDowns = 0, regenHours = 0;
  for (let c = 0; c < cycles; c++) {
    good += maxUses - 1;
    if (policy === "current") {
      scapegoatXp += 2 + 2; // 替罪羊本身 2 级 + 事后补一条 1 级垃圾词条 2 级
    } else if (policy === "inherit") {
      // 替罪羊照旧可用；但抄本继承磨损 → 对本题无影响，这里视作与 current 同
      scapegoatXp += 4;
    } else {
      // 替罪羊按词条精华定价：烧 1 级垃圾词条只回 2/12 ≈ 17% 充能 → 需再生补足
      scapegoatXp += 2;
      regenHours += 2 * (maxUses - 1) * (1 - 2 / 12);
    }
  }
  // 对照：不作弊，直接吃掉级
  const honestStepDowns = cycles;
  return { good, scapegoatXp, stepDowns, regenHours, honestStepDowns };
}

function PolicySim() {
  const [cycles, setCycles] = useState(6);
  const rows = useMemo(
    () =>
      (["current", "inherit", "priced"] as Policy[]).map((p) => ({ p, ...simulate(p, cycles) })),
    [cycles]
  );
  const label: Record<Policy, string> = { current: "现状（抵罪全额重置）", inherit: "方案 A：抄本继承磨损", priced: "方案 B：按词条精华定价抵罪" };
  return (
    <div className="panel rounded-2xl p-6 md:p-8">
      <div className="mb-6 flex items-baseline justify-between">
        <label className="text-[13px] font-semibold text-parch">模拟轮数（每轮 3 次正经拓印 + 1 次抵罪）</label>
        <span className="font-mono text-xl text-arcane-bright">{cycles}</span>
      </div>
      <input type="range" min={1} max={20} value={cycles} onChange={(e) => setCycles(+e.target.value)} className="w-full" style={{ "--fill": `${(cycles / 20) * 100}%` } as React.CSSProperties} />
      <div className="mt-7 grid gap-3">
        {rows.map((r) => (
          <div key={r.p} className={clsx("grid gap-3 rounded-xl border p-4 md:grid-cols-[1.3fr_repeat(3,1fr)] md:items-center", r.p === "priced" ? "border-xp/30 bg-xp/[0.05]" : "border-edge/70 bg-ink/50")}>
            <div className="text-[13px] font-semibold text-parch">{label[r.p]}</div>
            <Stat l="好词条拓印" v={`${r.good} 次`} />
            <Stat l="好词条掉级" v={`${r.stepDowns} 次`} dim={`诚实玩法 ${r.honestStepDowns}`} />
            <Stat l="抵罪代价" v={r.p === "priced" ? `${r.scapegoatXp} 级 + ${r.regenHours.toFixed(0)} h 温养` : `${r.scapegoatXp} 级 + 几枚青金石`} warn={r.p !== "priced"} />
          </div>
        ))}
      </div>
      <p className="mt-5 text-[12px] leading-relaxed text-ash">
        现状下，玩家以每轮约 4 级经验的代价，把“掉一级”这个本应触发的惩罚**永久清零**；再生系统（2h/1h/20min 一充能）也被整体绕开。方案 B 不取缔抵罪，而是让“烧什么”决定“回多少”——烧 1 级垃圾只回约 1/6，剩下的还得交给时间。
      </p>
    </div>
  );
}
function Stat({ l, v, dim, warn }: { l: string; v: string; dim?: string; warn?: boolean }) {
  return (
    <div>
      <div className="font-mono text-[9.5px] uppercase tracking-[0.25em] text-ash/70">{l}</div>
      <div className={clsx("mt-0.5 font-display text-base font-semibold", warn ? "text-gilt" : "text-parch")}>{v}</div>
      {dim && <div className="text-[10.5px] text-ash/60">{dim}</div>}
    </div>
  );
}

/* ---------------- wear cycle visual ---------------- */
function WearStrip() {
  const [step, setStep] = useState(0);
  const frames = [
    { wear: 0, note: "母本：锋利 V · 耐久 IV · 节肢杀手 I（替罪羊）", act: "初始 0/4 磨损" },
    { wear: 1, note: "拓印 锋利 V → 剑", act: "磨损 1/4" },
    { wear: 2, note: "拓印 锋利 V → 第二把剑", act: "磨损 2/4" },
    { wear: 3, note: "拓印 耐久 IV → 镐", act: "磨损 3/4 · UI 显示“剩 1 充能”" },
    { wear: 0, note: "拓印 节肢杀手 I → 随便一把木剑", act: "溢出 → 节肢杀手被移除，磨损归 0，锋利 V 毫发无伤" },
  ];
  const f = frames[step];
  return (
    <div className="panel rounded-2xl p-6 md:p-8">
      <div className="flex items-center gap-2">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className={clsx("h-3 flex-1 rounded-full transition-all duration-500", i < f.wear ? "bg-blood shadow-[0_0_12px_#f0716e]" : "bg-edge")} />
        ))}
        <span className="ml-3 font-mono text-[11px] text-ash">wear {f.wear}/4</span>
      </div>
      <div className="mt-5 min-h-[56px]">
        <div className="text-[14px] font-semibold text-parch">{f.note}</div>
        <div className="mt-1 text-[12px] text-ash">{f.act}</div>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {frames.map((_, i) => (
          <button key={i} onClick={() => setStep(i)} className={clsx("rounded-lg border px-3 py-1.5 font-mono text-[11px] transition-colors", i === step ? "border-arcane bg-arcane/15 text-arcane-bright" : "border-edge text-ash hover:text-parch")}>
            步骤 {i}
          </button>
        ))}
        <button onClick={() => setStep((step + 1) % frames.length)} className="ml-auto flex items-center gap-1 rounded-lg border border-xp/40 bg-xp/10 px-3 py-1.5 font-mono text-[11px] text-xp">
          下一步 <ArrowRight size={12} />
        </button>
      </div>
    </div>
  );
}

export function WearPage() {
  return (
    <div className="page-enter">
      <header className="relative overflow-hidden px-6 pb-14 pt-32 md:pt-40">
        <div className="rune-grid absolute inset-0" />
        <div className="pointer-events-none absolute -top-32 left-1/2 h-[480px] w-[820px] -translate-x-1/2 rounded-full bg-blood/10 blur-[140px]" />
        <div className="relative mx-auto max-w-6xl">
          <Reveal>
            <div className="flex flex-wrap items-center gap-3 font-mono text-[11px] tracking-widest text-ash">
              <span className="rounded-full border border-blood/30 bg-blood/10 px-3 py-1 text-blood">WEAR ECONOMY</span>
              <span className="hidden sm:inline">两处“设计级 BUG”的核实与裁决</span>
            </div>
          </Reveal>
          <Reveal delay={100}>
            <h1 className="mt-7 font-serifcn text-[13vw] font-black leading-[1.04] tracking-tight text-parch sm:text-7xl md:text-[80px]">
              满血抄本，<br /><span className="text-shimmer">替罪的词条</span>
            </h1>
          </Reveal>
          <Reveal delay={200}>
            <p className="mt-7 max-w-2xl text-[14px] leading-relaxed text-ash">
              你提出的两点我都去源码里核过了：<strong className="text-parch">两点都是事实</strong>。但“是事实”与“是 BUG”是两回事——下面分别给出代码证据、裁决，以及我认为比“一刀砍掉”更好的修法。
            </p>
          </Reveal>
        </div>
      </header>

      {/* ============ CASE 1 ============ */}
      <section className="mx-auto max-w-6xl px-6 py-10">
        <SectionHeading index="01" zh="案一：抄本出生即满充能" en="FULL-CHARGE COPIES" desc="把母本的词条拓印到一本新书上，新书的 cet_tome_wear 永远是 0。" />
        <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
          <Reveal>
            <CodeBlock
              title="全树 setWearUsed 写入点 —— 没有一处在附魔/拓印路径上"
              badge="GREP"
              code={`// grep -rn "setWearUsed\\|applyWildBookWear" src/main/java
WorldRegeneration.java:177   setWearUsed(updated, recovery.remainingWear()); // 温养回复
ApplyWildBookWearFunction.java:42   applyWildBookWear(...)                 // 战利品风化
BookshelfBookFiller.java:540        applyWildBookWear(...)                 // 结构书架风化

// EnchantmentApplication.applyFromBook / apply → 对目标书：
//   只写 enchantments + provenance，从不 setWearUsed
//   ⇒ 任何抄本 wear = 0 = 满充能`}
            />
          </Reveal>
          <Reveal delay={100} className="space-y-4">
            <Callout icon={<Scale size={15} className="text-blood" />} tone="blood" title="裁决：是 BUG —— 它让“磨损”对书这一类目标失去定义">
              每轮 4 充能可拓 2 本满血抄本（书拓本费 2），原本掉 1 级，但两本抄本都是**满级且满充能**。1 → 2 → 4 → 8，磨损系统在"书→书"这条边上是零阻力的指数增殖。再生系统（2h/1h/20min）设计的全部意义，在这条边上被一次性清空。
            </Callout>
            <div className="rounded-xl border border-edge/70 bg-ink/60 p-5 text-[12.5px] leading-relaxed text-parch/70">
              <div className="mb-2 font-mono text-[10px] uppercase tracking-[0.25em] text-ash">残存的摩擦（不足以抵消）</div>
              每本抄本仍要付：词条经验（锋利 V 约 10 级）+ 材料 + 可能的仪式等待 + 超载抄错 ≤18%。这些都是**线性税**，面对指数增殖是螳臂当车。
            </div>
          </Reveal>
        </div>

        <Reveal delay={140} className="mt-8">
          <div className="mb-4 flex items-center gap-2"><Lightbulb size={16} className="text-gilt" /><h3 className="font-serifcn text-xl font-bold text-parch">修法（按推荐度）</h3></div>
          <div className="grid gap-4 md:grid-cols-3">
            {[
              { icon: Dna, k: "推荐 · 世代褪色", t: "抄本继承 generation+1，每代 maxUses −1", d: "复印件的复印件会褪色——这是所有人都懂的直觉。NBT 加一个 cet_generation，remainingCharges 用 max(1, maxUses − generation − wear)。第 4 代抄本出生即只剩 1 口气，必须靠温养活着。Provenance 系统已存在，挂个字段零成本。", sev: "low" as const },
              { icon: Hourglass, k: "备选 · 继承磨损", t: "抄本 wear = 父本 wear + 拓本费", d: "最小改动：抄本带着父本的疲劳出生。缺点：首轮抄本仍几乎满血，只是把问题推迟一轮；但与再生系统天然接轨（新书出生就要排队温养）。", sev: "medium" as const },
              { icon: Coins, k: "保守 · 不改机制改价格", t: "书→书拓本费从 2 提到 maxUses−1（=3）", d: "一轮只出一本抄本、母本必掉级。纯数据包可调（book_copy_wear_cost），零代码。但只是把增殖倍率从 ×2 压到 ×1，没有从根上回答“磨损为何不继承”。", sev: "high" as const },
            ].map((o, i) => (
              <Reveal key={o.k} delay={i * 70}>
                <div className="panel h-full rounded-2xl p-6">
                  <div className="flex items-center justify-between"><o.icon size={18} className="text-arcane-bright" strokeWidth={1.5} /><Badge sev={o.sev}>{o.k}</Badge></div>
                  <h4 className="mt-4 text-[14px] font-bold text-parch">{o.t}</h4>
                  <p className="mt-2 text-[12.5px] leading-relaxed text-parch/65">{o.d}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </Reveal>
      </section>

      {/* ============ CASE 2 ============ */}
      <section className="mx-auto max-w-6xl px-6 py-16 md:py-24">
        <SectionHeading index="02" zh="案二：用垃圾词条“抵罪”刷新耐久" en="THE SCAPEGOAT" desc="磨损计数是书级的，溢出惩罚却只落在“本次被抄的那条词条”上。把最后一口气花在一条不要的词条上，母本满血复活，心爱的词条毫发无伤。" />
        <div className="grid gap-6 lg:grid-cols-2">
          <Reveal>
            <CodeBlock
              title="MasterTomeWear.computeWearStep — 溢出分支"
              badge="ROOT CAUSE"
              code={`int updatedWear = safeWear + delta;
if (updatedWear < safeMaxUses) {
    return new WearStepResult(safeLevel, updatedWear, false, false);
}
if (mode == CONSUME || depleteBehavior == DEPLETED_TOME || safeLevel <= 1) {
    return new WearStepResult(0, 0, false, true);   // 词条移除，wear → 0
}
return new WearStepResult(safeLevel - 1, 0, true, false); // 仅此词条 −1，wear → 0
//                                          ^^^
//   无论烧掉的是「无限」还是「节肢杀手 I」，重置量都是 100%`}
            />
          </Reveal>
          <Reveal delay={100}>
            <WearStrip />
          </Reveal>
        </div>

        <Reveal delay={120} className="mt-8 grid gap-5 lg:grid-cols-2">
          <Callout icon={<Gavel size={15} className="text-gilt" />} tone="gilt" title="裁决：不是 correctness BUG，是定价 BUG">
            你的直觉是对的——“从实际代价看不一定是 BUG”。它没有破坏任何不变量，而且<strong className="text-parch">“献祭一条词条换母本续命”本身是个极有风味的机制</strong>（成就系统里连「心急吃不了热豆腐」都有，这个叫「替罪羊」刚好配套）。问题只有一个：<strong className="text-parch">献祭品的价值不参与定价</strong>。烧一条 2 级经验的垃圾词条，和烧一条 12 级的「无限」，换回的是同样 100% 的重置。
          </Callout>
          <div className="rounded-xl border border-edge/70 bg-ink/60 p-5 text-[12.5px] leading-relaxed text-parch/70">
            <div className="mb-2 font-mono text-[10px] uppercase tracking-[0.25em] text-ash">顺带发现的两个配套事实</div>
            <ul className="space-y-2">
              <li>· <span className="font-mono text-lapis">remainingCharges = max(1, maxUses − wear)</span>：UI 永远不显示 0，“剩 1 充能”就是“下一次必溢出”——时机对玩家完全透明，这对**有意设计的机制**是好事，对**漏洞**是坏事。</li>
              <li>· <span className="font-mono text-lapis">CANDIDATE_ORDER</span> 优先选低等级、高磨损的母本——系统会主动把最残的那本推上祭坛，进一步降低玩家操作成本。</li>
            </ul>
            <div className="mt-3"><FileRef>mechanics/resonance/MasterTomeWear.java:410 · :456</FileRef></div>
          </div>
        </Reveal>

        <Reveal delay={160} className="mt-10">
          <div className="mb-4 flex items-center gap-2"><Scissors size={16} className="text-xp" /><h3 className="font-serifcn text-xl font-bold text-parch">推荐修法：把“抵罪”扶正，按词条精华定价</h3></div>
          <div className="grid gap-6 lg:grid-cols-[1fr_1.1fr]">
            <div className="space-y-4 text-[13px] leading-relaxed text-parch/75">
              <p>仓库里已经有一套现成的词条估值器：<span className="font-mono text-[12px] text-lapis">DisenchantmentApplication.essencePotential(holder, level, scale)</span>，祛魔返还就靠它。把它接进溢出分支：</p>
              <ol className="list-decimal space-y-2 pl-5">
                <li>溢出时计算 <span className="font-mono text-[12px]">ratio = essence(被烧词条) / max(essence(母本内各词条))</span>。</li>
                <li><span className="font-mono text-[12px]">nextWear = round(maxUses × (1 − ratio))</span>，而非一律 0。烧掉母本里最贵的词条 → 全额重置；烧 1 级垃圾 → 几乎不回血，剩下的交给温养。</li>
                <li>GUI 把这件事做成**显式按钮**：“献祭词条”—— 让玩家选烧哪条，并显示能换回多少充能。隐性漏洞变成显性策略。</li>
                <li>数据包开关 <span className="font-mono text-[12px]">scapegoat_pricing: "essence" | "flat"</span>，想保留现状的服务器可以选 flat。</li>
              </ol>
              <CodeBlock
                title="示意补丁（computeWearStep 溢出分支）"
                code={`// 新增参数：burnedEssence, topEssenceInTome
double ratio = topEssenceInTome <= 0 ? 1.0
    : Math.max(0.0, Math.min(1.0, burnedEssence / topEssenceInTome));
int restored = (int) Math.round(safeMaxUses * ratio);
int nextWear = Math.max(0, safeMaxUses - Math.max(1, restored));
return new WearStepResult(safeLevel - 1, nextWear, true, false);`}
              />
            </div>
            <PolicySim />
          </div>
        </Reveal>
      </section>

      {/* ============ closing ============ */}
      <section className="mx-auto max-w-6xl px-6 pb-24">
        <Reveal>
          <div className="relative overflow-hidden rounded-3xl border border-arcane/25 bg-gradient-to-br from-panel via-obsidian to-abyss p-8 md:p-12">
            <div className="font-mono text-[10px] uppercase tracking-[0.35em] text-arcane">MY TAKE</div>
            <h3 className="mt-4 font-serifcn text-2xl font-bold leading-snug text-parch md:text-3xl">同一个病根：磨损是“书”的属性，惩罚是“词条”的属性。</h3>
            <p className="mt-5 max-w-3xl text-[13.5px] leading-loose text-parch/75">
              案一是这个错位在“书→书”边上的表现（新书没有继承任何书级状态），案二是它在“溢出”时刻的表现（书级计数清零，词条级惩罚却可以挑软柿子）。
              所以我不建议分别打两个补丁，而是建议<strong className="text-parch">一次性把 wear 从单个 int 升级为一个小结构</strong>：<span className="font-mono text-[12px] text-lapis">{`{ wear, generation, lineage }`}</span> —— 抄本继承 lineage 与 generation+1，溢出惩罚按精华定价。
              两处“BUG”就都变成了同一套可讲出口的规则：<em className="text-arcane-bright">复印会褪色，献祭看诚意。</em>
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              <Badge sev="critical">案一：建议修复</Badge>
              <Badge sev="high">案二：建议扶正而非删除</Badge>
              <Badge sev="good">共用一个数据结构解决</Badge>
            </div>
          </div>
        </Reveal>
      </section>
      <span className="hidden"><BookCopy /></span>
    </div>
  );
}
