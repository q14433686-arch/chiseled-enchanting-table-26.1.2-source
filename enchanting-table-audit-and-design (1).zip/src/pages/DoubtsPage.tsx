import {
  Eye, Wrench, FlaskConical, FileWarning, GitBranch, Fingerprint,
  TestTube2, BookMarked, ToggleRight, Hourglass, ShieldAlert, Hammer,
} from "lucide-react";
import { Reveal, SectionHeading, Badge, FileRef, Callout } from "../components/chrome";

const DOUBTS = [
  {
    icon: Fingerprint,
    title: "生成物与人审之间的灰色地带",
    sev: "high" as const,
    body: "NEXT_TASK.md 自述“one-shot candidate merge scripts”参与落地，且明令“不要重跑脚本，会覆盖已审过的修复”。这与 LibraryResonance 里那段恒真三元式互相印证：存在一批“脚本写过、人没再看第二眼”的代码。怀疑不是代码会错，而是**没人说得清哪几行从未被人读过**。",
    ev: "NEXT_TASK.md · mechanics/resonance/LibraryResonance.java:946",
  },
  {
    icon: GitBranch,
    title: "版本身份三层时间戳互相矛盾",
    sev: "medium" as const,
    body: "仓库名咬死 26.1.2-source，构建目标已是 26.3，协议频道是 26_3_revision_9，发布签 1.1.0，fabric.mod.json 又长段自述 26.1.2 进度同步。对下游整合包与国内搬运站而言，这套命名是不可检索的——怀疑作者把“版本考古”当成了分支管理。",
    ev: "gradle.properties · fabric.mod.json · EnchantingProtocol.java",
  },
  {
    icon: FileWarning,
    title: "“Unofficial port” 名不副实的授权叙事",
    sev: "medium" as const,
    body: "MIT 给了 fork 的正当性，描述里也写明“Not affiliated”。但沿用原名 + 原图标 + 原机制大幅魔改后，仍以 “port” 之名分发，分发页面上用户会自然以为这是官方续作。怀疑这不是法律问题，是信任预算问题。",
    ev: "fabric.mod.json · README.md · assets/*icon*",
  },
  {
    icon: TestTube2,
    title: "测试火力集中在最不容易出事的地方",
    sev: "high" as const,
    body: "经济与配置守恒测试 1,855 行（非常扎实），但 payload 解码 fuzz、仪式队列持久化、ScreenHandler 镜像漂移、Mixin 注入点存在性这四类事故高发区几乎没有对应的 property-based 测试。考试押题押在了自己最擅长的章节。",
    ev: "src/test/.../EconomyAndConfigVerificationTest.java(1,855 行) vs NetworkCompatibilityTest.java(174 行)",
  },
  {
    icon: Hourglass,
    title: "部分数值的“节拍惩罚”缺少实测锚点",
    sev: "medium" as const,
    body: "母本温养 7200s 无架基准 = 现实 2 小时：对单人档这是“明天再来”，对服务器是“睡一觉”。风化期望 17.8% 有 wiki 级推导背书（值得表扬），但等待类数值没有任何实测或问卷佐证——怀疑它们是“看起来合理”的数字，不是“玩过之后”的数字。",
    ev: "library_resonance.json: tome_regen_base_seconds=7200",
  },
  {
    icon: ToggleRight,
    title: "全局行为改写默认全开，是生态级偷袭",
    sev: "high" as const,
    body: "铁砧平摊、禁用同级合书、磨石行为、原版台拦截、村民 Infinity 交易消毒——五个默认开启的全局改写。单机用户受益，整合包作者遭殃：任何依赖原版铁砧惩罚曲线的整合包都会被静默改平衡。开关齐全，但默认值本身就是设计决策。",
    ev: "RemoveXpCostScaling.java · ChiseledEnchantingTable.java:sanitizeVillagerInfinityOffers",
  },
  {
    icon: ShieldAlert,
    title: "静态 per-player 状态没有生命周期纪律",
    sev: "medium" as const,
    body: "LAST_REOPEN_TICK 永不驱逐只是症状；病灶是没有一条“凡静态玩家表必须挂 DISCONNECT 清理”的项目级规则。今天漏 96 字节，明天漏的可能是一个玩家的仪式会话。",
    ev: "menu/ChiseledEnchantingTableScreenHandler.java:53",
  },
  {
    icon: BookMarked,
    title: "文档精度跑赢了代码精度",
    sev: "low" as const,
    body: "42KB 的 WIKI 精确到 17.8% 风化期望、42KB 的 CHANGELOG 逐条对应提交——但 TODO.md 里两个 🚧 与交付记录互相矛盾。文档体系内部的单一真源同样缺失。怀疑这个项目的文档工程师比代码洁癖更出色。",
    ev: "docs/WIKI.md ↔ TODO.md",
  },
];

const ADVICE = [
  {
    p: "P0",
    icon: Hammer,
    title: "先还债，再谈扩展",
    items: [
      "删除 epiphanyMaxSlots 的恒真三元式（return 0;），并全树 grep '== *0\\.0|>= *0\\.0 &&' 做一次生成残留专项清扫",
      "LAST_REOPEN_TICK 挂上 ServerPlayConnectionEvents.DISCONNECT 清理；把这条写成 CONTRIBUTING 规则而非一次性修复",
      "仪式等待权重 0.42 / 0.58 / 0.35 移出 private 常量，进 library_resonance.json 的 ritual 段",
    ],
  },
  {
    p: "P1",
    icon: Wrench,
    title: "消灭双真源，归还数据主权",
    items: [
      "构建期 codegen：从 12 张 JSON 生成 Java 的 DEFAULT 常量，让 JSON 成为唯一真源，consistency.yml 只做“生成物与仓库是否同步”检查",
      "磨损免疫从硬编码 minecraft:infinity 改为 #chiseled_enchanting_table:wear_immune 标签，默认数据包内含 infinity——第三方内容即刻平等受惠",
      "REVISION / MISMATCH_MESSAGE / 仓库 README 版本号集中到一处常量派生，升级版本只改一个文件",
    ],
  },
  {
    p: "P2",
    icon: FlaskConical,
    title: "把测试枪口对准事故高发区",
    items: [
      "为 PayloadLimits 全部解码路径加 property-based fuzz（随机字节流注入，断言“要么成功要么有界异常”）",
      "为 ScreenHandler 的 30+ 镜像字段写一个不变量测试：任意广播后，客户端可见值 ∈ 服务端真值的合法集合",
      "仪式队列持久化做崩溃回放测试：写一半 kill -9，重启后必须落入 quarantine 分支（server-smoke.log 已证明该分支存在）",
    ],
  },
  {
    p: "P3",
    icon: Eye,
    title: "把“port”与“overhaul”两个身份拆开",
    items: [
      "五处全局改写默认降级为“询问式默认”：首次开图弹一次配置页，或在新存档默认 off，老存档保持 on",
      "分发渠道更名或显著化 fork 身份（如 “Chiseled Enchanting Table: Resonance Fork”），与上游品牌解耦",
      "给 WIKI 的数字接 CI 锚定：40% / 17.8% / 38 架等 wiki 数字从 JSON/代码取值自动比对，文档漂移即失败",
    ],
  },
];

export function DoubtsPage() {
  return (
    <div className="page-enter">
      <header className="relative overflow-hidden px-6 pb-14 pt-32 md:pt-40">
        <div className="rune-grid absolute inset-0" />
        <div className="pointer-events-none absolute -top-32 left-1/2 h-[480px] w-[820px] -translate-x-1/2 rounded-full bg-gilt/10 blur-[140px]" />
        <div className="relative mx-auto max-w-6xl">
          <Reveal>
            <div className="flex flex-wrap items-center gap-3 font-mono text-[11px] tracking-widest text-ash">
              <span className="rounded-full border border-gilt/30 bg-gilt/10 px-3 py-1 text-gilt">HONEST DOUBTS</span>
              <span className="hidden sm:inline">怀疑要中肯 · 建议要可执行</span>
            </div>
          </Reveal>
          <Reveal delay={100}>
            <h1 className="mt-7 font-serifcn text-[13vw] font-black leading-[1.04] tracking-tight text-parch sm:text-7xl md:text-[80px]">
              怀疑那些<span className="text-shimmer">没人看第二眼</span>的地方
            </h1>
          </Reveal>
          <Reveal delay={200}>
            <p className="mt-7 max-w-2xl text-[14px] leading-relaxed text-ash">
              前两页的证据足够支撑一句公道话：这是一份水准之上的工程。正因为水准之上，批评才应该更苛刻——以下怀疑全部可以证伪，全部欢迎作者逐条打脸；建议全部可以直接开工。
            </p>
          </Reveal>
        </div>
      </header>

      {/* ================= 怀疑 ================= */}
      <section className="mx-auto max-w-6xl px-6 pb-16">
        <SectionHeading
          index="01"
          zh="八条中肯的怀疑"
          en="EIGHT HONEST DOUBTS"
          desc="排序依据不是严重程度，而是“被证伪的成本”——越靠前，作者越难用一句“这是 feature”挡回去。"
        />
        <div className="grid gap-4 md:grid-cols-2">
          {DOUBTS.map((d, i) => (
            <Reveal key={d.title} delay={i * 60}>
              <div className="panel group h-full rounded-2xl p-6">
                <div className="flex items-start justify-between gap-4">
                  <d.icon size={20} className="mt-0.5 shrink-0 text-gilt transition-transform duration-500 group-hover:rotate-6" strokeWidth={1.5} />
                  <Badge sev={d.sev}>怀疑 {String(i + 1).padStart(2, "0")}</Badge>
                </div>
                <h3 className="mt-4 font-serifcn text-lg font-bold text-parch">{d.title}</h3>
                <p className="mt-2.5 text-[12.5px] leading-relaxed text-parch/65">{d.body}</p>
                <div className="mt-4"><FileRef>{d.ev}</FileRef></div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ================= 建议 ================= */}
      <section className="mx-auto max-w-6xl px-6 py-10 md:py-16">
        <SectionHeading
          index="02"
          zh="四条可立即开工的建议"
          en="ACTIONABLE ADVICE"
          desc="按优先级 P0→P3 排布：P0 是本周末就该进 main 的，P3 是下一个大版本的品牌工程。"
        />
        <div className="space-y-4">
          {ADVICE.map((a, i) => (
            <Reveal key={a.p} delay={i * 70}>
              <div className="panel overflow-hidden rounded-2xl">
                <div className="grid md:grid-cols-[220px_1fr]">
                  <div className="flex items-center gap-4 border-b border-edge/60 bg-ink/60 px-6 py-5 md:border-b-0 md:border-r">
                    <span className="font-display text-2xl font-semibold text-arcane-bright">{a.p}</span>
                    <div>
                      <a.icon size={16} className="text-arcane" strokeWidth={1.5} />
                      <div className="mt-1.5 text-[13px] font-semibold text-parch">{a.title}</div>
                    </div>
                  </div>
                  <ul className="space-y-2.5 px-6 py-5">
                    {a.items.map((it, j) => (
                      <li key={j} className="flex gap-3 text-[13px] leading-relaxed text-parch/70">
                        <span className="mt-0.5 shrink-0 font-mono text-[10px] text-arcane">{a.p}.{j + 1}</span>
                        {it}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ================= 收尾 ================= */}
      <section className="mx-auto max-w-6xl px-6 pb-24">
        <Reveal>
          <Callout icon={<Eye size={15} className="text-arcane-bright" />} tone="arcane" title="最后一句公道话">
            这个仓库最值得警惕的缺陷，和最值得赞扬的品质，是同一件事的两面：它用极高的纪律写出了 40+ 条自审标签、有界解码、服务端权威与守恒经济学——<strong className="text-parch">又用同一份自信，把一部分“已交付”的代码关进了人眼不再复查的抽屉</strong>。上限之于增益如此，人审之于生成物也如此：没有第二双眼睛，任何收益都会在某处悄悄冲出封顶。
          </Callout>
        </Reveal>
      </section>
    </div>
  );
}
