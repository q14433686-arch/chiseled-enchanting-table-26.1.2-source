import { useEffect, useMemo, useRef, useState } from "react";
import { Badge } from "./chrome";

/* =====================================================================
   Faithful JS ports of the mod's formulas (see BookshelfProgression /
   LibraryResonance). Kept intentionally identical to the Java logic.
   ===================================================================== */

/** BookshelfProgression.requiredBookshelvesForDirectTier, cap=38, gamma=1.25 */
export function requiredShelves(targetLevel: number, maxLevel: number, cap = 38, exp = 1.25): number {
  const safeMax = Math.max(1, maxLevel);
  const safeTarget = Math.max(1, Math.min(safeMax, targetLevel));
  const c = Math.max(1, cap);
  if (safeMax <= 1 || safeTarget <= 1) return 0;
  if (safeTarget >= safeMax) return c;
  const e = Number.isFinite(exp) ? Math.max(0.5, exp) : 1.25;
  const progress = (safeTarget - 1) / (safeMax - 1);
  const raw = Math.floor(c * Math.pow(progress, e) + 0.5);
  if (safeMax > c + 1) return Math.max(1, Math.min(c - 1, raw));
  const minAllowed = Math.min(c - 1, safeTarget - 1);
  const maxAllowed = Math.max(1, c - (safeMax - safeTarget));
  return Math.max(Math.min(minAllowed, maxAllowed), Math.min(raw, maxAllowed));
}

/** LibraryResonance.woodenBookshelfDiscountPercent (defaults) */
export function woodenDiscount(shelves: number): number {
  const MIN = 12, MAX = 38, CAP = 15;
  if (shelves < MIN) return 0;
  const clamped = Math.min(MAX, shelves);
  const span = Math.max(1, MAX - MIN);
  const progress = (clamped - MIN) / span;
  return Math.min(CAP, Math.max(1, Math.round(1 + Math.max(0, CAP - 1) * progress)));
}
/** globalMasteryDiscountPercent, multiplier 1.25, cap 20 */
export function masteryDiscount(units: number): number {
  if (units <= 0) return 0;
  return Math.min(20, Math.floor(units * 1.25));
}
/** baseXpDiscountPercent (cap 35) */
export function baseDiscount(shelves: number, units: number): number {
  return Math.min(35, woodenDiscount(shelves) + masteryDiscount(units));
}
/** specificEnchantmentDiscountBonus, exponent 1.0, cap 15 */
export function specificBonus(stored: number, max: number): number {
  const r = Math.max(0, Math.min(1, max > 0 ? stored / Math.max(1, max) : 0));
  if (r <= 0) return 0;
  return Math.min(15, Math.round(15 * Math.pow(r, 1.0)));
}
/** effectiveXpDiscountPercent — the hard 40% ceiling */
export function totalDiscount(shelves: number, units: number, stored: number, max: number): number {
  return Math.min(40, baseDiscount(shelves, units) + specificBonus(stored, max));
}

/* =====================================================================
   Discount simulator
   ===================================================================== */

function Row({ label, hint, pct, cap, color }: { label: string; hint: string; pct: number; cap: number; color: string }) {
  const hit = pct >= cap;
  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between gap-3">
        <span className="text-[12px] font-medium text-parch/80">{label}</span>
        <span className="font-mono text-[11px] text-ash">
          <span style={{ color }}>-{pct}%</span> <span className="text-ash/60">/ 上限 {cap}%</span>
        </span>
      </div>
      <div className="relative h-2 overflow-hidden rounded-full bg-edge/60">
        <div
          className="absolute inset-y-0 left-0 rounded-full transition-all duration-500 ease-out"
          style={{ width: `${Math.min(100, (pct / cap) * 100)}%`, background: color, boxShadow: `0 0 12px ${color}` }}
        />
      </div>
      <div className="mt-1 flex items-center justify-between">
        <span className="text-[10.5px] text-ash/70">{hint}</span>
        {hit && <Badge sev="high">已封顶</Badge>}
      </div>
    </div>
  );
}

export function DiscountSimulator() {
  const [shelves, setShelves] = useState(38);
  const [units, setUnits] = useState(16);
  const [stored, setStored] = useState(5);
  const maxLvl = 5;

  const wood = woodenDiscount(shelves);
  const mast = masteryDiscount(units);
  const base = baseDiscount(shelves, units);
  const spec = specificBonus(stored, maxLvl);
  const total = totalDiscount(shelves, units, stored, maxLvl);
  const naive = wood + mast + spec;
  const clipped = naive - total;

  const slider = (v: number, max: number) => ({ "--fill": `${(v / max) * 100}%` } as React.CSSProperties);

  return (
    <div className="panel rounded-2xl p-6 md:p-8">
      <div className="grid gap-8 lg:grid-cols-[1.1fr_1fr]">
        <div className="space-y-7">
          <div>
            <div className="mb-2 flex items-baseline justify-between">
              <label className="text-[13px] font-semibold text-parch">普通书架数量</label>
              <span className="font-mono text-xl text-arcane-bright">{shelves}</span>
            </div>
            <input type="range" min={0} max={48} value={shelves} onChange={(e) => setShelves(+e.target.value)} className="w-full" style={slider(shelves, 48)} />
            <p className="mt-1.5 text-[11px] text-ash">12 架起生效 · 38 架写满木质减免（超出的书架不再提供这项加成）</p>
          </div>
          <div>
            <div className="mb-2 flex items-baseline justify-between">
              <label className="text-[13px] font-semibold text-parch">雕纹总藏书·精通单位</label>
              <span className="font-mono text-xl text-xp">{units}</span>
            </div>
            <input type="range" min={0} max={24} value={units} onChange={(e) => setUnits(+e.target.value)} className="w-full" style={slider(units, 24)} />
            <p className="mt-1.5 text-[11px] text-ash">units = Σ(藏书等级/满级)^1.25 · ×1.25 向下取整</p>
          </div>
          <div>
            <div className="mb-2 flex items-baseline justify-between">
              <label className="text-[13px] font-semibold text-parch">同种藏书等级（目标附魔，满级 5）</label>
              <span className="font-mono text-xl text-lapis">{stored}</span>
            </div>
            <input type="range" min={0} max={5} value={stored} onChange={(e) => setStored(+e.target.value)} className="w-full" style={slider(stored, 5)} />
            <p className="mt-1.5 text-[11px] text-ash">专精加成 = round(15% × 等级/满级)</p>
          </div>
        </div>

        <div className="space-y-5">
          <Row label="① 木书架减免" hint="1% + 14% × 进度" pct={wood} cap={15} color="#e8c268" />
          <Row label="② 藏书馆总精通减免" hint="floor(units × 1.25)" pct={mast} cap={20} color="#6ee7a0" />
          <Row label="③ 公共减免小计 = ① + ②" hint="封顶 35%（注意：可能已经在这里被截断）" pct={base} cap={35} color="#a78bfa" />
          <Row label="④ 同种藏书专精" hint="round(15% × 专精度)" pct={spec} cap={15} color="#6d8dff" />
          <div className="hairline border-t pt-5">
            <div className="flex items-end justify-between gap-4">
              <div>
                <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-ash">总经验减免（硬顶 40%）</div>
                <div className="mt-1 font-display text-5xl font-semibold text-shimmer">-{total}%</div>
              </div>
              {clipped > 0 ? (
                <div className="text-right">
                  <Badge sev="critical">截断 -{clipped}%</Badge>
                  <p className="mt-1.5 max-w-[210px] text-[11px] leading-relaxed text-ash">
                    名义 {naive}% 中有 <span className="text-blood">{clipped}%</span> 被两道上限蒸发 —— 继续堆书架在这项加成上收益为零。
                  </p>
                </div>
              ) : (
                <div className="max-w-[210px] text-right text-[11px] leading-relaxed text-ash">
                  尚未触及上限 —— 此刻增益仍在生效。
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* =====================================================================
   Tier-gate curve chart (canvas)
   ===================================================================== */

const CURVES = [
  { m: 5, label: "M=5（锋利/效率…）", color: "#a78bfa" },
  { m: 4, label: "M=4（保护…）", color: "#6ee7a0" },
  { m: 3, label: "M=3", color: "#6d8dff" },
  { m: 2, label: "M=2", color: "#e8c268" },
];

export function TierCurveChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [hover, setHover] = useState<{ m: number; tier: number; x: number; y: number } | null>(null);
  const points = useMemo(
    () =>
      CURVES.map((c) => ({
        ...c,
        pts: Array.from({ length: c.m }, (_, i) => requiredShelves(i + 1, c.m)),
      })),
    []
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    const t0 = performance.now();

    const draw = (now: number) => {
      const anim = Math.min(1, (now - t0) / 1200);
      const ease = 1 - Math.pow(1 - anim, 3);
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const W = wrap.clientWidth;
      const H = Math.max(300, Math.floor(W * 0.52));
      if (canvas.width !== W * dpr || canvas.height !== H * dpr) {
        canvas.width = W * dpr;
        canvas.height = H * dpr;
        canvas.style.width = `${W}px`;
        canvas.style.height = `${H}px`;
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);

      const padL = 46, padR = 18, padT = 22, padB = 40;
      const plotW = W - padL - padR, plotH = H - padT - padB;
      const xOf = (t: number) => padL + ((t - 1) / 4) * plotW;
      const yOf = (s: number) => padT + plotH * (1 - s / 40);

      // grid
      ctx.strokeStyle = "rgba(139,92,246,0.10)";
      ctx.lineWidth = 1;
      ctx.font = "10px JetBrains Mono, monospace";
      ctx.fillStyle = "rgba(141,137,163,0.8)";
      for (let s = 0; s <= 40; s += 10) {
        const y = yOf(s);
        ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
        ctx.fillText(String(s), 14, y + 3);
      }
      for (let t = 1; t <= 5; t++) {
        const x = xOf(t);
        ctx.beginPath(); ctx.moveTo(x, padT); ctx.lineTo(x, H - padB); ctx.stroke();
        ctx.fillText(`直附 ${t} 级`, x - 16, H - padB + 18);
      }
      // milestone guides
      ctx.setLineDash([5, 5]);
      ctx.strokeStyle = "rgba(232,194,104,0.45)";
      [12, 32, 38].forEach((s, i) => {
        const y = yOf(s);
        ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
        ctx.fillStyle = "rgba(232,194,104,0.85)";
        ctx.fillText(i === 2 ? "38 架 = 满级闸门" : `${s} 架里程碑`, W - padR - 108, y - 5);
      });
      ctx.setLineDash([]);

      // blank-book ceiling band (⌈M/2⌉ for M=5 → tier 3 → 16 shelves… draw region above tier3 line)
      points.forEach((c) => {
        ctx.strokeStyle = c.color;
        ctx.lineWidth = 2.2;
        ctx.shadowColor = c.color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        c.pts.forEach((s, i) => {
          const x = xOf(i + 1);
          const y = yOf(s * ease);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        });
        ctx.stroke();
        ctx.shadowBlur = 0;
        c.pts.forEach((s, i) => {
          const x = xOf(i + 1), y = yOf(s * ease);
          ctx.beginPath();
          ctx.arc(x, y, hover && hover.m === c.m && hover.tier === i + 1 ? 6 : 4, 0, Math.PI * 2);
          ctx.fillStyle = "#0d0c18";
          ctx.fill();
          ctx.strokeStyle = c.color;
          ctx.lineWidth = 2;
          ctx.stroke();
        });
      });

      if (anim < 1) raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    const ro = new ResizeObserver(() => { raf = requestAnimationFrame(draw); });
    ro.observe(wrap);
    return () => { cancelAnimationFrame(raf); ro.disconnect(); };
  }, [points, hover]);

  const onMove = (e: React.MouseEvent) => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const rect = wrap.getBoundingClientRect();
    const W = rect.width;
    const H = Math.max(300, Math.floor(W * 0.52));
    const padL = 46, padR = 18, padT = 22, padB = 40;
    const plotW = W - padL - padR, plotH = H - padT - padB;
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    let best: { m: number; tier: number; x: number; y: number } | null = null;
    let bd = 400; // 20px radius
    points.forEach((c) =>
      c.pts.forEach((s, i) => {
        const x = padL + ((i + 1 - 1) / 4) * plotW;
        const y = padT + plotH * (1 - s / 40);
        const d = (x - mx) ** 2 + (y - my) ** 2;
        if (d < bd) { bd = d; best = { m: c.m, tier: i + 1, x, y }; }
      })
    );
    setHover(best);
  };

  const hoverPt = hover ? points.find((p) => p.m === hover.m) : null;
  const hoverShelves = hover && hoverPt ? hoverPt.pts[hover.tier - 1] : 0;

  return (
    <div className="panel rounded-2xl p-6 md:p-8">
      <div className="mb-5 flex flex-wrap items-center gap-x-6 gap-y-2">
        {CURVES.map((c) => (
          <span key={c.m} className="flex items-center gap-2 font-mono text-[11px] text-ash">
            <span className="h-2 w-4 rounded-full" style={{ background: c.color }} /> {c.label}
          </span>
        ))}
        <span className="ml-auto font-mono text-[10px] uppercase tracking-widest text-ash/70">gamma = 1.25 · cap = 38</span>
      </div>
      <div ref={wrapRef} className="relative" onMouseMove={onMove} onMouseLeave={() => setHover(null)}>
        <canvas ref={canvasRef} className="block" />
        {hover && (
          <div
            className="pointer-events-none absolute z-10 -translate-x-1/2 rounded-lg border border-edge bg-ink/95 px-3 py-2 text-center shadow-xl"
            style={{ left: Math.min(Math.max(hover.x, 90), (wrapRef.current?.clientWidth ?? 300) - 90), top: Math.max(hover.y - 64, 4) }}
          >
            <div className="font-mono text-[10px] uppercase tracking-widest text-ash">M={hover.m} · 直附 {hover.tier} 级</div>
            <div className="font-display text-lg font-semibold text-arcane-bright">
              {hoverShelves} <span className="text-xs font-normal text-ash">书架</span>
            </div>
          </div>
        )}
      </div>
      <p className="mt-4 text-[12px] leading-relaxed text-ash">
        黄色虚线是三条里程碑：<span className="text-gilt">12 架</span>（木质减免起算 / 残卷免经验修复）、<span className="text-gilt">32 架</span>（解锁宝藏顿悟 / 材料减半）、<span className="text-gilt">38 架</span>（直附升满级闸门）。
        注意高等级区间的斜率陡增 —— 曲线的形状本身就是"前几级便宜、冲顶昂贵"的宣言。
      </p>
    </div>
  );
}
