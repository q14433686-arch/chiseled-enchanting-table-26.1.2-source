import { useEffect, useRef, useState, type ReactNode } from "react";
import { clsx } from "clsx";

/* ---------------- Reveal on scroll ---------------- */
export function Reveal({ children, delay = 0, className }: { children: ReactNode; delay?: number; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            setVisible(true);
            io.disconnect();
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -40px 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={clsx("reveal", visible && "is-visible", className)} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

/* ---------------- tiny java syntax highlighter ---------------- */
const JAVA_RE = /(\/\/.*)|(\/\*\*?[\s\S]*?\*\/)|("(?:[^"\\]|\\.)*")|(@\w+)|\b(public|private|protected|static|final|void|int|long|double|boolean|return|if|else|for|while|new|class|record|enum|extends|implements|this|super|null|true|false|var|switch|case|break|import|package|abstract|throw|throws|try|catch|finally|instanceof)\b|\b(\d[\d_]*(?:\.\d+)?[dDlLfF]?)\b|\b([A-Z][A-Za-z0-9_]*)\b|(\w+)(?=\s*\()/g;

export function highlightJava(code: string): ReactNode[] {
  const out: ReactNode[] = [];
  let last = 0;
  let key = 0;
  for (const m of code.matchAll(JAVA_RE)) {
    const idx = m.index ?? 0;
    if (idx > last) out.push(code.slice(last, idx));
    const [full, line, block, str, ann, kw, num, type, fn] = m;
    if (line || block) out.push(<span key={key++} className="tok-com">{full}</span>);
    else if (str) out.push(<span key={key++} className="tok-str">{full}</span>);
    else if (ann) out.push(<span key={key++} className="tok-ann">{full}</span>);
    else if (kw) out.push(<span key={key++} className="tok-kw">{full}</span>);
    else if (num) out.push(<span key={key++} className="tok-num">{full}</span>);
    else if (type) out.push(<span key={key++} className="tok-type">{full}</span>);
    else if (fn) out.push(<span key={key++} className="tok-fn">{full}</span>);
    last = idx + full.length;
  }
  if (last < code.length) out.push(code.slice(last));
  return out;
}

export function CodeBlock({ code, title, badge }: { code: string; title?: string; badge?: string }) {
  return (
    <div className="overflow-hidden rounded-xl border border-edge bg-[#0a0916]">
      {(title || badge) && (
        <div className="flex items-center justify-between gap-3 border-b border-edge/70 px-4 py-2">
          <span className="truncate font-mono text-[11px] tracking-wide text-ash">{title}</span>
          {badge && (
            <span className="shrink-0 rounded-full border border-arcane/30 bg-arcane/10 px-2 py-0.5 font-mono text-[10px] uppercase tracking-widest text-arcane-bright">
              {badge}
            </span>
          )}
        </div>
      )}
      <pre className="codeblock overflow-x-auto p-4 text-parch/85">
        <code>{highlightJava(code)}</code>
      </pre>
    </div>
  );
}

/* ---------------- badge ---------------- */
export type Sev = "critical" | "high" | "medium" | "low" | "good";
const SEV_STYLE: Record<Sev, string> = {
  critical: "border-blood/50 bg-blood/15 text-blood",
  high: "border-gilt/50 bg-gilt/15 text-gilt",
  medium: "border-lapis/50 bg-lapis/15 text-lapis",
  low: "border-xp/40 bg-xp/10 text-xp",
  good: "border-arcane/50 bg-arcane/15 text-arcane-bright",
};
export function Badge({ sev, children }: { sev: Sev; children: ReactNode }) {
  return (
    <span className={clsx("inline-flex items-center gap-1 rounded-full border px-2 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-widest", SEV_STYLE[sev])}>
      {children}
    </span>
  );
}

/* ---------------- heading ---------------- */
export function SectionHeading({ index, zh, en, desc }: { index: string; zh: string; en: string; desc?: string }) {
  return (
    <Reveal className="mb-10">
      <div className="flex items-baseline gap-4">
        <span className="font-display text-sm font-light tracking-[0.35em] text-arcane">{index}</span>
        <span className="h-px flex-1 bg-gradient-to-r from-arcane/50 to-transparent" />
        <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-ash">{en}</span>
      </div>
      <h2 className="mt-4 font-serifcn text-3xl font-bold leading-tight text-parch md:text-5xl">{zh}</h2>
      {desc && <p className="mt-4 max-w-2xl text-sm leading-relaxed text-ash">{desc}</p>}
    </Reveal>
  );
}

/* ---------------- ticker number ---------------- */
export function Ticker({ value, decimals = 0, suffix = "" }: { value: number; decimals?: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [display, setDisplay] = useState(0);
  const started = useRef(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver((es) => {
      es.forEach((e) => {
        if (e.isIntersecting && !started.current) {
          started.current = true;
          const t0 = performance.now();
          const dur = 1400;
          const step = (t: number) => {
            const p = Math.min(1, (t - t0) / dur);
            setDisplay(value * (1 - Math.pow(1 - p, 4)));
            if (p < 1) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
          io.disconnect();
        }
      });
    });
    io.observe(el);
    return () => io.disconnect();
  }, [value]);
  return (
    <span ref={ref}>
      {display.toFixed(decimals)}
      {suffix}
    </span>
  );
}

/* ---------------- file ref chip ---------------- */
export function FileRef({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex max-w-full items-center gap-1.5 rounded-md border border-edge bg-ink px-2 py-0.5 font-mono text-[11px] text-lapis">
      <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-xp/80" />
      <span className="truncate">{children}</span>
    </span>
  );
}

/* ---------------- callout ---------------- */
export function Callout({ icon, tone = "arcane", title, children }: { icon?: ReactNode; tone?: "arcane" | "gilt" | "blood" | "xp"; title: string; children: ReactNode }) {
  const tones = {
    arcane: "border-arcane/30 bg-arcane/[0.07]",
    gilt: "border-gilt/30 bg-gilt/[0.07]",
    blood: "border-blood/30 bg-blood/[0.07]",
    xp: "border-xp/30 bg-xp/[0.06]",
  } as const;
  return (
    <div className={clsx("rounded-xl border p-5", tones[tone])}>
      <div className="flex items-center gap-2 text-sm font-semibold text-parch">
        {icon}
        {title}
      </div>
      <div className="mt-2 text-[13px] leading-relaxed text-parch/70">{children}</div>
    </div>
  );
}
