import { useState } from "react";
import { ShieldQuestion, Scale, AlertTriangle, Wrench, TrendingUp, Zap, CircleDot } from "lucide-react";
import { doubts, fairFirst, suggestions } from "../data/critique";
import { SectionHeading, TagBadge } from "../components/ui";
import { cn } from "../utils/cn";

const effortStyle: Record<string, string> = {
  低: "bg-emerald-400/10 text-emerald-300 ring-1 ring-inset ring-emerald-400/25",
  中: "bg-amber-400/10 text-amber-300 ring-1 ring-inset ring-amber-400/25",
  高: "bg-rose-400/10 text-rose-300 ring-1 ring-inset ring-rose-400/25",
};

export default function Critique() {
  const [tab, setTab] = useState<"doubts" | "suggestions">("doubts");

  return (
    <div className="mx-auto max-w-6xl px-5 pb-24 pt-10 md:px-8">
      <SectionHeading
        eyebrow="Critical Review"
        title="中肯的怀疑与建议"
        description="每一项怀疑都给出：主张（claim）→ 证据（evidence）→ 反方观点（counterpoint）→ 实际风险（risk）。列出反方观点不是为了和稀泥，而是因为这份移植的多数「问题」其实是「有意识的取舍」——怀疑的目的是让取舍的代价被看见，而非否定取舍本身。"
      />

      {/* Fair first */}
      <div className="mb-12 rounded-xl border border-emerald-400/20 bg-gradient-to-br from-emerald-400/5 to-transparent p-6 md:p-8">
        <h3 className="mb-4 flex items-center gap-2.5 font-serif text-xl font-semibold text-zinc-100">
          <ShieldQuestion className="h-5 w-5 text-emerald-300/80" />
          {fairFirst.title}
        </h3>
        <ul className="mb-5 space-y-2.5">
          {fairFirst.points.map((p, i) => (
            <li key={i} className="flex gap-3 text-[13.5px] leading-7 text-zinc-300">
              <CircleDot className="mt-1.5 h-3.5 w-3.5 shrink-0 text-emerald-400/60" />
              {p}
            </li>
          ))}
        </ul>
        <p className="rounded-lg border border-emerald-400/15 bg-emerald-400/5 p-3.5 text-[13px] leading-6 text-emerald-100/80">
          {fairFirst.conclusion}
        </p>
      </div>

      {/* Tabs */}
      <div className="mb-8 flex gap-2">
        <button
          onClick={() => setTab("doubts")}
          className={cn(
            "flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-medium transition-all",
            tab === "doubts" ? "bg-amber-400/15 text-amber-200 ring-1 ring-inset ring-amber-400/30" : "border border-zinc-700/70 text-zinc-400 hover:text-zinc-200"
          )}
        >
          <Scale className="h-4 w-4" />
          八项怀疑
        </button>
        <button
          onClick={() => setTab("suggestions")}
          className={cn(
            "flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-medium transition-all",
            tab === "suggestions" ? "bg-amber-400/15 text-amber-200 ring-1 ring-inset ring-amber-400/30" : "border border-zinc-700/70 text-zinc-400 hover:text-zinc-200"
          )}
        >
          <Wrench className="h-4 w-4" />
          十二项建议
        </button>
      </div>

      {tab === "doubts" ? (
        <div className="space-y-5">
          {doubts.map((d) => (
            <article
              key={d.id}
              className="rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-5 transition-colors hover:border-zinc-600/60 md:p-6"
            >
              <div className="mb-3 flex flex-wrap items-center gap-2.5">
                <span className="font-mono text-xs font-semibold text-amber-300/90">{d.id}</span>
                <TagBadge tone="purple">怀疑</TagBadge>
              </div>
              <h3 className="mb-5 text-[15.5px] font-semibold leading-snug text-zinc-100">{d.title}</h3>

              <div className="grid gap-3 md:grid-cols-2">
                <div className="rounded-lg border border-rose-400/15 bg-rose-400/5 p-4">
                  <div className="mb-1.5 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider text-rose-300/80">
                    <AlertTriangle className="h-3 w-3" /> 主张
                  </div>
                  <p className="text-[13px] leading-6 text-zinc-300">{d.claim}</p>
                </div>
                <div className="rounded-lg border border-zinc-700/50 bg-zinc-950/50 p-4">
                  <div className="mb-1.5 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider text-zinc-400">
                    证据
                  </div>
                  <p className="font-mono text-[12px] leading-6 text-zinc-400">{d.evidence}</p>
                </div>
                <div className="rounded-lg border border-sky-400/15 bg-sky-400/5 p-4">
                  <div className="mb-1.5 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider text-sky-300/80">
                    <Scale className="h-3 w-3" /> 反方观点
                  </div>
                  <p className="text-[13px] leading-6 text-zinc-300">{d.counterpoint}</p>
                </div>
                <div className="rounded-lg border border-amber-400/15 bg-amber-400/5 p-4">
                  <div className="mb-1.5 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider text-amber-300/80">
                    <TrendingUp className="h-3 w-3" /> 实际风险
                  </div>
                  <p className="text-[13px] leading-6 text-zinc-300">{d.risk}</p>
                </div>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <>
          {/* Priority matrix hint */}
          <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
            <div className="rounded-lg border border-zinc-800/80 bg-zinc-900/40 p-4">
              <div className="flex items-center gap-2 text-xs font-semibold text-zinc-200">
                <Zap className="h-3.5 w-3.5 text-amber-300" /> 低成本高回报
              </div>
              <div className="mt-2 text-[11px] leading-5 text-zinc-500">
                {suggestions.filter((s) => s.effort === "低" && s.impact === "高").map((s) => s.id).join(" · ")}
              </div>
            </div>
            <div className="rounded-lg border border-zinc-800/80 bg-zinc-900/40 p-4">
              <div className="text-xs font-semibold text-zinc-200">建议优先执行</div>
              <div className="mt-2 text-[11px] leading-5 text-zinc-500">
                {suggestions.filter((s) => s.effort === "中" && s.impact === "高").map((s) => s.id).join(" · ")}
              </div>
            </div>
            <div className="rounded-lg border border-zinc-800/80 bg-zinc-900/40 p-4">
              <div className="text-xs font-semibold text-zinc-200">长期投资</div>
              <div className="mt-2 text-[11px] leading-5 text-zinc-500">
                {suggestions.filter((s) => s.effort === "高").map((s) => s.id).join(" · ")}
              </div>
            </div>
            <div className="rounded-lg border border-zinc-800/80 bg-zinc-900/40 p-4">
              <div className="text-xs font-semibold text-zinc-200">随手修</div>
              <div className="mt-2 text-[11px] leading-5 text-zinc-500">
                {suggestions.filter((s) => s.impact === "低").map((s) => s.id).join(" · ")}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            {suggestions.map((s) => (
              <article
                key={s.id}
                className="rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-5 transition-colors hover:border-zinc-600/60"
              >
                <div className="mb-3 flex flex-wrap items-center gap-2.5">
                  <span className="font-mono text-xs font-semibold text-amber-300/90">{s.id}</span>
                  <span className={cn("rounded-full px-2.5 py-0.5 text-[11px] font-medium", effortStyle[s.effort])}>
                    成本 {s.effort}
                  </span>
                  <span className="rounded-full bg-violet-400/10 px-2.5 py-0.5 text-[11px] font-medium text-violet-300 ring-1 ring-inset ring-violet-400/25">
                    回报 {s.impact}
                  </span>
                  <div className="ml-auto flex gap-1.5">
                    {s.relates.map((r) => (
                      <TagBadge key={r}>{r}</TagBadge>
                    ))}
                  </div>
                </div>
                <h3 className="mb-2 text-[15px] font-semibold leading-snug text-zinc-100">{s.title}</h3>
                <p className="text-[13.5px] leading-7 text-zinc-300">{s.detail}</p>
              </article>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
