import { useMemo } from "react";
import { GitBranch, ScanSearch, FileCode2, ShieldCheck, Scale, AlertTriangle, ArrowRight } from "lucide-react";
import { auditPaths, balanceTopics, repoMeta, severityMeta, Severity } from "../data/audit";
import { textFindings } from "../data/textAudit";
import { doubts, suggestions } from "../data/critique";
import { SectionHeading, StatCard, TagBadge } from "../components/ui";

const severityOrder: Severity[] = ["critical", "high", "medium", "low", "info", "praise"];

export default function Overview({ onNavigate }: { onNavigate: (page: string) => void }) {
  const codeFindings = useMemo(() => auditPaths.flatMap((p) => p.findings), []);
  const severityCounts = useMemo(() => {
    const counts = new Map<Severity, number>();
    for (const f of codeFindings) counts.set(f.severity, (counts.get(f.severity) ?? 0) + 1);
    return counts;
  }, [codeFindings]);

  const textHigh = textFindings.filter((f) => f.severity === "high").length;
  const balanceDoubt = balanceTopics.filter((t) => t.verdict === "存疑" || t.verdict === "待验证").length;

  return (
    <div className="mx-auto max-w-6xl px-5 pb-24 pt-10 md:px-8">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-2xl border border-zinc-800/80 bg-gradient-to-br from-zinc-900/80 via-zinc-900/40 to-violet-950/20 p-8 md:p-12">
        <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-violet-500/10 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 -left-16 h-72 w-72 rounded-full bg-amber-500/8 blur-3xl" />
        <div className="relative">
          <div className="mb-5 flex flex-wrap items-center gap-2">
            <TagBadge tone="purple">源码审计报告</TagBadge>
            <TagBadge tone="gold">2026-10-25</TagBadge>
            <TagBadge>arena/b99a37c2 分支</TagBadge>
          </div>
          <h1 className="font-serif text-3xl font-bold leading-tight tracking-wide text-zinc-50 md:text-[2.75rem] md:leading-[1.2]">
            纂刻附魔台 26.1.2 移植版
            <br />
            <span className="bg-gradient-to-r from-amber-200 via-amber-300 to-violet-300 bg-clip-text text-transparent">
              全路径源码审计与文字质量评估
            </span>
          </h1>
          <p className="mt-5 max-w-3xl text-sm leading-7 text-zinc-400 md:text-[15px]">
            对 <span className="font-mono text-amber-200/90">{repoMeta.repo}</span>{" "}
            的一次全量审查：七条代码路径（源码 API、数据编解码、网络同步、GUI 输入、Mixin 注入、死代码、耦合风险）＋
            数值与机制设计合理性复算 ＋ 三轴文字质量审计（易读性 / 准确性 / 同一性）＋ 对项目现状的中肯怀疑与可执行建议。
          </p>
          <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <button
              onClick={() => onNavigate("audit")}
              className="group flex items-center justify-between rounded-lg border border-zinc-700/70 bg-zinc-900/60 px-4 py-3 text-left transition-all hover:border-amber-400/40 hover:bg-zinc-800/60"
            >
              <div>
                <div className="text-sm font-semibold text-zinc-100">代码审计</div>
                <div className="text-[11px] text-zinc-500">{codeFindings.length} 项发现 · 7 条路径</div>
              </div>
              <ArrowRight className="h-4 w-4 text-zinc-500 transition-transform group-hover:translate-x-0.5 group-hover:text-amber-300" />
            </button>
            <button
              onClick={() => onNavigate("text")}
              className="group flex items-center justify-between rounded-lg border border-zinc-700/70 bg-zinc-900/60 px-4 py-3 text-left transition-all hover:border-amber-400/40 hover:bg-zinc-800/60"
            >
              <div>
                <div className="text-sm font-semibold text-zinc-100">文字审计</div>
                <div className="text-[11px] text-zinc-500">{textFindings.length} 项 · 三轴评估</div>
              </div>
              <ArrowRight className="h-4 w-4 text-zinc-500 transition-transform group-hover:translate-x-0.5 group-hover:text-amber-300" />
            </button>
            <button
              onClick={() => onNavigate("critique")}
              className="group flex items-center justify-between rounded-lg border border-zinc-700/70 bg-zinc-900/60 px-4 py-3 text-left transition-all hover:border-amber-400/40 hover:bg-zinc-800/60"
            >
              <div>
                <div className="text-sm font-semibold text-zinc-100">怀疑与建议</div>
                <div className="text-[11px] text-zinc-500">{doubts.length} 问 + {suggestions.length} 策</div>
              </div>
              <ArrowRight className="h-4 w-4 text-zinc-500 transition-transform group-hover:translate-x-0.5 group-hover:text-amber-300" />
            </button>
            <div className="rounded-lg border border-zinc-800/60 bg-zinc-950/40 px-4 py-3">
              <div className="text-sm font-semibold text-zinc-400">审计范围</div>
              <div className="text-[11px] text-zinc-600">全源码 + 数据包 + 11 语言 + 4 层文档</div>
            </div>
          </div>
        </div>
      </section>

      {/* Meta */}
      <section className="mt-14">
        <SectionHeading eyebrow="Metadata" title="审计对象与方法" />
        <div className="grid gap-4 md:grid-cols-3">
          {[
            { icon: GitBranch, title: "仓库与分支", body: `${repoMeta.repo}\n分支 ${repoMeta.branch}` },
            { icon: FileCode2, title: "版本目标", body: `${repoMeta.target}\n模组版本 ${repoMeta.modVersion}\n上游 ${repoMeta.upstream}` },
            { icon: ScanSearch, title: "方法", body: repoMeta.method },
          ].map(({ icon: Icon, title, body }) => (
            <div key={title} className="rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-5">
              <div className="mb-3 flex items-center gap-2.5">
                <Icon className="h-4 w-4 text-amber-300/80" />
                <span className="text-sm font-semibold text-zinc-100">{title}</span>
              </div>
              <p className="whitespace-pre-line text-[12.5px] leading-6 text-zinc-400">{body}</p>
            </div>
          ))}
        </div>
        <div className="mt-4 rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-5">
          <div className="mb-2 flex items-center gap-2.5">
            <ShieldCheck className="h-4 w-4 text-amber-300/80" />
            <span className="text-sm font-semibold text-zinc-100">代码规模</span>
          </div>
          <p className="text-[12.5px] leading-6 text-zinc-400">{repoMeta.scope}</p>
        </div>
      </section>

      {/* Severity stats */}
      <section className="mt-14">
        <SectionHeading eyebrow="Statistics" title="发现分布" description="代码审计 23 项发现按严重度分布。无 Critical 级问题——这份移植的安全与健壮意识是扎实的；问题集中在结构与可维护性层。" />
        <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
          {severityOrder.map((sev) => {
            const count = severityCounts.get(sev) ?? 0;
            const meta = severityMeta[sev];
            return (
              <StatCard
                key={sev}
                value={String(count)}
                label={meta.label}
                accent={sev === "praise" ? "text-emerald-300" : undefined}
                sub={
                  sev === "high"
                    ? "ModMenu 接口复制、性能路径"
                    : sev === "medium"
                      ? "结构债与同步漂移温床"
                      : sev === "praise"
                        ? "超出社区平均的实践"
                        : undefined
                }
              />
            );
          })}
        </div>
        <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
          <StatCard value={String(textHigh)} label="文字高危发现" sub="zh_tw 双名分裂 · JEI 信息漂移 · README 数值矛盾" />
          <StatCard value={String(balanceDoubt)} label="数值存疑/待验证" sub="折扣可达性 · 顿悟上限 · 献祭边际成本" accent="text-yellow-200" />
          <StatCard value="33" label="格式符漂移" sub="11 语言 × 961 键扫描结果" accent="text-sky-300" />
          <StatCard value="4" label="文档事实矛盾" sub="README/WIKI/NEXT_TASK 交叉核对" accent="text-rose-300" />
        </div>
      </section>

      {/* Path overview */}
      <section className="mt-14">
        <SectionHeading eyebrow="Seven Paths" title="七条审计路径速览" />
        <div className="grid gap-4 md:grid-cols-2">
          {auditPaths.map((path) => {
            const counts = severityOrder.map(
              (s) => `${path.findings.filter((f) => f.severity === s).length}`
            );
            return (
              <button
                key={path.id}
                onClick={() => onNavigate("audit")}
                className="group rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-5 text-left transition-all hover:border-violet-400/40 hover:bg-zinc-900/70"
              >
                <div className="mb-2 flex items-center justify-between">
                  <span className="font-mono text-[10.5px] uppercase tracking-[0.2em] text-violet-300/70">{path.nameEn}</span>
                  <span className="font-mono text-[10.5px] text-zinc-600">{path.findings.length} findings</span>
                </div>
                <h3 className="mb-2 font-serif text-lg font-semibold text-zinc-100">{path.name}</h3>
                <p className="text-[12.5px] leading-6 text-zinc-400">{path.summary}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {severityOrder.map((s, i) =>
                    counts[i] !== "0" ? (
                      <span
                        key={s}
                        className={`rounded px-1.5 py-0.5 font-mono text-[10px] ${severityMeta[s].color}`}
                      >
                        {severityMeta[s].label} ×{counts[i]}
                      </span>
                    ) : null
                  )}
                </div>
              </button>
            );
          })}
          <div className="rounded-xl border border-amber-400/20 bg-gradient-to-br from-amber-400/5 to-violet-400/5 p-5">
            <div className="mb-2 flex items-center gap-2">
              <Scale className="h-4 w-4 text-amber-300/80" />
              <span className="font-mono text-[10.5px] uppercase tracking-[0.2em] text-amber-300/70">Balance</span>
            </div>
            <h3 className="mb-2 font-serif text-lg font-semibold text-zinc-100">数值与机制设计</h3>
            <p className="text-[12.5px] leading-6 text-zinc-400">
              gamma 曲线、XP 守恒、免磨损反漏洞体系复算全部吻合；折扣可达性、顿悟上限、献祭边际成本存在设计疑问。
            </p>
            <button
              onClick={() => onNavigate("audit")}
              className="mt-3 inline-flex items-center gap-1.5 text-xs font-medium text-amber-300 hover:text-amber-200"
            >
              查看全部 {balanceTopics.length} 个专题 <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* Top findings preview */}
      <section className="mt-14">
        <SectionHeading eyebrow="Highlights" title="最值得先看的六项发现" />
        <div className="grid gap-4 md:grid-cols-2">
          {[
            {
              id: "TA-01",
              tag: "文字",
              title: "zh_tw 同一文件两名并存：纂刻 ×32 vs 雕紋 ×13",
              body: "繁体玩家在游戏内同时看到「雕紋附魔台」方块与「纂刻附魔台」描述。",
            },
            {
              id: "TA-04",
              tag: "文字",
              title: "README「12+ 书架起减经验」与配置 3+ 直接矛盾",
              body: "三份文档（README/WIKI/JSON）中，玩家最先读的那份是错的。",
            },
            {
              id: "D-01",
              tag: "怀疑",
              title: "1.1.0 的文档跑在验证前面",
              body: "NEXT_TASK 自述「从未在真实客户端运行过」，README 却已全面宣传。",
            },
            {
              id: "BAL-02",
              tag: "数值",
              title: "−15% 折扣的 45 架上限可能实际放不下",
              body: "呼吸空间规则（每架 ≥6 开放邻格）与 7×5×7 体积约束下可达性存疑。",
            },
            {
              id: "NET-02",
              tag: "网络",
              title: "每秒为每个玩家全量重建置换显示",
              body: "O(players × transformations)/秒 的主线程路径，大型整合包下会痛。",
            },
            {
              id: "MIX-02",
              tag: "Mixin",
              title: "4 个 vanilla 热点方法的行为假设只被编译验证",
              body: "26.x 版本线快速迭代下，这是升级风险最高的一面。",
            },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => onNavigate(f.tag === "文字" ? "text" : f.tag === "怀疑" ? "critique" : "audit")}
              className="group flex gap-4 rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-5 text-left transition-all hover:border-amber-400/30 hover:bg-zinc-900/70"
            >
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-300/70" />
              <div>
                <div className="mb-1 flex items-center gap-2">
                  <span className="font-mono text-[10.5px] font-semibold text-amber-300/80">{f.id}</span>
                  <TagBadge>{f.tag}</TagBadge>
                </div>
                <h3 className="text-sm font-semibold leading-snug text-zinc-100">{f.title}</h3>
                <p className="mt-1.5 text-xs leading-5 text-zinc-500">{f.body}</p>
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
