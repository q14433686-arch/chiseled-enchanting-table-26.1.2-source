import { useState } from "react";
import { BookOpenCheck, Crosshair, GitCompareArrows, Quote, Lightbulb } from "lucide-react";
import { textFindings, textPrinciples, textVerdict } from "../data/textAudit";
import { CodeBlock, SectionHeading, TagBadge } from "../components/ui";
import { cn } from "../utils/cn";

const axisMeta = {
  readability: { label: "易读性", icon: BookOpenCheck, tone: "text-emerald-300", ring: "ring-emerald-400/25", bg: "bg-emerald-400/10" },
  accuracy: { label: "准确性", icon: Crosshair, tone: "text-amber-300", ring: "ring-amber-400/25", bg: "bg-amber-400/10" },
  consistency: { label: "同一性", icon: GitCompareArrows, tone: "text-violet-300", ring: "ring-violet-400/25", bg: "bg-violet-400/10" },
} as const;

const sevStyle: Record<string, string> = {
  high: "bg-rose-400/10 text-rose-300 ring-1 ring-inset ring-rose-400/25",
  medium: "bg-amber-400/10 text-amber-300 ring-1 ring-inset ring-amber-400/25",
  low: "bg-sky-400/10 text-sky-300 ring-1 ring-inset ring-sky-400/25",
  praise: "bg-emerald-400/10 text-emerald-300 ring-1 ring-inset ring-emerald-400/25",
};

export default function TextAudit() {
  const [axis, setAxis] = useState<"all" | keyof typeof axisMeta>("all");
  const filtered = axis === "all" ? textFindings : textFindings.filter((f) => f.axis === axis);
  const counts = {
    all: textFindings.length,
    readability: textFindings.filter((f) => f.axis === "readability").length,
    accuracy: textFindings.filter((f) => f.axis === "accuracy").length,
    consistency: textFindings.filter((f) => f.axis === "consistency").length,
  };

  return (
    <div className="mx-auto max-w-6xl px-5 pb-24 pt-10 md:px-8">
      <SectionHeading
        eyebrow="Text Quality Audit"
        title="文字的易读性、准确性与同一性"
        description="审计对象覆盖三个层面——说明（README / 发布页）、UI 内（11 语言 lang 文件、GUI 文案、纂刻秘典手册）、文档内（WIKI、NEXT_TASK、26 份报告）。方法：脚本化比对 961 键 × 11 语言的键集合与格式符；数值断言与 JSON 配置交叉验证；术语在简繁两版的分布统计。"
      />

      {/* Verdict cards */}
      <div className="mb-12 grid gap-4 md:grid-cols-3">
        {(Object.keys(axisMeta) as (keyof typeof axisMeta)[]).map((key) => {
          const meta = axisMeta[key];
          const v = textVerdict[key];
          return (
            <div key={key} className="rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-5">
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <meta.icon className={cn("h-4 w-4", meta.tone)} />
                  <span className="text-sm font-semibold text-zinc-100">{meta.label}</span>
                </div>
                <span className={cn("rounded-lg px-2.5 py-1 font-serif text-lg font-bold ring-1 ring-inset", meta.bg, meta.tone, meta.ring)}>
                  {v.score}
                </span>
              </div>
              <p className="text-[12.5px] leading-6 text-zinc-400">{v.note}</p>
            </div>
          );
        })}
      </div>

      {/* The core tension */}
      <div className="mb-12 rounded-xl border border-amber-400/20 bg-gradient-to-br from-amber-400/5 via-transparent to-violet-400/5 p-6 md:p-8">
        <h3 className="mb-3 flex items-center gap-2 font-serif text-xl font-semibold text-zinc-100">
          <Quote className="h-5 w-5 text-amber-300/80" />
          核心矛盾：易读性与同一性的张力
        </h3>
        <p className="max-w-4xl text-sm leading-7 text-zinc-300">
          这个项目的中文文案是<span className="text-emerald-300">母语级重写</span>而非直译——这是它易读性出色的原因，
          也正是它同一性失守的原因。当 zh_cn 为了口语化而丢掉 <span className="font-mono text-amber-200/90">%3$s</span>（顿悟 32 架阈值），
          或者为了简洁省略「同种书再 −15%」时，中文玩家与英文玩家在<span className="text-amber-200">同一个界面读到了不同的游戏</span>。
          解法不是退回直译，而是承认两类文本应当有不同的规则——详见下方发现 TA-02 与末尾方法论。
        </p>
      </div>

      {/* Axis filter */}
      <div className="mb-8 flex flex-wrap gap-2">
        {(["all", "readability", "accuracy", "consistency"] as const).map((key) => (
          <button
            key={key}
            onClick={() => setAxis(key)}
            className={cn(
              "rounded-lg px-4 py-2 text-[13px] font-medium transition-all",
              axis === key
                ? "bg-zinc-100 text-zinc-900"
                : "border border-zinc-700/70 text-zinc-400 hover:border-zinc-500 hover:text-zinc-200"
            )}
          >
            {key === "all" ? `全部 ${counts.all}` : `${axisMeta[key].label} ${counts[key]}`}
          </button>
        ))}
      </div>

      {/* Findings */}
      <div className="space-y-5">
        {filtered.map((f) => (
          <article
            key={f.id}
            className="rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-5 transition-colors hover:border-zinc-600/60"
          >
            <div className="mb-3 flex flex-wrap items-center gap-2.5">
              <span className="font-mono text-xs font-semibold text-amber-300/90">{f.id}</span>
              <span className={cn("rounded-full px-2.5 py-0.5 text-[11px] font-medium", sevStyle[f.severity])}>
                {f.severity === "high" ? "高危" : f.severity === "medium" ? "中危" : f.severity === "low" ? "低危" : "亮点"}
              </span>
              <TagBadge tone="purple">{axisMeta[f.axis].label}</TagBadge>
              <TagBadge>{f.source}</TagBadge>
            </div>
            <h3 className="mb-4 text-[15px] font-semibold leading-snug text-zinc-100">{f.title}</h3>

            {f.before && (
              <div className="mb-3">
                <div className="mb-1.5 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">
                  <span className="h-1 w-1 rounded-full bg-rose-400/70" /> 实录
                </div>
                <CodeBlock>{f.before}</CodeBlock>
              </div>
            )}

            {f.after && (
              <div className="mb-3">
                <div className="mb-1.5 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">
                  <span className="h-1 w-1 rounded-full bg-emerald-400/70" /> 建议改写
                </div>
                <CodeBlock>{f.after}</CodeBlock>
              </div>
            )}

            <p className="mb-3 text-[13.5px] leading-7 text-zinc-300">{f.detail}</p>

            <div className="rounded-lg border border-emerald-400/15 bg-emerald-400/5 p-3.5">
              <div className="mb-1 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider text-emerald-300/80">
                <span className="h-1 w-1 rounded-full bg-emerald-400/70" /> 处置
              </div>
              <p className="text-[13px] leading-6 text-emerald-100/80">{f.fix}</p>
            </div>
          </article>
        ))}
      </div>

      {/* Principles */}
      <div className="mt-20">
        <SectionHeading
          eyebrow="Methodology"
          title="系统性改进原则"
          description="单点修补解决不了结构问题。以下五条原则把文字质量从「靠人自觉」升级为「靠流程保障」——与本仓库已用代码证明过的 BundledDefaults 生成器模式一脉相承。"
        />
        <div className="grid gap-4 md:grid-cols-2">
          {textPrinciples.map((p, i) => (
            <div key={p.title} className="rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-5">
              <div className="mb-2 flex items-center gap-2.5">
                <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-400/10 font-mono text-xs font-bold text-amber-300 ring-1 ring-inset ring-amber-400/25">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <h3 className="text-sm font-semibold text-zinc-100">{p.title}</h3>
              </div>
              <p className="text-[12.5px] leading-6 text-zinc-400">{p.body}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 flex gap-4 rounded-xl border border-violet-400/20 bg-violet-400/5 p-6">
          <Lightbulb className="mt-0.5 h-5 w-5 shrink-0 text-violet-300/80" />
          <div>
            <h3 className="mb-1.5 text-sm font-semibold text-zinc-100">一句话总结</h3>
            <p className="text-[13.5px] leading-7 text-zinc-300">
              这个项目的文字工作已经赢下了「写得好看」；要赢下「写得一致」，需要的是把翻译键当作 API 来治理——
              参数签名（格式符）不可漂移、命名（术语）单一来源、文档数值由数据渲染。这三件事都有仓库内现成的成功先例可复制。
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
