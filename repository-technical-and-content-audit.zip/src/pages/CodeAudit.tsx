import { useState } from "react";
import * as Icons from "lucide-react";
import { auditPaths, balanceTopics } from "../data/audit";
import { CodeBlock, Field, FindingCard, SectionHeading, TagBadge } from "../components/ui";
import { cn } from "../utils/cn";

const verdictStyle: Record<string, string> = {
  合理: "bg-emerald-400/10 text-emerald-300 ring-1 ring-inset ring-emerald-400/25",
  存疑: "bg-amber-400/10 text-amber-300 ring-1 ring-inset ring-amber-400/25",
  待验证: "bg-sky-400/10 text-sky-300 ring-1 ring-inset ring-sky-400/25",
};

export default function CodeAudit() {
  const [active, setActive] = useState(auditPaths[0].id);
  const path = auditPaths.find((p) => p.id === active)!;

  return (
    <div className="mx-auto max-w-6xl px-5 pb-24 pt-10 md:px-8">
      <SectionHeading
        eyebrow="Code Audit"
        title="七条路径的源码审计"
        description="按「源码 API、数据编解码、网络同步、GUI 输入、Mixin 注入、死代码、耦合风险」七条路径组织，每条路径含证据定位、影响分析与修复建议。严重度含「亮点」级——好的实践同样值得记录与推广。"
      />

      {/* Path tabs */}
      <div className="sticky top-16 z-20 -mx-5 mb-8 border-b border-zinc-800/70 bg-zinc-950/85 px-5 py-3 backdrop-blur-md md:-mx-8 md:px-8">
        <div className="flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {auditPaths.map((p) => {
            const Icon = (Icons as any)[p.icon] ?? Icons.Circle;
            return (
              <button
                key={p.id}
                onClick={() => setActive(p.id)}
                className={cn(
                  "flex shrink-0 items-center gap-2 rounded-lg px-3.5 py-2 text-[13px] font-medium transition-all",
                  active === p.id
                    ? "bg-amber-400/15 text-amber-200 ring-1 ring-inset ring-amber-400/30"
                    : "text-zinc-400 hover:bg-zinc-800/60 hover:text-zinc-200"
                )}
              >
                <Icon className="h-3.5 w-3.5" />
                {p.name}
                <span className="font-mono text-[10px] text-zinc-500">{p.findings.length}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active path */}
      <div className="mb-8 rounded-xl border border-violet-400/20 bg-gradient-to-r from-violet-400/5 to-transparent p-5">
        <div className="mb-1 font-mono text-[10.5px] uppercase tracking-[0.2em] text-violet-300/70">{path.nameEn}</div>
        <p className="text-sm leading-7 text-zinc-300">{path.summary}</p>
      </div>

      <div className="space-y-5">
        {path.findings.map((f) => (
          <FindingCard key={f.id} id={f.id} severity={f.severity} title={f.title} location={f.location}>
            <Field label="证据">{f.evidence}</Field>
            <Field label="分析">{f.analysis}</Field>
            <Field label="建议">
              <span className="text-emerald-200/90">{f.recommendation}</span>
            </Field>
          </FindingCard>
        ))}
      </div>

      {/* Balance section */}
      <div className="mt-20">
        <SectionHeading
          eyebrow="Balance & Mechanics"
          title="数值与机制设计合理性"
          description="对关键公式与数值做独立复算（非转述文档），并评估设计意图。复算方法：按 shelf_gates.json / library_resonance.json / treasure_epiphany.json 的默认值代入 BookshelfProgression 与 XpCostConversion 的实际公式。"
        />

        <div className="space-y-5">
          {balanceTopics.map((t) => (
            <article
              key={t.id}
              className="rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-5 transition-colors hover:border-zinc-600/60"
            >
              <div className="mb-3 flex flex-wrap items-center gap-2.5">
                <span className="font-mono text-xs font-semibold text-amber-300/90">{t.id}</span>
                <span className={cn("rounded-full px-2.5 py-0.5 text-[11px] font-medium", verdictStyle[t.verdict])}>
                  {t.verdict}
                </span>
                <h3 className="text-[15px] font-semibold text-zinc-100">{t.title}</h3>
              </div>
              <p className="mb-3 text-[13.5px] leading-7 text-zinc-300">{t.detail}</p>
              <div className="mb-3 flex flex-wrap gap-1.5">
                {t.numbers.map((n) => (
                  <TagBadge key={n} tone="purple">
                    {n}
                  </TagBadge>
                ))}
              </div>
              <Field label="结论 / 建议">
                <span className={t.verdict === "合理" ? "text-emerald-200/90" : "text-amber-200/90"}>{t.suggestion}</span>
              </Field>
            </article>
          ))}
        </div>

        {/* Recalculation demo */}
        <div className="mt-10 rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-6">
          <h3 className="mb-3 font-serif text-lg font-semibold text-zinc-100">复算示例：gamma=1.25 曲线档位</h3>
          <p className="mb-4 text-[13px] leading-6 text-zinc-400">
            以 <span className="font-mono text-amber-200/90">W = round(38 · ((L−1)/(M−1))^1.25)</span> 独立复算（M = 最大等级，L = 目标等级），
            与 README 概念段、WIKI 3.1 节逐档比对：
          </p>
          <CodeBlock>{`M=5  锋利类:  I(0) → II(7) → III(16) → IV(27) → V(38)    ✓ README ✓ WIKI ✓ 代码
M=4  保护类:  I(0) → II(10) → III(23) → IV(38)               ✓ WIKI ✓ 代码
M=3  时运类:  I(0) → II(16) → III(38)                          ✓ WIKI ✓ 代码
M=2  击退类:  I(0) → II(22)  ← two_level_max_bookshelves=22    ✓ WIKI ✓ 代码
空白上限: HALF_CEIL → ⌈M/2⌉ (M=5 → 3 级)                       ✓ README ✓ 代码`}</CodeBlock>
          <p className="mt-3 text-xs leading-5 text-zinc-500">
            结论：本仓库数值文档可信度最高的部分。它证明「数值从数据渲染 + 公式注释」的模式可行——建议推广到折扣/顿悟/串扰等其余数值段落（见文字审计页 TA-04）。
          </p>
        </div>
      </div>
    </div>
  );
}
