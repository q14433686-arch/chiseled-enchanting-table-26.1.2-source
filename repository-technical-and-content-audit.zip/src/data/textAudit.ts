export interface TextFinding {
  id: string;
  axis: "readability" | "accuracy" | "consistency";
  source: "说明 (README/发布页)" | "UI 内 (lang/GUI/秘典)" | "文档内 (WIKI/任务清单/报告)";
  severity: "high" | "medium" | "low" | "praise";
  title: string;
  before: string;
  after?: string;
  detail: string;
  fix: string;
}

export const textVerdict = {
  readability: { score: "B+", note: "整体合格，中文文案明显经过母语润色，远高于社区模组平均水准；但句长与信息密度仍有优化空间" },
  accuracy: { score: "B−", note: "公式与数值大体可信（gamma 曲线三方复算吻合），但存在 4 处陈旧/矛盾断言，其中 1 处直接误导玩家" },
  consistency: { score: "C+", note: "同一性是最薄弱的一环：同语言双名、同键异义、33 处格式符漂移，且 CI 门只覆盖键名与 %s 数量" },
};

export const textFindings: TextFinding[] = [
  {
    id: "TA-01",
    axis: "consistency",
    source: "UI 内 (lang/GUI/秘典)",
    severity: "high",
    title: "zh_tw 同一文件内两名并存：「纂刻」×32 处 vs「雕紋」×13 处",
    before: "block.chiseled_enchanting_table.chiseled_enchanting_table = \"雕紋附魔台\"\njei.chiseled_enchanting_table.info.station_classic = \"纂刻附魔台（1.0.3 經典）：…\"",
    detail:
      "对 zh_tw.json 全量统计：含「纂刻」的键 32 个（含分类名、成就描述、JEI 信息页），含「雕紋附魔台」的键 13 个（含方块名本身）。繁体玩家在游戏内会同时看到「雕紋附魔台」方块与「纂刻附魔台」描述——同一语言、同一物件、两个名字。且 zh_cn 统一用「纂刻附魔台」，zh_tw 的方块名却用「雕紋附魔台」，简繁对同一 mod 采用了不同译名，跨区玩家搜索攻略时会割裂。",
    fix: "二选一批量替换：若尊重「chiseled = 雕紋」的既有方块名，则全文件统一为「雕紋附魔台」；若跟随 zh_cn 的「纂刻」品牌，则方块名与 13 处一并改「纂刻附魔台」。补一条 CI 检查：zh_cn 与 zh_tw 的 mod 专有名词表必须完全一致。",
  },
  {
    id: "TA-02",
    axis: "consistency",
    source: "UI 内 (lang/GUI/秘典)",
    severity: "high",
    title: "JEI station 信息页：同一 key 三种语言讲了三套内容（zh_cn 丢失 %3$s）",
    before:
      "en_us: \"…Wooden Bookshelves: Raise max upgrade tiers, cut XP costs & unlock Treasure Epiphany at %3$s+ shelves…\"\nzh_cn: \"自己挑附魔，不再看脸。\\n把附魔书放进附魔台周围 %1$s 的雕纹书架…（仅 %1$s %2$s 两个参数，无 %3$s）\"",
    detail:
      "zh_cn 版本为了口语化重写了整段：丢掉了 en 中「木质书架提升上限/开启宝藏顿悟（%3$s 架）」的整句，同时新增了 en 没有的「升级折抵差价」「退魔页全额退经验」两句。Java 对多余参数静默忽略，不崩溃——但中英文玩家从同一个界面读到的功能集合不同：中文玩家不知道顿悟存在，英文玩家不知道退差价存在。zh_tw 又是第三种取舍。这正是「易读性 vs 同一性」的教科书案例：润色越自由，信息漂移越大。",
    fix: "为「信息型 key」（数值、阈值、解锁条件类）定规则：允许调整语序与措辞，但参数集合与事实点必须逐项对齐（本例 zh_cn 必须补回顿悟句与 %3$s）。风味型 key（成就标题）才允许再创作。",
  },
  {
    id: "TA-03",
    axis: "consistency",
    source: "UI 内 (lang/GUI/秘典)",
    severity: "medium",
    title: "33 处格式符漂移：%n$s 位置参数与 %% 均不在 CI 校验范围",
    before:
      "en: \"Template Books: %s eq. full tomes -> +%s%% global (+up to 15%% per matching tome)\"\nzh_cn: \"雕纹藏书折合：%s 本满级书 → -%s%% 经验\"（丢失「同种额外 −15%」整句）",
    detail:
      "脚本比对 11 语言 × 961 键：33 处 en 与其它语言的占位符集合不一致（含 %1$s/%2$s/%3$s 位置参数缺失、%% 数量不等）。ci_static_checks.py 的 lang 门只校验「键集合一致 + %s 个数一致」（正则 (?<!%)%s），位置参数与转义百分号完全漏网。多数 %% 缺失无害（译文改写后确实不需要 % 字符），但像 chiseled_mastery 丢失「每本同种书再 −15%」这样的信息减损是实打实的。",
    fix: "扩展 ci_static_checks.py：对每个 key 提取 {位置参数集合, %%, %s, %d} 四元组，以 en_us 为基准全量比对，信息型 key 不等即 fail。这条门加上后，33 处漂移可一次清零。",
  },
  {
    id: "TA-04",
    axis: "accuracy",
    source: "说明 (README/发布页)",
    severity: "high",
    title: "README：「12+ 个书架才开始经验减免」与配置/ WIKI 直接矛盾（实为 3 个）",
    before:
      "README: \"grant XP reduction starting at 12+ shelves\"\nlibrary_resonance.json: \"min_discount_bookshelves\": 3\nWIKI 3.1: \"满 3 个起效、每约 3 架递增 1%、45 个满额 −15%\"",
    detail:
      "折扣公式 round(1% + 14%·clamp((W−3)/42)) 在 W=3 时即有 1%——WIKI 与配置一致，README 的「12+」是数值重调前的陈旧段落。README 是玩家接触的第一份文档（Modrinth/CurseForge 页面同源），错误阈值会直接误导建造决策（玩家以为要凑 12 架才开始，实际 3 架即生效）。三份文档中唯一错误的是最显眼的那份。",
    fix: "README 的数值段落改为由脚本从 library_resonance.json 渲染生成（复用 gen_bundled_defaults.py 思路），或至少在段落末尾标注「数值以 WIKI 与数据包为准」；短期先把 12+ 改为 3+。",
  },
  {
    id: "TA-05",
    axis: "accuracy",
    source: "文档内 (WIKI/任务清单/报告)",
    severity: "medium",
    title: "NEXT_TASK.md 断言「advancement 全部硬编码英文、无 lang key」与事实相反",
    before:
      "NEXT_TASK A.4: \"the display title/description in all eight files under data/.../advancement/ are still hardcoded English and no advancements.* key exists in any lang file\"\n实测: 29 个 advancement JSON 全部使用 {\"translate\": \"advancements.chiseled_enchanting_table.*\"}，11 个语言文件均含对应键。",
    detail:
      "该断言已过时（1.0.2 基线期的记录），但 NEXT_TASK.md 是贡献者的「下一步任务清单」——过时断言会让下一位贡献者去「修复」一个不存在的问题，或更糟：误以为翻译尚未开始而重做一遍。内部文档的事实性漂移比玩家文档更隐蔽，因为读者是开发者，会基于它行动。",
    fix: "为 NEXT_TASK.md 中的事实断言加日期戳（如「[2026-09-30 核实]」），并在每轮版本收尾时跑一次「断言复核」：凡是能用脚本验证的（key 是否存在、文件是否使用 translate）都写成 CI 检查而非散文。",
  },
  {
    id: "TA-06",
    axis: "consistency",
    source: "文档内 (WIKI/任务清单/报告)",
    severity: "low",
    title: "WIKI 章节编号漂移：## 10 之下挂着 ### 9.1 与 ### 9.2",
    before: "## 10. 游戏内可视化配置、JEI / REI 查询与数据包联动\n### 9.1 游戏内可视化规则配置（4 种打开方式…）\n### 9.2 JEI / REI 双向查询与底层数据包表",
    detail:
      "章节重排后小节编号未跟随（9.x 应为 10.x）。目录锚点、交叉引用（若有「见 9.1」）会指向错误位置。小问题，但它发生在一份 48KB、以「精确」为卖点的机制文档里，读者对编号连续性的预期会被打破。",
    fix: "写一个 10 行的标题编号 lint（解析 ## / ### 序列必须单调递增），挂进 ci_static_checks.py 的 docs 检查。",
  },
  {
    id: "TA-07",
    axis: "consistency",
    source: "说明 (README/发布页)",
    severity: "medium",
    title: "同一物件两个英文名：README 叫 Master Tomes，UI 叫 Template Books",
    before:
      "README 概念段: \"…turn stored Enchanted Books into permanent Master Tomes…\"\nen_us JEI: \"…Hold Enchanted Books as Template Books…\"\nzh_cn 两者统一译作「母本」",
    detail:
      "英文读者在 README 读到 Master Tome，进游戏看到 Template Book，JEI 信息页又两者混用，无法确定是否同一系统（中文反而因统一译「母本」而免疫）。跨文档术语不统一是最常见的「文档读得越多越困惑」来源。",
    fix: "建一份 TERMS.md 术语表（Master Tome / Template Book / Depleted Tome / Epiphany / Treasure Epiphany / Wild Book Wear × 11 语言），README 与 lang 统一取一个主名 + 首次出现处标注别名；CI 检查 en 文档中不再出现未收录别名。",
  },
  {
    id: "TA-08",
    axis: "readability",
    source: "UI 内 (lang/GUI/秘典)",
    severity: "low",
    title: "zh_cn 笔误：「任选一种任选材料」",
    before: "jei.chiseled_enchanting_table.tooltip.cost_synced = \"已同步服务器配置，任选一种任选材料即可\"",
    detail: "「任选」重复，「一种任选材料」语序不通。单处笔误，但该 tooltip 出现在 JEI 材料槽——高频可见位置。",
    fix: "改为「已同步服务器配置，任选一种材料即可」。顺手全量跑一次中文文本的重复词检查（bigram 重复检测可自动化）。",
  },
  {
    id: "TA-09",
    axis: "readability",
    source: "文档内 (WIKI/任务清单/报告)",
    severity: "medium",
    title: "WIKI 公式密度过高：玩家文档与设计文档未分层",
    before:
      "WIKI 3.1: \"$$W_req(L,M) = \\begin{cases} 0, & M\\le1 \\text{ 或 } L\\le1 \\\\ 22, & M=2 \\text{ 且 } L\\ge2 …\\end{cases}$$\n（同页还有 ΣL 承载、双曲渐近、telescoping 守恒等 10+ 个公式块）",
    detail:
      "数学上严谨且与代码吻合（本审计已复算），但玩家想问的是「我 20 个书架锋利能到几级」——需要解析分段幂函数。48KB 的 WIKI 中公式块超过 15 个，面向玩家的「表格 + 一句话结论」层缺失。README 概念段又过度营销化（三轨道/守恒验证/双向查询连用），两头都未真正服务「中等投入玩家」这个最大群体。",
    fix: "WIKI 每个公式块前加一行「人话版」结论（如「20 架 → 锋利 III：还差 16 架可 IV」），或提供「玩家页（查表）/设计页（公式）」双 tab；把常用档位做成速查表置顶。",
  },
  {
    id: "TA-10",
    axis: "readability",
    source: "文档内 (WIKI/任务清单/报告)",
    severity: "low",
    title: "文档语言矩阵不对称：英文读者只有 README，中文读者只有 WIKI",
    before: "README / CHANGELOG / CURRENT_BASELINE / NEXT_TASK：全英文\nWIKI（48KB 机制详解）：全中文",
    detail:
      "英文玩家拿不到机制细节（README 明确把深度内容指给 WIKI，但 WIKI 是中文），中文玩家拿不到变更历史与升级注意事项。docs/DOCUMENTATION_INDEX.md 列了 8 份文档但未标注语言与受众，两类读者各看一半。",
    fix: "最低成本：WIKI 加英文 TL;DR 章节（每节 3–5 行结论 + 速查表）；DOCUMENTATION_INDEX.md 每条目加「语言 / 受众 / 时效性」三列。",
  },
  {
    id: "TA-11",
    axis: "readability",
    source: "UI 内 (lang/GUI/秘典)",
    severity: "praise",
    title: "亮点：zh_cn 文案是母语级润色，秘典排版引擎自建光学居中",
    before:
      "zh_cn: \"自己挑附魔，不再看脸。\" / \"开启你的定向附魔之旅——告别看脸刷词条。\"\nGrimoireTextLayout: GLYPH_INK_HEIGHT=8.0f，注释含「True Multi-Line Optical Centering」「Wrap First, Never Crush to Ants」",
    detail:
      "zh_cn 明显经过完整的信息架构重写而非直译（口语化、分块、每块单一主题），成就标题也有本地化幽默感（「看腻紫色了，不如……」）。纂刻秘典（游戏内手册）甚至自建了排版引擎：单遍布局、显式 ARGB alpha、多行光学居中、禁止缩字——这种对可读性的工程投入在模组里极罕见。",
    fix: "保持。建议把 zh_cn 的重写方法论（信息型/风味型 key 分治）沉淀进 EXTENDING.md 的翻译章节，供后续语言扩展复用。",
  },
];

export const textPrinciples = [
  {
    title: "信息型与风味型 key 分治",
    body: "把 961 个键分成两类：信息型（数值、阈值、成本规则、解锁条件）禁止意译重写，参数集合与事实点逐项对齐 en_us；风味型（成就标题、彩蛋、lore）允许本地化再创作。当前 zh_cn 的高质量恰恰来自自由重写——问题不在重写，而在没有区分哪些能重写。",
  },
  {
    title: "术语表单一真相源",
    body: "建 TERMS.md：6–8 个核心术语 × 11 语言，Master Tome/Template Book/Depleted Tome/Epiphany 等全部收录。zh_tw 的双名分裂、en 的两名混用，本质都是「没有一张大家查得到的表」。",
  },
  {
    title: "数值从数据渲染，不手抄",
    body: "README/WIKI 中的数值段落应由脚本从 library_resonance.json / shelf_gates.json 渲染生成（BundledDefaults 已证明该模式可行），或至少加「以数据包为准」声明。12+ vs 3+ 的矛盾就是手抄的代价。",
  },
  {
    title: "CI 门覆盖到字符级",
    body: "现有 lang 门校验键集合与 %s 数量——把校验扩展到 {位置参数, %%, %d} 四元组比对，并加中文重复词检测、标题编号单调性检查。文字质量与代码质量一样，靠门禁不靠自觉。",
  },
  {
    title: "文档分层：玩家页 / 设计页",
    body: "玩家要速查表与人话结论，设计者要公式与守恒证明。两者都重要的项目应该物理分层（双 tab 或双文档），而不是把 LaTex 级公式堆给所有读者。",
  },
];
