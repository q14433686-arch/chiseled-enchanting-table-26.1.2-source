export type Severity = "critical" | "high" | "medium" | "low" | "info" | "praise";

export interface Finding {
  id: string;
  severity: Severity;
  title: string;
  location: string;
  evidence: string;
  analysis: string;
  recommendation: string;
}

export interface AuditPath {
  id: string;
  name: string;
  nameEn: string;
  icon: string;
  summary: string;
  findings: Finding[];
}

export const severityMeta: Record<Severity, { label: string; color: string; dot: string }> = {
  critical: { label: "严重", color: "text-rose-300 border-rose-400/30 bg-rose-400/10", dot: "bg-rose-400" },
  high: { label: "高危", color: "text-amber-300 border-amber-400/30 bg-amber-400/10", dot: "bg-amber-400" },
  medium: { label: "中危", color: "text-yellow-200 border-yellow-300/30 bg-yellow-300/10", dot: "bg-yellow-300" },
  low: { label: "低危", color: "text-sky-300 border-sky-400/30 bg-sky-400/10", dot: "bg-sky-400" },
  info: { label: "提示", color: "text-zinc-300 border-zinc-400/30 bg-zinc-400/10", dot: "bg-zinc-400" },
  praise: { label: "亮点", color: "text-emerald-300 border-emerald-400/30 bg-emerald-400/10", dot: "bg-emerald-400" },
};

export const repoMeta = {
  repo: "q14433686-arch/chiseled-enchanting-table-26.1.2-source",
  branch: "arena/b99a37c2-chiseled-enchanting-table-26-1",
  target: "Minecraft 26.1.2 · Fabric Loader ≥0.19.3 · Fabric API 0.151.0+26.1.2 · Java 25",
  modVersion: "1.1.0（非官方移植 SemVer）",
  upstream: "Sacramentix/chiseled-enchanting-table（MIT）",
  scope: "main + client 两个源码集共 90 个 Java 文件；ScreenHandler 3153 行 / Screen 2406 行 / ModRuntimeConfig 1887 行；11 语言 × 961 键；29 个 advancement JSON；14 个数据包 JSON；6 个测试类；CI 三工作流 + 离线静态门",
  method: "全量通读源码 + 数据包 JSON 交叉验证 + 语言文件脚本化比对（键 / 格式符 / 术语）+ 数值公式复算（gamma 曲线、折扣公式、XP 守恒）+ 文档一致性核对（README / WIKI / NEXT_TASK / CHANGELOG）",
};

export const auditPaths: AuditPath[] = [
  {
    id: "api",
    name: "源码 API",
    nameEn: "Source API",
    icon: "BookOpen",
    summary:
      "入口职责清晰、注册器分包、JEI/REI 为 compile-only 按需加载；但存在上游遗留的类名拼写错误扩散、超大聚合类、以及复制第三方接口进源码树的隐性维护风险。",
    findings: [
      {
        id: "API-01",
        severity: "low",
        title: "「Enchantement」法语拼写错误扩散至 7 个文件",
        location: "src/client/.../gui/EnchantementListWidget.java 等 7 处",
        evidence:
          "EnchantementListWidget（列表控件）、EnchantmentFinder、ItemTransformationApplication、EnchantmentApplication、EnchantingNetworking、ChiseledEnchantingTableScreenHandler 均引用该类型或同源拼法。",
        analysis:
          "上游作者为法语母语者，enchantement 是法语拼法。该名称不是 bug，但作为公开 API 面（client 源码集的公共类名）会持续误导贡献者，且搜索 \"Enchantment\" 时会漏掉这些文件。重命名是破坏性变更，但该类未发布独立 API，实际上只在本仓库内部使用。",
        recommendation:
          "在 2.0 或下一次协议 revision 更替时统一重命名为 EnchantmentListWidget；短期先在类 Javadoc 标注「名称为上游遗留拼写」。若保留，应在 CONTRIBUTING 中说明。",
      },
      {
        id: "API-02",
        severity: "medium",
        title: "ModMenu 接口被复制进源码树，API 演进零告警",
        location: "src/client/java/com/terraformersmc/modmenu/api/{ConfigScreenFactory,ModMenuApi}.java",
        evidence:
          "client 源码集直接携带 com.terraformersmc.modmenu.api 包的两个接口文件，ChiseledEnchantingModMenuPlugin 实现它们，build.gradle 中 ModMenu 为 compileOnly 或未声明。",
        analysis:
          "这是避免运行时硬依赖的常见技巧，但代价是：ModMenu 上游修改接口（加方法、改签名、迁包）时本仓库编译照常通过，只在玩家装了新版 ModMenu 的运行时才炸出 AbstractMethodError。该风险在 26.x 快节奏版本线上被放大。",
        recommendation:
          "两个方案择一：① 在 CI 增加一个「ModMenu 兼容矩阵」job，用真实 ModMenu jar 做 compileOnly 编译验证；② 在 EXTENDING.md 中登记所复制的接口版本与 upstream 变更检查清单，作为每次 MC 版本升级的固定动作。",
      },
      {
        id: "API-03",
        severity: "info",
        title: "3153 行 ScreenHandler 仍是核心 God Class",
        location: "src/main/.../menu/ChiseledEnchantingTableScreenHandler.java",
        evidence:
          "该类聚合：槽位定义与快速移动、XP 计算入口、仪式状态机、置换快照、DataSlot 位打包（16+15 位）、批次上限、书架扫描触发。2026-10-24 审计已拆出 EnchantingNetworking，但主体仍在。",
        analysis:
          "代码自身有大量审计注释（H-01/H-02/R-01/R-02 等），说明作者知道风险并逐步偿还。但当前任何机制改动（哪怕只改仪式等待曲线）都要动这个文件，merge 冲突面和回归面都最大。",
        recommendation:
          "继续沿既有方向拆分：RitualState、TransformationSnapshot、DataSlotPackaging 三块可各成一类；每拆一块补一条 NetworkCompatibilityTest 断言，保证行为不变。",
      },
      {
        id: "API-04",
        severity: "info",
        title: "配置系统体量约占主源码 15%",
        location: "config/ModRuntimeConfig.java(1887) + ConfigCatalog.java(1204) + rules/{RuleBook,RuntimeRules}",
        evidence: "合计约 3400 行纯配置代码，另加游戏内 7 大分类可视化配置 GUI 与数据包 JSON 双轨。",
        analysis:
          "运行时配置（config json + GUI）与数据包配置（library_resonance.json 等）是两套并行真相源，代码用 forAnvilSide()/effective() 在两者间切换。体量本身不是 bug，但对「改附魔台数值」这个需求而言，复杂度已接近企业级配置中心，普通整合包作者面对 3 个入口改同一个数值。",
        recommendation:
          "在 WIKI 增加一张「我想改 X 应该动哪个文件」决策表；长期考虑把 runtime config 收敛为 datapack 的薄覆盖层，只留一份 schema。",
      },
      {
        id: "API-05",
        severity: "praise",
        title: "村民交易清理采用不可变替换而非原地修改",
        location: "ChiseledEnchantingTable.sanitizeVillagerInfinityOffers",
        evidence:
          "克隆 result stack、新建 MerchantOffer 保留 uses/demand/xp/priceMultiplier/specialPriceDiff 后整体 set(i)，而非改写 offer.getResult()。",
        analysis:
          "注释标明这是 API-03 审计修复。避免了与其它 mod 在同一 offers 列表上的写冲突，是高质量兼容性实践。",
        recommendation: "保持；建议在 EXTENDING.md 中作为「与其它 mod 共享容器/列表」的推荐范式引用。",
      },
    ],
  },
  {
    id: "codec",
    name: "数据编解码",
    nameEn: "Data Codec",
    icon: "Binary",
    summary:
      "PayloadLimits 统一上限、解码全部非负钳制、BundledDefaults 由生成器从 JSON 渲染并 CI 字节级校验——防漂移设计出色；配置同步走 JSON-over-string 而非结构化编解码，单包体积接近 vanilla 上限。",
    findings: [
      {
        id: "CODEC-01",
        severity: "praise",
        title: "BundledDefaults：由脚本生成 + CI 字节级校验，消除双源漂移",
        location: "src/main/.../BundledDefaults.java + scripts/gen_bundled_defaults.py",
        evidence:
          "文件头注明 GENERATED，ci_static_checks.py 重新渲染并 diff，任何字节差异即失败。注释记载此前 Java DEFAULT 记录重复手打数字导致 P1 级漂移。",
        analysis:
          "把「数值默认值的唯一真相源」钉死在 JSON，是从流程上根治漂移的最佳实践，值得作为本仓库的模板推广到文档数值（见文字审计页 TA-05）。",
        recommendation: "保持；将同一机制推广到 README/WIKI 中的关键数值段落（见文字审计页建议）。",
      },
      {
        id: "CODEC-02",
        severity: "medium",
        title: "配置同步以三份 JSON 字符串单包传输，峰值约 590KB",
        location: "config/ModConfigNetworking.SyncRuntimeConfigPayload",
        evidence:
          "CODEC 依次 writeUtf(json, 262_144) + writeUtf(policyJson, 65_536) + writeUtf(effectiveJson, 262_144)，客户端 readUtf 后交给 Gson 解析。",
        analysis:
          "三段 UTF 字符串叠加接近 vanilla 1MB 自定义包上限；且 JSON 文本走字符串而非二进制 codec，体积约为结构化编码的 3–5 倍。当前有 250ms 节流（NET-03）缓解频率问题，但单包体积问题在大型数据包（overrides 表膨胀）时会显性化。",
        recommendation:
          "① 压缩：FriendlyByteBuf 可套 gzip（vanilla 自带 compression threshold 逻辑参考）；② 三份中 effectiveJson 可由客户端本地推导则不传；③ 若长期维护，改为结构化 codec 分字段同步。",
      },
      {
        id: "CODEC-03",
        severity: "low",
        title: "31-bit 仪式 tick 双半字同步存在瞬时撕裂窗口",
        location: "ChiseledEnchantingTableScreenHandler DataSlots 5..8",
        evidence:
          "剩余/总 tick 各拆 16 位低半字与 15 位高半字两个 DataSlot，两个包分别到达；客户端组装 syncedRitualRemainingTicks 时可能读到「新低字 + 旧高字」。",
        analysis:
          "数学上 16+15=31 位恰好覆盖非负 int，符号位永不使用——打包本身正确。撕裂窗口通常只造成一帧倒计时跳变（高字跨 65536 tick 边界时才可能错约 65536 tick，仪式上限 6000 tick 内高字恒为 0，实际风险极低）。属于防御性设计讨论而非可复现 bug。",
        recommendation:
          "若要绝对一致，可在两个半字间用「序号 + 重传」或把倒计时改为单 16 位秒数（当前 countdownSeconds 已是 16 位单槽，事实上已覆盖玩家可见信息，可考虑直接砍掉 tick 级双槽）。",
      },
      {
        id: "CODEC-04",
        severity: "praise",
        title: "解码侧统一非负钳制 + 集中上限",
        location: "menu/PayloadLimits.java + 各 payload read 路径",
        evidence:
          "MAX_COLLECTION_ENTRIES=65_536 / MAX_COST_OPTIONS=256 / MAX_TOTAL_COST_STACKS=131_072；所有 readVarInt 结果 Math.max(0, …)。",
        analysis:
          "类注释「never treat negative counts as empty」说明作者理解负数计数的经典攻击面。上限值选取也低于泛型集合极限，防止恶意包触发 OOM。",
        recommendation: "保持；建议在 PayloadLimits 补一条单元测试覆盖「负 count → 抛/拒绝」的明确行为。",
      },
    ],
  },
  {
    id: "net",
    name: "网络同步",
    nameEn: "Network Sync",
    icon: "Network",
    summary:
      "协议 revision 16 + Capability 双向握手、按玩家节流（apply 8/tick、action 6/tick、reopen 10t、config 250ms）、断线即清理；主要疑点是每秒全量置换重建的性能路径与 15 个 legacy probe 的无限累积。",
    findings: [
      {
        id: "NET-01",
        severity: "praise",
        title: "Capability 握手：堆叠数不匹配主动断连而非事后解码错",
        location: "EnchantingProtocol.Capability + EnchantCostSync JOIN 处理",
        evidence:
          "clientbound + serverbound 双注册；JOIN 时若 peer 有本 mod 的任一 cost 通道但没有当前 revision 通道，则以可翻译的 protocol_mismatch 消息断连；enchanted_book 堆叠数（boot 时固化）不一致也断连并提示修改 config。",
        analysis:
          "「先验证再解码」的顺序正确，避免了老版本包进入解码器后产生不可读的 raw decode error。断连消息走 translatable key + 英文 fallback，对 11 语言玩家友好。",
        recommendation: "保持。建议在 MISMATCH_MESSAGE 中附上当前 revision 常量值，便于玩家比对版本。",
      },
      {
        id: "NET-02",
        severity: "medium",
        title: "每 20 tick 为每个在线玩家全量重建置换显示并做深比较",
        location: "EnchantCostSync.END_SERVER_TICK 注册块",
        evidence:
          "每秒对每个玩家调用 buildTransformationDisplays(player)（遍历全部 item_transformations、解析成本选项），再与 WeakHashMap 中缓存做 equals，不等才推送。",
        analysis:
          "以「每秒每玩家一次全表构建 + 全表比较」换取变更检测。变换表随数据包增长（第三方附魔包注入后可能数百条）且多玩家服务器上这是 O(players × transformations) 的每秒开销，且发生在主线程。无 bug，但属于可预见的性能退化路径。",
        recommendation:
          "改为 dirty-flag：在 /reload、菜单打开、库存变化事件上置脏，END_SERVER_TICK 只对脏玩家重建；或把比较粒度降为内容哈希。",
      },
      {
        id: "NET-03",
        severity: "medium",
        title: "15 个 cost probe + 7 个 apply probe 常量只增不减，缺淘汰时间表",
        location: "EnchantingProtocol.LEGACY_COST_PROBES / LEGACY_APPLY_PROBES",
        evidence:
          "revision_1..15 全部保留为查询通道。注释说明政策：只要某版本「publicly shipped」就必须保留，否则老客户端 JOIN 时会收到 raw decode error。",
        analysis:
          "政策本身自洽（优雅降级优先），但没有任何「最老 N 版后允许退役」的量化规则，长远看这个列表将无限增长，且每个常量都要在 LEGACY_COST_PROBES 与独立字段两处维护（当前手工同步，存在漏加风险——revision_4 有独立常量 PREVIOUS_COST_TYPE，列表里却通过另一表达式加入，模式不一致）。",
        recommendation:
          "① 统一用循环生成常量数组，删除重复声明；② 写明政策如「保留最近 6 个公开发布版本」，超过即允许删除并在 CHANGELOG 标注 breaking。",
      },
      {
        id: "NET-04",
        severity: "low",
        title: "/reload 后关闭打开的菜单是正确但隐式的 UX 决策",
        location: "EnchantCostSync.END_DATA_PACK_RELOAD",
        evidence: "重载后对每个打开本菜单的玩家 player.closeContainer()，下次打开取新数据。",
        analysis:
          "注释解释了原因（菜单缓存了打开时的快照）。副作用是管理员在玩家附魔到一半时 /reload 会把所有人的界面关掉、输入槽物品退回。这是合理取舍但玩家侧无任何提示。",
        recommendation: "在 close 前给受影响玩家发一条可翻译的系统消息（如「配置已重载，请重新打开附魔台」）。",
      },
      {
        id: "NET-05",
        severity: "praise",
        title: "节流状态生命周期管理完整，无泄漏路径",
        location: "EnchantingNetworking / ModConfigNetworking / EnchantCostSync",
        evidence:
          "LAST_REOPEN_TICK、APPLY_BURST_STATE、ACTION_BURST_STATE、LAST_CONFIG_UPDATE_NANO 均注册 DISCONNECT 清理 + SERVER_STOPPED 全清；LAST_DISPLAYS 用 WeakHashMap。",
        analysis:
          "长期运行服务器不会累积每玩家条目。相比常见的「静态 Map 永不清」反模式，这里做对了。",
        recommendation: "保持；burst 计数用 (tick<<16)|count 打包进单个 Long 的手法也值得注释推广。",
      },
    ],
  },
  {
    id: "gui",
    name: "GUI 输入",
    nameEn: "GUI Input",
    icon: "MousePointerClick",
    summary:
      "服务端权威模型贯彻到位：所有 serverbound payload 经 containerMenu/stillValid/containerId 三重校验；批次上限钳制到堆叠上限；客户端伪造 DataSlot 被吸收。文字层面的问题见文字审计页。",
    findings: [
      {
        id: "GUI-01",
        severity: "praise",
        title: "全部 C2S 动作走「execute 后校验菜单身份」三重门",
        location: "EnchantingNetworking 各 receiver",
        evidence:
          "server.execute(() -> { 节流 → instanceof ChiseledEnchantingTableScreenHandler → payload.targets(menu.containerId) → menu.stillValid(player) → 才调用 menu 方法 })。",
        analysis:
          "防止了跨菜单重放（拿旧 containerId 对别的菜单发包）、断线竞态与伪造菜单类。reopen 路径还额外校验方块状态、BlockEntity 与旁观模式。",
        recommendation: "保持。建议把三重校验提为 receiver 工具方法，未来新增 payload 不易漏写。",
      },
      {
        id: "GUI-02",
        severity: "low",
        title: "批次上限对创造模式完全旁路",
        location: "ChiseledEnchantingTableScreenHandler.resolveTransformationBatchCount",
        evidence: "if (this.player.getAbilities().instabuild) return desired; —— 创造玩家可单批处理全部堆叠而不受 XP 门槛限制。",
        analysis:
          "与 vanilla 创造模式语义一致（创造不扣经验），且批处理本身上限已被 Math.min(maxCap, inputCount) 钳制到 maxStackSize（64）。真正的批处理数字源于数据包 depleted_base_batch_size=64。行为可接受，但生存/创造在 GUI 上显示相同「可批量」提示可能误导生存玩家以为也能一次 64。",
        recommendation:
          "在批量按钮 tooltip 上区分显示：创造模式标注「创造模式：不受经验限制」，生存模式显示实际 XP 上限折算的批次。",
      },
      {
        id: "GUI-03",
        severity: "info",
        title: "滚动位置 / 页签状态在 init 重建时手工保存恢复",
        location: "ChiseledEnchantingTableScreen.init / resize 路径",
        evidence: "savedScrollAmount / savedTabMode 在 init 前捕获，重建 scrollContainer 后恢复，且 setScrollAmount(Math.min(restoreScroll, maxScroll))。",
        analysis:
          "窗口缩放、配置 overlay 开合都会触发 init 重跑。当前实现正确（含 maxScroll 钳制），但状态机复杂度集中在 Screen 一处，页签可用性（CLEANSE 未解锁自动回落 INSCRIBE）也在此内联判断。",
        recommendation: "后续若再增页签，考虑提取 UiState 持久化对象，避免 init 内联逻辑继续膨胀。",
      },
      {
        id: "GUI-04",
        severity: "low",
        title: "TODO 中「UI 滚动条点击」未实现（上游遗留）",
        location: "TODO.md「handle Chiseled enchanting table ui scrollbar click」",
        evidence: "EnchantementListWidget 滚动主要靠滚轮与拖动，滚动条轨道点击行为未在代码中找到对应实现。",
        analysis:
          "可访问性问题：无法使用滚轮的玩家（触屏 / 辅助技术）难以长列表导航。上游 TODO 一直未勾选，本移植也未处理。",
        recommendation: "在 EnchantementListWidget 上补 scrollbar 轨道 mouseClicked→按比例跳转；属低成本高体验项。",
      },
    ],
  },
  {
    id: "mixin",
    name: "Mixin 注入",
    nameEn: "Mixin Injection",
    icon: "Syringe",
    summary:
      "8 个 mixin 全部带详尽注入理由（含「为什么是 HEAD 而不是 TAIL」级别的注释），已吸收 MX-04/M-07 教训改用 @WrapMethod+try/finally；风险集中在 26.x 版本线快速迭代下对 vanilla 内部行为的假设只靠编译验证。",
    findings: [
      {
        id: "MIX-01",
        severity: "praise",
        title: "注入点选择的理由全部文档化，含反例",
        location: "mixin/structure/LevelChunkPostProcessMixin.java 类注释",
        evidence:
          "注释解释了：为何不能在 worldgen 线程触碰 live level（历史死锁）、为何 HEAD 而非 TAIL（vanilla 在循环内 clear postProcessing 列表）、为何用 ProtoChunk.unpackOffsetCoordinates（编码非平凡 (y<<8)|(z<<4)|x）。",
        analysis:
          "这种「决策 + 反例 + 历史 bug 链接」的 mixin 注释是模组开发的范本。StructurePieceAccessor 也记录了不使用 @Invoker 时坐标错位的真实事故。",
        recommendation: "保持。建议把每个 mixin 的目标方法签名 + 行为假设汇总成 docs/MIXIN_UPGRADE_CHECKLIST.md，MC 小版本升级时逐条 re-check（当前信息散在各类注释里）。",
      },
      {
        id: "MIX-02",
        severity: "medium",
        title: "对 4 个 vanilla 热点方法的 @Inject 依赖行为细节而非仅签名",
        location: "AnvilMenu.createResult / EnchantmentMenu.getEnchantmentList / ReloadableServerRegistries.reload / ChiseledBookShelfBlock.randomTick",
        evidence:
          "RemoveEnchantMerge 在 createResult 前后操纵 inputSlots 计数；DisableBookEnchanting 对 getEnchantmentList 做可取消的 HEAD/RETURN 双注入；ReloadableServerRegistriesMixin 假设 reload 的 HEAD 早于 LOOT_TABLE 注册构建。",
        analysis:
          "compile-check 只能证明目标类与方法存在（NEXT_TASK A0 明言），不能证明 vanilla 26.1.3 不改内部调用顺序。尤其 createResult 的计数临时修改依赖「vanilla 不会缓存中间结果」这一假设。26.x 系列（Minecraft 新版本线）命名与内部结构变动频繁，这是整个仓库升级风险最高的面。",
        recommendation:
          "为每个 mixin 写一行「行为假设」注释（如：假设 createResult 每次重新计算 resultSlots[0]）；升级 MC 时跑专门的 mixin 冒烟测试服（NEXT_TASK A 部分已有清单，建议 CI 化为可选 nightly job）。",
      },
      {
        id: "MIX-03",
        severity: "low",
        title: "ThreadLocal 追踪 anvil 侧别是隐式跨方法状态",
        location: "mixin/anvil/RemoveXpCostScaling.CET_CLIENT_ANVIL_SIDE",
        evidence: "@WrapMethod createResult 时把 clientSide 写入静态 ThreadLocal，供深层调用读取，finally 恢复。",
        analysis:
          "实现正确（含嵌套恢复逻辑），但 ThreadLocal 是最难排查的隐式耦合形态之一：任何第三方 mod 在同线程穿插调用 anvil 逻辑时都会经过该状态。注释未说明为何无法通过参数传递——大概率是目标方法签名不可改。",
        recommendation:
          "补充注释说明「为什么必须 ThreadLocal」；若未来 vanilla 提供侧别查询 API（如 menu.player.level().isClientSide 已可获取），评估去除。",
      },
      {
        id: "MIX-04",
        severity: "praise",
        title: "锁定书抽取 fail-closed：容器默认方法路径也覆盖",
        location: "mixin/bookshelf/LockedBookContainerMixin",
        evidence:
          "@Inject removeItem(II) 之外，直接 @Override removeItemNoUpdate(int)——注释标明 MIXIN-02 审计：该方法是接口 default，@Inject 的 require=1 无法命中 class 字节码。",
        analysis:
          "对 mixin 注入目标的字节码形态（declared vs inherited default）有精确认知，堵住了「绕过 removeItem 直接拿书」的漏洞。同时合法抽取时清残留锁元数据。",
        recommendation: "保持；建议补一条集成测试：hopper 对锁定书的抽取路径。",
      },
    ],
  },
  {
    id: "dead",
    name: "死代码",
    nameEn: "Dead Code",
    icon: "Ghost",
    summary:
      "自我审计意识强（DEAD-03 有 probe 退役政策）；TODO.md 上游杂记与 NEXT_TASK.md 职责重叠；legacy probe 是「设计上必须活着的死代码」，应集中隔离并标注淘汰条件。",
    findings: [
      {
        id: "DEAD-01",
        severity: "low",
        title: "TODO.md 为上游遗留杂记，与 NEXT_TASK.md 职责重叠",
        location: "TODO.md（\"LIST OF THING!\"）",
        evidence:
          "含大量已完成勾选、未勾选的 \"setup translation\"（实际 11 语言已完成）、\"handle case book swap enchant level\"、拼写错误 fusioning；其中多项与 NEXT_TASK.md 重复或已被超越。",
        analysis:
          "两份任务清单并存会让新贡献者不知道哪份是真相。TODO.md 的历史价值在于记录上游意图，但作为「活文档」它在误导。",
        recommendation: "把 TODO.md 归档为 docs/upstream/TODO_ARCHIVE.md 并在开头声明「历史文件，不再维护，当前任务见 NEXT_TASK.md」。",
      },
      {
        id: "DEAD-02",
        severity: "info",
        title: "MISMATCH_MESSAGE 与 lang key 双源维护",
        location: "EnchantingProtocol.MISMATCH_MESSAGE / disconnect.chiseled_enchanting_table.protocol_mismatch",
        evidence: "Java 常量字符串与 lang 文件各持一份语义相同的文本，靠 translatableWithFallback 关联。",
        analysis:
          "fallback 机制使两者不一致时玩家仍能看到消息，属低危。但 11 个语言文件的该 key 若与英文 fallback 漂移，无 CI 校验（键存在≠内容同步）。",
        recommendation: "在 ci_static_checks 的 lang 检查中对 disconnect.* 这类「安全关键」键增加「非空且非逐字复制英文」的启发式提醒。",
      },
      {
        id: "DEAD-03",
        severity: "info",
        title: "协议 probe 常量在两个位置重复维护",
        location: "EnchantingProtocol：独立字段 PREVIOUS/REVISION_5..15 与 LEGACY_COST_PROBES 列表",
        evidence: "REVISION_5_COST_TYPE 等既作为独立 public 字段，又逐一加入 LEGACY_COST_PROBES；revision_1..3 只出现在列表里。两处手工保持同步。",
        analysis:
          "新增 revision 时需要同时改两处，漏改任何一处都会让 JOIN 检测遗漏某个旧版本（表现为老客户端 raw decode error 而非友好断连）。",
        recommendation: "收敛为单一数组（或由循环生成），独立字段仅保留最新一个；与 NET-03 一并处理。",
      },
    ],
  },
  {
    id: "coupling",
    name: "耦合风险",
    nameEn: "Coupling Risk",
    icon: "Link2",
    summary:
      "XpCostConversion 单一权威 XP 数学被服务端/客户端/JEI/REI 四方共用是教科书级解耦；主要耦合热点是 forAnvilSide 双路径配置读取、ScreenHandler 中心化，以及 11 语言 × 961 键 × 多文档矩阵的翻译漂移（详见文字审计页）。",
    findings: [
      {
        id: "COUP-01",
        severity: "praise",
        title: "XP 数学单源：服务端扣费、客户端 tooltip、JEI/REI、守恒验证共用一类",
        location: "mechanics/enchanting/XpCostConversion.java",
        evidence:
          "xpPointsForLevel/totalXpForLevel/minPointsRequired/combineSequential 等全部集中；Javadoc 明确「All methods accept an explicit LibraryResonance.Config so dedicated-server datapack overrides synced via SyncedEnchantmentCosts match server calculations 1:1 on clients」。",
        analysis:
          "这是防止「服务端收费与客户端显示不一致」这类最恶劣 bug 的结构性保障。批量等价公式（requiredLevel(B)=R₁+(B−1)D₁）与序贯合并公式都有证明式注释。",
        recommendation: "保持；其「显式传 Config」的模式可推广到 LibraryResonance 的其余计算。",
      },
      {
        id: "COUP-02",
        severity: "medium",
        title: "forAnvilSide：同一逻辑按线程侧别走两条配置源",
        location: "ModRuntimeConfig.forAnvilSide / configForSide",
        evidence:
          "客户端读 remoteServerInstance（同步快照），服务端读 ChiseledEnchantingTableData.runtimeConfiguration()（数据包解析）。mixin 在 AnvilMenu 与 ChiseledBookShelf 上按 world.isClientSide 分流。",
        analysis:
          "设计动机正确（客户端绝不能读本地磁盘配置覆盖服务器数值），但意味着每个用到的 mixin 都要正确传 side，任何一处误判（如集成服务器上 isClientSide 的边界）都会让两端显示不同价格。当前实现一致，但这是「同步漂移温床」类结构。",
        recommendation:
          "封装一个 ConfigView 上下文对象随调用链传递，而非每个调用点自行判断 side；对 forAnvilSide 的两个分支写对称性单元测试（同输入必同输出）。",
      },
      {
        id: "COUP-03",
        severity: "medium",
        title: "11 语言 × 961 键 × 4 层文档的翻译矩阵已实际漂移",
        location: "lang/*.json × {README, WIKI, NEXT_TASK, CHANGELOG}",
        evidence: "详见文字审计页：zh_tw 同文件双名（纂刻/雕紋）、33 处格式符漂移、README 与 WIKI 数值矛盾、NEXT_TASK 陈旧断言。",
        analysis:
          "这是本仓库最大的耦合面——代码、数据包、GUI 文本、外部文档四方共享同一批术语与数值。ci_static_checks 只校验键集合与 %s 数量，位置参数与 %% 完全不在门内。",
        recommendation: "见文字审计页的系统性建议（TA 系列），核心是把「术语表 + 格式符校验」升格为 CI 门。",
      },
    ],
  },
];

export interface BalanceTopic {
  id: string;
  verdict: "合理" | "存疑" | "待验证";
  title: string;
  detail: string;
  numbers: string[];
  suggestion: string;
}

export const balanceTopics: BalanceTopic[] = [
  {
    id: "BAL-01",
    verdict: "合理",
    title: "gamma=1.25 升级曲线：README / WIKI / 代码三方复算吻合",
    detail:
      "以 cap=38、maxLevel=5 复算 round(38·((L−1)/(M−1))^1.25)：L=2 → 38·0.25^1.25≈6.72→7；L=3 → 38·0.5^1.25≈15.98→16；L=4 → 38·0.75^1.25≈26.5→27；L=5（满级）→ 38。M=4 时 II(10)/III(23)/IV(38)、M=3 时 II(16)/III(38)、M=2 走 two_level_max_bookshelves=22——与 README 与 WIKI 3.1 节完全一致。HALF_CEIL 空白上限 ⌈M/2⌉ 的表述也与 BookshelfProgression.maxBlankWoodenTier 的 (clampedMax+1)/2 一致。",
    numbers: ["gamma=1.25", "cap=38", "M=2→22", "M=5: 7/16/27/38", "空白上限⌈M/2⌉"],
    suggestion: "无。这是本仓库数值文档可信度最高的部分，可作为其它数值段落的对齐标杆。",
  },
  {
    id: "BAL-02",
    verdict: "待验证",
    title: "普通书架 −15% 折扣的可达性：呼吸空间规则可能使 45 架放不下",
    detail:
      "折扣公式 round(1% + 14%·clamp((W−3)/42))，W=45 时恰为 15%。但 W 的上限受两重约束：扫描体积 7×5×7=245 格（半径 3/2/3），以及 require_breathing_room=true + min_open_adjacent_blocks=6。若呼吸空间约束作用于每个书架（需 ≥6 个开放邻格），则 245 格体积内同时满足约束的书架摆放数未必能达到 45——满额折扣可能在实际生存中不可达，导致 −15% 成为纸面数值。",
    numbers: ["min_discount=3", "max_discount=45", "span=42", "上限−15%", "min_open_adjacent=6", "体积7×5×7=245"],
    suggestion:
      "写一个小的摆放求解脚本（或创造模式实测）：在 245 格体积、台居中、满足呼吸规则的前提下求最大书架数；若 <45，应下调 max_discount_bookshelves 至可达值，或在 WIKI 明示「理论上限」与「实际可达」两档。",
  },
  {
    id: "BAL-03",
    verdict: "存疑",
    title: "宝藏顿悟 max_chance=0.90 终局贬值风险",
    detail:
      "概率 = min(0.90, 0.28 + 0.008·(W−32) + 0.022·T)。42 架 + 10 卷 ≈ 0.28+0.08+0.22 = 0.58；要到 0.90 需 ~46 卷或极端书架数，看似自限。但顿悟周期 12000 ticks（10 分钟）且可 Freeze（24000t）锁定 + 花费重掷，终局玩家每 10 分钟一次 0.5+ 概率的宝藏附魔产出，会让经验修补/无限这类宝藏迅速通货化——与免磨损获取限定（BAL-05）的保护意图相互抵消。",
    numbers: ["base=0.28", "+0.008/架", "+0.022/卷", "cap=0.90", "周期12000t", "Freeze=24000t"],
    suggestion: "将 cap 降至 0.75，或对同一宝藏附魔引入「顿悟冷却」（同附魔 N 游戏日内不重复出现），保住宝藏稀缺性。",
  },
  {
    id: "BAL-04",
    verdict: "合理",
    title: "批量等价公式保证单批不比逐次便宜",
    detail:
      "scaleTransformationXpForBatch 满足 requiredLevel(B)=R₁+(B−1)D₁、deducted(B)=B·D₁，且 minPoints ≥ B·minPoints(1)；maxTransformationBatchForLevel 由 (level−R)/D+1 推出最大可负担批。守恒式（telescoping V[k]−V[j] ≤ Cost_min）有 EconomyAndConfigVerificationTest 覆盖。批量不会成为折扣漏洞。",
    numbers: ["R(B)=R₁+(B−1)D₁", "D(B)=B·D₁", "守恒 V[k]−V[j]≤Cost_min", "批上限64"],
    suggestion: "无。建议把该公式的玩家侧解释（「一次做 64 个和一个个做花费完全一样」）写进 WIKI 8.1，玩家会关心。",
  },
  {
    id: "BAL-05",
    verdict: "合理",
    title: "免磨损（无限）反漏洞设计成体系",
    detail:
      "获取途径限定（世界战利品/原版台随机/已有母本复制）、代数衰减（Gen≥3 失去特权并扣上限）、全馆承载 ΣL≥3.0 触发串扰且封顶 25%（70% 降级/25% 无关附魔/5% 诅咒、串扰退 50%）、村民 wear_immune 书自动清理。拆多本高承载书绕过 ΣL 的漏洞被显式堵死（WIKI 3.2）。设计自洽度高。",
    numbers: ["Gen≤2 全额", "N≤4 全免", "超4条每条−6%", "保底30%", "ΣL≥3.0", "串扰cap 25%"],
    suggestion: "5% 诅咒对玩家挫败感偏强，建议给「首次串扰触发诅咒」一次豁免或将其降为 3%，并在 GUI 串扰提示中明示概率构成。",
  },
  {
    id: "BAL-06",
    verdict: "存疑",
    title: "献祭跳过可架空等待机制：队列边际成本递减",
    detail:
      "牺牲跳过单步封顶 15 级，每多一步只 +4 级（sacrifice_extra_xp_per_queued_step=4）。排队 5 步 = 15+4×4=31 级即可瞬间清空全部队列；而自然等待时间无上限累加（max_single_wait=300s 仅限单个附魔）。数学上「一次排 N 个附魔再一次性献祭」的每附魔边际经验远低于逐个等待或逐个献祭，深度铭刻的等待博弈被架空为纯经验税。",
    numbers: ["单步cap=15", "+4/排队步", "5步=31级", "单附魔等待cap=300s", "队列等待无上限"],
    suggestion: "让 +4 的边际递增改为递增斜率（如 +4, +6, +8…），或给「已跳过步数」引入 degrade 概率（复用 rush_degrade 通道），使深度排队仍有博弈感。",
  },
  {
    id: "BAL-07",
    verdict: "存疑",
    title: "三重折扣叠乘后边际成本过低",
    detail: "升级材料 ×0.8（master_tome_upgrade_material_multiplier）× 0.85 阶梯折抵（incremental_step_credit_factor）× 最高 −40% XP 折扣，三者乘性地叠加：满配图书馆下重复升级的边际成本 ≈ 0.8×0.85×0.6 ≈ 41% 基准。终局玩家为「+1 级」付出的增量被三重放大削减过半，可能使升级曲线在后期失去张力（gamma 1.25 在 27→38 架段本已变陡）。",
    numbers: ["材料×0.8", "折抵×0.85", "XP折扣−40%", "叠乘≈41%"],
    suggestion: "GUI 已显示多重折扣（好），建议 WIKI 补一张「边际成本递减曲线」图；数值上可考虑折扣只作用于 XP、材料倍率只作用于未折扣部分，避免乘性叠加。",
  },
  {
    id: "BAL-08",
    verdict: "合理",
    title: "XP 点数公式与 vanilla 逐段一致",
    detail: "xpPointsForLevel 实现 7 + 2L（L<15）/ 37 + 5(L−15)（15≤L<30）/ 112 + 9(L−30)（L≥30），与 vanilla 经验表完全一致；minPointsRequired 对 giveExperienceLevels 保留进度条分数的行为（移除 sum W(j) + p·(W(L)−W(L−d))）有注释级证明。",
    numbers: ["7+2L", "37+5(L−15)", "112+9(L−30)"],
    suggestion: "无。若未来 vanilla 调表，此处是唯一需要同步的点——建议在 MIXIN 升级清单中一并列出。",
  },
];
