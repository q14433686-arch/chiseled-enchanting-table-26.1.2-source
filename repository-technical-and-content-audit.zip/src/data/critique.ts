export interface Doubt {
  id: string;
  title: string;
  claim: string;
  evidence: string;
  counterpoint: string;
  risk: string;
}

export interface Suggestion {
  id: string;
  title: string;
  detail: string;
  effort: "低" | "中" | "高";
  impact: "低" | "中" | "高";
  relates: string[];
}

export const fairFirst = {
  title: "先说公道话：这份移植的工程素养在社区模组里属于前 5%",
  points: [
    "自带 6 个测试类（经济守恒、配置安全、网络兼容、规则架构、机制审计、全量移植运行时），绝大多数社区移植一个测试都没有；",
    "CI 三工作流 + 四道离线静态门，没有 JDK 的沙箱也能跑贡献前检查；",
    "26 份过程报告 + 代码内 30+ 条审计编号注释（H-01/R-01/NET-02/MX-04…），每个历史 bug 都留了可追溯的决策记录；",
    "worldgen 死锁这种最难的 bug 类别有专门的成因分析与两阶段修复（标记 + 主线程消费）；",
    "数据驱动程度极高：14 个 JSON 配置，BundledDefaults 由生成器产出并 CI 字节级校验；",
    "XP 数学单源（XpCostConversion）被服务端、客户端、JEI/REI 四方共用，结构性杜绝了「显示价 ≠ 实收费」。",
  ],
  conclusion:
    "以下怀疑建立在这个基线之上：问题不是因为作者懒或草率，而恰恰因为这套流程已经很重，某些结构性风险才更值得被指出。",
};

export const doubts: Doubt[] = [
  {
    id: "D-01",
    title: "1.1.0 的文档跑在验证前面：README 宣传的功能「从未在真实客户端运行过」",
    claim: "README 把 1.1.0 的进度重做、平衡、UI/UX、配方查看器大修写得像已交付，而 NEXT_TASK A0 白纸黑字写着：1.0.3 同步之后的所有东西都没进过真实客户端，测试者还因 Iris/Distant Horizons 版本冲突在第一帧就崩溃。",
    evidence: "NEXT_TASK.md: \"Nothing in the 1.0.3 sync has been in a real client yet… a green compile-check only proves the code compiles and the mixin target classes exist.\"",
    counterpoint:
      "CI 三工作流全绿 + 离线静态门齐全，且作者诚实地在内部文档记录了未验证状态——比大多数「默默发布」的移植负责任得多。问题只在 README（玩家唯一会读的文档）没有把这一状态传递出来。",
    risk: "玩家按 README 预期安装 1.1.0，遇到运行时问题却以为是自己的问题；或更糟——去上游 Sacramentix 仓库报 bug，污染上游的 issue 区。",
  },
  {
    id: "D-02",
    title: "「编译绿」的证明力被高估：8 个 mixin 的行为假设只被编译器验证了一半",
    claim: "compile-check 证明 mixin 目标类与方法签名存在，但 RemoveEnchantMerge 依赖 vanilla createResult 不缓存中间结果、ReloadableServerRegistriesMixin 依赖 reload 的 HEAD 先于 LOOT_TABLE 构建、DisableBookEnchanting 依赖 getEnchantmentList 的调用频率——这些行为契约在 26.x 快节奏版本线上随时可能变。",
    evidence: "26.1.2 是 Minecraft 新版本线（ mappings 与内部结构仍在频繁调整），仓库自己也在 Loom/映射版本上锁 1.16-SNAPSHOT / Gradle 9.4.1 追赶。",
    counterpoint:
      "作者对每个 mixin 都写了远超社区平均的注释（含「为什么 HEAD 不是 TAIL」级别的反例），风险是被认知的，只是没有被自动化。",
    risk: "MC 26.1.3/26.2 发布日的升级成本不可预估：某个 vanilla 内部顺序变了，症状会是「书架不生成/合并失效」这类静默行为退化，而非编译错误。",
  },
  {
    id: "D-03",
    title: "文档矩阵已经比代码更难维护，且正在出现事实漂移",
    claim: "主源码约 2.4 万行，而文档矩阵是：WIKI 48KB（中文）+ CHANGELOG 50KB + CURRENT_BASELINE 27KB + NEXT_TASK 16KB + 26 份历史报告 + TODO.md（上游遗留）+ DOCUMENTATION_INDEX。本审计已发现 4 处文档间事实矛盾（README 12+ vs 配置 3+、NEXT_TASK 的 advancement 断言过时、WIKI 编号漂移、Master Tome/Template Book 两名混用）。",
    evidence: "同一数值（min_discount_bookshelves=3）在 4 处被人类手工转写，其中 1 处已错。",
    counterpoint: "过程报告的存在价值真实（死锁分析、26.3 差异对照都是高质量内容），问题不是「写太多」而是「没有分层与退役机制」——全部处于「活跃」状态。",
    risk: "贡献者按 NEXT_TASK 的过时断言行动；玩家按 README 的错误阈值建造；作者自己每次改数值要同步 N 处，迟早再漏。",
  },
  {
    id: "D-04",
    title: "配置系统复杂度与目标用户错位：改一个数值有三个入口",
    claim: "改「附魔 XP 成本」可以动：① config/chiseled_enchanting_table.json（runtime，GUI 可视化 7 大分类）；② 数据包 library_resonance.json；③ 数据包 enchantment_costs.json。三者的优先级、同步时机（JOIN vs /reload）、适用范围（本地 vs 服务器权威）各不相同，对应约 3400 行配置代码 + 规则引擎（RuleBook/RuntimeRules）。",
    evidence: "ModRuntimeConfig(1887 行) + ConfigCatalog(1204 行) + rules 双层 + 7 分类 GUI，占主源码约 15%。",
    counterpoint:
      "双层设计（runtime 快速开关 + datapack 深度定制）本身合理，服务器管理员与整合包作者的需求确实不同；游戏内可视化配置 GUI 更是超配的诚意。",
    risk: "整合包作者（本类模组的核心用户）改错入口 → 改动被另一层覆盖 → 以为模组坏了 → 弃用。这是功能丰富度反噬可用性的典型路径。",
  },
  {
    id: "D-05",
    title: "协议兼容债只增不减：15 个 cost probe + 7 个 apply probe 没有退役时间表",
    claim: "EnchantingProtocol 保留 revision_1 到 15 的全部查询通道，注释的政策是「只要公开发布过就不能删」。但没有量化规则（如保留最近 6 个公开版本），长远每个 revision 常量要在独立字段与 PROBES 列表两处手工同步——漏一处，老客户端就从「友好断连」退化为「raw decode error」。",
    evidence: "PREVIOUS_COST_TYPE（revision_4）有独立常量，revision_1..3 只在列表里，revision_5..15 又是独立常量——三种维护模式并存。",
    counterpoint: "保留 probe 的动机（老客户端优雅降级）是对的，且查询通道不注册解码器，无安全面。",
    risk: "三年后这个列表有 50 个常量、三种书写模式，每次发版都要人肉核对——出错只是时间问题。",
  },
  {
    id: "D-06",
    title: "每秒为每个玩家全量重建置换显示：性能设计在为「正确」付「贵」的代价",
    claim: "EnchantCostSync 每 20 tick 对每个在线玩家构建完整 TransformationDisplay 列表（遍历全部 item_transformations + 解析成本选项）再做全表 equals，只为检测「有没有变化」。主线程执行，O(players × transformations)/秒。",
    evidence: "第三方附魔数据包注入后变换表可达数百条；20 人服务器即每秒数百次全表构建 + 比较。",
    counterpoint: "当前内置变换表很小（约 10 条），显示一致性收益真实；WeakHashMap 生命周期管理也正确。这是一个「现在不痛、规模化会痛」的路径。",
    risk: "大型整合包（300+ 变换）+ 多人服务器场景下成为隐性的每秒主线程开销，且极难从 profiler 里一眼归因。",
  },
  {
    id: "D-07",
    title: "测试金字塔缺了最关键的一层：mixin 行为无运行时断言",
    claim: "6 个测试类覆盖经济守恒、配置安全、网络兼容、规则架构——都是纯逻辑层。但本模组风险最高的部分（8 个 mixin 对 vanilla 行为的假设、GUI 交互、JEI/REI 双适配器）没有任何自动化运行时覆盖，完全依赖 NEXT_TASK 里那份手写的「A0 实测清单」。",
    evidence: "NEXT_TASK A0–A7 是一份详尽的人工回归清单（含 JEI/REI 双开、成本同步、语言切换、payload 往返），但它在 markdown 里，不在 CI 里。",
    counterpoint: "Fabric 生态的运行时测试基础设施确实薄弱（需要 headless client / gametest 框架），社区普遍如此；作者至少把人工清单写到了可执行级别。",
    risk: "每次 MC 版本升级，A0 清单执行一次的成本是小时级——执行率会随时间衰减，直到某次升级漏跑。",
  },
  {
    id: "D-08",
    title: "命名与身份：以「unofficial port」之名做了大量原创设计",
    claim: "1.1.0 相对上游已不只是移植：三轨道进度、守恒验证的经济系统、仪式等待博弈、免磨损代数衰减、可视化配置 GUI、JEI/REI 双适配——大量原创机制。但 mod 名仍是上游原名 + (Unofficial Port) 后缀，Modrinth/CurseForge 也挂在「unofficial port」名下。",
    evidence: "仓库自己的 README 顶部声明「not affiliated with, endorsed by, or maintained by the original author」，同时 CHANGELOG 记录了远超 port 范围的功能演进。",
    counterpoint:
      "MIT 协议允许且归属声明做得规范（credit 醒目、issue 导向本仓库）；保留原名也确实帮上游玩家找到这个分支。",
    risk: "「同名不同魂」的经典困境：上游玩家按上游文档来用这个 port，数值与机制全对不上；port 的原创设计被上游的历史 issue 淹没。",
  },
];

export const suggestions: Suggestion[] = [
  {
    id: "S-01",
    title: "README 增加「运行时验证状态」徽章，把 NEXT_TASK A0 的诚实传递给玩家",
    detail:
      "在 README 顶部加一个简单的状态表：编译 ✅ / 静态门 ✅ / 经济与网络单测 ✅ / 真实客户端回归 ⚠️ 部分。一行不说谎的免责声明，比任何营销段落都更能建立长期信任。",
    effort: "低",
    impact: "高",
    relates: ["D-01"],
  },
  {
    id: "S-02",
    title: "建 docs/MIXIN_UPGRADE_CHECKLIST.md：8 个 mixin × {目标签名, 行为假设, 升级 re-check 步骤}",
    detail:
      "把散在各类注释里的注入理由汇总成一张升级清单表。每次 MC 小版本升级，照表逐项检查目标方法的字节码/调用顺序是否变化。半小时的文档工作，换未来每次升级的可预估性。",
    effort: "低",
    impact: "高",
    relates: ["D-02", "D-07"],
  },
  {
    id: "S-03",
    title: "数值文档脚本化：README/WIKI 数值段由 JSON 渲染生成",
    detail:
      "复用 gen_bundled_defaults.py 的成熟模式：新写 gen_docs_numbers.py，从 library_resonance.json / shelf_gates.json / treasure_epiphany.json 渲染 README 概念段与 WIKI 速查表，CI 校验字节一致。一次根治「手抄数值」这个漂移源头。",
    effort: "中",
    impact: "高",
    relates: ["D-03", "TA-04"],
  },
  {
    id: "S-04",
    title: "CI 门升级：格式符四元组比对 + 术语表存在性 + 标题编号单调性",
    detail:
      "在 ci_static_checks.py 的 lang 检查中：① 每键比对 {位置参数集合, %%, %s, %d}（en_us 为基准）；② 校验 TERMS.md 收录的术语在各语言中一致（尤其 zh_cn/zh_tw 的 mod 名）；③ docs 检查加 markdown 标题编号单调递增。三条约各 30 行 Python。",
    effort: "中",
    impact: "高",
    relates: ["TA-01", "TA-03", "TA-06", "TA-07"],
  },
  {
    id: "S-05",
    title: "置换同步改 dirty-flag：事件置脏，tick 只重建脏玩家",
    detail:
      "在 /reload、菜单打开、库存变更、成本表到达等事件上标记 per-player dirty；END_SERVER_TICK 只处理脏玩家。把 O(全体×每秒) 降为 O(变更×每秒)。",
    effort: "中",
    impact: "中",
    relates: ["D-06"],
  },
  {
    id: "S-06",
    title: "协议 probe 退役政策量化 + 常量生成收敛",
    detail:
      "① 写明「保留最近 6 个公开发布版本，更早的允许在 minor 版本删除并在 CHANGELOG 标注 breaking」；② 把 15+7 个常量改为单一数组生成，消灭三种书写模式并存。改政策不改代码行为，纯债管理。",
    effort: "低",
    impact: "中",
    relates: ["D-05", "NET-03"],
  },
  {
    id: "S-07",
    title: "发布卫生：mod 显示名加后缀、fabric.mod.json 描述强调社区分支",
    detail:
      "显示名改为「Chiseled Enchanting Table (Community Port)」或在描述首句强化「机制与数值已与上游分叉，文档见本仓库 WIKI」；Modrinth/CurseForge 页面顶部链接 WIKI 与 CHANGELOG。让「同名不同魂」的身份显性化。",
    effort: "低",
    impact: "中",
    relates: ["D-08"],
  },
  {
    id: "S-08",
    title: "文档收敛：报告归档 + 断言加日期戳",
    detail:
      "docs/reports/ 的 26 份历史报告加「已归档」头与完成日期；TODO.md 归档为 upstream/TODO_ARCHIVE.md；NEXT_TASK 的事实断言全部加 [日期 核实] 标记。活跃文档收敛为 WIKI + CHANGELOG + NEXT_TASK 三份。",
    effort: "低",
    impact: "中",
    relates: ["D-03", "TA-05", "DEAD-01"],
  },
  {
    id: "S-09",
    title: "整合包作者决策表：「我想改 X，动哪个文件」",
    detail:
      "WIKI 增加一张三列表：想改什么（XP 成本/材料/解锁速度/书架范围/村民经济）→ 动哪个文件（runtime config vs datapack JSON）→ 同步时机（重启 vs /reload vs 重进）。直接回应 D-04 的入口混乱。",
    effort: "低",
    impact: "高",
    relates: ["D-04", "API-04"],
  },
  {
    id: "S-10",
    title: "玩家文档双层化：速查表层 + 设计公式层",
    detail:
      "WIKI 每个公式块前加「人话版」结论行（如「20 架 → 锋利 III」），常用档位做成速查表置顶；公式折叠或独立设计章节。玩家与贡献者各取所需。",
    effort: "中",
    impact: "中",
    relates: ["TA-09", "TA-10"],
  },
  {
    id: "S-11",
    title: "运行时回归最小集：把 A0 清单里可自动化的部分搬进 CI",
    detail:
      "Fabric 提供 gametest 框架与 headless server 方案：至少把「服务器启动无 mixin 错误」「菜单打开 payload 往返」「JEI/REI 单/双开注册」做成 nightly 可选 job。人工清单保留 GUI 手感部分。",
    effort: "高",
    impact: "高",
    relates: ["D-01", "D-02", "D-07"],
  },
  {
    id: "S-12",
    title: "GUI 批次提示区分创造/生存",
    detail:
      "批量按钮 tooltip 在创造模式标注「创造模式：不受经验限制」，生存模式显示按当前 XP 折算的实际最大批。低成本消除一处预期错位。",
    effort: "低",
    impact: "低",
    relates: ["GUI-02"],
  },
];
