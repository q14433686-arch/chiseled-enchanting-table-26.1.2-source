import { ReactNode } from "react";
import { cn } from "../utils/cn";
import { Severity, severityMeta } from "../data/audit";

export function SeverityBadge({ severity, className }: { severity: Severity; className?: string }) {
  const meta = severityMeta[severity];
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-medium tracking-wide",
        meta.color,
        className
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", meta.dot)} />
      {meta.label}
    </span>
  );
}

export function TagBadge({ children, tone = "default" }: { children: ReactNode; tone?: "default" | "gold" | "purple" }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-md px-2 py-0.5 text-[11px] font-mono tracking-wide",
        tone === "gold" && "bg-amber-400/10 text-amber-300 ring-1 ring-inset ring-amber-400/25",
        tone === "purple" && "bg-violet-400/10 text-violet-300 ring-1 ring-inset ring-violet-400/25",
        tone === "default" && "bg-zinc-400/10 text-zinc-300 ring-1 ring-inset ring-zinc-400/20"
      )}
    >
      {children}
    </span>
  );
}

export function CodeBlock({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <pre
      className={cn(
        "overflow-x-auto rounded-lg border border-zinc-700/60 bg-zinc-950/70 p-3.5 font-mono text-[12.5px] leading-relaxed text-zinc-300",
        className
      )}
    >
      {children}
    </pre>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string;
  title: string;
  description?: string;
}) {
  return (
    <div className="mb-8">
      <div className="mb-2 flex items-center gap-3">
        <span className="h-px w-8 bg-gradient-to-r from-transparent to-amber-400/60" />
        <span className="font-mono text-[11px] uppercase tracking-[0.25em] text-amber-300/80">{eyebrow}</span>
        <span className="h-px flex-1 bg-gradient-to-r from-amber-400/60 to-transparent" />
      </div>
      <h2 className="font-serif text-2xl font-semibold tracking-wide text-zinc-100 md:text-3xl">{title}</h2>
      {description && <p className="mt-3 max-w-3xl text-sm leading-7 text-zinc-400">{description}</p>}
    </div>
  );
}

export function FindingCard({
  id,
  severity,
  title,
  location,
  children,
}: {
  id: string;
  severity: Severity;
  title: string;
  location: string;
  children: ReactNode;
}) {
  return (
    <article
      id={id}
      className="group scroll-mt-28 rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-5 transition-colors duration-300 hover:border-zinc-600/60 hover:bg-zinc-900/60"
    >
      <div className="mb-3 flex flex-wrap items-center gap-2.5">
        <span className="font-mono text-xs font-semibold text-amber-300/90">{id}</span>
        <SeverityBadge severity={severity} />
        <span className="ml-auto hidden font-mono text-[10.5px] text-zinc-500 sm:block truncate max-w-[45%]" title={location}>
          {location}
        </span>
      </div>
      <h3 className="mb-3 text-[15px] font-semibold leading-snug text-zinc-100">{title}</h3>
      {children}
    </article>
  );
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="mb-2.5">
      <div className="mb-1 flex items-center gap-2">
        <span className="h-1 w-1 rounded-full bg-amber-400/70" />
        <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-500">{label}</span>
      </div>
      <div className="pl-3 text-[13.5px] leading-6.5 text-zinc-300">{children}</div>
    </div>
  );
}

export function StatCard({ value, label, sub, accent }: { value: string; label: string; sub?: string; accent?: string }) {
  return (
    <div className="rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-5">
      <div className={cn("font-serif text-3xl font-semibold tracking-wide", accent ?? "text-amber-300")}>{value}</div>
      <div className="mt-1.5 text-sm font-medium text-zinc-200">{label}</div>
      {sub && <div className="mt-1 text-xs leading-5 text-zinc-500">{sub}</div>}
    </div>
  );
}
