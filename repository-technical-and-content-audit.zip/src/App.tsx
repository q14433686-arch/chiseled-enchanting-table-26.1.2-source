import { useEffect, useState } from "react";
import { ScrollText, Code2, BookOpenCheck, ShieldQuestion, SquareArrowOutUpRight } from "lucide-react";
import Overview from "./pages/Overview";
import CodeAudit from "./pages/CodeAudit";
import TextAudit from "./pages/TextAudit";
import Critique from "./pages/Critique";
import { cn } from "./utils/cn";

const pages = [
  { id: "overview", label: "总览", icon: ScrollText },
  { id: "audit", label: "代码审计", icon: Code2 },
  { id: "text", label: "文字审计", icon: BookOpenCheck },
  { id: "critique", label: "怀疑与建议", icon: ShieldQuestion },
] as const;

type PageId = (typeof pages)[number]["id"];

function currentPage(): PageId {
  const hash = window.location.hash.replace("#", "");
  return (pages.find((p) => p.id === hash)?.id ?? "overview") as PageId;
}

export default function App() {
  const [page, setPage] = useState<PageId>(currentPage);

  useEffect(() => {
    const onHash = () => {
      setPage(currentPage());
      window.scrollTo({ top: 0 });
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const navigate = (id: string) => {
    window.location.hash = id;
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-200 antialiased [color-scheme:dark]">
      {/* Ambient background */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(124,58,237,0.06),transparent_55%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,rgba(217,160,28,0.04),transparent_50%)]" />
      </div>

      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-zinc-800/70 bg-zinc-950/85 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 md:px-8">
          <button onClick={() => navigate("overview")} className="group flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg border border-amber-400/30 bg-gradient-to-br from-violet-500/20 to-amber-400/10">
              <span className="font-serif text-base font-bold text-amber-300">纂</span>
            </div>
            <div className="text-left">
              <div className="font-serif text-[15px] font-semibold tracking-wide text-zinc-100 group-hover:text-amber-200">
                纂刻附魔台 · 移植审计
              </div>
              <div className="font-mono text-[10px] tracking-wider text-zinc-500">26.1.2-source / arena·b99a37c2</div>
            </div>
          </button>

          <nav className="hidden items-center gap-1 md:flex">
            {pages.map((p) => (
              <button
                key={p.id}
                onClick={() => navigate(p.id)}
                className={cn(
                  "flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-[13px] font-medium transition-all",
                  page === p.id
                    ? "bg-zinc-800/80 text-amber-200"
                    : "text-zinc-400 hover:bg-zinc-800/40 hover:text-zinc-200"
                )}
              >
                <p.icon className="h-3.5 w-3.5" />
                {p.label}
              </button>
            ))}
          </nav>

          <a
            href="https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/tree/arena%2Fb99a37c2-chiseled-enchanting-table-26-1"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 rounded-lg border border-zinc-700/70 px-3 py-1.5 text-xs text-zinc-400 transition-colors hover:border-zinc-500 hover:text-zinc-200"
          >
            <SquareArrowOutUpRight className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">查看仓库</span>
          </a>
        </div>

        {/* Mobile nav */}
        <nav className="flex gap-1 overflow-x-auto border-t border-zinc-800/50 px-4 py-2 md:hidden [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {pages.map((p) => (
            <button
              key={p.id}
              onClick={() => navigate(p.id)}
              className={cn(
                "flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-all",
                page === p.id ? "bg-zinc-800/80 text-amber-200" : "text-zinc-500"
              )}
            >
              <p.icon className="h-3 w-3" />
              {p.label}
            </button>
          ))}
        </nav>
      </header>

      {/* Content */}
      <main className="relative z-10">
        {page === "overview" && <Overview onNavigate={navigate} />}
        {page === "audit" && <CodeAudit />}
        {page === "text" && <TextAudit />}
        {page === "critique" && <Critique />}
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-zinc-800/70 bg-zinc-950/60">
        <div className="mx-auto max-w-6xl px-5 py-10 md:px-8">
          <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
            <div className="max-w-md">
              <div className="mb-2 font-serif text-sm font-semibold text-zinc-200">审计声明</div>
              <p className="text-xs leading-6 text-zinc-500">
                本报告基于公开分支 arena/b99a37c2（提交时间 2026-10-25 前）的全量源码静态审查与脚本化比对，未运行游戏客户端。
                严重度评级为审计者判断，供维护者参考；「亮点」级发现同样列出，因为它们值得被保持与推广。
                所有数值复算过程可按各条目给出的公式与默认值重现。
              </p>
            </div>
            <div className="text-xs text-zinc-600">
              <div className="mb-2 font-mono">审计路径</div>
              <div className="flex flex-wrap gap-1.5">
                {["源码 API", "数据编解码", "网络同步", "GUI 输入", "Mixin 注入", "死代码", "耦合风险", "数值设计", "文字三轴"].map((t) => (
                  <span key={t} className="rounded border border-zinc-800 px-1.5 py-0.5 font-mono text-[10px]">
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </div>
          <div className="mt-8 flex items-center justify-between border-t border-zinc-800/50 pt-6 text-[11px] text-zinc-600">
            <span className="font-mono">Unofficial audit · not affiliated with the mod's maintainers</span>
            <span className="font-mono">v1.1.0 · MC 26.1.2 · Fabric</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
