import type { Issue } from "./types";

/** 第二类：游戏内可见文本「不说人话」 */
export const INGAME_ISSUES: Issue[] = [
  {
    id: "I-01",
    title: "报错提示像修仙小说：「超载「无限」母本灵脉串扰！」",
    area: "ingame",
    severity: "blocker",
    tags: ["玩家看不懂", "损失提示", "zh+en"],
    location: "ChiseledEnchantingTableScreen / 强行跳过失败时弹出",
    keys: ["gui.chiseled_enchanting_table.ritual.slip_warning"],
    problem: [
      "现文案：「⚠ 超载「无限」母本灵脉串扰！%s 抄错降为 %s 级！」",
      "「超载」「灵脉串扰」「抄错」没有一个是本 mod 定义过的术语，玩家刚损失了一本母本，却看不出：① 发生了什么；② 损失了什么；③ 下次怎么避免。",
      "这是**唯一**一条会造成不可逆资源损失的提示，优先级应当最高。",
      "好的损失提示 = 结果 + 原因 + 对策，三件套缺一不可。",
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.ritual.slip_warning",
        before: "⚠ 超载「无限」母本灵脉串扰！%s 抄错降为 %s 级！",
        after: "⚠ 强行跳过失手了：《%s》被抄坏，等级掉到 %s 级。借用带「无限」的母本时失败率更高，下次改用「献祭经验」跳过可以零风险。",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.ritual.slip_warning",
        before: "⚠ Overloaded Infinity Tome interference! %s slipped to level %s!",
        after: "⚠ Rushing it backfired: %s was miscopied and dropped to Lv.%s. Borrowing an Infinity tome raises the failure rate — spend XP to skip instead if you want zero risk.",
      },
    ],
  },
  {
    id: "I-02",
    title: "“广义书架”是自造词，却是全套说明的核心名词",
    area: "ingame",
    severity: "major",
    tags: ["自造术语", "术语表", "高频"],
    location: "zh_cn.json 12+ 处 / en_us.json「Broad Bookshelves」",
    keys: [
      "gui.chiseled_enchanting_table.grimoire.home.p2",
      "gui.chiseled_enchanting_table.grimoire.ch3p0.s1",
      "gui.chiseled_enchanting_table.grimoire.ch3p0.s3",
      "gui.chiseled_enchanting_table.grimoire.diag.ch3p0_broad_hdr",
      "item.chiseled_enchanting_table.master_tome_regen_hint",
    ],
    problem: [
      "「广义书架」= 普通书架 + 空雕纹书架 + 有书雕纹书架 的并集。这是开发者给集合起的数学名字，不是玩家语言。",
      "英文「Broad Bookshelves」更糟，母语玩家第一反应是「宽书架？」。",
      "首次出现在首页 p2（第一屏第二行），此时玩家还没读到第 3 章的定义，直接劝退。",
      "建议统一改为「书架总数（含雕纹）」/ 英文 \"all shelves (any kind)\"，并在首次出现处就地解释，不要靠跳章。",
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.grimoire.home.p2",
        before: "书架总区分：普通书架管升级，广义书架管温养，雕纹母本管直附",
        after: "三种书架各管一摊：普通书架管升级，书架总数（含雕纹）管母本回充，雕纹里的附魔书管直接附魔",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.grimoire.ch3p0.s1",
        before:
          "【广义书架 = 三类之和】：包含 ① 普通书架、② 空的雕纹书架、③ 有书的雕纹书架（此处的「书」包含普通书、附魔书、秘典以及「褪魔残卷」）。",
        after:
          "【书架总数】= ① 普通书架 + ② 空的雕纹书架 + ③ 装了东西的雕纹书架。第 ③ 类里装普通书、附魔书、秘典、褪魔残卷都算。",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.grimoire.ch3p0.s3",
        before:
          "【各司其职】：直附上限、基础 -15% 减免、开启顿悟与台内残卷减耗只看「普通书架」；母本温养（38/42 架）、深层等待（≥32 架）与超载抄错看「广义书架」；1–3 级拓印只看「雕纹母本」。",
        after:
          "【谁管什么】只数普通书架：白板直附上限、基础 -%s%% 经验减免、宝藏顿悟开启、残卷还原省料。数书架总数：母本自动回充（%s/%s 架提速）、铭刻等待时间、强行跳过的失败率。只数雕纹里的附魔书：1–3 级直接附魔。",
      },
      {
        lang: "zh_cn",
        key: "item.chiseled_enchanting_table.master_tome_regen_hint",
        before: " 置入雕纹书架随附近广义书架数自动温养回复（%s / %s 架两档提速）",
        after: " 放进雕纹书架后会自动回充；附近书架越多越快，满 %s 架、%s 架各提一次速",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.grimoire.home.p2",
        before: "Shelf Taxonomy: Regular upgrades tiers, Broad shelves heal Tomes, Master Tomes copy",
        after: "Each shelf does one job: regular shelves raise levels, total shelf count recharges tomes, and books inside chiseled shelves let you enchant directly.",
      },
    ],
  },
  {
    id: "I-03",
    title: "JEI 的「褪魔残卷」说明是一句 230 字的长句，根本读不完",
    area: "ingame",
    severity: "major",
    tags: ["超长句", "JEI/REI", "可读性"],
    location: "JEI / REI info 面板（宽度约 40 字/行）",
    keys: ["jei.chiseled_enchanting_table.info.depleted_tome"],
    problem: [
      "一句话塞进了：产出来源 4 种、世界生成概率、在雕纹书架里的身份、村民回收价、村民修书价、重绘为附魔书的动态定价公式，还嵌了一层【】括号。",
      "JEI 的 info 面板会把它折成十几行，玩家根本不会读，等于白写。",
      "「总替换率 ≤30%」「按『稀有度×普适度×相对等级』动态加权决定」是设计文档语言，不是 tooltip 语言。",
      "原则：tooltip 一行一件事，先说玩家当下最想知道的（这东西怎么用 / 怎么变回书），再说补充信息。",
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "jei.chiseled_enchanting_table.info.depleted_tome",
        before:
          "附魔书合并、全洗、I 级降级、母本耗尽退化，或在世界各地宝箱及野生雕纹书架（总替换率 ≤30%）中获得的残卷。放入雕纹书架时计为「广义书架」（不作母本）；可由图书管理员按 2 残卷 = 1 绿宝石 / 2 紫水晶碎片回收，或按 4 青金石 / 2 墨囊 / 1 绿宝石基础价拜托修成普通书；拜托重绘为附魔书时，【所需村民职业等级门槛（新手 Lv.1～大师 Lv.5）】与【具体要价】均按「稀有度×普适度×相对等级」动态加权决定（封顶价低于原版图书管理员经验修补常见要价）！",
        after:
          "被榨干的附魔书，可以 64 本一摞。\n怎么来的：合并两本书、清空附魔、I 级降级，或母本充能耗尽；宝箱和野外雕纹书架里也能翻到。\n怎么用：在附魔台里花点料变回普通书；放进雕纹书架只算书架数量，不提供附魔。\n找图书管理员：2 本换 1 绿宝石或 2 紫水晶碎片；也能付 4 青金石 / 2 墨囊 / 1 绿宝石让他修成普通书。\n让他重写成附魔书：附魔越稀有、越通用、等级越高，要求的村民等级和价钱就越高，但封顶比原版买经验修补便宜。",
      },
      {
        lang: "en_us",
        key: "jei.chiseled_enchanting_table.info.depleted_tome",
        before:
          "A 64-stackable remnant scroll produced by book merging/stripping or Tome depletion, and found across world chests (10%–55%) and wild Chiseled Bookshelves (<=30% total book replacement). Inside a Chiseled Bookshelf it counts toward Broad Bookshelves (never as a Master Tome). Librarian villagers buy 2 scrolls for 1 Emerald / 2 Amethyst Shards, repair plain Books at Novice Lv.1 (base: 4 Lapis / 2 Ink / 1 Emerald), and unlock Enchanted Book rewrites whose required Villager Level (Novice Lv.1 to Master Lv.5) AND price BOTH scale by (Rarity x Universality x Relative Level), capped below typical vanilla Mending prices!",
        after:
          "A used-up enchanted book. Stacks to 64.\nWhere it comes from: merging books, clearing enchantments, dropping a level I book, or a master tome running out of charges. Also found in chests and in wild chiseled bookshelves.\nWhat to do with it: turn it back into a plain book at the table, or store it in a chiseled bookshelf — it still counts toward your shelf total.\nLibrarians: 2 scrolls buy 1 Emerald or 2 Amethyst Shards, and they repair plain books from Novice level.\nRewriting one into an enchanted book costs more (and needs a higher-level librarian) the rarer, more universal and higher-level the enchantment is — but always less than a vanilla Mending trade.",
      },
    ],
    note: "若 JEI info 面板不支持换行符，可改为拆成多条 info（JeiPlugin 支持传入 List<Component>）。",
  },
  {
    id: "I-04",
    title: "JEI 的附魔台总览同样是分号连成的一长串",
    area: "ingame",
    severity: "major",
    tags: ["超长句", "JEI/REI"],
    location: "JEI / REI 分类 info",
    keys: ["jei.chiseled_enchanting_table.info.station"],
    problem: [
      "一句话里 5 个分号、3 个括号，说了 6 件不相关的事，第一次打开 JEI 的玩家直接划走。",
      "「退魔洗练按本台溯源全额返还经验球、外来附魔折算返还，冲突覆盖自动退差」—— 「溯源」「折算返还」「退差」三连，没有任何一个在 UI 里出现过。",
      "建议：第一行回答「这台子干嘛的」，后面每行一件事。",
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "jei.chiseled_enchanting_table.info.station",
        before:
          "把附魔书放进周围 7×5×7 雕纹书架作为母本，每次仅扣 1~3 级经验（默认每级 16 点耐久，耗尽退一级）；升级已有附魔自动扣除已付成本，退魔洗练按本台溯源全额返还经验球、外来附魔折算返还，冲突覆盖自动退差。",
        after:
          "自己挑附魔，不再看脸。\n把附魔书放进附魔台周围 7×5×7 的雕纹书架，就能照着它附魔，每次只扣 1–3 级经验（每级 16 点充能，用完降一级）。\n升级已有附魔时，之前付过的材料和经验会自动折抵，只补差价。\n在「退魔」页清附魔：本台附上去的全额退经验，别处来的按折扣退；被覆盖掉的冲突附魔也会退回差额。",
      },
    ],
  },
  {
    id: "I-05",
    title: "“单洗 / 全洗 / 轮播 / 实扣 / 阶位”——开发者黑话直接上了界面",
    area: "ingame",
    severity: "major",
    tags: ["自造缩写", "术语表", "高频"],
    location: "退魔页、材料槽 tooltip、经验栏、书架进度条",
    keys: [
      "jei.chiseled_enchanting_table.tooltip.cost_hint",
      "gui.chiseled_enchanting_table.cleanse.panel_rule_strip",
      "gui.chiseled_enchanting_table.cleanse.panel_traits",
      "gui.chiseled_enchanting_table.shelf_locked.tip_title",
      "gui.chiseled_enchanting_table.tab.cleanse",
    ],
    problem: [
      "「单洗」「全洗」是内部缩写，玩家词汇是「移除 1 条附魔」「清空全部附魔」。",
      "「轮播材料」是在描述 UI 控件的动画行为（图标在循环切换），不是在描述游戏规则 —— 玩家只想知道「这几样材料任选一个」。",
      "「实扣」「阶位」「词条」混用：同一个东西在界面上叫「词条」「附魔」「阶位」三种名字。",
      "panel_rule_strip 还漏了主语和数量：退魔砂 1–3 个、青金石 2–6 个会随附魔等级涨，文案一个数字都没给。",
      "英文更糟：panel_traits 写成 “Traits: %s (%s clean)”，母语读者会理解成「其中 %s 条是干净的」，和原意「%s 条可以被清掉」正好相反。",
    ],
    evidence: [
      {
        label: "data/.../disenchanting.json → targeted_strip.options",
        detail:
          "cleansing_grit base_count=1 / max_level_count=3；lapis_lazuli base_count=2 / max_level_count=6；均带 level_exponent，随等级递增。",
      },
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "jei.chiseled_enchanting_table.tooltip.cost_hint",
        before: "放入轮播材料中的任意一种即可",
        after: "下面这几样材料，任选一种放进去就行",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.cleanse.panel_rule_strip",
        before: "• 单洗：下槽退魔砂 + 背包青金石/发光墨囊/紫水晶（或凝晶）",
        after: "• 移除 1 条附魔：下格放 1–3 个退魔砂，背包里再备青金石 / 发光墨囊 / 紫水晶碎片（用量随等级涨），或直接用 1 颗秘法凝晶代替全部材料",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.cleanse.panel_traits",
        before: "词条：%s 条（可洗 %s）",
        after: "这件物品有 %s 条附魔，其中 %s 条可以移除",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.cleanse.panel_traits",
        before: "Traits: %s (%s clean)",
        after: "%s enchantments on this item, %s of them removable",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.shelf_locked.tip_title",
        before: "🔒 待解锁阶位：%s",
        after: "🔒 还不能附到 %s 级",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.tab.cleanse",
        before: "退魔洗练",
        after: "去除附魔",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.tab.cleanse.desc",
        before: "免费全洗或逐级降级返还经验球；也可单洗 1 条附魔或破除诅咒",
        after: "免费清空全部附魔或降一级，经验会以经验球退回来；也能只去掉其中 1 条，或解掉诅咒",
      },
    ],
  },
  {
    id: "I-06",
    title: "“温养”这种古语不该出现在耐久提示里",
    area: "ingame",
    severity: "minor",
    tags: ["用词生僻", "术语表"],
    location: "母本耐久 tooltip / 秘典第 5 章",
    keys: [
      "gui.chiseled_enchanting_table.grimoire.ch5.note_b",
      "gui.chiseled_enchanting_table.grimoire.ch3p0.s3",
      "item.chiseled_enchanting_table.master_tome_regen_hint",
    ],
    problem: [
      "「温养」在中文里属于中医 / 器物保养语境，Minecraft 玩家对应的概念是「自动回充 / 自动恢复」。",
      "英文侧写成 \"passive healing\"，也和耐久 / 充能体系对不上（healing 通常指生命值）。统一用「回充 / recharge」。",
      "同族生僻词还有：「铭刻」（≈ 附魔中）、「母本」（≈ 模板书）、「纂刻」（物品名，保留）、「拓印」（≈ 抄一本）。建议在术语表里定死，见下方对照表。",
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.grimoire.ch5.note_t",
        before: "雕纹母本耐久 · 无限与温养",
        after: "模板书的充能：怎么用完、怎么自动回满",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.grimoire.ch5.note_b",
        before:
          "16 durability per tier (copying a book costs 4); Infinity Tomes have 0 wear, and Broad Bookshelves speed up passive healing (38 / 42 tiers)!",
        after:
          "Each tome level holds %s charges and copying a book spends 4. Infinity tomes never wear down. Tomes recharge on their own, and more shelves nearby make it faster (speed-ups at %s and %s shelves).",
      },
    ],
  },
  {
    id: "I-07",
    title: "英文侧同一件道具有 4 个名字",
    area: "ingame",
    severity: "major",
    tags: ["术语不统一", "en_us"],
    location: "en_us.json 全文",
    keys: [
      "item.chiseled_enchanting_table.arcane_catalyst",
      "gui.chiseled_enchanting_table.grimoire.rec.arcane_catalyst",
      "gui.chiseled_enchanting_table.grimoire.diag.ch5_r2",
      "gui.chiseled_enchanting_table.epiphany.treasure_rule",
      "gui.chiseled_enchanting_table.cleanse.panel_rule_strip",
    ],
    problem: [
      "物品名是 Arcane Synthesis Crystal，但正文里出现过 \"Arcane Crystal\"、\"1x Crystal\"、\"Catalyst\"、\"(Catalyst exempt)\" 四种叫法，注册 ID 又是 arcane_catalyst。玩家在 JEI 里搜不到。",
      "中文同病：「秘法凝晶」在 panel_rule_strip 里被缩成「凝晶」。",
      "规则：物品名在任何正文里必须整名出现一次；空间不够就缩短句子，不要缩短专有名词。",
    ],
    fixes: [
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.grimoire.rec.arcane_catalyst",
        before: "Arcane Crystal (Universal Catalyst)",
        after: "Arcane Synthesis Crystal (replaces any material cost)",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.grimoire.diag.ch5_r2",
        before: "Route B: Research (Reagent OR 1x Catalyst · 1.4x Full XP)",
        after: "Route B — Study one book: regular materials or 1 Arcane Synthesis Crystal, at 1.4x XP",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.epiphany.treasure_rule",
        before:
          "Master Tomes use single basic currency; unowned Epiphanies require dual materials (Catalyst exempt)",
        after:
          "Already stored that book? One material is enough. Haven't stored it? You need two — or a single Arcane Synthesis Crystal instead.",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.epiphany.treasure_rule",
        before: "未存书的顿悟需双材料（或秘法凝晶）；存入雕纹书架后仅需单材料",
        after: "雕纹书架里已经有这本书：只要 1 种材料。还没有：要 2 种材料，或用 1 颗秘法凝晶代替。",
      },
    ],
  },
  {
    id: "I-08",
    title: "英文大量电报体，不成句",
    area: "ingame",
    severity: "minor",
    tags: ["英文语法", "en_us"],
    location: "en_us.json 秘典章节",
    keys: [
      "gui.chiseled_enchanting_table.grimoire.ch7.s3",
      "gui.chiseled_enchanting_table.grimoire.ch6.note_b",
      "gui.chiseled_enchanting_table.grimoire.ch8.s3",
      "gui.chiseled_enchanting_table.grimoire.ch4.m1",
    ],
    problem: [
      "\"Lock holds rolls even if mined!\" —— 主语不明（谁 mined 什么？），母语玩家要猜。",
      "\"Costs drop at %s and %s Wooden Shelves, becoming 100% FREE with %s+ qualifying Tomes!\" —— 全大写 FREE + 感叹号，像广告弹窗。",
      "\"spend Lv.3–10 (-1~3L)\" —— 自创单位 L，且和前面的 Lv. 不一致。",
      "\"Green Orbs Lv.X [1–3L Mass Mode]\" —— 方括号堆标签，不是句子。",
    ],
    fixes: [
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.grimoire.ch6.note_b",
        before:
          "Lock holds rolls even if mined! Note: Infinity only comes from loot chests, random vanilla table rolls, or copying an owned Master Tome.",
        after:
          "Locking keeps the current rolls even if you break the table and put it back. Infinity is the exception: it only comes from loot chests, random vanilla enchanting, or copying a tome you already own.",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.grimoire.ch7.s3",
        before: "Costs drop at %s and %s Wooden Shelves, becoming 100%% FREE with %s+ qualifying Tomes!",
        after: "At %s shelves the XP cost disappears, at %s shelves the materials are halved, and once you store %s high-tier tomes it is completely free.",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.grimoire.ch8.s3",
        before:
          "Strip 1 Enchant: On multi-enchant gear, spend Lv.3–10 (-1~3L) with Grit + Lapis/Glow Ink/Amethyst, vanilla Amethyst+Lapis, or 1x Crystal to remove 1 enchant cleanly.",
        after:
          "Remove one enchantment: on gear with several enchantments, pay 3–10 levels plus either Cleansing Grit with Lapis / Glow Ink Sac / Amethyst, plain Amethyst + Lapis, or 1 Arcane Synthesis Crystal. Everything else stays untouched.",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.grimoire.ch4.m1",
        before:
          "Green Orbs Lv.X [1–3L Mass Mode]: Stored books & Transmutations deduct only 1–3 whole levels and keep bar progress.",
        after:
          "Green orb — cheap mode: when the book is already stored, or you are transmuting an item, you only lose 1–3 whole levels and your XP bar progress is kept.",
      },
    ],
  },
  {
    id: "I-09",
    title: "状态只用符号表示：● 🔒 ⚡ 🗺 ⟳ 全靠猜",
    area: "ingame",
    severity: "minor",
    tags: ["无障碍", "配置界面"],
    location: "配置界面顶部状态条 / 生效范围标签",
    keys: [
      "config.chiseled_enchanting_table.session.offline",
      "config.chiseled_enchanting_table.session.dedicated_readonly",
      "config.chiseled_enchanting_table.scope.immediate",
      "config.chiseled_enchanting_table.scope.new_gen",
      "config.chiseled_enchanting_table.scope.restart",
    ],
    problem: [
      "「🗺 新区块/新开箱」看完还是不知道「我现在改了，已经生成的村庄会不会变」。",
      "符号承担了主要语义（● 表示连接状态、🔒 表示只读），屏幕朗读和低分辨率下全部丢失。",
      "「⟳ 需重启游戏」没说清是重启游戏还是重进存档 —— 其 detail 里说的是「启动阶段注册」，即必须重启客户端。",
      "建议：符号只做装饰，语义必须由文字承担。",
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "config.chiseled_enchanting_table.scope.new_gen",
        before: "🗺 新区块/新开箱",
        after: "🗺 只影响以后新生成的地方",
      },
      {
        lang: "zh_cn",
        key: "config.chiseled_enchanting_table.scope.new_gen.detail",
        before: "🗺 对新生成的结构区块及尚未开启的战利品容器生效。",
        after: "改完只对之后新生成的区块、以及还没被打开过的箱子生效。已经探索过的地方不会变。",
      },
      {
        lang: "zh_cn",
        key: "config.chiseled_enchanting_table.scope.restart",
        before: "⟳ 需重启游戏",
        after: "⟳ 要重启游戏才生效",
      },
      {
        lang: "zh_cn",
        key: "config.chiseled_enchanting_table.scope.restart.detail",
        before: "⟳ 物品默认堆叠组件在启动阶段注册，修改后需重启游戏生效。",
        after: "堆叠上限是在游戏启动时注册的，改完要完全退出并重开游戏才算数（只重进存档没用）。",
      },
      {
        lang: "zh_cn",
        key: "config.chiseled_enchanting_table.session.dedicated_readonly",
        before: "🔒 服务器只读检视",
        after: "🔒 只能看不能改（服务器规则由管理员统一设置）",
      },
    ],
  },
  {
    id: "I-10",
    title: "秘典 3p2「强行跳过」一句 90 字、三层括号",
    area: "ingame",
    severity: "minor",
    tags: ["超长句", "秘典"],
    location: "秘典 第 3 章补页",
    keys: ["gui.chiseled_enchanting_table.grimoire.ch3p2.s3", "gui.chiseled_enchanting_table.grimoire.ch3p2.s1"],
    problem: [
      "s3 一句话包含：代价、风险、退化结果、退化后身份、两个不同的概率上限，还嵌了括号中的括号。",
      "秘典每页宽度有限，长句会被折成 6–7 行，而旁边 s1/s2 只有 2 行，排版也乱。",
      "建议拆成「代价 / 风险 / 后果」三短句；概率上限用参数注入。",
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.grimoire.ch3p2.s3",
        before:
          "【不献祭强行跳过】：0 经验硬跳，但有实时概率把一册雕纹母本烧成「褪魔残卷」（退化后该雕纹书架仍算有书的广义书架；平时封顶 50%，借用含「无限」母本时封顶 70%）。",
        after:
          "【强行跳过】不花经验，但有概率烧掉一本雕纹书架里的模板书，把它变成褪魔残卷。失败率随剩余时间下降，平时最高 %s%%，借用带「无限」的模板时最高 %s%%。书烧坏了那个雕纹书架照样算进书架总数。",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.grimoire.ch3p2.s1",
        before:
          "广义书架越多、母本词条越多、等级越接近满级、词条越通用（如无限、经验修补），等待越久——单条封顶 5 分钟，排队可无限累加。",
        after:
          "这几样会让等待变长：书架越多、模板书越多、附魔等级越高、附魔越万能（比如无限、经验修补）。单条最多等 5 分钟，排队的条数不限。",
      },
    ],
  },
  {
    id: "I-11",
    title: "成就标题玩梗玩过头：「为什么会变成这样呢？」",
    area: "ingame",
    severity: "polish",
    tags: ["本地化", "成就"],
    location: "成就页",
    keys: [
      "advancements.chiseled_enchanting_table.all_enchant_book.title",
      "advancements.chiseled_enchanting_table.craft.description",
      "advancements.chiseled_enchanting_table.root.description",
    ],
    problem: [
      "「为什么会变成这样呢？」是特定动画梗，和「做出一本含全部附魔的书」没有语义联系；不玩这个梗的玩家只会困惑。成就标题可以俏皮，但要和行为挂钩。",
      "更硬的问题：root 和 craft 两个成就的 description 一模一样（都是「合成或升级你的第一台纂刻附魔台。」），成就树上会出现两条重复说明。",
      "建议 root 讲「你拿到了台子」，craft 讲「你用它附了第一次魔」，各司其职。",
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "advancements.chiseled_enchanting_table.all_enchant_book.title",
        before: "为什么会变成这样呢？",
        after: "全都要",
      },
      {
        lang: "zh_cn",
        key: "advancements.chiseled_enchanting_table.craft.description",
        before: "合成或升级你的第一台纂刻附魔台。",
        after: "用纂刻附魔台完成第一次附魔。",
      },
    ],
    note: "若坚持保留梗，建议至少把 description 写明白：「做出一本集齐了全部附魔的书。」",
  },
  {
    id: "I-12",
    title: "“经验返还”面板没告诉玩家到底退多少、按什么退",
    area: "ingame",
    severity: "minor",
    tags: ["信息缺失", "退魔页"],
    location: "退魔页经验 tooltip",
    keys: [
      "gui.chiseled_enchanting_table.xp_mode.refund.hint",
      "gui.chiseled_enchanting_table.cleanse.panel_rule_free",
      "gui.chiseled_enchanting_table.cleanse.all_sub_item",
    ],
    problem: [
      "「按相对等级与稀有度计算，不消耗任何材料」—— 「相对等级」是什么？玩家无法据此预判收益。",
      "代码里真实规则是：本台附上去的附魔按 xp_refund_scale（默认 1.00，即全额）退，外来附魔按 external_xp_refund_scale（默认 0.25）退。这个「本台 vs 外来」的区别对玩家收益影响巨大，却只在 pricing.cleanse_provenance 一行里以「溯源」二字带过。",
      "「涌出经验球」这种文学化动词，统一成「退还经验球」。",
    ],
    evidence: [
      { label: "ModRuntimeConfig.java:634-635", detail: "xpRefundScale = 1.00; externalXpRefundScale = 0.25;" },
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.xp_mode.refund.hint",
        before: "按相对等级与稀有度计算，不消耗任何材料",
        after: "不花材料。这台子自己附上去的附魔全额退经验，别处来的按 %s%% 退。",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.cleanse.all_sub_item",
        before: "零耗材 · 洗去非诅咒词条并涌出经验球",
        after: "不花材料 · 去掉全部非诅咒附魔，退还经验球",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.cleanse.all_sub_book",
        before: "零耗材 · 化为褪魔残卷并涌出经验球",
        after: "不花材料 · 退还经验球，书本身变成褪魔残卷",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.cleanse.panel_rule_free",
        before: "• 全洗 / 降级：0 材料，直接返还经验球",
        after: "• 清空全部 / 降一级：不花材料，经验直接以经验球退回",
      },
    ],
  },
];
