import type { Issue } from "./types";

/** 第一类：文本与实际代码 / 数据包的偏差 */
export const DRIFT_ISSUES: Issue[] = [
  {
    id: "D-01",
    title: "秘典第 1 章写的附魔台配方，和数据包里的真实配方对不上",
    area: "drift",
    severity: "blocker",
    tags: ["配方不符", "误导玩家", "zh+en"],
    location: "lang/zh_cn.json · lang/en_us.json（11 语言同源）",
    keys: ["gui.chiseled_enchanting_table.grimoire.ch1.c2"],
    problem: [
      "现文案说「2 颗钻石直接合成」。真实配方是 书×1 + 钻石×2 + 雕纹书架×1 + 哭泣的黑曜石×3，少写了 3 样材料里的全部关键项。",
      "现文案说「紫水晶 + 哭泣的黑曜石升级原版台」。真实升级配方还需要 雕纹书架×1，且紫水晶是 4 个碎片（不是紫水晶块）。",
      "这是游戏内**唯一**的新手引导页；玩家照着凑材料会直接失败，属于最高优先级的文本缺陷。",
      "README 第 27 行写的配方是对的，反而是游戏内说明书写错了 —— 内外两套说法不一致。",
    ],
    evidence: [
      {
        label: "data/chiseled_enchanting_table/recipe/chiseled_enchanting_table.json",
        detail: 'pattern [" B ", "DCD", "OOO"]，B=book、D=diamond、C=chiseled_bookshelf、O=crying_obsidian',
      },
      {
        label: "data/chiseled_enchanting_table/recipe/chiseled_enchanting_table_upgrade.json",
        detail: 'pattern ["ACA", "AEA", "OOO"]，A=amethyst_shard×4、C=chiseled_bookshelf、E=enchanting_table、O=crying_obsidian×3',
      },
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.grimoire.ch1.c2",
        before: "附魔台合成：2 颗钻石直接合成，或用紫水晶 + 哭泣的黑曜石升级原版台。",
        after:
          "附魔台有序合成：书 ×1 + 钻石 ×2 + 雕纹书架 ×1 + 哭泣的黑曜石 ×3；手上已有原版附魔台时，用紫水晶碎片 ×4 + 雕纹书架 ×1 + 哭泣的黑曜石 ×3 升级更省钻石。",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.grimoire.ch1.c2",
        before: "Table (Shaped): 2 Diamonds direct craft, OR upgrade a vanilla Enchanting Table.",
        after:
          "Table (Shaped): 1 Book + 2 Diamonds + 1 Chiseled Bookshelf + 3 Crying Obsidian. Already own a vanilla table? Upgrade it with 4 Amethyst Shards + 1 Chiseled Bookshelf + 3 Crying Obsidian and save the diamonds.",
      },
    ],
    note:
      "同一页的 ch1.c1（秘典的两种无序配方）经核对与 recipe JSON 完全一致，无需改动 —— 问题只出在 c2。",
  },
  {
    id: "D-02",
    title: "“书架经验减免”tooltip 把 40% 的含义讲反了",
    area: "drift",
    severity: "major",
    tags: ["数值口径错误", "tooltip"],
    location: "ChiseledEnchantingTableScreen.java:1325 使用",
    keys: ["gui.chiseled_enchanting_table.resonance.title"],
    problem: [
      "现文案：「书架经验减免：-X%（同种满级母本最高 -40%）」。",
      "代码里 40% 是**所有来源叠加后的总封顶**（MAX_TOTAL_XP_DISCOUNT_PERCENT），而「同种满级母本」单独能给的上限是 **15%**（MAX_SPECIFIC_ENCHANT_BONUS_PERCENT）。文案把总上限安在了单一来源头上。",
      "同一界面往下 3 行的 resonance.specific_line 又按真实口径显示「额外 -x%（共 -y%）」，玩家会看到两条互相矛盾的说明。",
      "40 还是写死的字面量：服务端把 max_total_xp_discount_percent 调成 25 之后，tooltip 依旧吹 40。",
    ],
    evidence: [
      {
        label: "mechanics/resonance/LibraryResonance.java:28-33",
        detail:
          "MAX_WOODEN_DISCOUNT_PERCENT=15 / MAX_GLOBAL_MASTERY_DISCOUNT_PERCENT=20 / MAX_BASE_XP_DISCOUNT_PERCENT=35 / MAX_SPECIFIC_ENCHANT_BONUS_PERCENT=15 / MAX_TOTAL_XP_DISCOUNT_PERCENT=40",
      },
    ],
    codeChange:
      "Component.translatable(\"...resonance.title\", this.menu.xpDiscountPercent) 需补第二个参数 libraryResonanceConfig().maxTotalXpDiscountPercent()。",
    fixes: [
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.resonance.title",
        before: "书架经验减免：-%s%%（同种满级母本最高 -40%%）",
        after: "书架经验减免：当前 -%s%%（所有来源叠加后，最多减到 -%s%%）",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.resonance.title",
        before: "Library Resonance: -%s%% Base XP (up to -40%% w/ Tome Mastery)",
        after: "Bookshelf XP discount: -%s%% now (all sources combined cap out at -%s%%)",
      },
    ],
  },
  {
    id: "D-03",
    title: "三个键 11 种语言全翻译了，代码却一次都没用过（死键）",
    area: "drift",
    severity: "major",
    tags: ["死键", "维护成本", "UX 缺口"],
    location: "全量 key 引用扫描（617 键 × 全仓库 grep）",
    keys: [
      "gui.chiseled_enchanting_table.resonance.cap",
      "gui.chiseled_enchanting_table.pricing.tome_wear_cost",
      "gui.chiseled_enchanting_table.btn.grimoire.title",
      "gui.chiseled_enchanting_table.btn.grimoire.desc",
    ],
    problem: [
      "resonance.cap「单条最高减免上限：-40% 经验」—— 代码从未 translatable 过它，而且内容本身就是错的（见 D-02）。11 份语言文件白维护 11 遍。",
      "pricing.tome_wear_cost「• 消耗雕纹母本耐久：-%s / %s」—— 实际只用 tome_wear_live / tome_wear_infinite 两个键，是上个版本的遗留。",
      "btn.grimoire.title / .desc —— **这是真正的 UX 缺口**：界面右上角那颗打开《纂刻秘典》的按钮，代码里只画了贴图和一层 hover 高亮（ChiseledEnchantingTableScreen.java:584-589），完全没有 setTooltipForNextFrame。玩家只看到一个不明图标，而现成的说明文案就躺在语言文件里没人用。",
    ],
    evidence: [
      {
        label: "grep -rn 'resonance.cap' --include=*.java src → 0 命中",
        detail: "同理 'pricing.tome_wear_cost' 与 'btn.grimoire' 均 0 命中（btn.grimoire 仅命中 PNG 资源名 BTN_GRIMOIRE）。",
      },
      {
        label: "ChiseledEnchantingTableScreen.java:584",
        detail: "ctx.blit(BTN_GRIMOIRE, ...) → if (isOverGrimoireButton) ctx.fill(...)；分支里没有任何 tooltip 调用。",
      },
    ],
    codeChange:
      "① 删除 resonance.cap 与 pricing.tome_wear_cost（11 个语言文件各一行）；② 在 isOverGrimoireButton 分支补 tooltip，复用 btn.grimoire.title/.desc；③ 把「未被引用的 key」加进 scripts/ci_static_checks.py 的 lang 校验。",
    fixes: [
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.btn.grimoire.title",
        before: "打开《纂刻秘典》",
        after: "📖 打开《纂刻秘典》（图文说明书）",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.btn.grimoire.desc",
        before: "查阅合成配方、书架档位、双经验机制与全流程演示图",
        after: "里面有：合成配方、书架要摆多少个、经验怎么扣、退魔怎么用，全都带图",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.btn.grimoire.title",
        before: "Open Chiseled Grimoire",
        after: "📖 Open the Chiseled Grimoire (illustrated manual)",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.btn.grimoire.desc",
        before: "View crafting recipes, shelf gates, XP modes & interactive diagrams",
        after: "Recipes, how many bookshelves you need, how XP is charged, and how to disenchant — all with diagrams.",
      },
    ],
  },
  {
    id: "D-04",
    title: "9 处把可配置数值写死在译文里，改了配置文案就开始骗人",
    area: "drift",
    severity: "major",
    tags: ["硬编码数值", "批量", "需同时改代码"],
    location: "lang/*.json（11 语言）+ 对应 Screen / Grimoire 调用点",
    keys: [
      "gui.chiseled_enchanting_table.resonance.wooden_locked",
      "gui.chiseled_enchanting_table.xp_mode.free_tome",
      "gui.chiseled_enchanting_table.cleanse.panel_resonance",
      "gui.chiseled_enchanting_table.epiphany.auto_hint",
      "gui.chiseled_enchanting_table.grimoire.ch4.res_b",
      "gui.chiseled_enchanting_table.grimoire.ch5.note_b",
      "gui.chiseled_enchanting_table.grimoire.ch6.s2",
      "gui.chiseled_enchanting_table.grimoire.ch8.s4",
      "jei.chiseled_enchanting_table.tooltip.bookshelf",
    ],
    problem: [
      "这些句子里的 12 / 15 / 40 / 38 / 42 / 10 分钟 / 12 级 / 35% 全是字面量，但它们在 ModRuntimeConfig.Draft 和 library_resonance.json 里**都是可调项**，配置界面还专门给了滑条。",
      "整合包作者一旦调低上限，游戏内说明依旧照着默认值宣传，玩家会把它当 bug 报上来。",
      "更尴尬的是同一句里经常「一半参数化、一半写死」：ch6.s2 的书架数用了 %s，紧挨着的「每 10 分钟」却是写死的。",
      "右栏给出的替换文案已全部改为 %s 占位，同时附上调用点要补的参数。",
    ],
    evidence: [
      { label: "ModRuntimeConfig.java:640-641", detail: "tier1Bookshelves = 12; tier2Bookshelves = 32;（均可配）" },
      { label: "ModRuntimeConfig.java:611-614", detail: "tomeRegenTier1Shelves = 38; tomeRegenTier2Shelves = 42;" },
      { label: "ModRuntimeConfig.java:626,638", detail: "epiphanyCycleSeconds = 600; cursePurgeXpCost = 12;" },
      { label: "LibraryResonance.java:31-33", detail: "MAX_BASE_XP_DISCOUNT_PERCENT=35；MAX_SPECIFIC_ENCHANT_BONUS_PERCENT=15；MAX_TOTAL_XP_DISCOUNT_PERCENT=40（均被 library_resonance.json 覆盖）" },
    ],
    codeChange:
      "各调用点补参数：resonance.wooden_locked 已有 2 个参数 → 第三个传 minDiscountBookshelves；xp_mode.free_tome / cleanse.panel_resonance / epiphany.auto_hint 目前是无参 translatable，需改成带参；秘典章节文本由 ArcaneGrimoireScreen 统一注入 cfg 值。",
    fixes: [
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.resonance.wooden_locked",
        before: "普通书架：%s / %s 个（满 12 个起减免经验）",
        after: "普通书架：%s / %s 个（满 %s 个才开始减经验）",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.xp_mode.free_tome",
        before: "书库共鸣（普通书架 ≥12）：免除全部经验损耗",
        after: "普通书架已满 %s 个：这一步不扣经验",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.cleanse.panel_resonance",
        before: "• 雕纹书架对应母本可额外减免单洗经验（最高 -15%）",
        after: "• 雕纹书架里放着同一条附魔的书时，移除它还能再便宜（最多 -%s%%）",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.epiphany.auto_hint",
        before: "每 10 分钟或附魔后自动刷新（锁定时除外）",
        after: "每 %s 分钟自动换一批，附魔成功后也会换；锁定期间不换",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.grimoire.ch6.s2",
        before: "方法二【加权顿悟】：满 %s 个普通书架每 10 分钟刷新宝藏（最多 %s 格；越通用的神级词条如经验修补越珍稀）。",
        after: "方法二【碰运气】：普通书架满 %s 个后，每 %s 分钟自动刷新一批宝藏附魔（同时最多 %s 条）。越万能的词条（比如经验修补）出得越少。",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.grimoire.ch8.s4",
        before:
          "破除诅咒：花 12 级经验（吃最高 -35% 公共减免），用退魔砂+恶魂之泪/金苹果、原版 2 恶魂之泪+2 金苹果或 1 颗秘法凝晶净化诅咒，其余附魔全留！",
        after:
          "去掉诅咒：花 %s 级经验（书架最多帮你省 %s%%），材料三选一 —— 退魔砂＋恶魂之泪/金苹果、2 恶魂之泪＋2 金苹果，或 1 颗秘法凝晶。装备上其它附魔一条不动。",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.grimoire.ch5.note_b",
        before: "每级 16 点耐久（抄书 -4）；附带「无限」零损耗，随周围广义书架数自动温养回复（38/42 架两档提速）！",
        after: "母本每级有 %s 点充能，抄一本书扣 4 点。带「无限」的母本不掉充能。附近书架够多会自动回充，%s 架和 %s 架各提一次速。",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.grimoire.ch4.res_b",
        before:
          "普通书架最高 -%s%% + 雕纹总藏书最高 -%s%%（公共部分封顶 -%s%%）；已有同种藏书再减 -%s%%，总计最高 -40%%。",
        after:
          "普通书架最多 -%s%%，雕纹书架藏书最多 -%s%%，两者合计先封顶在 -%s%%；若雕纹里正好有同一条附魔的书，再额外减 -%s%%。全部加起来最多 -%s%%。",
      },
      {
        lang: "zh_cn",
        key: "jei.chiseled_enchanting_table.tooltip.bookshelf",
        before: "普通书架最高升满已有附魔；雕纹书架藏书无损直附对应等级，最高减免 40% 经验",
        after: "普通书架：把装备上已有的附魔一级级升到满级。雕纹书架里的附魔书：同等级直接附上，最多省 %s%% 经验。",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.epiphany.auto_hint",
        before: "Auto-refreshes every 10 min or after enchanting (unless locked)",
        after: "A new batch rolls every %s min, and right after you enchant — unless you locked it",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.cleanse.panel_resonance",
        before: "• Chiseled Master Tomes also grant up to -15% strip XP discount",
        after: "• Storing the same enchantment in a Chiseled Bookshelf makes removal cheaper too (up to -%s%%)",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.grimoire.ch8.s4",
        before:
          "Purge Curse: Spend 12L Full XP (up to -35% shelf discount) with Grit + Ghast Tear/Golden Apple, 2 Ghast Tears + 2 Golden Apples, or 1x Crystal to remove curses!",
        after:
          "Remove a curse: costs %s levels (bookshelves shave off up to %s%%). Pick one: Cleansing Grit + Ghast Tear/Golden Apple, 2 Ghast Tears + 2 Golden Apples, or 1 Arcane Synthesis Crystal. Every other enchantment stays.",
      },
    ],
  },
  {
    id: "D-05",
    title: "“呼吸空间”被写成开关，代码里其实是按比例打折",
    area: "drift",
    severity: "major",
    tags: ["机制描述错误", "玩家踩坑"],
    location: "BookshelfProgression.java:653-674",
    keys: [
      "config.chiseled_enchanting_table.opt.require_breathing_room.desc",
      "gui.chiseled_enchanting_table.grimoire.ch3.lead",
    ],
    problem: [
      "文案：「防止把附魔台完全埋入实心书架墙内，需保留邻近通透格」「只需台面周围留足呼吸空间（≥6 格空位且正上方不封死）即可生效」。读起来是「够 6 格 = 满效，不够 = 失效」的二值判断。",
      "代码真实行为是**线性折算**：开放格 < 门槛时，有效书架数 = 原始书架数 × 开放格 / 门槛。摆了 38 个书架但只留 3 格空位，实际只按 19 个算 —— 玩家会以为是 bug。",
      "另外「正上方封死」是**直接归零**，和缺格子的打折完全不同量级，文案把两件事混在一个括号里。",
      "玩家侧完全没有提示：界面只有一个 resonance.cramped 红字，不告诉你损失了多少。",
    ],
    evidence: [
      {
        label: "BookshelfProgression.java:663-673",
        detail:
          "if (ceilingBlocked) return 0;  …  if (openAdjacentBlocks >= minOpen) return rawShelves;  …  return floor(rawShelves * openAdjacentBlocks / minOpen);",
      },
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "config.chiseled_enchanting_table.opt.require_breathing_room.desc",
        before: "防止把附魔台完全埋入实心书架墙内，需保留邻近通透格",
        after:
          "别把附魔台砌死在墙里：台子正上方被挡住，所有书架直接不算数；周围空格不够时，书架按「实际空格 ÷ 要求空格」的比例打折计入。",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.grimoire.ch3.lead",
        before:
          "自动检测水平 ±%s 格、上下 ±%s 格（7×5×7）；只需台面周围留足呼吸空间（≥6 格空位且正上方不封死）即可生效。",
        after:
          "自动扫描水平 ±%s 格、上下 ±%s 格。台子正上方必须留空，否则书架全部作废；周围至少留 %s 格空位才算满效，少一格就按比例少算书架。",
      },
      {
        lang: "en_us",
        key: "gui.chiseled_enchanting_table.grimoire.ch3.lead",
        before:
          "Scans +/-%s horizontal & +/-%s vertical blocks (7×5×7) as long as open breathing room remains around the table.",
        after:
          "Scans %s blocks sideways and %s blocks up/down. Keep the block above the table clear or no shelf counts at all, and leave %s open spaces around it — fewer spaces means proportionally fewer shelves count.",
      },
      {
        lang: "en_us",
        key: "config.chiseled_enchanting_table.opt.require_breathing_room.desc",
        before: "Penalizes burying the table inside solid blocks without open space",
        after:
          "Block the space directly above the table and no shelf counts at all. Leave too few open cells around it and shelves count only in proportion to the space you did leave.",
      },
    ],
    note:
      "有意思的是英文版用的是 “Penalizes…”，比中文的「防止…需保留」更接近代码真相 —— 同一个键两种语言讲了两套规则，这正好说明为什么要以代码为准统一一次。",
  },
  {
    id: "D-06",
    title: "配置项描述里「3×2×3 共 17 格」自己算错了",
    area: "drift",
    severity: "minor",
    tags: ["算术错误", "配置界面"],
    location: "ConfigCatalog.java:529-530（显示 \"x / 17\"）",
    keys: ["config.chiseled_enchanting_table.opt.min_open_adjacent_blocks.desc"],
    problem: [
      "3 × 2 × 3 = 18，不是 17。玩家对着配置界面算半天也对不上。",
      "17 这个数来自 BookshelfProgression 把取值 clamp 在 1..17 —— 即 3×3×2 的 18 格**减去附魔台自身占的那一格**。文案没说减了什么。",
      "顺带：现文案「发挥 100% 书架效能所需的通透格数」是机翻腔，「通透格」不是玩家词汇。",
    ],
    evidence: [
      { label: "BookshelfProgression.java:168", detail: "minOpenAdjacentBlocks = clampInt(minOpenAdjacentBlocks, 1, 17);" },
      { label: "ConfigCatalog.java:530", detail: 'd -> d.minOpenAdjacentBlocks + " / 17"' },
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "config.chiseled_enchanting_table.opt.min_open_adjacent_blocks",
        before: "最少通透邻格数量",
        after: "台子周围至少要空几格",
      },
      {
        lang: "zh_cn",
        key: "config.chiseled_enchanting_table.opt.min_open_adjacent_blocks.desc",
        before: "台周 3×2×3 共 17 格中发挥 100% 书架效能所需的通透格数",
        after: "附魔台贴身的 3×3×2 范围共 18 格，除去台子本身还有 17 格。这 17 格里至少要空出多少格，书架才算满效；空得不够就按比例少算。",
      },
      {
        lang: "en_us",
        key: "config.chiseled_enchanting_table.opt.min_open_adjacent_blocks.desc",
        before: "Open passable cells in the 3x2x3 zone needed for 100% shelf power",
        after: "The 3×3×2 shell around the table holds 18 cells; 17 of them are free space once you subtract the table itself. This is how many of those 17 must stay empty for shelves to count at full strength.",
      },
    ],
  },
  {
    id: "D-07",
    title: "“白板最多附到中级”只在默认模式下成立，配置能改成三种行为",
    area: "drift",
    severity: "minor",
    tags: ["条件缺失", "配置相关"],
    location: "ModRuntimeConfig.BlankMaxTierMode（HALF_CEIL / LEVEL_ONE_ONLY / FULL_CURVE）",
    keys: [
      "gui.chiseled_enchanting_table.grimoire.ch3.t1",
      "gui.chiseled_enchanting_table.shelf_locked.tip_blank_cap",
    ],
    problem: [
      "两处都把「未附魔物品最多附到一半等级」当成铁律写死，但 blank_max_tier_mode 有三档：折半向上取整（默认）、仅 I 级入门、可直达满级。",
      "两处对同一件事还用了两套词：ch3.t1 说「等级上限的一半」，tip_blank_cap 说「中级」。「中级」在 Minecraft 语境里不存在。",
      "replacement 保留举例（最高 5 级 → 最多 3 级），但把它写成「默认规则下」。",
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.grimoire.ch3.t1",
        before:
          "普通书架直附：给未附魔的装备或普通书附魔，单靠普通书架最高附到等级上限的一半（如最高 5 级最多附到 3 级）。",
        after:
          "普通书架给白板物品附魔：默认只能附到该附魔最高等级的一半（最高 5 级 → 最多 III 级）。想一步到位请在雕纹书架里放对应附魔书，或在配置里改「白板物品直附上限」。",
      },
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.shelf_locked.tip_blank_cap",
        before:
          "无雕纹藏书时，未附魔物品最多直附到中级——可先附低级再逐级升满，或在雕纹书架放入对应附魔书",
        after:
          "雕纹书架里没有这条附魔的书时，白板物品默认只能附到一半等级。两条出路：先附低级再用普通书架一级级升满，或者把这条附魔的书放进雕纹书架。",
      },
    ],
  },
  {
    id: "D-08",
    title: "同一份中文里 “1~3 级” 和 “1–3 级” 混用",
    area: "drift",
    severity: "polish",
    tags: ["排版一致性", "全角半角"],
    location: "zh_cn.json：3 处用 ~，15 处用 –",
    keys: [
      "jei.chiseled_enchanting_table.info.station",
      "jei.chiseled_enchanting_table.info.bookshelf",
      "gui.chiseled_enchanting_table.xp_mode.full.master_hint",
    ],
    problem: [
      "JEI 说明和秘典讲的是同一个机制，一边写「1~3 级」一边写「1–3 级」，看起来像两套数值。",
      "中文排版里半角波浪号 ~ 做区间是不规范写法，统一用 en dash（–）或「至」。",
      "同类问题还有：✦ / ★ / 🔒 / ⚡ 等装饰符号在同一面板里风格不统一（见 I-09）。",
    ],
    fixes: [
      {
        lang: "zh_cn",
        key: "gui.chiseled_enchanting_table.xp_mode.full.master_hint",
        before: "放入同级附魔书至雕纹书架后，每次仅扣 1~3 级经验",
        after: "把同等级的附魔书放进雕纹书架，之后每次只扣 1–3 级经验",
      },
      {
        lang: "zh_cn",
        key: "jei.chiseled_enchanting_table.info.bookshelf",
        before:
          "放在纂刻附魔台周围 7×5×7 范围内的雕纹书架会将藏书作为母本提供给附魔台，对应附魔每次仅扣 1~3 级经验（默认每级耐久 16 点）。",
        after:
          "附魔台周围 7×5×7 内的雕纹书架，会把里面的附魔书借给附魔台当模板。用模板附魔每次只扣 1–3 级经验，模板每级有 16 点充能。",
      },
    ],
  },
];
