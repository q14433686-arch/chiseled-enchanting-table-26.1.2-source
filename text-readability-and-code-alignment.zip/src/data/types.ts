export type Severity = "blocker" | "major" | "minor" | "polish";
export type Area = "drift" | "ingame" | "docs";

export type LangFile = "zh_cn" | "en_us" | "md" | "java";

export interface Fix {
  /** 语言文件 key；markdown / java 改动可留空 */
  key?: string;
  lang: LangFile;
  /** 显示用的文件名，默认由 lang 推断 */
  file?: string;
  before: string;
  after: string;
}

export interface Evidence {
  label: string;
  detail: string;
}

export interface Issue {
  id: string;
  title: string;
  area: Area;
  severity: Severity;
  tags: string[];
  /** 问题所在文件（展示用） */
  location: string;
  /** 受影响的 lang key */
  keys: string[];
  /** 现象 / 为什么是缺陷 */
  problem: string[];
  /** 代码证据 */
  evidence?: Evidence[];
  /** 可直接替换的文本 */
  fixes: Fix[];
  /** 仅改文案不够、必须同时动代码时的说明 */
  codeChange?: string;
  note?: string;
}

export const SEVERITY_META: Record<
  Severity,
  { label: string; short: string; dot: string; chip: string; ring: string }
> = {
  blocker: {
    label: "阻断级",
    short: "阻断",
    dot: "bg-rose-500",
    chip: "bg-rose-500/15 text-rose-300 border-rose-500/30",
    ring: "ring-rose-500/40",
  },
  major: {
    label: "严重",
    short: "严重",
    dot: "bg-amber-500",
    chip: "bg-amber-500/15 text-amber-300 border-amber-500/30",
    ring: "ring-amber-500/40",
  },
  minor: {
    label: "一般",
    short: "一般",
    dot: "bg-sky-500",
    chip: "bg-sky-500/15 text-sky-300 border-sky-500/30",
    ring: "ring-sky-500/40",
  },
  polish: {
    label: "打磨",
    short: "打磨",
    dot: "bg-emerald-500",
    chip: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
    ring: "ring-emerald-500/40",
  },
};

export const AREA_META: Record<Area, { label: string; desc: string; icon: string }> = {
  drift: {
    label: "文本 ↔ 代码偏差",
    desc: "文案描述的规则与 Java / JSON 实际行为对不上，或键名已死",
    icon: "⚠",
  },
  ingame: {
    label: "游戏内文本",
    desc: "GUI、秘典、JEI/REI、成就、配置界面里玩家能看到的字",
    icon: "🎮",
  },
  docs: {
    label: "游戏外文档",
    desc: "README、安装说明、CI 段落等仓库门面文字",
    icon: "📄",
  },
};

export const LANG_META: Record<LangFile, { label: string; path: string }> = {
  zh_cn: {
    label: "zh_cn.json",
    path: "src/client/resources/assets/chiseled_enchanting_table/lang/zh_cn.json",
  },
  en_us: {
    label: "en_us.json",
    path: "src/client/resources/assets/chiseled_enchanting_table/lang/en_us.json",
  },
  md: { label: "README.md", path: "README.md" },
  java: { label: "Java", path: "src/..." },
};
