export interface GlossaryRow {
  current: string;
  currentEn: string;
  suggested: string;
  suggestedEn: string;
  reason: string;
  hits: number;
}

/** 统一术语表：左边是现在在用的，右边是建议统一改成的 */
export const GLOSSARY: GlossaryRow[] = [
  {
    current: "广义书架",
    currentEn: "Broad Bookshelves",
    suggested: "书架总数（含雕纹）",
    suggestedEn: "total shelf count",
    reason: "集合论命名，玩家无法从字面推出含义；英文更会被误读成「宽书架」。",
    hits: 14,
  },
  {
    current: "母本",
    currentEn: "Master Tome",
    suggested: "模板书",
    suggestedEn: "stored book / template book",
    reason: "「母本」是印刷/文献学术语。玩家理解的是「放在书架里当模板的那本书」。",
    hits: 31,
  },
  {
    current: "温养",
    currentEn: "passive healing",
    suggested: "自动回充",
    suggestedEn: "recharge",
    reason: "中医/器物用语；英文 healing 在 MC 语境里指回血，和充能体系冲突。",
    hits: 6,
  },
  {
    current: "单洗 / 全洗",
    currentEn: "Strip 1 / Disenchant All",
    suggested: "移除 1 条附魔 / 清空全部附魔",
    suggestedEn: "remove one / clear all",
    reason: "「洗」是国内刷词条黑话，新玩家和海外玩家都不通用。",
    hits: 18,
  },
  {
    current: "轮播材料",
    currentEn: "(cycling icon)",
    suggested: "可替换材料（任选一种）",
    suggestedEn: "any one of these",
    reason: "描述的是 UI 动画行为，不是游戏规则。玩家只关心「选哪个」。",
    hits: 4,
  },
  {
    current: "阶位",
    currentEn: "tier",
    suggested: "等级",
    suggestedEn: "level",
    reason: "原版中文只有「等级」。同义词多一个，玩家就要多猜一次。",
    hits: 9,
  },
  {
    current: "词条",
    currentEn: "trait",
    suggested: "附魔",
    suggestedEn: "enchantment",
    reason: "「词条」来自 RPG 装备属性，本 mod 里指的就是附魔本身，没必要换词。",
    hits: 22,
  },
  {
    current: "铭刻 / 纂刻 / 拓印",
    currentEn: "inscribe / chisel / copy",
    suggested: "附魔（动词）/ 抄写（复制书）",
    suggestedEn: "enchant / copy",
    reason: "三个近义动词指同一类操作。保留「纂刻」作方块名，正文动词统一。",
    hits: 27,
  },
  {
    current: "秘法凝晶 / 凝晶",
    currentEn: "Arcane Synthesis Crystal / Arcane Crystal / Catalyst / Crystal",
    suggested: "秘法凝晶（全称，不缩写）",
    suggestedEn: "Arcane Synthesis Crystal",
    reason: "同一件道具 4 种叫法，JEI 搜索会落空。专有名词不缩写。",
    hits: 11,
  },
  {
    current: "实扣 / 需扣",
    currentEn: "deduct / consume",
    suggested: "实际扣除",
    suggestedEn: "actually costs",
    reason: "双字缩写在 tooltip 里省不了几像素，却要玩家反应一下。",
    hits: 7,
  },
  {
    current: "涌出经验球",
    currentEn: "spawns XP orbs",
    suggested: "退还经验球",
    suggestedEn: "refunds XP orbs",
    reason: "「涌出」是文学化动词，没说清这是「退给你」还是「掉在地上」。",
    hits: 5,
  },
  {
    current: "顿悟 / 宝藏顿悟",
    currentEn: "Treasure Epiphany",
    suggested: "保留（已是专名），但首次出现要解释",
    suggestedEn: "keep, but explain on first use",
    reason: "作为系统专名可以留，问题在于玩家第一次看到它时没有任何解释。",
    hits: 36,
  },
];

export interface Principle {
  title: string;
  body: string;
  bad: string;
  good: string;
}

export const PRINCIPLES: Principle[] = [
  {
    title: "一句话只说一件事",
    body: "tooltip / 秘典一行的宽度在 36–44 个汉字之间。超过就会折行，超过两次折行玩家就不读了。分号是长句的警报器。",
    bad: "把附魔书放进周围 7×5×7 雕纹书架作为母本，每次仅扣 1~3 级经验（默认每级 16 点耐久，耗尽退一级）；升级已有附魔自动扣除已付成本，退魔洗练按本台溯源全额返还经验球……",
    good: "把附魔书放进附魔台周围的雕纹书架，就能照着它附魔。\n每次只扣 1–3 级经验。\n书每级有 16 点充能，用完降一级。",
  },
  {
    title: "先说结果，再说条件",
    body: "玩家扫视界面时只看前半句。把「能得到什么」放前面，「需要什么」放后面。",
    bad: "🔒 需 %s 普通书架（当前 %s）",
    good: "🔒 还差 %s 个普通书架才能升到这一级（现有 %s 个）",
  },
  {
    title: "数字能从配置读就不要写死",
    body: "译文里的每一个阿拉伯数字都要问一句：它在 config 里可调吗？可调就必须是 %s。否则整合包一改，文案立刻变成假话。",
    bad: "普通书架：%s / %s 个（满 12 个起减免经验）",
    good: "普通书架：%s / %s 个（满 %s 个才开始减经验）",
  },
  {
    title: "专有名词不缩写、不换说法",
    body: "一个概念只允许有一个名字。空间不够就砍句子，不要砍名词。",
    bad: "秘法凝晶 → 凝晶；Arcane Synthesis Crystal → Crystal / Catalyst",
    good: "全文一律「秘法凝晶」/「Arcane Synthesis Crystal」",
  },
  {
    title: "损失提示必须包含「发生了什么 + 为什么 + 下次怎么办」",
    body: "玩家只在倒霉的时候才会认真读提示。这时候给他看「灵脉串扰」是在火上浇油。",
    bad: "⚠ 超载「无限」母本灵脉串扰！%s 抄错降为 %s 级！",
    good: "⚠ 强行跳过失手了：《%s》被抄坏，等级掉到 %s 级。下次改用「献祭经验」跳过可以零风险。",
  },
  {
    title: "符号只做装饰，语义交给文字",
    body: "🔒 ⚡ 🗺 ● 在小字号、色盲模式和屏幕朗读下都会丢失。去掉所有图标后，句子必须仍然完整。",
    bad: "🗺 新区块/新开箱",
    good: "🗺 只影响以后新生成的地方",
  },
];

export const CI_CHECKS = [
  {
    cmd: "lang-unused-keys",
    desc: "扫出 lang 文件里存在、但全仓库 Java 从未 translatable 过的 key（本次扫到 3 组，含 1 个真实 UX 缺口）。",
  },
  {
    cmd: "lang-hardcoded-numbers",
    desc: "对照 ConfigCatalog 的可调项清单，报出译文中写死的同名数值（12 / 32 / 38 / 40 / 15 / 35 / 10 分钟…）。",
  },
  {
    cmd: "lang-format-arity",
    desc: "校验 11 份语言文件里同一 key 的 %s 个数一致，且与 Java 调用点传参数量一致。",
  },
  {
    cmd: "lang-line-length",
    desc: "GUI / tooltip 类 key 超过 44 个汉字（或 90 个拉丁字符）时告警，强制拆句。",
  },
  {
    cmd: "lang-glossary",
    desc: "术语黑名单：广义书架 / 温养 / 单洗 / 轮播 / 阶位 / 凝晶（缩写）出现即失败。",
  },
  {
    cmd: "recipe-doc-sync",
    desc: "把 recipe/*.json 的材料清单与秘典 ch1 文案做字符串比对，防止 D-01 再次发生。",
  },
];
