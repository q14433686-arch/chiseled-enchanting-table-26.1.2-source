import { DRIFT_ISSUES } from "./issuesDrift";
import { INGAME_ISSUES } from "./issuesIngame";
import { DOCS_ISSUES } from "./issuesDocs";
import type { Issue, Severity, Area } from "./types";

export * from "./types";
export * from "./glossary";

export const ISSUES: Issue[] = [...DRIFT_ISSUES, ...INGAME_ISSUES, ...DOCS_ISSUES];

export const REPO = {
  name: "q14433686-arch/chiseled-enchanting-table-26.1.2-source",
  url: "https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source",
  branch: "chiseled-enchanting-table-26.1.2-source",
  version: "1.1.0",
  mc: "26.1.2 (Fabric)",
  langKeys: 617,
  langFiles: 11,
  javaFiles: 92,
};

export function countBy<T extends string>(items: Issue[], pick: (i: Issue) => T) {
  return items.reduce<Record<string, number>>((acc, it) => {
    const k = pick(it);
    acc[k] = (acc[k] ?? 0) + 1;
    return acc;
  }, {});
}

export const SEVERITY_COUNTS = countBy<Severity>(ISSUES, (i) => i.severity);
export const AREA_COUNTS = countBy<Area>(ISSUES, (i) => i.area);

export const TOTAL_FIXES = ISSUES.reduce((n, i) => n + i.fixes.length, 0);
export const TOTAL_KEYS = new Set(ISSUES.flatMap((i) => i.fixes.map((f) => f.key).filter(Boolean))).size;
export const CODE_CHANGE_COUNT = ISSUES.filter((i) => i.codeChange).length;

/** 生成可直接覆盖进语言文件的 JSON 片段 */
export function buildPatch(lang: "zh_cn" | "en_us", issues: Issue[] = ISSUES) {
  const out: Record<string, string> = {};
  for (const issue of issues) {
    for (const fix of issue.fixes) {
      if (fix.lang === lang && fix.key) out[fix.key] = fix.after;
    }
  }
  return out;
}

export function patchToString(lang: "zh_cn" | "en_us", issues: Issue[] = ISSUES) {
  const obj = buildPatch(lang, issues);
  const keys = Object.keys(obj);
  if (keys.length === 0) return "{}";
  const body = keys
    .map((k) => `    ${JSON.stringify(k)}: ${JSON.stringify(obj[k])}`)
    .join(",\n");
  return `{\n${body}\n}`;
}
