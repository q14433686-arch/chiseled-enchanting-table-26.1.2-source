import type { Issue } from "./types";

/** 第三类：游戏外（README / 文档）措辞 */
export const DOCS_ISSUES: Issue[] = [
  {
    id: "R-01",
    title: "README 前 22 行全是版本号、基线、CI 和 issue 链接，玩家看不到「这 mod 干嘛的」",
    area: "docs",
    severity: "major",
    tags: ["信息架构", "README"],
    location: "README.md 第 1–23 行",
    keys: [],
    problem: [
      "读者打开仓库的第一个问题是「它改了什么游戏体验」。现在要滚过免责声明、版本号、Fabric Loader 版本、1.0.3 基线、issue #3、CI triad 之后，第 23 行才看到一句 “A Minecraft Fabric mod that enhances the enchanting experience.”",
      "而这句本身等于没说 —— 「增强附魔体验」可以形容任何一个附魔 mod。",
      "免责声明重要，但应当缩成两行并放在简介之后；维护者才关心的基线/CI 信息应下沉到独立小节或 docs/。",
      "右侧给出可直接替换的 README 开头（整段替换第 1–23 行）。",
    ],
    fixes: [
      {
        lang: "md",
        file: "README.md（替换第 1–23 行）",
        before: `# Chiseled Enchanting Table — Unofficial 26.1.2 Port

![banner](./banner.png)

> ⚠️ **Unofficial community port.** This repository is a community-maintained, unofficial port of
> [Sacramentix/chiseled-enchanting-table](...) updated to **Minecraft 26.1.2** on Fabric. …

**Current version:** \`1.1.0\` *(unofficial-port SemVer; see \`CURRENT_BASELINE.md\` for details)*
**Target:** Minecraft \`26.1.2\`, Fabric Loader \`>=0.19.3\`, Fabric API \`0.151.0+26.1.2\`, Java \`>=25\`.

📖 **Full Gameplay Wiki & Upstream Comparison …**

\`1.1.0\` builds on the \`1.0.3\` 26.3-sync baseline ([issue #3](...) worldgen deadlock fix, S2C
enchantment costs, 11 languages, and CI triad — see docs/reports/SYNC_FROM_26_3_REPORT.md) with a
comprehensive progression, balance, UI/UX, and recipe-viewer overhaul; …

A Minecraft Fabric mod that enhances the enchanting experience.`,
        after: `# Chiseled Enchanting Table — Unofficial 26.1.2 Port

![banner](./banner.png)

**Pick the enchantment you want, instead of gambling at the vanilla table.**

Put bookshelves around the Chiseled Enchanting Table and a list of enchantments appears.
Click one and it goes straight onto your gear. Store an enchanted book in a chiseled
bookshelf and that enchantment becomes permanently available for 1–3 levels a pop.
Changed your mind? The Cleanse tab gives the XP back — for free.

* 🎯 **Choose your enchantment** — no rerolling, no lapis lottery.
* 📚 **Bookshelves actually matter** — more shelves unlock higher levels and cut XP costs.
* ♻️ **Free disenchanting** — strip one enchantment, drop a level, or wipe the item clean.
* 📖 **Built-in illustrated manual** — the Chiseled Grimoire explains everything in-game.
* 🧩 **JEI & REI support, 11 languages, server-synced costs.**

| | |
|---|---|
| **Minecraft** | 26.1.2 (Fabric) |
| **Needs** | Fabric Loader ≥ 0.19.3 · Fabric API 0.151.0+26.1.2 · Java ≥ 25 |
| **Version** | 1.1.0 |
| **Manual** | [docs/WIKI.md](docs/WIKI.md) · [CHANGELOG.md](CHANGELOG.md) |

> ⚠️ **This is an unofficial community port.** The original mod is
> [Sacramentix/chiseled-enchanting-table](https://github.com/Sacramentix/chiseled-enchanting-table);
> all credit for the original design, code and assets goes to its author, and it is reused under the
> original [MIT License](LICENSE). The original author does not maintain or endorse this port, so
> please report problems **here**, not upstream.`,
      },
    ],
  },
  {
    id: "R-02",
    title: "小标题写成论文摘要：“Conservation-Verified Dual-Mode XP Formula”",
    area: "docs",
    severity: "major",
    tags: ["学术腔", "README"],
    location: "README.md · Concept 第 2 条",
    keys: [],
    problem: [
      "“Three-track library progression, Live World Sync & Conservation-Verified Dual-Mode XP Formula” —— 一个小标题里 3 个自造复合名词，没有任何一个在游戏里出现过。",
      "“Inductive XP Conservation & Standalone-Vanilla Cleanse Alternatives” 同理。",
      "README 的小标题是目录，应当用动词短语描述玩家能做什么，而不是描述实现保证了什么数学性质。",
    ],
    fixes: [
      {
        lang: "md",
        file: "README.md（Concept 小标题）",
        before:
          "* **Three-track library progression, Live World Sync & Conservation-Verified Dual-Mode XP Formula (see docs/WIKI.md)**:",
        after:
          "* **Your bookshelves decide what you can enchant** (full numbers in [docs/WIKI.md](docs/WIKI.md)):",
      },
      {
        lang: "md",
        file: "README.md（Concept 第 3 小点标题）",
        before:
          "* **Inductive XP Conservation & Standalone-Vanilla Cleanse Alternatives**: full wipes (`DISENCHANT_ALL`) and step-downs (`DOWNGRADE_ENCHANTMENT`) satisfy exact telescoping conservation (`V[k] - V[j] <= Cost_min(j -> k)` across all `maxLevel = 1..255`), while targeted trait stripping and curse purging support both custom catalysts (`Cleansing Grit`, `Arcane Synthesis Crystal`) and pure standalone vanilla item bundles (`disenchanting.json`).",
        after:
          "* **Disenchanting never loses you XP**: wiping an item or dropping an enchantment by one level always refunds at least as much as you paid, at every level from I to MAX — so there is no \"enchant then strip\" exploit and no hidden tax either. Removing a single enchantment or lifting a curse costs materials, and you can always choose between the mod's own reagents (Cleansing Grit, Arcane Synthesis Crystal) and a plain-vanilla item bundle. All of it is data-driven in `disenchanting.json`. *(The formal conservation proof lives in [docs/WIKI.md](docs/WIKI.md).)*",
      },
    ],
  },
  {
    id: "R-03",
    title: "Installation 一上来就让玩家去翻 GitHub Actions 的 artifact",
    area: "docs",
    severity: "major",
    tags: ["信息架构", "README"],
    location: "README.md · Installation",
    keys: [],
    problem: [
      "现文：“Grab the latest jar from the `build` workflow's artifact on the branch you want (Actions → build → Artifacts, kept 14 days) or from `release_output/…`”。普通玩家不知道什么是 workflow artifact，也不会注意到 14 天后链接会失效。",
      "紧接着的括号 “(the dev sandbox this port is maintained in has neither, which is why CI does the compiling — see below)” 是在跟自己解释开发环境，与安装无关。",
      "建议把「玩家怎么装」和「开发者怎么编译」彻底分成两节，开发者那节再讲 sandbox 的事。",
    ],
    fixes: [
      {
        lang: "md",
        file: "README.md（替换 Installation 整节）",
        before: `## Installation

Grab the latest \`chiseled-enchanting-table-1.1.0.jar\` from the \`build\` workflow's artifact on the
branch you want (Actions → *build* → **Artifacts**, kept 14 days) or from
\`release_output/chiseled_enchanting_table_1_1_0/\` when a release is staged there, and drop it into
your Fabric \`mods/\` folder alongside Fabric API \`0.151.0+26.1.2\`.

To build it yourself: JDK 25 + network access to \`maven.fabricmc.net\` (the dev sandbox this port is
maintained in has neither, which is why CI does the compiling — see below):`,
        after: `## Install

1. Install **Fabric Loader 0.19.3+** for Minecraft **26.1.2**.
2. Drop **Fabric API 0.151.0+26.1.2** into your \`mods/\` folder.
3. Drop **\`chiseled-enchanting-table-1.1.0.jar\`** in next to it.

Where to get the jar: the newest build is attached to the **Actions → build → Artifacts**
of this branch. GitHub deletes those after 14 days, so if the list is empty just re-run the
workflow (or grab a staged copy from \`release_output/\`). This port is not on Modrinth or
CurseForge, and it will never appear under the original mod's listing.

JEI or REI are optional. With either installed you get a **Chiseled Enchanting** tab that
shows, for any book, every item it can go on — and for any item, every book that fits it,
with the real XP and material cost your server is using.

## Build it yourself

You need **JDK 25** and network access to \`maven.fabricmc.net\`.

\`\`\`bash
chmod +x ./gradlew
python3 scripts/compat_check.py   # offline data-pack sanity check, no JDK needed
./gradlew build                   # jars land in build/libs/
\`\`\`

> Heads-up for contributors: this port is maintained in a sandbox with no JDK and no access to
> the Fabric maven, so the authoritative compile happens on GitHub Actions and the log is pushed
> back to the branch. See [docs/ci/README.md](docs/ci/README.md).`,
      },
    ],
  },
  {
    id: "R-04",
    title: "Usage 一节是纯废话",
    area: "docs",
    severity: "minor",
    tags: ["空话", "README"],
    location: "README.md 第 68 行",
    keys: [],
    problem: [
      "“Once installed, the Chiseled Enchanting Table will be available in your game. Craft it using the new recipe and start enchanting!” —— 三句话零信息量，且「the new recipe」没说是哪条。",
      "这段是从上游 README 原样继承的，没跟着这个移植版的新内容更新。",
      "玩家在这里真正需要的是「装完之后第一步做什么」。",
    ],
    fixes: [
      {
        lang: "md",
        file: "README.md（替换 Usage 整节）",
        before:
          "## Usage\n\nOnce installed, the Chiseled Enchanting Table will be available in your game. Craft it using the new recipe and start enchanting!",
        after: `## First five minutes

1. **Craft the table** — 1 Book + 2 Diamonds + 1 Chiseled Bookshelf + 3 Crying Obsidian.
   Already have a vanilla enchanting table? Upgrade it instead: 4 Amethyst Shards +
   1 Chiseled Bookshelf + 3 Crying Obsidian. Short on obsidian? 8 Obsidian + 1 Ghast Tear
   gives you 8 Crying Obsidian.
2. **Craft the manual** — Book and Quill + Chiseled Bookshelf (or Depleted Tome + Ink Sac).
   You can also open it from the button in the top-right corner of the table's screen.
3. **Put bookshelves around it** — the table scans 7 blocks across and 5 blocks tall.
   Leave the block above the table clear, and keep some space around it.
4. **Open the table, drop in your gear**, pick an enchantment from the list on the left,
   and put the material it asks for in the bottom slot.
5. **Store an enchanted book in a chiseled bookshelf** to unlock that enchantment permanently
   at 1–3 levels per use.`,
      },
    ],
  },
  {
    id: "R-05",
    title: "Forge 一节是上游原文，语法有误且第一人称与“非官方移植”身份冲突",
    area: "docs",
    severity: "minor",
    tags: ["继承未改", "语法"],
    location: "README.md 第 113–116 行",
    keys: [],
    problem: [
      "“But if the mod get more popular, I might have a look at it!” —— 主谓不一致（get → gets）。",
      "这段里的 “I” 指的是**上游作者**，但整个 README 的语境是这个非官方移植仓库；读者会以为移植维护者在承诺做 Forge 版。",
      "Contributing / Inspiration 两节也是原样继承，“I've looked at RPG enchanting table…” 同样是上游第一人称。",
    ],
    fixes: [
      {
        lang: "md",
        file: "README.md（替换 Forge 整节）",
        before:
          "## Forge (or other modloader) port\n\nNot planned at the moment.\nBut if the mod get more popular, I might have a look at it!",
        after:
          "## Forge / NeoForge\n\nNot planned. This port only targets Fabric. If someone wants to take a Forge version on,\nopen an issue first so we can avoid duplicate work.",
      },
      {
        lang: "md",
        file: "README.md（Inspiration 节，补一句归属）",
        before:
          "## Inspiration\n\nI've looked at RPG enchanting table to get the base concept done https://github.com/TheRedBrain/rpg-enchanting\nIf you are looking for a more RPG approch be sure to check out this mod!",
        after:
          "## Inspiration\n\nThe original author built the core concept after looking at\n[TheRedBrain/rpg-enchanting](https://github.com/TheRedBrain/rpg-enchanting) —\nworth a look if you want a more RPG-flavoured take on enchanting.",
      },
    ],
    note: "注意原文还有拼写错误 approch → approach。",
  },
  {
    id: "R-06",
    title: "README 把具体 commit 号和 run id 写死，发布当天就过期",
    area: "docs",
    severity: "minor",
    tags: ["会过期", "README"],
    location: "README.md · Continuous integration",
    keys: [],
    problem: [
      "“**Status: green.** On commit `da77188` (2026-10-21): `compile-check` run `39670181582` (`BUILD SUCCESSFUL in 48s` …), `build.yml` run `39670181557` …”",
      "下一次 push 之后这段就是错的，而且没人会记得更新。README 里不该放会腐烂的事实。",
      "正确做法是放 badge（自动反映当前状态），历史留在 docs/ci/README.md。",
    ],
    fixes: [
      {
        lang: "md",
        file: "README.md（替换 CI 状态段）",
        before:
          "**Status: green.** On commit `da77188` (2026-10-21): `compile-check` run `39670181582` (`BUILD SUCCESSFUL in 48s`, `compileJava` + `compileClientJava` with JEI and REI enabled, 2 deprecation warnings from JEI's API), `build.yml` run `39670181557` (static gates → full build + jar artifact → `no-viewers`), `consistency.yml` run `39670181572`. `docs/ci/README.md` records the history, including the two failed runs and what each one taught us.",
        after:
          "![build](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/actions/workflows/build.yml/badge.svg)\n![compile-check](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/actions/workflows/compile-check.yml/badge.svg)\n![consistency](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/actions/workflows/consistency.yml/badge.svg)\n\nThree workflows have to be green before a build is considered good: `compile-check` (compiles with\nJEI and REI on), `build` (static checks, full jar, plus a run with both viewers off) and\n`consistency` (version numbers agree across all five places they are written down).\nRun history and post-mortems of past failures: [docs/ci/README.md](docs/ci/README.md).",
      },
    ],
  },
  {
    id: "R-07",
    title: "面向玩家的段落里塞 tag ID、gamma 曲线和枚举常量",
    area: "docs",
    severity: "minor",
    tags: ["受众错位", "README"],
    location: "README.md · Concept 第 2 条正文",
    keys: [],
    problem: [
      "“Regular Bookshelves (`#chiseled_enchanting_table:regular_bookshelves`, configurable `7×5×7`) unlock blank inscriptions up to mid-tier (`ceil(maxLevel / 2)`), smoothly scale … along `0..38` shelves (`gamma = 1.25`: `I(0) → II(7) → III(16) → IV(27) → V(38)`)”",
      "一句话里同时出现 tag ID、向上取整函数、gamma 参数 —— 这些是数据包作者要的，不是玩家要的。",
      "但其中的 `I(0) → II(7) → III(16) → IV(27) → V(38)` 恰恰是玩家最想要的信息，被埋在括号里了。应当提升为一张表。",
    ],
    fixes: [
      {
        lang: "md",
        file: "README.md（Concept → 书架档位，改写为表格）",
        before:
          "**Regular Bookshelves (`#chiseled_enchanting_table:regular_bookshelves`, configurable `7×5×7`)** unlock blank inscriptions up to mid-tier (`ceil(maxLevel / 2)`), smoothly scale upgrades on already-inscribed gear/books up to `MAX` along `0..38` shelves (`gamma = 1.25`: `I(0) → II(7) → III(16) → IV(27) → V(38)`), grant XP reduction starting at `12+` shelves, and at **`32+` Bookshelves** awaken **Treasure Epiphany**.",
        after: `**Regular bookshelves** decide how far you can push an enchantment. For a 5-level
enchantment such as Sharpness:

| Bookshelves | What you can reach |
|---|---|
| 0 | Level I |
| 7 | Level II |
| 12 | Level II, and XP costs start dropping |
| 16 | Level III |
| 27 | Level IV |
| 32 | Level IV, and Treasure Epiphany wakes up |
| 38 | Level V (max) |

A brand-new, unenchanted item can only be taken to half of an enchantment's max level
(III out of V) unless the matching book is stored in a chiseled bookshelf — upgrade it
step by step from there.

*Data-pack authors: the shelf tag is \`#chiseled_enchanting_table:regular_bookshelves\`, the scan
box and the 0..38 curve (gamma 1.25) are configurable; see [docs/EXTENDING.md](docs/EXTENDING.md).*`,
      },
    ],
  },
  {
    id: "R-08",
    title: "CI 一节用“triad”“sister port”“arena/** 分支”等只有维护者懂的说法",
    area: "docs",
    severity: "polish",
    tags: ["内部黑话", "README"],
    location: "README.md · Continuous integration 开头",
    keys: [],
    problem: [
      "“CI mirrors the triad used by the sister port …, because this port is developed in a sandbox that cannot reach `maven.fabricmc.net` … and therefore cannot compile locally — the compile has to happen on Actions and the log has to come back to the branch.” 是一个 60 词的单句，三个从句。",
      "“triad”“sister port”“the log has to come back to the branch” 都是项目内部说法，外部贡献者要读两遍。",
      "建议：一句话说清「为什么 CI 这么特别」，细节留给表格和 docs/ci/README.md。",
    ],
    fixes: [
      {
        lang: "md",
        file: "README.md（CI 节开头）",
        before:
          "CI mirrors the triad used by the sister port [q14433686-arch/TaCZ_Refabricated_Unofficial](...) and by this repository's own `26.3` branch, because this port is developed in a sandbox that cannot reach `maven.fabricmc.net` (nor the JEI/REI mavens) and therefore cannot compile locally — the compile has to happen on Actions and the log has to come back to the branch.",
        after:
          "This port is developed in an environment with no JDK and no access to the Fabric maven, so nothing can be compiled locally. Every compile therefore runs on GitHub Actions, and the resulting log is committed back into the branch so it can be read offline. The same setup is used by [TaCZ_Refabricated_Unofficial](https://github.com/q14433686-arch/TaCZ_Refabricated_Unofficial).",
      },
    ],
  },
];
