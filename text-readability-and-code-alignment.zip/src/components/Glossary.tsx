import { CI_CHECKS, GLOSSARY, PRINCIPLES } from "../data";
import { CopyButton } from "./CopyButton";

export function Glossary() {
  const tsv = GLOSSARY.map(
    (g) => `${g.current}\t${g.currentEn}\t${g.suggested}\t${g.suggestedEn}\t${g.reason}`,
  ).join("\n");

  return (
    <section id="glossary" className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">统一术语表</h2>
          <p className="mt-2 max-w-3xl text-[14.5px] leading-relaxed text-slate-400">
            单条文案改好了，整体仍然会乱 —— 因为同一个概念在不同界面叫不同名字。
            下表是建议钉死的对照关系，改完全文替换一遍即可。
          </p>
        </div>
        <CopyButton text={tsv} label="复制为 TSV" />
      </div>

      <div className="overflow-hidden rounded-2xl border border-white/10">
        <div className="scroll-thin overflow-x-auto">
          <table className="w-full min-w-[840px] border-collapse text-left">
            <thead>
              <tr className="bg-white/[0.04] text-[11px] uppercase tracking-wider text-slate-500">
                <th className="px-4 py-3 font-semibold">现用（中）</th>
                <th className="px-4 py-3 font-semibold">现用（英）</th>
                <th className="px-4 py-3 font-semibold text-emerald-400/80">建议（中）</th>
                <th className="px-4 py-3 font-semibold text-emerald-400/80">建议（英）</th>
                <th className="px-4 py-3 font-semibold">为什么</th>
                <th className="px-4 py-3 text-right font-semibold">出现</th>
              </tr>
            </thead>
            <tbody>
              {GLOSSARY.map((g) => (
                <tr key={g.current} className="border-t border-white/5 align-top">
                  <td className="px-4 py-3 text-[13px] font-medium text-rose-300/80">{g.current}</td>
                  <td className="px-4 py-3 font-mono text-[11.5px] text-rose-300/60">{g.currentEn}</td>
                  <td className="px-4 py-3 text-[13px] font-semibold text-emerald-300">{g.suggested}</td>
                  <td className="px-4 py-3 font-mono text-[11.5px] text-emerald-300/70">{g.suggestedEn}</td>
                  <td className="px-4 py-3 text-[12.5px] leading-relaxed text-slate-400">{g.reason}</td>
                  <td className="px-4 py-3 text-right font-mono text-[12px] text-slate-500">{g.hits}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div id="principles" className="mt-16">
        <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">六条写作底线</h2>
        <p className="mt-2 max-w-3xl text-[14.5px] leading-relaxed text-slate-400">
          本次所有改写都遵循下面这几条。把它们写进 CONTRIBUTING，比逐条审查更省事。
        </p>

        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {PRINCIPLES.map((p, i) => (
            <div key={p.title} className="rounded-2xl border border-white/8 bg-white/[0.02] p-5">
              <div className="flex items-baseline gap-2.5">
                <span className="font-mono text-xs text-violet-400">{String(i + 1).padStart(2, "0")}</span>
                <h3 className="text-[15px] font-semibold text-slate-100">{p.title}</h3>
              </div>
              <p className="mt-2 text-[13px] leading-relaxed text-slate-400">{p.body}</p>
              <div className="mt-3.5 space-y-2">
                <div className="rounded-lg border border-rose-500/15 bg-rose-500/[0.06] px-3 py-2">
                  <div className="text-[10px] font-semibold uppercase tracking-wider text-rose-400/80">✗</div>
                  <pre className="mt-1 whitespace-pre-wrap break-words font-mono text-[11.5px] leading-relaxed text-rose-200/70">
                    {p.bad}
                  </pre>
                </div>
                <div className="rounded-lg border border-emerald-500/15 bg-emerald-500/[0.06] px-3 py-2">
                  <div className="text-[10px] font-semibold uppercase tracking-wider text-emerald-400/80">✓</div>
                  <pre className="mt-1 whitespace-pre-wrap break-words font-mono text-[11.5px] leading-relaxed text-emerald-100/85">
                    {p.good}
                  </pre>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div id="ci" className="mt-16">
        <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
          让它不再发生：补 6 个静态检查
        </h2>
        <p className="mt-2 max-w-3xl text-[14.5px] leading-relaxed text-slate-400">
          仓库已有
          <code className="mx-1 rounded bg-white/5 px-1.5 py-0.5 font-mono text-[12px] text-slate-300">
            scripts/ci_static_checks.py
          </code>
          做 11 语言键位对齐，但只查「有没有这个键」，不查「这句话对不对」。建议把下面几项加进去，
          全部可离线运行、不需要 JDK。
        </p>
        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          {CI_CHECKS.map((c) => (
            <div
              key={c.cmd}
              className="flex gap-3 rounded-xl border border-white/8 bg-white/[0.02] p-4 transition hover:border-emerald-400/25"
            >
              <span className="mt-0.5 font-mono text-emerald-400">$</span>
              <div>
                <code className="font-mono text-[12.5px] font-semibold text-emerald-300">{c.cmd}</code>
                <p className="mt-1 text-[12.5px] leading-relaxed text-slate-400">{c.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
