import { useMemo, useState } from "react";
import { cn } from "../utils/cn";
import { CopyButton } from "./CopyButton";
import { ISSUES, buildPatch, patchToString } from "../data";

type Lang = "zh_cn" | "en_us";

export function PatchExport() {
  const [lang, setLang] = useState<Lang>("zh_cn");
  const [onlyDrift, setOnlyDrift] = useState(false);

  const issues = useMemo(
    () => (onlyDrift ? ISSUES.filter((i) => i.area === "drift") : ISSUES),
    [onlyDrift],
  );

  const text = useMemo(() => patchToString(lang, issues), [lang, issues]);
  const count = useMemo(() => Object.keys(buildPatch(lang, issues)).length, [lang, issues]);

  const download = () => {
    const blob = new Blob([text], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${lang}.patch.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <section id="patch" className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
      <div className="mb-6">
        <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">
          一键导出：可直接合并的语言补丁
        </h2>
        <p className="mt-2.5 max-w-3xl text-[14.5px] leading-relaxed text-slate-400">
          下面是把本报告所有建议文本整理成的 JSON 片段，键名与仓库现有
          <code className="mx-1 rounded bg-white/5 px-1.5 py-0.5 font-mono text-[12px] text-slate-300">
            lang/*.json
          </code>
          完全一致。直接覆盖同名键即可；
          <span className="text-amber-300">带 %s 的条目需要先按「需同时改代码」一栏补齐调用点参数</span>，
          否则 Minecraft 会把多余的 %s 原样显示出来。
        </p>
      </div>

      <div className="overflow-hidden rounded-2xl border border-white/10 bg-[#0d1018]">
        <div className="flex flex-wrap items-center gap-3 border-b border-white/8 bg-white/[0.03] px-4 py-3">
          <div className="flex rounded-lg border border-white/10 bg-black/30 p-0.5">
            {(["zh_cn", "en_us"] as Lang[]).map((l) => (
              <button
                key={l}
                type="button"
                onClick={() => setLang(l)}
                className={cn(
                  "rounded-md px-3 py-1.5 font-mono text-xs transition",
                  lang === l ? "bg-violet-600 text-white" : "text-slate-400 hover:text-slate-200",
                )}
              >
                {l}.json
              </button>
            ))}
          </div>

          <label className="flex cursor-pointer items-center gap-2 text-xs text-slate-400">
            <input
              type="checkbox"
              checked={onlyDrift}
              onChange={(e) => setOnlyDrift(e.target.checked)}
              className="h-3.5 w-3.5 accent-violet-500"
            />
            只导出「文本 ↔ 代码偏差」类
          </label>

          <span className="ml-auto font-mono text-[11px] text-slate-500">{count} 个键</span>
          <CopyButton text={text} label="复制全部" compact />
          <button
            type="button"
            onClick={download}
            className="rounded-md border border-emerald-400/30 bg-emerald-400/10 px-2.5 py-1 text-[11px] font-medium text-emerald-300 transition hover:bg-emerald-400/20"
          >
            下载 .json
          </button>
        </div>

        <pre className="scroll-thin max-h-[32rem] overflow-auto p-4 font-mono text-[12px] leading-relaxed text-slate-300">
          {text}
        </pre>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        {[
          {
            t: "① 覆盖键值",
            d: "把上面的键逐条合并进 zh_cn.json / en_us.json。其余 9 种语言按 en_us 为准重翻，不要机翻中文。",
          },
          {
            t: "② 补齐参数",
            d: "D-02 / D-04 / D-05 等条目要求调用点多传 1–3 个参数，先改 Java 再换文案，否则会出现 %s 残留。",
          },
          {
            t: "③ 删掉死键",
            d: "resonance.cap 与 pricing.tome_wear_cost 在 11 份语言文件里各删一行；btn.grimoire.* 保留并在代码里接上 tooltip。",
          },
        ].map((s) => (
          <div key={s.t} className="rounded-xl border border-white/8 bg-white/[0.02] p-4">
            <div className="text-sm font-semibold text-slate-200">{s.t}</div>
            <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-500">{s.d}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
