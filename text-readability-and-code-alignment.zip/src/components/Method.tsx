import { REPO } from "../data";

const STEPS = [
  {
    n: "01",
    t: "全量取文本",
    d: `克隆分支 ${REPO.branch}，取出 lang/ 下 11 份语言文件共 ${REPO.langKeys} 个 key，以及 README.md / docs/WIKI.md / CHANGELOG.md。`,
    code: "git clone --depth 1 --branch chiseled-enchanting-table-26.1.2-source …",
  },
  {
    n: "02",
    t: "反查引用，找死键",
    d: `把每个 key 拿去 grep 全部 ${REPO.javaFiles} 份 Java 源码与数据包 JSON，扣掉由字符串拼接动态生成的 config.* / grimoire.ch{n}.* 之后，剩下的就是没人用的死键。`,
    code: "for k in keys: grep -r \"$k\" --include=*.java src → 0 hits ?",
  },
  {
    n: "03",
    t: "数值对账",
    d: "把译文里出现的每个阿拉伯数字，对照 ModRuntimeConfig.Draft 默认值、LibraryResonance 常量与 data/**/*.json，逐一判断「写死」还是「应该参数化」。",
    code: "ModRuntimeConfig.java:598-646 · LibraryResonance.java:28-33 · disenchanting.json",
  },
  {
    n: "04",
    t: "配方对账",
    d: "把秘典第 1 章描述的材料清单，与 data/chiseled_enchanting_table/recipe/ 下 7 份配方 JSON 做逐项比对 —— D-01 就是这样被揪出来的。",
    code: "recipe/chiseled_enchanting_table.json: [\" B \", \"DCD\", \"OOO\"]",
  },
  {
    n: "05",
    t: "行为对账",
    d: "读 BookshelfProgression / LibraryResonance 的实际分支逻辑，看文案描述的是不是同一套规则（呼吸空间「打折 vs 开关」就是这样发现的）。",
    code: "return floor(rawShelves * openAdjacentBlocks / minOpen);",
  },
  {
    n: "06",
    t: "按人话标准重写",
    d: "对每条问题文本按本页「六条写作底线」改写，保持 %s 占位符数量与调用点一致，长度控制在原文 ±30% 以内以免 GUI 溢出。",
    code: "zh_cn.json / en_us.json → 可直接覆盖的键值对",
  },
];

export function Method() {
  return (
    <section id="method" className="border-t border-white/8 bg-white/[0.015]">
      <div className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
        <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">扫描方法</h2>
        <p className="mt-2 max-w-3xl text-[14.5px] leading-relaxed text-slate-400">
          本报告不是凭感觉挑刺。每条结论都能在仓库里复现 —— 下面是完整步骤。
        </p>

        <ol className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {STEPS.map((s) => (
            <li key={s.n} className="rounded-2xl border border-white/8 bg-[#0d1018]/70 p-5">
              <div className="flex items-baseline gap-2.5">
                <span className="font-mono text-sm text-violet-400">{s.n}</span>
                <h3 className="text-[15px] font-semibold text-slate-100">{s.t}</h3>
              </div>
              <p className="mt-2 text-[13px] leading-relaxed text-slate-400">{s.d}</p>
              <pre className="scroll-thin mt-3 overflow-x-auto rounded-lg bg-black/40 px-3 py-2 font-mono text-[11px] leading-relaxed text-emerald-300/70">
                {s.code}
              </pre>
            </li>
          ))}
        </ol>

        <div className="mt-8 rounded-2xl border border-amber-500/20 bg-amber-500/[0.05] p-5">
          <h3 className="text-sm font-semibold text-amber-300">一句话结论</h3>
          <p className="mt-2 max-w-4xl text-[14px] leading-relaxed text-amber-100/80">
            这套文本的问题不在「写得少」，而在<b className="text-amber-200">写得太像设计文档</b>：
            把内部实现概念（广义书架、母本、溯源、守恒、telescoping conservation）原样端给玩家，
            同时把玩家真正要的信息（配方到底几样材料、书架少一格会损失多少、强行跳过到底亏了什么）
            压缩进括号里。
            改法也很简单 —— <b className="text-amber-200">名词挑玩家认识的，数字从 config 里读，一句话只说一件事。</b>
          </p>
        </div>
      </div>
    </section>
  );
}
