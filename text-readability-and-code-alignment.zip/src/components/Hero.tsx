import { AREA_COUNTS, AREA_META, ISSUES, REPO, SEVERITY_COUNTS, SEVERITY_META, TOTAL_FIXES, TOTAL_KEYS, CODE_CHANGE_COUNT } from "../data";
import { cn } from "../utils/cn";

function Stat({ value, label, accent }: { value: string | number; label: string; accent?: string }) {
  return (
    <div className="rounded-xl border border-white/8 bg-white/[0.03] px-4 py-3">
      <div className={cn("font-mono text-2xl font-semibold tabular-nums", accent ?? "text-slate-100")}>
        {value}
      </div>
      <div className="mt-0.5 text-[11.5px] text-slate-500">{label}</div>
    </div>
  );
}

export function Hero() {
  return (
    <header className="relative overflow-hidden border-b border-white/8">
      <div className="grid-bg absolute inset-0 opacity-70" />
      <div className="absolute -top-40 left-1/4 h-96 w-96 rounded-full bg-violet-600/20 blur-[120px]" />
      <div className="absolute -top-24 right-10 h-80 w-80 rounded-full bg-emerald-500/10 blur-[120px]" />

      <div className="relative mx-auto max-w-6xl px-5 pb-14 pt-16 sm:px-8 sm:pt-20">
        <div className="inline-flex items-center gap-2 rounded-full border border-violet-400/25 bg-violet-500/10 px-3 py-1 text-[11.5px] text-violet-200">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-violet-400" />
          文本审查报告 · 全量扫描 {REPO.langKeys} 条 lang key × {REPO.langFiles} 语言 + {REPO.javaFiles} 份 Java 源码
        </div>

        <h1 className="mt-5 text-balance text-3xl font-bold leading-[1.15] tracking-tight text-white sm:text-5xl">
          把<span className="bg-gradient-to-r from-violet-400 to-fuchsia-400 bg-clip-text text-transparent">不说人话</span>的文本
          <br className="hidden sm:block" />
          全部换成能直接粘贴的句子
        </h1>

        <p className="mt-5 max-w-3xl text-[15px] leading-relaxed text-slate-400">
          针对 <span className="font-mono text-slate-300">{REPO.name}</span>（{REPO.mc} · v{REPO.version}）
          的游戏内可见文本、游戏外文档措辞，以及
          <span className="text-slate-200">「文案说的」与「代码真正做的」之间的偏差</span>
          做一次性清查。每条问题都给出定位、证据，以及一段<span className="text-emerald-300">可直接覆盖进语言文件的替换文本</span>。
        </p>

        <div className="mt-7 flex flex-wrap items-center gap-3">
          <a
            href="#issues"
            className="rounded-lg bg-violet-600 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-violet-500"
          >
            查看 {ISSUES.length} 条问题
          </a>
          <a
            href="#patch"
            className="rounded-lg border border-emerald-400/30 bg-emerald-400/10 px-4 py-2.5 text-sm font-semibold text-emerald-300 transition hover:bg-emerald-400/20"
          >
            一键导出 JSON 补丁
          </a>
          <a
            href={REPO.url}
            target="_blank"
            rel="noreferrer"
            className="rounded-lg border border-white/10 px-4 py-2.5 text-sm text-slate-300 transition hover:border-white/25 hover:text-white"
          >
            打开仓库 ↗
          </a>
        </div>

        <div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <Stat value={ISSUES.length} label="问题总数" accent="text-violet-300" />
          <Stat value={TOTAL_FIXES} label="可直接替换的文本段" accent="text-emerald-300" />
          <Stat value={TOTAL_KEYS} label="涉及 lang key" />
          <Stat value={CODE_CHANGE_COUNT} label="需同时改代码" accent="text-orange-300" />
          <Stat value={SEVERITY_COUNTS.blocker ?? 0} label="阻断级（直接误导玩家）" accent="text-rose-400" />
          <Stat value={3} label="从未被引用的死键" accent="text-amber-300" />
        </div>

        <div className="mt-6 grid gap-3 sm:grid-cols-3">
          {(Object.keys(AREA_META) as Array<keyof typeof AREA_META>).map((key) => (
            <a
              key={key}
              href="#issues"
              className="group rounded-xl border border-white/8 bg-white/[0.02] p-4 transition hover:border-violet-400/30 hover:bg-violet-500/[0.06]"
            >
              <div className="flex items-baseline justify-between">
                <span className="text-sm font-semibold text-slate-200">
                  {AREA_META[key].icon} {AREA_META[key].label}
                </span>
                <span className="font-mono text-lg text-violet-300">{AREA_COUNTS[key] ?? 0}</span>
              </div>
              <p className="mt-1.5 text-[12px] leading-relaxed text-slate-500">{AREA_META[key].desc}</p>
            </a>
          ))}
        </div>

        <div className="mt-6 flex flex-wrap gap-2">
          {(Object.keys(SEVERITY_META) as Array<keyof typeof SEVERITY_META>).map((s) => (
            <span
              key={s}
              className={cn("rounded-full border px-3 py-1 text-[11.5px] font-medium", SEVERITY_META[s].chip)}
            >
              {SEVERITY_META[s].label} · {SEVERITY_COUNTS[s] ?? 0}
            </span>
          ))}
        </div>
      </div>
    </header>
  );
}
