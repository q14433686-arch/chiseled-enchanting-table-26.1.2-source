import { useState } from "react";
import { cn } from "../utils/cn";
import { CopyButton } from "./CopyButton";
import { AREA_META, LANG_META, SEVERITY_META, type Issue } from "../data";

function LangBadge({ lang }: { lang: Issue["fixes"][number]["lang"] }) {
  const map: Record<string, string> = {
    zh_cn: "bg-rose-500/10 text-rose-300 border-rose-500/25",
    en_us: "bg-sky-500/10 text-sky-300 border-sky-500/25",
    md: "bg-amber-500/10 text-amber-300 border-amber-500/25",
    java: "bg-orange-500/10 text-orange-300 border-orange-500/25",
  };
  return (
    <span className={cn("rounded border px-1.5 py-0.5 font-mono text-[10px] tracking-tight", map[lang])}>
      {LANG_META[lang].label}
    </span>
  );
}

export function IssueCard({ issue, index }: { issue: Issue; index: number }) {
  const [open, setOpen] = useState(index < 2);
  const sev = SEVERITY_META[issue.severity];
  const area = AREA_META[issue.area];

  return (
    <article
      id={issue.id}
      className={cn(
        "animate-rise overflow-hidden rounded-2xl border border-white/8 bg-[#0d1018]/80 backdrop-blur",
        "transition hover:border-white/15",
      )}
    >
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-start gap-4 p-5 text-left"
      >
        <span className="mt-0.5 flex h-7 shrink-0 items-center rounded-md border border-white/10 bg-white/5 px-2 font-mono text-xs text-slate-400">
          {issue.id}
        </span>

        <span className="min-w-0 flex-1">
          <span className="flex flex-wrap items-center gap-2">
            <span className={cn("rounded border px-1.5 py-0.5 text-[11px] font-semibold", sev.chip)}>
              {sev.label}
            </span>
            <span className="rounded border border-white/10 bg-white/5 px-1.5 py-0.5 text-[11px] text-slate-400">
              {area.icon} {area.label}
            </span>
            {issue.tags.map((t) => (
              <span key={t} className="text-[11px] text-slate-500">
                #{t}
              </span>
            ))}
          </span>
          <h3 className="mt-2 text-balance text-[15px] font-semibold leading-snug text-slate-100 sm:text-base">
            {issue.title}
          </h3>
          <p className="mt-1.5 font-mono text-[11px] text-slate-500">{issue.location}</p>
        </span>

        <span className="mt-1 flex shrink-0 items-center gap-2">
          <span className="hidden rounded-full bg-violet-500/10 px-2 py-0.5 text-[11px] text-violet-300 sm:inline">
            {issue.fixes.length} 条替换
          </span>
          <svg
            viewBox="0 0 24 24"
            className={cn("h-4 w-4 text-slate-500 transition", open && "rotate-180")}
            fill="none"
            stroke="currentColor"
            strokeWidth={2}
          >
            <path d="m6 9 6 6 6-6" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
      </button>

      {open && (
        <div className="space-y-5 border-t border-white/8 px-5 pb-6 pt-5">
          {issue.keys.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {issue.keys.map((k) => (
                <code
                  key={k}
                  className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-[10.5px] text-slate-400"
                >
                  {k}
                </code>
              ))}
            </div>
          )}

          <div>
            <h4 className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
              问题剖析
            </h4>
            <ul className="space-y-1.5">
              {issue.problem.map((p, i) => (
                <li key={i} className="flex gap-2.5 text-[13.5px] leading-relaxed text-slate-300">
                  <span className="mt-[7px] h-1 w-1 shrink-0 rounded-full bg-slate-600" />
                  <span>{p}</span>
                </li>
              ))}
            </ul>
          </div>

          {issue.evidence && issue.evidence.length > 0 && (
            <div className="rounded-xl border border-white/8 bg-black/30 p-3.5">
              <h4 className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-500">
                代码 / 数据证据
              </h4>
              <ul className="space-y-2">
                {issue.evidence.map((e, i) => (
                  <li key={i} className="font-mono text-[11.5px] leading-relaxed">
                    <div className="text-emerald-300/80">{e.label}</div>
                    <div className="mt-0.5 text-slate-400">{e.detail}</div>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {issue.codeChange && (
            <div className="flex gap-3 rounded-xl border border-orange-500/25 bg-orange-500/[0.07] p-3.5">
              <span className="text-base leading-none">🔧</span>
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-orange-300">
                  仅改文案不够，需同时改代码
                </h4>
                <p className="mt-1 text-[13px] leading-relaxed text-orange-100/80">{issue.codeChange}</p>
              </div>
            </div>
          )}

          <div>
            <h4 className="mb-2.5 text-xs font-semibold uppercase tracking-wider text-slate-500">
              可直接替换的文本
            </h4>
            <div className="space-y-3">
              {issue.fixes.map((fix, i) => (
                <div key={i} className="overflow-hidden rounded-xl border border-white/8">
                  <div className="flex flex-wrap items-center gap-2 border-b border-white/8 bg-white/[0.03] px-3 py-2">
                    <LangBadge lang={fix.lang} />
                    <code className="min-w-0 flex-1 truncate font-mono text-[11px] text-slate-400">
                      {fix.key ?? fix.file ?? LANG_META[fix.lang].path}
                    </code>
                    <CopyButton text={fix.after} label="复制新文本" compact />
                  </div>

                  <div className="grid gap-px bg-white/5 md:grid-cols-2">
                    <div className="bg-[#120e12] p-3">
                      <div className="mb-1.5 flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-wider text-rose-400/80">
                        <span className="h-1.5 w-1.5 rounded-full bg-rose-500" /> 现状
                      </div>
                      <pre className="scroll-thin max-h-72 overflow-auto whitespace-pre-wrap break-words font-mono text-[12px] leading-relaxed text-rose-200/65">
                        {fix.before}
                      </pre>
                    </div>
                    <div className="bg-[#0b1410] p-3">
                      <div className="mb-1.5 flex items-center gap-1.5 text-[10.5px] font-semibold uppercase tracking-wider text-emerald-400/80">
                        <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> 建议替换
                      </div>
                      <pre className="scroll-thin max-h-72 overflow-auto whitespace-pre-wrap break-words font-mono text-[12px] leading-relaxed text-emerald-100/90">
                        {fix.after}
                      </pre>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {issue.note && (
            <p className="rounded-lg border border-white/8 bg-white/[0.03] px-3 py-2.5 text-[12.5px] leading-relaxed text-slate-400">
              <span className="font-semibold text-slate-300">备注 · </span>
              {issue.note}
            </p>
          )}
        </div>
      )}
    </article>
  );
}
