import { useState } from "react";
import { cn } from "../utils/cn";

interface Props {
  text: string;
  label?: string;
  className?: string;
  compact?: boolean;
}

export function CopyButton({ text, label = "复制", className, compact }: Props) {
  const [done, setDone] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setDone(true);
    window.setTimeout(() => setDone(false), 1600);
  };

  return (
    <button
      onClick={copy}
      className={cn(
        "inline-flex shrink-0 items-center gap-1.5 rounded-md border font-medium transition",
        compact ? "px-2 py-1 text-[11px]" : "px-2.5 py-1.5 text-xs",
        done
          ? "border-emerald-400/40 bg-emerald-400/15 text-emerald-300"
          : "border-white/10 bg-white/5 text-slate-300 hover:border-violet-400/40 hover:bg-violet-400/10 hover:text-violet-200",
        className,
      )}
      type="button"
    >
      {done ? (
        <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2.5}>
          <path d="M20 6 9 17l-5-5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      ) : (
        <svg viewBox="0 0 24 24" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth={2}>
          <rect x="9" y="9" width="12" height="12" rx="2" />
          <path d="M5 15V5a2 2 0 0 1 2-2h10" strokeLinecap="round" />
        </svg>
      )}
      {done ? "已复制" : label}
    </button>
  );
}
