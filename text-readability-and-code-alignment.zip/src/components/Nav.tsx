import { useEffect, useState } from "react";
import { cn } from "../utils/cn";
import { REPO } from "../data";

const LINKS = [
  { href: "#issues", label: "问题清单" },
  { href: "#patch", label: "导出补丁" },
  { href: "#glossary", label: "术语表" },
  { href: "#principles", label: "写作底线" },
  { href: "#ci", label: "CI 检查" },
  { href: "#method", label: "扫描方法" },
];

export function Nav() {
  const [solid, setSolid] = useState(false);

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <nav
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition",
        solid ? "border-b border-white/8 bg-[#080a12]/85 backdrop-blur-xl" : "bg-transparent",
      )}
    >
      <div className="mx-auto flex max-w-6xl items-center gap-4 px-5 py-3 sm:px-8">
        <a href="#top" className="flex items-center gap-2.5">
          <span className="grid h-7 w-7 place-items-center rounded-md bg-gradient-to-br from-violet-500 to-fuchsia-600 text-xs font-bold text-white">
            文
          </span>
          <span className="hidden text-[13px] font-semibold text-slate-200 sm:inline">
            纂刻附魔台 · 文本可读性审查
          </span>
        </a>

        <div className="ml-auto hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="rounded-md px-2.5 py-1.5 text-[12.5px] text-slate-400 transition hover:bg-white/5 hover:text-white"
            >
              {l.label}
            </a>
          ))}
        </div>

        <a
          href={REPO.url}
          target="_blank"
          rel="noreferrer"
          className="ml-auto rounded-md border border-white/10 px-2.5 py-1.5 font-mono text-[11.5px] text-slate-400 transition hover:border-white/25 hover:text-white lg:ml-0"
        >
          GitHub ↗
        </a>
      </div>
    </nav>
  );
}
