import { useMemo, useState } from "react";
import { cn } from "../utils/cn";
import { IssueCard } from "./IssueCard";
import { AREA_META, ISSUES, SEVERITY_META, type Area, type Severity } from "../data";

const SEV_ORDER: Severity[] = ["blocker", "major", "minor", "polish"];

export function IssueList() {
  const [area, setArea] = useState<Area | "all">("all");
  const [sev, setSev] = useState<Severity | "all">("all");
  const [q, setQ] = useState("");
  const [onlyCode, setOnlyCode] = useState(false);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return ISSUES.filter((i) => {
      if (area !== "all" && i.area !== area) return false;
      if (sev !== "all" && i.severity !== sev) return false;
      if (onlyCode && !i.codeChange) return false;
      if (!needle) return true;
      const hay = [
        i.id,
        i.title,
        i.location,
        ...i.tags,
        ...i.keys,
        ...i.problem,
        ...i.fixes.flatMap((f) => [f.before, f.after, f.key ?? "", f.file ?? ""]),
      ]
        .join(" ")
        .toLowerCase();
      return hay.includes(needle);
    }).sort((a, b) => SEV_ORDER.indexOf(a.severity) - SEV_ORDER.indexOf(b.severity));
  }, [area, sev, q, onlyCode]);

  return (
    <section id="issues" className="mx-auto max-w-6xl px-5 py-16 sm:px-8">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">问题清单</h2>
          <p className="mt-2 text-[14.5px] text-slate-400">
            按严重度排序。点标题展开定位、证据与替换文本。
          </p>
        </div>
        <span className="font-mono text-sm text-slate-500">
          {filtered.length} / {ISSUES.length}
        </span>
      </div>

      <div className="sticky top-3 z-20 mb-6 rounded-2xl border border-white/10 bg-[#0d1018]/95 p-3 backdrop-blur-xl">
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[200px] flex-1">
            <svg
              viewBox="0 0 24 24"
              className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-600"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
            >
              <circle cx="11" cy="11" r="7" />
              <path d="m20 20-3.5-3.5" strokeLinecap="round" />
            </svg>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="搜 key、原文、译文、文件名…（如 resonance / 广义书架 / README）"
              className="w-full rounded-lg border border-white/10 bg-black/30 py-2 pl-9 pr-3 text-[13px] text-slate-200 outline-none placeholder:text-slate-600 focus:border-violet-400/40"
            />
          </div>

          <div className="flex rounded-lg border border-white/10 bg-black/30 p-0.5">
            <button
              type="button"
              onClick={() => setArea("all")}
              className={cn(
                "rounded-md px-2.5 py-1.5 text-xs transition",
                area === "all" ? "bg-white/10 text-white" : "text-slate-400 hover:text-slate-200",
              )}
            >
              全部
            </button>
            {(Object.keys(AREA_META) as Area[]).map((a) => (
              <button
                key={a}
                type="button"
                onClick={() => setArea(a)}
                className={cn(
                  "rounded-md px-2.5 py-1.5 text-xs transition",
                  area === a ? "bg-white/10 text-white" : "text-slate-400 hover:text-slate-200",
                )}
              >
                {AREA_META[a].icon} {AREA_META[a].label}
              </button>
            ))}
          </div>

          <div className="flex gap-1.5">
            {SEV_ORDER.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setSev((cur) => (cur === s ? "all" : s))}
                className={cn(
                  "rounded-full border px-2.5 py-1 text-[11px] font-medium transition",
                  sev === s
                    ? SEVERITY_META[s].chip
                    : "border-white/10 bg-transparent text-slate-500 hover:text-slate-300",
                )}
              >
                {SEVERITY_META[s].short}
              </button>
            ))}
          </div>

          <label className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-white/10 bg-black/30 px-2.5 py-1.5 text-[11.5px] text-slate-400">
            <input
              type="checkbox"
              checked={onlyCode}
              onChange={(e) => setOnlyCode(e.target.checked)}
              className="h-3.5 w-3.5 accent-orange-500"
            />
            需改代码
          </label>
        </div>
      </div>

      <div className="space-y-4">
        {filtered.map((issue, i) => (
          <IssueCard key={issue.id} issue={issue} index={i} />
        ))}
        {filtered.length === 0 && (
          <div className="rounded-2xl border border-dashed border-white/10 py-16 text-center text-sm text-slate-500">
            没有匹配的条目，换个关键词试试。
          </div>
        )}
      </div>
    </section>
  );
}
