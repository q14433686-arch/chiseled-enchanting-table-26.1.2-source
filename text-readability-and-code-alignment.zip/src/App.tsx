import { Nav } from "./components/Nav";
import { Hero } from "./components/Hero";
import { IssueList } from "./components/IssueList";
import { PatchExport } from "./components/PatchExport";
import { Glossary } from "./components/Glossary";
import { Method } from "./components/Method";
import { ISSUES, REPO, TOTAL_FIXES } from "./data";

export default function App() {
  return (
    <div id="top" className="min-h-screen bg-[#080a12] font-sans text-slate-200">
      <Nav />
      <main className="pt-12">
        <Hero />
        <IssueList />
        <div className="border-y border-white/8 bg-white/[0.015]">
          <PatchExport />
        </div>
        <Glossary />
        <Method />
      </main>

      <footer className="border-t border-white/8 bg-[#06080e]">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-5 py-8 sm:px-8">
          <div>
            <p className="text-[13px] text-slate-400">
              文本可读性与一致性审查 · 共 {ISSUES.length} 条问题 / {TOTAL_FIXES} 段可替换文本
            </p>
            <p className="mt-1 font-mono text-[11.5px] text-slate-600">
              {REPO.name} @ {REPO.branch} · v{REPO.version} · MC {REPO.mc}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <a
              href="#issues"
              className="rounded-lg border border-white/10 px-3 py-2 text-[12.5px] text-slate-400 transition hover:border-white/25 hover:text-white"
            >
              回到清单
            </a>
            <a
              href={REPO.url}
              target="_blank"
              rel="noreferrer"
              className="rounded-lg bg-violet-600 px-3 py-2 text-[12.5px] font-semibold text-white transition hover:bg-violet-500"
            >
              去仓库提 PR ↗
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
