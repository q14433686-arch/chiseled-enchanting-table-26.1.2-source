export const repository =
  "https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source";

export type RevisionKey = "baseline" | "previous" | "current";

export const revisions: Record<
  RevisionKey,
  { ref: string; short: string; label: string; detail: string }
> = {
  baseline: {
    ref: "26.1.2_1.0.3",
    short: "1.0.3",
    label: "基线标签",
    detail: "26.1.2_1.0.3 · 提交 09f854e",
  },
  previous: {
    ref: "360551d",
    short: "360551d",
    label: "上一轮快照",
    detail: "arena/649fac5c · 第一轮审查对象",
  },
  current: {
    ref: "620b092",
    short: "620b092",
    label: "本轮快照",
    detail: "arena/8eb3bb9e · 1.1.0 · 含维护者第二轮修复",
  },
};

export const currentBranch = "arena/8eb3bb9e-chiseled-enchanting-table-26-1";

export type Evidence = {
  label: string;
  url: string;
  revision: "1.0.3" | "上一轮" | "本轮" | "API";
};

export type Category = "mechanic" | "economy" | "copy" | "content";
export type Priority = "P1" | "P2" | "P3";
export type Status = "fixed" | "partial" | "open";

export type RecheckItem = {
  id: string;
  number: string;
  category: Category;
  status: Status;
  title: string;
  original: string;
  recheck: string;
  residual?: string[];
  evidence: Evidence[];
};

export type Finding = {
  id: string;
  number: string;
  category: Category;
  priority: Priority;
  title: string;
  summary: string;
  baseline: string;
  current: string;
  recommendations: string[];
  acceptance: string;
  caveat?: string;
  related?: string[];
  evidence: Evidence[];
};

const java = "src/main/java/chiseled_enchanting_table/";
const client = "src/client/java/chiseled_enchanting_table/";
const langDir = "src/client/resources/assets/chiseled_enchanting_table/lang/";
const zh = `${langDir}zh_cn.json`;
const data = "src/main/resources/data/chiseled_enchanting_table/chiseled_enchanting_table/";
const handler = `${java}menu/ChiseledEnchantingTableScreenHandler.java`;
const dataJava = `${java}data/ChiseledEnchantingTableData.java`;
const cfgJava = `${java}config/ModRuntimeConfig.java`;
const catalogJava = `${java}config/ConfigCatalog.java`;
const screenJava = `${client}gui/ChiseledEnchantingTableScreen.java`;
const widgetJava = `${client}gui/EnchantementListWidget.java`;
const appJava = `${java}mechanics/enchanting/EnchantmentApplication.java`;
const beJava = `${java}block/ChiseledEnchantingTableBlockEntity.java`;
const blockJava = `${java}block/ChiseledEnchantingTableBlock.java`;
const jeiCategory = `${client}compat/jei/EnchantingRecipeCategory.java`;
const jeiPlugin = `${client}compat/jei/ChiseledEnchantingJeiPlugin.java`;
const reiCategory = `${client}compat/rei/ReiEnchantingCategory.java`;
const grimoire = `${client}gui/grimoire/ArcaneGrimoireScreen.java`;
const safetyTest = "src/test/java/chiseled_enchanting_table/ConfigurationSafetyTest.java";
const auditDoc = "docs/reports/CLASSIC_1_0_3_AUDIT.md";

export function sourceUrl(revision: RevisionKey, path: string, lines?: string) {
  return `${repository}/blob/${revisions[revision].ref}/${path}${lines ? `#${lines}` : ""}`;
}

const revisionLabel: Record<RevisionKey, Evidence["revision"]> = {
  baseline: "1.0.3",
  previous: "上一轮",
  current: "本轮",
};

const ev = (label: string, revision: RevisionKey, path: string, lines: string): Evidence => ({
  label,
  url: sourceUrl(revision, path, lines),
  revision: revisionLabel[revision],
});

export const categoryLabels: Record<Category, string> = {
  mechanic: "机制与门禁",
  economy: "数据与经济",
  copy: "界面与文案",
  content: "内容与边界",
};

export const statusLabels: Record<Status, string> = {
  fixed: "已修复",
  partial: "部分修复",
  open: "未修复",
};

export const recheck: RecheckItem[] = [
  {
    id: "ritual-slip",
    number: "01",
    category: "mechanic",
    status: "fixed",
    title: "0 秒铭刻仍可能抄错或串行",
    original: "经典预设只把等待时间置零，结算阶段仍按母本过载负载抽取失误结果。",
    recheck:
      "completeActiveRitual 在经典下把 stepSlipProb 固定为 0；EnchantmentApplication 的无方块实体回退路径同样把 slipChance 置 0。KEEP 母本仍会回传 usedInfinityTome，但该标志不再进入任何抽签。",
    evidence: [
      ev("旧版直接写入附魔", "baseline", appJava, "L29-L76"),
      ev("上一轮：结算仍抽取失误", "previous", beJava, "L414-L450"),
      ev("本轮：结算概率固定 0", "current", beJava, "L351-L358"),
      ev("本轮：slip 分支加经典判断", "current", beJava, "L421-L430"),
      ev("本轮：回退路径置 0", "current", appJava, "L240-L247"),
    ],
  },
  {
    id: "epiphany-gate",
    number: "02",
    category: "mechanic",
    status: "fixed",
    title: "零概率顿悟不等于关闭刷新与锁定",
    original: "概率归零后，服务端仍接受付费刷新/锁定并推进种子，普通附魔与置换也推进种子。",
    recheck:
      "处理器在 epiphanyChance、epiphanyMaxSlots、computeActiveTreasureEpiphanies、canAffordReroll/Freeze、advanceTableEpiphanySeed 与 handleTomePageAction 六处加入经典门禁；数据层把 per-shelf / per-tome 概率归零；classic 布尔值在 compact constructor 内强制整套字段，单独开关不再出现“机制仍活、面板隐藏”。",
    evidence: [
      ev("旧版只有四种操作类型", "baseline", `${java}menu/ChiseledEnchantingMenuPayloads.java`, "L26-L40"),
      ev("上一轮：付费判定无门禁", "previous", handler, "L2454-L2529"),
      ev("本轮：种子推进直接返回", "current", handler, "L444-L447"),
      ev("本轮：母本页操作拒绝", "current", handler, "L654-L661"),
      ev("本轮：概率与槽位硬归零", "current", handler, "L2226-L2234"),
      ev("本轮：付费判定拒绝", "current", handler, "L2485-L2498"),
      ev("本轮：数据层归零每架概率", "current", dataJava, "L948-L956"),
      ev("本轮：compact constructor 强制全套", "current", cfgJava, "L468-L497"),
    ],
  },
  {
    id: "incremental-copy",
    number: "03",
    category: "copy",
    status: "fixed",
    title: "“仅补差价”与实际扣费相反",
    original: "经典模式完整收费，列表注释与价格来源浮窗却继续承诺自动抵扣。",
    recheck:
      "列表注释 upgrade_from 增加 !isClassic103Mode 判断；行浮窗新增 pricing.classic_1_0_3 分支；full.master_hint 在经典下隐藏；书转移文案换成“源书返还为普通书”的经典版本。措辞上的残留见 R2-10。",
    residual: ["classic-wording"],
    evidence: [
      ev("旧版完整成本扣除", "baseline", handler, "L412-L439"),
      ev("上一轮：注释无经典判断", "previous", widgetJava, "L1327-L1335"),
      ev("本轮：注释加门禁", "current", widgetJava, "L1327-L1340"),
      ev("本轮：经典计价分支", "current", screenJava, "L1671-L1700"),
      ev("本轮：量产提示隐藏", "current", screenJava, "L1529-L1535"),
      ev("本轮：新增文案键", "current", zh, "L319-L320"),
    ],
  },
  {
    id: "pricing-source",
    number: "04",
    category: "copy",
    status: "fixed",
    title: "消耗规则和计价来源各说各话",
    original: "XP 浮窗按完整等级显示，行浮窗却可能写“母本 1–3 级量产”或“置换 1–3 级”。",
    recheck:
      "经典下 XP 徽章与行浮窗都指向全额经验；JEI/REI 附魔类别改用 forFullArcaneRitual 显示“消耗：N 级经验”。材料选项的语义差异另见 R2-03。",
    residual: ["cost-semantics"],
    evidence: [
      ev("旧版置换 3 / 1 级", "baseline", `${data}item_transformations.json`, "L1-L24"),
      ev("上一轮：来源按类型猜测", "previous", screenJava, "L1665-L1748"),
      ev("本轮：经典 XP 统一全额", "current", handler, "L2125-L2128"),
      ev("本轮：JEI 全额显示", "current", jeiCategory, "L85-L104"),
      ev("本轮：REI 全额显示", "current", reiCategory, "L79-L100"),
    ],
  },
  {
    id: "resonance-text",
    number: "05",
    category: "copy",
    status: "fixed",
    title: "共鸣减免没生效，细项提示仍出现",
    original: "总上限为 0，但材料悬停可出现“同种藏书额外 -X%（共 -0%）”。",
    recheck:
      "applyRuntimeConfig 在经典下把 wooden / total / global / base / specific 五个上限全部归零，材料浮窗的 specific_line 也加了经典判断；测试 classicFrameZeroesResonanceSubCapsAndEpiphanyPerShelfChances 断言五个上限为 0。JEI 仍残留一句减免文字，见 R2-06。",
    residual: ["jei-bookshelf-line"],
    evidence: [
      ev("旧版只有书架提级", "baseline", blockJava, "L153-L203"),
      ev("上一轮：细项单独计算", "previous", handler, "L1960-L1986"),
      ev("本轮：五个上限归零", "current", dataJava, "L860-L875"),
      ev("本轮：材料提示加门禁", "current", screenJava, "L1443-L1452"),
      ev("本轮：单元测试断言", "current", safetyTest, "L200-L215"),
    ],
  },
  {
    id: "cost-table",
    number: "06",
    category: "economy",
    status: "partial",
    title: "完整收费仍引用 1.1.0 价格表",
    original: "“不打折”只决定扣法，原始 XP 与材料仍来自 1.1.0 表。",
    recheck:
      "enchantment_costs_classic_1_0_3.json 与标签逐字节一致，经典运行帧改用该表，经验修补 I = 35、保护 IV = 25 有测试覆盖。但这张表里 64 处 min_count/max_count 被现行引擎折算为中点，89 处多选项规则由“按玩家分配一种”变成“全部可选”：数值表一致，求值并不一致。",
    residual: ["cost-semantics"],
    evidence: [
      ev("1.0.3 价格表", "baseline", `${data}enchantment_costs.json`, "L1-L37"),
      ev("上一轮：运行帧沿用现行表", "previous", dataJava, "L1026-L1031"),
      ev("本轮：经典运行帧改用旧表", "current", dataJava, "L925-L938"),
      ev("本轮：XP 断言 35 / 25", "current", safetyTest, "L125-L160"),
      ev("本轮：范围取中点", "current", dataJava, "L2181-L2210"),
      ev("1.0.3：按玩家哈希选项与数量", "baseline", dataJava, "L645-L703"),
    ],
  },
  {
    id: "book-upgrades",
    number: "07",
    category: "economy",
    status: "partial",
    title: "升书倍率调回去了，材料规则没有",
    original: "预设只恢复双书/单书 XP 倍率，单书进修仍读新版催化剂与材料曲线。",
    recheck:
      "book_upgrades_classic_1_0_3.json 与标签逐字节一致，研究材料倍率 0.5 与主题材料（锋利→燧石等）已恢复。但 researchXpCost 由 floor 改为 round：锋利 III 的研究经验 1.0.3 为 7，现为 8，新测试直接把 8 写成期望值。",
    residual: ["research-rounding"],
    evidence: [
      ev("1.0.3 升书规则", "baseline", `${data}book_upgrades.json`, "L1-L16"),
      ev("上一轮：预设只覆盖倍率", "previous", cfgJava, "L209-L218"),
      ev("本轮：经典升书表接入", "current", dataJava, "L925-L934"),
      ev("本轮：round 取整", "current", dataJava, "L1826-L1828"),
      ev("1.0.3：floor 取整", "baseline", dataJava, "L518-L520"),
      ev("本轮：测试断言 8", "current", safetyTest, "L150-L156"),
    ],
  },
  {
    id: "apple-emerald",
    number: "08",
    category: "economy",
    status: "partial",
    title: "两项旧置换也并非逐项同价",
    original: "金苹果在旧数据中另需 2–5 绿宝石，经典分支写死为 2。",
    recheck:
      "classicTransformationCosts 以原始 stablePositiveHash 公式按玩家解析 2–5 绿宝石，哈希函数与拼接字符串均与标签一致，台内报价与实扣已对齐。但 S2C 成本行与 JEI/REI 仍走 resolvedBundles 的中点，显示 4 颗，见 R2-05。",
    residual: ["apple-viewer"],
    evidence: [
      ev("1.0.3：2–5 绿宝石", "baseline", `${data}item_transformations.json`, "L2-L24"),
      ev("上一轮：处理器写死 2", "previous", handler, "L1416-L1427"),
      ev("本轮：按玩家解析范围", "current", dataJava, "L552-L583"),
      ev("本轮：处理器改读经典规则", "current", handler, "L1428-L1439"),
      ev("本轮：经典置换 JSON 逐字节一致", "current", `${data}item_transformations_classic_1_0_3.json`, "L1-L26"),
    ],
  },
  {
    id: "unlock-filter",
    number: "09",
    category: "mechanic",
    status: "fixed",
    title: "默认宝藏补回七种，过滤口径未回退",
    original: "先执行新排除规则再补七个 ID，双标签的第三方附魔仍被滤掉。",
    recheck:
      "defaultEnchantments(lookup) 在经典下不再应用 exclude、exclude_tags 与顿悟显式 ID；Block 里的七个硬编码 ID 保留，等价于 1.0.3 的 values 列表。解锁集合同时改为只含最高等级，与 1.0.3 的列表行为一致。",
    evidence: [
      ev("1.0.3：展开不排除", "baseline", dataJava, "L88-L96"),
      ev("1.0.3：列表只列解锁条目", "baseline", widgetJava, "L183-L186"),
      ev("上一轮：先过滤后补七种", "previous", blockJava, "L365-L393"),
      ev("本轮：经典不排除", "current", dataJava, "L175-L196"),
      ev("本轮：只含最高等级", "current", blockJava, "L435-L446"),
    ],
  },
  {
    id: "world-loot",
    number: "10",
    category: "economy",
    status: "fixed",
    title: "新生成雕纹书架附魔书率变为四倍",
    original: "旧版每格 3%，现行 12%，预设未覆盖。",
    recheck:
      "预设与 compact constructor 都强制 bookshelfEnchantedProb = 0.03，滑杆步长改为 0.01 以便标准模式也能选回 0.03。维护者自述 max_level_weight_ratio（0.15 vs 0.1）与战利品注入表仍为 1.1.0 内容，只影响新生成结构。",
    evidence: [
      ev("1.0.3：概率 0.03", "baseline", `${data}bookshelf_book_pool.json`, "L4-L15"),
      ev("上一轮：预设未重设", "previous", cfgJava, "L220-L230"),
      ev("本轮：构造器强制 0.03", "current", cfgJava, "L497-L498"),
      ev("本轮：滑杆步长 0.01", "current", catalogJava, "L898-L903"),
      ev("维护者说明剩余漂移", "current", auditDoc, "L46-L51"),
    ],
  },
  {
    id: "recipe-scope",
    number: "11",
    category: "content",
    status: "partial",
    title: "玩法预设不会热切换合成表",
    original: "附魔台配方与新物品配方仍是 1.1.0 内容，预设说明没有交代。",
    recheck:
      "静态配方未切换；inert_note 现在明确写出“合成配方与新物品仍沿用 1.1.0、64 堆叠需重启”。这是上一轮的方案 B，可接受。但预设标题与描述仍是“原汁原味 / 逐项还原”，Wiki 同样如此，见 R2-10。",
    residual: ["classic-wording"],
    evidence: [
      ev("1.0.3 附魔台配方", "baseline", "src/main/resources/data/chiseled_enchanting_table/recipe/chiseled_enchanting_table.json", "L1-L17"),
      ev("本轮：边界说明", "current", zh, "L761-L763"),
      ev("维护者处置记录", "current", auditDoc, "L41-L42"),
      ev("Wiki 仍称逐项对齐", "current", "docs/WIKI.md", "L264-L266"),
    ],
  },
  {
    id: "viewer-manual",
    number: "12",
    category: "copy",
    status: "partial",
    title: "秘典、JEI、REI 仍在讲新版玩法",
    original: "手册与配方查看器继续展示顿悟、减免、磨损与 1–3 级量产。",
    recheck:
      "JEI 站点/书架信息新增经典变体，JEI/REI 经验改为全额，REI 隐藏了减免行，秘典第 3-3 / 4 / 5 / 6 / 8 / 9 章前置提示。残留四项：JEI 经典说明带字面 \\n（R2-02）、JEI 浮窗仍写“最多省 0%”（R2-06）、秘典第 2 / 3-1 / 3-2 / 7 章与图示未提示（R2-07）、JEI 信息页注册即定型（R2-08）。",
    residual: ["jei-literal-newline", "jei-bookshelf-line", "grimoire-coverage", "jei-static-info"],
    evidence: [
      ev("上一轮：JEI 始终算母本模式", "previous", jeiCategory, "L82-L96"),
      ev("本轮：JEI 信息经典变体", "current", jeiPlugin, "L124-L141"),
      ev("本轮：REI 隐藏减免行", "current", reiCategory, "L108-L113"),
      ev("本轮：秘典提示章节清单", "current", grimoire, "L1115-L1132"),
    ],
  },
  {
    id: "config-links",
    number: "13",
    category: "mechanic",
    status: "fixed",
    title: "配置项之间少了“功能已关闭”的联动",
    original: "经典下顿悟子项、减免上限、退魔开关仍可编辑且不说明为何无效。",
    recheck:
      "ConfigCatalog.CLASSIC_LOCKED_KEYS 列出 36 个键，在经典下灰显并给出 reason.classic_1_0_3，偏好值保留；测试 classicModeLocksSubordinateConfigOptionsWithReason 覆盖。少数无效项仍可编辑，见 R2-12。",
    residual: ["unlocked-noop-keys"],
    evidence: [
      ev("上一轮：顿悟子项 ALWAYS", "previous", catalogJava, "L705-L759"),
      ev("本轮：经典锁定判定", "current", catalogJava, "L284-L300"),
      ev("本轮：锁定键清单", "current", catalogJava, "L345-L370"),
      ev("本轮：新增原因文案", "current", zh, "L524"),
      ev("本轮：锁定测试", "current", safetyTest, "L187-L199"),
    ],
  },
  {
    id: "policy-truth",
    number: "14",
    category: "content",
    status: "partial",
    title: "“已应用预设”不等于“实际规则已对齐”",
    original: "预设匹配只比草稿；数据包、锁定与启动期组件可让有效规则偏离。",
    recheck:
      "RuntimeRules.prepare 在数据包解析后调用 Draft.build()，经典字段会被重新强制，数据包无法复活顿悟或减免——这点已核实。但同一强制把启动期专属的 enchanted_book_stack_size 也改成 64，与 RuleBook.withValidatedValues 的 startupOnly 校验冲突，详见 R2-01。",
    residual: ["startup-stack-conflict"],
    evidence: [
      ev("1.0.3：64 堆叠仍是 TODO", "baseline", `${java}ChiseledEnchantingTable.java`, "L20-L28"),
      ev("本轮：解析后归一化", "current", `${java}config/rules/RuntimeRules.java`, "L50-L59"),
      ev("本轮：startupOnly 校验抛错", "current", `${java}config/rules/RuleBook.java`, "L115-L128"),
      ev("本轮：构造器强制 64", "current", cfgJava, "L468-L470"),
    ],
  },
];

export const findings: Finding[] = [
  {
    id: "startup-stack-conflict",
    number: "R2-01",
    category: "mechanic",
    priority: "P1",
    title: "经典强制 64 堆叠，与启动期规则校验冲突",
    summary: "服务器若以非 64 的附魔书堆叠上限启动，运行时启用经典预设会被 RuleBook 拒绝，管理员只看到通用的“保存失败”。",
    baseline: "1.0.3 标签没有配置系统，也没有可切换的堆叠上限；64 堆叠在该标签源码中仍是 TODO，相关 accessor mixin 被构建脚本排除。",
    current: "compact constructor 在 classic103Mode 下把 enchantedBookStackSize 强制为 64。RuntimeRules.prepare 用启动时的配置值构造 RuleBook 的 startup 映射，解析后调用 Draft.build()，再交给 withValidatedValues；该方法规定 startupOnly 键的值若在归一化中改变就抛出 IllegalArgumentException。以 1 或 16 启动的服务器因此无法在运行时启用经典；ModConfigNetworking 捕获异常后只回传 save_failed。配置描述本身建议“配合第三方机器可改为 1”，所以这不是罕见组合。",
    recommendations: [
      "把 enchanted_book_stack_size 从经典强制集合中移出：预设仍建议 64，但由 RESTART_REQUIRED 徽章与 inert_note 说明生效时机；或在 RuntimeRules 的归一化阶段对 startup 键保持原值。",
      "保存失败时返回具体原因（例如“堆叠上限需重启后才能更改”），并新增“以 stack=1 启动后再启用经典”的单元或集成测试。",
    ],
    acceptance: "以 enchanted_book_stack_size=1 启动专用服与单机，运行时点击 1.0.3 预设并保存：应成功同步经典规则并提示重启后 64 生效；现有 ConfigurationSafetyTest 保持通过。",
    caveat: "结论来自对调用链的静态推导，尚未在真实服务器上复现；RuleBook 的 startup 值取自首次 prepare 时的本地配置。",
    related: ["policy-truth"],
    evidence: [
      ev("构造器强制 64", "current", cfgJava, "L468-L470"),
      ev("Draft.build 再次强制", "current", cfgJava, "L1387-L1394"),
      ev("startup 映射取启动配置", "current", `${java}config/rules/RuntimeRules.java`, "L23-L31"),
      ev("归一化后校验", "current", `${java}config/rules/RuntimeRules.java`, "L50-L59"),
      ev("startupOnly 改变即抛错", "current", `${java}config/rules/RuleBook.java`, "L115-L128"),
      ev("startup 键解析来源", "current", `${java}config/rules/RuleBook.java`, "L153-L166"),
      ev("异常只回传 save_failed", "current", `${java}config/ModConfigNetworking.java`, "L109-L133"),
      ev("1.0.3：64 堆叠为 TODO", "baseline", `${java}ChiseledEnchantingTable.java`, "L20-L28"),
      ev("1.0.3：accessor 被排除编译", "baseline", "build.gradle", "L84-L88"),
    ],
  },
  {
    id: "jei-literal-newline",
    number: "R2-02",
    category: "copy",
    priority: "P1",
    title: "JEI 经典说明文字在 11 种语言里都带字面 \\n",
    summary: "新增的 info.station_classic 使用了双反斜杠转义，JEI 会把 \\n 原样显示为两个字符；同文件的标准版 info.station 用的是真正换行。",
    baseline: "1.0.3 的 JEI 信息文本只有一段，没有换行转义问题。",
    current: "zh_cn.json 第 13 行等 11 个语言文件中，info.station_classic 的值解析后包含反斜杠 + n；第 14 行的 info.station 则是真实换行。JEI 插件在经典模式下选择前者作为站点说明。语言键齐平的 CI 门禁只检查键是否存在，不检查值。",
    recommendations: [
      "把 11 个文件中的双反斜杠改为单个换行转义；在 ci_static_checks.py 增加“语言值不得含字面反斜杠 n”的静态检查。",
    ],
    acceptance: "JSON 解析后字符串不含反斜杠；经典模式下在 JEI 悬停附魔台应显示三行要点。",
    related: ["viewer-manual"],
    evidence: [
      ev("zh_cn 经典键含字面转义", "current", zh, "L13"),
      ev("zh_cn 标准键为真实换行", "current", zh, "L14"),
      ev("en_us 同样问题", "current", `${langDir}en_us.json`, "L13"),
      ev("JEI 选择经典键", "current", jeiPlugin, "L124-L135"),
    ],
  },
  {
    id: "cost-semantics",
    number: "R2-03",
    category: "economy",
    priority: "P1",
    title: "成本表逐字节一致，求值语义仍是 1.1.0",
    summary: "现行引擎把 min_count..max_count 折算为固定中点，并把多选项全部开放；1.0.3 是按玩家哈希选唯一选项、再按玩家哈希在范围内取数。",
    baseline: "1.0.3 的 ItemCostRule.toStacks 以 stablePositiveHash(附魔:等级:上限:盐:option) 选唯一选项；ItemCostOption.toSingleStack 以同类哈希在 [min, max] 内取值。保护 IV 的满级材料因此是“绿宝石 3–6 + 铁锭”或“钻石 1–3 + 铁锭”二选一、数量因人而异。",
    current: "ItemCostRule.toBundles 把全部选项展开为可选组合；ItemCostOption.computeCount 对范围取 (min+max+1)/2，保护 IV 固定为 5 绿宝石或 2 钻石且两种都可用。经典成本表含 64 处范围项、89 处多选项规则；维护者只为附魔金苹果单独实现了按玩家哈希。测试断言的是 XP 值，没有覆盖材料数量。",
    recommendations: [
      "在经典运行帧下为附魔与研究材料接入同一个按玩家盐值解析的经典求值器（可复用 classicTransformationCosts 的思路），并让 S2C 成本行携带该玩家的解析结果。",
      "若决定保留“全部可选 + 中点”作为体验改进，需在预设说明与 Wiki 中写明这不是 1.0.3 行为，并把测试从“JSON 相同”升级为“同一玩家的报价相同”。",
    ],
    acceptance: "两名不同 UUID 的玩家对保护 IV：按 1.0.3 公式各自得到一个选项与 3–6 的数量；修复后台内报价、S2C 行与 JEI/REI 一致且与公式相符。",
    related: ["cost-table", "pricing-source"],
    evidence: [
      ev("1.0.3：按玩家选唯一选项", "baseline", dataJava, "L645-L655"),
      ev("1.0.3：范围按玩家哈希取数", "baseline", dataJava, "L687-L703"),
      ev("本轮：全部选项展开", "current", dataJava, "L1970-L1988"),
      ev("本轮：范围取中点", "current", dataJava, "L2181-L2210"),
      ev("本轮：仅金苹果按玩家解析", "current", dataJava, "L552-L583"),
      ev("经典表中的范围项示例", "current", `${data}enchantment_costs_classic_1_0_3.json`, "L39-L72"),
    ],
  },
  {
    id: "research-rounding",
    number: "R2-04",
    category: "economy",
    priority: "P2",
    title: "研究升书 XP 取整从 floor 变成 round",
    summary: "直接成本为奇数时经典模式多收 1 级；新测试把 8（而非 1.0.3 的 7）固化为期望值。",
    baseline: "1.0.3：researchXpCost = max(1, floor(直接成本 × 0.5))。锋利 III 直接成本 15 → 7；经验修补 I 35 → 17。",
    current: "现行：max(1, round(直接成本 × 倍率))，15 × 0.5 = 7.5 → 8。ConfigurationSafetyTest.classicFrameUses103CostAndBookUpgradeTables 断言 bookResearchXpCost(sharpness3) == 8。1.0.3 表中 5 / 25 / 35 全是奇数基数，受影响的等级不少。",
    recommendations: [
      "经典运行帧下使用 floor，或让 BookUpgradeRules 携带取整策略；把测试期望改为 7 并注明来源。",
    ],
    acceptance: "锋利 III、经验修补 I 等奇数成本的研究升书在经典下与 1.0.3 一致；标准模式不变。",
    related: ["book-upgrades"],
    evidence: [
      ev("1.0.3：floor", "baseline", dataJava, "L518-L520"),
      ev("本轮：round", "current", dataJava, "L1826-L1828"),
      ev("本轮：测试固化 8", "current", safetyTest, "L150-L156"),
      ev("1.0.3：奇数基数 5 / 25 / 35", "baseline", `${data}enchantment_costs.json`, "L2-L6"),
    ],
  },
  {
    id: "apple-viewer",
    number: "R2-05",
    category: "economy",
    priority: "P2",
    title: "附魔金苹果：台内按玩家 2–5，查看器与同步表显示 4",
    summary: "处理器用 classicTransformationCosts 按玩家解析绿宝石，但 EnchantCostTablePayload 与 TransformationQueryIndex 仍走 resolvedBundles 的中点。",
    baseline: "1.0.3 的 2–5 绿宝石按玩家哈希解析，当时没有 JEI/REI 可对照。",
    current: "S2C 成本行由 transformationCostOptions(transId) → resolvedBundles() 生成，范围取中点 4；JEI/REI 读取同步行，显示 4 颗，而台内与实扣为 2–5。EnchantCostTablePayload 本身就是按玩家生成的，具备携带正确值的条件。",
    recommendations: [
      "让 EnchantCostTablePayload 在经典下对置换行调用 classicTransformationCosts(player)；或在查看器中标注“数量随玩家 2–5”。",
    ],
    acceptance: "同一玩家在 JEI/REI、附魔台行与实际扣料看到相同的绿宝石数量。",
    related: ["apple-emerald"],
    evidence: [
      ev("本轮：处理器按玩家解析", "current", handler, "L1428-L1439"),
      ev("本轮：同步表走中点", "current", `${java}menu/EnchantCostTablePayload.java`, "L217-L233"),
      ev("本轮：查看器读取同步行", "current", `${java}compat/TransformationQueryIndex.java`, "L110-L121"),
      ev("本轮：resolvedBundles", "current", dataJava, "L1673-L1700"),
    ],
  },
  {
    id: "jei-bookshelf-line",
    number: "R2-06",
    category: "copy",
    priority: "P2",
    title: "JEI 配方浮窗仍写“最多省 0% 经验”",
    summary: "REI 已在经典下隐藏 tooltip.bookshelf，JEI 的 getTooltip 仍无条件追加这一行。",
    baseline: "1.0.3 没有书架经验减免。",
    current: "EnchantingRecipeCategory.getTooltip 第 146–149 行无条件添加 tooltip.bookshelf，参数为 maxTotalXpDiscountPercent（经典为 0）；ReiEnchantingCategory 第 108–113 行已加判断。两套查看器因此对同一规则给出不同描述。",
    recommendations: [
      "与 REI 同步加判断；更稳妥的做法是让这段提示读取报价对象的 discountApplied / priceSource，而不是读取配置上限。",
    ],
    acceptance: "经典下 JEI 附魔配方浮窗不出现减免文字；标准模式仍显示真实上限。",
    related: ["resonance-text", "viewer-manual"],
    evidence: [
      ev("本轮：JEI 无条件追加", "current", jeiCategory, "L146-L149"),
      ev("本轮：REI 已加判断", "current", reiCategory, "L108-L113"),
    ],
  },
  {
    id: "grimoire-coverage",
    number: "R2-07",
    category: "copy",
    priority: "P2",
    title: "秘典的经典提示只覆盖部分章节",
    summary: "第 2 章、第 3 章前两页、第 7 章以及图示与首页仍按标准模式叙述三轨书架、0–38 曲线、6 种置换与残卷。",
    baseline: "1.0.3 没有秘典；其书架规则是等级 +floor(W/3)，置换只有两项。",
    current: "ArcaneGrimoireScreen 只对第 4 / 5 / 6 / 8 / 9 章与第 3-3 页前置 classic_notice；SPREAD_SPECS 中的第 2、3-1、3-2、7 章未处理；GrimoireDiagramRenderer 的图示文案（如 diag.ch6_gate、diag.ch3p0_map_reg）与首页 home.p2 也没有分支。",
    recommendations: [
      "把提示扩展到所有描述非经典系统的章节与图示，或为经典提供精简目录：合成、+W/3 规则、两项置换、全额经验。",
    ],
    acceptance: "经典下逐页翻阅秘典，没有页面在无提示的情况下描述顿悟、减免、磨损、残卷或 6 种置换。",
    related: ["viewer-manual"],
    evidence: [
      ev("本轮：提示章节清单", "current", grimoire, "L1115-L1132"),
      ev("本轮：全部页面定义", "current", grimoire, "L58-L75"),
      ev("首页仍讲三种书架", "current", zh, "L176"),
      ev("第 7 章仍讲置换与残卷", "current", zh, "L276-L277"),
      ev("图示仍写顿悟门槛", "current", zh, "L268"),
    ],
  },
  {
    id: "jei-static-info",
    number: "R2-08",
    category: "copy",
    priority: "P2",
    title: "JEI 物品信息在插件注册时定型",
    summary: "info.station_classic 的选择发生在 registerRecipes；运行时切换预设后不会刷新，配置同步包晚于 JEI 注册时还会读到本地配置。",
    baseline: "不适用：1.0.3 的 JEI 说明没有模式分支。",
    current: "ChiseledEnchantingJeiPlugin.registerRecipes 以 ModRuntimeConfig.effective() 一次性决定信息文本；refreshRuntimeRecipes 只刷新附魔与置换两个类别，不触碰 addItemStackInfo。秘典与 JEI/REI 类别浮窗是逐帧读取配置的，因此只有信息页会失真。",
    recommendations: [
      "把模式相关说明改为类别浮窗（每次渲染读取配置），或在配置同步后触发 JEI 重载；至少在文档中说明需要重进世界。",
    ],
    acceptance: "专用服切换预设后，JEI 信息页在不重启客户端的情况下与当前模式一致，或界面明确提示需重进。",
    caveat: "同步包与 JEI 注册的先后顺序需要联机实测，这里只能指出两者没有显式依赖。",
    related: ["viewer-manual"],
    evidence: [
      ev("本轮：注册时读取配置", "current", jeiPlugin, "L119-L141"),
      ev("本轮：刷新只覆盖两个类别", "current", jeiPlugin, "L64-L82"),
    ],
  },
  {
    id: "classic-ignores-datapacks",
    number: "R2-09",
    category: "content",
    priority: "P2",
    title: "经典模式静默忽略外部数据包的成本、升书与置换表",
    summary: "经典运行帧直接读取随包 JSON，服主自定义的三张表不再生效，配置界面没有任何提示。",
    baseline: "1.0.3 的这三张表就是数据包资源，服主可以覆盖。",
    current: "applyRuntimeConfig 在经典下用 readBundledJsonObject 加载 *_classic_1_0_3.json；PackPolicy 只跟踪配置键，不覆盖整表来源，因此 reason.datapack_priority 不会出现。这符合“经典 = 内置 1.0.3 数据”的定义，但应当明说。",
    recommendations: [
      "在经典状态文本与 inert_note 中写明“经典模式使用内置 1.0.3 数据表，忽略同名数据包”；或提供 classic 覆盖层入口，让服主在经典基线上继续自定义。",
    ],
    acceptance: "加载自定义成本数据包并启用经典：界面出现明确提示；关闭经典后数据包立即恢复生效。",
    evidence: [
      ev("本轮：经典读取随包表", "current", dataJava, "L925-L938"),
      ev("本轮：经典置换读取随包表", "current", dataJava, "L996-L1000"),
      ev("本轮：PackPolicy 只覆盖配置键", "current", cfgJava, "L365-L390"),
      ev("1.0.3：三张表经资源重载加载", "baseline", dataJava, "L46-L68"),
    ],
  },
  {
    id: "classic-wording",
    number: "R2-10",
    category: "copy",
    priority: "P2",
    title: "“逐项还原 / 原汁原味”与“存书铭刻计价”仍过度承诺",
    summary: "预设标题与描述未随边界说明调整；经典行浮窗对没有存书的默认附魔也写“存书铭刻计价”。",
    baseline: "1.0.3 没有预设与这类文案。",
    current: "zh_cn 第 761–763 行：标题“原汁原味”、描述“逐项还原 1.0.3 玩法”，Wiki 第 264–266 行同样写“逐项对齐”；第 319 行 pricing.classic_1_0_3 =“存书铭刻计价（1.0.3 经典：全额经验费用）”，而屏幕第 1680–1696 行的分支覆盖所有非置换、非清洗的行，包括默认解锁的附魔。",
    recommendations: [
      "标题改为“1.0.3 玩法规则（配方与新物品除外）”，描述列出已知差异（材料选项、取整、JEI 信息页）；行浮窗改为中性表述“1.0.3 经典计价：按目标等级全额经验与材料”。",
      "同步 11 种语言、README 与 Wiki 的预设段落。",
    ],
    acceptance: "所有语言的预设说明与实际边界一致；默认附魔与存书附魔的经典浮窗都不含误导性前提。",
    related: ["incremental-copy", "recipe-scope"],
    evidence: [
      ev("本轮：预设标题与描述", "current", zh, "L761-L763"),
      ev("本轮：经典计价文案", "current", zh, "L319"),
      ev("本轮：分支覆盖所有附魔行", "current", screenJava, "L1680-L1696"),
      ev("Wiki 仍称逐项对齐", "current", "docs/WIKI.md", "L264-L266"),
    ],
  },
  {
    id: "legacy-locks",
    number: "R2-11",
    category: "mechanic",
    priority: "P3",
    title: "切换前已锁定的母本在经典下既不可用也无法解锁",
    summary: "锁定数据随物品保存；经典隐藏母本页并拒绝 TomePageAction，而解锁判定与候选扫描仍跳过锁定书。",
    baseline: "1.0.3 没有母本锁。",
    current: "EnchantmentFinder 第 26 行与 MasterTomeWear.collectCandidates 第 534 行跳过 isEffectivelyLocked 的书；handleTomePageAction 在经典下直接返回。经典强制 lockedBookExtractionBlocked=false，玩家可以取出再放回以清除锁，但没有任何提示说明这一点。",
    recommendations: [
      "进入经典时忽略锁状态（isEffectivelyLocked 加经典判断），或在切换时清理书架内的锁；至少在预设说明中给出“取出再放回即可解锁”的提示。",
    ],
    acceptance: "在标准模式永久锁定一本母本后切换经典：该书仍能解锁等级，或界面给出明确的解除方法。",
    evidence: [
      ev("本轮：解锁判定跳过锁定书", "current", `${java}utils/EnchantmentFinder.java`, "L26"),
      ev("本轮：候选扫描跳过锁定书", "current", `${java}mechanics/resonance/MasterTomeWear.java`, "L534"),
      ev("本轮：母本页操作被拒", "current", handler, "L654-L661"),
      ev("本轮：取出受配置控制", "current", `${java}mixin/bookshelf/LockedBookContainerMixin.java`, "L35-L41"),
    ],
  },
  {
    id: "unlocked-noop-keys",
    number: "R2-12",
    category: "content",
    priority: "P3",
    title: "部分经典下无效的配置项未被锁定",
    summary: "残卷还原档位、tier3 词条数、提前解锁消耗、献祭数量与母本页书架数在经典下没有意义，却仍可编辑。",
    baseline: "不适用。",
    current: "CLASSIC_LOCKED_KEYS 未包含 tier1_bookshelves、tier2_bookshelves、tier3_qualifying_enchantments、early_unlock_xp_levels、early_unlock_grit_count、sacrifice_required、tome_page_required_shelves；它们对应的残卷还原与母本页在经典下均被禁用。",
    recommendations: [
      "把上述键加入锁定集合，或为其 activeWhen 增加 !classic103Mode 并复用 reason.classic_1_0_3。",
    ],
    acceptance: "经典下配置面板中没有可编辑却不产生任何效果的选项。",
    related: ["config-links"],
    evidence: [
      ev("本轮：锁定键清单", "current", catalogJava, "L353-L370"),
      ev("本轮：母本页相关选项", "current", catalogJava, "L650-L672"),
      ev("本轮：残卷档位选项", "current", catalogJava, "L850-L866"),
    ],
  },
];

export const retained = [
  {
    title: "64 堆叠作为保留改进",
    text: "1.0.3 标签的 build.gradle 排除了 accessor mixin，源码里 64 堆叠仍是 TODO；本轮把它写进 inert_note 并说明需重启。只是强制方式与启动期校验冲突（R2-01）。",
    source: sourceUrl("baseline", "build.gradle", "L84-L88"),
  },
  {
    title: "铁砧与箱子战利品的旧 mixin",
    text: "维护者指出 1.0.3 构建排除了 RemoveXpCostScaling、structureProcessor 与 modifyChestLootTable；核对标签 build.gradle 第 84–88 行属实，所以 anvilFlatRepairCost=false 与 KEEP_BOTH 是忠实的。",
    source: sourceUrl("current", auditDoc, "L21-L26"),
  },
  {
    title: "经验按点数扣除与多词条合并计费",
    text: "标签源码本身已使用 pointsForLevelCost；多词条双书合并逐条收费是反套利修复。两者都不是 1.0.3 的玩法规则，保留合理，并应在预设说明中列为已知差异。",
    source: sourceUrl("current", handler, "L2022-L2051"),
  },
  {
    title: "世界生成死锁修复、成本同步与存档兼容注册",
    text: "与玩法无关的移植修复继续保留；新物品保持注册以保障旧存档，经典下由各自门禁置为无效。",
    source: sourceUrl("current", auditDoc, "L21-L26"),
  },
];

export const ciEvidence = [
  { label: "compile-check 最近一次", value: "成功（a93d6c6）", note: "compileJava 后触发 JUnit，日志回写到分支" },
  { label: "经典相关单元测试", value: "5 项通过", note: "强制联动、旧表接入、子上限归零、选项锁定、升书 JSON" },
  { label: "专用服冒烟", value: "BUILD SUCCESSFUL", note: "runServer 启动、reload、stop 均正常" },
  { label: "中间提交", value: "3 次测试失败后修正", note: "classicFrameUses103CostAndBookUpgradeTables 在注册表引导上反复" },
];

export const auditApi = [
  {
    title: "网络与服务端校验",
    code: "ServerPlayNetworking.registerGlobalReceiver",
    text: "刷新、锁定、母本页操作的收包处理器仍然注册，但处理器方法在经典下直接返回，符合“服务端门禁而非隐藏按钮”的要求。协议修订号未因本轮改动而变化，线格式没有新增字段。",
    source: sourceUrl("current", `${java}menu/EnchantingNetworking.java`, "L82-L114"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/networking/v1/ServerPlayNetworking.html",
  },
  {
    title: "资源重载与随包数据",
    code: "ResourceManagerHelper.get(PackType.SERVER_DATA)",
    text: "三张经典 JSON 以随包资源方式读取，不经过资源管理器，因此 /reload 与外部数据包都不影响它们；这正是 R2-09 需要向服主说明的边界。",
    source: sourceUrl("current", dataJava, "L152-L155"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/resource/ResourceManagerHelper.html",
  },
  {
    title: "附魔书堆叠上限",
    code: "DefaultItemComponentEvents.MODIFY",
    text: "MAX_STACK_SIZE 仍在 onInitialize 期间一次性写入；它是启动期组件，不应被运行时配置的 compact constructor 强制改写，否则就会出现 R2-01 的校验冲突。",
    source: sourceUrl("current", `${java}ChiseledEnchantingTable.java`, "L38-L50"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/item/v1/DefaultItemComponentEvents.html",
  },
  {
    title: "配置生效与客户端同步",
    code: "RuntimeFrame + EnchantCostTablePayload",
    text: "经典的成本表、升书表与置换表已经进入运行帧并随 S2C 成本同步下发，这条链路可信；剩余的不一致（金苹果中点、JEI 静态信息）都出在没有走这条链路的分支。",
    source: sourceUrl("current", `${java}config/ModConfigNetworking.java`, "L188-L213"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/networking/v1/PayloadTypeRegistry.html",
  },
];

export const roadmap = [
  {
    number: "01",
    title: "解开启动期键的强制",
    body: "先处理 R2-01：让经典预设不再改写 enchanted_book_stack_size 的有效值，保存失败时给出具体原因。这是唯一会让预设完全不可用的问题。",
    output: "涉及：ModRuntimeConfig / RuntimeRules / ModConfigNetworking",
  },
  {
    number: "02",
    title: "补齐经典求值器",
    body: "把按玩家盐值的选项选择与范围取数做成经典运行帧的统一入口，附魔、研究与置换共用，S2C 成本行随之携带玩家视角的结果；同时把研究取整改回 floor。",
    output: "涉及：ChiseledEnchantingTableData / EnchantCostTablePayload / 测试",
  },
  {
    number: "03",
    title: "收尾文案与查看器",
    body: "修正字面 \\n、JEI 减免行、秘典剩余章节与图示、预设措辞；JEI 信息页改为渲染时读取配置或提示重进。",
    output: "涉及：11 个语言文件 / JEI / Grimoire / Wiki",
  },
  {
    number: "04",
    title: "写明数据包与锁的边界",
    body: "在配置面板与说明里写清经典忽略同名数据包、旧锁如何解除、无效选项为何锁定，让“经典”成为一组可核对的承诺。",
    output: "涉及：ConfigCatalog / 文案 / 文档",
  },
];

export const testCases = [
  { scenario: "stack=1 启动后运行时启用经典", expected: "保存成功并提示重启后 64 生效", layer: "配置管线" },
  { scenario: "两名玩家查看保护 IV 材料", expected: "各自得到 1.0.3 公式的选项与数量，台内与查看器一致", layer: "经济 + 同步" },
  { scenario: "锋利 III 单书进修", expected: "经典扣 7 级（floor），标准保持现行", layer: "数据表" },
  { scenario: "金苹果置换悬停与实扣", expected: "JEI/REI、行与扣料的绿宝石数量相同", layer: "查看器" },
  { scenario: "JEI 悬停附魔台（经典）", expected: "三行要点正常换行，无“最多省 0%”", layer: "文案" },
  { scenario: "逐页翻阅秘典（经典）", expected: "所有非经典章节与图示都有提示", layer: "手册" },
  { scenario: "高负载免磨损母本铭刻", expected: "经典无串行；标准按概率（回归保护）", layer: "服务端结算" },
  { scenario: "32+ 书架下发送刷新/锁定包", expected: "经典不扣费不改种子（回归保护）", layer: "网络门禁" },
];
