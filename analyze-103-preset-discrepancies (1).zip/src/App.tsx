import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  Copy,
  Menu,
  Search,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import {
  auditApi,
  categoryLabels,
  ciEvidence,
  currentBranch,
  findings,
  recheck,
  repository,
  retained,
  revisions,
  roadmap,
  sourceUrl,
  statusLabels,
  testCases,
  type Category,
  type Evidence,
  type Finding,
  type RecheckItem,
  type Status,
} from "./reportData";

type Filter = "all" | Category;
type StatusFilter = "all" | Status;

const navigation = [
  { id: "overview", number: "00", label: "复检概览" },
  { id: "scope", number: "01", label: "对照口径" },
  { id: "recheck", number: "02", label: "原 14 项复检" },
  { id: "findings", number: "03", label: "本轮新发现" },
  { id: "retained", number: "04", label: "保留项核实" },
  { id: "api", number: "05", label: "26.1.2 API" },
  { id: "plan", number: "06", label: "实施顺序" },
  { id: "tests", number: "07", label: "验收矩阵" },
  { id: "sources", number: "08", label: "证据边界" },
];

const categoryFilters: { id: Filter; label: string }[] = [
  { id: "all", label: "全部" },
  { id: "mechanic", label: categoryLabels.mechanic },
  { id: "economy", label: categoryLabels.economy },
  { id: "copy", label: categoryLabels.copy },
  { id: "content", label: categoryLabels.content },
];

const statusFilters: { id: StatusFilter; label: string }[] = [
  { id: "all", label: "全部" },
  { id: "fixed", label: statusLabels.fixed },
  { id: "partial", label: statusLabels.partial },
  { id: "open", label: statusLabels.open },
];

function BrandMark() {
  return (
    <svg className="brand-mark" width="35" height="35" viewBox="0 0 35 35" fill="none" aria-hidden="true">
      <path d="M5.5 8.5C10.2 7.2 14.2 8.2 17.5 10.6C20.8 8.2 24.8 7.2 29.5 8.5V25.9C24.8 24.6 20.8 25.6 17.5 28C14.2 25.6 10.2 24.6 5.5 25.9V8.5Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M17.5 10.7V28M9 13C10.8 12.7 12.2 12.8 13.7 13.5M21.3 13.5C22.8 12.8 24.2 12.7 26 13" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
      <path d="M10 17H13.3M21.7 17H25" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}

function SectionHeading({
  number,
  eyebrow,
  title,
  description,
  inverted = false,
}: {
  number: string;
  eyebrow: string;
  title: string;
  description?: string;
  inverted?: boolean;
}) {
  return (
    <div className={`section-heading${inverted ? " section-heading-inverted" : ""}`}>
      <span className="section-index">{number}</span>
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h2>{title}</h2>
        {description ? <p>{description}</p> : null}
      </div>
    </div>
  );
}

function EvidenceLink({ item }: { item: Evidence }) {
  const tone = item.revision === "1.0.3" ? "is-old" : item.revision === "上一轮" ? "is-prev" : "";
  return (
    <a href={item.url} target="_blank" rel="noopener noreferrer" className="evidence-link">
      <span className={`evidence-revision ${tone}`}>{item.revision}</span>
      <span>{item.label}</span>
      <ArrowUpRight size={13} strokeWidth={1.8} aria-hidden="true" />
    </a>
  );
}

function StatusBadge({ status }: { status: Status }) {
  return <span className={`status-badge status-${status}`}>{statusLabels[status]}</span>;
}

function RecheckRow({
  item,
  open,
  toggle,
  jump,
  reducedMotion,
}: {
  item: RecheckItem;
  open: boolean;
  toggle: () => void;
  jump: (id: string) => void;
  reducedMotion: boolean;
}) {
  const related = (item.residual ?? [])
    .map((id) => findings.find((finding) => finding.id === id))
    .filter((finding): finding is Finding => finding !== undefined);
  const detailId = `${item.id}-recheck`;

  return (
    <article className={`recheck-item ${open ? "recheck-open" : ""}`} id={item.id}>
      <button type="button" className="recheck-toggle" onClick={toggle} aria-expanded={open} aria-controls={detailId}>
        <span className="recheck-number">{item.number}</span>
        <span className="recheck-main">
          <span className="recheck-topline">
            <StatusBadge status={item.status} />
            <span className="recheck-category">{categoryLabels[item.category]}</span>
          </span>
          <span className="recheck-title">{item.title}</span>
          <span className="recheck-original">上一轮：{item.original}</span>
        </span>
        <span className={`finding-chevron ${open ? "finding-chevron-open" : ""}`}>
          <ChevronDown size={20} strokeWidth={1.6} aria-hidden="true" />
        </span>
      </button>
      <AnimatePresence initial={false}>
        {open ? (
          <motion.div
            id={detailId}
            className="finding-detail-clip"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: reducedMotion ? 0 : 0.3, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="recheck-detail">
              <div className="recheck-block">
                <span className="detail-label"><i /> 本轮核实</span>
                <p>{item.recheck}</p>
              </div>
              {related.length ? (
                <div className="recheck-related">
                  <span className="detail-label detail-label-accent">残留项</span>
                  <div className="related-chips">
                    {related.map((finding) => (
                      <button type="button" key={finding.id} onClick={() => jump(finding.id)}>
                        <span>{finding.number}</span>{finding.title} <ArrowUpRight size={12} />
                      </button>
                    ))}
                  </div>
                </div>
              ) : null}
              <div className="evidence-footer">
                <span className="detail-label">源码证据</span>
                <div className="evidence-list">
                  {item.evidence.map((evidence) => <EvidenceLink key={evidence.url} item={evidence} />)}
                </div>
              </div>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </article>
  );
}

function FindingRow({
  finding,
  open,
  toggle,
  copyLink,
  jump,
  reducedMotion,
}: {
  finding: Finding;
  open: boolean;
  toggle: () => void;
  copyLink: () => void;
  jump: (id: string) => void;
  reducedMotion: boolean;
}) {
  const detailId = `${finding.id}-details`;
  const related = (finding.related ?? [])
    .map((id) => recheck.find((item) => item.id === id))
    .filter((item): item is RecheckItem => item !== undefined);

  return (
    <article className={`finding ${open ? "finding-open" : ""}`} id={finding.id}>
      <button type="button" className="finding-toggle" onClick={toggle} aria-expanded={open} aria-controls={detailId}>
        <span className="finding-side">
          <span className="finding-number">{finding.number}</span>
          <span className={`priority priority-${finding.priority.toLowerCase()}`}>{finding.priority}</span>
        </span>
        <span className="finding-main">
          <span className="finding-category">{categoryLabels[finding.category]}</span>
          <span className="finding-title">{finding.title}</span>
          <span className="finding-summary">{finding.summary}</span>
        </span>
        <span className={`finding-chevron ${open ? "finding-chevron-open" : ""}`}>
          <ChevronDown size={20} strokeWidth={1.6} aria-hidden="true" />
        </span>
      </button>

      <AnimatePresence initial={false}>
        {open ? (
          <motion.div
            id={detailId}
            className="finding-detail-clip"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: reducedMotion ? 0 : 0.3, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="finding-detail">
              <div className="comparison">
                <div className="comparison-cell">
                  <span className="detail-label"><i /> 1.0.3 标签源码</span>
                  <p>{finding.baseline}</p>
                </div>
                <div className="comparison-cell">
                  <span className="detail-label"><i /> 本轮 {revisions.current.short}</span>
                  <p>{finding.current}</p>
                </div>
              </div>
              <div className="recommendation">
                <div className="detail-label detail-label-accent">建议如何改</div>
                <ol>
                  {finding.recommendations.map((item) => <li key={item}>{item}</li>)}
                </ol>
              </div>
              <div className="acceptance">
                <div className="detail-label">如何验收</div>
                <p>{finding.acceptance}</p>
              </div>
              {finding.caveat ? <p className="finding-caveat">判断边界：{finding.caveat}</p> : null}
              {related.length ? (
                <div className="recheck-related">
                  <span className="detail-label">对应原问题</span>
                  <div className="related-chips">
                    {related.map((item) => (
                      <button type="button" key={item.id} onClick={() => jump(item.id)}>
                        <span>{item.number}</span>{item.title} <ArrowUpRight size={12} />
                      </button>
                    ))}
                  </div>
                </div>
              ) : null}
              <div className="evidence-footer">
                <div className="evidence-header">
                  <span className="detail-label">源码证据</span>
                  <button type="button" onClick={copyLink} className="copy-issue">
                    <Copy size={14} aria-hidden="true" /> 复制此问题链接
                  </button>
                </div>
                <div className="evidence-list">
                  {finding.evidence.map((item) => <EvidenceLink key={item.url} item={item} />)}
                </div>
              </div>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </article>
  );
}

export default function App() {
  const [activeSection, setActiveSection] = useState("overview");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set(["startup-stack-conflict"]));
  const [toast, setToast] = useState("");
  const prefersReducedMotion = useReducedMotion();

  const statusCounts = useMemo(() => {
    const result: Record<StatusFilter, number> = { all: recheck.length, fixed: 0, partial: 0, open: 0 };
    for (const item of recheck) result[item.status] += 1;
    return result;
  }, []);

  const priorityCounts = useMemo(() => {
    const result = { P1: 0, P2: 0, P3: 0 };
    for (const item of findings) result[item.priority] += 1;
    return result;
  }, []);

  const categoryCounts = useMemo(() => {
    const result: Record<Filter, number> = { all: findings.length, mechanic: 0, economy: 0, copy: 0, content: 0 };
    for (const item of findings) result[item.category] += 1;
    return result;
  }, []);

  const visibleRecheck = useMemo(
    () => recheck.filter((item) => statusFilter === "all" || item.status === statusFilter),
    [statusFilter],
  );

  const visibleFindings = useMemo(() => {
    const term = query.trim().toLocaleLowerCase();
    return findings.filter((item) => {
      if (filter !== "all" && item.category !== filter) return false;
      if (!term) return true;
      return [
        item.number,
        item.title,
        item.summary,
        item.baseline,
        item.current,
        item.recommendations.join(" "),
        item.acceptance,
        categoryLabels[item.category],
        item.priority,
      ].join(" ").toLocaleLowerCase().includes(term);
    });
  }, [filter, query]);

  const allVisibleExpanded = visibleFindings.length > 0 && visibleFindings.every((item) => expanded.has(item.id));

  useEffect(() => {
    const sections = navigation
      .map((item) => document.getElementById(item.id))
      .filter((item): item is HTMLElement => item !== null);
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((entry) => entry.isIntersecting);
        if (visible.length > 0) setActiveSection(visible[visible.length - 1].target.id);
      },
      { rootMargin: "-15% 0px -68% 0px", threshold: 0 },
    );
    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const hash = decodeURIComponent(window.location.hash.slice(1));
    const known = findings.some((item) => item.id === hash) || recheck.some((item) => item.id === hash);
    if (known) {
      setExpanded((previous) => new Set([...previous, hash]));
      const timer = window.setTimeout(() => document.getElementById(hash)?.scrollIntoView(), 180);
      return () => window.clearTimeout(timer);
    }
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2700);
    return () => window.clearTimeout(timer);
  }, [toast]);

  function toggleId(id: string) {
    setExpanded((previous) => {
      const next = new Set(previous);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function toggleVisibleFindings() {
    setExpanded((previous) => {
      const next = new Set(previous);
      visibleFindings.forEach((item) => {
        if (allVisibleExpanded) next.delete(item.id);
        else next.add(item.id);
      });
      return next;
    });
  }

  function jumpTo(id: string) {
    if (findings.some((item) => item.id === id)) {
      setFilter("all");
      setQuery("");
    } else {
      setStatusFilter("all");
    }
    setExpanded((previous) => new Set([...previous, id]));
    window.setTimeout(
      () => document.getElementById(id)?.scrollIntoView({ behavior: prefersReducedMotion ? "auto" : "smooth" }),
      60,
    );
  }

  async function copyText(text: string, message: string) {
    try {
      await navigator.clipboard.writeText(text);
      setToast(message);
    } catch {
      window.prompt("复制以下内容", text);
    }
  }

  const checklistText = [
    "纂刻附魔台 / 1.0.3 预设第二轮验收清单",
    ...testCases.map((item, index) => `${index + 1}. [ ] ${item.scenario}：${item.expected}（${item.layer}）`),
    `本轮快照：${repository}/tree/${revisions.current.ref}；基线：${repository}/tree/${revisions.baseline.ref}`,
  ].join("\n");

  return (
    <div className="app-shell">
      <div className="mobile-header">
        <div className="mobile-brand"><BrandMark /><span>纂刻附魔台 <small>第二轮复检</small></span></div>
        <button type="button" className="mobile-menu-button" onClick={() => setMobileNavOpen(!mobileNavOpen)} aria-expanded={mobileNavOpen} aria-label={mobileNavOpen ? "关闭目录" : "打开目录"}>
          {mobileNavOpen ? <X size={23} /> : <Menu size={23} />}
        </button>
      </div>

      {mobileNavOpen ? <button type="button" className="sidebar-scrim" onClick={() => setMobileNavOpen(false)} aria-label="关闭目录" /> : null}

      <aside className={`sidebar ${mobileNavOpen ? "sidebar-open" : ""}`}>
        <a href="#overview" className="sidebar-brand" onClick={() => setMobileNavOpen(false)}>
          <BrandMark />
          <span><strong>纂刻附魔台</strong><small>CHISELED ENCHANTING TABLE</small></span>
        </a>
        <div className="sidebar-report-title">
          <span className="sidebar-overline">SOURCE AUDIT / 002</span>
          <p>1.0.3 预设<br />第二轮复检</p>
        </div>
        <div className="sidebar-nav-label">报告目录</div>
        <nav aria-label="报告目录" className="sidebar-nav">
          {navigation.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              className={`sidebar-nav-item ${activeSection === item.id ? "sidebar-nav-active" : ""}`}
              onClick={() => {
                setActiveSection(item.id);
                setMobileNavOpen(false);
              }}
            >
              {activeSection === item.id ? <motion.span layoutId="active-nav" className="nav-active-line" transition={{ duration: prefersReducedMotion ? 0 : 0.25 }} /> : null}
              <span className="nav-number">{item.number}</span>
              <span>{item.label}</span>
              {item.id === "recheck" ? <span className="nav-count">{recheck.length}</span> : null}
              {item.id === "findings" ? <span className="nav-count">{findings.length}</span> : null}
            </a>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-bottom-label">对照版本</div>
          <div className="sidebar-version"><span>基线标签</span><strong>1.0.3</strong></div>
          <div className="sidebar-version"><span>上一轮</span><strong>{revisions.previous.short}</strong></div>
          <div className="sidebar-version"><span>本轮</span><strong>{revisions.current.short}</strong></div>
          <a href={`${repository}/tree/${currentBranch}`} target="_blank" rel="noopener noreferrer" className="sidebar-repo">打开本轮分支 <ArrowUpRight size={15} /></a>
        </div>
      </aside>

      <div className="main-area">
        <header className="topbar">
          <div className="topbar-path"><span className="path-root">RECHECK</span><span className="path-divider">/</span><span>MC 26.1.2</span><span className="path-divider">/</span><span>arena/8eb3bb9e</span></div>
          <div className="topbar-links">
            <a href={`${repository}/tree/${revisions.baseline.ref}`} target="_blank" rel="noopener noreferrer">1.0.3 标签 <ArrowUpRight size={13} /></a>
            <a href={`${repository}/tree/${revisions.current.ref}`} target="_blank" rel="noopener noreferrer">本轮源码 <ArrowUpRight size={13} /></a>
          </div>
        </header>

        <main>
          <section id="overview" className="hero content-width">
            <div className="hero-copy">
              <div className="hero-kicker"><span className="kicker-line" /> 第二轮源码复检 / 针对维护者修复分支</div>
              <h1>纂刻附魔台</h1>
              <h2>“1.0.3 原味”预设<br /><em>修复后的再检测</em></h2>
              <p className="hero-description">对照维护者在新分支上的第二轮修复，逐项核对上一轮 14 个问题的真实状态，并把本轮新引入或残留的偏差单独列出。每个判断仍指向 1.0.3 标签与本轮源码的具体行号。</p>
              <div className="hero-links">
                <a href="#recheck" className="hero-primary">查看逐项复检 <ArrowDownRight size={18} strokeWidth={1.7} /></a>
                <a href="#findings" className="hero-secondary">直接看新发现 <ArrowRight size={16} strokeWidth={1.7} /></a>
              </div>
            </div>
            <div className="hero-compare" aria-hidden="true">
              <div className="hero-compare-label">RECHECK / STATUS</div>
              <div className="hero-stat"><strong>{statusCounts.fixed}</strong><span>已修复</span></div>
              <div className="hero-stat hero-stat-partial"><strong>{statusCounts.partial}</strong><span>部分修复</span></div>
              <div className="hero-stat hero-stat-new"><strong>{findings.length}</strong><span>本轮新发现 / 残留</span></div>
              <div className="hero-compare-foot">P1 ×{priorityCounts.P1} · P2 ×{priorityCounts.P2} · P3 ×{priorityCounts.P3}</div>
            </div>
          </section>

          <section className="verdict-band">
            <div className="content-width verdict-inner">
              <div className="verdict-side"><span className="verdict-line" /> 复检结论 <span>AT A GLANCE</span></div>
              <div className="verdict-copy"><strong>行为层的门禁基本补齐，数据层的“一致”还停留在文件相同。</strong><p>抄错、顿悟刷新、补差价文案、减免细项、解锁过滤等上一轮的关键问题都已在服务端与界面落地，并有单元测试覆盖。剩余偏差集中在三处：经典对启动期堆叠键的强制会让非 64 启动的服务器无法保存预设；成本表虽逐字节复制，但求值语义（选项、范围、取整）仍是 1.1.0；JEI 与秘典还有几处标准模式的叙述和一个字面 \\n 的文案缺陷。</p></div>
            </div>
          </section>

          <section id="scope" className="report-section content-width scope-section">
            <SectionHeading number="01" eyebrow="AUDIT BASIS / 判定口径" title="这次比较的是三个版本" description="基线仍是 1.0.3 标签；上一轮快照用来证明问题曾经存在；本轮快照是维护者标注“第二轮修复”的分支头。" />
            <div className="scope-grid scope-grid-three">
              {(["baseline", "previous", "current"] as const).map((key) => (
                <div className="scope-column" key={key}>
                  <span className="scope-column-top">{key === "baseline" ? "BASELINE / 基线" : key === "previous" ? "PREVIOUS / 上一轮" : "CURRENT / 本轮"}</span>
                  <h3>{revisions[key].ref}</h3>
                  <p>{revisions[key].detail}</p>
                  <a href={`${repository}/tree/${revisions[key].ref}`} target="_blank" rel="noopener noreferrer" className="text-link">打开快照 <ArrowUpRight size={15} /></a>
                </div>
              ))}
            </div>
            <div className="scope-boundary">
              <span>维护者自述</span>
              <p>本轮分支附带 docs/reports/CLASSIC_1_0_3_AUDIT.md，对上一轮 14 项逐条给出处置；本报告不以该文件为证据，而是重新读取代码、数据与 CI 日志逐项核实，核实不符的地方写入“本轮新发现”。</p>
              <a href={sourceUrl("current", "docs/reports/CLASSIC_1_0_3_AUDIT.md")} target="_blank" rel="noopener noreferrer">查看维护者记录 <ArrowUpRight size={13} /></a>
            </div>
            <div className="ci-grid">
              {ciEvidence.map((item) => (
                <div className="ci-cell" key={item.label}>
                  <span className="ci-label">{item.label}</span>
                  <strong>{item.value}</strong>
                  <p>{item.note}</p>
                </div>
              ))}
              <a className="ci-link" href={sourceUrl("current", "build-reports/compile-java.log")} target="_blank" rel="noopener noreferrer">查看回写的 CI 日志 <ArrowUpRight size={13} /></a>
            </div>
          </section>

          <section id="recheck" className="report-section content-width recheck-section">
            <SectionHeading number="02" eyebrow="RECHECK / 逐项复检" title="上一轮 14 项的真实状态" description="“已修复”表示服务端行为与界面都已核实；“部分修复”表示主路径已改，但存在可测量的残留，残留项在本轮新发现中单列。" />
            <div className="finding-tools">
              <div className="filter-tabs" role="group" aria-label="按状态筛选">
                {statusFilters.map((item) => (
                  <button key={item.id} type="button" className={`filter-tab ${statusFilter === item.id ? "filter-active" : ""}`} onClick={() => setStatusFilter(item.id)} aria-pressed={statusFilter === item.id}>
                    {item.label} <span>{statusCounts[item.id]}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="recheck-list">
              {visibleRecheck.map((item) => (
                <RecheckRow
                  key={item.id}
                  item={item}
                  open={expanded.has(item.id)}
                  toggle={() => toggleId(item.id)}
                  jump={jumpTo}
                  reducedMotion={Boolean(prefersReducedMotion)}
                />
              ))}
            </div>
          </section>

          <section id="findings" className="report-section content-width findings-section">
            <SectionHeading number="03" eyebrow="NEW FINDINGS / 本轮新发现与残留" title="修复引入的新问题，以及没修到底的旧问题" description="按优先级排序：P1 会阻断预设或造成明显错误显示；P2 是可测量的行为或文案偏差；P3 是边界情形。" />
            <div className="finding-tools">
              <div className="filter-tabs" role="group" aria-label="按类别筛选问题">
                {categoryFilters.map((item) => (
                  <button key={item.id} type="button" className={`filter-tab ${filter === item.id ? "filter-active" : ""}`} onClick={() => setFilter(item.id)} aria-pressed={filter === item.id}>
                    {item.label} <span>{categoryCounts[item.id]}</span>
                  </button>
                ))}
              </div>
              <div className="finding-utilities">
                <label className="search-field">
                  <Search size={16} strokeWidth={1.7} aria-hidden="true" />
                  <span className="sr-only">搜索问题内容</span>
                  <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索编号、关键词或源码问题" />
                  {query ? <button type="button" onClick={() => setQuery("")} aria-label="清除搜索"><X size={14} /></button> : null}
                </label>
                <button type="button" className="expand-all" onClick={toggleVisibleFindings} disabled={visibleFindings.length === 0}>{allVisibleExpanded ? "收起当前" : "展开当前"}</button>
              </div>
            </div>
            <div className="findings-result" aria-live="polite">显示 {visibleFindings.length} 项 / 共 {findings.length} 项</div>
            <div className="finding-list">
              {visibleFindings.length ? visibleFindings.map((item) => (
                <FindingRow
                  key={item.id}
                  finding={item}
                  open={expanded.has(item.id)}
                  toggle={() => toggleId(item.id)}
                  copyLink={() => copyText(`${window.location.origin}${window.location.pathname}#${item.id}`, "问题链接已复制")}
                  jump={jumpTo}
                  reducedMotion={Boolean(prefersReducedMotion)}
                />
              )) : <div className="empty-results"><Search size={28} strokeWidth={1.3} /><strong>没有找到对应问题</strong><p>试试其他关键词，或切回“全部”。</p><button type="button" onClick={() => { setQuery(""); setFilter("all"); }}>清除筛选 <ArrowRight size={15} /></button></div>}
            </div>
          </section>

          <section id="retained" className="report-section content-width retained-section">
            <SectionHeading number="04" eyebrow="RETAINED / 保留项核实" title="哪些差异是合理保留，而不是漏改" description="维护者声明了若干“故意不回退”的修复。逐条对照标签源码后，这些声明成立，但应在预设说明中列为已知差异。" />
            <div className="retained-list">
              {retained.map((item, index) => (
                <div className="retained-row" key={item.title}>
                  <span className="api-number">0{index + 1}</span>
                  <div className="retained-copy">
                    <h3>{item.title}</h3>
                    <p>{item.text}</p>
                    <a href={item.source} target="_blank" rel="noopener noreferrer" className="text-link">核对来源 <ArrowUpRight size={15} /></a>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section id="api" className="api-section">
            <div className="content-width">
              <SectionHeading number="05" eyebrow="IMPLEMENTATION CONTEXT / API 校核" title="建议仍落在 26.1.2 的 API 上" description="对照本轮的实际调用与 Fabric API 0.151.0+26.1.2 文档；依赖版本未变（Minecraft 26.1.2、Loader 0.19.3、Fabric API 0.151.0+26.1.2）。" inverted />
              <div className="api-list">
                {auditApi.map((item, index) => (
                  <div className="api-row" key={item.title}>
                    <span className="api-number">0{index + 1}</span>
                    <div className="api-main"><h3>{item.title}</h3><code>{item.code}</code><p>{item.text}</p><div className="api-links"><a href={item.source} target="_blank" rel="noopener noreferrer">分支调用 <ArrowUpRight size={13} /></a><a href={item.api} target="_blank" rel="noopener noreferrer">26.1.2 官方 API <ArrowUpRight size={13} /></a></div></div>
                  </div>
                ))}
              </div>
              <p className="api-footnote">依赖版本以仓库 <a href={sourceUrl("current", "gradle.properties", "L5-L26")} target="_blank" rel="noopener noreferrer">gradle.properties</a> 为准。本轮没有新增网络字段或资源条件，所有修复都在现有 API 用法内完成。</p>
            </div>
          </section>

          <section id="plan" className="report-section content-width plan-section">
            <SectionHeading number="06" eyebrow="EXECUTION / 建议顺序" title="先解除阻断，再补齐求值，最后收尾文案" description="四个批次可独立提交与验收；每一步都同时跑经典与标准两种模式。" />
            <div className="roadmap-list">
              {roadmap.map((item) => (
                <div className="roadmap-step" key={item.number}>
                  <div className="roadmap-marker">{item.number}</div>
                  <div className="roadmap-copy"><h3>{item.title}</h3><p>{item.body}</p><span>{item.output}</span></div>
                </div>
              ))}
            </div>
          </section>

          <section id="tests" className="report-section content-width tests-section">
            <SectionHeading number="07" eyebrow="ACCEPTANCE / 验收矩阵" title="第二轮应补的测试" description="前六项针对本轮新发现，后两项是上一轮已修复路径的回归保护；均为建议，不代表已在游戏内通过。" />
            <div className="test-table">
              <div className="test-head"><span>测试场景</span><span>预期结果</span><span>覆盖层</span></div>
              {testCases.map((test) => <div className="test-row" key={test.scenario}><span>{test.scenario}</span><span>{test.expected}</span><span>{test.layer}</span></div>)}
            </div>
            <button type="button" className="copy-checklist" onClick={() => copyText(checklistText, "验收清单已复制")}><Copy size={16} strokeWidth={1.7} /> 复制验收清单 <ArrowUpRight size={15} /></button>
          </section>

          <footer id="sources" className="footer-section">
            <div className="content-width footer-inner">
              <div className="footer-main">
                <span className="eyebrow">SOURCE NOTE / 证据边界</span>
                <h2>复检只认代码与日志，<br />不认处置表。</h2>
                <p>本页是对公开源码、随包数据与回写 CI 日志的静态复检，不是已合入的补丁，也没有在 Minecraft 客户端或专用服实测。R2-01 与 R2-08 的结论来自调用链推导，已在条目内标注判断边界；其余结论都能在引用的行号处直接读到。</p>
              </div>
              <div className="footer-sources">
                <span className="footer-sources-label">核对所用的一手材料</span>
                <a href={`${repository}/tree/${revisions.baseline.ref}`} target="_blank" rel="noopener noreferrer"><span>1.0.3 标签源码</span><ArrowUpRight size={15} /></a>
                <a href={`${repository}/tree/${revisions.previous.ref}`} target="_blank" rel="noopener noreferrer"><span>上一轮快照 {revisions.previous.short}</span><ArrowUpRight size={15} /></a>
                <a href={`${repository}/tree/${revisions.current.ref}`} target="_blank" rel="noopener noreferrer"><span>本轮快照 {revisions.current.short}</span><ArrowUpRight size={15} /></a>
                <a href={`${repository}/compare/${revisions.previous.ref}...${revisions.current.ref}`} target="_blank" rel="noopener noreferrer"><span>两轮之间的完整差异</span><ArrowUpRight size={15} /></a>
                <a href="https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/" target="_blank" rel="noopener noreferrer"><span>Fabric API 0.151.0 Javadoc</span><ArrowUpRight size={15} /></a>
              </div>
            </div>
            <div className="content-width footer-bottom"><span>纂刻附魔台 / 第二轮复检</span><span>BASELINE {revisions.baseline.ref} &nbsp; / &nbsp; PREVIOUS {revisions.previous.short} &nbsp; / &nbsp; CURRENT {revisions.current.short}</span><a href="#overview">返回顶部 <ArrowUpRight size={13} /></a></div>
          </footer>
        </main>
      </div>
      <AnimatePresence>
        {toast ? <motion.div className="toast" role="status" aria-live="polite" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} transition={{ duration: prefersReducedMotion ? 0 : 0.2 }}><Check size={16} />{toast}</motion.div> : null}
      </AnimatePresence>
    </div>
  );
}
