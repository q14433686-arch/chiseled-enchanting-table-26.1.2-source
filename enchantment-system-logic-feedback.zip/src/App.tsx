import { useEffect, useState } from "react";
import Hero from "./components/Hero";
import Upgrade from "./components/Upgrade";
import Refund from "./components/Refund";
import Wash from "./components/Wash";
import GateLadder from "./components/GateLadder";
import Residue from "./components/Residue";
import Ladder from "./components/Ladder";
import Decision from "./components/Decision";
import Closing from "./components/Closing";

const NAV = [
  { id: "upgrade", label: "壹 · 升阶当省", tone: "#e8c37c" },
  { id: "refund", label: "贰 · 降阶当返", tone: "#8df0a4" },
  { id: "wash", label: "叁 · 洗条当费", tone: "#f08cc8" },
  { id: "gate", label: "肆 · 升阶准入 38", tone: "#f08cc8" },
  { id: "residue", label: "伍 · 残卷三梯度", tone: "#7ee8dc" },
  { id: "ladder", label: "陆 · 书架总阶梯", tone: "#8df0a4" },
  { id: "decision", label: "决 · 双页同面", tone: "#a18cff" },
];

const SideNav = () => {
  const [active, setActive] = useState("");
  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) setActive(en.target.id);
        });
      },
      { rootMargin: "-40% 0px -55% 0px" },
    );
    NAV.forEach((n) => {
      const el = document.getElementById(n.id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, []);

  return (
    <nav className="fixed left-6 top-1/2 -translate-y-1/2 z-40 hidden xl:flex flex-col gap-5">
      {NAV.map((n) => (
        <a
          key={n.id}
          href={`#${n.id}`}
          className="group flex items-center gap-3"
        >
          <span
            className="w-2 h-2 rotate-45 transition-all duration-300"
            style={{
              background: active === n.id ? n.tone : "rgba(111,101,154,0.4)",
              boxShadow: active === n.id ? `0 0 10px ${n.tone}` : "none",
              transform: `rotate(45deg) scale(${active === n.id ? 1.3 : 1})`,
            }}
          />
          <span
            className="font-code text-[10px] tracking-[0.2em] whitespace-nowrap transition-all duration-300 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0"
            style={{ color: active === n.id ? n.tone : "#9c93bd" }}
          >
            {n.label}
          </span>
        </a>
      ))}
    </nav>
  );
};

const Divider = () => (
  <div className="max-w-6xl mx-auto px-6 md:px-10">
    <div className="flex items-center gap-6 py-2">
      <div className="gold-rule flex-1" />
      <span className="font-display text-arcane/40 text-sm select-none">᛭</span>
      <div className="gold-rule flex-1" />
    </div>
  </div>
);

export default function App() {
  return (
    <div className="noise relative min-h-screen bg-obsidian text-parch font-body selection:bg-arcane/30">
      <SideNav />
      <Hero />
      <main className="relative z-10">
        <Divider />
        <Upgrade />
        <Divider />
        <Refund />
        <Divider />
        <Wash />
        <Divider />
        <GateLadder />
        <Divider />
        <Residue />
        <Divider />
        <Ladder />
        <Divider />
        <Decision />
      </main>
      <Closing />
    </div>
  );
}
