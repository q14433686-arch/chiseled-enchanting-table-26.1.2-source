# 錾刻审计台 · Enchantment Fusion

针对用户指定 GitHub 分支的独立源码审计工作台。使用 React、Vite、Tailwind CSS 和 Lucide 图标构建。

## 审计基线

- 上游仓库：`q14433686-arch/chiseled-enchanting-table-26.1.2-source`
- 分支：`arena/11fcd984-chiseled-enchanting-table-26-1`
- 提交：`799622aec3eb93a8a9470970e2898faa4a0b743c`
- 模组：Enchantment Fusion 0.4.0
- 环境声明：Minecraft 26.1.2、Fabric、Java 25

`audit-upstream/` 是只读上游克隆。本项目没有修改或推送上游源码。原文通过 Vite raw import 打包，源码浏览器不依赖运行时 GitHub API。

## 页面与功能

1. **审计总览**：20 条记录、7 条主审计路径、状态/优先级/路径/关键词筛选、证据详情、复核标记与个人笔记。
2. **源码浏览器**：锁定提交的原文、文件与内容搜索、行号跳转、证据高亮、关联记录、原文下载。
3. **数值与机制**：按 Java 经济公式复算合成/转换费用、失败率、有效触媒上限、半费取整与装备免伤概率叠加。
4. **文字与术语**：9 条独立校订建议、原文/校订/并排模式、编辑与本地保存、占位符检查、采纳清单、语义预览、术语表及 Markdown 导出。
5. **存疑与建议**：7 个带已知事实、未知条件、验证步骤与决策依据的问题，个人验证进度和分阶段推进建议。

全局支持 Ctrl/Cmd+K 搜索、最近查看、报告导出（Markdown/JSON）、高可读模式和移动端导航。所有个人状态只保存在当前浏览器 localStorage；没有后端、登录或虚构同步。

## 审计边界

已确认表示可以从静态代码路径推导的问题；待验证风险和设计建议不等于已证实的运行时故障。未运行上游 Java/Gradle/Minecraft，也未核实远端 CI 结果。网站自身的构建和浏览器回归，与模组游戏内测试是两回事。

重点静态观察包括：同书双候选的残留/复制路径、即时消耗品在实际成功使用前的返还、稳定晶说明与分级风险公式不一致、普通失败的牺牲输入选择，以及旧文档数量与名称漂移。

## 开发与验证

- 安装：`npm install`
- 开发：`npm run dev`
- 构建：`npm run build`
- 类型检查：`npx tsc --noEmit`
- 上游静态契约：`node scripts/verify-snapshot.mjs`

浏览器回归使用 Playwright。先启动 `npm run preview -- --port 4173`，再运行 `node scripts/smoke.mjs`。测试环境可额外安装 `npm install --no-save playwright` 与 `npx playwright install --with-deps chromium`。

`scripts/verify-snapshot.mjs` 校验固定提交、114 个唯一签名、36 个别名、115 个跨界变体、43 个矩阵配置，以及 11 个语言文件各 661 个键和占位符一致性。语言键一致不代表翻译语义或实际 GUI 排版已经验收。

## 视觉素材

`public/images/enchantment-study.png` 是为本项目生成的附魔台主题示意图，不是 Minecraft 游戏截图。游戏语义预览也明确标注为 Web 预览。