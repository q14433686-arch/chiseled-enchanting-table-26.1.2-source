import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Archive, ArrowDownToLine, ArrowUpRight, BookOpen, Box, Check, CheckCheck, CheckCircle2, ChevronRight, CircleHelp, Code2, Copy, Database, ExternalLink, FileCode2, FileText, GitBranch, Layers3, MousePointer2, Network, Puzzle, Search, ShieldCheck, SlidersHorizontal, TriangleAlert, X, type LucideIcon } from 'lucide-react';
import { githubUrl, statusLabels, type Evidence, type FindingStatus, type Severity } from '../data/audit';

export const categoryIcons: Record<string, LucideIcon> = { source: Code2, data: Database, network: Network, gui: MousePointer2, mixin: Puzzle, dead: Archive, coupling: Layers3, code: Code2, database: Database, mouse: MousePointer2, puzzle: Puzzle, archive: Archive, layers: Layers3 };
export function CategoryIcon({ name, size = 18, ...props }: { name: string; size?: number; className?: string }) { const Icon = categoryIcons[name] || Box; return <Icon size={size} strokeWidth={1.7} {...props} />; }
export function SeverityBadge({ value }: { value: Severity }) { return <span className={`severity severity-${value.toLowerCase()}`}><span className="severity-dot" />{value}<span className="severity-word">{value === 'P1' ? '高' : value === 'P2' ? '中' : '低'}</span></span>; }
export function StatusBadge({ status }: { status: FindingStatus }) { const Icon = status === 'confirmed' ? CheckCircle2 : status === 'risk' ? CircleHelp : SlidersHorizontal; return <span className={`status-badge status-${status}`}><Icon size={12} />{statusLabels[status]}</span>; }
export function usePersistentState<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => { try { const saved = localStorage.getItem(key); return saved ? JSON.parse(saved) as T : initial; } catch { return initial; } });
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* The app remains usable when storage is unavailable. */ } }, [key, value]);
  return [value, setValue] as const;
}
export async function copyText(text: string) {
  if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(text); return; }
  const el = document.createElement('textarea'); el.value = text; el.style.position = 'fixed'; el.style.opacity = '0'; document.body.appendChild(el); el.select();
  const ok = document.execCommand('copy'); el.remove(); if (!ok) throw new Error('Clipboard unavailable');
}
export function downloadText(filename: string, text: string, type = 'text/markdown;charset=utf-8') {
  const url = URL.createObjectURL(new Blob([text], { type })); const a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function SourceLink({ file, line, short = false }: { file: string; line?: number; short?: boolean }) {
  return <a className="source-link" href={githubUrl(file, line)} target="_blank" rel="noreferrer" title={file}>{short ? file.split('/').pop() : file}{line ? `:${line}` : ''}<ArrowUpRight size={12} /></a>;
}
export function CodeBlock({ evidence }: { evidence: Evidence }) {
  return <div className="code-block"><div className="code-caption"><span><FileCode2 size={14} />证据摘读 · 以原文为准</span><a href={githubUrl(evidence.file, evidence.line)} target="_blank" rel="noreferrer">查看原文 <ExternalLink size={12} /></a></div><div className="code-origin">{evidence.file}:{evidence.line}</div><pre><code>{evidence.snippet.split('\n').map((line, i) => <span className="code-line" key={i}><span className="line-number" aria-hidden="true">{String(i + 1).padStart(2, '0')}</span><span>{highlightLine(line)}</span></span>)}</code></pre></div>;
}
export function highlightLine(line: string): ReactNode {
  const parts = line.split(/(\/\/.*$|"(?:\\.|[^"\\])*"|\b(?:public|private|static|final|return|if|else|new|for|int|float|double|boolean|void|record|implements|case|switch|true|false|null)\b|\b\d+(?:\.\d+)?[FDL]?\b)/g);
  return parts.map((part, i) => <span key={i} className={part.startsWith('//') ? 'syntax-comment' : part.startsWith('"') ? 'syntax-string' : /^(public|private|static|final|return|if|else|new|for|int|float|double|boolean|void|record|implements|case|switch|true|false|null)$/.test(part) ? 'syntax-keyword' : /^\d/.test(part) ? 'syntax-number' : undefined}>{part}</span>);
}
export function Dialog({ title, children, onClose, className = '', subtitle }: { title: string; children: ReactNode; onClose: () => void; className?: string; subtitle?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose); closeRef.current = onClose;
  useEffect(() => {
    const old = document.body.style.overflow; document.body.style.overflow = 'hidden';
    const previous = document.activeElement as HTMLElement | null;
    const timer = window.setTimeout(() => { const el = ref.current?.querySelector<HTMLElement>('[data-autofocus]') ?? ref.current?.querySelector<HTMLElement>('input, button, textarea, select, a[href]'); el?.focus(); }, 40);
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); closeRef.current(); }
      if (event.key === 'Tab') {
        const focusables = Array.from(ref.current?.querySelectorAll<HTMLElement>('button:not([disabled]), input, select, textarea, a[href], [tabindex="0"]') || []).filter(el => el.offsetParent !== null);
        const first = focusables[0]; const last = focusables[focusables.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => { clearTimeout(timer); document.body.style.overflow = old; document.removeEventListener('keydown', onKey); previous?.focus(); };
  }, []);
  return <div className={`dialog-backdrop ${className.includes('drawer') ? 'drawer-backdrop' : ''}`} onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><div ref={ref} role="dialog" aria-modal="true" aria-label={title} className={`dialog ${className}`}><header className="dialog-header"><div>{subtitle && <p className="eyebrow mb-2">{subtitle}</p>}<h2>{title}</h2></div><button className="icon-button" onClick={onClose} aria-label="关闭弹窗"><X size={20} /></button></header>{children}</div></div>;
}
export function EmptyState({ title = '没有找到匹配的记录', description = '试试更短的关键词，或清除筛选条件。', onReset }: { title?: string; description?: string; onReset?: () => void }) { return <div className="empty-state"><Search size={30} strokeWidth={1.3} /><h3>{title}</h3><p>{description}</p>{onReset && <button className="button button-secondary mt-4" onClick={onReset}>清除筛选</button>}</div>; }
export function SectionHeading({ icon: Icon = FileText, title, subtitle, action }: { icon?: LucideIcon; title: string; subtitle?: string; action?: ReactNode }) { return <div className="section-heading"><div className="flex items-center gap-2.5"><Icon size={18} strokeWidth={1.7} /><h2>{title}</h2>{subtitle && <span className="section-subtitle">{subtitle}</span>}</div>{action}</div>; }
export function CopyButton({ text, label = '复制', onDone }: { text: string; label?: string; onDone?: (message: string) => void }) {
  const [copied, setCopied] = useState(false);
  useEffect(() => { if (!copied) return; const t = setTimeout(() => setCopied(false), 2000); return () => clearTimeout(t); }, [copied]);
  return <button className="button button-secondary button-small" onClick={async () => { try { await copyText(text); setCopied(true); onDone?.('已复制到剪贴板'); } catch { onDone?.('无法访问剪贴板，请选中文本手动复制'); } }}>{copied ? <CheckCheck size={14} /> : <Copy size={14} />}{copied ? '已复制' : label}</button>;
}
export function PageHeading({ eyebrow, title, description, badge, action }: { eyebrow: string; title: string; description: string; badge?: string; action?: ReactNode }) { return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><div className="flex flex-wrap items-center gap-3 mt-2"><h1>{title}</h1>{badge && <span className="subtle-badge">{badge}</span>}</div><p>{description}</p></div>{action}</div>; }
export function SmallCheck({ checked, label }: { checked: boolean; label: string }) { return <span className={`small-check ${checked ? 'is-checked' : ''}`}>{checked ? <Check size={12} /> : <span />}{label}</span>; }
export { Archive, ArrowDownToLine, ArrowUpRight, BookOpen, Box, Check, CheckCircle2, ChevronRight, CircleHelp, Code2, Database, FileCode2, FileText, GitBranch, Layers3, Search, ShieldCheck, SlidersHorizontal, TriangleAlert };
