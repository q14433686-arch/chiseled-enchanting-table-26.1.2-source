import { githubUrl } from './audit';
export interface CopyIssue {
  id: string; category: 'accuracy' | 'readability' | 'consistency'; title: string; location: string;
  file: string; line: number; key: string; before: string; after: string; reason: string; caveat?: string; finding?: string;
}
const lang = 'src/client/resources/assets/enchantment_fusion/lang/zh_cn.json';
export const copyIssues: CopyIssue[] = [
  {
    id: 'TX-01', category: 'accuracy', title: '先说清风险，再承诺稳定', location: '物品说明 · 谐振稳定晶', file: lang, line: 5,
    key: 'item.enchantment_fusion.resonance_stabilizer.lore',
    before: '在融合满级互斥附魔时消除排斥波动，确保100%稳定成书。',
    after: '放入催化槽可降低融合失败率。互斥融合最多生效 3 个，失败率最低为 9%。',
    reason: '当前代码为 45% − 12% × 有效数量。把“必成”改为可验证的概率，并明确数量上限。物品 lore 是静态文案，操作区仍应显示本次实际概率。',
    caveat: '此校订以保留 0.4.0 分级风险机制为前提；若设计决定恢复必成，应先修机制再统一文案。', finding: 'EF-003'
  },
  {
    id: 'TX-02', category: 'accuracy', title: '失败损失，不要让玩家猜', location: '操作反馈 · 普通失败', file: lang, line: 599,
    key: 'message.enchantment_fusion.failure.normal_refund',
    before: '共鸣溃散：载体无恙，损耗副卷 1 本，已返还半数经验与材料费用。',
    after: '融合失败：装备已保留。消耗 1 本副位书，经验与材料按半费收取（向下取整）。',
    reason: '先报告玩家最关心的装备状态，再列出损失；“半费”指实际扣除，避免把“收取半价”误读成“返还半价”。',
    caveat: '目标文案依赖 EF-004 修复：当前 B 来自装备时可能消耗 A 书。修复前不能承诺只损耗副位书。', finding: 'EF-004'
  },
  {
    id: 'TX-03', category: 'consistency', title: '同一物品，只保留一个名字', location: '风险提示 / 秘典 · 触媒名称', file: lang, line: 609,
    key: 'gui.enchantment_fusion.tip.risk_high',
    before: '失稳风险：%s%%（失败将异变为畸变融合或沾染诅咒；置入共鸣稳定剂可压制）',
    after: '失败率：%s%%。失败可能产生异变或诅咒。放入「谐振稳定晶」可降低风险。',
    reason: '物品注册名是“谐振稳定晶”，不是“共鸣稳定剂”。统一术语，并把过长的原因说明拆成短句。保留 %s 与 %% 的格式化语义。', finding: 'EF-003'
  },
  {
    id: 'TX-04', category: 'accuracy', title: '旧版“必成”规则应明确退场', location: '设计文档 · §6.1', file: 'docs/GDD.md', line: 173,
    key: '§6.1 · 触发条件',
    before: '常规与跨界融合 100% 稳定成功；唯有在进行「死敌互斥满级强融」……存在 35% 排斥失稳率。',
    after: '融合按风险档位结算，非互斥融合也可能失败。互斥融合基础失败率为 45%；有效稳定晶可降低风险。本次费用与结果以操作预览为准。',
    reason: '0.4.0 已引入 tiered_risk，不应继续把旧版 100% / 35% 规则当成当前行为。历史机制可以保留在带版本号的变更记录中。',
    caveat: '原文此处为长句节选。当前实现还区分签名、高阶转化与书镶嵌，详细数值应链接到自动生成的规则表。', finding: 'EF-003'
  },
  {
    id: 'TX-05', category: 'consistency', title: '版本与数量，建立同一基线', location: 'README / GDD · 当前版本', file: 'docs/GDD.md', line: 4,
    key: 'Current baseline',
    before: '当前版本：0.3.1 · 42 种附魔 · 108 条共鸣 · 111 项化形 · 三页签',
    after: '当前版本：0.4.0 · Minecraft 26.1.2。43 个矩阵配置、114 个唯一签名、115 个跨界变体。工作台为两页签，秘典独立打开。',
    reason: '静态计数与 CURRENT_BASELINE 对齐。36 个 regAlias 是复用映射，不应计为新增签名；“8 × 14”是分类维度，不等于只能有 112 个效果。',
    caveat: '这里汇总了多行旧文案，并非连续原文。数量应由注册表自动生成，避免下次新增机制再次漂移。', finding: 'EF-018'
  },
  {
    id: 'TX-06', category: 'readability', title: '操作提示应能一眼扫读', location: '融合工作台 · 顶部引导', file: lang, line: 119,
    key: 'gui.enchantment_fusion.tab0.header_hint',
    before: '左键选[A主] · 右键选[B副] · 无需空白书直接凝练成书',
    after: '左键设 A · 右键设 B\n无需普通书，直接融合',
    reason: '把输入方式与产物说明拆成两层，减少中括号和术语堆叠。正文不宜依赖 0.56 倍缩字来容纳全部内容。',
    caveat: '换行需要对应 UI 布局调整；这是语义与布局建议，不是可直接替换便完成的纯文案补丁。', finding: 'EF-019'
  },
  {
    id: 'TX-07', category: 'readability', title: '槽位状态，统一标点与数字关系', location: '物品 Tooltip · 器魂容量', file: lang, line: 6,
    key: 'tooltip.enchantment_fusion.vessel_status',
    before: '器魂槽位: %s (%d/%d)',
    after: '器魂槽 %s · 已用 %d / %d',
    reason: '明确数字是“已用 / 上限”，用中文排版与中文标点统一视觉。保留一个 %s、两个 %d，不改变参数顺序。', finding: 'EF-019'
  },
  {
    id: 'TX-08', category: 'consistency', title: '姊妹模组名称也需要单一来源', location: '说明与净化提示 · 模组名称', file: 'docs/GDD.md', line: 54,
    key: 'Chiseled Enchanting Table display name',
    before: '《纂刻附魔台》……（语言文件与 README 中同时出现「雕纹附魔台」）',
    after: '仅可在「雕纹附魔台」进行净化。',
    reason: '暂按当前语言文件的“雕纹附魔台”统一，避免同一入口出现两个中文名。英文 ID 与显示名称分开维护。',
    caveat: '最终显示名应核对姊妹模组自身的官方语言文件；这里不擅自认定哪一个是官方正式名称。', finding: 'EF-018'
  },
  {
    id: 'TX-09', category: 'accuracy', title: '“0◇”不是“没有代价”', location: '秘典 · 跨界单附魔说明', file: 'docs/GDD.md', line: 8,
    key: 'Cross-domain vessel budget',
    before: '免占用 ◇ 器魂槽（0◇）完成异位铭刻。',
    after: '跨界铭刻不占用融合对的器魂槽，但会消耗附魔书、经验与材料。它仍写入物品的附魔数据。',
    reason: '槽位预算、费用预算与附魔组件数量是三个不同维度。明确边界，避免把 0◇ 理解为免费、无限或不保存数据。', finding: 'EF-017'
  },
];
export const copyCategories = { accuracy: '准确性', readability: '易读性', consistency: '一致性' };
export const glossary = [
  ['附魔融合台', '工作方块', '不使用“融合工作台 / 三页签台”混称'],
  ['融合附魔书', '承载一个有序融合对的物品', '与原版附魔书区分'],
  ['谐振稳定晶', '降低失败率的触媒', '不使用“共鸣稳定剂 / 稳定剂”作为物品正式名'],
  ['器魂槽', '融合对的容量单位', '0◇ 仅表示不占融合对槽位'],
  ['初识 → 通晓', '图鉴发现阶段', '线索解锁不等于效果已触发'],
  ['雕纹附魔台', '姊妹模组显示名（待核实）', '发布前以姊妹模组官方语言文件为准'],
];
export interface Question {
  id: string; title: string; domain: string; priority: string; hypothesis: string; known: string; unknown: string;
  experiment: string; decision: string; evidence: { label: string; url: string }; finding?: string;
}
export const questions: Question[] = [
  {
    id: 'Q-01', title: '先验证运行契约，而不是把 Java 25 当成错误', domain: '版本与兼容', priority: 'P0 · 发布门槛',
    hypothesis: '真正需要警惕的是可选入口与注入目标，而不是符合 26.1.2 的 Java 版本。',
    known: 'gradle.properties、Mixin 配置与构建均对齐 Java 25；目标 Minecraft 为 26.1.2。仓库声明 4 个 Mixin，并已有编译与客户端 smoke 流程。',
    unknown: '本次没有 Java 运行时，未执行上游 Gradle 构建、Mixin 应用或真实客户端 smoke；也没有查询该提交的远端 CI 结论。',
    experiment: '在干净环境用 Java 25 构建；分别测试无 JEI/REI、仅 JEI、仅 REI、有/无姊妹模组。保存启动日志、解析依赖版本与截图。',
    decision: '若最小环境不能启动，先处理入口与依赖；若所有目标注入命中，则不制造“版本不兼容”结论。',
    evidence: { label: '查看 Gradle 构建配置', url: githubUrl('build.gradle', 96) }, finding: 'EF-014'
  },
  {
    id: 'Q-02', title: '测试通过，能否说明书没有被复制', domain: '事务与回归', priority: 'P0 · 正确性',
    hypothesis: '当前测试更偏模型、规则与源码字符串约束，尚未覆盖完整的物品交易不变量。',
    known: '已阅读三个测试类；存在字符串 contains 断言与模型规则测试。EF-001/002 展示了静态代码可推导的复制路径。',
    unknown: '没有运行上游测试，不能把“存在测试”写成“测试通过”；也需验证实际随机分支与调用时序。',
    experiment: '为融合、失败、补强、拆解加入 ItemStack 快照测试：总附魔守恒、费用非负、输出满格不丢失、保存重载后等价。覆盖同书 A+B 与无效右键。',
    decision: '先锁定可复现损失/复制，再重构交易执行器。不要把大规模重写作为修复的第一步。',
    evidence: { label: '查看现有规则测试', url: githubUrl('src/test/java/enchantment_fusion/FusionRuleEngineTest.java', 272) }, finding: 'EF-001'
  },
  {
    id: 'Q-03', title: '顺序敏感，是“每一对都不同”吗', domain: '规则与语义', priority: 'P1 · 设计契约',
    hypothesis: '“[A ▷ B] ≠ [B ▷ A]”应描述核心能力，而非承诺所有顺序都会产生不同机制。',
    known: '静态表包含 114 个唯一签名与 36 个别名，部分正反序复用同一签名。融合后只把 A 写入原版 ENCHANTMENTS；补强 A 同步组件，补强 B 仅更新自定义 pair。',
    unknown: 'B 的非原生语义是否在所有翻转、卸下、第三方处理路径中保持一致，需要明确契约后测试。不能仅凭写入不对称判定 B 补强必然失效。',
    experiment: '列出所有正向/反向/别名组合，生成效果差异表。对 A/B 补强后翻转、拆解、再铭刻做状态往返测试。',
    decision: '把“部分组合共享效果”如实展示；只有确认 B 应在某一路径原生生效后，才改变组件同步策略。',
    evidence: { label: '查看签名与别名注册', url: githubUrl('src/main/java/enchantment_fusion/mechanics/SignaturePairs.java', 80) }, finding: 'EF-018'
  },
  {
    id: 'Q-04', title: '双倍的代价，是否真的有约束力', domain: '数值与机制', priority: 'P1 · 平衡验证',
    hypothesis: '多件免伤叠加与永不损坏的钳制，可能让招财金身的收益远大于表面代价。',
    known: 'III 级单件触发率为 25%。若四件独立判定，至少一次触发概率为 1 − 0.75⁴ ≈ 68.4%。当前惩罚在 maxDamage − 1 停止。',
    unknown: '实际承伤分布、装备耐久基数、生成条件与获取成本尚未实测，无法给出唯一“正确削到多少”的数字。',
    experiment: '建立可复现随机种子，模拟低额高频、高额低频与致死伤害；比较单件/多件、不同获取成本下的有效生命与资源回收率。',
    decision: '若保底不毁是设计意图，就明确写出；否则使用真实耐久管线并限制同一伤害事件的重复触发。先定义目标，再调数值。',
    evidence: { label: '查看免伤与耐久代价', url: githubUrl('src/main/java/enchantment_fusion/mechanics/SignaturePairs.java', 364) }, finding: 'EF-005'
  },
  {
    id: 'Q-05', title: '数据包是覆盖默认值，还是拥有最终权威', domain: '数据与配置', priority: 'P1 · 可扩展性',
    hypothesis: '当前“默认表 + 合并”的做法方便开箱即用，但不等于完整的可配置规则系统。',
    known: '解析失败保留旧快照是正确保护；空排斥组会回退默认值，缺失 profile 也继续由内置表提供。registry 是全局 volatile 快照。',
    unknown: '是否希望支持删除规则、不同服务器/世界的独立规则，以及跨版本迁移，需要产品层决定。',
    experiment: '测试缺字段、空数组、非法枚举、删除 profile、多个存档切换与 /reload。记录实际生效规则及管理端诊断信息。',
    decision: '明确 merge 与 replace；使用版本化 schema 和可验证的加载报告。不要在没有需求时引入复杂的动态脚本系统。',
    evidence: { label: '查看数据快照解析', url: githubUrl('src/main/java/enchantment_fusion/data/FusionMatrixRegistry.java', 74) }, finding: 'EF-006'
  },
  {
    id: 'Q-06', title: '性能风险需要火焰图，不需要拍脑袋', domain: '耦合与生命周期', priority: 'P2 · 量化后优化',
    hypothesis: '全量同步 JSON 写入与每 tick 投射物扫描值得测量，但不能仅凭代码形状断言 TPS 会下降。',
    known: '每次 persistAndSync 都序列化全服解锁状态；每玩家扫描附近 72 格投射物；部分缓存仅在停服时清理。',
    unknown: '真实玩家数、实体数、发现频率、磁盘延迟和 JVM 分配率未采样，尚无性能退化幅度证据。',
    experiment: '在固定种子与实体预算下，分别模拟 1、20、50 位玩家；采集 tick 分位数、 allocation、IO 次数与缓存大小，再逐项优化。',
    decision: '优先合并重复写入与明确退服清理；只有 profiling 证明扫描是瓶颈后，再引入索引或事件驱动。',
    evidence: { label: '查看图鉴保存路径', url: githubUrl('src/main/java/enchantment_fusion/mechanics/CompendiumDiscoveryTracker.java', 318) }, finding: 'EF-012'
  },
  {
    id: 'Q-07', title: '语言键齐了，语义与界面也齐了吗', domain: '文字与体验', priority: 'P1 · 发布质量',
    hypothesis: '键与占位符一致是基础契约，不足以证明翻译准确、术语统一或所有标签可读。',
    known: '本次静态检查：11 个语言文件各 661 个键，相对 en_us 无缺失或多余键，未发现占位符类型/数量差异。中文中仍存在旧概率承诺与名称混用。',
    unknown: '未做所有语言的自然语言审校，也未运行游戏获取不同 GUI Scale 下的真实文字截图。',
    experiment: '从同一规则快照生成数值文案；对最长翻译、稀有字形、换行与省略号做截图回归。让术语表同时约束 UI、JEI/REI、秘典与文档。',
    decision: '先修事实，再压缩句子，最后调排版。不要用更小字号掩盖过时的规则说明。',
    evidence: { label: '查看中文语言文件', url: githubUrl(lang) }, finding: 'EF-019'
  },
];
