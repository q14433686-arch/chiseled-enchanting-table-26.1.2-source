const sourceModules = import.meta.glob<string>('../../audit-upstream/src/**/*.{java,json}', { eager: true, query: '?raw', import: 'default' });
const rootModules = import.meta.glob<string>('../../audit-upstream/*.{md,gradle,properties}', { eager: true, query: '?raw', import: 'default' });
const docModules = import.meta.glob<string>('../../audit-upstream/docs/GDD.md', { eager: true, query: '?raw', import: 'default' });
export const sources: Record<string, string> = Object.fromEntries(
  Object.entries({ ...sourceModules, ...rootModules, ...docModules }).map(([path, content]) => [path.replace('../../audit-upstream/', ''), content])
);
export const sourcePaths = Object.keys(sources).sort();
