export const REPO = 'q14433686-arch/chiseled-enchanting-table-26.1.2-source';
export const BRANCH = 'arena/11fcd984-chiseled-enchanting-table-26-1';
export const COMMIT = '799622aec3eb93a8a9470970e2898faa4a0b743c';
export const SHORT_COMMIT = '799622a';
export const githubUrl = (path: string, line?: number) => `https://github.com/${REPO}/blob/${COMMIT}/${path}${line ? `#L${line}` : ''}`;
export type Category = 'source' | 'data' | 'network' | 'gui' | 'mixin' | 'dead' | 'coupling';
export type FindingStatus = 'confirmed' | 'risk' | 'design';
export type Severity = 'P1' | 'P2' | 'P3';
export interface Evidence { file: string; line: number; end: number; snippet: string; note?: string }
export interface Finding {
  id: string; title: string; category: Category; severity: Severity; status: FindingStatus;
  summary: string; impact: string; suggestion: string; steps: string[]; evidence: Evidence; tags: string[];
}
export const categories: { id: Category; name: string; english: string; description: string; icon: string }[] = [
  { id: 'source', name: '源码 API', english: 'Source & API', description: '版本契约、调用时机与状态写入', icon: 'code' },
  { id: 'data', name: '数据编解码', english: 'Data & codecs', description: '持久化、资源加载与数据边界', icon: 'database' },
  { id: 'network', name: '网络同步', english: 'Network sync', description: '服务端权威、载荷与武器快照', icon: 'network' },
  { id: 'gui', name: 'GUI 输入', english: 'GUI & input', description: '操作反馈、费用展示与可读性', icon: 'mouse' },
  { id: 'mixin', name: 'Mixin 注入', english: 'Mixin injection', description: '注入范围、事件重入与模组共存', icon: 'puzzle' },
  { id: 'dead', name: '死代码', english: 'Dead code', description: '不可达分支与遗留语义', icon: 'archive' },
  { id: 'coupling', name: '耦合风险', english: 'Coupling & design', description: '模块边界、机制代价与文档契约', icon: 'layers' },
];
export const statusLabels: Record<FindingStatus, string> = { confirmed: '已确认', risk: '待验证', design: '设计建议' };
export const severityLabels: Record<Severity, string> = { P1: '优先修复', P2: '建议改进', P3: '低优先级' };

const op = 'src/main/java/enchantment_fusion/mechanics/FusionStationOperations.java';
const economy = 'src/main/java/enchantment_fusion/mechanics/FusionEconomyRules.java';
const cross = 'src/main/java/enchantment_fusion/mechanics/CrossDomainTransmutations.java';
const zh = 'src/client/resources/assets/enchantment_fusion/lang/zh_cn.json';
export const findings: Finding[] = [
  {
    id: 'EF-001', title: '多附魔书融合后，副词条可能残留', category: 'data', severity: 'P1', status: 'confirmed',
    summary: '两个候选来自同一本书时，连续消耗会改变候选赖以识别的附魔集合。',
    impact: '一本书同时提供 A、B 时，第一次消耗移除 A；第二次按 B 查找时只剩一个附魔，直接返回。输出获得 A+B，而输入仍保留 B，形成可重复利用的词条。',
    suggestion: '先按来源 ItemStack 分组，再一次性移除所有选中的附魔；执行前验证候选仍属于同一份输入快照。增加“同书双词条融合”物品守恒测试。',
    steps: ['准备同时含锋利与击退的一本附魔书，放入 A 槽。', '分别选择书内两个候选，固定随机结果或令失败率为零后执行。', '检查输出融合书及输入书：输入不应保留已被融合的 B。'],
    evidence: { file: op, line: 845, end: 857, snippet: `private static void consumeCandidateFromSlot(Container inv, EnchantCandidate cand) {
    ItemStack book = inv.getItem(cand.sourceSlot());
    if (book.isEmpty() || !book.is(Items.ENCHANTED_BOOK)) return;
    ItemEnchantments stored = book.getOrDefault(DataComponents.STORED_ENCHANTMENTS, ItemEnchantments.EMPTY);
    if (stored.size() <= 1) {
        book.shrink(1);
    } else {
        ItemEnchantments.Mutable mut = new ItemEnchantments.Mutable(stored);
        mut.removeIf(h -> h.unwrapKey().map(k -> k.identifier().toString().equals(cand.id())).orElse(false));
        book.set(DataComponents.STORED_ENCHANTMENTS, mut.toImmutable());
    }
}` }, tags: ['物品复制', '事务', '硬编码']
  },
  {
    id: 'EF-002', title: '消耗品返还发生在“使用成功”之前', category: 'source', severity: 'P1', status: 'confirmed',
    summary: 'UseItemCallback 不是物品成功消耗事件，但即时消耗品在这里直接返还。',
    impact: '经久省用对没有 CONSUMABLE 组件的物品在右键入口抽返还概率，未确认投掷或使用真的成功。持续右键空气也可能增加物品；多方块交互还会重复进入事件。',
    suggestion: '把返还移到实际 count 减少后的服务端事件，以一次使用事务为单位去重。对失败、取消、双手与多方块调用增加负向测试。',
    steps: ['给雪球铭刻耐久并转为经久省用，准备一组物品。', '面对空气连续右键，记录数量变化。', '对照实际投掷次数与返还次数；失败使用不应产生返还。'],
    evidence: { file: cross, line: 1461, end: 1465, snippet: `// Multi-tick eat/drink items roll in onConsumableFinished() instead!
if (!stack.has(DataComponents.CONSUMABLE)) {
    tryRefundRationItem(level, player, stack);
}` }, tags: ['物品复制', 'API 语义', '消耗品']
  },
  {
    id: 'EF-003', title: '稳定晶的“100% 稳定”承诺不成立', category: 'gui', severity: 'P1', status: 'confirmed',
    summary: '说明承诺必成，实际互斥融合即使放入 3 个稳定晶仍有 9% 失败率。',
    impact: '0.45 − 0.12 × 3 = 0.09；下限 0.08 不会把 9% 再压到零。物品 lore 与 JEI 说明仍沿用旧版必成机制，会直接影响玩家的资源投入决策。',
    suggestion: '先决定机制：恢复特定触媒必成，或更新所有说明。若保留分级风险，界面动态显示实际失败率、有效触媒数量及失败后果。',
    steps: ['选择双方满级的互斥附魔。', '催化槽放入 3 个谐振稳定晶，查看实际 quote。', '对照物品 lore、JEI 说明与预览中的成功率。'],
    evidence: { file: economy, line: 100, end: 105, snippet: `if (repulsive) {
    int xp = zeroXpCatalyst ? 0 : (7 + Math.min(4, sumLv / 3));
    int mats = (pLv >= pMax && sLv >= sMax) ? 3 : 2;
    int used = Math.min(3, safeStab);
    double fail = clampProb(0.45 - 0.12 * used, 0.08, 0.85);
    return new EconomyQuote(xp, ReagentKind.EMERALD, mats, fail, true, used);
}` }, tags: ['数值契约', '稳定晶', '硬编码']
  },
  {
    id: 'EF-004', title: '普通失败并不总是保住“主书”', category: 'source', severity: 'P1', status: 'confirmed',
    summary: '失败分支优先消耗 B；当 B 来自装备时，回退消耗的却是 A 书。',
    impact: '注释与玩家提示强调主体安全，但 A 来自书、B 来自装备时，A 会被当作 sacrificial 消耗。装备安全不等于主书安全，当前文案也固定写“损耗副卷”。',
    suggestion: '明确定义牺牲输入，预览与结算共用同一选择结果；不要仅按候选顺序猜测。若只应消耗副书，则无副书时应拒绝该失败结算或选择明确的新规则。',
    steps: ['装备已有附魔 B，A 槽放入附魔书。', '选择 A 书与装备 B 进行融合，触发普通失败。', '确认损失的书与操作前提示是否一致。'],
    evidence: { file: op, line: 525, end: 531, snippet: `EnchantCandidate cA = preview.selection().primary();
EnchantCandidate cB = preview.selection().secondary();
EnchantCandidate sacrificial = (cB != null && cB.sourceSlot() != SLOT_TARGET) ? cB : cA;
if (sacrificial != null && sacrificial.sourceSlot() != SLOT_TARGET) {
    consumeCandidateFromSlot(inv, sacrificial);
}` }, tags: ['资源损耗', '事务', '失败分支']
  },
  {
    id: 'EF-005', title: '“双倍耐久代价”停在最后一格耐久', category: 'coupling', severity: 'P2', status: 'design',
    summary: '免伤概率随附魔等级提高，而耐久惩罚被钳制为永不损坏。',
    impact: '招财金身 III 单件免伤率为 25%；四件独立判定合计约 68.4%。代价直接按原始伤害计算，绕过原版耐久概率，并在 maxDamage − 1 截断，长期收益可能远高于代价。',
    suggestion: '先确认是否有意保底不毁装备。若是有保底，应明示；否则按实际耐久结算设计代价，并增加单次受击的触发上限或冷却。用承伤分布而非单次体感评估。',
    steps: ['固定 Fortune III，分别测试 1、2、4 件装备。', '统计足够多次受击的免伤频率与耐久损失。', '把装备耐久置于上限附近，验证是否仍会损坏。'],
    evidence: { file: 'src/main/java/enchantment_fusion/mechanics/SignaturePairs.java', line: 384, end: 394, snippet: `if ("lucky_golden_body".equals(sigId)) {
    float procChance = 0.10F + 0.05F * pair.primaryLevel();
    if (level.getRandom().nextFloat() < procChance) {
        if (gear.isDamageableItem()) {
            int extraDurabilityLoss = Math.max(2, Math.round(amount * 2.0F));
            int nextDmg = Math.min(gear.getMaxDamage() - 1, gear.getDamageValue() + extraDurabilityLoss);
            gear.setDamageValue(nextDmg);
        }
        return false;
    }
}` }, tags: ['概率叠加', '耐久', '平衡']
  },
  {
    id: 'EF-006', title: '空排斥表无法真正覆盖内置规则', category: 'data', severity: 'P2', status: 'confirmed',
    summary: '数据加载采用默认值合并，且空 exclusive_groups 会自动回退到默认组。',
    impact: '数据包作者无法通过空表禁用全部排斥，也无法删除某个内置 profile。文件存在与配置生效之间缺少清晰、可观察的契约。',
    suggestion: '区分字段缺失、显式空数组与替换操作；为 merge/replace 提供 schema 和加载报告。保留解析失败时原子回退这一正确设计。',
    steps: ['加载 exclusive_groups: [] 的数据包并执行 /reload。', '查询原内置互斥组合，确认仍然互斥。', '尝试删除一个 profile，检查是否仍由默认表补回。'],
    evidence: { file: 'src/main/java/enchantment_fusion/data/FusionMatrixRegistry.java', line: 94, end: 116, snippet: `List<Set<String>> groups = new ArrayList<>();
// profiles are merged into defaults above
if (repulsiveObj != null) {
    if (repulsiveObj.has("exclusive_groups") && repulsiveObj.get("exclusive_groups").isJsonArray()) {
        // parse non-empty groups
    }
}
if (groups.isEmpty()) {
    groups = defaults.exclusiveGroups();
}` }, tags: ['硬编码', '数据包', '覆盖语义']
  },
  {
    id: 'EF-007', title: '数据模型的容错策略并不统一', category: 'data', severity: 'P2', status: 'risk',
    summary: '构造器静默截断列表，Codec 却拒绝超长列表；附魔 ID 与等级缺少统一语义校验。',
    impact: 'FusedPair 把等级钳到 1…255，而非附魔自身上限；列表构造器截到 2 项，持久化 listOf(0, 2) 会报错。损坏或跨版本数据可能走不同失败路径。',
    suggestion: '在加载边界使用严格 schema、显式迁移与诊断；内部构造器尽量维护不变量。缺失附魔应降级为可诊断状态，而不是静默获得其他语义。',
    steps: ['构造 0、255、256 与负数等级的模型及 NBT。', '分别经过构造器、Codec 与 StreamCodec 往返。', '卸载提供附魔 ID 的模组，再加载保存的物品。'],
    evidence: { file: 'src/main/java/enchantment_fusion/model/FusedPair.java', line: 20, end: 28, snippet: `public FusedPair {
    Objects.requireNonNull(primaryId, "primaryId");
    Objects.requireNonNull(secondaryId, "secondaryId");
    primaryId = primaryId.trim();
    secondaryId = secondaryId.trim();
    primaryLevel = Math.max(1, Math.min(255, primaryLevel));
    secondaryLevel = Math.max(1, Math.min(255, secondaryLevel));
    aberrationId = aberrationId == null ? "" : aberrationId.trim();
}` }, tags: ['Codec', '迁移', '数据边界']
  },
  {
    id: 'EF-008', title: '网络动作缺少显式协议与拒绝反馈', category: 'network', severity: 'P2', status: 'risk',
    summary: '动作由 enum ordinal 编码；客户端播放点击声不代表服务端接受操作。',
    impact: '当前接收端已检查 containerId、stillValid 与动作范围，这是优点。但重排枚举会改变协议；通道不可用或动作被拒绝时，界面可能只有点击声而没有结果。',
    suggestion: '使用稳定的显式动作 ID 和协议版本；增加请求关联 ID、服务端确认/拒绝原因以及超时恢复。不要信任客户端计算的费用或随机结果。',
    steps: ['交换枚举成员顺序，模拟旧客户端与新服务端。', '在经验不足或候选变化后发送执行动作。', '禁用通道发送，观察界面是否一直处于无反馈状态。'],
    evidence: { file: 'src/main/java/enchantment_fusion/menu/FusionNetworking.java', line: 43, end: 56, snippet: `public record StationActionPayload(
    int containerId, int actionOrdinal, int paramA, int paramB
) implements CustomPacketPayload {
    public static final StreamCodec<ByteBuf, StationActionPayload> STREAM_CODEC = StreamCodec.composite(
        ByteBufCodecs.VAR_INT, StationActionPayload::containerId,
        ByteBufCodecs.VAR_INT, StationActionPayload::actionOrdinal,
        ByteBufCodecs.VAR_INT, StationActionPayload::paramA,
        ByteBufCodecs.VAR_INT, StationActionPayload::paramB,
        StationActionPayload::new
    );
}` }, tags: ['协议', '服务端权威', '反馈']
  },
  {
    id: 'EF-009', title: '投射物可能继承“现在的手持物”', category: 'network', severity: 'P2', status: 'risk',
    summary: '发射物没有武器组件时，命中与飞行路径会回退到玩家当前主手。',
    impact: '若发射后切换武器，附魔可能来自另一件装备。是否实际触发取决于具体 Projectile 的 getWeaponItem 实现，需按箭、弩箭、三叉戟和鱼钩分别验证。',
    suggestion: '在真正发射时持久化武器快照或必要组件，绑定到 projectile；命中使用同一快照。没有快照时宁可不触发，也不应猜测当前主手。',
    steps: ['使用带融合词条的弓发射箭。', '箭命中前切换到另一把武器。', '对照命中效果与发射时装备，并分别测试副手及快速切换。'],
    evidence: { file: 'src/main/java/enchantment_fusion/mixin/ProjectileImpactFusionMixin.java', line: 93, end: 104, snippet: `private static ItemStack resolveFiringWeapon(Projectile self, ServerPlayer shooter) {
    ItemStack firedFrom = self.getWeaponItem();
    if (firedFrom != null && !firedFrom.isEmpty()) return firedFrom;
    if (self.getType() == EntityType.FISHING_BOBBER) {
        ItemStack main = shooter.getMainHandItem();
        if (main.getItem() instanceof FishingRodItem) return main;
        ItemStack off = shooter.getOffhandItem();
        if (off.getItem() instanceof FishingRodItem) return off;
    }
    return shooter.getMainHandItem();
}` }, tags: ['快照', '武器切换', '同步']
  },
  {
    id: 'EF-010', title: '宽泛 projectile 注入需要事件级去重', category: 'mixin', severity: 'P2', status: 'risk',
    summary: 'Projectile.onHit 统一处理多种实体，并临时清零 invulnerableTime。',
    impact: '集中注入减少了对子类覆盖点的遗漏，但扩大了与其他模组的交互面。钓鱼另有 UseItemCallback 入口；需要证明同一次收钩不会重复结算，且其他模组的取消逻辑仍被尊重。',
    suggestion: '保留必要的宽注入，但使用事件 ID 去重，明确定义与原版伤害管线及其他 Mixin 的顺序。测试取消、免疫、反射伤害和多投射物命中。',
    steps: ['记录一次收钩的 UseItem 与 onHit 调用次数。', '加入取消命中或修改受伤计时的测试 Mixin。', '检查单次事件的效果、伤害、冷却与粒子是否重复。'],
    evidence: { file: 'src/main/java/enchantment_fusion/mixin/ProjectileImpactFusionMixin.java', line: 77, end: 88, snippet: `if (target != null) {
    int prevInv = target.invulnerableTime;
    target.invulnerableTime = 0;
    try {
        MatrixEffectExecutor.dispatch(serverLevel, shooter, weapon, trigger, target, hitResult.getLocation());
        CrossDomainTransmutations.onProjectileImpact(serverLevel, self, shooter, weapon, target, hitResult.getLocation());
    } finally {
        target.invulnerableTime = prevInv;
    }
}` }, tags: ['事件重入', 'Mixin', '模组兼容']
  },
  {
    id: 'EF-011', title: '“退还半数”与逐项向下取整需统一', category: 'coupling', severity: 'P2', status: 'design',
    summary: '半费通过 xpLevels / 2 与 reagentCount / 2 分别计算。',
    impact: '3 个材料只扣 1 个，即收取 33.3%，并非严格半价。向下取整本身可以成为合理规则，但必须在数值表、提示和测试里说清楚。',
    suggestion: '明确“先折扣后取整”或“先收全费再退还”的单位；使用一个结算函数生成预览和实扣，展示实际扣除数量而非笼统的 50%。',
    steps: ['枚举 XP 为 2…11、材料为 1…5 的所有报价。', '比较预览、普通失败实扣与文案。', '确认创造模式、零费触媒与背包/催化槽扣费一致。'],
    evidence: { file: economy, line: 67, end: 73, snippet: `public int halfChargedXp() {
    return xpLevels / 2;
}
public int halfChargedReagents() {
    return reagentCount / 2;
}` }, tags: ['取整', '经济', '数值契约']
  },
  {
    id: 'EF-012', title: '每次图鉴解锁都同步重写全服文件', category: 'coupling', severity: 'P2', status: 'risk',
    summary: 'persistAndSync 把全体玩家状态序列化为 JSON，并直接 Files.writeString。',
    impact: '状态量与玩家数增长后，每次发现都产生全量 O(N) 写入；批量扫描可能在同一 tick 多次触发。风险需 profiling 量化，不能直接断言已经卡服。',
    suggestion: '引入脏玩家集合、合并写入与周期保存，退出时强制落盘；使用临时文件原子替换。网络只同步当前玩家增量或必要快照。',
    steps: ['准备不同规模的玩家解锁数据。', '在同一 tick 触发批量发现，记录 IO 次数和耗时。', '测试写入中断后重启，验证数据完整性。'],
    evidence: { file: 'src/main/java/enchantment_fusion/mechanics/CompendiumDiscoveryTracker.java', line: 318, end: 324, snippet: `private static void persistAndSync(ServerPlayer player) {
    MinecraftServer srv = player.level().getServer();
    if (srv != null) {
        saveWorldFile(srv);
    }
    FusionNetworking.sendCompendiumSync(player, encodeStates(player.getUUID()));
}` }, tags: ['性能', '持久化', '生命周期']
  },
  {
    id: 'EF-013', title: '玩家扫描缓存仅在停服时释放', category: 'coupling', severity: 'P3', status: 'risk',
    summary: 'SCANNED_ENCHANTS_CACHE 按 UUID 累积已见附魔，未看到退服清理入口。',
    impact: '长期运行且独立玩家很多时，缓存会保留离线玩家记录。它不是无限增长的单次事件泄漏，但在高流动服务器中值得设置边界。',
    suggestion: '在 DISCONNECT 清理该玩家的扫描缓存；持久化解锁状态与临时扫描缓存分离。测试重复登入后知识状态不丢失。',
    steps: ['模拟大量不同 UUID 的玩家登入与退服。', '记录缓存条目数与堆内存。', '重新登入，确认图鉴持久状态仍可恢复。'],
    evidence: { file: 'src/main/java/enchantment_fusion/mechanics/CompendiumDiscoveryTracker.java', line: 87, end: 98, snippet: `ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
    saveWorldFile(server);
    SERVER_STATES.clear();
    SCANNED_ENCHANTS_CACHE.clear();
});
ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
    ServerPlayer player = handler.player;
    scanPlayerInventory(player);
    FusionNetworking.sendCompendiumSync(player, encodeStates(player.getUUID()));
});` }, tags: ['缓存', '退服', '性能']
  },
  {
    id: 'EF-014', title: '可选编译依赖与入口元数据未联动', category: 'source', severity: 'P2', status: 'risk',
    summary: 'JEI/REI 可被关闭且为 compileOnly，但 fabric.mod.json 始终声明两个入口。',
    impact: '无查看器构建可能保留不存在的入口类。Fabric Loader 对缺失入口的具体处理需按 pinned 版本实测，不应仅凭配置断言必崩。',
    suggestion: '按构建开关生成 entrypoints，或把可选适配器拆分并通过动态检测注册。CI 不仅编译，还要无 JEI、无 REI 启动。',
    steps: ['运行 -Penable_jei=false -Penable_rei=false 构建。', '检查 jar 内入口类与 fabric.mod.json 是否匹配。', '在完全不安装查看器的客户端及专用服务端启动。'],
    evidence: { file: 'src/main/resources/fabric.mod.json', line: 23, end: 36, snippet: `"entrypoints": {
  "main": ["enchantment_fusion.EnchantmentFusion"],
  "client": ["enchantment_fusion.EnchantmentFusionClient"],
  "jei_mod_plugin": ["enchantment_fusion.compat.jei.EnchantmentFusionJeiPlugin"],
  "rei_client": ["enchantment_fusion.compat.rei.EnchantmentFusionReiPlugin"]
}` }, tags: ['Fabric', '可选依赖', '元数据']
  },
  {
    id: 'EF-015', title: '可复现构建仍依赖快照与通配版本', category: 'source', severity: 'P3', status: 'risk',
    summary: 'Loom 使用 1.16-SNAPSHOT，运行时 fabric-api 依赖声明为 *。',
    impact: 'Gradle 中 API 构建版本已固定，Java 25 也与 26.1.2 对齐；但插件快照和宽松运行时边界仍会让不同时刻的构建与启动结果不同。',
    suggestion: '发布时固定 Loom、保存依赖锁或校验信息，并声明经过测试的 Fabric API 范围。把“编译版本”和“兼容范围”分别写清楚。',
    steps: ['在干净缓存环境重复构建同一提交。', '记录插件、Loader 和 API 的实际解析版本。', '测试声明支持的最低与最高 API 版本。'],
    evidence: { file: 'build.gradle', line: 1, end: 5, snippet: `plugins {
    id 'net.fabricmc.fabric-loom' version '1.16-SNAPSHOT'
    id 'java-library'
    id 'maven-publish'
}` }, tags: ['构建', '版本锁定', '26.1.2']
  },
  {
    id: 'EF-016', title: '两页签实现保留不可达的第三页签', category: 'dead', severity: 'P3', status: 'confirmed',
    summary: 'activeTab 与 SELECT_TAB 都钳制到 0…1，TAB_COMPENDIUM = 2 的 inspect 分支无法由当前菜单到达。',
    impact: '旧架构没有完全退场，增加阅读与后续修改成本。另有未使用的拒绝枚举和指向不存在 FusionPlanner 的注释；不应把整个图鉴类误判为死代码。',
    suggestion: '删除不可达分支和过期常量，或明确标为未来扩展且从当前协议移除；更新类注释与旧语言键。独立秘典仍在使用，应保留。',
    steps: ['追踪 activeTab 与 SELECT_TAB 的取值范围。', '搜索 TAB_COMPENDIUM 的全部引用。', '确认删除旧分支不影响独立 FusionGrimoireScreen。'],
    evidence: { file: 'src/main/java/enchantment_fusion/menu/EnchantmentFusionMenu.java', line: 132, end: 134, snippet: `public int activeTab() {
    return Math.max(0, Math.min(1, uiState.get(0)));
}` }, tags: ['不可达分支', '三页签', '清理']
  },
  {
    id: 'EF-017', title: '大型机制类同时拥有过多职责', category: 'coupling', severity: 'P2', status: 'design',
    summary: 'CrossDomainTransmutations 约 2380 行，混合规则表、角色分派、状态缓存与世界副作用。',
    impact: '新增一个变体往往需要同时修改映射、触发、文案与经济规则；测试难以独立覆盖。文件大本身不是 BUG，但修改半径与回归风险值得关注。',
    suggestion: '按“纯规则注册表 / 角色解析 / 事件上下文 / 效果执行器”渐进拆分。先为现有行为补特征测试，再迁移，不建议无测试重写。',
    steps: ['为一个变体列出所有必须修改的文件与分支。', '建立纯规则输入输出测试，不启动 Minecraft。', '逐批迁移效果处理器并保持旧接口适配。'],
    evidence: { file: cross, line: 789, end: 804, snippet: `public static int getTransmutedLevel(ItemStack stack, String variantId) {
    if (stack == null || stack.isEmpty() || variantId == null) return 0;
    ItemEnchantments enchs = stack.getOrDefault(DataComponents.ENCHANTMENTS, ItemEnchantments.EMPTY);
    for (Holder<Enchantment> holder : enchs.keySet()) {
        String eid = holder.unwrapKey().map(k -> k.identifier().toString()).orElse(null);
        Optional<TransmuteVariant> v = resolve(eid, stack);
        if (v.isPresent() && variantId.equals(v.get().id())) return enchs.getLevel(holder);
    }
    return 0;
}` }, tags: ['职责分离', '热路径', '重构']
  },
  {
    id: 'EF-018', title: '入口说明与 0.4.0 实现已经脱节', category: 'coupling', severity: 'P2', status: 'confirmed',
    summary: 'README/GDD 仍写 42 种附魔、108 个签名、111 个变体与三页签。',
    impact: '静态核对得到 43 个矩阵 profile、114 个唯一签名、115 个变体；CURRENT_BASELINE 与当前客户端则对应两页签。36 个别名不能计成额外签名。',
    suggestion: '从规则注册表生成数量，发布时检查 README、GDD、语言键和 UI 契约。历史版本说明保留版本号，不用旧“定稿”覆盖当前行为。',
    steps: ['比较 README、GDD 与 CURRENT_BASELINE 的版本和数量。', '按唯一 ID 统计 reg，单列 regAlias。', '运行界面截图回归，核对工作台与独立秘典入口。'],
    evidence: { file: 'CURRENT_BASELINE.md', line: 7, end: 7, snippet: `Milestone: Phase 4 (0.4.0) — 43 matrix profiles, 114 Signature Resonances,
115 Cross-Domain Transmutations, standalone Fusion Grimoire,
streamlined 2-tab workstation, 661-key 11-locale parity.` }, tags: ['文档一致性', '统计口径', '版本']
  },
  {
    id: 'EF-019', title: '缩字不是长文本可读性的完整解法', category: 'gui', severity: 'P2', status: 'risk',
    summary: 'GUI 使用 0.50…0.62 倍文字，并在极窄区域使用最小 8 个原始单位的截断下限。',
    impact: '长中文名及德语、俄语等翻译可能在省略号加入后继续越界；即使不越界，小比例缩放也降低像素字形辨识度。是否实际裁切需逐语言截图验证。',
    suggestion: '关键操作名保持可读字号；长说明换行或移到 tooltip。省略号加入后再次测量，而非持续缩小。为最长翻译保留布局预算。',
    steps: ['采集 11 个语言文件中最长的按钮与费用文案。', '在各 GUI Scale 下截图并检查实际像素边界。', '验证截断文本仍能通过 tooltip 或详情页完整获取。'],
    evidence: { file: 'src/client/java/enchantment_fusion/gui/FusionGuiSkin.java', line: 173, end: 186, snippet: `float minScale = 0.52F;
float scale = maxScale;
String shown = text;
if (rawW * scale > maxW) {
    float fit = (float) maxW / (float) rawW;
    if (fit >= minScale) {
        scale = fit;
    } else {
        scale = minScale;
        int maxRaw = Math.max(8, Math.round(maxWForEllipsis(maxW, scale, font)));
        shown = font.plainSubstrByWidth(text, maxRaw) + "…";
    }
}` }, tags: ['可读性', '本地化', '布局']
  },
  {
    id: 'EF-020', title: '未知附魔被哈希映射成确定但任意的机制', category: 'data', severity: 'P2', status: 'risk',
    summary: '第三方附魔缺少 profile 时，用字符串哈希选择触发器与效果类型。',
    impact: '确定性不等于语义正确。新附魔可能得到不匹配的触发节奏；Math.abs(Integer.MIN_VALUE) 仍为负数，也是可修复的边界。当前未证明存在实际哈希碰撞故障。',
    suggestion: '为未知附魔提供明确的默认策略或不支持原因；适配表由数据包配置。若保留哈希，使用 floorMod 并清楚标注为兜底玩法，而非自动兼容承诺。',
    steps: ['添加未配置的第三方附魔并查看解析结果。', '改变 ID 命名，观察触发器与效果是否无意义地改变。', '单测 hashCode 最小值与空 ID 的边界。'],
    evidence: { file: 'src/main/java/enchantment_fusion/data/FusionMatrixRegistry.java', line: 33, end: 40, snippet: `// Deterministic fallback for third-party modded enchantments
int h = Math.abs(enchantmentId == null ? 0 : enchantmentId.hashCode());
TriggerType[] triggers = TriggerType.values();
PayloadType[] payloads = PayloadType.values();
return new MatrixProfile(
    triggers[h % triggers.length],
    payloads[(h / triggers.length) % payloads.length]
);` }, tags: ['硬编码', '兜底', '第三方附魔']
  },
];

export const sourceNotes: Record<string, string> = {
  [op]: '工作台事务的核心路径。预览与执行共享 inspect 是优点，但输入消耗、失败结算与输出应作为一个整体事务验证。',
  [economy]: '0.4.0 的分级风险经济规则。注意：这里硬编码的 45% 基础风险与旧 GDD 的 35% 不是同一套契约。',
  [cross]: '大型跨界机制调度器。此处只展示证据片段；完整文件约 2380 行，包含 115 个静态变体。',
  [zh]: '语言键存在不代表文案与当前规则一致。完整语言文件包含 661 个键。',
};
