import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
const root = path.resolve('audit-upstream');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');
const commit = execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim();
assert.equal(commit, '799622aec3eb93a8a9470970e2898faa4a0b743c');
const signature = read('src/main/java/enchantment_fusion/mechanics/SignaturePairs.java');
const cross = read('src/main/java/enchantment_fusion/mechanics/CrossDomainTransmutations.java');
const matrix = read('src/main/java/enchantment_fusion/data/FusionMatrixRegistry.java');
const signatures = [...signature.matchAll(/^\s*reg\("([^"]+)"/gm)].map(m => m[1]);
const aliases = [...signature.matchAll(/^\s*regAlias\("([^"]+)"/gm)];
const variants = [...cross.matchAll(/^\s*\{"/gm)];
const profiles = [...matrix.matchAll(/^\s*put\(m,/gm)];
assert.equal(new Set(signatures).size, 114);
assert.equal(aliases.length, 36);
assert.equal(variants.length, 115);
assert.equal(profiles.length, 43);
const localeDir = path.join(root, 'src/client/resources/assets/enchantment_fusion/lang');
const locales = fs.readdirSync(localeDir).filter(f => f.endsWith('.json'));
const baseline = JSON.parse(read('src/client/resources/assets/enchantment_fusion/lang/en_us.json'));
const tokens = value => (value.match(/%\d+\$[a-z]|%[sdf]/g) || []).sort();
const localeResults = [];
assert.equal(locales.length, 11);
for (const locale of locales) {
  const values = JSON.parse(fs.readFileSync(path.join(localeDir, locale), 'utf8'));
  assert.equal(Object.keys(values).length, 661, locale);
  assert.deepEqual(Object.keys(values).sort(), Object.keys(baseline).sort(), `${locale}: key parity`);
  for (const [key, value] of Object.entries(baseline)) assert.deepEqual(tokens(value), tokens(values[key]), `${locale}: ${key}`);
  localeResults.push({ locale, keys: Object.keys(values).length, keyParity: true, placeholderParity: true });
}
const zhPath = 'src/client/resources/assets/enchantment_fusion/lang/zh_cn.json';
const zhLines = read(zhPath).split('\n');
const editorial = fs.readFileSync('src/data/editorial.ts', 'utf8');
for (const match of editorial.matchAll(/file: lang, line: (\d+),\s*key: '([^']+)'/g)) {
  assert.ok(zhLines[Number(match[1]) - 1].includes(`"${match[2]}"`), `Editorial line anchor: ${match[2]}`);
}
const audit = fs.readFileSync('src/data/audit.ts', 'utf8');
assert.equal([...audit.matchAll(/status: 'confirmed'/g)].length, 7);
assert.equal([...audit.matchAll(/status: 'risk'/g)].length, 10);
assert.equal([...audit.matchAll(/status: 'design'/g)].length, 3);
assert.equal([...audit.matchAll(/severity: 'P1'/g)].length, 4);
console.log(JSON.stringify({ commit, signatures: new Set(signatures).size, aliases: aliases.length, crossDomainVariants: variants.length, matrixProfiles: profiles.length, locales: localeResults, editorialLineAnchors: 'passed', findingCounts: { confirmed: 7, risk: 10, design: 3, priority: 4 } }, null, 2));
