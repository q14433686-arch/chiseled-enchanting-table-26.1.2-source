import { useEffect, useState } from "react";
import { ShieldAlert, Compass } from "lucide-react";
import Hero from "./components/Hero";
import Upgrade from "./components/Upgrade";
import Refund from "./components/Refund";
import Wash from "./components/Wash";
import GateLadder from "./components/GateLadder";
import Residue from "./components/Residue";
import Ladder from "./components/Ladder";
import Decision from "./components/Decision";
import Closing from "./components/Closing";
import AuditHero from "./components/AuditHero";
import ArbitrageLab from "./components/ArbitrageLab";
import MechanismAudit from "./components/MechanismAudit";
import HardcodeAudit from "./components/HardcodeAudit";

type WorkspaceMode = "audit" | "proposal";

const AUDIT_NAV = [
  { id: "arbitrage", label: "审壹 · 套利实证", tone: "#f08cc8" },
  { id: "mechanism", label: "审贰 · 机制边界", tone: "#e8c37c" },
  { id: "hardcode", label: "审叁 · 硬编码表", tone: "#7ee8dc" },
  { id: "drift", label: "审肆 · 漂移与整改", tone: "#a18cff" },
];

const PROPOSAL_NAV = [
  { id: "upgrade", label: "壹 · 升阶当省", tone: "#e8c37c" },
  { id: "refund", label: "贰 · 降阶当返", tone: "#8df0a4" },
  { id: "wash", label: "叁 · 洗条当费", tone: "#f08cc8" },
  { id: "gate", label: "肆 · 升阶准入 38", tone: "#f08cc8" },
  { id: "residue", label: "伍 · 残卷三梯度", tone: "#7ee8dc" },
  { id: "ladder", label: "陆 · 书架总阶梯", tone: "#8df0a4" },
  { id: "decision", label: "决 · 双页同面", tone: "#a18cff" },
];

const TopModeBar = ({
  mode,
  setMode,
}: {
  mode: WorkspaceMode;
  setMode: (m: WorkspaceMode) => void;
}) => (
  <div className="fixed top-0 inset-x-0 z-50 backdrop-blur-md bg-obsidian/85 border-b border-arcane/15">
    <div className="max-w-6xl mx-auto px-4 md:px-10 h-14 flex items-center justify-between gap-3">
      <div className="flex items-center gap-2.5">
        <div className="w-7 h-7 pixelframe bg-arcane-deep/30 border border-arcane/40 flex items-center justify-center">
          <span className="font-display font-black text-arcane text-xs">纂</span>
        </div>
        <span className="font-display font-bold text-xs md:text-sm text-parch hidden sm:inline">
          纂刻附魔台 · 审计与提案台
        </span>
      </div>

      <div className="flex items-center gap-1.5 bg-vellum/80 p-1 rounded-sm border border-arcane/20">
        <button
          onClick={() => {
            setMode("audit");
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-sm font-code text-[11px] transition-all cursor-pointer"
          style={{
            color: mode === "audit" ? "#0a0913" : "#ede6d4",
            background: mode === "audit" ? "#f08cc8" : "transparent",
          }}
        >
          <ShieldAlert size={13} />
          分支源码审查 (arena/d0fffdab)
        </button>
        <button
          onClick={() => {
            setMode("proposal");
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-sm font-code text-[11px] transition-all cursor-pointer"
          style={{
            color: mode === "proposal" ? "#0a0913" : "#9c93bd",
            background: mode === "proposal" ? "#e8c37c" : "transparent",
          }}
        >
          <Compass size={13} />
          前序设计蓝图对照
        </button>
      </div>
    </div>
  </div>
);

const SideNav = ({ items }: { items: { id: string; label: string; tone: string }[] }) => {
  const [active, setActive] = useState("");
  useEffect(() => {
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) setActive(en.target.id);
        });
      },
      { rootMargin: "-40% 0px -55% 0px" },
    );
    items.forEach((n) => {
      const el = document.getElementById(n.id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, [items]);

  return (
    <nav className="fixed left-6 top-1/2 -translate-y-1/2 z-40 hidden xl:flex flex-col gap-5">
      {items.map((n) => (
        <a key={n.id} href={`#${n.id}`} className="group flex items-center gap-3">
          <span
            className="w-2 h-2 rotate-45 transition-all duration-300"
            style={{
              background: active === n.id ? n.tone : "rgba(111,101,154,0.4)",
              boxShadow: active === n.id ? `0 0 10px ${n.tone}` : "none",
              transform: `rotate(45deg) scale(${active === n.id ? 1.3 : 1})`,
            }}
          />
          <span
            className="font-code text-[10px] tracking-[0.2em] whitespace-nowrap transition-all duration-300 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0"
            style={{ color: active === n.id ? n.tone : "#9c93bd" }}
          >
            {n.label}
          </span>
        </a>
      ))}
    </nav>
  );
};

const Divider = () => (
  <div className="max-w-6xl mx-auto px-6 md:px-10">
    <div className="flex items-center gap-6 py-2">
      <div className="gold-rule flex-1" />
      <span className="font-display text-arcane/40 text-sm select-none">᛭</span>
      <div className="gold-rule flex-1" />
    </div>
  </div>
);

export default function App() {
  const [mode, setMode] = useState<WorkspaceMode>("audit");
  const navItems = mode === "audit" ? AUDIT_NAV : PROPOSAL_NAV;

  return (
    <div className="noise relative min-h-screen bg-obsidian text-parch font-body selection:bg-arcane/30">
      <TopModeBar mode={mode} setMode={setMode} />
      <SideNav items={navItems} />

      {mode === "audit" ? (
        <>
          <AuditHero />
          <main className="relative z-10">
            <Divider />
            <ArbitrageLab />
            <Divider />
            <MechanismAudit />
            <Divider />
            <HardcodeAudit />
          </main>
        </>
      ) : (
        <>
          <div className="pt-14">
            <Hero />
          </div>
          <main className="relative z-10">
            <Divider />
            <Upgrade />
            <Divider />
            <Refund />
            <Divider />
            <Wash />
            <Divider />
            <GateLadder />
            <Divider />
            <Residue />
            <Divider />
            <Ladder />
            <Divider />
            <Decision />
          </main>
        </>
      )}

      <Closing />
    </div>
  );
}
