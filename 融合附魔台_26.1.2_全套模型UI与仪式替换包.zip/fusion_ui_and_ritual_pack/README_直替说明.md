# 《融合附魔台 26.1.2》中空视窗祭坛 UI · 智能关联秘卷抽屉 · 2秒可跳过仪式 · 黑曜星典直替包说明

针对 **`q14433686-arch/chiseled-enchanting-table-26.1.2-source`**（分支 `arena/11fcd984-chiseled-enchanting-table-26-1`）**正在进行大规模代码重写**的实际情况，本内容包（`fusion_ui_and_ritual_pack/` 与压缩包 `融合附魔台_26.1.2_全套模型UI与仪式替换包.zip`）采用**双层彻底解耦架构**交付：无论你是想**只拿纯美术资产接入新架构**，还是想**一键覆盖当前 26.1.2 源码即刻运行**，都能零摩擦直接替换。

---

## 一、 本次重构彻底解决的四大痛点

| 原版痛点 | 本包落地的解决方案 |
| :--- | :--- |
| **1. 合成秒变无过程，且 UI 把背后的 3D 祭坛挡得严严实实** | **双翼中空祭坛视窗（`384 × 218`）+ 2.0 秒可跳过声画同步仪式**：中央预留 **`116 × 118` 无模糊透明石拱视窗**（重写 `extractBackground` 取消全屏暗色毛玻璃），让背后的 3D 融合附魔台在 UI 正中央清晰可见！点击合成后触发 **1.95 秒金/青能量导槽充能 + 4 阶紫晶渐升和弦**，同时视窗内的 **3D 祭坛浮空紫晶加速至 `720°/s`、四角火盆紫焰暴涨 `1.52×`、环绕附魔书螺旋向心聚拢**，高潮瞬间绽放震荡波与顶部金边揭晓横幅；**蓄力中途再次点击或按空格/回车即可瞬间跳过直出成品**，批量合成零拖沓。 |
| **2. 外部黑曜石紫晶祭坛 vs 内部灰铁板 + 突兀黄羊皮纸《融合秘典》严重割裂** | **40 张像素级 GUI 贴图全量重绘（100% 祭坛同源材质）**：工作台面板升级为**雕花暗黑曜石底盘 + 白骨银镶边 + 四角动态跳动微型紫焰火盆 + 金/青/紫晶导魔能量槽**；双页《融合秘典》（`grimoire_spread.png`）彻底告别黄色羊皮纸，重绘为**五枚紫晶书脊扣装订的黑曜星穹魔典**，配高对比星辉金/青/月白墨色（`FusionGuiSkin.COLOR_INK_*`）。 |
| **3. 查《融合秘典》像背字典，与当前放入的物品毫无联动** | **右侧智能关联秘卷侧拉抽屉（`FusionContextDrawer`）**：右翼边缘常驻 `【秘卷 N】` 紫晶书签徽章，实时统计当前槽位附魔书/装备可触发的**签名共鸣 & 异位化形**数量；拉开抽屉即可查看匹配配方，**单击任意配方行即可按正确主副顺序自动选中 `[A] ▷ [B]`**，底部亦可一键展开双页《融合秘典》全卷。 |
| **4. 顶部冗余双 Tab + 上下两套重复的调序/拆解小按钮显得杂乱拥挤** | **智能单面板自动变形（Auto-Morphing Wing）**：彻底移除顶部 `Tab 0 / Tab 1` 横条与重复小工具栏！3 号槽为空或放融合书时自动呈现 **【◆ 秘典凝练】**（仅在闲置管理融合书时显示单组内联 `[⇄ 调序]` / `[✦ 拆解]`）；放入武器/盔甲/镐/矛等宿主时**自动变形为【◆ 器魂铭刻】**（器魂槽卡片 + 单附魔切换芯片），所有控件严格零重叠、字号更舒展。 |

---

## 二、 目录结构与两种直替方式

压缩包 `/home/user/融合附魔台_26.1.2_全套模型UI与仪式替换包.zip`（对应目录 `/home/user/fusion_ui_and_ritual_pack/`）内含两个独立层级：

### 方案 1：`1_纯贴图皮肤直替包_零代码耦合/`（适合你重写后的全新代码直接挂载）
**零 Java 代码依赖！** 仅包含纯客户端资源 `assets/enchantment_fusion/`：
- **`textures/gui/*.png`（共 40 张像素级 GUI 精灵图）**：
  - **27 张原版同名直替贴图**：`panel_frame.png`、`grimoire_spread.png`（黑曜星典）、`slot_{primary,secondary,catalyst,default}.png`、`swap_button*.png`、`button_*.png`、`row_*.png`、`socket_card_*.png`、`vessel_gem_*.png`、`tab_*.png`、`vfx_*.png`。即使你的新代码沿用旧贴图路径，直接覆盖即可立刻换上黑曜石白骨银皮肤！
  - **13 张中空视窗/导能槽/微型火盆扩展贴图**：`viewport_arch_frame.png`（`116×118` 透明拱门框）、`mini_brazier_{idle,lit_a,lit_b}.png`（动态紫焰微型火盆）、`conduit_beam_{gold,cyan,amethyst}.png`、`conduit_track_dark.png`、`ritual_progress_fill.png`、`drawer_panel.png`、`drawer_tab_badge.png`、`climax_banner_{sig,aberrant}.png`。
- **`textures/block/`、`textures/particle/`、`models/`、`items/`、`blockstates/`**：
  - 完整包含 `128×1024` 8 帧流动 3D 融合附魔台材质、LabPBR `_s.png` / `_glowmask.png` 光影自发光贴图、分离式浮空紫晶核心/碎晶/四角 `45°` 交叉紫火模型与金蓝轨迹粒子贴图。

**使用方法**：直接将 `1_纯贴图皮肤直替包_零代码耦合/assets/` 复制覆盖到你新工程的 `src/client/resources/assets/`（或做成独立材质包）即可生效。

---

### 方案 2：`2_完整26.1.2客户端与菜单直替包_开箱即用/`（直接覆盖当前 `26.1.2` 分支即刻运行）
包含全套客户端资源、11 国语言包同步更新，以及高度模块化的 Java 实现（**零服务端网络包改动**，完全复用现有 `StationActionPayload`）：

```bash
# 在你的仓库根目录一键覆盖：
cp -r /path/to/fusion_ui_and_ritual_pack/2_完整26.1.2客户端与菜单直替包_开箱即用/* ./

# 运行仓库自带全套静态与可读性检查：
python3 scripts/ci_static_checks.py
python3 scripts/test_ui_readability.py
python3 scripts/check_architecture_boundaries.py
```

#### 如果你正在大规模重写后端逻辑，如何把“2秒仪式”和“关联抽屉”无缝迁入新架构？
我们在设计代码时特意将核心交互拆成了两个**零后端耦合的纯客户端独立组件**：

1. **`FusionRitualDirector.java`（约 110 行，独立 2.0s 可跳过仪式状态机）**：
   - 不依赖任何附魔计算细节，只接收 `(String token, String revealTitle, boolean highRisk, BlockPos tablePos, Runnable commitAction)`：
   ```java
   // 按钮点击时调用（第 1 次点击开启 1.95s 聚魔与 3D 祭坛联动；蓄力中第 2 次点击立即跳过并提交！）：
   FusionRitualDirector.triggerOrSkip(token, previewTitle, highRisk, tablePos, () -> sendCommitPacket());

   // 每帧渲染时调用（若玩家中途取走槽位物品导致 token 变化，自动安全取消，绝不误发包）：
   FusionRitualDirector.updateFrame(liveToken, ready, () -> sendCommitPacket());
   ```
   - 3D 渲染器 `EnchantmentFusionTableRenderer` 只需一行 `FusionRitualDirector.activeChannelProgressForTable(be.getBlockPos())` 即可实时获取 `0.0 ~ 1.0` 蓄力进度，驱动 3D 水晶加速、火盆喷发与环绕物品向心聚拢。

2. **`FusionContextDrawer.java`（独立智能关联秘卷抽屉）**：
   - 通过回调接口 `Runnable onOpenFullGrimoire` 与 `BiConsumer<EnchantCandidate, Boolean> onPickCandidate` 与主界面通信，不绑定特定 `Menu` 内部实现，你在重写 `Menu` 或配方表时只需替换 `collectRecipes(...)` 中的数据源即可。

---

## 三、 已通过的仓库自动化门禁清单

本直替包已在 `arena/11fcd984-chiseled-enchanting-table-26-1` 源码树上实测通过全部静态与架构契约检查：
- `scripts/ci_static_checks.py`：**PASS**（零 `.fill(` 纯色占位矩形、11 国语言 key 100% 对齐、术语规范与方向性签名完整）
- `scripts/test_ui_readability.py`：**PASS**（40 张 PNG 精灵图完整校验、`384×218` 中空双翼布局与 `360×224` 黑曜星典所有热区严格零重叠、全语言 BMP 字符安全）
- `scripts/test_sync_26_1_2.py`：**PASS**（无任何 `ResourceLocation` 残留，严格遵循 Minecraft `26.1.2` `Identifier` 规范）
- `scripts/check_architecture_boundaries.py` & `scripts/compat_check.py`：**PASS**（Client/Main 边界纯净，REI `guiBounds()` 动态避让支持完整）
