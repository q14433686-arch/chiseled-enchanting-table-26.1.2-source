// ═══════════════════════════════════════════════════════════
// 公式层 · 1:1 移植自 Java 实装（HEAD 89f545b）
// LibraryResonance / BookshelfProgression / XpCostConversion /
// DisenchantmentApplication.essencePotentialFromParams
// ═══════════════════════════════════════════════════════════

import { ENCH, type Ench, type Target, canEnchant, EPIPHANY } from "./data";

/** Java Math.round(double) */
export const jr = (x: number) => Math.floor(x + 0.5);

/* ── library_resonance.json（出厂值）── */
export const CFG = {
  minDiscountShelves: 12,
  maxDiscountShelves: 38,
  maxWood: 15,
  masteryExp: 1.25,
  globalMult: 1.25,
  maxGlobal: 20,
  maxBase: 35,
  maxSpecific: 15,
  specificExp: 1.0,
  maxTotal: 40,
  credit: 0.85,
  epiGlobalW: 0.45,
  epiAffinityW: 0.85,
  blankBookW: 0.5,
  epiShelfScore: 1.0,
  epiGlobalScore: 2.2,
  epiAffinityScore: 3.5,
};

/* ── shelf_gates.json ── */
export const GATES = { cap: 38, gamma: 1.25, t1: 8, t2: 18, t3Tomes: 6, baseBatch: 8, t3Batch: 64 };

export type Tomes = Record<string, number>; // enchantId → stored master level

/* ════════ 共振减免 ════════ */
export const relMastery = (stored: number, max: number) =>
  stored <= 0 ? 0 : Math.min(1, Math.min(stored, Math.max(1, max)) / Math.max(1, max));

export const masteryUnit = (stored: number, max: number) => {
  const r = relMastery(stored, max);
  return r <= 0 ? 0 : Math.pow(r, CFG.masteryExp);
};

export const totalMastery = (tomes: Tomes) =>
  Object.entries(tomes).reduce((s, [id, lvl]) => {
    const e = ENCH[id];
    if (!e || e.curse || lvl <= 0) return s;
    return s + masteryUnit(lvl, e.max);
  }, 0);

export const affinityMastery = (tomes: Tomes, target: Target) =>
  Object.entries(tomes).reduce((s, [id, lvl]) => {
    const e = ENCH[id];
    if (!e || e.curse || lvl <= 0) return s;
    if (target === "book") return s + masteryUnit(lvl, e.max) * CFG.blankBookW;
    return canEnchant(e, target) ? s + masteryUnit(lvl, e.max) : s;
  }, 0);

export const woodDiscount = (W: number) => {
  if (W < CFG.minDiscountShelves) return 0;
  const clamped = Math.min(CFG.maxDiscountShelves, W);
  const span = Math.max(1, CFG.maxDiscountShelves - CFG.minDiscountShelves);
  const p = (clamped - CFG.minDiscountShelves) / span;
  return Math.min(CFG.maxWood, Math.max(1, jr(1 + Math.max(0, CFG.maxWood - 1) * p)));
};

export const globalDiscount = (E: number) => (E <= 0 ? 0 : Math.min(CFG.maxGlobal, Math.floor(E * CFG.globalMult)));

export const specificBonus = (stored: number, max: number) => {
  const r = relMastery(stored, max);
  if (r <= 0) return 0;
  const w = CFG.specificExp === 1 ? r : Math.pow(r, CFG.specificExp);
  return Math.min(CFG.maxSpecific, jr(CFG.maxSpecific * w));
};

export const baseDiscount = (W: number, E: number) => Math.min(CFG.maxBase, woodDiscount(W) + globalDiscount(E));

export const effectiveDiscount = (W: number, E: number, stored: number, max: number) =>
  Math.min(CFG.maxTotal, baseDiscount(W, E) + specificBonus(stored, max));

/* ════════ 书架阶梯 ════════ */
export const requiredShelves = (L: number, M: number, cap = GATES.cap, gamma = GATES.gamma) => {
  const sM = Math.max(1, M);
  const sL = Math.max(1, Math.min(sM, L));
  if (sM <= 1 || sL <= 1) return 0;
  if (sL >= sM) return cap;
  const exp = Math.max(0.5, gamma);
  const prog = (sL - 1) / (sM - 1);
  const raw = Math.floor(cap * Math.pow(prog, exp) + 0.5);
  if (sM > cap + 1) return Math.max(1, Math.min(cap - 1, raw));
  const minA = Math.min(cap - 1, sL - 1);
  const maxA = Math.max(1, cap - (sM - sL));
  return Math.max(Math.min(minA, maxA), Math.min(raw, maxA));
};

export const unlockedByShelves = (M: number, W: number) => {
  let u = 1;
  for (let L = 1; L <= Math.max(1, M); L++) if (W >= requiredShelves(L, M)) u = L;
  return u;
};

/** 轨道一：白板 half_ceil 封顶 */
export const blankCap = (M: number, W: number) => Math.min(Math.ceil(Math.max(1, M) / 2), unlockedByShelves(M, W));

/** 轨道二：已持有词条可升阶上限（与母本取大） */
export const upgradeCap = (M: number, W: number, stored: number) =>
  Math.min(Math.max(1, M), Math.max(Math.max(0, stored), unlockedByShelves(M, W)));

export const minQualifying = (M: number) => (M <= 1 ? 1 : M === 2 ? 2 : M - 1);

export const qualifyingTomes = (tomes: Tomes) =>
  Object.entries(tomes).filter(([id, lvl]) => {
    const e = ENCH[id];
    return e && !e.curse && lvl > 0 && lvl >= minQualifying(e.max);
  }).length;

export type TomeTier = 0 | 1 | 2 | 3;
export const depletedTier = (W: number, q: number): TomeTier => {
  if (W >= GATES.t2) return q >= GATES.t3Tomes ? 3 : 2;
  if (W >= GATES.t1) return 1;
  return 0;
};

/* ════════ 经验 ════════ */
export const xpPts = (l: number) => (l >= 30 ? 112 + (l - 30) * 9 : l >= 15 ? 37 + (l - 15) * 5 : 7 + Math.max(0, l) * 2);
export const totalXp = (lvl: number) => {
  let s = 0;
  for (let l = 0; l < Math.max(0, lvl); l++) s += xpPts(l);
  return s;
};
export const pointsForLevels = (from: number, n: number) => {
  let s = 0;
  for (let l = Math.max(0, from - n); l < from; l++) s += xpPts(l);
  return s;
};

export interface XpReq {
  raw: number;
  req: number;
  d: number;
  disc: number;
  vanilla: boolean;
  refund?: number;
}

const clampDisc = (d: number) => Math.max(0, Math.min(CFG.maxTotal, d));

export const tierDeduction = (L: number, M: number) => {
  const cm = Math.max(1, M);
  if (cm <= 1) return 3;
  const r = Math.max(1, Math.min(L, cm)) / cm;
  return r <= 0.4 ? 1 : r <= 0.75 ? 2 : 3;
};

export const masterTome = (L: number, M: number, raw: number, disc: number): XpReq => {
  const cm = Math.max(1, M);
  const tier = tierDeduction(L, cm);
  const minT = Math.max(tier, jr(8 + 22 * (Math.min(cm, L) / cm)));
  const rawT = raw > 0 ? Math.max(minT, raw) : minT;
  const d = clampDisc(disc);
  return { raw: rawT, req: Math.max(tier, jr(rawT * (1 - d / 100))), d: tier, disc: d, vanilla: true };
};

export const incremental = (a: number, k: number, M: number, raw: number, disc: number): XpReq => {
  const cm = Math.max(1, M);
  const delta = Math.max(1, k - Math.max(0, a));
  const tier = tierDeduction(delta, cm);
  const tF = Math.min(cm, k) / cm;
  const pF = Math.min(cm, Math.max(0, a)) / cm;
  const rem = Math.max(0.15, tF - CFG.credit * pF);
  const minStep = Math.max(tier, jr(8 + 22 * rem));
  const scaled = raw > 0 ? Math.max(tier, jr(raw * (tF <= 0 ? 1 : rem / tF))) : minStep;
  const rawT = Math.max(minStep, scaled);
  const d = clampDisc(disc);
  return { raw: Math.max(1, rawT), req: Math.max(tier, jr(rawT * (1 - d / 100))), d: tier, disc: d, vanilla: true };
};

export const fullRitual = (raw: number, disc: number): XpReq => {
  const r = Math.max(0, raw);
  if (r === 0) return { raw: 0, req: 0, d: 0, disc: 0, vanilla: false };
  const d = clampDisc(disc);
  const ded = Math.max(1, jr(r * (1 - d / 100)));
  return { raw: r, req: ded, d: ded, disc: d, vanilla: false };
};

export const fullArcaneOrUpgrade = (ex: number, tgt: number, M: number, raw: number, disc: number): XpReq => {
  if (raw <= 0) return { raw: 0, req: 0, d: 0, disc: 0, vanilla: false };
  const base = fullRitual(raw, disc);
  const floor = ex > 0 ? incremental(ex, tgt, M, 0, disc) : masterTome(tgt, M, 0, disc);
  const d = Math.max(base.d, floor.d);
  const req = Math.max(d, Math.max(base.req, floor.req));
  return { raw: Math.max(base.raw, floor.raw), req, d, disc: base.disc, vanilla: false };
};

/** enchantment_costs.json 基础经验 */
export const baseXpCost = (L: number, M: number) => {
  if (M <= 1) return 10;
  if (L <= 1) return 2;
  return Math.max(2, jr(2 + ((L - 1) / (M - 1)) * 8));
};

export type RowKind = "enchant" | "combine" | "research";

/** ScreenHandler.resolveEffectiveXpRequirement 的附魔/升阶分支 */
export const resolveEnchantXp = (e: Ench, target: number, existing: number, stored: number, disc: number, kind: RowKind = "enchant"): XpReq => {
  const M = e.max;
  const direct = baseXpCost(target, M);
  const rawCost = kind === "combine" ? Math.max(1, jr(direct * 0.6)) : kind === "research" ? Math.max(1, jr(direct * 1.4)) : direct;
  if (existing > 0 && target > existing) {
    if (stored >= target) {
      const eff = kind === "combine" ? Math.min(rawCost, direct) : direct;
      return incremental(existing, target, M, eff, disc);
    }
    const deltaRaw = Math.max(1, direct - baseXpCost(existing, M));
    const effRaw = kind === "enchant" ? deltaRaw : Math.min(rawCost, deltaRaw);
    return fullArcaneOrUpgrade(existing, target, M, effRaw, disc);
  }
  if (kind === "enchant" && stored >= target) return masterTome(target, M, rawCost, disc);
  return fullArcaneOrUpgrade(0, target, M, rawCost, disc);
};

/** 置换 */
export const transformXp = (raw: number, disc: number, minReq: number, deduct: number): XpReq => {
  const r = Math.max(0, raw);
  if (r === 0) return { raw: 0, req: 0, d: 0, disc: 0, vanilla: true };
  const tier = deduct > 0 ? deduct : r <= 1 ? 1 : tierDeduction(r, 30);
  const minGate = Math.max(tier, Math.max(1, minReq));
  const d = clampDisc(disc);
  return { raw: r, req: Math.max(minGate, jr(r * (1 - d / 100))), d: tier, disc: d, vanilla: true };
};

export const minPoints = (x: XpReq) => {
  if (x.d <= 0) return 0;
  const start = Math.max(x.d, x.req);
  let s = 0;
  for (let i = 0; i < x.d; i++) s += xpPts(start - 1 - i);
  return s;
};

/* ════════ 退魔返还（归纳封顶）════════ */
const MARGIN = 5;
export const essence = (M: number, L: number, anvil: number, treasure: boolean, scale = 1): number => {
  const sc = Math.max(0, Math.min(1, scale));
  if (L <= 0 || sc <= 0) return 0;
  const cm = Math.max(1, M);
  const target = Math.min(L, cm);
  const rarity = Math.min(1.45, Math.max(1, 1 + 0.18 * Math.log(Math.max(1, anvil)))) * (treasure ? 1.15 : 1);
  const base = cm === 1 ? 34 : 48;
  const v = new Array(target + 1).fill(0);
  for (let k = 1; k <= target; k++) {
    const desired = jr(sc * base * rarity * Math.pow(k / cm, 1.65));
    let cap = Math.max(0, minPoints(masterTome(k, cm, 0, CFG.maxTotal)) - MARGIN);
    for (let a = 1; a < k; a++) {
      const step = minPoints(incremental(a, k, cm, 0, CFG.maxTotal));
      cap = Math.min(cap, Math.max(0, v[a] + step - MARGIN));
    }
    v[k] = Math.max(v[k - 1], Math.min(desired, cap));
  }
  return v[target];
};

export const essenceOf = (e: Ench, L: number) => (e.curse ? 0 : essence(e.max, L, e.anvil, !!e.treasure));

export const stepRefund = (e: Ench, cur: number, to: number) => Math.max(0, essenceOf(e, cur) - (to <= 0 ? 0 : essenceOf(e, to)));

/** 单洗：targeted_strip 3~10 插值 → forTargetedCleanse */
export const stripXp = (e: Ench, L: number, disc: number): XpReq => {
  const M = Math.max(1, e.max);
  const raw = M <= 1 ? 10 : jr(3 + ((Math.min(L, M) - 1) / (M - 1)) * 7);
  const tier = tierDeduction(L, M);
  const base = Math.max(tier, Math.max(4, raw));
  const d = clampDisc(disc);
  return { raw: base, req: Math.max(tier, jr(base * (1 - d / 100))), d: tier, disc: d, vanilla: true };
};

/** ItemCostOption.computeCount 移植（base_count / max_level_count / level_exponent） */
export const costCount = (base: number, maxLvlCount: number, exp: number, L: number, M: number) => {
  const sM = Math.max(1, M);
  const sL = Math.max(1, Math.min(sM, L));
  if (sM === 1) return Math.max(1, jr(base + (maxLvlCount - base) * 0.45));
  const span = Math.min(1.3, 0.52 + 0.096 * sM);
  const effMax = base + (maxLvlCount - base) * span;
  const u = (sL - 1) / (sM - 1);
  return Math.max(1, jr(base + (effMax - base) * Math.pow(u, exp)));
};

export const stripGrit = (e: Ench, L: number) => costCount(1, 3, 1.15, L, e.max);

/* ════════ 宝藏顿悟 ════════ */
export const epiphanyProb = (W: number, E: number, A: number) => {
  if (W < EPIPHANY.minShelves) return 0;
  const eff = CFG.epiGlobalW * Math.max(0, E) + CFG.epiAffinityW * Math.max(0, A);
  const raw = EPIPHANY.baseChance + Math.max(0, W - EPIPHANY.minShelves) * EPIPHANY.perShelf + eff * EPIPHANY.perTome;
  return Math.max(0, Math.min(EPIPHANY.maxChance, raw));
};

export const epiphanyScore = (W: number, E: number, A: number) =>
  W < EPIPHANY.minShelves ? 0 : Math.max(0, W - EPIPHANY.minShelves) * CFG.epiShelfScore + CFG.epiGlobalScore * E + CFG.epiAffinityScore * A;

export const epiphanySlots = (W: number, E: number, A: number) => {
  if (W < EPIPHANY.minShelves) return 0;
  const unlocked = 1 + Math.floor(epiphanyScore(W, E, A) / EPIPHANY.scorePerSlot);
  return Math.max(1, Math.min(EPIPHANY.maxSlots, unlocked));
};
