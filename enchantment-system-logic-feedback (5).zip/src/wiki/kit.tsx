import { createContext, useContext, useRef, useState, type ReactNode } from "react";
import { createPortal } from "react-dom";
import { motion } from "framer-motion";
import { Sprite } from "./pixel";
import { ITEM_NAME, type Target } from "./data";
import type { Tomes, XpReq } from "./mechanics";

/* ═══════════ 全局书库状态（模拟器 → 全站联动）═══════════ */
export interface LibState {
  W: number;
  setW: (n: number) => void;
  tomes: Tomes;
  setTome: (id: string, lvl: number) => void;
  setTomes: (t: Tomes) => void;
  target: Target;
  setTarget: (t: Target) => void;
}
const LibCtx = createContext<LibState | null>(null);
export const useLib = () => useContext(LibCtx)!;

export const LibProvider = ({ children }: { children: ReactNode }) => {
  const [W, setW] = useState(24);
  const [tomes, setTomes] = useState<Tomes>({ sharpness: 5, protection: 3, efficiency: 4, mending: 1 });
  const [target, setTarget] = useState<Target>("sword");
  const setTome = (id: string, lvl: number) =>
    setTomes((t) => {
      const n = { ...t };
      if (lvl <= 0) delete n[id];
      else n[id] = lvl;
      return n;
    });
  return <LibCtx.Provider value={{ W, setW, tomes, setTome, setTomes, target, setTarget }}>{children}</LibCtx.Provider>;
};

/* ═══════════ MC 提示框 ═══════════ */
export const McTip = ({ children, tip, className }: { children: ReactNode; tip: ReactNode; className?: string }) => {
  const [pos, setPos] = useState<{ x: number; y: number } | null>(null);
  const ref = useRef<HTMLSpanElement>(null);
  return (
    <span
      ref={ref}
      className={`relative inline-flex ${className ?? ""}`}
      onMouseMove={(e) => setPos({ x: e.clientX, y: e.clientY })}
      onMouseLeave={() => setPos(null)}
    >
      {children}
      {pos &&
        createPortal(
          <div
            className="mc-tooltip fixed z-[100] pointer-events-none max-w-[280px]"
            style={{
              left: Math.min(pos.x + 14, window.innerWidth - 290),
              top: Math.max(8, pos.y - 30),
            }}
          >
            {tip}
          </div>,
          document.body,
        )}
    </span>
  );
};

/* ═══════════ 物品格 ═══════════ */
export const Slot = ({
  id,
  count,
  size = 40,
  lore,
  glint,
  highlight,
  empty,
}: {
  id?: string | null;
  count?: number;
  size?: number;
  lore?: ReactNode;
  glint?: boolean;
  highlight?: string;
  empty?: boolean;
}) => {
  const inner = (
    <span
      className="mc-slot relative inline-flex items-center justify-center"
      style={{
        width: size,
        height: size,
        outline: highlight ? `2px solid ${highlight}` : undefined,
        boxShadow: highlight ? `inset 2px 2px 0 #373737, inset -2px -2px 0 #fff, 0 0 14px ${highlight}` : undefined,
      }}
    >
      {id && !empty && <Sprite id={id} size={size - 8} glint={glint} />}
      {count !== undefined && count > 1 && (
        <span
          className="absolute right-[2px] bottom-[-1px] font-vt text-white leading-none"
          style={{ fontSize: size * 0.48, textShadow: "2px 2px 0 #3f3f3f" }}
        >
          {count}
        </span>
      )}
    </span>
  );
  if (!id || empty) return inner;
  return (
    <McTip
      tip={
        <>
          <div className="mc-title">{ITEM_NAME[id] ?? id}</div>
          {lore}
          <div className="mc-gray" style={{ fontSize: 14 }}>
            {id.includes(":") ? id : `minecraft:${id}`}
          </div>
        </>
      }
    >
      {inner}
    </McTip>
  );
};

/* ═══════════ 经验徽章 ═══════════ */
export const XpBadge = ({ x, compact }: { x: XpReq; compact?: boolean }) => {
  if (x.refund && x.refund > 0)
    return (
      <span className="inline-flex items-center gap-1.5 font-vt text-[18px] leading-none text-[#55ffff]">
        <Sprite id="experience_orb" size={18} /> +{x.refund}
        {!compact && <span className="text-[14px] text-mute">点</span>}
      </span>
    );
  if (x.req <= 0 && x.d <= 0)
    return <span className="font-vt text-[18px] leading-none text-[#55ff55]">免费</span>;
  if (x.vanilla)
    return (
      <span className="inline-flex items-center gap-1.5">
        <span className="inline-flex -space-x-1">
          {Array.from({ length: Math.min(3, x.d) }).map((_, i) => (
            <Sprite key={i} id="experience_orb" size={18} style={{ animation: `orbBob 1.8s ${i * 0.2}s ease-in-out infinite` }} />
          ))}
        </span>
        <span className="font-vt text-[18px] leading-none text-[#80ff20]">Lv.{x.req}</span>
        {!compact && <span className="font-vt text-[15px] leading-none text-mute">扣{x.d}级</span>}
      </span>
    );
  return (
    <span className="inline-flex items-center gap-1.5">
      <Sprite id="experience_bottle" size={18} glint={false} style={{ filter: "hue-rotate(210deg) saturate(1.4)" }} />
      <span className="font-vt text-[18px] leading-none text-[#ff55ff]">-{x.d}L</span>
      {!compact && <span className="font-vt text-[15px] leading-none text-mute">需 Lv.{x.req}</span>}
    </span>
  );
};

/* ═══════════ 章节骨架 ═══════════ */
export const WSection = ({
  id,
  icon,
  kicker,
  title,
  intro,
  children,
  bg,
  tone = "#a18cff",
}: {
  id: string;
  icon: string;
  kicker: string;
  title: ReactNode;
  intro?: ReactNode;
  children: ReactNode;
  bg?: string;
  tone?: string;
}) => (
  <section id={id} data-wiki-section className="relative scroll-mt-20 py-16 md:py-20">
    {bg && (
      <div className="absolute inset-0 -mx-6 md:-mx-10 overflow-hidden rounded-sm pointer-events-none">
        <img src={bg} alt="" className="w-full h-full object-cover opacity-[0.18]" />
        <div className="absolute inset-0 bg-gradient-to-b from-obsidian via-obsidian/70 to-obsidian" />
      </div>
    )}
    <div className="relative">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-60px" }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="flex items-start gap-4 mb-8"
      >
        <span
          className="mc-slot w-14 h-14 flex items-center justify-center shrink-0"
          style={{ boxShadow: `inset 2px 2px 0 #373737, inset -2px -2px 0 #fff, 0 0 24px ${tone}55` }}
        >
          <Sprite id={icon} size={40} />
        </span>
        <div>
          <p className="font-pixel text-[10px] tracking-[0.3em] uppercase mb-1.5" style={{ color: tone }}>
            {kicker}
          </p>
          <h2 className="font-display text-3xl md:text-4xl font-black text-parch leading-tight">{title}</h2>
        </div>
      </motion.div>
      {intro && (
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="max-w-3xl text-[14.5px] leading-8 text-mute font-light mb-10"
        >
          {intro}
        </motion.p>
      )}
      {children}
    </div>
  </section>
);

export const Panel = ({ children, className, tone }: { children: ReactNode; className?: string; tone?: string }) => (
  <div
    className={`pixelframe bg-vellum/75 backdrop-blur-sm border p-5 md:p-6 ${className ?? ""}`}
    style={{ borderColor: tone ? `${tone}33` : "rgba(161,140,255,0.15)" }}
  >
    {children}
  </div>
);

export const PanelTitle = ({ children, tone = "#e8c37c", icon }: { children: ReactNode; tone?: string; icon?: string }) => (
  <p className="flex items-center gap-2 font-pixel text-[10px] tracking-[0.22em] uppercase mb-4" style={{ color: tone }}>
    {icon && <Sprite id={icon} size={16} />}
    {children}
  </p>
);

export const Stat = ({ label, value, tone = "#ede6d4", sub }: { label: string; value: ReactNode; tone?: string; sub?: ReactNode }) => (
  <div className="rounded-sm bg-obsidian/60 border border-arcane/10 px-4 py-3">
    <p className="text-[11px] text-faint mb-1">{label}</p>
    <p className="font-vt text-[30px] leading-none" style={{ color: tone }}>
      {value}
    </p>
    {sub && <p className="text-[10.5px] text-faint mt-1.5">{sub}</p>}
  </div>
);

export const Range = ({
  label,
  value,
  min,
  max,
  onChange,
  fmt,
  tone = "#e8c37c",
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (n: number) => void;
  fmt?: (n: number) => string;
  tone?: string;
}) => (
  <label className="block">
    <span className="flex justify-between items-baseline mb-2">
      <span className="text-xs text-mute">{label}</span>
      <span className="font-vt text-[22px] leading-none" style={{ color: tone }}>
        {fmt ? fmt(value) : value}
      </span>
    </span>
    <input type="range" className="slider w-full" min={min} max={max} value={value} onChange={(e) => onChange(Number(e.target.value))} />
  </label>
);

export const Pill = ({ on, onClick, children, tone = "#a18cff" }: { on?: boolean; onClick?: () => void; children: ReactNode; tone?: string }) => (
  <button
    onClick={onClick}
    className="px-3 py-1.5 rounded-sm text-[12px] border transition-all duration-200 inline-flex items-center gap-1.5"
    style={{
      color: on ? "#0a0913" : tone,
      background: on ? tone : `${tone}10`,
      borderColor: `${tone}44`,
    }}
  >
    {children}
  </button>
);
