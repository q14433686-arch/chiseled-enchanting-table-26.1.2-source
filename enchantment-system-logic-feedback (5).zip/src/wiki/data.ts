// ═══════════════════════════════════════════════════════════
// WIKI 数据层 · 对齐 arena/d0fffdab @ 89f545b
// ═══════════════════════════════════════════════════════════

export type Target = "sword" | "axe" | "pickaxe" | "helmet" | "chestplate" | "leggings" | "boots" | "bow" | "crossbow" | "trident" | "mace" | "rod" | "book";

export const TARGETS: { id: Target; name: string; icon: string }[] = [
  { id: "sword", name: "剑", icon: "diamond_sword" },
  { id: "pickaxe", name: "镐", icon: "diamond" },
  { id: "chestplate", name: "胸甲", icon: "diamond_block" },
  { id: "boots", name: "靴子", icon: "lapis_block" },
  { id: "bow", name: "弓", icon: "arrow" },
  { id: "trident", name: "三叉戟", icon: "trident" },
  { id: "book", name: "普通书", icon: "book" },
];

export interface Ench {
  id: string;
  name: string;
  max: number;
  anvil: number;
  treasure?: boolean; // #minecraft:treasure
  exclusive?: boolean; // #chiseled_enchanting_table:epiphany_exclusive
  curse?: boolean;
  on: Target[];
}

const ARMOR: Target[] = ["helmet", "chestplate", "leggings", "boots"];
const TOOLS: Target[] = ["pickaxe", "axe"];
const ALL: Target[] = ["sword", "axe", "pickaxe", ...ARMOR, "bow", "crossbow", "trident", "mace", "rod"];

export const ENCHANTS: Ench[] = [
  { id: "protection", name: "保护", max: 4, anvil: 1, on: ARMOR },
  { id: "fire_protection", name: "火焰保护", max: 4, anvil: 2, on: ARMOR },
  { id: "blast_protection", name: "爆炸保护", max: 4, anvil: 4, on: ARMOR },
  { id: "projectile_protection", name: "弹射物保护", max: 4, anvil: 2, on: ARMOR },
  { id: "feather_falling", name: "摔落缓冲", max: 4, anvil: 2, on: ["boots"] },
  { id: "respiration", name: "水下呼吸", max: 3, anvil: 4, on: ["helmet"] },
  { id: "aqua_affinity", name: "水下速掘", max: 1, anvil: 4, exclusive: true, on: ["helmet"] },
  { id: "thorns", name: "荆棘", max: 3, anvil: 8, on: ARMOR },
  { id: "depth_strider", name: "深海探索者", max: 3, anvil: 4, on: ["boots"] },
  { id: "frost_walker", name: "冰霜行者", max: 2, anvil: 4, treasure: true, exclusive: true, on: ["boots"] },
  { id: "soul_speed", name: "灵魂疾行", max: 3, anvil: 8, treasure: true, exclusive: true, on: ["boots"] },
  { id: "swift_sneak", name: "迅捷潜行", max: 3, anvil: 8, treasure: true, exclusive: true, on: ["leggings"] },
  { id: "sharpness", name: "锋利", max: 5, anvil: 1, on: ["sword", "axe"] },
  { id: "smite", name: "亡灵杀手", max: 5, anvil: 2, on: ["sword", "axe", "mace"] },
  { id: "bane_of_arthropods", name: "节肢杀手", max: 5, anvil: 2, on: ["sword", "axe", "mace"] },
  { id: "knockback", name: "击退", max: 2, anvil: 2, on: ["sword"] },
  { id: "fire_aspect", name: "火焰附加", max: 2, anvil: 4, on: ["sword", "mace"] },
  { id: "looting", name: "抢夺", max: 3, anvil: 4, on: ["sword"] },
  { id: "sweeping_edge", name: "横扫之刃", max: 3, anvil: 4, on: ["sword"] },
  { id: "efficiency", name: "效率", max: 5, anvil: 1, on: TOOLS },
  { id: "silk_touch", name: "精准采集", max: 1, anvil: 8, exclusive: true, on: TOOLS },
  { id: "fortune", name: "时运", max: 3, anvil: 4, on: TOOLS },
  { id: "unbreaking", name: "耐久", max: 3, anvil: 2, on: ALL },
  { id: "power", name: "力量", max: 5, anvil: 1, on: ["bow"] },
  { id: "punch", name: "冲击", max: 2, anvil: 4, on: ["bow"] },
  { id: "flame", name: "火矢", max: 1, anvil: 4, exclusive: true, on: ["bow"] },
  { id: "infinity", name: "无限", max: 1, anvil: 8, exclusive: true, on: ["bow"] },
  { id: "multishot", name: "多重射击", max: 1, anvil: 2, exclusive: true, on: ["crossbow"] },
  { id: "quick_charge", name: "快速装填", max: 3, anvil: 2, on: ["crossbow"] },
  { id: "piercing", name: "穿透", max: 4, anvil: 1, on: ["crossbow"] },
  { id: "loyalty", name: "忠诚", max: 3, anvil: 1, on: ["trident"] },
  { id: "impaling", name: "穿刺", max: 5, anvil: 2, on: ["trident"] },
  { id: "riptide", name: "激流", max: 3, anvil: 4, on: ["trident"] },
  { id: "channeling", name: "引雷", max: 1, anvil: 8, exclusive: true, on: ["trident"] },
  { id: "density", name: "致密", max: 5, anvil: 1, on: ["mace"] },
  { id: "breach", name: "破甲", max: 4, anvil: 2, on: ["mace"] },
  { id: "wind_burst", name: "风爆", max: 3, anvil: 4, treasure: true, exclusive: true, on: ["mace"] },
  { id: "luck_of_the_sea", name: "海之眷顾", max: 3, anvil: 4, on: ["rod"] },
  { id: "lure", name: "饵钓", max: 3, anvil: 4, on: ["rod"] },
  { id: "mending", name: "经验修补", max: 1, anvil: 4, treasure: true, exclusive: true, on: ALL },
  { id: "binding_curse", name: "绑定诅咒", max: 1, anvil: 8, treasure: true, curse: true, on: ARMOR },
  { id: "vanishing_curse", name: "消失诅咒", max: 1, anvil: 8, treasure: true, curse: true, on: ALL },
];

export const ENCH = Object.fromEntries(ENCHANTS.map((e) => [e.id, e])) as Record<string, Ench>;

export const canEnchant = (e: Ench, t: Target) => t !== "book" && e.on.includes(t);

/** 默认可直附（#in_enchanting_table 减去宝藏/诅咒/顿悟专属） */
export const isDefaultUnlock = (e: Ench) => !e.treasure && !e.curse && !e.exclusive;

export const ROMAN = ["0", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"];
export const roman = (n: number) => (n <= 10 ? ROMAN[n] : String(n));

/** 母本书颜色（用于雕纹书架可视化） */
export const enchColor = (e: Ench) =>
  e.curse ? "#c0392b" : e.treasure ? "#e8c37c" : e.exclusive ? "#16a085" : e.on.some((t) => ARMOR.includes(t)) ? "#2e86de" : e.on.includes("bow") || e.on.includes("crossbow") ? "#27ae60" : "#8a2be2";

/* ── 合成配方 ── */
export interface Recipe {
  id: string;
  name: string;
  shaped: boolean;
  grid: (string | null)[]; // 9
  result: string;
  count: number;
  note: string;
}

export const RECIPES: Recipe[] = [
  {
    id: "table",
    name: "纂刻附魔台 · 直接合成",
    shaped: true,
    grid: [null, "book", null, "diamond", "chiseled_bookshelf", "diamond", "crying_obsidian", "crying_obsidian", "crying_obsidian"],
    result: "chiseled_enchanting_table",
    count: 1,
    note: "最快的入门路线：1 书 + 2 钻石 + 1 雕纹书架 + 3 哭泣的黑曜石。",
  },
  {
    id: "upgrade",
    name: "纂刻附魔台 · 原版升级",
    shaped: true,
    grid: ["amethyst_shard", "chiseled_bookshelf", "amethyst_shard", "amethyst_shard", "enchanting_table", "amethyst_shard", "crying_obsidian", "crying_obsidian", "crying_obsidian"],
    result: "chiseled_enchanting_table",
    count: 1,
    note: "已有原版附魔台？4 紫水晶碎片 + 雕纹书架 + 3 哭泣的黑曜石即可升级，不浪费钻石。",
  },
  {
    id: "crying",
    name: "哭泣的黑曜石 · 量产",
    shaped: true,
    grid: ["obsidian", "obsidian", "obsidian", "obsidian", "ghast_tear", "obsidian", "obsidian", "obsidian", "obsidian"],
    result: "crying_obsidian",
    count: 8,
    note: "8 黑曜石围住 1 恶魂之泪 → 8 哭泣的黑曜石。",
  },
  {
    id: "catalyst",
    name: "秘法凝晶",
    shaped: true,
    grid: ["amethyst_block", "diamond_block", "amethyst_block", "emerald_block", "crying_obsidian", "emerald_block", "lapis_block", "gold_block", "lapis_block"],
    result: "arcane_catalyst",
    count: 1,
    note: "高阶万能触媒：可单件顶替宝藏顿悟、研究升级、退魔与锁定的整套材料。",
  },
  {
    id: "grit",
    name: "退魔砂 · 无序",
    shaped: false,
    grid: ["flint", "quartz", "glow_ink_sac", "bone_meal", null, null, null, null, null],
    result: "cleansing_grit",
    count: 4,
    note: "燧石 + 下界石英 + 发光墨囊 + 骨粉 → 4 退魔砂。单洗与破咒的核心耗材。",
  },
  {
    id: "grimoire_shelf",
    name: "纂刻秘典 · 书架路线",
    shaped: false,
    grid: ["writable_book", "chiseled_bookshelf", null, null, null, null, null, null, null],
    result: "arcane_grimoire",
    count: 1,
    note: "书与笔 + 雕纹书架，无序合成。已在书架前？直接翻书即可。",
  },
  {
    id: "grimoire_tome",
    name: "纂刻秘典 · 残卷路线",
    shaped: false,
    grid: ["depleted_tome", "ink_sac", null, null, null, null, null, null, null],
    result: "arcane_grimoire",
    count: 1,
    note: "褪魔残卷 + 墨囊，无序合成。把退魔留下的残页写成一本图解手册。",
  },
];

export const ITEM_NAME: Record<string, string> = {
  book: "书",
  enchanted_book: "附魔书",
  depleted_tome: "褪魔残卷",
  diamond: "钻石",
  emerald: "绿宝石",
  lapis_lazuli: "青金石",
  amethyst_shard: "紫水晶碎片",
  chiseled_bookshelf: "雕纹书架",
  bookshelf: "书架",
  crying_obsidian: "哭泣的黑曜石",
  obsidian: "黑曜石",
  ghast_tear: "恶魂之泪",
  enchanting_table: "附魔台",
  chiseled_enchanting_table: "纂刻附魔台",
  amethyst_block: "紫水晶块",
  diamond_block: "钻石块",
  emerald_block: "绿宝石块",
  lapis_block: "青金石块",
  gold_block: "金块",
  arcane_catalyst: "秘法凝晶",
  arcane_grimoire: "纂刻秘典",
  flint: "燧石",
  quartz: "下界石英",
  glow_ink_sac: "发光墨囊",
  ink_sac: "墨囊",
  bone_meal: "骨粉",
  cleansing_grit: "退魔砂",
  paper: "纸",
  golden_apple: "金苹果",
  enchanted_golden_apple: "附魔金苹果",
  glass_bottle: "玻璃瓶",
  experience_bottle: "附魔之瓶",
  totem_of_undying: "不死图腾",
  diamond_sword: "钻石剑",
  trident: "三叉戟",
  nautilus_shell: "鹦鹉螺壳",
  prismarine_shard: "海晶碎片",
  prismarine_crystals: "海晶砂粒",
  echo_shard: "回响碎片",
  sculk: "幽匿块",
  experience_orb: "经验球",
  blaze_rod: "烈焰棒",
  arrow: "箭",
  spectral_arrow: "光灵箭",
  copper_block: "铜块",
  string: "线",
  ender_pearl: "末影珍珠",
  blue_ice: "蓝冰",
  soul_sand: "灵魂沙",
  breeze_rod: "旋风棒",
  iron_ingot: "铁锭",
  feather: "羽毛",
  phantom_membrane: "幻翼膜",
  wind_charge: "风弹",
  cactus: "仙人掌",
  sweet_berries: "甜浆果",
};

/* ── 物品置换（item_transformations.json） ── */
export interface Transform {
  id: string;
  name: string;
  input: string;
  output: string;
  primary: [string, number];
  extras: [string, number][];
  xp: number;
  minReq: number;
  deduct: number;
  blurb: string;
}

export const TRANSFORMS: Transform[] = [
  { id: "blank_overwrite", name: "空白覆写", input: "depleted_tome", output: "book", primary: ["paper", 2], extras: [], xp: 1, minReq: 1, deduct: 1, blurb: "残卷还原为纯净普通书。纸/骨粉/青金石/绿宝石/墨囊/发光墨囊/紫水晶任选 2 个；受残卷三梯度减免。" },
  { id: "experience_bottle", name: "附魔之瓶", input: "glass_bottle", output: "experience_bottle", primary: ["lapis_lazuli", 8], extras: [["amethyst_shard", 2]], xp: 5, minReq: 3, deduct: 1, blurb: "把经验封进瓶里：门槛 Lv.5（保底 Lv.3），只扣 1 级。" },
  { id: "echo_shard", name: "回响碎片", input: "amethyst_shard", output: "echo_shard", primary: ["sculk", 4], extras: [["crying_obsidian", 2]], xp: 12, minReq: 2, deduct: 2, blurb: "不必再下远古城市：幽匿之力灌注紫水晶。" },
  { id: "enchanted_golden_apple", name: "附魔金苹果", input: "golden_apple", output: "enchanted_golden_apple", primary: ["gold_block", 8], extras: [["emerald", 14]], xp: 20, minReq: 2, deduct: 2, blurb: "复刻旧版禁忌配方，但需要绿宝石与等级门槛。" },
  { id: "trident", name: "三叉戟", input: "diamond_sword", output: "trident", primary: ["nautilus_shell", 1], extras: [["prismarine_shard", 3], ["prismarine_crystals", 2]], xp: 25, minReq: 3, deduct: 3, blurb: "轻量化海洋配方：钻石剑 + 鹦鹉螺壳 + 海晶材料。" },
  { id: "totem_of_undying", name: "不死图腾", input: "emerald_block", output: "totem_of_undying", primary: ["gold_block", 4], extras: [["ghast_tear", 1], ["amethyst_shard", 5]], xp: 30, minReq: 3, deduct: 3, blurb: "无需袭击：绿宝石块被赋予不朽之魂。门槛 Lv.30。" },
];

/* ── 宝藏顿悟（treasure_epiphany.json） ── */
export const EPIPHANY = {
  minShelves: 32,
  baseChance: 0.28,
  perShelf: 0.008,
  perTome: 0.022,
  maxChance: 0.9,
  maxSlots: 4,
  scorePerSlot: 12,
  cycleTicks: 12000,
  freezeTicks: 24000,
  maxFreezeTicks: 72000,
  freezeXp: 1,
  rerollXp: 2,
  defaultXp: 24,
};

export const TREASURE_COSTS: { id: string; xp: number; a: [string, number]; b: [string, number] }[] = [
  { id: "aqua_affinity", xp: 18, a: ["nautilus_shell", 2], b: ["prismarine_shard", 8] },
  { id: "flame", xp: 20, a: ["blaze_rod", 4], b: ["arrow", 16] },
  { id: "multishot", xp: 20, a: ["spectral_arrow", 16], b: ["emerald", 14] },
  { id: "channeling", xp: 22, a: ["copper_block", 4], b: ["prismarine_crystals", 8] },
  { id: "silk_touch", xp: 24, a: ["diamond", 6], b: ["string", 16] },
  { id: "infinity", xp: 26, a: ["ender_pearl", 8], b: ["diamond", 4] },
  { id: "mending", xp: 28, a: ["diamond", 8], b: ["amethyst_shard", 10] },
  { id: "frost_walker", xp: 20, a: ["blue_ice", 10], b: ["amethyst_shard", 6] },
  { id: "soul_speed", xp: 20, a: ["ghast_tear", 4], b: ["soul_sand", 16] },
  { id: "swift_sneak", xp: 22, a: ["echo_shard", 3], b: ["sculk", 16] },
  { id: "wind_burst", xp: 25, a: ["breeze_rod", 4], b: ["amethyst_shard", 7] },
];

/* ── 进度 ── */
export interface Adv {
  id: string;
  title: string;
  desc: string;
  icon: string;
  goal?: boolean;
}
export const ADV_GROUPS: { name: string; tone: string; items: Adv[] }[] = [
  {
    name: "启程",
    tone: "#a18cff",
    items: [
      { id: "root", title: "纂刻之旅启程！", desc: "合成或升级你的第一台纂刻附魔台。", icon: "chiseled_enchanting_table" },
      { id: "craft", title: "纂刻附魔！", desc: "合成或升级你的第一台纂刻附魔台。", icon: "chiseled_bookshelf" },
      { id: "color_table", title: "看腻紫色了，不如……", desc: "手持染料为纂刻附魔台染色。", icon: "glow_ink_sac" },
      { id: "unlock_new_enchant", title: "告别随机附魔！", desc: "在附近的雕纹书架中放入附魔书以解锁对应附魔。", icon: "enchanted_book" },
    ],
  },
  {
    name: "藏书与升阶",
    tone: "#e8c37c",
    items: [
      { id: "enchant_to_book", title: "纂刻附魔书！", desc: "在纂刻附魔台上为书本铭刻附魔。", icon: "book" },
      { id: "upgrade_enchanted_book", title: "精研秘法", desc: "在纂刻附魔台上提升一本附魔书的附魔等级。", icon: "lapis_lazuli" },
      { id: "max_level_book", title: "秘典宗师", desc: "在纂刻附魔台上获得一本满级附魔书。", icon: "enchanted_book", goal: true },
      { id: "enchant_from_book", title: "免费附魔！", desc: "在纂刻附魔台上直接消耗材料格附魔书中的附魔。", icon: "enchanted_book" },
      { id: "transfer_enchanted_book", title: "移花接木", desc: "将附魔从一本书转移到另一本书。", icon: "paper" },
      { id: "all_enchant_book", title: "为什么会变成这样呢？", desc: "制作一本包含全部附魔的附魔书。", icon: "enchanted_book", goal: true },
    ],
  },
  {
    name: "书库共鸣",
    tone: "#8df0a4",
    items: [
      { id: "library_resonance", title: "满堂书香", desc: "通过周围书架达到高额经验减免。", icon: "bookshelf" },
      { id: "grand_library", title: "万卷圣堂", desc: "在周围放置至少 32 个普通书架，解锁宝藏顿悟。", icon: "bookshelf", goal: true },
      { id: "inscribe_epiphany", title: "灵光铭刻", desc: "成功附魔一条宝藏顿悟刷出的附魔。", icon: "experience_orb" },
      { id: "multi_epiphany", title: "群星共鸣", desc: "使同一件物品同时刷出至少 2 条宝藏顿悟。", icon: "amethyst_shard", goal: true },
      { id: "freeze_epiphany", title: "刹那永恒", desc: "锁定一次当前刷出的宝藏顿悟词条。", icon: "blue_ice" },
    ],
  },
  {
    name: "炼金与退魔",
    tone: "#f08cc8",
    items: [
      { id: "transmute_item", title: "炼金质变", desc: "在纂刻附魔台上完成一次物品置换。", icon: "experience_bottle" },
      { id: "enchanted_golden_apple", title: "禁忌金果", desc: "将金苹果置换为附魔金苹果。", icon: "enchanted_golden_apple", goal: true },
      { id: "arcane_catalyst", title: "万法归一", desc: "合成一枚秘法凝晶。", icon: "arcane_catalyst" },
      { id: "cleanse_enchantment", title: "返璞归真", desc: "完成一次退魔、降级或单洗。", icon: "cleansing_grit" },
      { id: "purge_curse", title: "破咒净魂", desc: "成功破除一条诅咒附魔。", icon: "ghast_tear" },
      { id: "blank_overwrite", title: "洗尽铅华", desc: "将褪魔残卷还原为普通书。", icon: "depleted_tome" },
    ],
  },
];

/* ── 自定义物品 ── */
export const CUSTOM_ITEMS = [
  {
    id: "arcane_grimoire",
    name: "纂刻秘典",
    kind: "手册",
    lore: ["手持右键翻阅 · 可在雕纹书架中摆放", "8 章图解 · 现场数据驱动的示意图"],
    body: "游戏内的双页图解手册：8 章、左右页对照、右边缘书签、键盘与鼠标翻页，右侧示意图直接读取当前服务器的书架与减免数据。两种无序配方都能做出来（书与笔 + 雕纹书架，或褪魔残卷 + 墨囊），做成后还能放进雕纹书架收藏。",
  },
  {
    id: "chiseled_enchanting_table",
    name: "纂刻附魔台",
    kind: "方块",
    lore: ["读取 7×5×7 内书架与雕纹书架", "手持染料右键可为台布染色"],
    body: "本 mod 的核心方块。以「目标格 + 材料格」两槽工作，左侧列表点击即附魔、升阶、置换或退魔。台布颜色可用任意原版染料混色，破坏后掉落物保留颜色；冻结中的顿悟状态也随方块保留。",
  },
  {
    id: "depleted_tome",
    name: "褪魔残卷",
    kind: "物品",
    lore: ["可在纂刻附魔台中还原为普通书"],
    body: "附魔书被合并消耗、或物品被全部退魔后留下的可 64 堆叠残页。它把「空组件附魔书」从普通书堆里隔离出来；在附魔台用「空白覆写」还原为书，代价随书库规模三梯度递减直至免费。",
  },
  {
    id: "cleansing_grit",
    name: "退魔砂",
    kind: "物品",
    lore: ["在附魔台「退魔」页单洗指定词条或破除诅咒"],
    body: "由燧石、下界石英、发光墨囊、骨粉无序合成（一次 4 个）。定向单洗与破除诅咒的首选耗材；所有退魔配方同时提供纯原版替代方案，不装本物品的数据包也能运行。",
  },
  {
    id: "arcane_catalyst",
    name: "秘法凝晶",
    kind: "物品",
    lore: ["万能触媒 · 可单件替代整套材料"],
    body: "六种贵重方块凝成的高阶触媒。在宝藏顿悟铭刻、研究升级、单洗、破咒等处可直接单件替代整组双材料——适合材料紧缺、但资源储备雄厚的后期玩家。",
  },
];

/* ── 数据包文件 ── */
export interface DpFile {
  path: string;
  title: string;
  desc: string;
  keys: [string, string][];
  sample: string;
}

export const DATAPACK: DpFile[] = [
  {
    path: "library_resonance.json",
    title: "书库共鸣",
    desc: "全部经验减免与顿悟亲和参数。修复后 25 个叶键全部被 fromJson 消费，并随 EnchantCostTablePayload 同步到客户端。",
    keys: [
      ["wooden_bookshelves.min_discount_bookshelves", "木书架减免起效数（12）"],
      ["wooden_bookshelves.max_discount_bookshelves", "木书架减免满额数（38）"],
      ["wooden_bookshelves.max_wooden_discount_percent", "木书架减免上限（15%）"],
      ["chiseled_mastery.mastery_unit_exponent", "母本权重 w = r^1.25"],
      ["chiseled_mastery.global_mastery_multiplier", "公共减免 = ⌊E·1.25⌋%"],
      ["chiseled_mastery.max_base_xp_discount_percent", "公共减免上限（35%）"],
      ["chiseled_mastery.max_specific_enchant_bonus_percent", "同种母本专属上限（15%）"],
      ["chiseled_mastery.max_total_xp_discount_percent", "总上限（40%）"],
      ["chiseled_mastery.incremental_step_credit_factor", "增量升阶信用因子（0.85）"],
      ["epiphany_affinity.*", "顿悟概率与槽位权重 12 项"],
    ],
    sample: `{
  "wooden_bookshelves": {
    "min_discount_bookshelves": 12,
    "max_discount_bookshelves": 38,
    "max_wooden_discount_percent": 15
  },
  "chiseled_mastery": {
    "mastery_unit_exponent": 1.25,
    "max_total_xp_discount_percent": 40,
    "incremental_step_credit_factor": 0.85
  }
}`,
  },
  {
    path: "shelf_gates.json",
    title: "书架阶梯",
    desc: "扫描体积、升阶书架门槛曲线、白板封顶模式、残卷三梯度与批次大小。",
    keys: [
      ["scan_volume.horizontal_radius / vertical_radius", "扫描半径（3 / 2 → 7×5×7）"],
      ["direct_upgrade_gates.max_bookshelves", "升阶 MAX 所需普通书架（38）"],
      ["direct_upgrade_gates.gamma", "门槛曲线指数（1.25）"],
      ["direct_upgrade_gates.blank_max_tier_mode", "白板封顶：half_ceil / level_one_only / full_curve"],
      ["direct_upgrade_gates.overrides", "按魔咒自定义门槛数组"],
      ["depleted_tome_gradients.tier1/2_bookshelves", "残卷梯度 8 / 18 架"],
      ["depleted_tome_gradients.tier3_qualifying_enchantments", "梯度叁所需去重满级母本（6 种）"],
      ["depleted_tome_gradients.base/tier3_batch_size", "单批覆写上限 8 / 64"],
    ],
    sample: `{
  "scan_volume": { "horizontal_radius": 3, "vertical_radius": 2 },
  "direct_upgrade_gates": {
    "enabled": true, "max_bookshelves": 38, "gamma": 1.25,
    "blank_max_tier_mode": "half_ceil", "overrides": {}
  },
  "depleted_tome_gradients": {
    "tier1_bookshelves": 8, "tier2_bookshelves": 18,
    "tier2_material_multiplier": 0.5,
    "tier3_qualifying_enchantments": 6,
    "base_batch_size": 8, "tier3_batch_size": 64
  }
}`,
  },
  {
    path: "disenchanting.json",
    title: "退魔",
    desc: "降级返还缩放、定向单洗与破除诅咒的经验与材料。返还缩放被钳制在 [0, 1]，且由归纳守恒构造保证永远低于铭刻成本。",
    keys: [
      ["xp_refund_scale", "返还缩放（≤ 1.0）"],
      ["allow_curse_purge", "是否允许破除诅咒"],
      ["targeted_strip.xp_cost_min / max", "单洗经验 3~10 级插值"],
      ["targeted_strip.options[]", "退魔砂 + 青金石/发光墨囊/紫水晶，或纯原版替代"],
      ["curse_purge.xp_cost", "破咒经验（12 级，完整消耗）"],
    ],
    sample: `{
  "enabled": true,
  "allow_curse_purge": true,
  "xp_refund_scale": 1.0,
  "targeted_strip": { "xp_cost_min": 3, "xp_cost_max": 10, "options": [ ... ] },
  "curse_purge": { "xp_cost": 12, "options": [ ... ] }
}`,
  },
  {
    path: "treasure_epiphany.json",
    title: "宝藏顿悟",
    desc: "顿悟门槛、概率、槽位、轮转/锁定/重刷与每种宝藏魔咒的专属双材料。宝藏池完全由标签驱动。",
    keys: [
      ["min_regular_bookshelves", "解锁门槛（32 架）"],
      ["base_chance / chance_per_extra_bookshelf / chance_per_master_tome / max_chance", "0.28 / 0.008 / 0.022 / 0.90"],
      ["max_slots_cap / score_per_extra_slot", "单件最多 4 条 / 每 12 分加一槽"],
      ["cycle_ticks", "自然轮转 12000 tick（10 分钟）"],
      ["freeze_duration_ticks / max_freeze_ticks", "每次锁定 +20 分钟，上限 60 分钟"],
      ["treasure_tags / exclude_tags", "#treasure + #epiphany_exclusive − #curse"],
    ],
    sample: `{
  "min_regular_bookshelves": 32,
  "base_chance": 0.28,
  "max_chance": 0.90,
  "max_slots_cap": 4,
  "cycle_ticks": 12000,
  "freeze_duration_ticks": 24000,
  "max_freeze_ticks": 72000,
  "treasure_tags": ["#minecraft:treasure", "#chiseled_enchanting_table:epiphany_exclusive"]
}`,
  },
  {
    path: "book_upgrades.json",
    title: "附魔书升阶",
    desc: "两本同级合并（零材料 + 0.6× 经验）与材料研究（主题化三选一材料 + 1.4× 经验）。研究材料可按魔咒覆写。",
    keys: [
      ["combine_route.xp_cost_multiplier_of_vanilla_like", "合并经验倍率（0.6）"],
      ["research_route.xp_cost_multiplier_of_direct_enchant", "研究经验倍率（1.4）"],
      ["research_route.default_material_cost", "默认：青金石 / 绿宝石 / 紫水晶 / 秘法凝晶"],
      ["research_route.enchantment_overrides", "如保护→铁锭/黑曜石；火焰保护→岩浆膏/烈焰粉…"],
    ],
    sample: `{
  "combine_route": { "enabled": true, "xp_cost_multiplier_of_vanilla_like": 0.6 },
  "research_route": {
    "enabled": true,
    "xp_cost_multiplier_of_direct_enchant": 1.4,
    "enchantment_overrides": {
      "minecraft:feather_falling": { "material_cost": { "options": [
        { "item": "minecraft:feather", "count_per_level": 4 }
      ] } }
    }
  }
}`,
  },
  {
    path: "enchantment_costs.json",
    title: "附魔基础价",
    desc: "铭刻基础经验（1 级 2 → 满级 10，单级魔咒 10）与按相对等级渐进的单材料曲线。",
    keys: [
      ["xp.level_one_cost / common_max_cost", "多级魔咒 2 → 10 线性"],
      ["xp.rare_single_level_cost", "单级魔咒 10"],
      ["xp.overrides", "按魔咒按等级覆写"],
      ["items.options[].base_count / max_level_count / level_exponent", "材料曲线（见版本页注意事项）"],
    ],
    sample: `{
  "xp": { "level_one_cost": 2, "common_max_cost": 10, "rare_single_level_cost": 10 },
  "items": { "options": [
    { "item": "minecraft:lapis_lazuli", "base_count": 3, "max_level_count": 20, "level_exponent": 1.3 },
    { "item": "minecraft:emerald", "base_count": 2, "max_level_count": 18, "level_exponent": 1.3 },
    { "item": "minecraft:amethyst_shard", "base_count": 1, "max_level_count": 8, "level_exponent": 1.3 }
  ] }
}`,
  },
  {
    path: "item_transformations.json",
    title: "物品置换",
    desc: "自定义「输入 → 输出」配方，自动同步至界面与 JEI/REI。min_required_level 为门槛下限，deducted_levels 为实际扣除等级。",
    keys: [
      ["input / output", "上槽输入与产出"],
      ["primary_cost / cost_options", "下槽主材料（可多选）"],
      ["additional_costs", "背包辅料"],
      ["xp_cost / min_required_level / deducted_levels", "门槛基数 / 门槛下限 / 实扣等级"],
    ],
    sample: `{
  "id": "chiseled_enchanting_table:experience_bottle",
  "input": "minecraft:glass_bottle",
  "output": "minecraft:experience_bottle",
  "xp_cost": 5, "min_required_level": 3, "deducted_levels": 1,
  "primary_cost": { "item": "minecraft:lapis_lazuli", "count": 8 },
  "additional_costs": [ { "item": "minecraft:amethyst_shard", "count": 2 } ]
}`,
  },
  {
    path: "default_enchantments.json",
    title: "默认解锁",
    desc: "哪些魔咒无需母本即可在台上出现。默认取 #in_enchanting_table，排除宝藏、诅咒与顿悟专属标签。",
    keys: [
      ["tags[]", "{ tag: #minecraft:in_enchanting_table, level: 1 }"],
      ["exclude", "#treasure / #curse / #epiphany_exclusive"],
      ["values[]", "额外单独列出的魔咒"],
    ],
    sample: `{
  "values": [],
  "tags": [ { "tag": "#minecraft:in_enchanting_table", "level": 1 } ],
  "exclude": ["#minecraft:treasure", "#minecraft:curse",
              "#chiseled_enchanting_table:epiphany_exclusive"]
}`,
  },
  {
    path: "tags/block/regular_bookshelves.json",
    title: "普通书架标签",
    desc: "哪些方块算作「普通书架」。默认引用原版 #enchantment_power_provider，模组书架自动兼容。",
    keys: [["values", "#minecraft:enchantment_power_provider"]],
    sample: `{ "replace": false, "values": ["#minecraft:enchantment_power_provider"] }`,
  },
  {
    path: "tags/enchantment/epiphany_exclusive.json",
    title: "顿悟专属标签",
    desc: "不在原版宝藏标签里、但本 mod 仍限定为顿悟/母本获取的魔咒（水下速掘、火矢、多重射击、引雷、精准采集、无限……）。",
    keys: [["values", "11 个魔咒 ID"]],
    sample: `{ "replace": false, "values": [
  "minecraft:aqua_affinity", "minecraft:flame", "minecraft:multishot",
  "minecraft:channeling", "minecraft:silk_touch", "minecraft:infinity",
  "minecraft:mending", "minecraft:frost_walker", "minecraft:soul_speed",
  "minecraft:swift_sneak", "minecraft:wind_burst"
] }`,
  },
  {
    path: "config/chiseled_enchanting_table.json",
    title: "启动配置（非数据包）",
    desc: "ModBootstrapConfig：游戏启动前读取的全局开关，位于 .minecraft/config/。",
    keys: [["enchanted_book_stack_size", "附魔书堆叠上限 1~64（默认 64；与自动化模组冲突时可设 1）"]],
    sample: `{ "enchanted_book_stack_size": 64 }`,
  },
];
