import { useState } from "react";
import { motion } from "framer-motion";
import { TRANSFORMS, ITEM_NAME } from "../data";
import { Sprite } from "../pixel";
import { totalMastery, baseDiscount, transformXp } from "../mechanics";
import { useLib, WSection, Slot, XpBadge } from "../kit";

const Card = ({ t, disc, i }: { t: (typeof TRANSFORMS)[number]; disc: number; i: number }) => {
  const [flip, setFlip] = useState(false);
  const x = transformXp(t.xp, disc, t.minReq, t.deduct);
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: i * 0.07 }}
      className="h-[250px]"
      style={{ perspective: 1000 }}
      onMouseEnter={() => setFlip(true)}
      onMouseLeave={() => setFlip(false)}
      onClick={() => setFlip((f) => !f)}
    >
      <motion.div className="relative w-full h-full" style={{ transformStyle: "preserve-3d" }} animate={{ rotateY: flip ? 180 : 0 }} transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}>
        {/* front */}
        <div className="absolute inset-0 pixelframe bg-vellum/80 border border-arcane/20 p-5 flex flex-col items-center justify-center gap-4" style={{ backfaceVisibility: "hidden" }}>
          <div className="flex items-center gap-4">
            <Sprite id={t.input} size={52} />
            <motion.span animate={{ x: [0, 5, 0] }} transition={{ duration: 1.4, repeat: Infinity }} className="font-vt text-[32px] text-gild">➜</motion.span>
            <Sprite id={t.output} size={64} />
          </div>
          <p className="font-display font-black text-xl text-parch">{t.name}</p>
          <XpBadge x={x} />
          <p className="font-pixel text-[8.5px] tracking-widest text-faint">悬停 / 点击查看配方</p>
        </div>
        {/* back */}
        <div className="absolute inset-0 pixelframe bg-[#1d1433] border border-gild/30 p-5 flex flex-col gap-3" style={{ backfaceVisibility: "hidden", transform: "rotateY(180deg)" }}>
          <p className="font-display font-bold text-parch">{t.name}</p>
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-faint w-10">上槽</span>
            <Slot id={t.input} size={36} />
            <span className="text-[11px] text-faint w-10 ml-2">下槽</span>
            <Slot id={t.primary[0]} count={t.primary[1]} size={36} />
          </div>
          {t.extras.length > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-[11px] text-faint w-10">背包</span>
              {t.extras.map(([it, n]) => (
                <Slot key={it} id={it} count={n} size={36} />
              ))}
            </div>
          )}
          <p className="text-[12px] leading-5 text-mute font-light">{t.blurb}</p>
          <p className="mt-auto font-vt text-[15px] text-faint">
            xp_cost {t.xp} · min_required_level {t.minReq} · deducted_levels {t.deduct}
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
};

const Transmute = () => {
  const { W, tomes } = useLib();
  const disc = baseDiscount(W, totalMastery(tomes));
  return (
    <WSection
      id="transmute"
      icon="experience_bottle"
      kicker="Item Transformations"
      title="物品置换"
      tone="#7ee8dc"
      intro={
        <>
          附魔台不只附魔。上槽放入可置换物品、下槽放主材料、辅料放在背包，即可完成置换；全部走原版量产模式（只扣 1~3 级）。
          当前书库公共减免 <span className="font-vt text-[18px] text-xp">−{disc}%</span> 已计入门槛。全部配方都可在 JEI / REI「纂刻置换」分类中双向检索，
          也可以在 item_transformations.json 中添加你自己的配方。
        </>
      }
    >
      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {TRANSFORMS.map((t, i) => (
          <Card key={t.id} t={t} disc={disc} i={i} />
        ))}
      </div>
      <p className="text-[11.5px] text-faint mt-4">
        空白覆写的经验与材料另受「褪魔残卷三梯度」修正：{ITEM_NAME.depleted_tome}在 8 架起免经验、18 架起材料减半、再加 6 种满级母本则完全免费。
      </p>
    </WSection>
  );
};

export default Transmute;
