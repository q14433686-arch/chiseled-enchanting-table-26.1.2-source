import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DATAPACK } from "../data";
import { Sprite } from "../pixel";
import { WSection, Panel } from "../kit";

const highlight = (src: string) =>
  src
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/("(?:[^"\\]|\\.)*")(\s*:)/g, '<span class="json-key">$1</span>$2')
    .replace(/:\s*("(?:[^"\\]|\\.)*")/g, ': <span class="json-str">$1</span>')
    .replace(/(\[|,)\s*("(?:[^"\\]|\\.)*")/g, '$1 <span class="json-str">$2</span>')
    .replace(/\b(-?\d+(?:\.\d+)?)\b/g, '<span class="json-num">$1</span>')
    .replace(/\b(true|false)\b/g, '<span class="json-bool">$1</span>');

const Datapack = () => {
  const [sel, setSel] = useState(0);
  const [copied, setCopied] = useState(false);
  const f = DATAPACK[sel];
  const isTag = f.path.startsWith("tags/");
  const isCfg = f.path.startsWith("config/");
  const fullPath = isCfg ? `.minecraft/${f.path}` : isTag ? `data/chiseled_enchanting_table/${f.path}` : `data/chiseled_enchanting_table/chiseled_enchanting_table/${f.path}`;

  return (
    <WSection
      id="datapack"
      icon="paper"
      kicker="Datapack Reference"
      title="数据包与配置"
      tone="#a18cff"
      intro="几乎所有数值都由数据包驱动，并在玩家进服与 /reload 后同步到客户端——JEI / REI 显示的永远是服务器真实价格。左侧选择文件查看键说明与示例。"
    >
      <div className="grid lg:grid-cols-[280px_1fr] gap-5">
        <Panel className="!p-3">
          <p className="font-vt text-[16px] text-faint px-2 pb-2">📁 data/chiseled_enchanting_table/</p>
          <div className="space-y-0.5">
            {DATAPACK.map((d, i) => {
              const tag = d.path.startsWith("tags/");
              const cfg = d.path.startsWith("config/");
              return (
                <button
                  key={d.path}
                  onClick={() => setSel(i)}
                  className="w-full flex items-center gap-2 px-2 py-1.5 rounded-sm text-left transition-colors"
                  style={{ background: sel === i ? "rgba(161,140,255,0.14)" : "transparent", paddingLeft: tag ? 22 : 8 }}
                >
                  <Sprite id={cfg ? "chiseled_enchanting_table" : tag ? "glow_ink_sac" : "paper"} size={16} />
                  <span className={`font-code text-[11.5px] truncate ${sel === i ? "text-parch" : "text-mute"}`}>{d.path.replace(/^tags\/(block|enchantment)\//, "").replace("config/", "⚙ ")}</span>
                </button>
              );
            })}
          </div>
        </Panel>

        <AnimatePresence mode="wait">
          <motion.div key={f.path} initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.25 }}>
            <Panel tone="#a18cff">
              <div className="flex flex-wrap items-baseline gap-3 mb-2">
                <h3 className="font-display font-black text-2xl text-parch">{f.title}</h3>
                <code className="font-code text-[11px] text-faint break-all">{fullPath}</code>
              </div>
              <p className="text-[13.5px] leading-7 text-mute font-light mb-5">{f.desc}</p>
              <div className="grid xl:grid-cols-2 gap-5">
                <div className="space-y-1.5">
                  {f.keys.map(([k, v]) => (
                    <div key={k} className="rounded-sm bg-obsidian/60 border border-arcane/10 px-3 py-2">
                      <code className="font-code text-[11px] text-arcane break-all">{k}</code>
                      <p className="text-[12px] text-mute mt-0.5">{v}</p>
                    </div>
                  ))}
                </div>
                <div className="relative">
                  <button
                    onClick={() => {
                      navigator.clipboard?.writeText(f.sample);
                      setCopied(true);
                      setTimeout(() => setCopied(false), 1400);
                    }}
                    className="absolute right-2 top-2 px-2 py-1 rounded-sm text-[11px] border border-arcane/25 text-mute hover:text-parch bg-obsidian/80"
                  >
                    {copied ? "已复制 ✓" : "复制"}
                  </button>
                  <pre
                    className="rounded-sm bg-[#07060d] border border-arcane/15 p-4 pt-9 overflow-x-auto font-code text-[11.5px] leading-6 text-parch/90"
                    dangerouslySetInnerHTML={{ __html: highlight(f.sample) }}
                  />
                </div>
              </div>
            </Panel>
          </motion.div>
        </AnimatePresence>
      </div>
    </WSection>
  );
};

export default Datapack;
