import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Block3D, Sprite, TEX } from "../pixel";
import { Slot, McTip } from "../kit";

const DYES: [string, string][] = [
  ["紫色", "#5b2b8a"], ["红色", "#a3262a"], ["蓝色", "#2c3e9a"], ["青色", "#167a8a"],
  ["绿色", "#4a6a1c"], ["黄绿色", "#6ab02a"], ["黄色", "#d8b020"], ["橙色", "#d06a1a"],
  ["品红色", "#b03aa8"], ["粉红色", "#e07aa8"], ["淡蓝色", "#4a9ad8"], ["棕色", "#6a4428"],
  ["黑色", "#1c1c22"], ["灰色", "#4a4a52"], ["淡灰色", "#8a8a8a"], ["白色", "#d8d8d8"],
];

const GLYPHS = Array.from("ᔑʖᓵ↸ᒷ⎓⊣⍑╎⋮ꖌꖎᒲリ𝙹ᑑ∷ᓭℸ⚍⍊∴⨅ᚠᚢᚦᚨᚱᚲᚷ");

/** 原版附魔台粒子：从书架方向飞向书本 */
const RuneStream = () => {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (!c) return;
    const g = c.getContext("2d")!;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    let w = 0;
    let h = 0;
    const resize = () => {
      w = c.clientWidth;
      h = c.clientHeight;
      c.width = w * dpr;
      c.height = h * dpr;
      g.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);
    interface P { x: number; y: number; sx: number; sy: number; t: number; sp: number; g: string; gold: boolean; s: number }
    const ps: P[] = [];
    const spawn = (): P => {
      const ang = Math.random() * Math.PI * 2;
      const rad = Math.max(w, h) * (0.35 + Math.random() * 0.35);
      const cx = w * 0.5;
      const cy = h * 0.42;
      const sx = cx + Math.cos(ang) * rad;
      const sy = cy + Math.sin(ang) * rad * 0.6;
      return { x: sx, y: sy, sx, sy, t: 0, sp: 0.004 + Math.random() * 0.006, g: GLYPHS[Math.floor(Math.random() * GLYPHS.length)], gold: Math.random() < 0.28, s: 11 + Math.random() * 9 };
    };
    for (let i = 0; i < 70; i++) {
      const p = spawn();
      p.t = Math.random();
      ps.push(p);
    }
    let raf = 0;
    const tick = () => {
      g.clearRect(0, 0, w, h);
      const cx = w * 0.5;
      const cy = h * 0.42;
      for (let i = 0; i < ps.length; i++) {
        const p = ps[i];
        p.t += p.sp;
        if (p.t >= 1) {
          ps[i] = spawn();
          continue;
        }
        const e = p.t * p.t * (3 - 2 * p.t);
        const lift = Math.sin(p.t * Math.PI) * 60;
        p.x = p.sx + (cx - p.sx) * e;
        p.y = p.sy + (cy - p.sy) * e - lift;
        const a = Math.sin(p.t * Math.PI) * 0.9;
        g.font = `${p.s * (1 - e * 0.5)}px "Noto Sans SC", serif`;
        g.fillStyle = p.gold ? `rgba(232,195,124,${a})` : `rgba(190,170,255,${a})`;
        g.shadowColor = p.gold ? "rgba(232,195,124,0.8)" : "rgba(161,140,255,0.8)";
        g.shadowBlur = 8;
        g.fillText(p.g, p.x, p.y);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);
  return <canvas ref={ref} className="absolute inset-0 w-full h-full pointer-events-none" />;
};

/** 3D 附魔台 + 开合之书 */
const TableScene = ({ cloth }: { cloth: string }) => {
  const S = 132;
  const side = TEX.tableSide(cloth);
  const top = TEX.tableTop(cloth);
  const bottom = TEX.obsidian();
  const page = TEX.pageL();
  const cover = TEX.cover();
  return (
    <div className="relative w-[260px] h-[300px] mx-auto" style={{ perspective: 900 }}>
      <div className="absolute left-1/2 top-[58%]" style={{ transformStyle: "preserve-3d", animation: "spinSlow 22s linear infinite" }}>
        <div style={{ transformStyle: "preserve-3d", transform: `translate3d(${-S / 2}px, ${-S / 2}px, 0)` }}>
          <Block3D size={S} side={side} top={top} bottom={bottom} height={0.75} glow="rgba(161,140,255,0.25)" />
        </div>
        {/* book */}
        <div
          className="absolute"
          style={{ transformStyle: "preserve-3d", transform: `translate3d(0, ${-S * 0.62}px, 0)` }}
        >
          <div style={{ transformStyle: "preserve-3d", animation: "bookHover 3.4s ease-in-out infinite" }}>
            {[-1, 1].map((sgn) => (
              <div
                key={sgn}
                className="absolute"
                style={{
                  width: 44,
                  height: 58,
                  top: -29,
                  left: sgn < 0 ? -44 : 0,
                  transformOrigin: sgn < 0 ? "right center" : "left center",
                  transformStyle: "preserve-3d",
                  animation: `${sgn < 0 ? "bookFlapL" : "bookFlapR"} 3.4s ease-in-out infinite`,
                }}
              >
                <span className="cube-face" style={{ width: 44, height: 58, backgroundImage: `url(${page})`, transform: sgn < 0 ? "scaleX(-1)" : undefined }} />
                <span className="cube-face" style={{ width: 44, height: 58, backgroundImage: `url(${cover})`, transform: "rotateY(180deg) translateZ(1px)" }} />
              </div>
            ))}
            <div className="absolute -left-10 -top-10 w-20 h-20 rounded-full" style={{ background: "radial-gradient(circle, rgba(200,170,255,0.55), transparent 70%)", filter: "blur(6px)" }} />
          </div>
        </div>
      </div>
      <div className="absolute left-1/2 bottom-2 -translate-x-1/2 w-56 h-10 rounded-[50%]" style={{ background: "radial-gradient(ellipse, rgba(109,94,240,0.45), transparent 70%)" }} />
    </div>
  );
};

const STEPS = [
  { t: "搭建书库", d: "在附魔台周围 7×5×7 内摆放普通书架（推进等级、减免经验）与雕纹书架（放附魔书即解锁母本）。" },
  { t: "放入目标与材料", d: "上槽放装备 / 书 / 可置换物品；下槽放青金石、绿宝石或紫水晶任一种。辅料留在背包即可自动扣除。" },
  { t: "点击词条", d: "左侧列表直接点击。满足材料与等级即生效，没有铁砧那样的「过于昂贵」累积惩罚。" },
];

const QuickStart = () => {
  const [step, setStep] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setStep((s) => (s + 1) % 3), 3600);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="grid lg:grid-cols-[1fr_380px] gap-6 items-center">
      <div className="space-y-3">
        {STEPS.map((s, i) => (
          <button
            key={s.t}
            onClick={() => setStep(i)}
            className="w-full text-left flex gap-4 p-4 rounded-sm border transition-all duration-300"
            style={{
              background: step === i ? "rgba(161,140,255,0.08)" : "rgba(10,9,19,0.5)",
              borderColor: step === i ? "rgba(161,140,255,0.4)" : "rgba(161,140,255,0.1)",
            }}
          >
            <span className="font-pixel text-2xl leading-none w-8 shrink-0" style={{ color: step === i ? "#e8c37c" : "#6f659a" }}>
              {i + 1}
            </span>
            <span>
              <span className="block font-display font-bold text-[16px] text-parch mb-1">{s.t}</span>
              <span className="block text-[13px] leading-6 text-mute font-light">{s.d}</span>
            </span>
          </button>
        ))}
      </div>
      {/* GUI mock */}
      <div className="mc-panel p-3 select-none">
        <p className="font-vt text-[18px] text-[#404040] mb-2 px-1">纂刻附魔台</p>
        <div className="flex gap-2">
          <div className="flex-1 bg-[#1a142c] p-1.5 space-y-1 min-h-[150px]">
            {["锋利 V", "耐久 III", "经验修补"].map((r, i) => (
              <motion.div
                key={r}
                animate={{
                  backgroundColor: step === 2 && i === 0 ? "#3d2f6b" : "#241d3d",
                  scale: step === 2 && i === 0 ? [1, 1.04, 1] : 1,
                }}
                transition={{ duration: 0.5 }}
                className="flex items-center justify-between px-2 py-1.5 font-vt text-[17px] text-[#e0d8ff]"
                style={{ opacity: step === 0 ? 0.35 : 1 }}
              >
                <span>{r}</span>
                <span className="text-[#80ff20] text-[15px]">{i === 2 ? "Lv.17" : i === 0 ? "Lv.18" : "Lv.13"}</span>
              </motion.div>
            ))}
          </div>
          <div className="flex flex-col items-center gap-2 pt-1">
            <AnimatePresence mode="wait">
              <motion.div key={`t${step}`} initial={{ y: -10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ opacity: 0 }}>
                <Slot id={step >= 1 ? "diamond_sword" : null} glint={step === 2} size={42} />
              </motion.div>
            </AnimatePresence>
            <Slot id={step >= 1 ? "lapis_lazuli" : null} count={step === 2 ? 12 : 20} size={42} />
          </div>
        </div>
        <div className="mt-3 flex gap-1 justify-center">
          {Array.from({ length: 9 }).map((_, i) => (
            <span key={i} className="mc-slot w-8 h-8 inline-flex items-center justify-center">
              {step === 0 && i < 5 && <Sprite id={i % 2 ? "chiseled_bookshelf" : "bookshelf"} size={24} />}
              {step >= 1 && i === 0 && <Sprite id="experience_orb" size={20} />}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
};

const Home = () => {
  const [cloth, setCloth] = useState(DYES[0][1]);
  return (
    <>
      <header id="home" data-wiki-section className="relative -mx-6 md:-mx-10 -mt-6 overflow-hidden min-h-[640px] flex items-center">
        <img src="/images/wiki-hero.jpg" alt="" className="absolute inset-0 w-full h-full object-cover opacity-55 scale-105" />
        <div className="absolute inset-0 bg-gradient-to-r from-obsidian via-obsidian/75 to-obsidian/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-obsidian via-transparent to-obsidian/50" />
        <RuneStream />
        <div className="relative w-full grid lg:grid-cols-[1.15fr_1fr] gap-6 items-center px-6 md:px-12 py-16">
          <div>
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="font-pixel text-[11px] tracking-[0.4em] text-gild mb-5"
            >
              CHISELED ENCHANTING · WIKI
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1, duration: 0.9 }}
              className="font-display font-black leading-[1.05] text-parch"
              style={{ fontSize: "clamp(2.8rem, 6.5vw, 5.4rem)" }}
            >
              纂刻附魔台
              <br />
              <span className="shimmer-text">交互式图鉴</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.35, duration: 0.8 }}
              className="mt-6 max-w-xl text-[15px] leading-8 text-mute font-light"
            >
              告别看脸的随机词条。用<span className="text-parch">普通书架</span>推进等级、用
              <span className="text-parch">雕纹书架藏书</span>解锁母本，构筑可成长、可量产、可退魔、无累积惩罚的定向附魔工坊。
              新增的<span className="text-parch">纂刻秘典</span>把这一切装订成一本 8 章图解手册；页内所有计算器都与游戏实装公式逐行一致。
            </motion.p>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="mt-7 flex flex-wrap gap-2">
              {[
                ["Minecraft", "26.1.2"],
                ["Fabric Loader", "≥ 0.19.3"],
                ["Java", "≥ 25"],
                ["语言", "11 种"],
                ["JEI / REI", "可选联动"],
                ["手册", "8 章图解"],
              ].map(([k, v]) => (
                <span key={k} className="px-3 py-1.5 rounded-sm bg-obsidian/70 border border-arcane/20 text-[12px]">
                  <span className="text-faint mr-1.5">{k}</span>
                  <span className="font-vt text-[17px] text-parch">{v}</span>
                </span>
              ))}
            </motion.div>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.65 }} className="mt-8 flex gap-3">
              <a href="#library" className="px-6 py-3 pixelframe bg-arcane-deep/40 border border-arcane/50 text-parch text-sm font-medium hover:bg-arcane-deep/60 transition-colors glow-arcane">
                打开书库模拟器
              </a>
              <a href="#recipes" className="px-6 py-3 pixelframe border border-arcane/20 text-mute text-sm hover:text-parch transition-colors">
                从合成开始
              </a>
              <a href="#grimoire" className="px-6 py-3 pixelframe border border-gild/30 text-gild text-sm hover:bg-gild/10 transition-colors flex items-center gap-2">
                <Sprite id="arcane_grimoire" size={18} />翻阅秘典
              </a>
            </motion.div>
          </div>
          <div className="relative">
            <TableScene cloth={cloth} />
            <div className="mt-2 flex flex-col items-center gap-2">
              <p className="font-pixel text-[9px] tracking-[0.25em] text-faint">右键染料 · 为台布染色</p>
              <div className="grid grid-cols-8 gap-1">
                {DYES.map(([n, c]) => (
                  <McTip key={n} tip={<span className="mc-title">{n}染料</span>}>
                    <button
                      onClick={() => setCloth(c)}
                      className="w-6 h-6 transition-transform hover:scale-125"
                      style={{
                        background: c,
                        boxShadow: cloth === c ? "0 0 0 2px #fff, 0 0 12px #fff8" : "inset -2px -2px 0 #0006, inset 2px 2px 0 #fff3",
                      }}
                    />
                  </McTip>
                ))}
              </div>
            </div>
          </div>
        </div>
      </header>

      <section id="quickstart" data-wiki-section className="relative scroll-mt-20 py-16">
        <p className="font-pixel text-[10px] tracking-[0.3em] text-gild mb-2">QUICK START</p>
        <h2 className="font-display text-3xl md:text-4xl font-black text-parch mb-8">三步上手</h2>
        <QuickStart />
      </section>
    </>
  );
};

export default Home;
