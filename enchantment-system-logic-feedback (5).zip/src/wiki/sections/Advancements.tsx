import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ADV_GROUPS } from "../data";
import { Sprite } from "../pixel";
import { WSection, McTip } from "../kit";

const KEY = "cet-wiki-adv";

const Advancements = () => {
  const [done, setDone] = useState<Record<string, boolean>>(() => {
    try {
      return JSON.parse(localStorage.getItem(KEY) ?? "{}");
    } catch {
      return {};
    }
  });
  const [toast, setToast] = useState<{ title: string; goal?: boolean } | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(done));
    } catch {
      /* ignore */
    }
  }, [done]);

  const all = ADV_GROUPS.flatMap((g) => g.items);
  const count = all.filter((a) => done[a.id]).length;

  const toggle = (id: string, title: string, goal?: boolean) => {
    setDone((d) => {
      const n = { ...d, [id]: !d[id] };
      if (n[id]) {
        setToast({ title, goal });
        setTimeout(() => setToast(null), 2600);
      }
      return n;
    });
  };

  return (
    <WSection
      id="advancements"
      icon="experience_orb"
      kicker="Advancements"
      title="进度图鉴"
      tone="#e8c37c"
      intro="本 mod 共 21 项进度。点击图标即可标记为已完成——进度保存在浏览器本地，作为你的生存清单。"
    >
      <div className="flex items-center gap-4 mb-8">
        <div className="flex-1 h-3 bg-obsidian border border-arcane/20 rounded-sm overflow-hidden">
          <motion.div className="h-full bg-gradient-to-r from-gild-deep to-gild" animate={{ width: `${(count / all.length) * 100}%` }} />
        </div>
        <span className="font-vt text-[24px] text-gild">{count} / {all.length}</span>
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        {ADV_GROUPS.map((g, gi) => (
          <motion.div
            key={g.name}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: gi * 0.08 }}
            className="relative rounded-sm p-5 overflow-hidden"
            style={{ background: "linear-gradient(180deg, rgba(23,18,48,0.85), rgba(15,12,29,0.9))", border: `1px solid ${g.tone}30` }}
          >
            <div className="absolute inset-0 opacity-[0.06] pixelated" style={{ backgroundImage: "repeating-linear-gradient(0deg,#fff 0 1px,transparent 1px 16px),repeating-linear-gradient(90deg,#fff 0 1px,transparent 1px 16px)" }} />
            <p className="relative font-display font-bold text-lg mb-5" style={{ color: g.tone }}>{g.name}</p>
            <div className="relative flex flex-wrap items-center gap-y-6">
              {g.items.map((a, i) => (
                <div key={a.id} className="flex items-center">
                  <McTip
                    tip={
                      <>
                        <div className={a.goal ? "mc-purple" : "mc-yellow"}>{a.title}</div>
                        <div className="mc-gray">{a.desc}</div>
                        <div className={done[a.id] ? "mc-green" : "mc-gray"} style={{ fontSize: 14 }}>{done[a.id] ? "✔ 已完成" : "点击标记完成"}</div>
                      </>
                    }
                  >
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.92 }}
                      onClick={() => toggle(a.id, a.title, a.goal)}
                      className={`adv-frame ${done[a.id] ? "done" : ""} w-[52px] h-[52px] inline-flex items-center justify-center`}
                      style={{ clipPath: a.goal ? "polygon(20% 0,80% 0,100% 20%,100% 80%,80% 100%,20% 100%,0 80%,0 20%)" : undefined, borderRadius: a.goal ? 0 : 3 }}
                    >
                      <Sprite id={a.icon} size={32} />
                    </motion.button>
                  </McTip>
                  {i < g.items.length - 1 && <span className="w-5 h-[3px]" style={{ background: done[a.id] ? g.tone : "#3a3060" }} />}
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ x: 340, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 340, opacity: 0 }}
            className="fixed top-20 right-4 z-[90] flex items-center gap-3 px-4 py-3"
            style={{ background: "#212121", boxShadow: "inset 0 0 0 2px #555, 0 0 0 2px #000" }}
          >
            <Sprite id="experience_orb" size={28} />
            <div>
              <p className="font-vt text-[17px] leading-none" style={{ color: toast.goal ? "#ff55ff" : "#ffff55" }}>{toast.goal ? "目标已达成！" : "进度已达成！"}</p>
              <p className="font-vt text-[19px] text-white leading-tight mt-1">{toast.title}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </WSection>
  );
};

export default Advancements;
