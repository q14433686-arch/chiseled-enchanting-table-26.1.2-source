import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ENCHANTS, ENCH, roman } from "../data";
import { Sprite } from "../pixel";
import { totalMastery, effectiveDiscount, resolveEnchantXp, costCount, depletedTier, qualifyingTomes, GATES } from "../mechanics";
import { useLib, WSection, Panel, PanelTitle, Range, Slot, XpBadge, Pill } from "../kit";

const RESEARCH_DEFAULT: [string, number, number][] = [
  ["lapis_lazuli", 6, 26],
  ["emerald", 5, 23],
  ["amethyst_shard", 2, 10],
];
const RESEARCH_OVERRIDE: Record<string, [string, number, number | "per", number?][]> = {
  protection: [["iron_ingot", 4, 16], ["obsidian", 2, 9], ["amethyst_shard", 2, 7]],
  feather_falling: [["feather", 4, "per"], ["phantom_membrane", 1, "per"], ["wind_charge", 2, "per"]],
  thorns: [["cactus", 4, "per"], ["sweet_berries", 6, "per"], ["prismarine_shard", 3, "per"]],
};

const Compare = () => {
  const { W, tomes } = useLib();
  const [id, setId] = useState("sharpness");
  const e = ENCH[id];
  const [to, setTo] = useState(Math.min(4, e.max));
  useEffect(() => setTo(Math.min(Math.max(2, to), e.max)), [id]); // eslint-disable-line react-hooks/exhaustive-deps
  const stored = tomes[id] ?? 0;
  const disc = effectiveDiscount(W, totalMastery(tomes), stored, e.max);
  const from = to - 1;
  const comb = resolveEnchantXp(e, to, from, stored, disc, "combine");
  const res = resolveEnchantXp(e, to, from, stored, disc, "research");
  const override = RESEARCH_OVERRIDE[id];

  const routes = [
    {
      name: "合并升级",
      sub: `${e.name} ${roman(from)} + ${e.name} ${roman(from)}`,
      x: comb,
      mats: <span className="text-[12px] text-xp">零材料</span>,
      leftover: "消耗的那本 → 褪魔残卷",
      tone: "#8df0a4",
    },
    {
      name: "材料研究",
      sub: `${e.name} ${roman(from)} + 主题材料`,
      x: res,
      mats: (
        <div className="flex flex-wrap gap-1.5">
          {(override
            ? override.map(([it, a, b]) => [it, b === "per" ? a * to : costCount(a, b as number, 1.25, to, e.max)] as [string, number])
            : RESEARCH_DEFAULT.map(([it, a, b]) => [it, costCount(a, b, 1.3, to, e.max)] as [string, number])
          ).map(([it, n]) => (
            <Slot key={it} id={it} count={n} size={34} />
          ))}
          <Slot id="arcane_catalyst" count={1} size={34} />
        </div>
      ),
      leftover: "四选一 · 不产生残卷",
      tone: "#e8c37c",
    },
    {
      name: "直接转移",
      sub: "下槽放附魔书",
      x: { raw: 0, req: 0, d: 0, disc: 0, vanilla: true },
      mats: <span className="text-[12px] text-tealw">消耗一本现成附魔书</span>,
      leftover: "源书 → 褪魔残卷",
      tone: "#7ee8dc",
    },
  ];

  return (
    <Panel tone="#e8c37c">
      <div className="flex flex-wrap items-center gap-3 mb-5">
        <PanelTitle tone="#e8c37c" icon="enchanted_book">升阶比价</PanelTitle>
        <select value={id} onChange={(ev) => setId(ev.target.value)} className="bg-obsidian border border-arcane/25 rounded-sm px-3 py-1.5 text-[13px] text-parch ml-auto">
          {ENCHANTS.filter((q) => q.max > 1 && !q.curse).map((q) => (
            <option key={q.id} value={q.id}>{q.name}</option>
          ))}
        </select>
      </div>
      <Range label={`升至 ${roman(to)}（自 ${roman(from)}）`} value={to} min={2} max={e.max} onChange={setTo} fmt={roman} />
      <div className="grid md:grid-cols-3 gap-3 mt-5">
        {routes.map((r) => (
          <div key={r.name} className="rounded-sm bg-obsidian/60 border p-4 flex flex-col gap-3" style={{ borderColor: `${r.tone}40` }}>
            <div>
              <p className="font-display font-bold text-parch">{r.name}</p>
              <p className="text-[11.5px] text-faint">{r.sub}</p>
            </div>
            <XpBadge x={r.x} />
            <div className="min-h-[40px]">{r.mats}</div>
            <p className="text-[11px] text-faint mt-auto">{r.leftover}</p>
          </div>
        ))}
      </div>
      <p className="text-[11.5px] text-faint mt-4 leading-5">
        {stored >= to ? "已有母本覆盖目标等级：两种升阶都走增量量产模式（扣 1~2 级）。" : "无母本覆盖：按完整消耗模式，且不低于同等级母本路线的门槛。"}
        合并的经验基数为直附的 0.6×，研究为 1.4×；书架门槛（轨道二）同时生效。研究材料可在 book_upgrades.json 按魔咒主题覆写
        {override ? "（当前魔咒已覆写）" : ""}。
      </p>
    </Panel>
  );
};

const LIFE = [
  { id: "enchanted_book", t: "附魔书", d: "合并消耗 / 全部退魔" },
  { id: "depleted_tome", t: "褪魔残卷", d: "可 64 堆叠，与普通书隔离" },
  { id: "book", t: "空白覆写", d: "按梯度计价，最高免费" },
];

const Lifecycle = () => {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % 3), 2000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="flex items-center justify-center gap-3 md:gap-6 py-4">
      {LIFE.map((n, k) => (
        <div key={n.id} className="flex items-center gap-3 md:gap-6">
          <motion.div animate={{ scale: i === k ? 1.12 : 0.92, opacity: i === k ? 1 : 0.5 }} className="flex flex-col items-center gap-2 w-24">
            <span className="mc-slot w-16 h-16 inline-flex items-center justify-center" style={{ boxShadow: i === k ? "inset 2px 2px 0 #373737, inset -2px -2px 0 #fff, 0 0 20px #a18cff" : undefined }}>
              <Sprite id={n.id} size={48} />
            </span>
            <span className="font-display font-bold text-[13px] text-parch">{n.t}</span>
            <span className="text-[10.5px] text-faint text-center leading-4">{n.d}</span>
          </motion.div>
          {k < 2 && (
            <motion.span animate={{ opacity: i === k ? 1 : 0.25, x: i === k ? [0, 6, 0] : 0 }} transition={{ duration: 0.8, repeat: i === k ? Infinity : 0 }} className="font-vt text-[28px] text-gild">
              ➜
            </motion.span>
          )}
        </div>
      ))}
    </div>
  );
};

const OVERWRITE_MATS = ["paper", "bone_meal", "lapis_lazuli", "emerald", "ink_sac", "glow_ink_sac", "amethyst_shard"];

const Overwrite = () => {
  const { W, tomes } = useLib();
  const [n, setN] = useState(16);
  const [mat, setMat] = useState("paper");
  const tier = depletedTier(W, qualifyingTomes(tomes));
  const batch = tier === 3 ? GATES.t3Batch : GATES.baseBatch;
  const per = tier >= 3 ? 0 : tier === 2 ? 1 : 2;
  const clicks = Math.ceil(n / batch);
  const [done, setDone] = useState(false);
  return (
    <Panel tone="#7ee8dc">
      <PanelTitle tone="#7ee8dc" icon="depleted_tome">空白覆写 · 当前梯度 {["零", "壹", "贰", "叁"][tier]}</PanelTitle>
      <Lifecycle />
      <div className="grid md:grid-cols-2 gap-5 mt-4">
        <div className="space-y-4">
          <Range label="待还原残卷" value={n} min={1} max={64} onChange={(v) => { setN(v); setDone(false); }} fmt={(v) => `${v} 本`} tone="#7ee8dc" />
          <div className="flex flex-wrap gap-1.5">
            {OVERWRITE_MATS.map((m) => (
              <button key={m} onClick={() => setMat(m)} className="rounded-sm p-0.5" style={{ outline: mat === m ? "2px solid #7ee8dc" : "none" }}>
                <Slot id={m} count={2} size={36} />
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2 text-center">
            {[
              ["经验", tier >= 1 ? "0" : `Lv.1 扣1`, tier >= 1 ? "#8df0a4" : "#f08cc8"],
              ["材料", per === 0 ? "0" : `${per * n}`, per === 0 ? "#8df0a4" : "#7ee8dc"],
              ["点击", `${clicks} 次`, "#e8c37c"],
            ].map(([k, v, c]) => (
              <div key={k} className="rounded-sm bg-obsidian/60 border border-arcane/10 py-3">
                <p className="text-[11px] text-faint">{k}</p>
                <p className="font-vt text-[26px] leading-none mt-1" style={{ color: c }}>{v}</p>
              </div>
            ))}
          </div>
          <button
            onClick={() => setDone(true)}
            className="w-full py-3 pixelframe bg-tealw/10 border border-tealw/40 text-tealw text-sm hover:bg-tealw/20 transition-colors"
          >
            覆写：书 ×{n}
          </button>
          <AnimatePresence>
            {done && (
              <motion.div initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="flex items-center gap-3 justify-center">
                <Slot id="book" count={n} size={42} highlight="#8df0a4" />
                <span className="text-[12px] text-xp">还原完成{per ? ` · 消耗 ${per * n} 个材料` : " · 零代价"}</span>
              </motion.div>
            )}
          </AnimatePresence>
          <div className="flex gap-1.5 flex-wrap">
            {["8 架 → 免经验", "18 架 → 材料 2→1", "18 架 + 6 种满级母本 → 免费 · 单批 64"].map((t, k) => (
              <Pill key={t} on={tier >= k + 1} tone={["#7ee8dc", "#a18cff", "#8df0a4"][k]}>{t}</Pill>
            ))}
          </div>
        </div>
      </div>
    </Panel>
  );
};

const BookCare = () => (
  <WSection
    id="books"
    icon="enchanted_book"
    kicker="Book Cultivation"
    title="附魔书培养闭环"
    intro="附魔书在本 mod 中可 64 堆叠。未满级的书有两条升阶路线：两本同级合并，或直接用主题材料研究。被消耗的书不会凭空消失，而是成为褪魔残卷，再经空白覆写回到书本——一个完整的资源闭环。"
    tone="#e8c37c"
  >
    <div className="grid xl:grid-cols-2 gap-6">
      <Compare />
      <Overwrite />
    </div>
  </WSection>
);

export default BookCare;
