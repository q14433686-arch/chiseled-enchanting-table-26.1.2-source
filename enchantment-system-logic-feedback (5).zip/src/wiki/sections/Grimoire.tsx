import { useCallback, useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sprite } from "../pixel";
import { useLib, WSection, Panel, Slot, Range, McTip } from "../kit";
import {
  totalMastery,
  affinityMastery,
  effectiveDiscount,
  epiphanyProb,
  epiphanySlots,
  woodDiscount,
  globalDiscount,
  CFG,
} from "../mechanics";
import { TRANSFORMS } from "../data";

const CHAPTERS = [
  {
    key: "ch1",
    title: "合成与第一台附魔台",
    short: "启程",
    prose: "两台路线：2 钻石 + 雕纹书架 + 3 哭泣的黑曜石直接合成；或用 4 紫水晶碎片把原版附魔台升级上来。哭泣的黑曜石可以 8 黑曜石 + 1 恶魂之泪量产，一次 8 个。",
    bullets: ["直接合成：1 书 + 2 钻石 + 1 雕纹书架 + 3 哭泣的黑曜石", "升级路线：4 紫水晶碎片 + 雕纹书架 + 原版附魔台", "染料右键可给台布混色，掉落保留颜色"],
    icon: "chiseled_enchanting_table",
  },
  {
    key: "ch2",
    title: "界面五区与三步操作",
    short: "界面",
    prose: "上槽放目标、下槽放材料，左侧列表点词条。右侧面板显示书库共鸣，底部是背包。没有铁砧的「过于昂贵」惩罚；任何时刻都可以改主意。",
    bullets: ["上槽：装备 / 书 / 可置换物", "下槽：青金石、绿宝石或紫水晶任选一种", "辅料留在背包会自动扣"],
    icon: "book",
  },
  {
    key: "ch3",
    title: "书库三轨与书架阶梯",
    short: "书库",
    prose: "普通书架与雕纹书架各司其职：白板直附封顶在 ⌈M/2⌉；已持有词条后可沿书架曲线一路升到 MAX；雕纹书架里的附魔书则 1:1 解锁母本与量产。",
    bullets: ["7×5×7 扫描，普通书架走 regular_bookshelves 标签", "38 架解锁满级升阶；8 / 18 / 32 是三段关键刻度", "拆装书架后，已打开的界面会自动同步"],
    icon: "chiseled_bookshelf",
  },
  {
    key: "ch4",
    title: "双经验模式",
    short: "经验",
    prose: "母本覆盖的附魔与物品置换走绿球量产：只校验门槛，扣 1–3 级并完整保留经验条百分比。无母本的基础附魔、升阶与顿悟走紫色药水瓶，按完整等级扣除。",
    bullets: ["木架 12 架起减，38 架满 15%", "母本公共减免上限 35%，同词条再 +15%", "总封顶 40%"],
    icon: "experience_orb",
  },
  {
    key: "ch5",
    title: "附魔书培养",
    short: "藏书",
    prose: "附魔书可 64 堆叠。两本同级书可以合并（0 材料、0.6× 经验），也可以用主题材料研究（1.4× 经验，四选一，含秘法凝晶）。被消耗的书留下褪魔残卷。",
    bullets: ["合并：下槽放第二本同阶书", "研究：主题材料 + 经验，不需要第二本书", "满级母本入架后，全队进入 1–3 级量产"],
    icon: "enchanted_book",
  },
  {
    key: "ch6",
    title: "宝藏顿悟与锁定",
    short: "顿悟",
    prose: "32 架普通书架唤醒大书库。顿悟按 10 分钟自然轮转，可花经验与材料锁定，也可手动重刷。多级宝藏未满级时会继续刷出更高阶。",
    bullets: ["基础 28%，最高 90%", "单件可同时刷出多条，随藏书提升", "锁定可跨挖台、重放保留"],
    icon: "amethyst_shard",
  },
  {
    key: "ch7",
    title: "物品置换与残卷覆写",
    short: "炼金",
    prose: "六种内置置换都走绿球量产，辅料放背包。褪魔残卷可整批还原为书：8 架免经验、18 架材料减半、再加上 6 种满级母本则完全免费。",
    bullets: ["附魔之瓶门槛 5、保底 3、实扣 1 级", "三叉戟与图腾各扣 3 级", "单批 8 本；免费档单批 64 本"],
    icon: "experience_bottle",
  },
  {
    key: "ch8",
    title: "退魔页：降级、单洗、破咒",
    short: "退魔",
    prose: "磨浅刻痕返经验；精准剔除一条词条需要退魔砂；整件磨平免费。返还量守恒：每一级都严格低于母本路线最低实付，任何循环都不可能净赚。",
    bullets: ["降级：免材料，返还经验球", "单洗：退魔砂 + 经验，保留其余词条", "破咒：完整消耗 12 级"],
    icon: "cleansing_grit",
  },
];

const MiniCraft = () => (
  <div className="grid grid-cols-3 gap-[2px] w-max mx-auto">
    {["writable_book", null, null, "chiseled_bookshelf", null, null, null, null, null].map((s, i) => (
      <Slot key={i} id={s} size={26} />
    ))}
  </div>
);

const Diagram = ({ chapter }: { chapter: number }) => {
  const { W, tomes, target } = useLib();
  const E = totalMastery(tomes);
  const A = affinityMastery(tomes, target);
  const [wLocal, setWLocal] = useState(W);
  useEffect(() => setWLocal(W), [W]);
  const disc = effectiveDiscount(wLocal, E, 0, 5);
  const prob = epiphanyProb(wLocal, E, A);

  if (chapter === 1)
    return (
      <div className="flex flex-col items-center gap-3">
        <p className="font-pixel text-[9px] tracking-widest text-gild">路线 A · 书与笔 + 雕纹书架</p>
        <MiniCraft />
        <Sprite id="arcane_grimoire" size={44} />
        <p className="font-code text-[10px] text-faint">recipe/arcane_grimoire_from_shelf.json</p>
      </div>
    );
  if (chapter === 2)
    return (
      <div className="grid grid-cols-2 gap-2 w-full max-w-[240px] mx-auto">
        {[
          ["目标槽", "diamond_sword"],
          ["材料槽", "lapis_lazuli"],
          ["列表", "enchanted_book"],
          ["书库面板", "bookshelf"],
          ["背包", "book"],
        ].map(([label, icon]) => (
          <div key={label} className="rounded-sm border border-[#8a6a3a]/50 bg-[#f3e7c8]/50 p-2 flex items-center gap-2">
            <Slot id={icon} size={26} />
            <span className="text-[11px] text-[#5a4020]">{label}</span>
          </div>
        ))}
      </div>
    );
  if (chapter === 3)
    return (
      <div className="space-y-3">
        <Range label="普通书架" value={wLocal} min={0} max={60} onChange={setWLocal} fmt={(v) => `${v} 架`} tone="#3f7a3a" />
        <div className="relative h-3 bg-[#d8c69a] rounded-sm overflow-hidden">
          {[8, 18, 32, 38].map((m) => (
            <span key={m} className="absolute top-0 bottom-0 w-[2px] bg-[#8a6a3a]/60" style={{ left: `${(m / 60) * 100}%` }} />
          ))}
          <motion.div className="h-full bg-[#4a7a3a]" animate={{ width: `${(wLocal / 60) * 100}%` }} />
        </div>
        <div className="grid grid-cols-3 gap-1.5 text-center">
          {[
            ["木架减免", `−${woodDiscount(wLocal)}%`],
            ["公共减免", `−${Math.min(CFG.maxBase, disc)}%`],
            ["顿悟", wLocal >= 32 ? "苏醒" : "休眠"],
          ].map(([k, v]) => (
            <div key={k} className="rounded-sm border border-[#8a6a3a]/40 bg-[#f3e7c8]/60 py-1.5">
              <p className="text-[9.5px] text-[#7a6038]">{k}</p>
              <p className="font-vt text-[17px] text-[#3f5a2a]">{v}</p>
            </div>
          ))}
        </div>
      </div>
    );
  if (chapter === 4)
    return (
      <div className="space-y-3">
        {[
          ["木书架", woodDiscount(wLocal), "#3f7a3a"],
          ["公共母本", globalDiscount(E), "#4a5aa8"],
          ["同词条", 0, "#b58a2a"],
        ].map(([k, v, c]) => (
          <div key={k as string}>
            <div className="flex justify-between text-[10.5px] text-[#5a4020]">
              <span>{k as string}</span>
              <span className="font-vt text-[15px]">−{v as number}%</span>
            </div>
            <div className="h-2.5 bg-[#d8c69a] rounded-sm overflow-hidden">
              <motion.div className="h-full" style={{ background: c as string }} animate={{ width: `${((v as number) / 40) * 100}%` }} />
            </div>
          </div>
        ))}
        <p className="text-[10.5px] text-[#7a6038] text-center">三相叠加，总封顶 −40%</p>
      </div>
    );
  if (chapter === 5)
    return (
      <div className="space-y-2">
        {[
          ["合并路线", "两本同级书 → 下一级", "0 材料 · 0.6× 经验", "enchanted_book"],
          ["研究路线", "一本未满级书 + 主题材料", "四选一 · 1.4× 经验", "arcane_catalyst"],
          ["直接转移", "现成附魔书放入下槽", "0 经验 · 留下残卷", "depleted_tome"],
        ].map(([a, b, c, i]) => (
          <div key={a} className="flex items-center gap-2 rounded-sm border border-[#8a6a3a]/40 bg-[#f3e7c8]/60 p-2">
            <Sprite id={i} size={24} />
            <div className="min-w-0">
              <p className="text-[11px] text-[#4a3010] font-medium">{a}</p>
              <p className="text-[10px] text-[#7a6038] truncate">{b} · {c}</p>
            </div>
          </div>
        ))}
      </div>
    );
  if (chapter === 6)
    return (
      <div className="text-center space-y-2">
        <div className="relative w-[132px] h-[72px] mx-auto overflow-hidden">
          <svg viewBox="0 0 132 72" className="w-full h-full">
            <path d="M10 64 A56 56 0 0 1 122 64" fill="none" stroke="#d8c69a" strokeWidth="9" strokeLinecap="round" />
            <motion.path
              d="M10 64 A56 56 0 0 1 122 64"
              fill="none"
              stroke="#b58a2a"
              strokeWidth="9"
              strokeLinecap="round"
              strokeDasharray={Math.PI * 56}
              animate={{ strokeDashoffset: Math.PI * 56 * (1 - prob) }}
            />
          </svg>
          <span className="absolute inset-x-0 bottom-1 font-vt text-[24px] text-[#5a4020]">{Math.round(prob * 100)}%</span>
        </div>
        <p className="font-vt text-[15px] text-[#5a4020]">最多同时 {epiphanySlots(wLocal, E, A)} 条</p>
        <p className="text-[10px] text-[#7a6038]">门槛 {wLocal >= 32 ? "已满足" : "需 32 架"} · 每 10 分钟轮转</p>
      </div>
    );
  if (chapter === 7)
    return (
      <div className="grid grid-cols-3 gap-1.5">
        {TRANSFORMS.slice(0, 6).map((t) => (
          <McTip key={t.id} tip={<><div className="mc-title">{t.name}</div><div className="mc-gray">{t.primary[1]}× 主材料 + 辅料</div></>}>
            <div className="rounded-sm border border-[#8a6a3a]/40 bg-[#f3e7c8]/60 p-1.5 flex flex-col items-center">
              <Sprite id={t.output} size={22} />
              <span className="font-vt text-[12px] text-[#5a4020] mt-0.5">{t.xp}L</span>
            </div>
          </McTip>
        ))}
      </div>
    );
  return (
    <div className="grid grid-cols-2 gap-1.5">
      {[
        ["全部退魔", "0 材料", "experience_orb"],
        ["逐级降阶", "返经验", "depleted_tome"],
        ["定向单洗", "退魔砂", "cleansing_grit"],
        ["破除诅咒", "12 级", "ghast_tear"],
      ].map(([a, b, i]) => (
        <div key={a} className="rounded-sm border border-[#8a6a3a]/40 bg-[#f3e7c8]/60 p-2 text-center">
          <Sprite id={i} size={22} />
          <p className="text-[10.5px] text-[#4a3010] mt-1">{a}</p>
          <p className="font-vt text-[13px] text-[#7a6038]">{b}</p>
        </div>
      ))}
    </div>
  );
};

const Grimoire = () => {
  const [open, setOpen] = useState(false);
  const [i, setI] = useState(0);
  const ch = CHAPTERS[i];

  const go = useCallback((n: number) => setI((p) => Math.max(0, Math.min(CHAPTERS.length - 1, p + n))), []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key.toLowerCase() === "d") go(1);
      else if (e.key === "ArrowLeft" || e.key.toLowerCase() === "a") go(-1);
      else if (/^[1-8]$/.test(e.key)) setI(Number(e.key) - 1);
      else if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, go]);

  return (
    <WSection
      id="grimoire"
      icon="arcane_grimoire"
      kicker="Illustrated Manual"
      title={<>纂刻秘典 · <span className="shimmer-text">游戏内图解手册</span></>}
      intro={
        <>
          新增的双页图鉴物品。左右页对照、右缘书签、底部页码，支持 <kbd className="font-code text-parch">←/→</kbd>、
          <kbd className="font-code text-parch">A/D</kbd>、<kbd className="font-code text-parch">1–8</kbd> 与 <kbd className="font-code text-parch">Esc</kbd>。
          右页的示意图是原生 Java 绘制的，不是图片。下面是可以翻的网页版。
        </>
      }
      tone="#e8c37c"
    >
      <div className="grid lg:grid-cols-[1fr_320px] gap-6">
        <Panel tone="#e8c37c" className="!p-4">
          {/* closed book */}
          <AnimatePresence mode="wait">
            {!open ? (
              <motion.button
                key="cover"
                onClick={() => setOpen(true)}
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.96 }}
                className="relative w-full max-w-[380px] mx-auto block group"
                style={{ perspective: 900 }}
              >
                <motion.div
                  whileHover={{ rotateY: -14, rotateX: 4 }}
                  transition={{ type: "spring", stiffness: 140, damping: 14 }}
                  className="relative aspect-[3/4] rounded-r-md overflow-hidden"
                  style={{
                    transformStyle: "preserve-3d",
                    background: "linear-gradient(135deg,#5b2b8a,#31164e 60%,#241038)",
                    boxShadow: "0 24px 60px rgba(0,0,0,0.6), inset 0 0 0 2px rgba(232,195,124,0.5)",
                  }}
                >
                  <div className="absolute left-0 top-0 bottom-0 w-3 bg-black/40" />
                  <div className="absolute inset-5 border border-gild/50" />
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-4">
                    <Sprite id="arcane_grimoire" size={74} />
                    <p className="font-display font-black text-2xl text-gild tracking-[0.2em] text-glow-gild">纂刻秘典</p>
                    <p className="font-pixel text-[8.5px] tracking-[0.3em] text-gild/70">ILLUSTRATED MANUAL</p>
                    <div className="mt-4 w-24 h-px bg-gild/40" />
                    <p className="font-vt text-[15px] text-[#efe0bb]/70">8 章 · 全彩图解</p>
                  </div>
                  <span className="absolute bottom-3 left-0 right-0 text-center font-pixel text-[8px] tracking-widest text-gild/50">点击翻开</span>
                </motion.div>
              </motion.button>
            ) : (
              <motion.div key="spread" initial={{ opacity: 0, rotateY: 18 }} animate={{ opacity: 1, rotateY: 0 }} className="relative">
                <div
                  className="relative rounded-sm overflow-hidden"
                  style={{
                    background: "linear-gradient(180deg,#f7efd9,#eadfc2)",
                    boxShadow: "0 22px 60px rgba(0,0,0,0.55), inset 0 0 40px rgba(160,120,60,0.25)",
                  }}
                >
                  <div className="absolute inset-y-0 left-1/2 w-[2px] bg-gradient-to-b from-[#c3ac82] via-[#9a855f] to-[#c3ac82] shadow-[0_0_14px_rgba(0,0,0,0.25)]" />
                  <div className="grid md:grid-cols-2">
                    {/* left page */}
                    <div className="p-5 md:p-6 min-h-[340px] flex flex-col">
                      <p className="font-pixel text-[8.5px] tracking-[0.25em] text-[#9a7b3a] mb-1">CHAPTER {String(i + 1).padStart(2, "0")}</p>
                      <h4 className="font-display font-black text-xl text-[#3d2a12] leading-snug">{ch.title}</h4>
                      <div className="h-px bg-[#c3ac82] my-3" />
                      <p className="text-[13px] leading-7 text-[#5a4326] font-light">{ch.prose}</p>
                      <ul className="mt-4 space-y-1.5">
                        {ch.bullets.map((b) => (
                          <li key={b} className="flex gap-2 text-[12px] leading-5 text-[#6a4f2c]">
                            <span className="text-[#b58a2a] mt-[1px]">◆</span>
                            {b}
                          </li>
                        ))}
                      </ul>
                      <div className="mt-auto pt-4 flex items-center justify-between">
                        <button onClick={() => go(-1)} disabled={i === 0} className="font-vt text-[15px] text-[#8a6a3a] disabled:opacity-30 hover:text-[#3d2a12]">◀ 上一章</button>
                        <span className="font-vt text-[15px] text-[#8a6a3a]">{i + 1} / {CHAPTERS.length}</span>
                        <button onClick={() => go(1)} disabled={i === CHAPTERS.length - 1} className="font-vt text-[15px] text-[#8a6a3a] disabled:opacity-30 hover:text-[#3d2a12]">下一章 ▶</button>
                      </div>
                    </div>
                    {/* right page */}
                    <div className="p-5 md:p-6 md:pr-9 min-h-[340px] flex flex-col bg-[#f5ecd6]/60">
                      <p className="font-pixel text-[8.5px] tracking-[0.25em] text-[#9a7b3a] mb-3">图示 · {ch.short}</p>
                      <div className="flex-1 flex items-center justify-center">
                        <div className="w-full max-w-[260px]">
                          <Diagram chapter={i + 1} />
                        </div>
                      </div>
                      <p className="mt-3 text-center font-vt text-[13px] text-[#9a7b3a]">示意数据取自当前书库设置</p>
                    </div>
                  </div>
                  {/* bookmarks */}
                  <div className="absolute right-0 top-8 flex flex-col gap-1">
                    <button onClick={() => setI(0)} className="px-1.5 py-1 font-vt text-[13px] text-[#f5ecd6]" style={{ background: i === 0 ? "#b58a2a" : "#8a6a3a" }}>⌂</button>
                    {CHAPTERS.map((c, k) => (
                      <button
                        key={c.key}
                        onClick={() => setI(k)}
                        title={c.title}
                        className="px-1.5 py-0.5 font-vt text-[12px] text-[#f5ecd6] transition-all"
                        style={{ background: i === k ? "#b58a2a" : "#8a6a3a", transform: i === k ? "translateX(-4px)" : "none" }}
                      >
                        {String(k + 1).padStart(2, "0")}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex justify-between items-center mt-3">
                  <button onClick={() => setOpen(false)} className="font-vt text-[16px] text-gild hover:text-parch">合上手册</button>
                  <span className="font-pixel text-[8px] tracking-widest text-faint">← → 翻页 · 1–8 跳章 · ESC 合上</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </Panel>

        <div className="space-y-4">
          <Panel tone="#a18cff">
            <p className="font-pixel text-[9px] tracking-[0.22em] text-arcane mb-3">两种无序配方</p>
            {[
              ["writable_book", "chiseled_bookshelf"],
              ["depleted_tome", "ink_sac"],
            ].map(([a, b], k) => (
              <div key={k} className="flex items-center gap-2 mb-2 rounded-sm bg-obsidian/60 border border-arcane/12 p-2">
                <Slot id={a} size={32} />
                <span className="text-faint text-sm">+</span>
                <Slot id={b} size={32} />
                <span className="text-faint text-sm">→</span>
                <Slot id="arcane_grimoire" size={32} highlight="#e8c37c" />
              </div>
            ))}
            <p className="text-[11.5px] text-faint leading-5 mt-2">做出来自动解锁配方书；放进雕纹书架也行（#bookshelf_books）。</p>
          </Panel>
          <Panel tone="#f08cc8">
            <p className="font-pixel text-[9px] tracking-[0.22em] text-inkd mb-2">打开方式</p>
            <div className="space-y-2 text-[12px] leading-5.5 text-mute">
              <p className="flex gap-2"><Sprite id="arcane_grimoire" size={18} />手持右键，直接翻开。</p>
              <p className="flex gap-2"><Sprite id="chiseled_enchanting_table" size={18} />附魔台界面顶部也有一个手册按钮。</p>
            </div>
            <div className="mt-3 rounded-sm border border-[#ff5555]/35 bg-[#ff5555]/8 p-2.5">
              <p className="font-code text-[10px] tracking-wider text-[#ff8888] mb-1">已知问题 · 由本轮审计记录</p>
              <p className="text-[11px] leading-5 text-mute">
                从附魔台界面点按钮打开手册，会关闭当前容器（两槽物品退回背包），合上后回到的是一个已失效的台界面。
                建议先用手持右键打开。
              </p>
            </div>
          </Panel>
        </div>
      </div>
    </WSection>
  );
};

export default Grimoire;
