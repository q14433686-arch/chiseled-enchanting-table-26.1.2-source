import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ENCHANTS, ENCH, roman, canEnchant, type Target } from "../data";
import { Sprite } from "../pixel";
import { essenceOf, stepRefund, stripXp, stripGrit, fullRitual, totalMastery, effectiveDiscount, baseDiscount, pointsForLevels } from "../mechanics";
import { useLib, WSection, Panel, PanelTitle, Slot, XpBadge, Pill, McTip } from "../kit";

type Item = { kind: "diamond_sword" | "book"; ench: Record<string, number> };

const START: Item = { kind: "diamond_sword", ench: { sharpness: 5, looting: 3, unbreaking: 3, mending: 1, vanishing_curse: 1 } };

interface Burst { id: number; n: number }

const OrbBurst = ({ n }: { n: number }) => (
  <>
    {Array.from({ length: Math.min(14, Math.max(3, Math.round(n / 8))) }).map((_, i) => {
      const ang = (Math.PI * 2 * i) / 14 + Math.random();
      const r = 50 + Math.random() * 60;
      return (
        <motion.span
          key={i}
          className="absolute left-1/2 top-1/2 pointer-events-none"
          initial={{ x: 0, y: 0, opacity: 1, scale: 0.6 }}
          animate={{ x: [0, Math.cos(ang) * r, 160], y: [0, Math.sin(ang) * r - 30, -110], opacity: [1, 1, 0], scale: [0.6, 1.1, 0.5] }}
          transition={{ duration: 1.3, ease: "easeOut", delay: i * 0.025 }}
        >
          <Sprite id="experience_orb" size={18} />
        </motion.span>
      );
    })}
  </>
);

const Cleanse = () => {
  const { W, tomes } = useLib();
  const [item, setItem] = useState<Item>(START);
  const [ledger, setLedger] = useState({ gained: 0, spentLv: 0, grit: 0, tear: 0 });
  const [bursts, setBursts] = useState<Burst[]>([]);
  const [log, setLog] = useState<string[]>([]);
  const [depleted, setDepleted] = useState(false);

  const E = totalMastery(tomes);
  const target: Target = item.kind === "book" ? "book" : "sword";
  const entries = Object.entries(item.ench).filter(([, l]) => l > 0);
  const nonCurse = entries.filter(([id]) => !ENCH[id].curse);
  const totalRefund = nonCurse.reduce((s, [id, l]) => s + essenceOf(ENCH[id], l), 0);

  const burst = (n: number) => {
    if (n <= 0) return;
    const id = Date.now() + Math.random();
    setBursts((b) => [...b, { id, n }]);
    setTimeout(() => setBursts((b) => b.filter((x) => x.id !== id)), 1500);
  };
  const say = (s: string) => setLog((l) => [s, ...l].slice(0, 6));

  const finalize = (ench: Record<string, number>) => {
    const left = Object.values(ench).filter((v) => v > 0).length;
    if (item.kind === "book" && left === 0) setDepleted(true);
    setItem({ ...item, ench });
  };

  const disenchantAll = () => {
    const keep = Object.fromEntries(entries.filter(([id]) => ENCH[id].curse));
    setLedger((g) => ({ ...g, gained: g.gained + totalRefund }));
    burst(totalRefund);
    say(`全部退魔：返还 ${totalRefund} 点经验${item.kind === "book" && Object.keys(keep).length === 0 ? "，书化为褪魔残卷" : ""}`);
    finalize(keep);
  };

  const downgrade = (id: string) => {
    const e = ENCH[id];
    const cur = item.ench[id];
    const r = stepRefund(e, cur, cur - 1);
    setLedger((g) => ({ ...g, gained: g.gained + r }));
    burst(r);
    say(`降级：${e.name} ${roman(cur)} → ${cur - 1 ? roman(cur - 1) : "移除"}，返还 ${r} 点`);
    finalize({ ...item.ench, [id]: cur - 1 });
  };

  const strip = (id: string) => {
    const e = ENCH[id];
    const L = item.ench[id];
    if (nonCurse.length <= 1) {
      const r = essenceOf(e, L);
      setLedger((g) => ({ ...g, gained: g.gained + r }));
      burst(r);
      say(`唯一词条：单洗自动转为免费全部退魔，返还 ${r} 点`);
    } else {
      const x = stripXp(e, L, effectiveDiscount(W, E, tomes[id] ?? 0, e.max));
      const g = stripGrit(e, L);
      setLedger((s) => ({ ...s, spentLv: s.spentLv + x.d, grit: s.grit + g }));
      say(`单洗：抹除 ${e.name} ${roman(L)}，消耗 ${g} 退魔砂 + ${x.d} 级`);
    }
    finalize({ ...item.ench, [id]: 0 });
  };

  const purge = (id: string) => {
    const x = fullRitual(12, baseDiscount(W, E));
    setLedger((s) => ({ ...s, spentLv: s.spentLv + x.d, grit: s.grit + 3, tear: s.tear + 1 }));
    say(`破除诅咒：${ENCH[id].name}，消耗 3 退魔砂 + 1 恶魂之泪 + ${x.d} 级`);
    finalize({ ...item.ench, [id]: 0 });
  };

  const reset = (kind: Item["kind"]) => {
    setItem(kind === "book" ? { kind, ench: { protection: 4, feather_falling: 4, binding_curse: 1 } } : START);
    setLedger({ gained: 0, spentLv: 0, grit: 0, tear: 0 });
    setLog([]);
    setDepleted(false);
  };

  const addable = ENCHANTS.filter((e) => !item.ench[e.id] && (item.kind === "book" || canEnchant(e, target)));

  return (
    <WSection
      id="cleanse"
      icon="cleansing_grit"
      kicker="Disenchant Sandbox"
      title="退魔页 · 降级、单洗与破咒"
      bg="/images/wiki-cleanse.jpg"
      tone="#f08cc8"
      intro={
        <>
          磨浅刻痕会把经验还给你，精准剔除一条词条则需要退魔砂与经验，整件磨平免费且退还全部「铭刻势能」。
          返还量 V(e,L) 由<span className="text-parch">归纳封顶</span>构造：每一级都严格低于母本路线的最低实付（再留 5 点裕度），
          因此任何「铭刻 → 退魔」循环都不可能净赚经验——这一点已被 JUnit 在 M = 1..255 全量验证。
        </>
      }
    >
      <div className="grid xl:grid-cols-[1fr_340px] gap-6">
        <Panel tone="#f08cc8">
          <div className="flex flex-wrap items-center gap-2 mb-5">
            <PanelTitle tone="#f08cc8" icon="cleansing_grit">沙盒</PanelTitle>
            <span className="ml-auto" />
            <Pill on={item.kind === "diamond_sword"} onClick={() => reset("diamond_sword")} tone="#7ee8dc"><Sprite id="diamond_sword" size={14} />钻石剑</Pill>
            <Pill on={item.kind === "book"} onClick={() => reset("book")} tone="#a18cff"><Sprite id="enchanted_book" size={14} />附魔书</Pill>
          </div>

          <div className="flex flex-col md:flex-row gap-6">
            <div className="relative flex flex-col items-center gap-3 md:w-40 shrink-0">
              <motion.div key={depleted ? "d" : item.kind} initial={{ scale: 0.7, rotate: -8 }} animate={{ scale: 1, rotate: 0 }}>
                <Slot id={depleted ? "depleted_tome" : item.kind === "book" && entries.length ? "enchanted_book" : item.kind} glint={!depleted && entries.length > 0} size={88} />
              </motion.div>
              <div className="absolute left-1/2 top-11">
                <AnimatePresence>{bursts.map((b) => <OrbBurst key={b.id} n={b.n} />)}</AnimatePresence>
              </div>
              <button
                disabled={nonCurse.length === 0}
                onClick={disenchantAll}
                className="w-full py-2.5 pixelframe border text-sm transition-colors disabled:opacity-30"
                style={{ background: "rgba(141,240,164,0.1)", borderColor: "rgba(141,240,164,0.4)", color: "#8df0a4" }}
              >
                全部退魔
                <span className="block font-vt text-[17px]">+{totalRefund} 点</span>
              </button>
            </div>

            <div className="flex-1 space-y-2">
              <AnimatePresence initial={false}>
                {entries.map(([id, L]) => {
                  const e = ENCH[id];
                  const d = effectiveDiscount(W, E, tomes[id] ?? 0, e.max);
                  const sx = stripXp(e, L, d);
                  const g = stripGrit(e, L);
                  return (
                    <motion.div
                      key={id}
                      layout
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 30, filter: "blur(4px)" }}
                      className="rounded-sm border px-3 py-2.5 flex flex-wrap items-center gap-2"
                      style={{ background: e.curse ? "rgba(192,57,43,0.08)" : "rgba(10,9,19,0.6)", borderColor: e.curse ? "rgba(255,85,85,0.35)" : "rgba(161,140,255,0.15)" }}
                    >
                      <span className={`font-vt text-[20px] ${e.curse ? "text-[#ff5555]" : "text-[#aaaaaa]"} mr-auto`}>
                        {e.name} {e.max > 1 ? roman(L) : ""}
                      </span>
                      {e.curse ? (
                        <McTip tip={<><div className="mc-title">破除诅咒</div><div className="mc-gray">3 退魔砂 + 1 恶魂之泪 / 2 退魔砂 + 1 金苹果</div><div className="mc-gray">或 1 秘法凝晶 · 2 恶魂之泪 + 2 金苹果</div><div className="mc-purple">完整消耗 12 级（受公共减免）</div></>}>
                          <button onClick={() => purge(id)} className="px-2.5 py-1 rounded-sm text-[12px] border border-[#ff5555]/50 text-[#ff8888] hover:bg-[#ff5555]/10">
                            破除诅咒 · <span className="font-vt text-[15px]">-{fullRitual(12, baseDiscount(W, E)).d}L</span>
                          </button>
                        </McTip>
                      ) : (
                        <>
                          <button onClick={() => downgrade(id)} className="px-2.5 py-1 rounded-sm text-[12px] border border-xp/40 text-xp hover:bg-xp/10">
                            降级 · <span className="font-vt text-[15px]">+{stepRefund(e, L, L - 1)}</span>
                          </button>
                          <McTip
                            tip={
                              nonCurse.length <= 1 ? (
                                <><div className="mc-title">唯一词条</div><div className="mc-green">自动转为免费全部退魔</div></>
                              ) : (
                                <><div className="mc-title">定向单洗</div><div className="mc-gray">{g} 退魔砂 + 青金石 / 发光墨囊 / 紫水晶</div><div className="mc-gray">或纯原版：紫水晶 + 青金石 · 1 秘法凝晶</div><div className="mc-green">门槛 Lv.{sx.req} · 扣 {sx.d} 级</div></>
                              )
                            }
                          >
                            <button onClick={() => strip(id)} className="px-2.5 py-1 rounded-sm text-[12px] border border-inkd/40 text-inkd hover:bg-inkd/10 inline-flex items-center gap-1">
                              单洗 · {nonCurse.length <= 1 ? <span className="font-vt text-[15px]">+{essenceOf(e, L)}</span> : <><Sprite id="cleansing_grit" size={13} /><span className="font-vt text-[15px]">{g}</span><XpBadge x={sx} compact /></>}
                            </button>
                          </McTip>
                        </>
                      )}
                    </motion.div>
                  );
                })}
              </AnimatePresence>
              {entries.length === 0 && <p className="text-[13px] text-faint py-6 text-center">{depleted ? "书已化为褪魔残卷——去「空白覆写」把它还原吧。" : "已无附魔。"}</p>}
              {!depleted && addable.length > 0 && (
                <select
                  value=""
                  onChange={(ev) => {
                    const e = ENCH[ev.target.value];
                    if (e) setItem({ ...item, ench: { ...item.ench, [e.id]: e.max } });
                  }}
                  className="w-full bg-obsidian/70 border border-dashed border-arcane/25 rounded-sm px-3 py-2 text-[12.5px] text-mute"
                >
                  <option value="">＋ 添加附魔（满级）…</option>
                  {addable.map((e) => (
                    <option key={e.id} value={e.id}>{e.name}{e.curse ? "（诅咒）" : ""}</option>
                  ))}
                </select>
              )}
            </div>
          </div>
        </Panel>

        <div className="space-y-4">
          <Panel tone="#8df0a4">
            <PanelTitle tone="#8df0a4" icon="experience_orb">收支账本</PanelTitle>
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-sm bg-obsidian/60 border border-arcane/10 p-3">
                <p className="text-[11px] text-faint">经验返还</p>
                <motion.p key={ledger.gained} initial={{ scale: 1.3 }} animate={{ scale: 1 }} className="font-vt text-[28px] text-[#55ffff] leading-none mt-1">+{ledger.gained}</motion.p>
              </div>
              <div className="rounded-sm bg-obsidian/60 border border-arcane/10 p-3">
                <p className="text-[11px] text-faint">等级支出</p>
                <p className="font-vt text-[28px] text-[#ff55ff] leading-none mt-1">-{ledger.spentLv}L</p>
              </div>
            </div>
            <div className="flex gap-3 mt-3">
              <Slot id="cleansing_grit" count={ledger.grit || undefined} size={38} />
              <Slot id="ghast_tear" count={ledger.tear || undefined} size={38} />
              <span className="text-[11px] text-faint self-center leading-4">已消耗材料<br />（30 级约 {pointsForLevels(30, ledger.spentLv)} 点）</span>
            </div>
            <button onClick={() => reset(item.kind)} className="mt-4 w-full py-2 rounded-sm border border-arcane/20 text-[12px] text-mute hover:text-parch">重置沙盒</button>
          </Panel>
          <Panel>
            <PanelTitle tone="#9c93bd">操作日志</PanelTitle>
            <div className="space-y-1.5 min-h-[120px]">
              <AnimatePresence initial={false}>
                {log.map((l, i) => (
                  <motion.p key={l + i + log.length} initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1 - i * 0.13, y: 0 }} className="font-vt text-[16px] text-mute leading-5">
                    › {l}
                  </motion.p>
                ))}
              </AnimatePresence>
              {log.length === 0 && <p className="text-[12px] text-faint">点击左侧任意操作……</p>}
            </div>
          </Panel>
        </div>
      </div>
    </WSection>
  );
};

export default Cleanse;
