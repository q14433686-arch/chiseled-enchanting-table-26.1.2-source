import { useCallback, useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ENCH, TREASURE_COSTS, EPIPHANY, ITEM_NAME, canEnchant, roman } from "../data";
import { Sprite } from "../pixel";
import { totalMastery, affinityMastery, epiphanyProb, epiphanySlots, epiphanyScore, specificBonus, fullRitual } from "../mechanics";
import { useLib, WSection, Panel, PanelTitle, Slot, McTip, XpBadge } from "../kit";

const SPEED = 30; // 演示加速倍率

const Gauge = ({ p, locked }: { p: number; locked: boolean }) => {
  const R = 74;
  const C = Math.PI * R;
  return (
    <svg viewBox="0 0 180 104" className="w-full max-w-[260px] mx-auto">
      <defs>
        <linearGradient id="gg" x1="0" x2="1">
          <stop offset="0" stopColor="#a18cff" />
          <stop offset="1" stopColor="#e8c37c" />
        </linearGradient>
      </defs>
      <path d={`M16 92 A${R} ${R} 0 0 1 164 92`} fill="none" stroke="#1d1738" strokeWidth="14" strokeLinecap="round" />
      <motion.path
        d={`M16 92 A${R} ${R} 0 0 1 164 92`}
        fill="none"
        stroke={locked ? "#3a3060" : "url(#gg)"}
        strokeWidth="14"
        strokeLinecap="round"
        strokeDasharray={C}
        animate={{ strokeDashoffset: C * (1 - p) }}
        transition={{ type: "spring", stiffness: 60, damping: 16 }}
      />
      <path d={`M16 92 A${R} ${R} 0 0 1 164 92`} fill="none" stroke="#fff3" strokeWidth="1" strokeDasharray="2 6" />
      <text x="90" y="80" textAnchor="middle" fontFamily="VT323" fontSize="38" fill={locked ? "#6f659a" : "#ede6d4"}>
        {locked ? "LOCKED" : `${Math.round(p * 100)}%`}
      </text>
      <text x="90" y="98" textAnchor="middle" fontFamily="VT323" fontSize="13" fill="#9c93bd">
        触发概率 · 上限 90%
      </text>
    </svg>
  );
};

const fmtTime = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;

const Console = () => {
  const { W, tomes, target } = useLib();
  const E = totalMastery(tomes);
  const A = affinityMastery(tomes, target);
  const unlocked = W >= EPIPHANY.minShelves;
  const p = epiphanyProb(W, E, A);
  const slots = epiphanySlots(W, E, A);
  const score = epiphanyScore(W, E, A);

  const cycle = EPIPHANY.cycleTicks / 20;
  const [left, setLeft] = useState(cycle);
  const [freeze, setFreeze] = useState(0);
  const [seed, setSeed] = useState(1);

  const pool = useMemo(
    () => TREASURE_COSTS.filter((t) => target === "book" || canEnchant(ENCH[t.id], target)).filter((t) => (tomes[t.id] ?? 0) < ENCH[t.id].max),
    [target, tomes],
  );

  const rolled = useMemo(() => {
    if (!unlocked || pool.length === 0) return [];
    let s = seed * 9301 + 49297;
    const rnd = () => ((s = (s * 9301 + 49297) % 233280) / 233280);
    if (rnd() > p) return [];
    const k = Math.max(1, Math.min(slots, 1 + Math.floor(rnd() * slots)));
    const shuffled = [...pool].sort(() => rnd() - 0.5);
    return shuffled.slice(0, k).map((t) => {
      const e = ENCH[t.id];
      const cur = tomes[t.id] ?? 0;
      return { ...t, lvl: Math.min(e.max, Math.max(1, cur + 1)) };
    });
  }, [seed, unlocked, pool, p, slots, tomes]);

  const reroll = useCallback(() => {
    setSeed((v) => v + 1);
    setLeft(cycle);
  }, [cycle]);

  useEffect(() => {
    const t = setInterval(() => {
      if (freeze > 0) {
        setFreeze((f) => Math.max(0, f - SPEED));
        return;
      }
      setLeft((l) => {
        if (l - SPEED <= 0) {
          setSeed((v) => v + 1);
          return cycle;
        }
        return l - SPEED;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [freeze, cycle]);

  const maxFreeze = EPIPHANY.maxFreezeTicks / 20;
  const locked = freeze > 0;

  return (
    <div className="grid lg:grid-cols-[300px_1fr] gap-6">
      <Panel tone="#e8c37c">
        <PanelTitle tone="#e8c37c" icon="experience_orb">共鸣强度</PanelTitle>
        {unlocked ? (
          <>
            <Gauge p={p} locked={false} />
            <div className="flex justify-center gap-2 mt-2">
              {Array.from({ length: EPIPHANY.maxSlots }).map((_, i) => (
                <motion.span
                  key={i}
                  animate={{ scale: i < slots ? [1, 1.2, 1] : 1, opacity: i < slots ? 1 : 0.25 }}
                  transition={{ duration: 1.6, repeat: i < slots ? Infinity : 0, delay: i * 0.2 }}
                  className="font-vt text-[30px] text-gild"
                >
                  ✦
                </motion.span>
              ))}
            </div>
            <p className="text-center text-[11.5px] text-faint mt-1">单件最多同时 {slots} 条 · 共鸣分 {score.toFixed(1)}（每 12 分 +1）</p>
            <div className="mt-4 space-y-1 text-[11.5px] text-mute">
              <p>基础 28% + 每多 1 架 0.8%</p>
              <p>+ (0.45×公共母本 + 0.85×同系母本) × 2.2%</p>
              <p className="text-faint">同系 = 能附在当前目标上的母本</p>
            </div>
          </>
        ) : (
          <div className="text-center py-8">
            <Sprite id="bookshelf" size={48} />
            <p className="font-vt text-[26px] text-faint mt-3">尚未唤醒</p>
            <p className="text-[12.5px] text-mute mt-1">普通书架 {W} / 32 · 去书库模拟器加书架</p>
          </div>
        )}
      </Panel>

      <Panel tone="#a18cff" className="relative overflow-hidden">
        <div className="flex flex-wrap items-center gap-3 mb-5">
          <PanelTitle tone="#a18cff" icon="enchanted_book">顿悟控制台（演示 ×{SPEED} 速）</PanelTitle>
          <div className="ml-auto flex items-center gap-2">
            <span className="font-vt text-[26px] leading-none" style={{ color: locked ? "#74a8f6" : "#ede6d4" }}>
              {locked ? `❄ ${fmtTime(freeze)}` : fmtTime(left)}
            </span>
            <McTip tip={<><div className="mc-title">锁定顿悟</div><div className="mc-gray">每次 +20 分钟，上限 60 分钟</div><div className="mc-gray">16 浮冰 / 4 蓝冰 / 16 青金石 / 14 绿宝石 / 6 紫水晶 / 2 哭泣的黑曜石</div><div className="mc-green">扣 1 级 · 挖下重放仍保留</div></>}>
              <button
                disabled={!unlocked}
                onClick={() => setFreeze((f) => Math.min(maxFreeze, f + EPIPHANY.freezeTicks / 20))}
                className="w-10 h-10 mc-slot inline-flex items-center justify-center disabled:opacity-30"
              >
                <Sprite id="blue_ice" size={26} />
              </button>
            </McTip>
            <McTip tip={<><div className="mc-title">重刷顿悟</div><div className="mc-gray">10 青金石 / 8 绿宝石 / 3 紫水晶</div><div className="mc-green">扣 2 级</div></>}>
              <button disabled={!unlocked || locked} onClick={reroll} className="w-10 h-10 mc-slot inline-flex items-center justify-center disabled:opacity-30">
                <Sprite id="amethyst_shard" size={26} />
              </button>
            </McTip>
          </div>
        </div>

        {locked && <div className="absolute inset-0 pointer-events-none" style={{ background: "linear-gradient(180deg, rgba(116,168,246,0.10), transparent 40%)", boxShadow: "inset 0 0 40px rgba(116,168,246,0.25)" }} />}

        <div className="min-h-[190px]">
          <AnimatePresence mode="popLayout">
            {!unlocked ? (
              <motion.p key="lock" className="text-[13px] text-faint text-center py-14">需要 32 个普通书架</motion.p>
            ) : rolled.length === 0 ? (
              <motion.div key={`none-${seed}`} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="text-center py-12">
                <p className="font-vt text-[24px] text-faint">本轮没有灵光</p>
                <p className="text-[12px] text-mute mt-1">{pool.length === 0 ? "当前目标没有可顿悟的宝藏魔咒（或母本已满级）" : "等待轮转，或使用重刷"}</p>
              </motion.div>
            ) : (
              <div key={`r-${seed}`} className="grid sm:grid-cols-2 gap-3">
                {rolled.map((t, i) => {
                  const e = ENCH[t.id];
                  const owned = (tomes[t.id] ?? 0) > 0;
                  const x = fullRitual(t.xp, specificBonus(tomes[t.id] ?? 0, e.max));
                  return (
                    <motion.div
                      key={t.id}
                      initial={{ opacity: 0, y: 20, rotateX: -40 }}
                      animate={{ opacity: 1, y: 0, rotateX: 0 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ delay: i * 0.12, type: "spring", stiffness: 160 }}
                      className="rounded-sm border p-3 flex items-center gap-3"
                      style={{ background: "linear-gradient(135deg, rgba(232,195,124,0.12), rgba(161,140,255,0.08))", borderColor: "rgba(232,195,124,0.4)" }}
                    >
                      <Slot id="enchanted_book" size={48} />
                      <div className="flex-1 min-w-0">
                        <p className="font-vt text-[21px] text-[#ffff55] leading-none">{e.name} {e.max > 1 ? roman(t.lvl) : ""}</p>
                        <div className="flex items-center gap-1.5 mt-2">
                          {owned ? (
                            <span className="text-[11px] text-xp">已有母本 · 免双材料</span>
                          ) : (
                            <>
                              <Slot id={t.a[0]} count={t.a[1]} size={28} />
                              <Slot id={t.b[0]} count={t.b[1]} size={28} />
                            </>
                          )}
                          <span className="ml-auto"><XpBadge x={x} compact /></span>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </AnimatePresence>
        </div>
        <p className="text-[11px] text-faint mt-4">轮转时若未锁定会刷新词条；完成一次附魔也会推进轮转。多级宝藏（如迅捷潜行）未满级时可继续顿悟更高阶。</p>
      </Panel>
    </div>
  );
};

const Pool = () => (
  <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 mt-8">
    {TREASURE_COSTS.map((t, i) => {
      const e = ENCH[t.id];
      return (
        <motion.div
          key={t.id}
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.04 }}
          whileHover={{ y: -4, borderColor: "rgba(232,195,124,0.55)" }}
          className="rounded-sm bg-obsidian/70 border border-arcane/15 p-3 flex items-center gap-3"
        >
          <McTip
            tip={
              <>
                <div className="mc-yellow">附魔书</div>
                <div className="mc-gray">{e.name}{e.max > 1 ? ` I~${roman(e.max)}` : ""}</div>
                <div className="mc-gold">{e.treasure ? "#minecraft:treasure" : "#epiphany_exclusive"}</div>
              </>
            }
          >
            <Sprite id="enchanted_book" size={36} />
          </McTip>
          <div className="flex-1 min-w-0">
            <p className="text-[13px] text-parch truncate">{e.name}</p>
            <p className="text-[10.5px] text-faint truncate">
              {ITEM_NAME[t.a[0]]}×{t.a[1]} + {ITEM_NAME[t.b[0]]}×{t.b[1]}
            </p>
          </div>
          <span className="font-vt text-[19px] text-[#ff55ff]">{t.xp}L</span>
        </motion.div>
      );
    })}
  </div>
);

const Epiphany = () => (
  <WSection
    id="epiphany"
    icon="enchanted_book"
    kicker="Treasure Epiphany"
    title={<>宝藏顿悟 · <span className="shimmer-text">万卷圣堂</span></>}
    bg="/images/wiki-epiphany.jpg"
    tone="#e8c37c"
    intro="周围普通书架达到 32 架时唤醒。经验修补、无限、迅捷潜行、风爆等宝藏与顿悟专属魔咒不会出现在默认列表中——它们只能来自雕纹书架母本，或在这里「灵光一现」。顿悟铭刻需要专属双材料（或 1 枚秘法凝晶）；母本已入架的宝藏魔咒则只需普通单材料。"
  >
    <Console />
    <Pool />
  </WSection>
);

export default Epiphany;
