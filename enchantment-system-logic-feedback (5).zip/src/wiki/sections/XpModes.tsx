import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ENCHANTS, ENCH, roman } from "../data";
import { Sprite } from "../pixel";
import { totalMastery, effectiveDiscount, resolveEnchantXp, minPoints, totalXp, type RowKind } from "../mechanics";
import { useLib, WSection, Panel, PanelTitle, Range, Pill, XpBadge, Stat } from "../kit";

const MODES = [
  {
    key: "vanilla",
    title: "原版量产模式",
    icon: "experience_orb",
    tone: "#8df0a4",
    badge: "1 / 2 / 3 颗绿色经验球 + Lv.X",
    when: ["雕纹书架母本已覆盖的附魔", "全部物品置换"],
    rule: "只校验门槛 Lv.X（8 + 22·L/M，最高 30，享受最高 −40% 减免），点击后只扣 1 / 2 / 3 级，保留经验条进度。",
  },
  {
    key: "full",
    title: "完整消耗模式",
    icon: "experience_bottle",
    tone: "#f08cc8",
    badge: "紫色药水瓶 + −XL",
    when: ["未放入雕纹书架的默认附魔", "无母本的升阶 / 合并 / 研究", "宝藏顿悟铭刻、破除诅咒"],
    rule: "按基础价扣除完整等级，且永不低于同等级母本路线的门槛与扣除——确保「洗了重刻」永远不比升阶划算。",
  },
  {
    key: "free",
    title: "附魔书直接转移",
    icon: "enchanted_book",
    tone: "#7ee8dc",
    badge: "绿色 0L",
    when: ["下槽放一本附魔书，上槽放装备或书"],
    rule: "0 经验，但消耗下槽那本附魔书并留下褪魔残卷。",
  },
];

const XpBar = ({ level, after, d }: { level: number; after: number; d: number }) => (
  <div>
    <div className="relative h-4 bg-[#1a1a1a] border-2 border-black" style={{ imageRendering: "pixelated" }}>
      <motion.div className="absolute inset-y-0 left-0 bg-[#80ff20]" animate={{ width: "62%" }} />
      <div className="absolute inset-0 flex">
        {Array.from({ length: 18 }).map((_, i) => (
          <span key={i} className="flex-1 border-r border-black/50" />
        ))}
      </div>
    </div>
    <div className="flex justify-center items-center gap-3 mt-1">
      <span className="font-vt text-[30px] text-[#80ff20]" style={{ textShadow: "2px 2px 0 #000" }}>{level}</span>
      {d > 0 && (
        <>
          <span className="font-vt text-[22px] text-mute">→</span>
          <motion.span key={after} initial={{ scale: 1.5, color: "#ff5555" }} animate={{ scale: 1, color: "#80ff20" }} className="font-vt text-[30px]" style={{ textShadow: "2px 2px 0 #000" }}>
            {after}
          </motion.span>
        </>
      )}
    </div>
  </div>
);

const Calculator = () => {
  const { W, tomes } = useLib();
  const [id, setId] = useState("sharpness");
  const e = ENCH[id];
  const [kind, setKind] = useState<RowKind>("enchant");
  const [target, setTarget] = useState(e.max);
  const [existing, setExisting] = useState(0);
  const [storedOverride, setStoredOverride] = useState<number | null>(null);
  const [player, setPlayer] = useState(30);

  useEffect(() => {
    setTarget(e.max);
    setExisting(0);
    setStoredOverride(null);
  }, [id, e.max]);

  const stored = storedOverride ?? tomes[id] ?? 0;
  const E = totalMastery(tomes);
  const disc = effectiveDiscount(W, E, stored, e.max);
  const ex = kind === "enchant" ? Math.min(existing, target - 1) : target - 1;
  const x = resolveEnchantXp(e, target, ex, stored, disc, kind);
  const pts = minPoints(x);

  const chain = useMemo(() => {
    const out = [player];
    let l = player;
    if (x.d <= 0) return out;
    while (l >= x.req && out.length < 12) {
      l -= x.d;
      out.push(l);
    }
    return out;
  }, [player, x.req, x.d]);
  const runs = chain.length - 1;
  const ok = player >= x.req;

  return (
    <Panel tone="#8df0a4">
      <PanelTitle tone="#8df0a4" icon="experience_orb">经验计算器 · 继承书库减免</PanelTitle>
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="space-y-5">
          <div className="flex flex-wrap gap-2 items-center">
            <select value={id} onChange={(ev) => setId(ev.target.value)} className="bg-obsidian border border-arcane/25 rounded-sm px-3 py-2 text-[13px] text-parch">
              {ENCHANTS.filter((q) => !q.curse).map((q) => (
                <option key={q.id} value={q.id}>{q.name}（{roman(q.max)}）</option>
              ))}
            </select>
            {(["enchant", "combine", "research"] as RowKind[]).map((k) => (
              <Pill key={k} on={kind === k} onClick={() => setKind(k)} tone="#e8c37c">
                {k === "enchant" ? "附魔 / 升阶" : k === "combine" ? "附魔书合并" : "附魔书研究"}
              </Pill>
            ))}
          </div>
          <Range label="目标等级" value={target} min={kind === "enchant" ? 1 : 2} max={e.max} onChange={setTarget} fmt={roman} />
          {kind === "enchant" && e.max > 1 && (
            <Range label="物品上已有等级（0 = 白板）" value={Math.min(existing, target - 1)} min={0} max={Math.max(0, target - 1)} onChange={setExisting} fmt={(v) => (v ? roman(v) : "无")} tone="#a18cff" />
          )}
          <Range label="雕纹书架母本等级" value={stored} min={0} max={e.max} onChange={setStoredOverride} fmt={(v) => (v ? roman(v) : "无")} tone="#e8c37c" />
          <Range label="玩家当前等级" value={player} min={0} max={50} onChange={setPlayer} tone="#80ff20" />
        </div>

        <div className="space-y-4">
          <div className="rounded-sm bg-obsidian/70 border p-5" style={{ borderColor: x.vanilla ? "#8df0a455" : "#f08cc855" }}>
            <div className="flex items-center justify-between mb-3">
              <span className="font-display font-bold text-parch">
                {e.name} {roman(target)}
                {ex > 0 && <span className="text-faint text-sm ml-2">（自 {roman(ex)}）</span>}
              </span>
              <XpBadge x={x} />
            </div>
            <p className="text-[12px] leading-6 text-mute">
              {x.vanilla ? "原版量产模式" : "完整消耗模式"} · 门槛 <span className="text-parch">Lv.{x.req}</span>（原始 {x.raw}，减免 −{x.disc}%）· 扣除{" "}
              <span className="text-parch">{x.d}</span> 级 ≈ <span className="text-parch">{pts}</span> 点起
            </p>
          </div>
          <XpBar level={player} after={ok ? player - x.d : player} d={ok ? x.d : 0} />
          <div className="grid grid-cols-2 gap-2">
            <Stat label="能否执行" value={ok ? "可以" : "等级不足"} tone={ok ? "#8df0a4" : "#ff5555"} sub={ok ? "" : `还差 ${x.req - player} 级`} />
            <Stat label="当前等级可连续执行" value={`${runs} 次`} tone="#e8c37c" sub={`总经验 ${totalXp(player)} 点`} />
          </div>
          {runs > 0 && (
            <div className="flex flex-wrap items-center gap-1.5 font-vt text-[19px]">
              {chain.map((l, i) => (
                <motion.span key={i} initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 }} className="flex items-center gap-1.5">
                  <span style={{ color: i === 0 ? "#80ff20" : "#c8ffa0" }}>{l}</span>
                  {i < chain.length - 1 && <span className="text-faint">→</span>}
                </motion.span>
              ))}
            </div>
          )}
        </div>
      </div>
    </Panel>
  );
};

const XpModes = () => (
  <WSection
    id="xp"
    icon="experience_bottle"
    kicker="Dual XP Formula"
    title="经验双模式"
    intro="为兼顾拓荒期的成长感与毕业后的量产体验，列表中并存两套经验规则，并以每行最右侧的徽章区分。母本一旦放进雕纹书架，对应魔咒就自动切换到绿色经验球的量产模式。"
    tone="#8df0a4"
  >
    <div className="grid md:grid-cols-3 gap-4 mb-8">
      {MODES.map((m, i) => (
        <motion.div
          key={m.key}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.08 }}
          className="pixelframe bg-vellum/70 border p-5"
          style={{ borderColor: `${m.tone}33` }}
        >
          <div className="flex items-center gap-3 mb-3">
            <Sprite id={m.icon} size={32} />
            <div>
              <p className="font-display font-bold text-parch">{m.title}</p>
              <p className="font-vt text-[15px]" style={{ color: m.tone }}>{m.badge}</p>
            </div>
          </div>
          <ul className="space-y-1 mb-3">
            {m.when.map((w) => (
              <li key={w} className="text-[12px] text-parch flex gap-2"><span style={{ color: m.tone }}>◆</span>{w}</li>
            ))}
          </ul>
          <p className="text-[12px] leading-6 text-mute font-light">{m.rule}</p>
        </motion.div>
      ))}
    </div>
    <Calculator />
  </WSection>
);

export default XpModes;
