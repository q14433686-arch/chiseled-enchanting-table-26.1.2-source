import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { RECIPES, CUSTOM_ITEMS, ITEM_NAME } from "../data";
import { Sprite } from "../pixel";
import { Slot, WSection, McTip } from "../kit";

const CraftingTable = () => {
  const [idx, setIdx] = useState(0);
  const r = RECIPES[idx];
  return (
    <div className="grid lg:grid-cols-[260px_1fr] gap-6">
      <div className="space-y-2">
        {RECIPES.map((rc, i) => (
          <button
            key={rc.id}
            onClick={() => setIdx(i)}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-sm border text-left transition-all"
            style={{
              background: idx === i ? "rgba(232,195,124,0.08)" : "rgba(10,9,19,0.5)",
              borderColor: idx === i ? "rgba(232,195,124,0.45)" : "rgba(161,140,255,0.1)",
            }}
          >
            <Sprite id={rc.result} size={28} />
            <span className="text-[13px] text-parch leading-5">{rc.name}</span>
          </button>
        ))}
      </div>

      <div className="flex flex-col items-center gap-5">
        <div className="mc-panel p-4 md:p-5">
          <p className="font-vt text-[20px] text-[#404040] mb-3">{r.shaped ? "合成" : "合成（无序）"}</p>
          <div className="flex items-center gap-4 md:gap-6">
            <div className="grid grid-cols-3 gap-0">
              {r.grid.map((cell, i) => (
                <AnimatePresence mode="wait" key={`${r.id}-${i}`}>
                  <motion.div
                    key={`${r.id}-${i}-${cell}`}
                    initial={{ opacity: 0, y: -14, scale: 0.6 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ delay: i * 0.05, type: "spring", stiffness: 380, damping: 18 }}
                  >
                    <Slot id={cell} size={48} />
                  </motion.div>
                </AnimatePresence>
              ))}
            </div>
            <svg width="44" height="32" viewBox="0 0 22 16" className="pixelated shrink-0">
              <polygon points="0,6 12,6 12,2 14,2 14,3 15,3 15,4 16,4 16,5 17,5 17,6 18,6 18,7 19,7 19,9 18,9 18,10 17,10 17,11 16,11 16,12 15,12 15,13 14,13 14,14 12,14 12,10 0,10" fill="#8b8b8b" />
            </svg>
            <motion.div key={r.id} initial={{ scale: 0.4, rotate: -20 }} animate={{ scale: 1, rotate: 0 }} transition={{ delay: 0.5, type: "spring" }}>
              <Slot id={r.result} count={r.count} size={64} highlight="#e8c37c" />
            </motion.div>
          </div>
        </div>
        <AnimatePresence mode="wait">
          <motion.p
            key={r.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="max-w-xl text-center text-[13.5px] leading-7 text-mute font-light"
          >
            {r.note}
            <span className="block mt-2 font-vt text-[16px] text-faint">
              {r.grid.filter(Boolean).reduce<Record<string, number>>((m, c) => ((m[c!] = (m[c!] ?? 0) + 1), m), {}) &&
                Object.entries(
                  r.grid.filter(Boolean).reduce<Record<string, number>>((m, c) => ((m[c!] = (m[c!] ?? 0) + 1), m), {}),
                )
                  .map(([k, v]) => `${ITEM_NAME[k] ?? k}×${v}`)
                  .join(" · ")}
            </span>
          </motion.p>
        </AnimatePresence>
      </div>
    </div>
  );
};

const Compendium = () => (
  <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4 mt-14">
    {CUSTOM_ITEMS.map((it, i) => (
      <motion.div
        key={it.id}
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: i * 0.08, duration: 0.6 }}
        whileHover={{ y: -6 }}
        className="group pixelframe relative bg-vellum/70 border border-arcane/15 p-5 overflow-hidden"
      >
        <div className="absolute -top-10 -right-10 w-36 h-36 rounded-full bg-arcane/10 blur-2xl group-hover:bg-gild/15 transition-colors duration-500" />
        <div className="relative flex items-center gap-4 mb-4">
          <McTip
            tip={
              <>
                <div className="mc-title">{it.name}</div>
                {it.lore.map((l) => (
                  <div key={l} className="mc-gray">
                    {l}
                  </div>
                ))}
                <div className="mc-purple" style={{ fontSize: 14 }}>
                  chiseled_enchanting_table:{it.id}
                </div>
              </>
            }
          >
            <motion.span
              className="mc-slot w-16 h-16 inline-flex items-center justify-center"
              animate={{ y: [0, -4, 0] }}
              transition={{ duration: 3 + i * 0.3, repeat: Infinity, ease: "easeInOut" }}
            >
              <Sprite id={it.id} size={50} />
            </motion.span>
          </McTip>
          <div>
            <p className="font-display font-black text-lg text-parch">{it.name}</p>
            <p className="font-pixel text-[9px] tracking-widest text-faint mt-1">{it.kind}</p>
          </div>
        </div>
        <p className="relative text-[12.5px] leading-6 text-mute font-light">{it.body}</p>
      </motion.div>
    ))}
  </div>
);

const Recipes = () => (
  <WSection
    id="recipes"
    icon="chiseled_enchanting_table"
    kicker="Crafting & Items"
    title="合成配方与物品图鉴"
    intro="五个配方覆盖从入门到后期的全部自定义物品。点击左侧切换配方，悬停任一格查看原版风格提示框。"
    tone="#e8c37c"
  >
    <CraftingTable />
    <Compendium />
  </WSection>
);

export default Recipes;
