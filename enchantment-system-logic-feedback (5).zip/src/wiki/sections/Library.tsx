import { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Block3D, Sprite, TEX } from "../pixel";
import { ENCHANTS, ENCH, TARGETS, roman, enchColor, isDefaultUnlock } from "../data";
import {
  totalMastery,
  affinityMastery,
  woodDiscount,
  globalDiscount,
  specificBonus,
  baseDiscount,
  effectiveDiscount,
  requiredShelves,
  blankCap,
  upgradeCap,
  qualifyingTomes,
  depletedTier,
  epiphanyProb,
  epiphanySlots,
  CFG,
  GATES,
  type Tomes,
} from "../mechanics";
import { useLib, WSection, Panel, PanelTitle, Stat, Range, Pill, McTip } from "../kit";

const S = 30; // block px
const N = 7;

/** 普通书架摆放顺序：外圈 → 由下往上 → 次外圈 */
const SHELF_POS: [number, number, number][] = (() => {
  const out: [number, number, number][] = [];
  for (const ring of [3, 2]) {
    for (let y = 0; y < 3; y++) {
      for (let x = -ring; x <= ring; x++)
        for (let z = -ring; z <= ring; z++) if (Math.max(Math.abs(x), Math.abs(z)) === ring) out.push([x, y, z]);
    }
  }
  return out;
})();

const CHISELED_POS: [number, number, number][] = [
  [-1, 0, -2], [1, 0, -2], [0, 0, -2], [-2, 0, -1], [2, 0, -1], [-2, 0, 1], [2, 0, 1], [-1, 0, 2], [1, 0, 2], [0, 0, 2], [-2, 0, 0], [2, 0, 0],
];

const Scene = ({ W, tomes }: { W: number; tomes: Tomes }) => {
  const rotRef = useRef<HTMLDivElement>(null);
  const ang = useRef(-35);
  const drag = useRef<{ x: number; a: number } | null>(null);

  useEffect(() => {
    let raf = 0;
    const tick = () => {
      if (!drag.current) ang.current += 0.06;
      if (rotRef.current) rotRef.current.style.transform = `rotateX(60deg) rotateZ(${ang.current}deg)`;
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const tomeList = Object.entries(tomes).filter(([, l]) => l > 0);
  const chiseledCount = Math.min(CHISELED_POS.length, Math.ceil(tomeList.length / 6));
  const shelves = SHELF_POS.slice(0, Math.min(W, SHELF_POS.length));

  const shelfTex = useMemo(() => [TEX.bookshelf(41), TEX.bookshelf(77), TEX.bookshelf(113)], []);
  const planks = TEX.planks();
  const tableSide = TEX.tableSide();
  const tableTop = TEX.tableTop();

  /*
   * 地面为 XY 平面、+Z 朝上。方块局部框左上为原点、中心 (S/2,S/2,0)。
   * rotateX(-90°)：局部 y → −Z、局部 z → +Y。
   * 要让中心落到 (S/2, S/2, S/2 + y·S)：局部先平移 (0, −S−y·S, S/2)。
   */
  const place = (x: number, y: number, z: number) =>
    `translate3d(${(x + 3) * S}px, ${(z + 3) * S}px, 0) rotateX(-90deg) translate3d(0, ${-S - y * S}px, ${S / 2}px)`;

  return (
    <div
      className="relative h-[420px] cursor-grab active:cursor-grabbing select-none overflow-hidden rounded-sm"
      style={{ perspective: 1300, background: "radial-gradient(ellipse at 50% 60%, rgba(109,94,240,0.18), transparent 65%)" }}
      onPointerDown={(e) => {
        drag.current = { x: e.clientX, a: ang.current };
        (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
      }}
      onPointerMove={(e) => {
        if (drag.current) ang.current = drag.current.a + (e.clientX - drag.current.x) * 0.4;
      }}
      onPointerUp={() => (drag.current = null)}
      onPointerLeave={() => (drag.current = null)}
    >
      <div className="absolute left-1/2 top-[54%]" style={{ transformStyle: "preserve-3d" }}>
        <div ref={rotRef} style={{ transformStyle: "preserve-3d" }}>
          <div style={{ transformStyle: "preserve-3d", transform: `translate3d(${(-N * S) / 2}px, ${(-N * S) / 2}px, 0)` }}>
            <div
              className="absolute pixelated"
              style={{
                width: N * S,
                height: N * S,
                backgroundImage: `url(${planks})`,
                backgroundSize: `${S}px ${S}px`,
                boxShadow: "0 0 60px rgba(109,94,240,0.35)",
                filter: "brightness(0.7)",
              }}
            />
            {/* table */}
            <div className="absolute" style={{ transformStyle: "preserve-3d", transform: place(0, 0, 0) }}>
              <Block3D size={S} side={tableSide} top={tableTop} bottom={TEX.obsidian()} height={0.75} glow="rgba(161,140,255,0.6)" />
            </div>
            {shelves.map(([x, y, z], i) => (
              <motion.div
                key={`s${x},${y},${z}`}
                className="absolute"
                style={{ transformStyle: "preserve-3d", transform: place(x, y, z) }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                <Block3D size={S} side={shelfTex[i % 3]} top={planks} bottom={planks} />
              </motion.div>
            ))}
            {CHISELED_POS.slice(0, chiseledCount).map(([x, y, z], i) => {
              const group = tomeList.slice(i * 6, i * 6 + 6);
              const filled = [0, 1, 2, 3, 4, 5].map((k) => k < group.length);
              const colors = group.map(([id]) => enchColor(ENCH[id]));
              return (
                <div key={`c${i}`} className="absolute" style={{ transformStyle: "preserve-3d", transform: place(x, y, z) }}>
                  <Block3D size={S} side={TEX.chiseledShelf(filled, colors)} top={planks} bottom={planks} glow="rgba(232,195,124,0.35)" />
                </div>
              );
            })}
          </div>
        </div>
      </div>
      <div className="absolute left-3 bottom-3 flex gap-3 font-vt text-[17px] text-mute">
        <span className="flex items-center gap-1.5">
          <Sprite id="bookshelf" size={18} /> {W}
          {W > SHELF_POS.length && <span className="text-faint">（显示 {SHELF_POS.length}）</span>}
        </span>
        <span className="flex items-center gap-1.5">
          <Sprite id="chiseled_bookshelf" size={18} /> {chiseledCount}
        </span>
      </div>
      <p className="absolute right-3 bottom-3 font-pixel text-[9px] tracking-widest text-faint">拖拽旋转</p>
    </div>
  );
};

const PRESETS: { name: string; tomes: Tomes; W: number }[] = [
  { name: "空馆", tomes: {}, W: 0 },
  { name: "拓荒", tomes: { sharpness: 2, efficiency: 2, protection: 1 }, W: 10 },
  { name: "中期", tomes: { sharpness: 4, efficiency: 4, protection: 3, unbreaking: 2, fortune: 2, power: 3 }, W: 24 },
  {
    name: "毕业",
    tomes: { sharpness: 5, efficiency: 5, protection: 4, unbreaking: 3, fortune: 3, power: 5, feather_falling: 4, looting: 3, mending: 1, silk_touch: 1 },
    W: 38,
  },
  {
    name: "万卷",
    tomes: Object.fromEntries(ENCHANTS.filter((e) => !e.curse).map((e) => [e.id, e.max])),
    W: 60,
  },
];

const MARKS = [
  { at: 8, label: "残卷免经验", tone: "#7ee8dc" },
  { at: 12, label: "木架减免起效", tone: "#9c93bd" },
  { at: 18, label: "残卷材料折半", tone: "#a18cff" },
  { at: 32, label: "宝藏顿悟", tone: "#e8c37c" },
  { at: 38, label: "升阶 MAX · 木架减免满额", tone: "#f08cc8" },
];

const TIER_LABEL = ["原价", "免经验", "材料 −50%", "完全免费"];
const TIER_TONE = ["#9c93bd", "#7ee8dc", "#a18cff", "#8df0a4"];

const Library = () => {
  const { W, setW, tomes, setTome, setTomes, target, setTarget } = useLib();
  const [focus, setFocus] = useState("sharpness");
  const fe = ENCH[focus];

  const E = totalMastery(tomes);
  const A = affinityMastery(tomes, target);
  const wood = woodDiscount(W);
  const glob = globalDiscount(E);
  const base = baseDiscount(W, E);
  const stored = tomes[focus] ?? 0;
  const spec = specificBonus(stored, fe.max);
  const total = effectiveDiscount(W, E, stored, fe.max);
  const q = qualifyingTomes(tomes);
  const tier = depletedTier(W, q);
  const prob = epiphanyProb(W, E, A);
  const slots = epiphanySlots(W, E, A);

  const shown = Math.min(base, CFG.maxTotal);
  const specShown = Math.max(0, total - shown);

  return (
    <WSection
      id="library"
      icon="chiseled_bookshelf"
      kicker="Library Simulator"
      title={<>书库共鸣 · <span className="shimmer-text">实时模拟器</span></>}
      intro={
        <>
          附魔台读取周围 <span className="text-parch">7×5×7</span>（244 格）内的方块：<span className="text-parch">普通书架</span>
          推进等级上限、提供经验减免、在 32 架唤醒宝藏顿悟；<span className="text-parch">雕纹书架</span>
          里的每本附魔书都是一份永不消耗的「母本」，1:1 解锁对应魔咒并叠加专属减免。在这里搭你的书库——本页之后的所有计算器都会沿用这里的状态。
        </>
      }
      tone="#8df0a4"
    >
      <div className="grid xl:grid-cols-[1.1fr_1fr] gap-6">
        <Panel className="!p-3" tone="#8df0a4">
          <Scene W={W} tomes={tomes} />
        </Panel>

        <Panel tone="#8df0a4">
          <PanelTitle tone="#8df0a4" icon="bookshelf">书库编辑</PanelTitle>
          <div className="flex flex-wrap gap-2 mb-5">
            {PRESETS.map((p) => (
              <Pill
                key={p.name}
                tone="#e8c37c"
                onClick={() => {
                  setTomes(p.tomes);
                  setW(p.W);
                }}
              >
                {p.name}
              </Pill>
            ))}
          </div>
          <Range label="范围内普通书架" value={W} min={0} max={72} onChange={setW} fmt={(v) => `${v} 架`} tone="#8df0a4" />

          <p className="text-xs text-mute mt-5 mb-2">铭刻目标（影响顿悟亲和）</p>
          <div className="flex flex-wrap gap-1.5 mb-5">
            {TARGETS.map((t) => (
              <Pill key={t.id} on={target === t.id} onClick={() => setTarget(t.id)} tone="#7ee8dc">
                <Sprite id={t.icon} size={14} />
                {t.name}
              </Pill>
            ))}
          </div>

          <div className="flex items-baseline justify-between mb-2">
            <p className="text-xs text-mute">雕纹书架母本（左键升级 · 右键降级）</p>
            <p className="font-vt text-[16px] text-faint">{Object.keys(tomes).length} 种 · {Math.ceil(Object.keys(tomes).length / 6)} 座</p>
          </div>
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-1 max-h-[232px] overflow-y-auto wiki-scroll pr-1">
            {ENCHANTS.filter((e) => !e.curse).map((e) => {
              const lvl = tomes[e.id] ?? 0;
              const c = enchColor(e);
              return (
                <button
                  key={e.id}
                  onClick={() => setTome(e.id, lvl >= e.max ? 0 : lvl + 1)}
                  onContextMenu={(ev) => {
                    ev.preventDefault();
                    setTome(e.id, Math.max(0, lvl - 1));
                  }}
                  onMouseEnter={() => setFocus(e.id)}
                  className="relative px-2 py-1.5 rounded-sm text-left border transition-all"
                  style={{
                    background: lvl ? `${c}22` : "rgba(10,9,19,0.5)",
                    borderColor: lvl ? `${c}88` : focus === e.id ? "rgba(237,230,212,0.3)" : "rgba(161,140,255,0.08)",
                  }}
                >
                  <span className="block text-[11.5px] text-parch truncate">{e.name}</span>
                  <span className="flex gap-[2px] mt-1">
                    {Array.from({ length: e.max }).map((_, i) => (
                      <span key={i} className="h-1 flex-1" style={{ background: i < lvl ? c : "rgba(111,101,154,0.25)" }} />
                    ))}
                  </span>
                </button>
              );
            })}
          </div>
        </Panel>
      </div>

      {/* 书架刻度 */}
      <Panel className="mt-6" tone="#a18cff">
        <PanelTitle tone="#a18cff" icon="bookshelf">书架刻度 · 0 → 44</PanelTitle>
        <div className="relative h-24 mt-2">
          <div className="absolute left-0 right-0 top-10 h-[3px] bg-obsidian">
            <motion.div className="h-full bg-gradient-to-r from-xp via-arcane to-inkd" animate={{ width: `${(Math.min(W, 44) / 44) * 100}%` }} />
          </div>
          {MARKS.map((m, i) => {
            const on = W >= m.at;
            return (
              <div key={m.at} className="absolute top-0" style={{ left: `${(m.at / 44) * 100}%` }}>
                <div className="-translate-x-1/2 flex flex-col items-center">
                  <span className="font-vt text-[20px] leading-none" style={{ color: on ? m.tone : "#6f659a" }}>{m.at}</span>
                  <motion.span
                    className="w-3 h-3 rotate-45 mt-[14px]"
                    animate={{ scale: on ? 1.2 : 0.8, backgroundColor: on ? m.tone : "#2c2450" }}
                    style={{ boxShadow: on ? `0 0 12px ${m.tone}` : undefined }}
                  />
                  <span className={`text-[10.5px] mt-2 whitespace-nowrap ${i % 2 ? "translate-y-3" : ""}`} style={{ color: on ? "#ede6d4" : "#6f659a" }}>
                    {m.label}
                  </span>
                </div>
              </div>
            );
          })}
          <motion.div className="absolute top-[30px]" animate={{ left: `${(Math.min(W, 44) / 44) * 100}%` }}>
            <div className="-translate-x-1/2 w-0 h-0 border-l-[6px] border-r-[6px] border-t-[8px] border-l-transparent border-r-transparent border-t-parch" />
          </motion.div>
        </div>
      </Panel>

      {/* 结果仪表 */}
      <div className="grid lg:grid-cols-3 gap-4 mt-6">
        <Panel className="lg:col-span-2" tone="#8df0a4">
          <PanelTitle tone="#8df0a4" icon="experience_orb">经验减免拆解 · 以「{fe.name}」为例</PanelTitle>
          <div className="relative h-11 bg-obsidian rounded-sm overflow-hidden border border-arcane/10">
            <motion.div className="absolute inset-y-0 left-0 bg-xp/80" animate={{ width: `${(Math.min(wood, shown) / 40) * 100}%` }} />
            <motion.div
              className="absolute inset-y-0 bg-arcane/80"
              animate={{ left: `${(Math.min(wood, shown) / 40) * 100}%`, width: `${(Math.max(0, shown - wood) / 40) * 100}%` }}
            />
            <motion.div
              className="absolute inset-y-0 bg-gild/90"
              animate={{ left: `${(shown / 40) * 100}%`, width: `${(specShown / 40) * 100}%` }}
            />
            <div className="absolute inset-y-0 border-r-2 border-dashed border-parch/40" style={{ left: `${(CFG.maxBase / 40) * 100}%` }} />
            <span className="absolute inset-0 flex items-center justify-end pr-3 font-vt text-[26px] text-parch drop-shadow">−{total}%</span>
          </div>
          <div className="flex justify-between font-vt text-[14px] text-faint mt-1">
            <span>0</span>
            <span style={{ marginLeft: `${(CFG.maxBase / 40) * 100 - 8}%` }}>公共上限 35</span>
            <span>总上限 40</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-4">
            <Stat label="木书架" value={`−${wood}%`} tone="#8df0a4" sub={`12 架起 1%，38 架满 15%`} />
            <Stat label="公共母本" value={`−${glob}%`} tone="#a18cff" sub={`⌊E×1.25⌋，E=${E.toFixed(2)}`} />
            <Stat label="专属母本" value={`−${spec}%`} tone="#e8c37c" sub={`round(15·r)，r=${stored}/${fe.max}`} />
            <Stat label="合计（封顶 40）" value={`−${total}%`} tone="#ede6d4" sub={`公共部分 ${base}%`} />
          </div>
          <p className="text-[11.5px] text-faint mt-3 leading-5">悬停上方母本列表中的魔咒可切换示例。母本权重 w(e) = r(e)^1.25，诅咒不计。</p>
        </Panel>

        <div className="space-y-4">
          <Panel tone="#e8c37c">
            <PanelTitle tone="#e8c37c" icon="enchanted_book">宝藏顿悟</PanelTitle>
            {W < 32 ? (
              <p className="text-[13px] text-mute leading-6">
                <span className="font-vt text-[22px] text-faint">未解锁</span>
                <br />
                还差 <span className="text-gild">{32 - W}</span> 个普通书架。
              </p>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <Stat label="触发概率" value={`${Math.round(prob * 100)}%`} tone="#e8c37c" sub="上限 90%" />
                <Stat
                  label="同时刷出"
                  value={
                    <span className="inline-flex gap-1">
                      {Array.from({ length: 4 }).map((_, i) => (
                        <span key={i} style={{ color: i < slots ? "#e8c37c" : "#2c2450" }}>✦</span>
                      ))}
                    </span>
                  }
                  sub={`${slots} / 4 条`}
                />
              </div>
            )}
          </Panel>
          <Panel tone={TIER_TONE[tier]}>
            <PanelTitle tone={TIER_TONE[tier]} icon="depleted_tome">褪魔残卷 · 梯度 {["零", "壹", "贰", "叁"][tier]}</PanelTitle>
            <p className="font-vt text-[26px] leading-none" style={{ color: TIER_TONE[tier] }}>{TIER_LABEL[tier]}</p>
            <p className="text-[11.5px] text-faint mt-2 leading-5">
              合格母本（去重 · MAX 或 MAX−1）：<span className="text-parch">{q}</span> / {GATES.t3Tomes} 种
              {tier < 3 && W >= 18 && <> · 再凑 {GATES.t3Tomes - q} 种即免费</>}
            </p>
          </Panel>
        </div>
      </div>

      {/* 三轨解锁表 */}
      <Panel className="mt-6" tone="#f08cc8">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <PanelTitle tone="#f08cc8" icon="enchanted_book">三轨解锁 · {fe.name}（最高 {roman(fe.max)}）</PanelTitle>
          <select
            value={focus}
            onChange={(e) => setFocus(e.target.value)}
            className="bg-obsidian border border-arcane/25 rounded-sm px-3 py-1.5 text-[13px] text-parch"
          >
            {ENCHANTS.filter((e) => !e.curse).map((e) => (
              <option key={e.id} value={e.id}>
                {e.name}（{roman(e.max)}）
              </option>
            ))}
          </select>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="text-faint text-left">
                <th className="font-normal py-2 pr-4">等级</th>
                <th className="font-normal py-2 pr-4">升阶所需书架</th>
                <th className="font-normal py-2 pr-4">
                  <McTip tip={<><div className="mc-title">轨道一 · 白板</div><div className="mc-gray">无该词条的装备/书，木书架最多推到 ⌈M/2⌉</div></>}>
                    <span className="border-b border-dashed border-faint">轨道一 · 白板直附</span>
                  </McTip>
                </th>
                <th className="font-normal py-2 pr-4">
                  <McTip tip={<><div className="mc-title">轨道二 · 已持有升阶</div><div className="mc-gray">已有该词条 L≥1 时，沿书架曲线升到 MAX</div></>}>
                    <span className="border-b border-dashed border-faint">轨道二 · 已持有升阶</span>
                  </McTip>
                </th>
                <th className="font-normal py-2">轨道三 · 母本</th>
              </tr>
            </thead>
            <tbody>
              {Array.from({ length: fe.max }).map((_, i) => {
                const L = i + 1;
                const need = requiredShelves(L, fe.max);
                const defaultOk = isDefaultUnlock(fe);
                const t1 = defaultOk && L <= blankCap(fe.max, W);
                const t2 = defaultOk ? L <= upgradeCap(fe.max, W, stored) : stored >= L;
                const t3 = stored >= L;
                const cell = (ok: boolean) => (
                  <span className="font-vt text-[19px]" style={{ color: ok ? "#8df0a4" : "#4a4170" }}>{ok ? "✔ 可用" : "✖"}</span>
                );
                return (
                  <tr key={L} className="border-t border-arcane/10">
                    <td className="py-2 pr-4 font-display font-bold text-parch">{roman(L)}</td>
                    <td className="py-2 pr-4 font-vt text-[19px]" style={{ color: W >= need ? "#8df0a4" : "#e8c37c" }}>
                      {need} 架
                    </td>
                    <td className="py-2 pr-4">{cell(t1)}</td>
                    <td className="py-2 pr-4">{cell(t2)}</td>
                    <td className="py-2">{cell(t3)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {!isDefaultUnlock(fe) && (
          <p className="text-[12px] text-gild/80 mt-3">
            {fe.name}属于宝藏 / 顿悟专属魔咒，不出现在默认列表中：只能经由雕纹书架母本、宝藏顿悟或附魔书直接转移获得。
          </p>
        )}
      </Panel>
    </WSection>
  );
};

export default Library;
