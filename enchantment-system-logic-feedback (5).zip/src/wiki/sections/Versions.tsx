import { useState } from "react";
import { motion } from "framer-motion";
import { WSection, Panel, PanelTitle, Pill } from "../kit";
import { Sprite } from "../pixel";

const TIMELINE = [
  { sha: "d29d109", t: "首轮审计基线", d: "11 条：高 maxLevel 魔咒经验套利、CI 模型分叉、残卷条件未去重、中阶天花板被移除、共振常数硬编码等。", tone: "#ff6b8a" },
  { sha: "2f6979b", t: "首轮修复 · 2442 行", d: "归纳守恒返还 + 运行期自检、三轨分离、去重、标签驱动扫描、残卷批量可配。复审：7 修 / 1 变异 / 1 装饰性 / 2 敞口，新增 9 条。", tone: "#e8c37c" },
  { sha: "118acdf", t: "次轮修复 · 1618 行", d: "合并改扣 deductedLevels、library_resonance.json 25 键全消费、activeConfig 绕过同步归零、JUnit 跑真实函数 M=1..255、WIKI 公式重写、死代码与内嵌副本清理。", tone: "#8df0a4" },
  { sha: "89f545b", t: "WIKI 基线", d: "两轮 20 条全部闭环，CI 绿灯。本页上半部分所有公式与数字对齐此提交。", tone: "#a18cff" },
  { sha: "e5eeb33", t: "新增 · 图解手册", d: "Arcane Grimoire：双页排版、8 章原生示意图、书签/键盘导航、双无序配方、JEI/REI 物品查询。", tone: "#7ee8dc" },
  { sha: "5a669bc", t: "手册修正 · 声音与译文", d: "放弃自定义 Vorbis 音效套件、改用原版翻书音；补齐 11 语言共 308 键；加入 JEI/REI 物品查询与界面边界提供器。", tone: "#7ee8dc" },
  { sha: "a64350c", t: "当前 HEAD · 终审", d: "只更新 CI 报告，功能代码未再变动。手册发行审计发现 1 处功能缺陷与 6 处内容漂移，见下。", tone: "#f08cc8" },
];

const FINDINGS = [
  {
    id: "G1",
    sev: "P1",
    t: "从附魔台打开手册会销毁容器会话",
    where: "ChiseledEnchantingTableScreen#mouseClicked → setScreen(new ArcaneGrimoireScreen(this))",
    detail:
      "Minecraft 切换到新 Screen 时会先调用旧界面的 removed()，而 AbstractContainerScreen.removed() 会执行 player.closeContainer()。服务端 ChiseledEnchantingTableScreenHandler.removed(player) 接着 clearContainer(player, inventory)，把上/下两槽的物品退回背包（背包满则掉出）。合上手册时 onClose() 又把那个已经移除的旧 Screen 设回来——看起来是附魔台，但菜单已失效、点击不再生效，书架实时状态也停止同步。",
    fix: "用 pushGuiLayer 以覆盖层打开（保留容器），或改成只从手持右键进入；若必须从台内打开，合上时发送一个 C2S「重新打开附魔台」请求，而不是恢复旧 Screen。",
    tone: "#ff6b8a",
  },
  {
    id: "G2",
    sev: "P1",
    t: "顿悟门槛：手册写 30 架，实装是 32 架",
    where: "lang/*.json grimoire.diag.ch3_epi_off · diag.ch6_gate · treasure_epiphany.json#min_regular_bookshelves",
    detail:
      "手册两处插画文案写「未满 30 架木书架：宝藏顿悟休眠中」「30+ 木书架唤醒大书库」，而同期代码读取的是 SyncedEnchantmentCosts.epiphanyMinBookshelves()，出厂值 32。同一页的仪表按 32 判断，文案却按 30，玩家正好卡在 30–31 架时会看到「已唤醒」的文字和休眠的仪表。",
    fix: "把这两句改成带 %s 的动态门槛（ch6.s2 已经这么做了），或统一写 32。",
    tone: "#ff6b8a",
  },
  {
    id: "G3",
    sev: "P1",
    t: "单件顿悟上限：手册写 3 条，实装 4 条",
    where: "lang/*.json grimoire.diag.ch6_slots · treasure_epiphany.json#max_slots_cap",
    detail: "出厂 max_slots_cap 为 4，手册图注写「最多同时 3 条！」。实际仪表读 epiphanySlots()，可以亮 4 颗。",
    fix: "改为 %s 动态取值，或直接写 4；如果设计上就想 3 条，则调低配置而不是只改文案。",
    tone: "#ff6b8a",
  },
  {
    id: "G4",
    sev: "P2",
    t: "−40% 的拆解算术不成立",
    where: "lang/*.json grimoire.diag.ch4_res",
    detail:
      "文案写「−40%（木架15%+全局20%+同词条15%）」。当前实现先算公共减免 min(35, 15+20)=35，再加同词条 15 = 50，最后总封顶 40。三个数相加是 50，却写着 40，读者会以为是简单相加。",
    fix: "写成「木架 15% + 全局 20% → 公共 35%（封顶）；同词条 +15% → 总封顶 40%」，或直接用三段动态数值。",
    tone: "#e8c37c",
  },
  {
    id: "G5",
    sev: "P2",
    t: "「按住 Shift 整组还原」并不存在",
    where: "lang grimoire.ch7.s2 · ItemTransformationApplication#apply",
    detail:
      "手册写「每次点击转化 1 件；褪魔残卷按住 Shift 点击可整组批量还原」。代码里没有任何 Shift 分支：空白覆写一次点击就按 min(批次上限, 持有数, 可支付数) 整批处理（普通 8 本、免费档 64 本）；其他置换则固定 1 件。",
    fix: "删掉 Shift 说法，改成「一次点击按可支付上限整批还原（8 / 64 本）」。",
    tone: "#e8c37c",
  },
  {
    id: "G6",
    sev: "P2",
    t: "合并要放「下槽」，不是「背包」",
    where: "lang grimoire.ch5.s1 · BookUpgradeApplication#applyCombine",
    detail:
      "手册写「背包带同阶书，仅 0.6× 经验」。applyCombine 要求第二本同阶附魔书放在材料格（下槽），背包里的书不会参与合并。新玩家照做会发现按钮点不动。",
    fix: "改为「下槽放入一本同阶书」。",
    tone: "#e8c37c",
  },
  {
    id: "G7",
    sev: "P2",
    t: "CHANGELOG 仍在宣传已被移除的 Vorbis 音效套件",
    where: "CHANGELOG.md · GrimoireSoundHelper · 资源包",
    detail:
      "1.1.0 的 CHANGELOG 写有「Complete 6-Event Vorbis Audio Suite (SoundRegistry + sounds.json)」，但随后的 5a669bc 改为使用原版 BOOK_PAGE_TURN / BOOK_PUT / UI_BUTTON_CLICK；仓库内既没有 sounds.json，也没有任何 .ogg。字幕翻译同样不存在。",
    fix: "把 CHANGELOG 该段改为「使用原版书籍音效」，删除 SoundRegistry 与字幕条目。",
    tone: "#e8c37c",
  },
  {
    id: "G8",
    sev: "P3",
    t: "手册里的 7 个配方示意是第二份真值",
    where: "GrimoireDiagramRenderer#showcases()（static cachedRecipes）",
    detail:
      "示意图里的 7 个配方（含新增的两个手册配方）在 Java 里硬编码为 ItemStack 数组，与 recipe/*.json 完全独立。数据包改配方、或整合包替换产物后，手册仍显示旧配方，而且缓存在静态字段里、不会随 /reload 刷新。",
    fix: "从 RecipeManager 读取真实配方，或至少在 /reload 后清空缓存；并把「手册配方」标记为示例而非权威。",
    tone: "#7ee8dc",
  },
  {
    id: "G9",
    sev: "P3",
    t: "build.gradle 注释与 exclude 列表已不一致",
    where: "build.gradle sourceSets.main.java 注释",
    detail:
      "注释仍称 mixin.enchanting_table.* 被排除、以免破坏铁砧；实际 exclude 里没有这一项，DisableBookEnchanting 与两个 anvil mixin 都编译进包并注册在 mixins.json。功能上是好的，但注释会误导后续维护者。",
    fix: "更新注释；把「已恢复」的 mixin 单独列出来。",
    tone: "#7ee8dc",
  },
];

const REMAINING = [
  { t: "3 段回落 JSON 文本块换了变量名", d: "ChiseledEnchantingTableData 第 812 / 882 / 1301 行仍内嵌默认 JSON；CI 的 F8 门禁只匹配字面量 BUILT_IN_JSON。建议检测 = \"\"\" 文本块，或构建期从 data/*.json 生成。" },
  { t: "max_level_count 名不副实", d: "computeCount 中 span = min(1.30, 0.52 + 0.096·M)：M=3 时满级只取 81%，M=5 恰为 100%，M≥8 达到 130%。建议改名或写进文档。" },
  { t: "运行期守恒自检以抛异常失败", d: "verifyRuntimeConservation 在 /reload 监听器内 throw。按构造不可达，但若未来重构破坏不变量，整个重载会失败而不是降级告警。" },
  { t: "合并 0.6× 常被母本下限吞没", d: "无母本时完整消耗模式取 max(基础, 母本下限)，多数情况下合并与研究经验相同；合并的实际优势是零材料。WIKI 已如实说明。" },
];

const Versions = () => {
  const [tab, setTab] = useState<"findings" | "notes">("findings");
  return (
    <WSection id="versions" icon="paper" kicker="Changelog & Audit" title="版本与审计" tone="#9c93bd" intro="本 WIKI 的正文公式对齐 89f545b；手册章节与下方发行审计对齐当前 HEAD a64350c。">
      <div className="relative pl-8 space-y-5 mb-10">
        <div className="absolute left-3 top-2 bottom-2 w-[2px] bg-gradient-to-b from-[#ff6b8a] via-gild to-tealw" />
        {TIMELINE.map((s, i) => (
          <motion.div key={s.sha} initial={{ opacity: 0, x: -16 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }} className="relative">
            <span className="absolute -left-[26px] top-1.5 w-3.5 h-3.5 rotate-45" style={{ background: s.tone, boxShadow: `0 0 12px ${s.tone}` }} />
            <p className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
              <code className="font-code text-[12px]" style={{ color: s.tone }}>{s.sha}</code>
              <span className="font-display font-bold text-parch">{s.t}</span>
            </p>
            <p className="text-[13px] leading-6 text-mute font-light mt-1 max-w-3xl">{s.d}</p>
          </motion.div>
        ))}
      </div>

      <div className="flex flex-wrap gap-2 mb-5">
        <Pill on={tab === "findings"} onClick={() => setTab("findings")} tone="#f08cc8">
          发行审计 · {FINDINGS.length} 条
        </Pill>
        <Pill on={tab === "notes"} onClick={() => setTab("notes")} tone="#7ee8dc">
          遗留备注 · {REMAINING.length} 条
        </Pill>
      </div>

      {tab === "findings" ? (
        <div className="space-y-3">
          {FINDINGS.map((f) => (
            <motion.div key={f.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="pixelframe bg-vellum/70 border p-5" style={{ borderColor: `${f.tone}33` }}>
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <span className="font-code text-[10.5px] px-2 py-0.5 rounded-sm" style={{ color: f.tone, background: `${f.tone}15`, border: `1px solid ${f.tone}44` }}>
                  {f.sev} · {f.id}
                </span>
                <p className="font-medium text-[14px] text-parch">{f.t}</p>
              </div>
              <code className="font-code text-[10.5px] text-faint break-all">{f.where}</code>
              <p className="text-[12.5px] leading-6 text-mute font-light mt-2">{f.detail}</p>
              <p className="text-[12px] leading-5.5 text-tealw/90 mt-2">→ {f.fix}</p>
            </motion.div>
          ))}
        </div>
      ) : (
        <Panel tone="#7ee8dc">
          <PanelTitle tone="#7ee8dc" icon="experience_orb">此前遗留 · 仍然成立（非阻断）</PanelTitle>
          <div className="grid md:grid-cols-2 gap-3">
            {REMAINING.map((n, i) => (
              <div key={n.t} className="rounded-sm bg-obsidian/60 border border-arcane/10 p-4">
                <p className="font-medium text-[13.5px] text-parch mb-1">
                  <span className="font-code text-[11px] text-tealw mr-2">N{i + 1}</span>
                  {n.t}
                </p>
                <p className="text-[12px] leading-6 text-mute font-light">{n.d}</p>
              </div>
            ))}
          </div>
        </Panel>
      )}

      <p className="text-center text-[11.5px] text-faint mt-12 flex items-center justify-center gap-2">
        <Sprite id="arcane_grimoire" size={18} />
        非官方社区移植 · 原作 Sacramentix/chiseled-enchanting-table · MIT License · 以游戏内实际表现为准
      </p>
    </WSection>
  );
};

export default Versions;
