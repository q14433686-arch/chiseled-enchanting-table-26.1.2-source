import type { CSSProperties, ReactNode } from "react";

/* ═══════════════════════════════════════════════════════════
   像素精灵系统 · 16×16 网格 → canvas → PNG dataURL（缓存）
   ═══════════════════════════════════════════════════════════ */

type Pal = Record<string, string>;
interface GridSprite {
  pal: Pal;
  rows: string[];
}

const cache = new Map<string, string>();

const renderGrid = (key: string, s: GridSprite): string => {
  const hit = cache.get(key);
  if (hit) return hit;
  if (typeof document === "undefined") return "";
  const c = document.createElement("canvas");
  c.width = 16;
  c.height = 16;
  const g = c.getContext("2d")!;
  s.rows.forEach((row, y) => {
    for (let x = 0; x < 16; x++) {
      const ch = row[x];
      if (!ch || ch === ".") continue;
      const col = s.pal[ch];
      if (!col) continue;
      g.fillStyle = col;
      g.fillRect(x, y, 1, 1);
    }
  });
  const url = c.toDataURL();
  cache.set(key, url);
  return url;
};

/* ── 程序化贴图（方块）── */
const mulberry = (seed: number) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

const renderProc = (key: string, draw: (g: CanvasRenderingContext2D, rnd: () => number) => void, seed = 7) => {
  const hit = cache.get(key);
  if (hit) return hit;
  if (typeof document === "undefined") return "";
  const c = document.createElement("canvas");
  c.width = 16;
  c.height = 16;
  const g = c.getContext("2d")!;
  draw(g, mulberry(seed));
  const url = c.toDataURL();
  cache.set(key, url);
  return url;
};

const px = (g: CanvasRenderingContext2D, x: number, y: number, col: string) => {
  g.fillStyle = col;
  g.fillRect(x, y, 1, 1);
};

const noiseFill = (g: CanvasRenderingContext2D, rnd: () => number, cols: string[], x0 = 0, y0 = 0, w = 16, h = 16) => {
  for (let y = y0; y < y0 + h; y++) for (let x = x0; x < x0 + w; x++) px(g, x, y, cols[Math.floor(rnd() * cols.length)]);
};

const OBSIDIAN = ["#0f0a18", "#150e22", "#1b1230", "#0b0812", "#231840", "#120c1d"];

export const BOOK_COLORS = ["#8a2be2", "#c0392b", "#2e86de", "#27ae60", "#d35400", "#16a085", "#8e44ad", "#b7950b", "#c2185b", "#5e35b1"];

export const TEX = {
  obsidian: () => renderProc("obsidian", (g, r) => noiseFill(g, r, OBSIDIAN), 11),
  cryingObsidian: () =>
    renderProc("crying", (g, r) => {
      noiseFill(g, r, OBSIDIAN);
      for (let i = 0; i < 14; i++) px(g, Math.floor(r() * 16), Math.floor(r() * 16), r() > 0.5 ? "#a020f0" : "#d36bff");
    }, 23),
  goldBlock: () =>
    renderProc("gold", (g, r) => {
      noiseFill(g, r, ["#f6d548", "#f2cb2e", "#fbe27a", "#e9bd22"]);
      g.fillStyle = "#fff4a8";
      g.fillRect(0, 0, 16, 1);
      g.fillRect(0, 0, 1, 16);
      g.fillStyle = "#b58c12";
      g.fillRect(0, 15, 16, 1);
      g.fillRect(15, 0, 1, 16);
    }, 3),
  emeraldBlock: () =>
    renderProc("emeraldb", (g, r) => {
      noiseFill(g, r, ["#2ecc71", "#27b863", "#45e08a", "#1fa155"]);
      g.fillStyle = "#0e6b33";
      for (let i = 0; i < 16; i += 5) g.fillRect(0, i, 16, 1);
    }, 5),
  lapisBlock: () => renderProc("lapisb", (g, r) => noiseFill(g, r, ["#1f4fb4", "#2a5fd0", "#163c8c", "#3a72e6"]), 9),
  diamondBlock: () =>
    renderProc("diamondb", (g, r) => {
      noiseFill(g, r, ["#6ff0ea", "#53dcd6", "#8af7f2", "#3fc3bd"]);
      g.fillStyle = "#d8fffd";
      g.fillRect(1, 1, 14, 1);
    }, 13),
  amethystBlock: () => renderProc("amethystb", (g, r) => noiseFill(g, r, ["#8a5cd0", "#a070e0", "#6e42b0", "#b58cf2"]), 17),
  sculk: () =>
    renderProc("sculk", (g, r) => {
      noiseFill(g, r, ["#0b1d24", "#0f2a33", "#081419", "#13343e"]);
      for (let i = 0; i < 10; i++) px(g, Math.floor(r() * 16), Math.floor(r() * 16), "#29dfeb");
    }, 29),
  planks: () =>
    renderProc("planks", (g, r) => {
      noiseFill(g, r, ["#a0794a", "#94703f", "#ab8452", "#8a6638"]);
      g.fillStyle = "#6b4e2a";
      [3, 7, 11, 15].forEach((y) => g.fillRect(0, y, 16, 1));
    }, 31),
  bookshelf: (seed = 41) =>
    renderProc(`bookshelf-${seed}`, (g, r) => {
      noiseFill(g, r, ["#a0794a", "#94703f", "#ab8452"]);
      g.fillStyle = "#6b4e2a";
      g.fillRect(0, 0, 16, 1);
      g.fillRect(0, 7, 16, 2);
      g.fillRect(0, 15, 16, 1);
      [1, 9].forEach((yy) => {
        let x = 1;
        while (x < 15) {
          const w = r() > 0.7 ? 2 : 1;
          const col = BOOK_COLORS[Math.floor(r() * BOOK_COLORS.length)];
          const h = 5 + Math.floor(r() * 2);
          for (let i = 0; i < w && x < 15; i++, x++) {
            for (let y = yy + (6 - h); y < yy + 6; y++) px(g, x, y, col);
            px(g, x, yy + (6 - h), "#00000044");
          }
          if (r() > 0.75) x++;
        }
      });
    }, seed),
  chiseledShelf: (filled: boolean[] = [false, false, false, false, false, false], colors: string[] = []) =>
    renderProc(`chiseled-${filled.map((f) => (f ? 1 : 0)).join("")}-${colors.join("")}`, (g, r) => {
      noiseFill(g, r, ["#a0794a", "#94703f", "#ab8452"]);
      g.fillStyle = "#5b4124";
      g.fillRect(0, 0, 16, 1);
      g.fillRect(0, 15, 16, 1);
      g.fillRect(0, 0, 1, 16);
      g.fillRect(15, 0, 1, 16);
      g.fillRect(0, 7, 16, 2);
      g.fillRect(5, 1, 1, 14);
      g.fillRect(10, 1, 1, 14);
      const slots = [
        [1, 1], [6, 1], [11, 1],
        [1, 9], [6, 9], [11, 9],
      ];
      slots.forEach(([sx, sy], i) => {
        g.fillStyle = "#2a1c10";
        g.fillRect(sx, sy, 4, 6);
        if (filled[i]) {
          const col = colors[i] ?? BOOK_COLORS[i % BOOK_COLORS.length];
          g.fillStyle = col;
          g.fillRect(sx, sy + 1, 4, 5);
          g.fillStyle = "#ffffff55";
          g.fillRect(sx, sy + 1, 4, 1);
          g.fillStyle = "#e8c37c";
          g.fillRect(sx + 1, sy + 3, 2, 1);
        }
      });
    }, 43),
  tableSide: (cloth = "#5b2b8a", trim = "#e8c37c") =>
    renderProc(`tableside-${cloth}`, (g, r) => {
      noiseFill(g, r, OBSIDIAN);
      for (let y = 0; y < 5; y++) for (let x = 0; x < 16; x++) px(g, x, y, r() > 0.85 ? shade(cloth, -18) : cloth);
      g.fillStyle = trim;
      g.fillRect(0, 4, 16, 1);
      [3, 8, 12].forEach((x) => {
        g.fillRect(x, 5, 1, 2);
      });
      g.fillStyle = "#00000066";
      g.fillRect(0, 5, 16, 1);
    }, 51),
  tableTop: (cloth = "#5b2b8a", trim = "#e8c37c") =>
    renderProc(`tabletop-${cloth}`, (g, r) => {
      for (let y = 0; y < 16; y++) for (let x = 0; x < 16; x++) px(g, x, y, r() > 0.86 ? shade(cloth, -16) : cloth);
      g.fillStyle = trim;
      g.fillRect(1, 1, 14, 1);
      g.fillRect(1, 14, 14, 1);
      g.fillRect(1, 1, 1, 14);
      g.fillRect(14, 1, 1, 14);
      [[0, 0], [14, 0], [0, 14], [14, 14]].forEach(([x, y]) => {
        g.fillStyle = "#4ee6e0";
        g.fillRect(x, y, 2, 2);
        g.fillStyle = "#d8fffd";
        g.fillRect(x, y, 1, 1);
      });
      g.fillStyle = shade(trim, -30);
      g.fillRect(6, 6, 4, 4);
      g.fillStyle = trim;
      g.fillRect(7, 5, 2, 6);
      g.fillRect(5, 7, 6, 2);
    }, 53),
  pageL: () =>
    renderProc("pageL", (g) => {
      g.fillStyle = "#efe6cf";
      g.fillRect(0, 0, 16, 16);
      g.fillStyle = "#c9bb96";
      for (let y = 3; y < 14; y += 2) g.fillRect(2, y, 11 - ((y * 3) % 5), 1);
      g.fillStyle = "#8a6fd0";
      g.fillRect(3, 3, 3, 1);
    }, 1),
  cover: () =>
    renderProc("cover", (g, r) => {
      noiseFill(g, r, ["#5b2b8a", "#53257f", "#62309a"]);
      g.fillStyle = "#e8c37c";
      g.fillRect(1, 1, 14, 1);
      g.fillRect(1, 14, 14, 1);
      g.fillRect(7, 5, 2, 6);
    }, 2),
};

const shade = (hex: string, amt: number) => {
  const n = parseInt(hex.slice(1, 7), 16);
  const c = (v: number) => Math.max(0, Math.min(255, v + amt));
  return `#${[c(n >> 16), c((n >> 8) & 255), c(n & 255)].map((v) => v.toString(16).padStart(2, "0")).join("")}`;
};

/* ── 手绘网格精灵 ── */
const BOOK_ROWS = [
  "................",
  "..kkkkkkkkkkk...",
  ".ksbbbbbbbbbbk..",
  ".ksbBBBBBBBBbk..",
  ".ksbBbbbbbbBbk..",
  ".ksbBbbggbbBbk..",
  ".ksbBbbbbbbBbk..",
  ".ksbBBBBBBBBbk..",
  ".ksbbbbbbbbbbk..",
  ".ksbbbbbbbbbbk..",
  ".ksbbbbbbbbbbk..",
  ".ksbbbbbbbbbbk..",
  ".kswwwwwwwwwwk..",
  ".kspppppppppppk.",
  "..kkkkkkkkkkkk..",
  "................",
];
const TOME_ROWS = [
  "................",
  "..kkkkkkkkkkk...",
  ".ksbbbbxbbbbbk..",
  ".ksbBBBxBBBBbk..",
  ".ksbBbbbxbbBbk..",
  ".ksbBbbbxbbBbk..",
  ".ksbBbbxbbbBbk..",
  ".ksbBBBxBBBBbk..",
  ".ksbbbbbxbbbbk..",
  ".ksbbbbbbxbbbk..",
  ".ksbbbbbbxbbbk..",
  ".ksbbbbbxbbbbk..",
  ".kswwwwwwwwwwk..",
  ".kspppppppppppk.",
  "..kkkkkkkkkkkk..",
  "................",
];
const GEM_ROWS = [
  "................",
  "................",
  ".....kkkkkk.....",
  "....kwlllllk....",
  "...kwllllllmk...",
  "..kwlllllllmmk..",
  ".kkkkkkkkkkkkkk.",
  ".kllllllllmmmdk.",
  "..klllllllmmdk..",
  "...kllllllmdk...",
  "....kllllmdk....",
  ".....kllmdk.....",
  "......klmk......",
  ".......kk.......",
  "................",
  "................",
];
const SHARD_ROWS = [
  "................",
  "...........kk...",
  "..........kwlk..",
  ".........kwlmk..",
  "....kk..kwlmk...",
  "...kwlk.kllmk...",
  "...kwllkklmk....",
  "....kllmklmk....",
  "....kllmmmk.....",
  ".....klmmdk.....",
  ".....kkmmdk.....",
  "......kddk......",
  ".......kk.......",
  "................",
  "................",
  "................",
];
const ORB_ROWS = [
  "................",
  "................",
  "................",
  ".....kkkkkk.....",
  "....kyyyyyyk....",
  "...kywwyyyygk...",
  "...kywyyyyygk...",
  "...kyyyyyyggk...",
  "...kyyyyyggGk...",
  "...kyyyygggGk...",
  "....kgggggGk....",
  ".....kkkkkk.....",
  "................",
  "................",
  "................",
  "................",
];
const DUST_ROWS = [
  "................",
  "................",
  "................",
  ".......s........",
  "..........s.....",
  "....s...........",
  ".......kk.......",
  ".....kkwwkk.....",
  "....kwwllwwk....",
  "...kwllllllmk...",
  "..kwllllllllmk..",
  "..klllllllmmmk..",
  ".kllllllmmmmmdk.",
  ".kkkkkkkkkkkkkk.",
  "................",
  "................",
];
const CATALYST_ROWS = [
  "................",
  ".......kk.......",
  ".....kkAEkk.....",
  "....kAAAEEEk....",
  "...kAAAwwEEEk...",
  "..kAAAwDDwEEEk..",
  "..kAAwDDDDwEEk..",
  ".kAAAwDDDDwEEEk.",
  "..kLLwDDDDwGGk..",
  "..kLLLwDDwGGGk..",
  "...kLLLwwGGGk...",
  "....kLLLGGGk....",
  ".....kkLGkk.....",
  ".......kk.......",
  "................",
  "................",
];
const BOTTLE_ROWS = [
  "................",
  "......kkkk......",
  "......kcck......",
  ".......kk.......",
  "......kwwk......",
  ".....kwffwk.....",
  "....kwffffwk....",
  "....kffffffk....",
  "....kffffffk....",
  "....kffffffk....",
  "....kffffffk....",
  ".....kffffk.....",
  "......kkkk......",
  "................",
  "................",
  "................",
];
const APPLE_ROWS = [
  "................",
  ".......s........",
  ".......sLL......",
  "....kkkskkkk....",
  "...kwaaaaaaak...",
  "..kwwaaaaaaaak..",
  "..kwaaaaaaaaak..",
  "..kaaaaaaaaamk..",
  "..kaaaaaaaammk..",
  "..kaaaaaaammmk..",
  "...kaaaaammmk...",
  "....kaammmmk....",
  ".....kkkkkk.....",
  "................",
  "................",
  "................",
];
const TOTEM_ROWS = [
  "................",
  ".....kkkkkk.....",
  ".....kyyyyk.....",
  ".....kgyygk.....",
  ".....kyyyyk.....",
  "...kkkyyyykkk...",
  "..kyyyyyyyyyyk..",
  "..kyykyyyykyyk..",
  "...kk.kyyk.kk...",
  "......kyyk......",
  ".....kyyyyk.....",
  ".....kymmyk.....",
  ".....kyyyyk.....",
  "......kkkk......",
  "................",
  "................",
];
const TRIDENT_ROWS = [
  "................",
  "...k...k...k....",
  "...t...t...t....",
  "...t...t...t....",
  "...ttttttttt....",
  ".......h........",
  ".......h........",
  ".......h........",
  ".......h........",
  ".......h........",
  ".......h........",
  ".......h........",
  ".......h........",
  ".......t........",
  ".......t........",
  "................",
];
const TEAR_ROWS = [
  "................",
  "................",
  "................",
  ".......kk.......",
  "......kwtk......",
  ".....kwttdk.....",
  "....kwttttdk....",
  "....kttttttk....",
  "....kttttddk....",
  ".....kttddk.....",
  "......kkkk......",
  "................",
  "................",
  "................",
  "................",
  "................",
];
const SWORD_ROWS = [
  ".............kk.",
  "............kwlk",
  "...........kwlk.",
  "..........kwlk..",
  ".........kwlk...",
  "........kwlk....",
  "...kk..kwlk.....",
  "...kgkkwlk......",
  "....kgklk.......",
  ".....kgk........",
  "....khkgk.......",
  "...khk.kgk......",
  "..khk...kk......",
  ".khk............",
  ".kk.............",
  "................",
];
const PAPER_ROWS = [
  "................",
  "................",
  "...kkkkkkkkk....",
  "...kwwwwwwwwk...",
  "...kwppppppwk...",
  "...kwwwwwwwwk...",
  "...kwppppwwwk...",
  "...kwwwwwwwwk...",
  "...kwpppppwwk...",
  "...kwwwwwwwwk...",
  "...kwwwwwwwsk...",
  "...kkkkkkkkkk...",
  "................",
  "................",
  "................",
  "................",
];
const SHELL_ROWS = [
  "................",
  "................",
  ".....kkkkkk.....",
  "....kwwccwwk....",
  "...kwccwwccwk...",
  "..kwcwkkkkwcwk..",
  "..kcwk....kwck..",
  "..kcwk.kk.kwck..",
  "..kwck.kckkwck..",
  "...kwckkkkwck...",
  "....kwccccwk....",
  ".....kkkkkk.....",
  "................",
  "................",
  "................",
  "................",
];

const GRIMOIRE_ROWS = [
  "................",
  "..kkkkkkkkkkk...",
  ".ksbbbbGbbbbbk..",
  ".ksbBBGGGBBBbk..",
  ".ksbBGGGGGBBbk..",
  ".ksbBGGxGGBBbk..",
  ".ksbBGGGGGBBbk..",
  ".ksbBBGGGBBBbk..",
  ".ksbbbbGbbbbbk..",
  ".ksbbbbbbbbbbk..",
  ".ksbbbbxbbbbbk..",
  ".ksbbbbbbbbbbk..",
  ".kswwwwwwwwwwk..",
  ".kspppppppppppk.",
  "..kkkkkkkkkkkk..",
  "................",
];

const BOOK_PAL: Pal = { k: "#2b1a10", s: "#5a3418", b: "#7a4a2a", B: "#9c6436", g: "#7a4a2a", w: "#efe6cf", p: "#c9bb96" };
const EBOOK_PAL: Pal = { k: "#1c0b2e", s: "#3e1a63", b: "#5b2b8a", B: "#8f5bd6", g: "#e8c37c", w: "#efe6cf", p: "#c9bb96" };
const TOME_PAL: Pal = { k: "#1f1c24", s: "#47414f", b: "#5f5868", B: "#7d7687", x: "#2a2630", w: "#bdb6a6", p: "#958e80" };

const gem = (l: string, w: string, m: string, d: string, k: string): GridSprite => ({ pal: { l, w, m, d, k }, rows: GEM_ROWS });
const shard = (l: string, w: string, m: string, d: string, k: string): GridSprite => ({ pal: { l, w, m, d, k }, rows: SHARD_ROWS });
const dust = (l: string, w: string, m: string, d: string, k: string, s: string): GridSprite => ({ pal: { l, w, m, d, k, s }, rows: DUST_ROWS });

const SPRITES: Record<string, GridSprite> = {
  book: { pal: BOOK_PAL, rows: BOOK_ROWS },
  enchanted_book: { pal: EBOOK_PAL, rows: BOOK_ROWS },
  arcane_grimoire: {
    pal: { k: "#1a0b2b", s: "#3d1a5e", b: "#5a2a8a", B: "#8f5bd6", G: "#e8c37c", x: "#b98a3e", w: "#f5ead0", p: "#cbba92" },
    rows: GRIMOIRE_ROWS,
  },
  depleted_tome: { pal: TOME_PAL, rows: TOME_ROWS },
  diamond: gem("#4ee6e0", "#d8fffd", "#2bb3b0", "#16706e", "#0c3a3a"),
  emerald: gem("#3fdc72", "#c9ffd9", "#1ea24c", "#0d6b2e", "#063a18"),
  lapis_lazuli: gem("#2f5fd0", "#9fbfff", "#1f3f9a", "#132766", "#0a1436"),
  echo_shard: gem("#1f8a9a", "#8ff3f6", "#126070", "#0a3a44", "#051a20"),
  quartz: gem("#ece6dc", "#ffffff", "#cfc6b8", "#a89e8e", "#5a5246"),
  amethyst_shard: shard("#c58cf2", "#f1dcff", "#9a5cd0", "#6a35a0", "#33184f"),
  prismarine_shard: shard("#5fc9b0", "#c8fff0", "#3a9e88", "#226a5a", "#103a32"),
  prismarine_crystals: shard("#cfe9e0", "#ffffff", "#9fd6c6", "#6aa898", "#2f5a50"),
  flint: shard("#5a5a5a", "#9a9a9a", "#3e3e3e", "#2a2a2a", "#141414"),
  experience_orb: { pal: { y: "#d6ff5a", w: "#ffffd0", g: "#6ad63a", G: "#3a9a22", k: "#1f4a10" }, rows: ORB_ROWS },
  cleansing_grit: dust("#e9e3f2", "#ffffff", "#b9aecb", "#8a7fa0", "#4a4058", "#f0d0ff"),
  bone_meal: dust("#f2f0e6", "#ffffff", "#d6d2c2", "#aaa594", "#5c5848", "#00000000"),
  ink_sac: dust("#2a2a3a", "#4a4a62", "#1c1c28", "#121218", "#06060a", "#00000000"),
  glow_ink_sac: dust("#3fd6c8", "#b8fff6", "#2aa89c", "#187066", "#0a3a34", "#9ffff4"),
  gunpowder: dust("#6a6a6a", "#9a9a9a", "#4a4a4a", "#333333", "#161616", "#00000000"),
  sculk_dust: dust("#0f2a33", "#29dfeb", "#0b1d24", "#081419", "#03090c", "#29dfeb"),
  arcane_catalyst: {
    pal: { A: "#b072e8", E: "#3fdc72", L: "#2f5fd0", G: "#f2c440", D: "#bff7f5", w: "#ffffff", k: "#1a1030" },
    rows: CATALYST_ROWS,
  },
  glass_bottle: { pal: { k: "#4a6a7a", c: "#8b5a2b", w: "#e8f6ff", f: "#a8d0e655" }, rows: BOTTLE_ROWS },
  experience_bottle: { pal: { k: "#2a5a1a", c: "#8b5a2b", w: "#d6ff9a", f: "#7ad84a" }, rows: BOTTLE_ROWS },
  golden_apple: { pal: { a: "#f6d548", w: "#fff5b0", m: "#c9a020", k: "#5a4510", s: "#6b4a1e", L: "#4fae3a" }, rows: APPLE_ROWS },
  enchanted_golden_apple: { pal: { a: "#f6d548", w: "#fff5b0", m: "#c9a020", k: "#5a4510", s: "#6b4a1e", L: "#4fae3a" }, rows: APPLE_ROWS },
  totem_of_undying: { pal: { y: "#e8c040", m: "#3fdc72", g: "#2fa050", k: "#5a4010" }, rows: TOTEM_ROWS },
  trident: { pal: { k: "#bff7f0", t: "#4fc1b8", h: "#2f8f88" }, rows: TRIDENT_ROWS },
  ghast_tear: { pal: { t: "#cfe9f0", w: "#ffffff", d: "#8fb5c0", k: "#4a6a74" }, rows: TEAR_ROWS },
  diamond_sword: { pal: { k: "#0c3a3a", w: "#d8fffd", l: "#4ee6e0", g: "#3a2a1a", h: "#6b4a1e" }, rows: SWORD_ROWS },
  paper: { pal: { k: "#8a8070", w: "#f6f2e6", p: "#cfc8b4", s: "#d8d2c0" }, rows: PAPER_ROWS },
  nautilus_shell: { pal: { k: "#5a4030", w: "#f2e2c8", c: "#c98a5a" }, rows: SHELL_ROWS },
  blaze_rod: shard("#f6c830", "#fff2a0", "#e08a10", "#a85a08", "#4a2604"),
  breeze_rod: shard("#a8b8f6", "#e8f0ff", "#7a8ad8", "#4a5aa8", "#1e2650"),
  ender_pearl: { pal: { y: "#1f6b5a", w: "#7fe3c6", g: "#165042", G: "#0c342a", k: "#061a14" }, rows: ORB_ROWS },
  string: dust("#eeeeee", "#ffffff", "#cccccc", "#999999", "#555555", "#00000000"),
  iron_ingot: {
    pal: { k: "#3a3a3a", w: "#ffffff", l: "#d8d8d8", m: "#a8a8a8", d: "#6a6a6a" },
    rows: [
      "................",
      "................",
      "................",
      "................",
      "................",
      ".....kkkkkkkk...",
      "....kwwwwwwlmk..",
      "...kwllllllmdk..",
      "..kwllllllmddk..",
      "..kkkkkkkkkkkk..",
      "..kmmmmmmmmddk..",
      "..kkkkkkkkkkk...",
      "................",
      "................",
      "................",
      "................",
    ],
  },
  feather: shard("#f2f2f2", "#ffffff", "#cfcfcf", "#9a9a9a", "#4a4a4a"),
  phantom_membrane: dust("#c8d0e6", "#f0f4ff", "#a0aac8", "#7a84a8", "#3a4058", "#00000000"),
  wind_charge: { pal: { y: "#b8d8ff", w: "#f0f8ff", g: "#8ab0e6", G: "#5a80c0", k: "#2a3a60" }, rows: ORB_ROWS },
  sweet_berries: { pal: { y: "#e0303a", w: "#ff9aa0", g: "#b01c26", G: "#7a1018", k: "#3a0608" }, rows: ORB_ROWS },
  arrow: shard("#c9c0b0", "#ffffff", "#8a7a60", "#5a4a30", "#2a2010"),
  spectral_arrow: shard("#f6d548", "#fff5b0", "#c9a020", "#8a6a10", "#3a2a04"),
};

/** 程序化方块作为物品图标 */
const BLOCK_ICON: Record<string, () => string> = {
  obsidian: TEX.obsidian,
  crying_obsidian: TEX.cryingObsidian,
  gold_block: TEX.goldBlock,
  emerald_block: TEX.emeraldBlock,
  lapis_block: TEX.lapisBlock,
  diamond_block: TEX.diamondBlock,
  amethyst_block: TEX.amethystBlock,
  sculk: TEX.sculk,
  bookshelf: () => TEX.bookshelf(41),
  chiseled_bookshelf: () => TEX.chiseledShelf([true, false, true, true, true, false]),
  enchanting_table: () => TEX.tableSide("#a3262a", "#e8c37c"),
  chiseled_enchanting_table: () => TEX.tableSide(),
  copper_block: () => renderProc("copper", (g, r) => noiseFill(g, r, ["#c06a45", "#d67c52", "#a85a3a", "#e08a60"]), 61),
  blue_ice: () => renderProc("blueice", (g, r) => noiseFill(g, r, ["#74a8f6", "#88b8ff", "#5f94e6", "#a0c8ff"]), 63),
  soul_sand: () => renderProc("soulsand", (g, r) => noiseFill(g, r, ["#4a3a2a", "#5a4632", "#3a2c20", "#62503a"]), 65),
  cactus: () =>
    renderProc("cactus", (g, r) => {
      noiseFill(g, r, ["#2f7a2a", "#3a8a32", "#256a22", "#44983a"]);
      for (let i = 0; i < 8; i++) px(g, Math.floor(r() * 16), Math.floor(r() * 16), "#d8e8a0");
    }, 67),
  sculk_block: TEX.sculk,
};

export const GLINT_IDS = new Set(["enchanted_book", "enchanted_golden_apple", "experience_bottle"]);

export const spriteUrl = (id: string): string => {
  const key = id.replace(/^.*:/, "");
  if (SPRITES[key]) return renderGrid(key, SPRITES[key]);
  if (BLOCK_ICON[key]) return BLOCK_ICON[key]();
  return renderGrid("book", SPRITES.book);
};

export const isBlockIcon = (id: string) => !!BLOCK_ICON[id.replace(/^.*:/, "")];

/* ═══════════════════ 组件 ═══════════════════ */

export const Sprite = ({
  id,
  size = 32,
  glint,
  className,
  style,
}: {
  id: string;
  size?: number;
  glint?: boolean;
  className?: string;
  style?: CSSProperties;
}) => {
  const url = spriteUrl(id);
  const key = id.replace(/^.*:/, "");
  const g = glint ?? GLINT_IDS.has(key);
  const block = isBlockIcon(id);
  return (
    <span
      className={`relative inline-block shrink-0 ${className ?? ""}`}
      style={{ width: size, height: size, ...style }}
    >
      {block ? (
        <MiniIsoBlock url={url} size={size} />
      ) : (
        <img src={url} alt={key} width={size} height={size} className="pixelated block w-full h-full" draggable={false} />
      )}
      {g && !block && (
        <span
          className="glint absolute inset-0"
          style={{ WebkitMaskImage: `url(${url})`, maskImage: `url(${url})` }}
        />
      )}
    </span>
  );
};

/** 物品栏里的方块：伪等距三面 */
const MiniIsoBlock = ({ url, size }: { url: string; size: number }) => {
  const s = size * 0.62;
  return (
    <span className="absolute inset-0" style={{ perspective: 400 }}>
      <span
        className="cube"
        style={{
          width: s,
          height: s,
          left: (size - s) / 2,
          top: (size - s) / 2 + size * 0.04,
          transform: "rotateX(-30deg) rotateY(45deg)",
        }}
      >
        <span className="cube-face" style={{ width: s, height: s, backgroundImage: `url(${url})`, transform: `translateZ(${s / 2}px)`, filter: "brightness(0.8)" }} />
        <span className="cube-face" style={{ width: s, height: s, backgroundImage: `url(${url})`, transform: `rotateY(90deg) translateZ(${s / 2}px)`, filter: "brightness(0.62)" }} />
        <span className="cube-face" style={{ width: s, height: s, backgroundImage: `url(${url})`, transform: `rotateX(90deg) translateZ(${s / 2}px)` }} />
      </span>
    </span>
  );
};

/** 真 3D 方块（6 面），可指定顶/侧/底贴图 */
export const Block3D = ({
  size,
  side,
  top,
  bottom,
  height = 1,
  x = 0,
  y = 0,
  z = 0,
  glow,
  children,
  shadeSides = true,
}: {
  size: number;
  side: string;
  top?: string;
  bottom?: string;
  height?: number;
  x?: number;
  y?: number;
  z?: number;
  glow?: string;
  children?: ReactNode;
  shadeSides?: boolean;
}) => {
  const h = size * height;
  const t = top ?? side;
  const b = bottom ?? side;
  const face = (img: string, transform: string, w: number, hh: number, bright = 1, extra: CSSProperties = {}) => (
    <span
      className="cube-face"
      style={{
        width: w,
        height: hh,
        backgroundImage: `url(${img})`,
        transform,
        filter: shadeSides && bright !== 1 ? `brightness(${bright})` : undefined,
        left: (size - w) / 2,
        top: (size - hh) / 2,
        boxShadow: glow ? `0 0 14px ${glow}` : undefined,
        ...extra,
      }}
    />
  );
  return (
    <span
      className="cube"
      style={{
        width: size,
        height: size,
        transform: `translate3d(${x}px, ${y}px, ${z}px)`,
      }}
    >
      {face(side, `translateZ(${size / 2}px) translateY(${(size - h) / 2}px)`, size, h, 0.86, { backgroundPosition: "top", backgroundSize: `100% ${size}px` })}
      {face(side, `rotateY(180deg) translateZ(${size / 2}px) translateY(${(size - h) / 2}px)`, size, h, 0.7, { backgroundPosition: "top", backgroundSize: `100% ${size}px` })}
      {face(side, `rotateY(90deg) translateZ(${size / 2}px) translateY(${(size - h) / 2}px)`, size, h, 0.72, { backgroundPosition: "top", backgroundSize: `100% ${size}px` })}
      {face(side, `rotateY(-90deg) translateZ(${size / 2}px) translateY(${(size - h) / 2}px)`, size, h, 0.92, { backgroundPosition: "top", backgroundSize: `100% ${size}px` })}
      {face(t, `rotateX(90deg) translateZ(${size / 2 - (size - h)}px)`, size, size, 1)}
      {face(b, `rotateX(-90deg) translateZ(${size / 2}px)`, size, size, 0.5)}
      {children}
    </span>
  );
};
