import { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence, useScroll, useSpring } from "framer-motion";
import { Search, Menu, X, ScrollText, CornerDownLeft } from "lucide-react";
import { Sprite } from "./pixel";
import { LibProvider } from "./kit";
import { ENCHANTS, ITEM_NAME, ADV_GROUPS, DATAPACK, TRANSFORMS, CUSTOM_ITEMS, roman } from "./data";
import Home from "./sections/Home";
import Recipes from "./sections/Recipes";
import Library from "./sections/Library";
import XpModes from "./sections/XpModes";
import BookCare from "./sections/BookCare";
import Cleanse from "./sections/Cleanse";
import Epiphany from "./sections/Epiphany";
import Transmute from "./sections/Transmute";
import Advancements from "./sections/Advancements";
import Datapack from "./sections/Datapack";
import Grimoire from "./sections/Grimoire";
import Versions from "./sections/Versions";

const NAV = [
  { id: "home", label: "首页", icon: "chiseled_enchanting_table" },
  { id: "quickstart", label: "三步上手", icon: "book" },
  { id: "recipes", label: "合成与物品", icon: "crying_obsidian" },
  { id: "library", label: "书库模拟器", icon: "chiseled_bookshelf" },
  { id: "xp", label: "经验双模式", icon: "experience_orb" },
  { id: "books", label: "附魔书培养", icon: "enchanted_book" },
  { id: "grimoire", label: "纂刻秘典", icon: "arcane_grimoire" },
  { id: "cleanse", label: "退魔页", icon: "cleansing_grit" },
  { id: "epiphany", label: "宝藏顿悟", icon: "amethyst_shard" },
  { id: "transmute", label: "物品置换", icon: "experience_bottle" },
  { id: "advancements", label: "进度图鉴", icon: "golden_apple" },
  { id: "datapack", label: "数据包", icon: "paper" },
  { id: "versions", label: "版本与审计", icon: "depleted_tome" },
];

interface Hit {
  label: string;
  sub: string;
  icon: string;
  to: string;
}

const buildIndex = (): Hit[] => [
  ...NAV.map((n) => ({ label: n.label, sub: "章节", icon: n.icon, to: n.id })),
  ...ENCHANTS.map((e) => ({
    label: e.name,
    sub: `魔咒 · 最高 ${roman(e.max)}${e.curse ? " · 诅咒" : e.treasure ? " · 宝藏" : e.exclusive ? " · 顿悟专属" : ""}`,
    icon: "enchanted_book",
    to: e.curse ? "cleanse" : e.treasure || e.exclusive ? "epiphany" : "library",
  })),
  ...CUSTOM_ITEMS.map((c) => ({ label: c.name, sub: "自定义物品", icon: c.id, to: "recipes" })),
  ...TRANSFORMS.map((t) => ({ label: t.name, sub: `置换 · ${ITEM_NAME[t.input]} → ${ITEM_NAME[t.output]}`, icon: t.output, to: "transmute" })),
  ...ADV_GROUPS.flatMap((g) => g.items.map((a) => ({ label: a.title, sub: `进度 · ${a.desc}`, icon: a.icon, to: "advancements" }))),
  ...DATAPACK.map((d) => ({ label: d.path, sub: `数据包 · ${d.title}`, icon: "paper", to: "datapack" })),
  { label: "经验减免", sub: "书库共鸣 · 最高 −40%", icon: "experience_orb", to: "library" },
  { label: "褪魔残卷三梯度", sub: "8 / 18 / 18+6", icon: "depleted_tome", to: "books" },
  { label: "锁定 / 重刷顿悟", sub: "顿悟控制台", icon: "blue_ice", to: "epiphany" },
];

const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });

const Palette = ({ open, onClose }: { open: boolean; onClose: () => void }) => {
  const [q, setQ] = useState("");
  const [cur, setCur] = useState(0);
  const idx = useMemo(buildIndex, []);
  const inputRef = useRef<HTMLInputElement>(null);
  const hits = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return idx.slice(0, 12);
    return idx.filter((h) => h.label.toLowerCase().includes(s) || h.sub.toLowerCase().includes(s)).slice(0, 30);
  }, [q, idx]);

  useEffect(() => {
    if (open) {
      setQ("");
      setCur(0);
      setTimeout(() => inputRef.current?.focus(), 30);
    }
  }, [open]);

  const pick = (h: Hit) => {
    onClose();
    setTimeout(() => go(h.to), 60);
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-[120] flex items-start justify-center pt-[12vh] px-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
          <motion.div
            initial={{ y: -16, scale: 0.97 }}
            animate={{ y: 0, scale: 1 }}
            exit={{ y: -10, opacity: 0 }}
            className="relative w-full max-w-xl mc-tooltip !p-0 !text-base overflow-hidden"
            style={{ fontFamily: "inherit", textShadow: "none" }}
          >
            <div className="flex items-center gap-3 px-4 py-3 border-b border-[#5000ff]/40">
              <Search size={16} className="text-[#a18cff]" />
              <input
                ref={inputRef}
                value={q}
                onChange={(e) => {
                  setQ(e.target.value);
                  setCur(0);
                }}
                onKeyDown={(e) => {
                  if (e.key === "ArrowDown") {
                    e.preventDefault();
                    setCur((c) => Math.min(hits.length - 1, c + 1));
                  } else if (e.key === "ArrowUp") {
                    e.preventDefault();
                    setCur((c) => Math.max(0, c - 1));
                  } else if (e.key === "Enter" && hits[cur]) pick(hits[cur]);
                  else if (e.key === "Escape") onClose();
                }}
                placeholder="搜索魔咒、物品、进度、数据包文件……"
                className="flex-1 bg-transparent outline-none text-[15px] text-white placeholder:text-[#7a6aa8]"
              />
              <kbd className="font-vt text-[14px] text-[#7a6aa8]">ESC</kbd>
            </div>
            <div className="max-h-[50vh] overflow-y-auto wiki-scroll py-1">
              {hits.length === 0 && <p className="px-4 py-6 text-center text-[13px] text-[#7a6aa8]">没有找到「{q}」</p>}
              {hits.map((h, i) => (
                <button
                  key={h.label + h.sub}
                  onMouseEnter={() => setCur(i)}
                  onClick={() => pick(h)}
                  className="w-full flex items-center gap-3 px-4 py-2 text-left"
                  style={{ background: i === cur ? "rgba(80,0,255,0.25)" : "transparent" }}
                >
                  <Sprite id={h.icon} size={22} />
                  <span className="flex-1 min-w-0">
                    <span className="block text-[14px] text-white truncate">{h.label}</span>
                    <span className="block text-[11.5px] text-[#9a8ac8] truncate">{h.sub}</span>
                  </span>
                  {i === cur && <CornerDownLeft size={14} className="text-[#a18cff]" />}
                </button>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

const WikiApp = ({ onSwitch }: { onSwitch: () => void }) => {
  const [active, setActive] = useState("home");
  const [palette, setPalette] = useState(false);
  const [menu, setMenu] = useState(false);
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 24 });

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setPalette((p) => !p);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    const els = Array.from(document.querySelectorAll<HTMLElement>("[data-wiki-section]"));
    const obs = new IntersectionObserver(
      (es) => es.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: "-35% 0px -60% 0px" },
    );
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  const Nav = (
    <nav className="space-y-0.5">
      {NAV.map((n) => (
        <button
          key={n.id}
          onClick={() => {
            go(n.id);
            setMenu(false);
          }}
          className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-sm text-left transition-all duration-200 group"
          style={{ background: active === n.id ? "rgba(161,140,255,0.12)" : "transparent" }}
        >
          <span className="relative">
            <Sprite id={n.icon} size={20} />
            {active === n.id && <motion.span layoutId="navglow" className="absolute -inset-1 rounded-sm" style={{ boxShadow: "0 0 12px rgba(232,195,124,0.6)" }} />}
          </span>
          <span className={`text-[13px] transition-colors ${active === n.id ? "text-parch" : "text-mute group-hover:text-parch"}`}>{n.label}</span>
          {active === n.id && <motion.span layoutId="navbar" className="ml-auto w-1 h-4 bg-gild rounded-full" />}
        </button>
      ))}
    </nav>
  );

  return (
    <LibProvider>
      <div className="min-h-screen bg-obsidian text-parch font-body">
        <motion.div className="fixed top-0 left-0 right-0 h-[2px] z-[80] origin-left bg-gradient-to-r from-arcane via-gild to-inkd" style={{ scaleX: progress }} />

        {/* top bar */}
        <header className="sticky top-0 z-[70] h-14 flex items-center gap-3 px-4 md:px-6 bg-obsidian/85 backdrop-blur-md border-b border-arcane/10">
          <button className="lg:hidden text-mute" onClick={() => setMenu(true)}>
            <Menu size={20} />
          </button>
          <button onClick={() => go("home")} className="flex items-center gap-2.5">
            <Sprite id="chiseled_enchanting_table" size={28} />
            <span className="font-display font-black text-[15px] tracking-wide">纂刻附魔台</span>
            <span className="hidden sm:inline font-pixel text-[9px] tracking-[0.25em] text-gild">WIKI</span>
          </button>
          <button
            onClick={() => setPalette(true)}
            className="ml-auto md:ml-8 flex items-center gap-2 px-3 py-1.5 rounded-sm border border-arcane/20 bg-vellum/50 text-mute hover:text-parch hover:border-arcane/40 transition-colors md:w-72"
          >
            <Search size={14} />
            <span className="hidden md:inline text-[12.5px]">搜索魔咒、物品、进度……</span>
            <kbd className="hidden md:inline ml-auto font-vt text-[14px] text-faint">⌘K</kbd>
          </button>
          <button
            onClick={onSwitch}
            className="md:ml-auto flex items-center gap-2 px-3 py-1.5 rounded-sm border border-gild/30 text-gild text-[12px] hover:bg-gild/10 transition-colors"
          >
            <ScrollText size={14} />
            <span className="hidden sm:inline">设计提案 & 审计报告</span>
          </button>
        </header>

        <div className="flex">
          <aside className="hidden lg:block sticky top-14 h-[calc(100vh-3.5rem)] w-56 shrink-0 border-r border-arcane/10 overflow-y-auto wiki-scroll p-3">
            <p className="font-pixel text-[9px] tracking-[0.25em] text-faint px-2.5 mb-2">目录</p>
            {Nav}
            <div className="mt-6 mx-2.5 p-3 rounded-sm bg-vellum/50 border border-arcane/10">
              <p className="text-[11px] text-faint leading-5">
                数据对齐 <code className="font-code text-arcane">89f545b</code>
                <br />
                MC 26.1.2 · Fabric
              </p>
            </div>
          </aside>

          <main className="flex-1 min-w-0 px-6 md:px-10 pt-6 pb-10 max-w-[1280px] mx-auto">
            <Home />
            <Recipes />
            <Library />
            <XpModes />
            <BookCare />
            <Grimoire />
            <Cleanse />
            <Epiphany />
            <Transmute />
            <Advancements />
            <Datapack />
            <Versions />
          </main>
        </div>

        <AnimatePresence>
          {menu && (
            <motion.div className="fixed inset-0 z-[110] lg:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="absolute inset-0 bg-black/60" onClick={() => setMenu(false)} />
              <motion.aside initial={{ x: -260 }} animate={{ x: 0 }} exit={{ x: -260 }} className="absolute left-0 top-0 bottom-0 w-64 bg-abyss border-r border-arcane/20 p-3 overflow-y-auto">
                <button className="mb-3 text-mute" onClick={() => setMenu(false)}>
                  <X size={20} />
                </button>
                {Nav}
              </motion.aside>
            </motion.div>
          )}
        </AnimatePresence>

        <Palette open={palette} onClose={() => setPalette(false)} />
      </div>
    </LibProvider>
  );
};

export default WikiApp;
