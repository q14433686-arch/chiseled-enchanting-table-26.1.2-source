import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  BadgeCheck,
  ChevronRight,
  FlaskConical,
  GitCompareArrows,
  Hammer,
  RotateCcw,
  Scale,
} from "lucide-react";
import {
  FOLLOW_UPS,
  FIX_META,
  FINDINGS2,
  SEV2_META,
  incrementalFloor,
  pointsForLevels,
  RESONANCE_JSON_KEYS,
  RESONANCE_JAVA_KEYS,
  type Finding2,
} from "../lib/audit2";
import { SectionHead, Reveal, Chip, Slider } from "./ui";

/* ── R2-1 交互演示：合并 vs 研究 ── */
const CombineDemo = () => {
  const [disc, setDisc] = useState(40);
  // 场景：锋利 M=5，III→IV，无母本；deltaRaw 取典型值 2（2→10 插值单步差）
  const floor = incrementalFloor(3, 4, 5, disc);
  const deltaRaw = 2;
  const baseD = Math.max(1, Math.floor(deltaRaw * (1 - disc / 100) + 0.5));
  const deducted = Math.max(baseD, floor.d);
  const required = Math.max(deducted, baseD, floor.req);
  const combinePts = pointsForLevels(required, required);
  const researchPts = pointsForLevels(required, deducted);

  return (
    <div className="pixelframe bg-vellum/70 border border-[#ff6b8a]/25 overflow-hidden">
      <div className="flex items-center justify-between px-6 md:px-8 py-4 border-b border-arcane/10">
        <p className="font-code text-[11px] tracking-[0.3em] text-[#ff6b8a] flex items-center gap-2">
          <Scale size={13} /> R2-1 REPRO · 合并扣费实算（锋利 III→IV，无母本）
        </p>
        <Chip tone="#ff6b8a">显示扣 {deducted} 级 · 实扣 {required} 级</Chip>
      </div>
      <div className="p-6 md:p-8 space-y-6">
        <Slider
          label="书库减免"
          value={disc}
          min={0}
          max={40}
          onChange={setDisc}
          format={(v) => `−${v}%`}
          accent="#e8c37c"
        />
        <div className="grid sm:grid-cols-3 gap-3">
          <div className="pixelframe bg-obsidian/60 border border-arcane/12 p-5 text-center">
            <p className="font-code text-[10px] text-faint mb-2">界面显示（两处相同）</p>
            <p className="font-display text-3xl font-black text-parch leading-none">
              {deducted} <span className="text-sm font-medium text-mute">级</span>
            </p>
            <p className="font-code text-[10px] text-faint mt-2">tooltip consumed = deductedLevels</p>
          </div>
          <motion.div
            key={`r-${researchPts}`}
            initial={{ scale: 0.97, opacity: 0.6 }}
            animate={{ scale: 1, opacity: 1 }}
            className="pixelframe bg-xp/5 border border-xp/25 p-5 text-center"
          >
            <p className="font-code text-[10px] text-faint mb-2">研究实扣</p>
            <p className="font-display text-3xl font-black text-xp leading-none">
              {deducted} <span className="text-sm font-medium text-mute">级</span>
            </p>
            <p className="font-code text-[10px] text-faint mt-2">{researchPts} 点 · 与显示一致 ✓</p>
          </motion.div>
          <motion.div
            key={`c-${combinePts}`}
            initial={{ scale: 0.97, opacity: 0.6 }}
            animate={{ scale: 1, opacity: 1 }}
            className="pixelframe bg-[#ff6b8a]/5 border border-[#ff6b8a]/30 p-5 text-center"
          >
            <p className="font-code text-[10px] text-faint mb-2">合并实扣</p>
            <p className="font-display text-3xl font-black text-[#ff6b8a] leading-none">
              {required} <span className="text-sm font-medium text-mute">级</span>
            </p>
            <p className="font-code text-[10px] text-faint mt-2">
              {combinePts} 点 · {(combinePts / Math.max(1, researchPts)).toFixed(1)}× 于研究
            </p>
          </motion.div>
        </div>
        <div className="rounded-sm bg-obsidian/60 border border-arcane/10 p-4 font-code text-[11.5px] leading-6 text-mute">
          <span className="text-faint">// BookUpgradeApplication.java:47 — 旧版 required≡deducted 时正确，分离后未同步</span>
          <br />
          int xpCost = handler.getEnchantmentXpLevelCost(ewl, <span className="text-gild">BOOK_COMBINE_UPGRADE</span>);
          <span className="text-faint ml-2">→ resolveXpRequirement(...).requiredLevel()</span>
          <br />
          <span className="text-faint">// ScreenHandler.java:1074 — 合并分支丢弃 0.6×</span>
          <br />
          effectiveRaw = (type == RESEARCH) ? min(rawCost, deltaRaw) : <span className="text-[#ff6b8a]">deltaRaw</span>;
          <span className="text-faint ml-2">← rawCost（含 0.6×）被丢弃</span>
        </div>
      </div>
    </div>
  );
};

/* ── R2-2 键名对照 ── */
const SchemaMismatch = () => {
  const [side, setSide] = useState<"json" | "java">("json");
  const keys = side === "json" ? RESONANCE_JSON_KEYS : RESONANCE_JAVA_KEYS;
  return (
    <div className="pixelframe bg-vellum/70 border border-[#ff6b8a]/25 overflow-hidden">
      <div className="flex items-center justify-between px-6 md:px-8 py-4 border-b border-arcane/10">
        <p className="font-code text-[11px] tracking-[0.3em] text-[#ff6b8a] flex items-center gap-2">
          <GitCompareArrows size={13} /> R2-2 EVIDENCE · 键名交集 = ∅
        </p>
        <div className="flex gap-2">
          {(["json", "java"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setSide(s)}
              className="px-3 py-1 rounded-sm text-[11px] font-code border transition-all"
              style={{
                color: side === s ? "#0a0913" : "#9c93bd",
                background: side === s ? "#e8c37c" : "transparent",
                borderColor: "#e8c37c44",
              }}
            >
              {s === "json" ? `JSON ${RESONANCE_JSON_KEYS.length} 键` : `Java ${RESONANCE_JAVA_KEYS.length} 键`}
            </button>
          ))}
        </div>
      </div>
      <div className="p-6 md:p-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={side}
            initial={{ opacity: 0, x: side === "json" ? -12 : 12 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="grid sm:grid-cols-2 gap-1.5 max-h-64 overflow-y-auto pr-1"
          >
            {keys.map((k) => (
              <div
                key={k}
                className="font-code text-[10.5px] px-3 py-1.5 rounded-sm bg-obsidian/60 border border-arcane/10 text-mute flex items-center gap-2"
              >
                <span className="w-1.5 h-1.5 rotate-45 bg-[#ff6b8a]/70 shrink-0" />
                <span className="break-all">{k}</span>
              </div>
            ))}
          </motion.div>
        </AnimatePresence>
        <p className="mt-5 text-[12px] leading-6 text-mute font-light">
          左边嵌套三段、右边扁平 22 键——包括
          <span className="font-code text-parch"> max_total_xp_discount_percent </span>
          在内没有一个键能对上（层级错位）。fromJson 全 Miss → 整份配置恒回落 DEFAULT。
          三层门禁（文件存在 / S2C 同步 / CI 断言 JSON 内值）全部放行。
        </p>
      </div>
    </div>
  );
};

const Finding2Card = ({ f, idx }: { f: Finding2; idx: number }) => {
  const [open, setOpen] = useState(idx < 2);
  const meta = SEV2_META[f.sev];
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: Math.min(idx * 0.04, 0.3) }}
      className="pixelframe bg-vellum/60 border overflow-hidden"
      style={{ borderColor: open ? `${meta.tone}44` : "rgba(161,140,255,0.12)" }}
    >
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center gap-3 md:gap-4 px-5 py-4 text-left hover:bg-vellum2/50 transition-colors"
      >
        <span
          className="font-code text-[10px] px-2 py-1 rounded-sm shrink-0 w-11 text-center"
          style={{ color: meta.tone, background: `${meta.tone}14`, border: `1px solid ${meta.tone}38` }}
        >
          {meta.label}
        </span>
        <span className="font-code text-[11px] text-faint shrink-0 w-9">{f.id}</span>
        <span className="flex-1 font-medium text-[13.5px] md:text-[14.5px] text-parch leading-5">
          {f.title}
        </span>
        <motion.span animate={{ rotate: open ? 90 : 0 }} className="shrink-0">
          <ChevronRight size={15} className="text-faint" />
        </motion.span>
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 pt-1 space-y-4 border-t border-arcane/10">
              <p className="font-code text-[10.5px] text-faint break-all pt-3">📍 {f.where}</p>
              {[
                { k: "现象", v: f.what, c: "#9c93bd" },
                { k: "为什么要紧", v: f.why, c: "#e8c37c" },
                { k: "建议", v: f.fix, c: "#8df0a4" },
              ].map((b) => (
                <div key={b.k} className="flex gap-3">
                  <span className="font-code text-[10px] tracking-wider shrink-0 w-14 pt-0.5" style={{ color: b.c }}>
                    {b.k}
                  </span>
                  <p className="text-[12.5px] leading-6.5 text-mute font-light flex-1">{b.v}</p>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

const AuditRound2 = () => {
  const [filter, setFilter] = useState<"all" | "high" | "medium" | "low">("all");
  const counts = useMemo(() => {
    const c: Record<string, number> = { all: FINDINGS2.length };
    FINDINGS2.forEach((f) => (c[f.sev] = (c[f.sev] ?? 0) + 1));
    return c;
  }, []);
  const shown = FINDINGS2.filter((f) => filter === "all" || f.sev === filter).sort(
    (a, b) => SEV2_META[a.sev].rank - SEV2_META[b.sev].rank,
  );

  return (
    <section id="audit2" className="relative max-w-6xl mx-auto px-6 md:px-10 py-24 md:py-32">
      <div
        className="absolute top-40 -left-20 font-display font-black text-[16rem] leading-none select-none pointer-events-none opacity-[0.035]"
        aria-hidden
      >
        复
      </div>

      <SectionHead
        numeral="复"
        kicker="CODE REVIEW ROUND 2 · 2f6979b → a45d319"
        accent="#7ee8dc"
        title={<>第二轮复审：<span className="text-tealw">7 修 1 变 2 敞口</span>，新增 9 条</>}
        blurb="修复提交 2f6979b（2442 行）回应了首轮几乎所有条目，态度拉满。但实测结论是：F1 的守恒修复是真的（本轮独立实算 391,680 项零违反），F5 的数据驱动修复是假的（三层门禁同时放行了一份不生效的配置），而 F2 从「成本模型对不上」变异成了「连被验对象都换了」。另有一处合并路线的三重回归故障是本次修复引入的。"
      />

      {/* 验证横幅 */}
      <Reveal>
        <div className="pixelframe bg-gradient-to-br from-vellum to-vellum2/60 border border-xp/25 p-7 md:p-8 mb-10">
          <div className="flex items-start gap-4">
            <FlaskConical className="text-xp shrink-0 mt-1" size={22} />
            <div className="w-full">
              <p className="font-display text-xl md:text-2xl font-bold text-parch leading-relaxed">
                独立复算：实装守恒成立 —— <span className="font-code text-xp">391,680</span> 项检查，
                <span className="text-xp"> 0 违反</span>
              </p>
              <p className="mt-3 text-sm leading-7 text-mute font-light">
                逐行复刻实装的 <span className="font-code text-parch">essencePotentialFromParams</span>
               （含 0.85 信用因子、5 点裕度、Java 半偶舍入），覆盖 M=1..255 × 铁砧 6 档 × 宝藏与否：
                全洗返还恒低于母本最低实付（最坏裕度 <span className="text-xp">7 点</span>），
                逐级降返恒低于对应增量成本（M≤40 全验 + 大 M 抽验，最坏裕度
                <span className="text-xp"> 5 点</span>）。F1 可以结案。
                但注意：守恒成立靠的是<span className="text-parch">归纳封顶构造</span>本身，
                CI 里那段 Python「证明」验的是另一套参数——见 R2-4。
              </p>
              <div className="mt-5 flex flex-wrap gap-2">
                <Chip tone="#8df0a4">F1 结案 ✓</Chip>
                <Chip tone="#8df0a4">telescoping 精确（max(1,·)→max(0,·)）</Chip>
                <Chip tone="#8df0a4">运行期自检探针 M∈{`{1..10,15,30,100,255}`}</Chip>
              </div>
            </div>
          </div>
        </div>
      </Reveal>

      {/* 首轮跟进矩阵 */}
      <Reveal>
        <div className="flex items-center gap-2 mb-5">
          <RotateCcw size={14} className="text-tealw" />
          <p className="font-code text-[11px] tracking-[0.3em] text-tealw">
            ROUND-1 FOLLOW-UP · 首轮 11 条去向
          </p>
        </div>
        <div className="grid md:grid-cols-2 gap-2.5 mb-10">
          {FOLLOW_UPS.map((f, i) => {
            const m = FIX_META[f.status];
            return (
              <motion.div
                key={f.id}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: Math.min(i * 0.04, 0.3), duration: 0.45 }}
                className="flex gap-3 items-start rounded-sm bg-vellum/60 border border-arcane/12 px-4 py-3"
              >
                <span className="font-code text-[11px] text-faint shrink-0 w-7 pt-0.5">{f.id}</span>
                <span
                  className="font-code text-[10px] px-2 py-0.5 rounded-sm shrink-0 whitespace-nowrap"
                  style={{ color: m.tone, background: `${m.tone}12`, border: `1px solid ${m.tone}35` }}
                >
                  {m.label}
                </span>
                <p className="text-[12px] leading-5.5 text-mute font-light flex-1">{f.note}</p>
              </motion.div>
            );
          })}
        </div>
      </Reveal>

      {/* R2-1 / R2-2 实证 */}
      <Reveal>
        <div className="mb-6">
          <CombineDemo />
        </div>
      </Reveal>
      <Reveal>
        <div className="mb-10">
          <SchemaMismatch />
        </div>
      </Reveal>

      {/* 新发现列表 */}
      <Reveal>
        <div className="flex flex-wrap items-center gap-2 mb-5">
          <Hammer size={14} className="text-mute mr-1" />
          {(["all", "high", "medium", "low"] as const).map((s) => {
            const tone = s === "all" ? "#a18cff" : SEV2_META[s].tone;
            const on = filter === s;
            return (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className="px-3.5 py-1.5 rounded-sm text-[11.5px] font-code border transition-all"
                style={{
                  color: on ? "#0a0913" : tone,
                  background: on ? tone : `${tone}0d`,
                  borderColor: `${tone}40`,
                }}
              >
                {s === "all" ? "全部" : SEV2_META[s].label} {counts[s] ?? 0}
              </button>
            );
          })}
        </div>
      </Reveal>
      <div className="space-y-2.5 mb-10">
        {shown.map((f, i) => (
          <Finding2Card key={f.id} f={f} idx={i} />
        ))}
      </div>

      {/* 收尾 */}
      <Reveal>
        <div className="pixelframe bg-gradient-to-br from-vellum to-vellum2/50 border border-gild/25 p-7 md:p-9">
          <p className="font-code text-[11px] tracking-[0.3em] text-gild mb-6">
            PRIORITY · 本轮如果只改三件事
          </p>
          <div className="space-y-4">
            {[
              {
                n: "壹",
                t: "先修 R2-1（合并三重故障）：它是回归，且每天都在多扣玩家经验",
                d: "两行改动：applyCombine 改扣 deductedLevels；合并分支 effectiveRaw 改 min(rawCost, deltaRaw)。再补一条 CI 断言锁死「合并费 ≤ 研究费」。这是本轮唯一在持续造成实际伤害的条目。",
                tone: "#ff6b8a",
              },
              {
                n: "贰",
                t: "再修 R2-2（共振配置零生效）：否则所有平衡讨论都是空谈",
                d: "fromJson 与 JSON 必须说同一种语言（二选一统一），然后补「全键消费覆盖率」CI 断言。在此之前，任何关于减免数值的调参结论都不可信——因为生效值恒为 DEFAULT。",
                tone: "#f08cc8",
              },
              {
                n: "叁",
                t: "把 CI 的 Python 复刻证明换成真货（R2-4）",
                d: "两轮了，CI 守恒门禁两次验的都不是实装。最干净的修法：删掉 Python 复刻，改为 Java 单测快照回归。退一步也要把参数逐项对齐并绑定行号注释。",
                tone: "#8df0a4",
              },
            ].map((r) => (
              <div key={r.n} className="flex gap-4">
                <span className="font-display font-black text-xl shrink-0 w-8 text-center" style={{ color: r.tone }}>
                  {r.n}
                </span>
                <div>
                  <p className="font-medium text-[14.5px] text-parch mb-1">{r.t}</p>
                  <p className="text-[12.5px] leading-6 text-mute font-light">{r.d}</p>
                </div>
              </div>
            ))}
          </div>
          <p className="mt-7 pt-5 border-t border-arcane/10 text-[11.5px] leading-6 text-faint font-light flex items-start gap-2">
            <BadgeCheck size={14} className="shrink-0 mt-1 text-xp" />
            <span>
              值得肯定的改进：三轨分离干净（白板/升阶/母本各有归属）、去重直接复用既有 Map、
              运行期守恒自检 fail-closed、LiveShelfState 变更门控推送、标签驱动扫描、ModBootstrapConfig 落盘干净、
              S2C 载荷正确扩展。本轮新增问题多为「修得太快」留下的接口错位，而非方向错误。
            </span>
          </p>
        </div>
      </Reveal>
    </section>
  );
};

export default AuditRound2;
