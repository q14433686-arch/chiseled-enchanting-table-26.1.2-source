// ─────────────────────────────────────────────────────────────
// 第二轮审查 · commit 2f6979b 之后 (HEAD a45d319)
// 首轮 11 条跟进 + 新增 9 条发现
// ─────────────────────────────────────────────────────────────

export type FixStatus = "fixed" | "mutated" | "open" | "taste" | "decorative";

export const FIX_META: Record<FixStatus, { label: string; tone: string }> = {
  fixed: { label: "已修复", tone: "#8df0a4" },
  mutated: { label: "变异未除", tone: "#f08cc8" },
  open: { label: "仍敞口", tone: "#ff6b8a" },
  decorative: { label: "装饰性修复", tone: "#ff6b8a" },
  taste: { label: "取向确认", tone: "#7ee8dc" },
};

export interface FollowUp {
  id: string;
  status: FixStatus;
  note: string;
}

export const FOLLOW_UPS: FollowUp[] = [
  { id: "F1", status: "fixed", note: "返还改为从成本曲线派生的归纳封顶（含 5 点安全裕度）+ 运行期自检。本轮实算 391,680 项零违反，最坏裕度 7 点。" },
  { id: "F2", status: "mutated", note: "Java 已向 CI 旧模型对齐（8+22r / 边界 0.75），但 CI 的守恒证明现在验的是另一套函数——见 R2-4。" },
  { id: "F3", status: "fixed", note: "改用按魔咒 ID 去重的 storedMasterLevels 统计。旧的按槽累加函数已无调用者，成为死代码。" },
  { id: "F4", status: "fixed", note: "三轨分离落地：白板 half_ceil 封顶 + 已持有升阶走全曲线 + 母本 1:1。M=2 合格线取 MAX（比建议更严，可接受）。" },
  { id: "F5", status: "decorative", note: "library_resonance.json 建了，但 fromJson 读的是另一套扁平键名——零键重叠，全部回落 DEFAULT。见 R2-2。" },
  { id: "F6", status: "fixed", note: "base_batch_size / tier3_batch_size 已进 shelf_gates.json。" },
  { id: "F7", status: "fixed", note: "扫描半径可配 + 容量按公式计算 + regular_bookshelves 标签。三处全改。" },
  { id: "F8", status: "open", note: "BUILT_IN_JSON 文本块副本仍在，CI 仍只验 schema 不验漂移。见 R2-9。" },
  { id: "F9", status: "fixed", note: "xp_refund_scale 上限收到 1.0，且返还侧二次钳制 + 运行期守恒自检。" },
  { id: "F10", status: "taste", note: "γ 取 1.25（更凸），M=5 阶梯 0/7/16/27/38。属取向选择，配合白板封顶后自洽。" },
  { id: "F11", status: "fixed", note: "22 个中间产物已删，.gitignore 已补，CI 新增 F11 门禁防回归。" },
];

export type Sev2 = "high" | "medium" | "low";

export const SEV2_META: Record<Sev2, { label: string; tone: string; rank: number }> = {
  high: { label: "高", tone: "#ff6b8a", rank: 0 },
  medium: { label: "中", tone: "#e8c37c", rank: 1 },
  low: { label: "低", tone: "#7ee8dc", rank: 2 },
};

export interface Finding2 {
  id: string;
  sev: Sev2;
  title: string;
  where: string;
  what: string;
  why: string;
  fix: string;
}

export const FINDINGS2: Finding2[] = [
  {
    id: "R2-1",
    sev: "high",
    title: "合并升级三重故障：0.6× 被旁路、按门槛扣费、显示与扣费不一致",
    where: "BookUpgradeApplication.java:47-50 / ScreenHandler.java:1055-1079",
    what: "① 合并必走 existingLevel>0 分支，该分支 effectiveRaw=deltaRaw（全额），第 1037 行算出的 0.6× rawCost 被直接丢弃——book_upgrades.json 的 combine 乘数对正常路径是死配置。② applyCombine 按 requiredLevel（门槛）扣若干整级，而研究/界面按 deductedLevels 扣/显示。③ 全奥术路径经 masterFloor 取 max 后 required≫deducted 成为常态。",
    why: "回归故障：旧版全奥术 required恒等于 deducted，所以按 required 扣是对的；本轮修复引入 required/deducted 分离后没同步改 applyCombine。实算锋利 III→IV（M=5，40% 减免）：masterFloor=(门槛 8，扣 1)，合并实扣 8 级、研究实扣 1~2 级、界面两处都显示「扣 1~2 级」。文档承诺的「零材料 + 0.6× 经验」路线实际变成全场最贵且货不对板。",
    fix: "① applyCombine 改用 xpReq.deductedLevels() 扣费（与研究同源）；② 合并分支 effectiveRaw 改用 min(rawCost, deltaRaw) 让 0.6× 生效；③ 在 CI 加一条「同升级合并费 ≤ 研究费」断言防回归。",
  },
  {
    id: "R2-2",
    sev: "high",
    title: "library_resonance.json 与 fromJson 的键名零重叠，整份配置不生效",
    where: "LibraryResonance.java:75-116 vs library_resonance.json",
    what: "JSON 用三段嵌套（wooden_bookshelves / chiseled_mastery / epiphany_affinity）共 13 个键；fromJson 在 root 层读 22 个扁平键（mastery_unit_exponent、incremental_step_credit_factor…）。两边键名交集为空——连 max_total_xp_discount_percent 都因嵌套层级错位而读不到。所有值恒回落 DEFAULT。",
    why: "F5 的修复是装饰性的：文件存在、S2C 同步了（同步的也只是 DEFAULT）、CI 只断言 JSON 里 max_total==40——三层检查全部放行了一个不生效的配置。服主照 WIKI 改 library_resonance.json 会发现什么都没变，这是对数据驱动承诺的直接伤害。附带：实际生效的 incremental 信用因子是 DEFAULT 的 0.85，而非 JSON 里的 0.35。",
    fix: "二选一：① 把 fromJson 改成读嵌套结构（推荐，与 shelf_gates/disenchanting 的分段风格一致）；② 把 JSON 拍平成 22 键。然后在 CI 加「JSON 全键被 fromJson 消费」覆盖率断言——本次三层门禁同时失守，缺的正是这一条。",
  },
  {
    id: "R2-3",
    sev: "medium",
    title: "activeConfig() 绕过 S2C 同步，5 处调用点在客户端用错常量",
    where: "LibraryResonance.java:137 起；调用点见正文",
    what: "activeConfig() 直接读 ChiseledEnchantingTableData 静态量——该静态量在专服客户端上永远不会被更新（payload 只写入 SyncedEnchantmentCosts）。handler 自身的 libraryResonanceConfig() 正确走了 synced 分支，但 5 处静态调用绕过了它：返还封顶 maxDiscount（Disenchant:107）、增量信用因子（XpCost:161）、减免钳制（XpCost:245）、handler 构造钳制（138）、运行期自检（139，后者在服务端，无碍）。",
    why: "后果是纯显示侧：服务端改了 max_total 或信用因子后，专服客户端的 JEI/REI 预览、返还点数预览、减免钳制全部按本地 DEFAULT（40 / 0.85）计算，与服务端实扣不一致。实际发放走服务端所以刷不出东西，但玩家看到的数字是错的——而本 mod 的核心卖点之一正是 JEI/REI 显示服务端真实价格。",
    fix: "给 activeConfig() 加 boolean isClientSide 参数（或拆 activeServerConfig/activeSyncedConfig），5 处调用点按执行侧选择数据源；XpCostConversion 的纯函数签名改为显式传 Config（handler 侧已有正确范例）。",
  },
  {
    id: "R2-4",
    sev: "medium",
    title: "CI 守恒证明与实装函数分叉：验的不是发的货",
    where: "scripts/compat_check.py:940-975 vs DisenchantmentApplication.java:94-133",
    what: "CI 的 build_potential_table 与实装 essencePotentialFromParams 处处不同：稀有度 1.0+0.14ln(min8,anvil)→1.30×1.12 vs 1.0+0.18ln(anvil)→1.45×1.15；base 30/40 vs 34/48；step 成本用 6+20r+span 档 vs 真实增量公式（含 0.85 信用）；无 5 点裕度；还多了一段实装没有的严格递增强制。实装侧现在靠运行期自检保护，CI 这段证明的是另一个函数。",
    why: "F2 的变异形态：上次是「成本模型对不上」，这次是「连被验对象都换了」。这段 CI 既不能为实装背书（参数全不同），失败时也不对应真实漏洞（上次 maxLevel 覆盖 1..10 的教训重演，只是换了个样子）。目前实装的真实保护是 verifyRuntimeConservation（12 个 M 探针）+ 本轮外部实算，全不在 CI 里。",
    fix: "① 首选：CI 改为运行 Java 单测/快照（用真实函数输出做回归基线），删掉 Python 复刻；② 退一步：把 Python 复刻的参数与实装逐项对齐并加注释绑定（注明对应 Java 行号），探针 M 覆盖 1..255 全量而非抽样。",
  },
  {
    id: "R2-5",
    sev: "medium",
    title: "WIKI §3 减免公式与实装四处脱节",
    where: "docs/WIKI.md:62-75 vs LibraryResonance.java:154-268",
    what: "① 木书架：WIKI 2%+⌊(W−12)/2⌋、32 架封顶 12% → 实装线性插值 round(1+11·(W−12)/26)，12 架=1%、38 架才满 12%。② 母本权重：0.45r+0.55r² → r^1.25。③ 公共：round(1.5E) → floor(1.25E)。④ 专属：round(15·r^1.5) → round(15·r) 线性。另：白板书按 0.5 权重计入顿悟亲和（旧版为 0），属未记录的行为变更。",
    why: "数值本身无对错（线性化后更易懂），但 WIKI 是玩家唯一的规则书：中期木书架减免被削弱（W=20：旧 6%→新 4%）且满额点后移到 38（与升阶 MAX 门槛耦合），玩家按 WIKI 配书架会发现减免对不上。修复提交声称“align WIKI”，但 §3 公式一条没改。",
    fix: "按实装重写 §3 四条公式并注明木书架满额 38；把白板书 0.5 亲和写进 §7；CI 加 WIKI 公式快照抽查（至少断言关键数字串存在）。",
  },
  {
    id: "R2-6",
    sev: "low",
    title: "顿悟概率的精通权重 0.45/0.85 硬编码，且与可配的 score 因子分裂",
    where: "LibraryResonance.java:335（epiphanyProbability）",
    what: "effectiveMastery = 0.45·E总 + 0.85·E亲和，两个权重是字面量。同一 Config 里 score 路径的对应因子（epiphany_global/affinity_mastery_score_factor = 2.2/3.5）却是可配的——同一对概念在概率路径不可配、在槽位路径可配。",
    why: "影响面小（默认 0.28+0.008/架+0.022/单位，上限 0.90 可达），但这是 F5 风格残留：上轮要求“共振系统可配”，本轮漏了这两个。且 R2-2 存在时连可配的那几个也不生效，问题叠加。",
    fix: "把 0.45/0.85 收进 Config（epiphany_probability_global/affinity_weight），默认保持现值。",
  },
  {
    id: "R2-7",
    sev: "low",
    title: "外部书源（村民/战利品）经免费转移 + 降级转为经验",
    where: "转移路径（0 费）× DOWNGRADE_ENCHANTMENT",
    what: "附魔书直接转移仍是 0 经验（仅消耗书）。村民交易/战利品获得的成品书 → 免费转到垃圾件 → 降级/全洗 → 返还 V（满级约 40~120 点）。成本基础是绿宝石而非经验，构成跨货币兑换。",
    why: "不是无限复制（每本书一次，村民补货有限），且重度打折村民本就是原版经济漏洞区。但治愈村民 1 绿宝石 1 本书 × 返还 40+ 点，长期服会有“书→经验”定向转化线。设计取舍问题，不是 bug。",
    fix: "可选：转移路径对非本台产出的书加收一次性手续费，或降级返还按 min(V, 本台铭刻成本) 封顶。后者需要书上打来源标记，成本较高；建议先观察。",
  },
  {
    id: "R2-8",
    sev: "low",
    title: "min_player_level 实为扣费下限且命名误导；经验之瓶扣费涨到 3 级",
    where: "XpCostConversion.forTransformation / experience_bottle（min 3, xp 2）",
    what: "min_player_level 实现为 max(1, level) 的扣费下限（deducted = max(min, round(raw·(1−disc)))），而非“使用门槛”。全库唯一用例经验之瓶：raw 2 + min 3 → 恒扣 3 级且门槛 3。旧 WIKI 写“扣 1 级”。",
    why: "机制自洽（要求与扣除相等），但命名会让数据包作者误以为它是门槛；瓶子 3 级换 3~11 点是纯经验销毁（只能做存取工具），与旧版经济位不同。行为变更未记录。",
    fix: "改名 min_deduction_levels（保留旧键别名兼容），并在 WIKI 置换表更新瓶子价格。或语义拆分为门槛 + 下限两个键。",
  },
  {
    id: "R2-9",
    sev: "low",
    title: "残留：死代码三件套、BUILT_IN_JSON 副本、客户端写死 12000L",
    where: "多处（见正文）",
    what: "① 旧按槽累加三函数（countQualifyingHighTierEnchantments / InShelf / isQualifyingHighTierBook）已无调用者，且 CI 还在用其中一个名字做存在性断言——删了会炸 CI，留着是死代码，互相锁死。② F8 的 disenchanting 文本块副本仍在且无漂移检查。③ handler 构造的 syncedCycleIndex 用 /12000L，而 cycle_ticks 已可配——改了周期的服客户端相位错乱（纯显示）。",
    why: "都是卫生问题，单个无害，但 ① 是个小陷阱：CI 把“函数名存在”当作“去重已实现”的代理，名字和实现互相绑架，下次重构必踩。",
    fix: "① 删死代码并把 CI 断言改为调真实函数（或断言新函数名）；② 构建期从 JSON 生成 fallback 或加漂移断言（同 F8 旧议）；③ cycle 指数改读 treasureEpiphanyRules.cycleTicks()。",
  },
];

// ── R2-1 演示：实装公式 TS 复刻（M=5 锋利 III→IV） ──
export const jround = (x: number): number => Math.floor(x + 0.5);
export const xpPts = (l: number): number =>
  l >= 30 ? 112 + (l - 30) * 9 : l >= 15 ? 37 + (l - 15) * 5 : 7 + Math.max(0, l) * 2;

export const tierOf = (level: number, M: number): number => {
  const cm = Math.max(1, M);
  if (cm <= 1) return 3;
  const r = Math.max(1, Math.min(level, cm)) / cm;
  return r <= 0.4 ? 1 : r <= 0.75 ? 2 : 3;
};

/** forIncrementalMasterTomeEnchant(a→k, rawCost=0) · credit 取实装 DEFAULT 0.85（JSON 读不到） */
export const incrementalFloor = (a: number, k: number, M: number, disc: number) => {
  const cm = Math.max(1, M);
  const delta = Math.max(1, k - Math.max(0, a));
  const tier = tierOf(delta, cm);
  const credit = 0.85;
  const tF = Math.min(cm, k) / cm;
  const pF = Math.min(cm, Math.max(0, a)) / cm;
  const rem = Math.max(0.15, tF - credit * pF);
  const rawT = Math.max(tier, jround(8 + 22 * rem));
  const req = Math.max(tier, jround(rawT * (1 - disc / 100)));
  return { raw: rawT, req, d: tier };
};

export const pointsForLevels = (playerLvl: number, n: number): number => {
  let s = 0;
  for (let i = 0; i < n; i++) s += xpPts(playerLvl - 1 - i);
  return s;
};

/** R2-2：键名对照（交集为空） */
export const RESONANCE_JSON_KEYS = [
  "wooden_bookshelves.min_discount_bookshelves",
  "wooden_bookshelves.base_discount_percent",
  "wooden_bookshelves.bookshelves_per_extra_percent",
  "wooden_bookshelves.max_discount_percent",
  "wooden_bookshelves.upgrade_material_multiplier",
  "chiseled_mastery.linear_weight",
  "chiseled_mastery.quadratic_weight",
  "chiseled_mastery.global_discount_per_unit",
  "chiseled_mastery.max_global_discount_percent",
  "chiseled_mastery.max_base_discount_percent",
  "chiseled_mastery.max_specific_discount_percent",
  "chiseled_mastery.specific_exponent",
  "chiseled_mastery.max_total_xp_discount_percent",
  "chiseled_mastery.upgrade_material_multiplier",
  "chiseled_mastery.incremental_threshold_credit_factor",
  "epiphany_affinity.affinity_chance_per_unit",
  "epiphany_affinity.global_slot_weight",
  "epiphany_affinity.affinity_slot_weight",
];

export const RESONANCE_JAVA_KEYS = [
  "min_discount_bookshelves",
  "max_discount_bookshelves",
  "max_wooden_discount_percent",
  "max_global_mastery_discount_percent",
  "max_base_xp_discount_percent",
  "max_specific_enchant_bonus_percent",
  "max_total_xp_discount_percent",
  "mastery_unit_exponent",
  "global_mastery_multiplier",
  "master_tome_upgrade_material_multiplier",
  "shelf_upgrade_material_multiplier",
  "epiphany_shelf_score_factor",
  "epiphany_global_mastery_score_factor",
  "epiphany_affinity_mastery_score_factor",
  "epiphany_tier2_max_prob",
  "epiphany_tier2_score_divisor",
  "epiphany_tier2_mastery_bonus",
  "epiphany_tier_plus_max_prob",
  "epiphany_tier_plus_score_divisor",
  "epiphany_tier_plus_mastery_bonus",
  "incremental_step_credit_factor",
];
