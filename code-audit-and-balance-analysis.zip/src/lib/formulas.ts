/**
 * 以下公式逐字对应仓库源码 / Wiki：
 *  - 抄错概率：InscriptionRitualMechanics.computeLoadSlipProbability
 *  - 藏书减免：docs/WIKI.md §3.1 / §3.2 与 library_resonance.json 默认值
 */

export const SLIP = {
  minLoad: 3.0,
  slope: 0.035,
  cap: 0.18,
  tiers: [
    { shelves: 42, bonus: 0.03 },
    { shelves: 38, bonus: 0.02 },
    { shelves: 32, bonus: 0.01 },
  ],
};

export function shelfBonus(shelves: number): number {
  for (const t of SLIP.tiers) if (shelves >= t.shelves) return t.bonus;
  return 0;
}

export function slipProbability(load: number, shelves: number): number {
  if (load + 1e-9 < SLIP.minLoad) return 0;
  const raw = SLIP.slope * Math.max(0, load - SLIP.minLoad) + shelfBonus(shelves);
  return Math.min(SLIP.cap, Math.max(0, raw));
}

/** 达到上限 cap 所需的负载 L */
export function loadToCap(shelves: number): number {
  return SLIP.minLoad + (SLIP.cap - shelfBonus(shelves)) / SLIP.slope;
}

/** 评分表：按源码 computeTraitQualificationScore 的规则计算。
 *  weight / supported 为原版近似值（以实际注册表为准），仅用于演示。 */
export interface TraitPreset {
  id: string;
  name: string;
  level: number;
  maxLevel: number;
  weight: number;
  broad: boolean; // supportedItems >= 12
  treasure: boolean;
  unbreaking?: boolean;
}

export const PRESETS: TraitPreset[] = [
  { id: "mending", name: "经验修补 I", level: 1, maxLevel: 1, weight: 2, broad: true, treasure: true },
  { id: "unb3", name: "耐久 III", level: 3, maxLevel: 3, weight: 5, broad: true, treasure: false, unbreaking: true },
  { id: "silk", name: "精准采集 I", level: 1, maxLevel: 1, weight: 1, broad: true, treasure: false },
  { id: "fortune3", name: "时运 III", level: 3, maxLevel: 3, weight: 2, broad: true, treasure: false },
  { id: "sharp5", name: "锋利 V", level: 5, maxLevel: 5, weight: 10, broad: true, treasure: false },
  { id: "eff5", name: "效率 V", level: 5, maxLevel: 5, weight: 10, broad: true, treasure: false },
  { id: "prot4", name: "保护 IV", level: 4, maxLevel: 4, weight: 10, broad: true, treasure: false },
  { id: "thorns3", name: "荆棘 III", level: 3, maxLevel: 3, weight: 1, broad: true, treasure: false },
  { id: "loot3", name: "抢夺 III", level: 3, maxLevel: 3, weight: 2, broad: false, treasure: false },
  { id: "frost2", name: "冰霜行者 II", level: 2, maxLevel: 2, weight: 2, broad: false, treasure: true },
  { id: "soul3", name: "灵魂疾行 III", level: 3, maxLevel: 3, weight: 1, broad: false, treasure: true },
  { id: "swift3", name: "迅捷潜行 III", level: 3, maxLevel: 3, weight: 1, broad: false, treasure: true },
  { id: "wind3", name: "风爆 III", level: 3, maxLevel: 3, weight: 2, broad: false, treasure: true },
  { id: "knock1", name: "击退 I", level: 1, maxLevel: 2, weight: 5, broad: false, treasure: false },
  { id: "bane1", name: "节肢杀手 I", level: 1, maxLevel: 5, weight: 5, broad: false, treasure: false },
];

export function traitScore(t: TraitPreset): number {
  let s = 0;
  if (t.treasure) s += 1.0;
  if (t.weight <= 2) s += 1.0;
  else if (t.weight <= 5) s += 0.5;
  if (t.broad) s += 0.5;
  if (t.level / Math.max(1, t.maxLevel) + 1e-9 >= 0.6) s += 0.5;
  if (t.unbreaking && t.level >= 3) s += 1.0;
  return s;
}

/** computeInfinityTomeQualificationLoad：任意宝藏 ⇒ 至少 3.0 */
export function bookLoad(traits: TraitPreset[]): number {
  if (traits.length === 0) return 0;
  let total = 0;
  let hasTreasure = false;
  for (const t of traits) {
    if (t.treasure) hasTreasure = true;
    total += traitScore(t);
  }
  if (hasTreasure) total = Math.max(total, 3.0);
  return total;
}

/* ───── 藏书减免 ───── */
export function woodenDiscount(w: number): number {
  if (w < 12) return 0;
  const t = Math.min(1, Math.max(0, (w - 12) / (38 - 12)));
  return Math.round(1 + 14 * t);
}

export function globalMastery(e: number): number {
  return Math.min(20, Math.floor(1.25 * e));
}

export function totalDiscount(w: number, e: number, r: number): number {
  const pub = Math.min(35, woodenDiscount(w) + globalMastery(e));
  const spec = Math.round(15 * r);
  return Math.min(40, pub + spec);
}

/** 原版升级所需点数（每级） */
export function pointsPerLevel(level: number): number {
  if (level <= 15) return 2 * level + 7;
  if (level <= 30) return 5 * level - 38;
  return 9 * level - 158;
}
