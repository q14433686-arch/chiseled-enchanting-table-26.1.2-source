import type { ReactNode } from "react";
import { cn } from "../utils/cn";
import type { Confidence, Severity } from "../data/findings";

export const SEV_META: Record<Severity, { label: string; cls: string }> = {
  high: { label: "高", cls: "bg-rose-500/15 text-rose-300 ring-rose-400/40" },
  med: { label: "中", cls: "bg-amber-500/15 text-amber-300 ring-amber-400/40" },
  low: { label: "低", cls: "bg-sky-500/15 text-sky-300 ring-sky-400/40" },
};

export const CONF_META: Record<Confidence, { label: string; cls: string }> = {
  confirmed: { label: "已证实", cls: "bg-emerald-500/15 text-emerald-300 ring-emerald-400/40" },
  inferred: { label: "推断", cls: "bg-violet-500/15 text-violet-300 ring-violet-400/40" },
  "needs-test": { label: "待实测", cls: "bg-fuchsia-500/15 text-fuchsia-300 ring-fuchsia-400/40" },
};

export function Pill({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ring-inset",
        className
      )}
    >
      {children}
    </span>
  );
}

export function SectionTitle({
  kicker,
  title,
  children,
}: {
  kicker?: string;
  title: string;
  children?: ReactNode;
}) {
  return (
    <div className="mb-5">
      {kicker && (
        <div className="mb-1 text-xs font-semibold uppercase tracking-[0.2em] text-amber-400/80">
          {kicker}
        </div>
      )}
      <h2 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">{title}</h2>
      {children && <p className="mt-2 max-w-3xl text-sm leading-relaxed text-slate-400">{children}</p>}
    </div>
  );
}

export function Card({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-white/10 bg-white/[0.03] p-5 shadow-lg shadow-black/20 backdrop-blur",
        className
      )}
    >
      {children}
    </div>
  );
}

type Tone = "amber" | "rose" | "emerald" | "sky" | "violet";
const TONES: Record<Tone, string> = {
  amber: "border-amber-400/30 bg-amber-400/[0.07] text-amber-100",
  rose: "border-rose-400/30 bg-rose-400/[0.07] text-rose-100",
  emerald: "border-emerald-400/30 bg-emerald-400/[0.07] text-emerald-100",
  sky: "border-sky-400/30 bg-sky-400/[0.07] text-sky-100",
  violet: "border-violet-400/30 bg-violet-400/[0.07] text-violet-100",
};

export function Callout({
  tone = "amber",
  title,
  children,
}: {
  tone?: Tone;
  title?: string;
  children: ReactNode;
}) {
  return (
    <div className={cn("rounded-xl border p-4 text-sm leading-relaxed", TONES[tone])}>
      {title && <div className="mb-1 font-semibold">{title}</div>}
      <div className="opacity-90">{children}</div>
    </div>
  );
}

export function Code({ children }: { children: ReactNode }) {
  return (
    <code className="rounded bg-black/40 px-1.5 py-0.5 font-mono text-[12px] text-amber-200">
      {children}
    </code>
  );
}

export function Slider({
  label,
  value,
  min,
  max,
  step = 1,
  onChange,
  suffix,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  suffix?: string;
}) {
  return (
    <label className="block">
      <div className="mb-1 flex items-baseline justify-between text-xs text-slate-400">
        <span>{label}</span>
        <span className="font-mono text-sm text-amber-300">
          {value}
          {suffix}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/10 accent-amber-400"
      />
    </label>
  );
}

export function Meter({
  value,
  max,
  tone = "amber",
}: {
  value: number;
  max: number;
  tone?: "amber" | "rose" | "emerald";
}) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const bar = tone === "rose" ? "bg-rose-400" : tone === "emerald" ? "bg-emerald-400" : "bg-amber-400";
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-white/10">
      <div className={cn("h-full rounded-full transition-all", bar)} style={{ width: `${pct}%` }} />
    </div>
  );
}
