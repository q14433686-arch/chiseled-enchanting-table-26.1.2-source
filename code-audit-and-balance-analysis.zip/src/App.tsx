import { useCallback, useEffect, useState } from "react";
import AuditPage from "./pages/AuditPage";
import DebatePage from "./pages/DebatePage";
import AdvicePage from "./pages/AdvicePage";
import { cn } from "./utils/cn";

type PageId = "audit" | "debate" | "advice";

const TABS: { id: PageId; label: string; sub: string }[] = [
  { id: "audit", label: "审计报告", sub: "七条路径 + 数值" },
  { id: "debate", label: "论点分析", sub: "矛盾？超级书？" },
  { id: "advice", label: "怀疑与建议", sub: "路线图 + 验证" },
];

const REPO =
  "https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/tree/arena%2F2d61e52c-chiseled-enchanting-table-26-1";

function readHash(): PageId {
  const h = window.location.hash.replace("#/", "").replace("#", "");
  return h === "debate" || h === "advice" ? h : "audit";
}

export default function App() {
  const [page, setPage] = useState<PageId>(readHash);

  useEffect(() => {
    const onHash = () => setPage(readHash());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const go = useCallback((p: PageId) => {
    window.location.hash = `#/${p}`;
    setPage(p);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 antialiased">
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(60%_50%_at_20%_0%,rgba(139,92,246,0.18),transparent),radial-gradient(50%_40%_at_90%_10%,rgba(251,191,36,0.10),transparent)]" />

      <header className="sticky top-0 z-30 border-b border-white/10 bg-slate-950/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-2.5">
          <button onClick={() => go("audit")} className="flex items-center gap-2.5 text-left">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-amber-300 to-fuchsia-500 text-sm font-black text-slate-900">
              纂
            </span>
            <span className="hidden sm:block">
              <span className="block text-sm font-bold leading-tight text-white">Chiseled Enchanting Table</span>
              <span className="block text-[11px] leading-tight text-slate-500">26.1.2 unofficial port · 审计</span>
            </span>
          </button>

          <nav className="ml-auto flex gap-1">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => go(t.id)}
                className={cn(
                  "rounded-lg px-3 py-1.5 text-left transition",
                  page === t.id ? "bg-white/10 text-white" : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
                )}
              >
                <span className="block text-sm font-semibold leading-tight">{t.label}</span>
                <span className="hidden text-[10px] leading-tight text-slate-500 md:block">{t.sub}</span>
              </button>
            ))}
          </nav>
          <a
            href={REPO}
            target="_blank"
            rel="noreferrer"
            className="hidden rounded-lg border border-white/15 px-3 py-1.5 text-xs text-slate-300 hover:bg-white/10 lg:block"
          >
            仓库 ↗
          </a>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-10">
        {page === "audit" && <AuditPage onNavigate={go} />}
        {page === "debate" && <DebatePage />}
        {page === "advice" && <AdvicePage />}
      </main>

      <footer className="border-t border-white/10 py-8 text-center text-xs text-slate-500">
        静态审计 · 未编译未进游戏 · 所有「待实测」条目请当作测试用例而非结论
      </footer>
    </div>
  );
}
