import { useMemo, useState } from "react";
import { Callout, Card, Code, Pill, SectionTitle, Slider } from "../components/ui";
import { cn } from "../utils/cn";

const DOUBTS: { t: string; why: string; how: string }[] = [
  {
    t: "「CI 全绿」证明的比看上去少",
    why: "绿的是 compileJava + compileClientJava，加一次专用服务器冒烟启动（server-smoke.log）。NEXT_TASK 自己写着「1.0.3 的同步还没有进过真实客户端」，且测试者的客户端曾在第一帧因 Iris/Distant Horizons 不兼容而崩溃。1.1.0 又新增了大量自绘 GUI（Screen 1.9k + Grimoire 1.7k + 列表 1.5k 行），这些全部没有任何自动化覆盖。",
    how: "补一套 Fabric GameTest（附魔台开屏、点击行、叠层输入）+ 一次带截图的人工 smoke，并把「在真实客户端跑过」作为发布门槛。",
  },
  {
    t: "测试保护的不一定是生产在用的代码",
    why: "DepletedTomeWorldMechanics 的 5 个分类方法、ConfigCatalog.byKey/resetAll 等只被测试引用（D-02）。1859 行的 EconomyAndConfigVerificationTest 很用心，但它主要验证「公式自洽 / 守恒」，而不是「玩家实际遇到的路径」。",
    how: "做一次覆盖率交叉：把「仅测试覆盖」的方法列出来，逐个决定是接进生产还是删掉。",
  },
  {
    t: "数值的事实源是对的，文档不是",
    why: "BundledDefaults 由 JSON 生成并被 CI 比对，这很好；但 Wiki 手写，已经出现 3.3× 的温养差、18% vs 20%、55 vs 63 项（H-01/02/04）。写下 Wiki 的人和调参数的人很可能已经不是同一个人（或同一轮）。",
    how: "Wiki 里的数字段落全部由脚本从 JSON 渲染，CI 里 diff。",
  },
  {
    t: "配置面太大，组合无法被推理",
    why: "63 项 ConfigCatalog + 11 份数据包 JSON + pack_policy + 7 条父子联动 + 重复键（max_*_slip_chance 两个）。服主调其中任一项，都很难预知它与「磨损/再生/折扣/惩罚」其他项的乘性后果——而这个仓库的核心风险恰恰是乘性塌缩。",
    how: "提供 3 档预设（原版感 / 默认 / 创造向）而不是 63 个旋钮；每次发布附带「默认值下的经济快照」。",
  },
  {
    t: "全局 Mixin 的外溢",
    why: "铁砧平摊成本影响所有物品（M-02）、ContainerHelper 全局拦截（M-01）、结构 Processor 对所有模板池追加（M-04）、砂轮结果槽被替换（M-03）。每一项单独看都有配置开关，但整合包里与其他 mod 同时存在时没有兼容矩阵。",
    how: "发布前对 Top 20 的整合包 mod（含铁砧/砂轮/结构类）跑一次启动 + 开屏 smoke；把全局性改动在文档开头单独列出。",
  },
  {
    t: "概念负担超出了「增强附魔」本身",
    why: "广义书架、雕纹母本、褪魔残卷、深层铭刻、宝藏顿悟、温养、献祭、超载、抄错、锁定……玩家要理解的名词比上游多一个数量级。内置《纂刻秘典》是在为此买单，但这说明玩法复杂度本身就是成本。",
    how: "把「首次游玩 30 分钟」可见的机制限制在 3 个以内，其余用进度（advancement）逐步解锁（仓库已有此机制，可以更激进）。",
  },
  {
    t: "「无限」的稀缺性只押在一次掉落上",
    why: "整个防线是：第一本无限书只能来自战利品。拿到之后可无损复制（B-03）。多人服里这是单点失败。",
    how: "把「世代」引入免疫（见 P1-5），让稀缺性随复制而衰减，而不是只在入口。",
  },
  {
    t: "我对自己的审计也有怀疑",
    why: "我只读了相关片段，没读全 37k 行；没编译、没进游戏；死代码用的是名字计数启发式；评分计算器里的原版 weight/适用面是近似；Mixin 的 M-01 是「若 26.1.2 的 Inventory 走 ContainerHelper」的条件命题。我也曾怀疑 all_enchant_book 成就不可达，核对后排除（D-04）。",
    how: "请把标「待实测」的条目当作测试用例，而不是结论。",
  },
];

interface Rec {
  id: string;
  pri: "P0" | "P1" | "P2";
  effort: "S" | "M" | "L";
  title: string;
  why: string;
  steps: string[];
  code?: string;
  refs: string[];
}

const RECS: Rec[] = [
  {
    id: "P0-1",
    pri: "P0",
    effort: "S",
    title: "修握手探测：不再逐版本枚举",
    why: "N-01：11–13 被漏掉，旧客户端既不被踢也收不到数据。逐版本枚举注定每个版本都要补一次。",
    steps: [
      "把所有历史 cost 通道改为「前缀探测」：遍历对端已注册的通道标识，凡以 enchant_cost_table 开头且不等于当前通道，即视为「装了旧版本」。",
      "保留 MISMATCH_MESSAGE，并附上对端检测到的修订号，便于排障。",
    ],
    code: `// EnchantCostSync
private static boolean peerHasAnyCostChannel(ServerPlayer p) {
  return ServerPlayNetworking.getSendable(p).stream()
      .anyMatch(id -> id.getNamespace().equals(MOD_ID)
                   && id.getPath().startsWith("enchant_cost_table"));
}`,
    refs: ["N-01", "D-03"],
  },
  {
    id: "P0-2",
    pri: "P0",
    effort: "S",
    title: "把附魔书堆叠上限纳入握手",
    why: "N-02：服务器与客户端各读各的本地配置，不一致会导致物品回弹/幽灵堆叠。",
    steps: [
      "Capability 载荷携带 enchanted_book_stack_size。",
      "JOIN 时比较：不一致则断开并提示「请同步配置」，而不是静默继续。",
    ],
    code: `public record Capability(int bookStackSize) implements CustomPacketPayload { … }
// JOIN: if (cap.bookStackSize() != local) disconnect("enchanted_book_stack_size mismatch: " + …)`,
    refs: ["N-02"],
  },
  {
    id: "P0-3",
    pri: "P0",
    effort: "M",
    title: "先实机验证、再收窄 LockedBookContainerMixin",
    why: "M-01 是静态阅读里风险最高的一条，且代价很小就能验证。",
    steps: [
      "复现：锁一本磨损的书 → 敲掉书架 → 拾取 → 在背包/箱子/末影箱里点击移动。",
      "不管结果如何：物品离开 ChiseledBookShelfBlockEntity 时清锁（或在 removeItem 里清）。",
      "Mixin 里增加调用来源判断，只拦截来自雕纹书架 BE 与漏斗的路径。",
    ],
    refs: ["M-01"],
  },
  {
    id: "P0-4",
    pri: "P0",
    effort: "S",
    title: "统一「无限」的判定：全部走 #wear_immune",
    why: "H-07：免疫走标签、罚则走字面 ID，数据包扩展会把两者拆开。",
    steps: [
      "computeInfinityTomeQualificationLoad 的 hasInf 改为：书上是否有任一 wear_immune 标签内的附魔。",
      "村民清洗、强跳 70% 上限同样改为标签判断。",
    ],
    refs: ["H-07"],
  },
  {
    id: "P1-5",
    pri: "P1",
    effort: "M",
    title: "重做「无限」：把二元免疫改成连续曲线 + 世代衰减 + 总量计分",
    why: "B-01/02/03 是同一个问题的三个侧面：免疫是整本二元的，罚则饱和且按单本计分，复制无损。三选一都不够，推荐组合 (a)+(b)+(c)。",
    steps: [
      "(a) 免疫曲线：N 为书上非诅咒附魔条数。N≤K 时 100% 豁免；之后每多一条豁免概率下降 s；下限取现有的 unbreaking_waiver_max_chance（0.3）。超级书自然退化成「耐久 III 级别」的收益。",
      "(b) 总量计分：对范围内所有无限书求 ΣL，而不是逐本 L；拆书无益。惩罚上限提高，且在 L 饱和后仍随条数缓慢增长。",
      "(c) 世代衰减：无限书的拷贝世代 g>G 时失去免疫（TomeWearData 已有 generation 字段，hasWearImmunity 直接读它即可）。",
    ],
    code: `waiver(N, g) =
  g > G            ? baseWaiver
  N <= K           ? 1.0
  : max(floor, 1.0 - s * (N - K))      // floor = unbreaking_waiver_max_chance`,
    refs: ["B-01", "B-02", "B-03", "H-03"],
  },
  {
    id: "P1-6",
    pri: "P1",
    effort: "S",
    title: "DISENCHANT_ALL 增加确认",
    why: "G-01：一次误点就能把一本多附魔书洗成褪魔残卷。",
    steps: ["目标为附魔书且附魔条数 ≥3，或书带 wear_immune 时，要求 Shift+点击或二次确认条目。", "确认状态在 2 秒后自动失效。"],
    refs: ["G-01"],
  },
  {
    id: "P1-7",
    pri: "P1",
    effort: "S",
    title: "文档由 JSON 渲染并在 CI 里 diff",
    why: "H-01/02/04：事实源是 JSON，文档是手写。仓库已有 gen_bundled_defaults.py 与 ci_static_checks 的比对模式，直接复用。",
    steps: ["Wiki 的数字表由 scripts/render_wiki_numbers.py 从 library_resonance.json / shelf_gates.json 生成。", "ci_static_checks 里增加字节比对；NEXT_TASK 的版本号纳入 check_release_consistency.sh。"],
    refs: ["H-01", "H-02", "H-04", "K-04"],
  },
  {
    id: "P1-8",
    pri: "P1",
    effort: "M",
    title: "数据驱动残余常量；守恒自检全量化并可 fail-closed",
    why: "H-06 / H-08：210 秒与 17 个采样点。",
    steps: ["ritual.rush_degrade_time_constant_seconds 进 JSON 与 payload。", "自检遍历 maxLevel=1..255；新增 strict_conservation：违反时关闭退魔返还。"],
    refs: ["H-06", "H-08"],
  },
  {
    id: "P1-9",
    pri: "P1",
    effort: "M",
    title: "载荷：命名子 codec + schema hash；单一权威通道",
    why: "C-01 / C-02：~60 个位置式字段、两条通道同步同一份配置。",
    steps: ["每个子配置一个 record + StreamCodec；总载荷由它们组合。", "头部放一个由字段名/类型生成的 8 字节 schema hash，客户端不一致即拒收。", "RuntimeConfig JSON 仅用于 UI；JEI/秘典用的二进制仅发 hash 对账。"],
    refs: ["C-01", "C-02"],
  },
  {
    id: "P2-10",
    pri: "P2",
    effort: "M",
    title: "Mixin 分级：核心 require=1，其余 require=0 + 启动自检",
    why: "A-01：一次小版本热修就让整个 mod 起不来。",
    steps: ["把结构/村民/砂轮/铁砧拆到第二个 mixins.json，defaultRequire=0。", "启动日志打印每个 Mixin 的生效状态；放宽 minecraft 依赖到 26.1.x 并保留自检。"],
    refs: ["A-01", "M-02", "M-03", "M-04"],
  },
  {
    id: "P2-11",
    pri: "P2",
    effort: "S",
    title: "死代码与测试对齐",
    why: "D-01 / D-02 / D-03。",
    steps: ["删除 28 个无调用方方法（IDE 复核后）、ModBootstrapConfig、无用探测常量。", "让「仅测试引用」的方法被生产路径调用，或连同测试一并删除。"],
    refs: ["D-01", "D-02", "D-03"],
  },
  {
    id: "P2-12",
    pri: "P2",
    effort: "L",
    title: "拆分上帝类，给配置一个原子快照",
    why: "K-01 / K-02 / K-03。",
    steps: ["ChiseledEnchantingTableData 的 30+ volatile 合并成一个 Snapshot 引用，重载时原子替换。", "引入 ConfigView 接口，服务端/客户端各自实现；规则层不再 import net.minecraft.server。"],
    refs: ["K-01", "K-02", "K-03"],
  },
  {
    id: "P2-13",
    pri: "P2",
    effort: "S",
    title: "头号平衡实验：砂轮回路 + 无限世代",
    why: "B-08：用 headless 模拟枚举（附魔 × 等级）确认是否有正回路；若有，给砂轮的附魔书经验乘来源系数。",
    steps: ["脚本化：对每个 (附魔, 等级, k, 小数) 计算铭刻点数 vs 砂轮期望。", "同时把 N-03 的每秒构建改为事件驱动。"],
    refs: ["B-08", "N-03"],
  },
];

const CHECKLIST: { id: string; t: string; ref: string }[] = [
  { id: "c1", t: "锁定一本磨损的书 → 敲掉书架 → 拾取 → 在背包/箱子/末影箱点击移动", ref: "M-01" },
  { id: "c2", t: "用 revision 11–13 的旧客户端连入，观察是否被踢及提示", ref: "N-01" },
  { id: "c3", t: "服务端 stack=16，客户端默认 64：Shift 点击与合并是否回弹", ref: "N-02" },
  { id: "c4", t: "数据包把锋利加入 #wear_immune：该书是否 0 磨损且无抄错", ref: "H-07" },
  { id: "c5", t: "超级书（≥30 条）+ 42 架，连续 100 次铭刻统计抄错率是否 ≈18%", ref: "B-02" },
  { id: "c6", t: "拆成 L<3 的小书，同样 100 次统计，抄错率是否为 0（非宝藏书）", ref: "B-02" },
  { id: "c7", t: "L≤13 玩家：量产一本锋利 V → 砂轮磨掉，经验净值", ref: "B-08" },
  { id: "c8", t: "误点 DISENCHANT_ALL：多附魔书是否被洗成残卷、返还多少经验", ref: "G-01" },
  { id: "c9", t: "装 200+ 附魔的整合包，悬停列表时的帧率", ref: "G-02" },
  { id: "c10", t: "与其他铁砧 / 砂轮 mod 同装，Mixin 是否互相覆盖", ref: "M-02/03" },
  { id: "c11", t: "回滚区域文件（不回滚 data/ 目录），温养进度是否错配", ref: "C-03" },
  { id: "c12", t: "模拟 50 个假玩家，观察 EnchantCostSync 每秒耗时", ref: "N-03" },
];

export default function AdvicePage() {
  return (
    <div className="space-y-14">
      <header>
        <div className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-amber-400/80">Page 3 · 怀疑与建议</div>
        <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">中肯的怀疑，以及可以今天就开始做的事</h1>
        <p className="mt-4 max-w-3xl text-slate-300">
          这个仓库的工程文化并不差：有审计编号（MX-04、NET-03）、有静态闸门、有专用服冒烟、有原子写入。
          我的怀疑不是「它很烂」，而是<b>「它宣称的确定性比它验证过的要多」</b>。下面先说怀疑，再给一份带优先级的建议，最后是一张实机验证清单。
        </p>
      </header>

      <section>
        <SectionTitle kicker="Skepticism" title="8 个中肯的怀疑" />
        <div className="grid gap-4 md:grid-cols-2">
          {DOUBTS.map((d, i) => (
            <Card key={d.t} className="flex flex-col gap-3">
              <div className="flex items-start gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-amber-400/15 font-mono text-xs font-bold text-amber-300">
                  {i + 1}
                </span>
                <h3 className="text-[15px] font-bold leading-snug text-white">{d.t}</h3>
              </div>
              <p className="text-sm leading-relaxed text-slate-300">{d.why}</p>
              <div className="mt-auto rounded-lg border border-emerald-400/20 bg-emerald-400/[0.05] p-3 text-xs leading-relaxed text-emerald-100/90">
                <b className="text-emerald-300">怎么消除：</b>
                {d.how}
              </div>
            </Card>
          ))}
        </div>
      </section>

      <section className="space-y-5">
        <SectionTitle kicker="Roadmap" title="按优先级的建议">
          P0 = 是 Bug 或可能卡物品，改动小；P1 = 数值/文档/编解码的结构性问题；P2 = 韧性与可维护性。S/M/L 是我对工作量的粗估。
        </SectionTitle>
        <RoadmapList />
      </section>

      <WaiverPreview />

      <Checklist />

      <Callout tone="violet" title="如果只做三件事">
        <ol className="list-decimal space-y-1 pl-5">
          <li>
            <b>P0-3</b>：花半小时实机验证锁定书能否离架后取出——它是我最担心的、也最便宜的验证。
          </li>
          <li>
            <b>P1-5</b>：把「无限」从二元免疫改成曲线 + 世代衰减。它同时回答了你在第二页那两个问题。
          </li>
          <li>
            <b>P1-7</b>：让 Wiki 的数字从 JSON 渲染。其他所有「数值争论」都建立在文档是对的这个前提上。
          </li>
        </ol>
      </Callout>
    </div>
  );
}

function RoadmapList() {
  const [filter, setFilter] = useState<"all" | "P0" | "P1" | "P2">("all");
  const [open, setOpen] = useState<Set<string>>(new Set(["P0-1", "P1-5"]));
  const list = RECS.filter((r) => filter === "all" || r.pri === filter);
  const priCls = {
    P0: "bg-rose-500/15 text-rose-300 ring-rose-400/40",
    P1: "bg-amber-500/15 text-amber-300 ring-amber-400/40",
    P2: "bg-sky-500/15 text-sky-300 ring-sky-400/40",
  };
  return (
    <div>
      <div className="mb-4 flex gap-2">
        {(["all", "P0", "P1", "P2"] as const).map((p) => (
          <button
            key={p}
            onClick={() => setFilter(p)}
            className={cn(
              "rounded-full border px-3 py-1 text-xs",
              filter === p
                ? "border-amber-400 bg-amber-400 font-semibold text-slate-900"
                : "border-white/15 bg-white/5 text-slate-300 hover:bg-white/10"
            )}
          >
            {p === "all" ? "全部" : p}
          </button>
        ))}
      </div>
      <div className="space-y-3">
        {list.map((r) => {
          const isOpen = open.has(r.id);
          return (
            <div key={r.id} className={cn("overflow-hidden rounded-2xl border bg-white/[0.03]", isOpen ? "border-amber-400/30" : "border-white/10")}>
              <button
                className="flex w-full items-start gap-3 p-4 text-left"
                onClick={() =>
                  setOpen((s) => {
                    const n = new Set(s);
                    if (n.has(r.id)) n.delete(r.id);
                    else n.add(r.id);
                    return n;
                  })
                }
              >
                <span className="mt-0.5 font-mono text-xs text-slate-500">{r.id}</span>
                <div className="flex-1">
                  <div className="font-semibold text-white">{r.title}</div>
                  <div className="mt-1.5 flex flex-wrap gap-1.5">
                    <Pill className={priCls[r.pri]}>{r.pri}</Pill>
                    <Pill className="bg-white/5 text-slate-300 ring-white/15">工作量 {r.effort}</Pill>
                    {r.refs.map((x) => (
                      <Pill key={x} className="bg-black/30 font-mono text-slate-400 ring-white/10">
                        {x}
                      </Pill>
                    ))}
                  </div>
                </div>
                <span className={cn("mt-1 text-slate-500 transition", isOpen && "rotate-90")}>▸</span>
              </button>
              {isOpen && (
                <div className="space-y-3 border-t border-white/10 bg-black/20 p-4 text-sm">
                  <p className="leading-relaxed text-slate-300">
                    <b className="text-slate-100">为什么：</b>
                    {r.why}
                  </p>
                  <ol className="list-decimal space-y-1.5 pl-5 leading-relaxed text-slate-300">
                    {r.steps.map((s, i) => (
                      <li key={i}>{s}</li>
                    ))}
                  </ol>
                  {r.code && (
                    <pre className="overflow-auto rounded-lg bg-black/50 p-3 font-mono text-[12px] leading-relaxed text-amber-100/90">{r.code}</pre>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* 免疫曲线预览（P1-5 (a)） */
function WaiverPreview() {
  const [K, setK] = useState(4);
  const [s, setS] = useState(0.06);
  const [floor, setFloor] = useState(0.3);
  const [N, setN] = useState(14);

  const f = (n: number) => (n <= K ? 1 : Math.max(floor, 1 - s * (n - K)));
  const W = 560;
  const H = 180;
  const maxN = 45;
  const pts = useMemo(() => {
    const out: string[] = [];
    for (let n = 0; n <= maxN; n++) {
      const x = 30 + (n / maxN) * (W - 50);
      const y = 12 + (1 - f(n)) * (H - 36);
      out.push(`${x.toFixed(1)},${y.toFixed(1)}`);
    }
    return out.join(" ");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [K, s, floor]);

  const curX = 30 + (N / maxN) * (W - 50);
  const curY = 12 + (1 - f(N)) * (H - 36);
  const wearPerUse = 1 - f(N);

  return (
    <section className="space-y-4">
      <SectionTitle kicker="Preview · P1-5(a)" title="「无限」免疫曲线：让超级书的持续成本与词条数同向">
        现在是 N≤任意都 100% 免耗损（红线）。提议：N≤K 全免，之后每多一条下降 s，下限取仓库里已有的{" "}
        <Code>unbreaking_waiver_max_chance</Code>（0.3）。拖动看超级书会落在哪。
      </SectionTitle>
      <Card className="space-y-4">
        <div className="grid gap-4 md:grid-cols-4">
          <Slider label="免费条数 K" value={K} min={1} max={10} onChange={setK} />
          <Slider label="每多一条下降 s" value={s} min={0.01} max={0.15} step={0.01} onChange={setS} />
          <Slider label="豁免下限" value={floor} min={0} max={0.6} step={0.05} onChange={setFloor} />
          <Slider label="书上附魔条数 N" value={N} min={1} max={45} onChange={setN} />
        </div>
        <div className="overflow-x-auto">
          <svg viewBox={`0 0 ${W} ${H}`} className="w-full min-w-[480px]">
            {[0, 0.25, 0.5, 0.75, 1].map((g) => {
              const y = 12 + (1 - g) * (H - 36);
              return (
                <g key={g}>
                  <line x1={30} x2={W - 20} y1={y} y2={y} stroke="rgba(255,255,255,0.08)" />
                  <text x={4} y={y + 3} fontSize={9} fill="#94a3b8">
                    {Math.round(g * 100)}%
                  </text>
                </g>
              );
            })}
            <line x1={30} x2={W - 20} y1={12} y2={12} stroke="#f43f5e" strokeDasharray="4 3" />
            <text x={W - 150} y={9} fontSize={9} fill="#fb7185">
              现状：恒为 100%
            </text>
            <polyline points={pts} fill="none" stroke="#fbbf24" strokeWidth={2.5} />
            <circle cx={curX} cy={curY} r={5} fill="#fbbf24" stroke="#0f172a" strokeWidth={2} />
            {[0, 10, 20, 30, 40].map((n) => (
              <text key={n} x={30 + (n / maxN) * (W - 50) - 4} y={H - 8} fontSize={9} fill="#94a3b8">
                {n}
              </text>
            ))}
            <text x={W / 2 - 40} y={H - 0} fontSize={9} fill="#64748b">
              书上附魔条数 N
            </text>
          </svg>
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          <Info k={`N = ${N} 时的豁免概率`} v={`${(f(N) * 100).toFixed(0)}%`} />
          <Info k="每次使用的期望磨损" v={`${wearPerUse.toFixed(2)} 点`} />
          <Info k="对比：N=4 的小书" v="0 点（保持现状）" />
        </div>
        <p className="text-xs leading-relaxed text-slate-400">
          效果：小而精的「无限 + 少量附魔」书保持原有手感；一本装满所有附魔的超级书会退化到「耐久 III 级别」的收益——可以做，但要为它持续付出。
          再叠加 (b) 总量计分与 (c) 世代衰减，就把二元的「有无」变成了连续的「多少」。
        </p>
      </Card>
    </section>
  );
}

function Info({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-black/30 p-3">
      <div className="text-xs text-slate-500">{k}</div>
      <div className="text-xl font-bold text-amber-300">{v}</div>
    </div>
  );
}

function Checklist() {
  const [done, setDone] = useState<Set<string>>(new Set());
  const pct = Math.round((done.size / CHECKLIST.length) * 100);
  return (
    <section className="space-y-4">
      <SectionTitle kicker="Verification" title="实机验证清单">
        所有「待实测」与「推断」条目，都能写成下面这样的可执行用例。勾选只存在于本页内存里，仅用于自己跟踪。
      </SectionTitle>
      <Card>
        <div className="mb-4 flex items-center gap-3">
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10">
            <div className="h-full rounded-full bg-emerald-400 transition-all" style={{ width: `${pct}%` }} />
          </div>
          <span className="font-mono text-xs text-slate-300">
            {done.size}/{CHECKLIST.length}
          </span>
        </div>
        <ul className="space-y-2">
          {CHECKLIST.map((c) => {
            const on = done.has(c.id);
            return (
              <li key={c.id}>
                <label
                  className={cn(
                    "flex cursor-pointer items-start gap-3 rounded-lg border px-3 py-2.5 text-sm transition",
                    on ? "border-emerald-400/30 bg-emerald-400/[0.06] text-slate-400 line-through" : "border-white/10 bg-white/[0.02] text-slate-200 hover:bg-white/5"
                  )}
                >
                  <input
                    type="checkbox"
                    checked={on}
                    onChange={() =>
                      setDone((s) => {
                        const n = new Set(s);
                        if (n.has(c.id)) n.delete(c.id);
                        else n.add(c.id);
                        return n;
                      })
                    }
                    className="mt-0.5 h-4 w-4 accent-emerald-400"
                  />
                  <span className="flex-1">{c.t}</span>
                  <span className="shrink-0 font-mono text-[11px] text-slate-500">{c.ref}</span>
                </label>
              </li>
            );
          })}
        </ul>
      </Card>
    </section>
  );
}
