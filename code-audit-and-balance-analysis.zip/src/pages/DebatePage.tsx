import { useMemo, useState } from "react";
import { Callout, Card, Code, Meter, Pill, SectionTitle, Slider } from "../components/ui";
import {
  PRESETS,
  SLIP,
  bookLoad,
  globalMastery,
  loadToCap,
  pointsPerLevel,
  shelfBonus,
  slipProbability,
  totalDiscount,
  traitScore,
  woodenDiscount,
  type TraitPreset,
} from "../lib/formulas";
import { cn } from "../utils/cn";

const pct = (x: number, d = 1) => `${(x * 100).toFixed(d)}%`;

export default function DebatePage() {
  return (
    <div className="space-y-14">
      <header>
        <div className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-amber-400/80">Page 2 · 论点分析</div>
        <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
          「既给大增益又设限制，不是自相矛盾吗？」
          <span className="mt-1 block text-slate-400">「一本带无限的超级书装满所有附魔，我不就赚麻了？」</span>
        </h1>
        <p className="mt-4 max-w-3xl text-slate-300">
          这是两句常见的反对意见。我的看法先放前面，再给出它们各自对在哪、错在哪——并且用仓库里的真实公式做了计算器，你可以自己拖。
        </p>

        <div className="mt-6 grid gap-4 md:grid-cols-3">
          <Verdict
            q="「增益与限制自相矛盾」"
            v="作为原则：不成立"
            tone="emerald"
            body="增益和上限不在同一条轴上，而且几个增益相乘才是真正需要被封顶的东西。"
          />
          <Verdict
            q="「限制没有用在对的地方」"
            v="作为经验判断：对「无限」成立"
            tone="rose"
            body="单本评分、饱和的 18%、+3% 的书架加成——这三处限制都被横向扩展或饱和绕开了。"
          />
          <Verdict
            q="「超级书赚麻了」"
            v="夸张，但方向对"
            tone="amber"
            body="不是免费附魔（XP 与材料仍在），而是拿到第一本无限后，模板书的整条经济线被短路。"
          />
        </div>
      </header>

      {/* ───────── 论点 A ───────── */}
      <section className="space-y-6">
        <SectionTitle kicker="Argument A" title="「给了这么大增益，还要限制增益，自相矛盾」">
          先把它换成最强版本再回应：<i>「Infinity、周围多书架、模板书各自都已经很强，为什么还要再给每一项加限制——单本词条、书架数收益、无限的好处？要么放开，要么别给。」</i>
        </SectionTitle>

        <div className="grid gap-4 lg:grid-cols-3">
          <Card>
            <div className="mb-2 text-sm font-bold text-amber-300">① 它们不在同一条轴上</div>
            <p className="text-sm leading-relaxed text-slate-300">
              增益解决的是<b>「你能做什么」</b>（能直附到几级、能不能 1~3 级量产），限制约束的是<b>「做的速率与价格」</b>
              （单价折扣、磨损、再生时间）。<Code>-40%</Code>封的是价格，<Code>wear</Code>封的是次数，<Code>38/42 架</Code>
              决定的是速度。给了 A 轴的能力，不等于必须同时放开 B 轴。
            </p>
          </Card>
          <Card>
            <div className="mb-2 text-sm font-bold text-amber-300">② 上限是给「相乘」设的</div>
            <p className="text-sm leading-relaxed text-slate-300">
              价格 ×0.6、磨损 ×0、再生 ×3、复制成本 ×0 ——它们是乘在一起的，任何一项不封顶，整个经济都会趋向「免费」。
              原版同样如此：附魔台 15 书架封顶、保护类总点数封顶 20、铁砧 39 级线。<b>「强」与「有上限」从来不矛盾，没有上限才会让强失去意义。</b>
            </p>
          </Card>
          <Card>
            <div className="mb-2 text-sm font-bold text-amber-300">③ 否则就没有数值游戏</div>
            <p className="text-sm leading-relaxed text-slate-300">
              「给了大增益就不许限制」如果成立，任何带边际递减的系统都会被判为矛盾。把它当原则用，等于否定所有数值设计；
              只有把它当成<b>「这些限制是否真的在咬」</b>的问题来问，才有信息量。
            </p>
          </Card>
        </div>

        <Callout tone="rose" title="但这句批评有一半是对的：问题不是「有没有限制」，而是「限制落在哪」">
          逐项看，这个仓库里的限制有的真在咬，有的几乎是装饰：
        </Callout>

        <div className="overflow-hidden rounded-2xl border border-white/10">
          <table className="w-full text-left text-sm">
            <thead className="bg-white/5 text-xs uppercase tracking-wider text-slate-400">
              <tr>
                <th className="px-4 py-3">增益</th>
                <th className="px-4 py-3">限制</th>
                <th className="px-4 py-3">限制真的在咬吗</th>
                <th className="px-4 py-3">对应发现</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 align-top">
              <Row
                a="普通书架 0–38 架升满级"
                b="γ=1.25 幂律阶梯；白板只能直附 ⌈M/2⌉"
                v="咬"
                tone="emerald"
                n="真正拉开了进度曲线；38 架这个数在 244 格里也不算小"
                id="—"
              />
              <Row
                a="模板书直附 1~3 级、量产"
                b="每级 4 次磨损，耗尽降一级；拷贝代数衰减"
                v="咬（对非无限书）"
                tone="emerald"
                n="磨损 + 再生是个真实的资源循环"
                id="B-09"
              />
              <Row
                a="藏书精通 −20% / 同种 −15%（总 −40%）"
                b="按附魔「种类」去重计分，总封顶"
                v="半咬"
                tone="amber"
                n="种类集合 16 项即满，一本书就够"
                id="B-05"
              />
              <Row
                a="书架数提升温养 3×（38→42 架）"
                b="仅加载区块计时；重叠取最快；档位含空架"
                v="咬，但门槛太低"
                tone="amber"
                n="空雕纹书架也计数，阈值只占 244 格的 15–17%"
                id="B-06"
              />
              <Row
                a="「无限」整本免耗损、免费复制"
                b="超载「抄错」≤18%；获取限定"
                v="基本不咬"
                tone="rose"
                n="惩罚饱和、可拆书规避；获取限定只卡第一本"
                id="B-01/02/03"
              />
              <Row
                a="深层铭刻等待（≤5 分钟/条，累加）"
                b="献祭跳过 ≤15 级；强跳牺牲最弱母本"
                v="弱"
                tone="rose"
                n="成本与排队长度脱钩；垫背书抵消风险"
                id="B-07"
              />
            </tbody>
          </table>
        </div>

        <Callout tone="sky" title="所以我对 A 的回答">
          「矛盾」这个词不对；对的批评是<b>「限制放错了位置」</b>：限制的是单本书的评分，而不是范围内无限书的总量；限制的是抄错概率，
          而不是免耗损本身；书架数在惩罚侧只有 +1~3%，在收益侧却是 3 倍提速。这叫<b>杠杆错位</b>，不叫自相矛盾。
        </Callout>
      </section>

      {/* ───────── 论点 B ───────── */}
      <section className="space-y-6">
        <SectionTitle kicker="Argument B" title="「一本带无限、装满所有附魔的书，我不就赚麻了？」">
          先做事实核查，再看计算器，最后说立场。
        </SectionTitle>

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <div className="mb-3 flex items-center gap-2 text-sm font-bold text-emerald-300">
              <span>✓</span> 这句话里属实的部分
            </div>
            <ul className="space-y-2 text-sm leading-relaxed text-slate-300">
              <li>
                <b>确实能做出来。</b>书（<Code>wasBook</Code>）不做冲突清除，锋利 + 亡灵杀手 + 保护 + 火焰保护可以共存。仓库甚至有一个隐藏挑战成就
                <i> 「Why Did It Turn Out Like This?」</i>，在一本书拿齐所有非诅咒附魔时授予——设计者知情并奖励。
              </li>
              <li>
                <b>免耗损是整本书的。</b>判断对象是书的 stack，而不是被使用的那条附魔。一个「无限」词条把另外几十条一起带走。
              </li>
              <li>
                <b>复制不耗磨损。</b>只要手里有一本无限母本，新的无限书只需付 1~3 级经验和材料。
              </li>
              <li>
                <b>藏书折扣一本拿满。</b>E 按种类去重，16 种满级 = −20%，一格就够。
              </li>
            </ul>
          </Card>
          <Card>
            <div className="mb-3 flex items-center gap-2 text-sm font-bold text-rose-300">
              <span>✗</span> 这句话里夸张的部分
            </div>
            <ul className="space-y-2 text-sm leading-relaxed text-slate-300">
              <li>
                <b>不是免费附魔。</b>每次铭刻仍扣 1~3 整级（已含折扣）+ 材料；宝藏要顿悟，≥10 条还会触发深层铭刻等待。
              </li>
              <li>
                <b>第一本无限很难。</b>它被移出默认直附列表、移出顿悟池、村民交易里的无限会被剥离（若无限是该书唯一附魔则替换成力量 I）；书只能来自战利品，原版附魔台默认只给<i>装备</i>（如弓）而不给书。
              </li>
              <li>
                <b>抄错税确实存在。</b>封顶时：12.6% 降一级、4.5% 抄成废附魔、0.9% 抄成诅咒（每次铭刻）。
              </li>
              <li>
                <b>XP 仍然是沉没成本。</b>这个仓库的经济并没有崩，只是「书库维护」这条玩法线被短路了。
              </li>
            </ul>
          </Card>
        </div>

        <SlipLab />
        <DiscountLab />

        <div className="grid gap-4 lg:grid-cols-2">
          <Card className="border-amber-400/30">
            <div className="mb-2 text-sm font-bold text-amber-300">我的立场</div>
            <p className="text-sm leading-relaxed text-slate-300">
              「赚麻了」是夸张——钱（XP/材料）还在花。更准确的说法是：<b>拿到第一本无限之后，模板书经济停止运转</b>。
              你不再需要维护书库、不再关心磨损、不再为再生时间排班；你省下的恰好是设计里<b>本来要你付出的那两样东西</b>（磨损与格子）。
              而且这份豁免是整本、永久、可无损复制的。
            </p>
            <p className="mt-3 text-sm leading-relaxed text-slate-300">
              单机 PVE 里这是一个可接受的「毕业奖励」；在多人服里它会扩散——第一本被谁捡到，全服都能抄。这时它才是真问题。
            </p>
          </Card>
          <Card>
            <div className="mb-2 text-sm font-bold text-violet-300">反方最强的辩护（我认为有道理的部分）</div>
            <ul className="list-disc space-y-1.5 pl-5 text-sm leading-relaxed text-slate-300">
              <li>获取第一本无限需要极大运气 + 大量 XP，奖励「毕业感」本身就是设计目标。</li>
              <li>设计者做了成就，说明「做超级书」是被鼓励的玩法，而不是漏洞。</li>
              <li>它仍然吃 XP 与材料，没有绕开原版最重要的 XP 沉没。</li>
              <li>真正会让经济崩的是「无限 + 复制 + 折扣」同时无上限；而折扣已经封顶在 −40%。</li>
            </ul>
            <p className="mt-3 text-sm text-slate-400">
              我的底线：可以让超级书存在，但<b>它的持续成本应当随词条数同向增长</b>——现在是反向的。
            </p>
          </Card>
        </div>
      </section>

      <GrindLab />

      <Callout tone="amber" title="一句话收束">
        关于「自相矛盾」：不矛盾，但限制放错了位置。关于「超级书」：不是免费，是短路——短路的是模板书经济，不是 XP 经济。
        具体怎么改，在第三页。
      </Callout>
    </div>
  );
}

function Verdict({ q, v, body, tone }: { q: string; v: string; body: string; tone: "emerald" | "rose" | "amber" }) {
  const border = { emerald: "border-emerald-400/40", rose: "border-rose-400/40", amber: "border-amber-400/40" }[tone];
  const text = { emerald: "text-emerald-300", rose: "text-rose-300", amber: "text-amber-300" }[tone];
  return (
    <div className={cn("rounded-2xl border bg-white/[0.03] p-5", border)}>
      <div className="text-xs text-slate-500">{q}</div>
      <div className={cn("mt-1 text-lg font-bold", text)}>{v}</div>
      <p className="mt-2 text-sm leading-relaxed text-slate-300">{body}</p>
    </div>
  );
}

function Row({
  a,
  b,
  v,
  n,
  id,
  tone,
}: {
  a: string;
  b: string;
  v: string;
  n: string;
  id: string;
  tone: "emerald" | "amber" | "rose";
}) {
  const cls = {
    emerald: "bg-emerald-500/15 text-emerald-300 ring-emerald-400/40",
    amber: "bg-amber-500/15 text-amber-300 ring-amber-400/40",
    rose: "bg-rose-500/15 text-rose-300 ring-rose-400/40",
  }[tone];
  return (
    <tr>
      <td className="px-4 py-3 text-slate-100">{a}</td>
      <td className="px-4 py-3 text-xs text-slate-400">{b}</td>
      <td className="px-4 py-3">
        <Pill className={cls}>{v}</Pill>
        <div className="mt-1.5 text-xs text-slate-400">{n}</div>
      </td>
      <td className="px-4 py-3 font-mono text-xs text-slate-500">{id}</td>
    </tr>
  );
}

/* ═════════════ 计算器 1：抄错 / 拆书 ═════════════ */
function SlipLab() {
  const [chosen, setChosen] = useState<Set<string>>(
    new Set(["mending", "unb3", "silk", "fortune3", "sharp5", "eff5", "prot4", "thorns3"])
  );
  const [shelves, setShelves] = useState(42);

  const sel = useMemo(() => PRESETS.filter((p) => chosen.has(p.id)), [chosen]);
  const superL = bookLoad(sel);
  const superP = slipProbability(superL, shelves);

  const split = useMemo(() => {
    const treasures = sel.filter((t) => t.treasure);
    const others = sel.filter((t) => !t.treasure).sort((a, b) => traitScore(b) - traitScore(a));
    const bins: TraitPreset[][] = [];
    for (const t of others) {
      const s = traitScore(t);
      const bin = bins.find((b) => b.reduce((acc, x) => acc + traitScore(x), 0) + s < SLIP.minLoad - 1e-9);
      if (bin) bin.push(t);
      else bins.push([t]);
    }
    const books = [...treasures.map((t) => [t]), ...bins];
    const rows = books.map((b) => {
      const L = bookLoad(b);
      return { traits: b, L, P: slipProbability(L, shelves) };
    });
    return {
      rows,
      maxP: rows.reduce((m, r) => Math.max(m, r.P), 0),
      sheves: Math.ceil(rows.length / 6),
    };
  }, [sel, shelves]);

  const toggle = (id: string) =>
    setChosen((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  return (
    <Card className="space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="text-xs font-semibold uppercase tracking-[0.18em] text-amber-400/80">计算器 ①</div>
          <h3 className="text-xl font-bold text-white">「抄错」惩罚 vs. 超级书 / 拆书</h3>
          <p className="mt-1 max-w-2xl text-sm text-slate-400">
            公式取自 <Code>computeLoadSlipProbability</Code>：<Code>P = min(18%, 0.035·(L−3) + 书架加成)</Code>，L&lt;3 时 P=0；任意宝藏附魔使 L 至少为 3。
            以下评分使用原版近似权重，仅作演示。
          </p>
        </div>
        <Pill className="bg-fuchsia-500/15 text-fuchsia-300 ring-fuchsia-400/40">按源码公式 · 权重为近似</Pill>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1.2fr_1fr]">
        <div>
          <div className="mb-2 text-xs text-slate-400">书里有哪些附魔（「无限」本身不计分，已默认存在）</div>
          <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
            {PRESETS.map((p) => {
              const on = chosen.has(p.id);
              return (
                <button
                  key={p.id}
                  onClick={() => toggle(p.id)}
                  className={cn(
                    "flex items-center justify-between rounded-lg border px-2.5 py-1.5 text-left text-xs transition",
                    on
                      ? "border-amber-400/60 bg-amber-400/10 text-amber-100"
                      : "border-white/10 bg-white/[0.02] text-slate-400 hover:bg-white/5"
                  )}
                >
                  <span>
                    {p.name}
                    {p.treasure && <span className="ml-1 text-fuchsia-300">★</span>}
                  </span>
                  <span className="font-mono text-[10px] opacity-70">+{traitScore(p).toFixed(1)}</span>
                </button>
              );
            })}
          </div>
          <div className="mt-2 flex gap-2 text-xs">
            <button
              className="rounded-md border border-white/10 px-2 py-1 text-slate-300 hover:bg-white/10"
              onClick={() => setChosen(new Set(PRESETS.map((p) => p.id)))}
            >
              全选（超级书）
            </button>
            <button
              className="rounded-md border border-white/10 px-2 py-1 text-slate-300 hover:bg-white/10"
              onClick={() => setChosen(new Set(["unb3"]))}
            >
              只留耐久 III
            </button>
            <button
              className="rounded-md border border-white/10 px-2 py-1 text-slate-300 hover:bg-white/10"
              onClick={() => setChosen(new Set())}
            >
              清空
            </button>
          </div>
          <div className="mt-4">
            <Slider label="范围内广义书架数 S" value={shelves} min={0} max={60} onChange={setShelves} />
            <div className="mt-1 text-[11px] text-slate-500">
              书架加成：≥32 +1% · ≥38 +2% · ≥42 +3%（当前 +{(shelfBonus(shelves) * 100).toFixed(0)}%）
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <div className="rounded-xl border border-white/10 bg-black/30 p-4">
            <div className="text-xs text-slate-400">单本超级书（{sel.length} 条附魔 + 无限）</div>
            <div className="mt-1 flex items-baseline gap-3">
              <div className="text-3xl font-bold text-white">{pct(superP)}</div>
              <div className="text-xs text-slate-400">
                L = <span className="font-mono text-amber-300">{superL.toFixed(1)}</span>，封顶需 L ≈{" "}
                <span className="font-mono">{loadToCap(shelves).toFixed(1)}</span>
              </div>
            </div>
            <div className="mt-2">
              <Meter value={superP} max={SLIP.cap} tone={superP >= SLIP.cap - 1e-9 ? "rose" : "amber"} />
            </div>
            <div className="mt-2 text-xs text-slate-400">
              每次铭刻平均需 <span className="font-mono text-slate-200">{(1 / (1 - superP)).toFixed(2)}×</span> 次尝试。封顶时：
              降一级 {pct(superP * 0.7)} / 废附魔 {pct(superP * 0.25)} / 诅咒 {pct(superP * 0.05)}。
            </div>
          </div>

          <div className="rounded-xl border border-emerald-400/30 bg-emerald-400/[0.06] p-4">
            <div className="text-xs text-emerald-200/80">换成「拆书」策略（每本 L&lt;3，宝藏各占一本）</div>
            <div className="mt-1 flex items-baseline gap-3">
              <div className="text-3xl font-bold text-white">{pct(split.maxP)}</div>
              <div className="text-xs text-slate-300">
                最坏一本 · 共 {split.rows.length} 本 · 占 {split.sheves} 个雕纹书架
              </div>
            </div>
            <ul className="mt-2 max-h-32 space-y-1 overflow-auto pr-1 text-[11px] text-slate-300">
              {split.rows.map((r, i) => (
                <li key={i} className="flex justify-between gap-2 rounded bg-black/30 px-2 py-1">
                  <span className="truncate">{r.traits.map((t) => t.name).join(" + ")}</span>
                  <span className="shrink-0 font-mono text-slate-400">
                    L={r.L.toFixed(1)} → {pct(r.P)}
                  </span>
                </li>
              ))}
              {split.rows.length === 0 && <li className="text-slate-500">未选择附魔</li>}
            </ul>
            <p className="mt-2 text-[11px] leading-relaxed text-emerald-100/70">
              非宝藏的小书 P=0；宝藏书只剩书架加成（≤3%）。而每一本都仍带「无限」，免耗损对整本生效。
            </p>
          </div>
        </div>
      </div>

      <Callout tone="rose" title="读数的结论">
        一旦有 3~4 条高分附魔，惩罚就贴着 18% 的上限，往后再加 30 条附魔<b>一分钱都不会多付</b>；而把附魔分到几本小书里，惩罚几乎归零。
        限制「单本模板书」的初衷，被「书架格子很多」这件事本身绕开了——而书架多，恰恰是模组在鼓励的。
      </Callout>
    </Card>
  );
}

/* ═════════════ 计算器 2：藏书减免 ═════════════ */
function DiscountLab() {
  const [w, setW] = useState(38);
  const [e, setE] = useState(16);
  const [r, setR] = useState(1);

  const wood = woodenDiscount(w);
  const glob = globalMastery(e);
  const pub = Math.min(35, wood + glob);
  const spec = Math.round(15 * r);
  const total = totalDiscount(w, e, r);
  const shelvesNeeded = Math.ceil(e / 6);

  return (
    <Card className="space-y-5">
      <div>
        <div className="text-xs font-semibold uppercase tracking-[0.18em] text-amber-400/80">计算器 ②</div>
        <h3 className="text-xl font-bold text-white">−40% 藏书减免要多少「格子」？</h3>
        <p className="mt-1 max-w-2xl text-sm text-slate-400">
          取自 Wiki §3.1/3.2：普通书架 <Code>round(1% + 14%·clamp((W−12)/26))</Code>（W≥12），全局藏书 <Code>min(20%, ⌊1.25·E⌋)</Code>，
          公共封顶 35%，同种 <Code>round(15%·r)</Code>，总封顶 40%。
        </p>
      </div>
      <div className="grid gap-5 lg:grid-cols-[1fr_1fr]">
        <div className="space-y-4">
          <Slider label="普通书架数 W" value={w} min={0} max={60} onChange={setW} />
          <Slider label="已存附魔种类数 E（按满级计，同名去重）" value={e} min={0} max={40} onChange={setE} />
          <Slider label="目标附魔相对等级 r = L/M" value={r} min={0} max={1} step={0.05} onChange={setR} />
        </div>
        <div className="space-y-3">
          <Bar label="普通书架" value={wood} max={15} note={`${wood}%`} />
          <Bar label="全局藏书" value={glob} max={20} note={`${glob}%`} />
          <Bar label="公共合计（封顶 35）" value={pub} max={35} note={`${pub}%`} />
          <Bar label="同种藏书" value={spec} max={15} note={`${spec}%`} />
          <div className="rounded-xl border border-amber-400/40 bg-amber-400/[0.07] p-3">
            <div className="flex items-baseline justify-between">
              <span className="text-sm text-amber-100">总减免</span>
              <span className="text-2xl font-bold text-white">−{total}%</span>
            </div>
            <div className="text-xs text-amber-100/70">成本倍率 ×{(1 - total / 100).toFixed(2)}</div>
          </div>
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat k="一本超级书" v="1 格" note={`容纳 ${e} 种附魔`} tone="rose" />
        <Stat k="一书一附魔" v={`${shelvesNeeded} 个书架`} note={`每架 6 格，共 ${e} 格`} tone="amber" />
        <Stat k="扫描体积" v="244 格" note="7×7×5 − 台面自身" tone="sky" />
      </div>
      <Callout tone="amber" title="读数的结论">
        拿满 −40% 的最小条件大约是：W≥38、E≥16、r≥0.33。即使不用超级书，也只需要 3 个雕纹书架；用超级书则是 1 格。
        「用格子换折扣」在 244 格的扫描体积里根本不构成约束——所以不是折扣被限制住了，而是<b>没有东西在限制它</b>。
      </Callout>
    </Card>
  );
}

function Bar({ label, value, max, note }: { label: string; value: number; max: number; note: string }) {
  return (
    <div>
      <div className="mb-1 flex justify-between text-xs text-slate-400">
        <span>{label}</span>
        <span className="font-mono text-slate-200">{note}</span>
      </div>
      <Meter value={value} max={max} />
    </div>
  );
}

function Stat({ k, v, note, tone }: { k: string; v: string; note: string; tone: "rose" | "amber" | "sky" }) {
  const c = { rose: "text-rose-300", amber: "text-amber-300", sky: "text-sky-300" }[tone];
  return (
    <div className="rounded-xl border border-white/10 bg-black/30 p-3">
      <div className="text-xs text-slate-500">{k}</div>
      <div className={cn("text-xl font-bold", c)}>{v}</div>
      <div className="text-xs text-slate-400">{note}</div>
    </div>
  );
}

/* ═════════════ 计算器 3：砂轮回路（待实测） ═════════════ */
const GRIND: { name: string; minCost: number }[] = [
  { name: "锋利 V", minCost: 45 },
  { name: "效率 V", minCost: 41 },
  { name: "保护 IV", minCost: 34 },
  { name: "时运 III", minCost: 33 },
  { name: "经验修补", minCost: 25 },
  { name: "耐久 III", minCost: 21 },
  { name: "无限", minCost: 20 },
  { name: "精准采集", minCost: 15 },
];

function GrindLab() {
  const [lvl, setLvl] = useState(10);
  const [k, setK] = useState(1);
  const [idx, setIdx] = useState(0);
  const [frac, setFrac] = useState(0.5);

  const minCost = GRIND[idx].minCost;
  const L = Math.max(k, lvl);

  const cost = useMemo(() => {
    let s = 0;
    for (let j = L - k; j <= L - 1; j++) s += pointsPerLevel(j);
    s += frac * (pointsPerLevel(L) - pointsPerLevel(L - k));
    return s;
  }, [L, k, frac]);

  const half = Math.ceil(minCost / 2);
  const gain = half + (half - 1) / 2;
  const net = gain - cost;

  const breakEven = useMemo(() => {
    let be = 0;
    for (let l = k; l <= 60; l++) {
      let c = 0;
      for (let j = l - k; j <= l - 1; j++) c += pointsPerLevel(j);
      c += frac * (pointsPerLevel(l) - pointsPerLevel(l - k));
      if (gain - c > 0) be = l;
    }
    return be;
  }, [k, frac, gain]);

  return (
    <section className="space-y-4">
      <SectionTitle kicker="Hypothesis · 待实测" title="疑点：量产模式 + 砂轮，会不会有低等级经验正回路？">
        这不是已证实的 Bug，是我从两段代码里推出来的假设。下面把粗算摊开，方便你直接验证或推翻。
      </SectionTitle>
      <Card className="space-y-5">
        <div className="flex flex-wrap items-center gap-2">
          <Pill className="bg-fuchsia-500/15 text-fuchsia-300 ring-fuchsia-400/40">待实测</Pill>
          <span className="text-xs text-slate-400">
            量产模式只扣 1~3 整级并保留经验条；砂轮对附魔书发放原版经验，未经溯源折算（<Code>external_xp_refund_scale=0.25</Code> 仅在附魔台内生效）。
          </span>
        </div>
        <div className="grid gap-5 lg:grid-cols-2">
          <div className="space-y-4">
            <Slider label="玩家等级 L" value={lvl} min={1} max={40} onChange={setLvl} />
            <Slider label="量产模式扣除级数 k" value={k} min={1} max={3} onChange={setK} />
            <Slider label="经验条小数部分（保留）" value={frac} min={0} max={0.95} step={0.05} onChange={setFrac} />
            <div>
              <div className="mb-1 text-xs text-slate-400">砂轮磨掉的附魔（minCost 为原版近似值）</div>
              <div className="flex flex-wrap gap-1.5">
                {GRIND.map((g, i) => (
                  <button
                    key={g.name}
                    onClick={() => setIdx(i)}
                    className={cn(
                      "rounded-md border px-2 py-1 text-xs",
                      i === idx
                        ? "border-amber-400 bg-amber-400 font-semibold text-slate-900"
                        : "border-white/15 text-slate-300 hover:bg-white/10"
                    )}
                  >
                    {g.name} · {g.minCost}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="space-y-3">
            <div className="grid grid-cols-3 gap-3">
              <Stat k="铭刻成本（点）" v={cost.toFixed(0)} note={`L${L}→L${L - k}，保留小数`} tone="amber" />
              <Stat k="砂轮期望（点）" v={gain.toFixed(1)} note="ceil(i/2)+rand(ceil(i/2))" tone="sky" />
              <Stat k="净值" v={`${net >= 0 ? "+" : ""}${net.toFixed(0)}`} note={net > 0 ? "可能为正" : "为负"} tone={net > 0 ? "rose" : "sky"} />
            </div>
            <Callout tone={net > 0 ? "rose" : "emerald"} title={net > 0 ? "此组合下粗算为正" : "此组合下粗算为负"}>
              在 k={k}、小数={frac.toFixed(2)}、{GRIND[idx].name} 的条件下，净值在等级 ≤ <b>{breakEven || "—"}</b> 时为正。
              材料（青金石/墨囊等）、空白书、以及量产扣级的实际算法都没计入——真正的结论需要用 GameTest 或 headless 模拟来定。
            </Callout>
          </div>
        </div>
      </Card>
    </section>
  );
}

