import { useMemo, useState, type ReactNode } from "react";
import {
  CATEGORIES,
  FINDINGS,
  POSITIVES,
  type CategoryId,
  type Confidence,
  type Finding,
  type Severity,
} from "../data/findings";
import { CONF_META, Callout, Card, Pill, SEV_META, SectionTitle } from "../components/ui";
import { cn } from "../utils/cn";

const STATS = [
  { v: "37,478", l: "行 Java（main / client / test）" },
  { v: "106", l: "个 Java 文件" },
  { v: "13", l: "个 Mixin（required=true）" },
  { v: "63", l: "项 ConfigCatalog 配置" },
  { v: "11", l: "份数据包 JSON 规则" },
];

const RECON: { k: string; doc: string; real: string; ok: boolean }[] = [
  { k: "温养基础间隔 (+1 耐久)", doc: "24,000 s（20 游戏日）", real: "7,200 s（JSON）", ok: false },
  { k: "38 架档", doc: "12,000 s（10 游戏日）", real: "3,600 s", ok: false },
  { k: "42 架档", doc: "3,600 s（3 游戏日）", real: "1,200 s", ok: false },
  { k: "抄错概率上限", doc: "≤ 20%", real: "18%（两个同义键）", ok: false },
  { k: "超载触发条件", doc: "无限 + 其他附魔 > 3 条", real: "质量负载 L ≥ 3", ok: false },
  { k: "配置项数量", doc: "55 项", real: "63 项", ok: false },
  { k: "藏书减免总上限", doc: "-40%", real: "-40%（35 公共 + 15 同种）", ok: true },
  { k: "强行跳过退化上限", doc: "50% / 无限 70%", real: "0.5 / 0.7", ok: true },
  { k: "单次等待上限", doc: "5 分钟", real: "300 s", ok: true },
];

export default function AuditPage({ onNavigate }: { onNavigate: (p: "debate" | "advice") => void }) {
  const [cat, setCat] = useState<CategoryId | "all">("all");
  const [sev, setSev] = useState<Severity | "all">("all");
  const [conf, setConf] = useState<Confidence | "all">("all");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<Set<string>>(new Set(["M-01", "B-02", "N-01"]));

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: FINDINGS.length };
    for (const f of FINDINGS) c[f.cat] = (c[f.cat] ?? 0) + 1;
    return c;
  }, []);

  const sevCounts = useMemo(() => {
    const c = { high: 0, med: 0, low: 0 };
    for (const f of FINDINGS) c[f.sev]++;
    return c;
  }, []);

  const list = useMemo(() => {
    const kw = q.trim().toLowerCase();
    return FINDINGS.filter(
      (f) =>
        (cat === "all" || f.cat === cat) &&
        (sev === "all" || f.sev === sev) &&
        (conf === "all" || f.conf === conf) &&
        (!kw ||
          (f.title + f.impact + f.fix + f.evidence.join(" ") + f.id).toLowerCase().includes(kw))
    );
  }, [cat, sev, conf, q]);

  const toggle = (id: string) =>
    setOpen((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  const expandAll = () => setOpen(new Set(list.map((f) => f.id)));
  const collapseAll = () => setOpen(new Set());

  return (
    <div className="space-y-12">
      {/* Hero */}
      <section>
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <Pill className="bg-violet-500/15 text-violet-200 ring-violet-400/40">
            chiseled-enchanting-table-26.1.2-source
          </Pill>
          <Pill className="bg-white/5 text-slate-300 ring-white/20">arena/2d61e52c-… · v1.1.0</Pill>
          <Pill className="bg-white/5 text-slate-300 ring-white/20">MC 26.1.2 · Fabric · Java 25</Pill>
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-5xl">
          纂刻附魔台仓库审计
          <span className="block bg-gradient-to-r from-amber-300 via-fuchsia-300 to-violet-300 bg-clip-text text-transparent">
            七条路径 + 数值机制
          </span>
        </h1>
        <p className="mt-4 max-w-3xl text-base leading-relaxed text-slate-300">
          我克隆了这个分支，按「硬编码、源码 API、数据编解码、网络同步、GUI 输入、Mixin 注入、死代码、耦合风险」逐条取证，
          再对「无限 / 周围多书架 / 模板书」的数值与机制做了一次合理性核算。下面每一条都带文件与符号级证据，
          并标注了置信度——<b className="text-amber-200">我没有编译或进游戏跑过</b>，所以凡是需要实机才能下结论的，都明确写成「待实测」。
        </p>

        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-5">
          {STATS.map((s) => (
            <Card key={s.l} className="!p-4">
              <div className="text-2xl font-bold text-white">{s.v}</div>
              <div className="mt-1 text-xs text-slate-400">{s.l}</div>
            </Card>
          ))}
        </div>

        <div className="mt-6 grid gap-4 lg:grid-cols-3">
          <Callout tone="rose" title={`最需要先看的 ${sevCounts.high} 条（高）`}>
            <ul className="list-disc space-y-1 pl-5">
              <li>
                <b>M-01</b> 全局 ContainerHelper Mixin + 锁随物品离架（待实测，潜在卡物品）
              </li>
              <li>
                <b>B-01 / B-02</b>「无限」整本二元免疫 + 抄错惩罚饱和且可拆书规避
              </li>
            </ul>
          </Callout>
          <Callout tone="amber" title="最容易修的 3 个真 Bug">
            <ul className="list-disc space-y-1 pl-5">
              <li>
                <b>N-01</b> 握手探测漏了 REVISION_11–13
              </li>
              <li>
                <b>N-02</b> 附魔书堆叠上限不参与握手
              </li>
              <li>
                <b>H-07</b> 标签驱动免疫 vs 字面 ID 驱动罚则
              </li>
            </ul>
          </Callout>
          <Callout tone="sky" title="接下来看什么">
            <div className="space-y-2">
              <p>你问的两个「论点」与「中肯怀疑 + 建议」分别在另外两页：</p>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => onNavigate("debate")}
                  className="rounded-lg bg-amber-400 px-3 py-1.5 text-xs font-semibold text-slate-900 hover:bg-amber-300"
                >
                  → 论点分析（含计算器）
                </button>
                <button
                  onClick={() => onNavigate("advice")}
                  className="rounded-lg border border-white/20 px-3 py-1.5 text-xs font-semibold text-white hover:bg-white/10"
                >
                  → 怀疑与建议
                </button>
              </div>
            </div>
          </Callout>
        </div>
      </section>

      {/* Reconciliation */}
      <section>
        <SectionTitle kicker="Doc ↔ Code" title="文档与单一事实源对账">
          仓库的数值事实源是 <code className="font-mono text-amber-200">library_resonance.json</code> 与{" "}
          <code className="font-mono text-amber-200">shelf_gates.json</code>（Java 常量由脚本生成）。Wiki 是手写的，
          于是出现了下面的漂移。
        </SectionTitle>
        <div className="overflow-hidden rounded-2xl border border-white/10">
          <table className="w-full text-left text-sm">
            <thead className="bg-white/5 text-xs uppercase tracking-wider text-slate-400">
              <tr>
                <th className="px-4 py-3">项目</th>
                <th className="px-4 py-3">Wiki 写的</th>
                <th className="px-4 py-3">代码 / JSON 实际</th>
                <th className="px-4 py-3 text-center">一致</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {RECON.map((r) => (
                <tr key={r.k} className={r.ok ? "" : "bg-rose-500/[0.05]"}>
                  <td className="px-4 py-2.5 text-slate-200">{r.k}</td>
                  <td className="px-4 py-2.5 font-mono text-xs text-slate-400">{r.doc}</td>
                  <td className="px-4 py-2.5 font-mono text-xs text-slate-200">{r.real}</td>
                  <td className="px-4 py-2.5 text-center">{r.ok ? "✓" : "✗"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Findings */}
      <section>
        <SectionTitle kicker="Findings" title={`逐条发现（${FINDINGS.length}）`}>
          点击卡片展开证据 / 影响 / 修法。置信度：<b className="text-emerald-300">已证实</b>= 我读到了代码或 JSON；
          <b className="text-violet-300"> 推断</b>= 由代码结构推出但没看到运行行为；
          <b className="text-fuchsia-300"> 待实测</b>= 需要进游戏验证。
        </SectionTitle>

        <div className="sticky top-[57px] z-20 -mx-4 mb-5 space-y-3 border-b border-white/10 bg-slate-950/90 px-4 py-3 backdrop-blur sm:-mx-0 sm:rounded-xl sm:border sm:px-4">
          <div className="flex flex-wrap gap-1.5">
            <Chip active={cat === "all"} onClick={() => setCat("all")}>
              全部 <span className="opacity-60">{counts.all}</span>
            </Chip>
            {CATEGORIES.map((c) => (
              <Chip key={c.id} active={cat === c.id} onClick={() => setCat(c.id)} title={c.hint}>
                {c.label} <span className="opacity-60">{counts[c.id] ?? 0}</span>
              </Chip>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <Select
              value={sev}
              onChange={(v) => setSev(v as Severity | "all")}
              options={[
                ["all", "严重度：全部"],
                ["high", `高 (${sevCounts.high})`],
                ["med", `中 (${sevCounts.med})`],
                ["low", `低 (${sevCounts.low})`],
              ]}
            />
            <Select
              value={conf}
              onChange={(v) => setConf(v as Confidence | "all")}
              options={[
                ["all", "置信度：全部"],
                ["confirmed", "已证实"],
                ["inferred", "推断"],
                ["needs-test", "待实测"],
              ]}
            />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="搜索：Mixin / REVISION / 无限 …"
              className="min-w-[200px] flex-1 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-slate-200 placeholder:text-slate-500 focus:border-amber-400/60 focus:outline-none"
            />
            <button onClick={expandAll} className="rounded-lg border border-white/10 px-2.5 py-1.5 text-slate-300 hover:bg-white/10">
              全部展开
            </button>
            <button onClick={collapseAll} className="rounded-lg border border-white/10 px-2.5 py-1.5 text-slate-300 hover:bg-white/10">
              全部收起
            </button>
            <span className="ml-auto text-slate-500">显示 {list.length} 条</span>
          </div>
        </div>

        <div className="space-y-3">
          {list.map((f) => (
            <FindingCard key={f.id} f={f} open={open.has(f.id)} onToggle={() => toggle(f.id)} />
          ))}
          {list.length === 0 && (
            <div className="rounded-xl border border-dashed border-white/15 p-10 text-center text-slate-500">
              没有符合条件的条目
            </div>
          )}
        </div>
      </section>

      {/* Positives */}
      <section>
        <SectionTitle kicker="Fair play" title="没发现问题 / 做得对的地方">
          审计不只是找茬。下面这些是我专门去查、并且确认写得扎实的部分。
        </SectionTitle>
        <div className="grid gap-3 sm:grid-cols-2">
          {POSITIVES.map((p, i) => (
            <Card key={i} className="flex gap-3 !p-4">
              <span className="mt-0.5 text-emerald-400">✓</span>
              <p className="text-sm leading-relaxed text-slate-300">{p}</p>
            </Card>
          ))}
        </div>
      </section>

      <Callout tone="violet" title="审计边界（请务必读）">
        <ul className="list-disc space-y-1 pl-5">
          <li>静态阅读：克隆分支后读源码与 JSON，没有用 JDK 25 编译，也没有进游戏。</li>
          <li>
            死代码是启发式（方法名在 main + client 只出现一次，排除 override/注册回调），可能漏掉方法引用调用；删之前请用 IDE 复核。
          </li>
          <li>评分计算器使用的原版附魔 weight / 适用面是近似值，真实值以游戏内注册表为准。</li>
          <li>文件引用用文件名 + 符号，不写行号，因为我只读了每个文件的相关片段。</li>
        </ul>
      </Callout>
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
  title,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  title?: string;
}) {
  return (
    <button
      onClick={onClick}
      title={title}
      className={cn(
        "rounded-full border px-3 py-1 text-xs transition",
        active
          ? "border-amber-400 bg-amber-400 font-semibold text-slate-900"
          : "border-white/15 bg-white/5 text-slate-300 hover:bg-white/10"
      )}
    >
      {children}
    </button>
  );
}

function Select({
  value,
  onChange,
  options,
}: {
  value: string;
  onChange: (v: string) => void;
  options: [string, string][];
}) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="rounded-lg border border-white/10 bg-slate-900 px-2.5 py-1.5 text-slate-200 focus:border-amber-400/60 focus:outline-none"
    >
      {options.map(([v, l]) => (
        <option key={v} value={v}>
          {l}
        </option>
      ))}
    </select>
  );
}

function FindingCard({ f, open, onToggle }: { f: Finding; open: boolean; onToggle: () => void }) {
  const cat = CATEGORIES.find((c) => c.id === f.cat)!;
  return (
    <div
      className={cn(
        "overflow-hidden rounded-2xl border bg-white/[0.03] transition",
        open ? "border-amber-400/30" : "border-white/10 hover:border-white/20"
      )}
    >
      <button onClick={onToggle} className="flex w-full items-start gap-3 p-4 text-left">
        <span className="mt-0.5 shrink-0 font-mono text-xs text-slate-500">{f.id}</span>
        <div className="min-w-0 flex-1">
          <div className="text-[15px] font-semibold leading-snug text-white">{f.title}</div>
          <div className="mt-2 flex flex-wrap items-center gap-1.5">
            <Pill className={SEV_META[f.sev].cls}>严重度 {SEV_META[f.sev].label}</Pill>
            <Pill className={CONF_META[f.conf].cls}>{CONF_META[f.conf].label}</Pill>
            <Pill className="bg-white/5 text-slate-400 ring-white/15">{cat.label}</Pill>
          </div>
        </div>
        <span className={cn("mt-1 text-slate-500 transition", open && "rotate-90")}>▸</span>
      </button>
      {open && (
        <div className="space-y-4 border-t border-white/10 bg-black/20 p-4 text-sm">
          <div>
            <div className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-slate-500">证据</div>
            <ul className="space-y-1.5">
              {f.evidence.map((e, i) => (
                <li
                  key={i}
                  className="rounded-lg bg-black/40 px-3 py-2 font-mono text-[12px] leading-relaxed text-slate-300"
                >
                  {e}
                </li>
              ))}
            </ul>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <div className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-rose-300/80">影响</div>
              <p className="leading-relaxed text-slate-300">{f.impact}</p>
            </div>
            <div>
              <div className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-emerald-300/80">建议</div>
              <p className="leading-relaxed text-slate-300">{f.fix}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
