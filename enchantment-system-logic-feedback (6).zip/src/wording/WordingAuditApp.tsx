import { useState } from "react";
import {
  FileText,
  AlertTriangle,
  BookOpen,
  CheckCircle2,
  Copy,
  Check,
  ArrowRight,
  Sparkles,
  MessageSquare,
  ScrollText,
} from "lucide-react";
import {
  TERMINOLOGY_DICTIONARY,
  CODE_DRIFT_FACTS,
  DIRECT_REPLACE_ZH,
  DIRECT_REPLACE_EN,
  CHAPTER_REWRITES,
} from "./wordingData";
import { Sprite } from "../wiki/pixel";

export default function WordingAuditApp({ onSwitch }: { onSwitch: (v: "wiki" | "proposal" | "wording") => void }) {
  const [activeTab, setActiveTab] = useState<"facts" | "lexicon" | "chapters" | "patches">("facts");
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard?.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1800);
  };

  return (
    <div className="min-h-screen bg-obsidian text-parch font-body selection:bg-arcane/30 pb-20">
      {/* Top Header */}
      <header className="sticky top-0 z-[70] h-14 flex items-center justify-between px-4 md:px-8 bg-obsidian/90 backdrop-blur-md border-b border-arcane/15">
        <div className="flex items-center gap-2.5">
          <Sprite id="arcane_grimoire" size={28} />
          <span className="font-display font-black text-[15px] tracking-wide text-parch">
            文本校准 & 人话手册
          </span>
          <span className="hidden sm:inline font-pixel text-[9px] tracking-[0.2em] text-gild bg-gild/10 border border-gild/30 px-2 py-0.5 rounded-sm">
            LANG & WIKI POLISH
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onSwitch("wiki")}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-sm border border-arcane/25 text-mute hover:text-parch text-[12px] transition-colors"
          >
            <BookOpen size={13} />
            <span className="hidden sm:inline">交互式 WIKI</span>
          </button>
          <button
            onClick={() => onSwitch("proposal")}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-sm border border-arcane/25 text-mute hover:text-parch text-[12px] transition-colors"
          >
            <ScrollText size={13} />
            <span className="hidden sm:inline">设计提案与审计</span>
          </button>
        </div>
      </header>

      {/* Hero Banner */}
      <section className="relative px-6 md:px-12 pt-14 pb-12 max-w-6xl mx-auto overflow-hidden">
        <div className="absolute top-0 right-10 w-96 h-96 rounded-full bg-arcane/10 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 left-10 w-80 h-80 rounded-full bg-gild/10 blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <p className="font-pixel text-[10px] tracking-[0.35em] text-gild uppercase mb-3">
            ACCURACY & READABILITY OVERHAUL · 彻底说人话
          </p>
          <h1
            className="font-display font-black leading-[1.08] text-parch"
            style={{ fontSize: "clamp(2.2rem, 5.5vw, 4.2rem)" }}
          >
            拒绝机翻与伪学术黑话，
            <br />
            <span className="shimmer-text">100% 对齐代码真实机制</span>
          </h1>
          <p className="mt-5 max-w-3xl text-sm md:text-base leading-8 text-mute font-light">
            为什么许多优秀的模组，玩家一打开说明书就头痛？因为文本里堆满了
            <span className="text-parch font-medium">「势能差、白板基底、微创手术、差价守恒、信用折抵」</span>
            等伪学术生造词汇，甚至存在<span className="text-inkd font-medium">「全洗产碎砂、降级消耗紫水晶、破咒用回响碎片、合书放背包」</span>等严重误导玩家的代码偏差。
            本页逐一清查这些问题，并提供<span className="text-gild font-medium">可直接一键复制替换的 JSON / Markdown 文本包</span>。
          </p>

          {/* Quick Stat Pillows */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-8">
            <div className="rounded-sm bg-obsidian/60 border border-inkd/30 p-3.5 flex items-center gap-3">
              <AlertTriangle className="text-inkd shrink-0" size={24} />
              <div>
                <p className="font-vt text-[26px] leading-none text-inkd">10 处</p>
                <p className="text-[11px] text-faint mt-0.5">代码事实性偏差</p>
              </div>
            </div>
            <div className="rounded-sm bg-obsidian/60 border border-gild/30 p-3.5 flex items-center gap-3">
              <MessageSquare className="text-gild shrink-0" size={24} />
              <div>
                <p className="font-vt text-[26px] leading-none text-gild">9 个</p>
                <p className="text-[11px] text-faint mt-0.5">黑话人话转换</p>
              </div>
            </div>
            <div className="rounded-sm bg-obsidian/60 border border-tealw/30 p-3.5 flex items-center gap-3">
              <BookOpen className="text-tealw shrink-0" size={24} />
              <div>
                <p className="font-vt text-[26px] leading-none text-tealw">8 章</p>
                <p className="text-[11px] text-faint mt-0.5">秘典全章节重写</p>
              </div>
            </div>
            <div className="rounded-sm bg-obsidian/60 border border-xp/30 p-3.5 flex items-center gap-3">
              <CheckCircle2 className="text-xp shrink-0" size={24} />
              <div>
                <p className="font-vt text-[26px] leading-none text-xp">Ready</p>
                <p className="text-[11px] text-faint mt-0.5">即插即用替换补丁</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Nav Tabs */}
      <div className="sticky top-14 z-30 bg-obsidian/95 backdrop-blur-md border-y border-arcane/15 px-6 md:px-12">
        <div className="max-w-6xl mx-auto flex overflow-x-auto wiki-scroll gap-2 py-2.5">
          {[
            { id: "facts", label: "代码偏差对账 (10 处)", icon: AlertTriangle, tone: "#f08cc8" },
            { id: "lexicon", label: "人话转换字典 (9 个)", icon: MessageSquare, tone: "#e8c37c" },
            { id: "chapters", label: "《纂刻秘典》8 章人话试读", icon: BookOpen, tone: "#7ee8dc" },
            { id: "patches", label: "可直接替换文本包 (JSON/MD)", icon: FileText, tone: "#8df0a4" },
          ].map((tab) => {
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className="flex items-center gap-2 px-4 py-2 rounded-sm text-[12.5px] font-medium whitespace-nowrap transition-all border cursor-pointer"
                style={{
                  color: active ? "#0a0913" : "#ede6d4",
                  background: active ? tab.tone : "rgba(10,9,19,0.5)",
                  borderColor: active ? tab.tone : "rgba(161,140,255,0.15)",
                }}
              >
                <tab.icon size={14} style={{ color: active ? "#0a0913" : tab.tone }} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab 1: Facts Drift Table */}
      {activeTab === "facts" && (
        <section className="px-6 md:px-12 py-10 max-w-6xl mx-auto space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display font-black text-2xl text-parch">
                文本与实际代码的 10 大事实性偏差
              </h2>
              <p className="text-sm text-mute mt-1 font-light">
                文案声称的规则与 Java 逻辑或 JSON 数据包完全矛盾，会导致玩家操作受阻或产生恶性 Bug 疑虑。
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {CODE_DRIFT_FACTS.map((fact) => (
              <div
                key={fact.id}
                className="pixelframe bg-vellum/75 border border-inkd/30 p-5 md:p-6 space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className="font-code text-[11px] font-bold px-2 py-0.5 rounded-sm bg-inkd/15 border border-inkd/40 text-inkd">
                      {fact.id}
                    </span>
                    <h3 className="font-display font-bold text-base md:text-lg text-parch">
                      {fact.title}
                    </h3>
                  </div>
                  <code className="font-code text-[10.5px] text-faint break-all bg-obsidian/70 px-2 py-1 rounded">
                    {fact.location}
                  </code>
                </div>

                {/* Compare Grid */}
                <div className="grid md:grid-cols-2 gap-3 pt-1">
                  <div className="rounded-sm bg-obsidian/85 border border-red-500/25 p-3.5">
                    <p className="font-code text-[10px] text-red-400 mb-1 flex items-center gap-1.5 font-bold">
                      ✕ 当前错误/误导文案
                    </p>
                    <p className="text-[12.5px] text-red-200/90 leading-5.5 font-light">
                      {fact.wrongTextZh}
                    </p>
                  </div>
                  <div className="rounded-sm bg-obsidian/85 border border-xp/25 p-3.5">
                    <p className="font-code text-[10px] text-xp mb-1 flex items-center gap-1.5 font-bold">
                      ✓ 代码实际运行逻辑
                    </p>
                    <p className="text-[12.5px] text-emerald-200/90 leading-5.5 font-light">
                      {fact.actualCodeRule}
                    </p>
                  </div>
                </div>

                {/* Impact */}
                <div className="text-[12px] text-gild/90 bg-gild/8 border border-gild/20 px-3 py-2 rounded-sm leading-5">
                  <span className="font-bold">实操危害：</span>
                  {fact.hazard}
                </div>

                {/* Direct replacement block */}
                <div className="rounded-sm bg-[#120f24] border border-tealw/25 p-3 flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="font-code text-[10px] text-tealw font-bold mb-0.5">
                      建议直接替换文本 (zh_cn)
                    </p>
                    <p className="text-[12.5px] text-parch leading-5 truncate">
                      {fact.correctedZh}
                    </p>
                  </div>
                  <button
                    onClick={() => copyToClipboard(fact.correctedZh, fact.id)}
                    className="px-2.5 py-1 text-[11px] font-code rounded border border-tealw/35 text-tealw hover:bg-tealw/10 transition-colors flex items-center gap-1 shrink-0 cursor-pointer"
                  >
                    {copiedKey === fact.id ? <Check size={12} /> : <Copy size={12} />}
                    {copiedKey === fact.id ? "已复制" : "复制"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Tab 2: Jargon to Human Lexicon */}
      {activeTab === "lexicon" && (
        <section className="px-6 md:px-12 py-10 max-w-6xl mx-auto space-y-6">
          <div>
            <h2 className="font-display font-black text-2xl text-parch">
              人话转换字典 · 告别机翻与伪学术
            </h2>
            <p className="text-sm text-mute mt-1 font-light">
              为什么玩家讨厌许多模组说明？因为作者把最通俗的游戏机制用最晦涩的生造词包装。以下是规范化改写指南：
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {TERMINOLOGY_DICTIONARY.map((term, i) => (
              <div
                key={term.jargon}
                className="pixelframe bg-vellum/70 border border-arcane/20 p-5 flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-code text-[10px] text-faint">词条 #{i + 1}</span>
                    <span className="font-code text-[9.5px] px-2 py-0.5 rounded bg-arcane/15 text-arcane">
                      {term.mcStyle}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 mb-3">
                    <span className="font-display font-bold text-red-400 text-base line-through opacity-85">
                      {term.jargon}
                    </span>
                    <ArrowRight size={14} className="text-gild shrink-0" />
                    <span className="font-display font-black text-emerald-400 text-lg">
                      {term.human}
                    </span>
                  </div>

                  <p className="text-[12px] leading-5 text-mute font-light mb-3">
                    {term.reason}
                  </p>
                </div>

                <div className="space-y-2 pt-2 border-t border-arcane/10 font-light text-[11.5px]">
                  <div className="text-red-300/80 bg-red-950/30 p-2 rounded border border-red-500/20">
                    <span className="font-bold block text-[10px] text-red-400">避坑示范：</span>
                    {term.exampleBad}
                  </div>
                  <div className="text-emerald-300/90 bg-emerald-950/30 p-2 rounded border border-emerald-500/20">
                    <span className="font-bold block text-[10px] text-emerald-400">人话示范：</span>
                    {term.exampleGood}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Tab 3: Chapter-by-Chapter Rewrites */}
      {activeTab === "chapters" && (
        <section className="px-6 md:px-12 py-10 max-w-6xl mx-auto space-y-6">
          <div>
            <h2 className="font-display font-black text-2xl text-parch">
              《纂刻秘典》8 章通俗人话逐章试读
            </h2>
            <p className="text-sm text-mute mt-1 font-light">
              将游戏中 8 个章节的全部正文，从原先的数学公式堆砌彻底重写为通俗自然的原版 Minecraft 口吻：
            </p>
          </div>

          <div className="space-y-6">
            {CHAPTER_REWRITES.map((ch) => (
              <div
                key={ch.chapterNum}
                className="pixelframe bg-vellum/75 border border-arcane/20 p-5 md:p-7 space-y-4"
              >
                <div className="flex items-center gap-3">
                  <span className="font-pixel text-xl text-gild">
                    CH {String(ch.chapterNum).padStart(2, "0")}
                  </span>
                  <h3 className="font-display font-black text-xl text-parch">
                    {ch.title}
                  </h3>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  {/* Original */}
                  <div className="rounded-sm bg-obsidian/80 border border-red-500/20 p-4 space-y-2">
                    <div className="flex items-center justify-between text-red-400 font-code text-[11px] font-bold">
                      <span>✕ 当前晦涩机翻版 (含事实错误)</span>
                    </div>
                    <p className="text-[13px] text-red-200/80 leading-6 font-light">
                      {ch.originalBad}
                    </p>
                  </div>

                  {/* Rewritten */}
                  <div className="rounded-sm bg-obsidian/80 border border-emerald-500/30 p-4 space-y-2 relative">
                    <div className="flex items-center justify-between text-emerald-400 font-code text-[11px] font-bold">
                      <span>✓ 润色后通俗人话版 (100% 真实)</span>
                      <button
                        onClick={() => copyToClipboard(ch.rewrittenGood, `ch-${ch.chapterNum}`)}
                        className="px-2 py-0.5 text-[10px] font-code rounded border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/10 transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        {copiedKey === `ch-${ch.chapterNum}` ? <Check size={11} /> : <Copy size={11} />}
                        {copiedKey === `ch-${ch.chapterNum}` ? "已复制" : "复制代码"}
                      </button>
                    </div>
                    <p className="text-[13px] text-emerald-100 leading-6 font-light">
                      {ch.rewrittenGood}
                    </p>
                  </div>
                </div>

                <div className="text-[11.5px] text-mute flex items-center gap-2 pt-1 font-light">
                  <Sparkles size={13} className="text-gild shrink-0" />
                  <span>改写点评：{ch.whyBetter}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Tab 4: Ready-to-Replace Code Patches */}
      {activeTab === "patches" && (
        <section className="px-6 md:px-12 py-10 max-w-6xl mx-auto space-y-8">
          <div>
            <h2 className="font-display font-black text-2xl text-parch">
              直接可替换的文本补丁包 (Ready-to-Replace)
            </h2>
            <p className="text-sm text-mute mt-1 font-light">
              开发者或服主可以直接复制下方的完整 JSON 覆盖到对应的语言文件中，一次性修复全仓的所有文字错误与人话缺陷。
            </p>
          </div>

          {/* Patch 1: zh_cn.json */}
          <div className="pixelframe bg-[#0c0919] border border-gild/35 overflow-hidden">
            <div className="px-6 py-4 border-b border-arcane/20 flex flex-wrap items-center justify-between gap-3 bg-vellum/60">
              <div>
                <p className="font-display font-bold text-parch text-base">
                  补丁 1：zh_cn.json 纠偏补丁（完整标准格式）
                </p>
                <code className="font-code text-[11px] text-faint">
                  src/client/resources/assets/chiseled_enchanting_table/lang/zh_cn.json
                </code>
              </div>
              <button
                onClick={() =>
                  copyToClipboard(
                    JSON.stringify(DIRECT_REPLACE_ZH, null, 2),
                    "patch-zh"
                  )
                }
                className="px-4 py-2 pixelframe bg-gild/15 border border-gild/50 text-gild font-code text-xs flex items-center gap-2 hover:bg-gild/25 transition-colors cursor-pointer"
              >
                {copiedKey === "patch-zh" ? <Check size={14} /> : <Copy size={14} />}
                {copiedKey === "patch-zh" ? "已复制到剪贴板！" : "一键复制完整 JSON 片段"}
              </button>
            </div>
            <pre className="p-6 font-code text-[11.5px] leading-5 text-emerald-200/90 overflow-x-auto max-h-[380px] wiki-scroll">
              {JSON.stringify(DIRECT_REPLACE_ZH, null, 2)}
            </pre>
          </div>

          {/* Patch 2: en_us.json */}
          <div className="pixelframe bg-[#0c0919] border border-tealw/35 overflow-hidden">
            <div className="px-6 py-4 border-b border-arcane/20 flex flex-wrap items-center justify-between gap-3 bg-vellum/60">
              <div>
                <p className="font-display font-bold text-parch text-base">
                  补丁 2：en_us.json 对称纠偏补丁（英文原版对齐）
                </p>
                <code className="font-code text-[11px] text-faint">
                  src/client/resources/assets/chiseled_enchanting_table/lang/en_us.json
                </code>
              </div>
              <button
                onClick={() =>
                  copyToClipboard(
                    JSON.stringify(DIRECT_REPLACE_EN, null, 2),
                    "patch-en"
                  )
                }
                className="px-4 py-2 pixelframe bg-tealw/15 border border-tealw/50 text-tealw font-code text-xs flex items-center gap-2 hover:bg-tealw/25 transition-colors cursor-pointer"
              >
                {copiedKey === "patch-en" ? <Check size={14} /> : <Copy size={14} />}
                {copiedKey === "patch-en" ? "已复制到剪贴板！" : "一键复制完整 JSON 片段"}
              </button>
            </div>
            <pre className="p-6 font-code text-[11.5px] leading-5 text-tealw/90 overflow-x-auto max-h-[380px] wiki-scroll">
              {JSON.stringify(DIRECT_REPLACE_EN, null, 2)}
            </pre>
          </div>

          {/* Patch 3: WIKI.md */}
          <div className="pixelframe bg-[#0c0919] border border-arcane/35 overflow-hidden">
            <div className="px-6 py-4 border-b border-arcane/20 flex flex-wrap items-center justify-between gap-3 bg-vellum/60">
              <div>
                <p className="font-display font-bold text-parch text-base">
                  补丁 3：docs/WIKI.md 核心段落纠偏（Markdown）
                </p>
                <code className="font-code text-[11px] text-faint">
                  docs/WIKI.md §3, §4, §8 修正段落
                </code>
              </div>
              <button
                onClick={() =>
                  copyToClipboard(
                    `### 3.2 经验减免上限算术说明
经验减免计算为分段叠加，而非简单的三个数直接相加：
1. **公共减免**：$\\Delta_{\\text{公共}} = \\min(35\\%, \\; \\Delta_{\\text{木书架}}(W) + \\Delta_{\\text{全局藏书}}(E))$；
2. **专属母本减免**：若存有同种母本，额外获得最高 $15\\%$ 的专属减免；
3. **最终减免上限**：$\\Delta_{\\text{总}} = \\min(40\\%, \\; \\Delta_{\\text{公共}} + \\Delta_{\\text{专属}})$。

### 8. 内置物品置换配方总表（修正版）
| 产出物品 | 上槽输入 | 下槽主材料 | 背包辅料 | 经验要求（原版量产规则） |
| :--- | :--- | :--- | :--- | :---: |
| **书**（空白覆写） | \`褪魔残卷\` | \`2× 纸/骨粉/青金石/绿宝石/墨囊/发光墨囊/紫水晶\` | 无 | 需 \`Lv.1\` · **扣 1 级** |
| **附魔之瓶** | \`玻璃瓶\` | \`8× 青金石\` | \`2× 紫水晶碎片\` | 需 \`Lv.5\`（保底 \`Lv.3\`）· **扣 1 级** |
| **回响碎片** | \`紫水晶碎片\` | \`4× 幽匿块\` | \`2× 哭泣的黑曜石\` | 需 \`Lv.12\` · **扣 2 级** |
| **附魔金苹果** | \`金苹果\` | \`8× 金块\` | \`14× 绿宝石\` | 需 \`Lv.20\` · **扣 2 级** |
| **三叉戟** | \`钻石剑\` | \`1× 鹦鹉螺壳\` | \`3× 海晶碎片\` + \`2× 海晶砂粒\` | 需 \`Lv.25\` · **扣 3 级** |
| **不死图腾** | \`绿宝石块\` | \`4× 金块\` | \`1× 恶魂之泪\` + \`5× 紫水晶碎片\` | 需 \`Lv.30\` · **扣 3 级** |`,
                    "patch-md"
                  )
                }
                className="px-4 py-2 pixelframe bg-arcane/15 border border-arcane/50 text-arcane font-code text-xs flex items-center gap-2 hover:bg-arcane/25 transition-colors cursor-pointer"
              >
                {copiedKey === "patch-md" ? <Check size={14} /> : <Copy size={14} />}
                {copiedKey === "patch-md" ? "已复制到剪贴板！" : "一键复制 Markdown 修正段"}
              </button>
            </div>
            <pre className="p-6 font-code text-[11.5px] leading-5 text-parch/90 overflow-x-auto max-h-[300px] wiki-scroll whitespace-pre-wrap">
{`### 3.2 经验减免上限算术说明
经验减免计算为分段叠加，而非简单的三个数直接相加：
1. 公共减免：Δ_公共 = min(35%, Δ_木书架 + Δ_全局藏书)；
2. 专属母本减免：若存有同种母本，额外获得最高 15% 的专属减免；
3. 最终减免上限：Δ_总 = min(40%, Δ_公共 + Δ_专属)。

### 8. 内置物品置换配方总表（修正版）
- 空白覆写：2× 纸/骨粉/青金石...，需 Lv.1，扣 1 级（受残卷三梯度折减）
- 附魔之瓶：需 Lv.5（保底 Lv.3），扣 1 级
- 附魔金苹果：需 Lv.20，扣 2 级
- 三叉戟：需 Lv.25，扣 3 级
- 不死图腾：需 Lv.30，扣 3 级`}
            </pre>
          </div>
        </section>
      )}
    </div>
  );
}
