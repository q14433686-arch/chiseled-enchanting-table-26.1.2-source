import type { ReactNode } from "react";
import { cn } from "../utils/cn";
import type { Severity } from "../data/audit";

export function PageHeader({ kicker, title, children }: { kicker: string; title: string; children?: ReactNode }) {
  return (
    <div className="mb-10 max-w-3xl">
      <p className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-violet-700">{kicker}</p>
      <h1 className="text-3xl font-bold leading-tight text-stone-900 md:text-4xl">{title}</h1>
      {children && <div className="mt-4 text-[15px] leading-7 text-stone-600">{children}</div>}
    </div>
  );
}

export function SectionTitle({ n, title, desc }: { n: string; title: string; desc?: string }) {
  return (
    <div className="mb-5 mt-14 flex items-baseline gap-3 border-b border-stone-200 pb-3">
      <span className="font-mono text-sm text-violet-700">{n}</span>
      <div>
        <h2 className="text-xl font-semibold text-stone-900">{title}</h2>
        {desc && <p className="mt-1 text-sm text-stone-500">{desc}</p>}
      </div>
    </div>
  );
}

const SEV_STYLE: Record<Severity, string> = {
  严重: "bg-red-700 text-white",
  高: "bg-orange-100 text-orange-800 ring-1 ring-orange-300",
  中: "bg-amber-50 text-amber-800 ring-1 ring-amber-200",
  低: "bg-stone-100 text-stone-600 ring-1 ring-stone-200",
};

export function SevBadge({ s }: { s: Severity }) {
  return <span className={cn("rounded-md px-2 py-0.5 text-xs font-semibold", SEV_STYLE[s])}>{s}</span>;
}

export function Chip({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span className={cn("rounded-md bg-stone-100 px-2 py-0.5 text-xs text-stone-600", className)}>{children}</span>
  );
}

export function Code({ children }: { children: string }) {
  return (
    <pre className="overflow-x-auto rounded-lg bg-stone-900 p-3.5 font-mono text-[12.5px] leading-6 text-stone-100">
      {children}
    </pre>
  );
}
