export interface TermConflict {
  concept: string;
  variants: { text: string; where: string }[];
  recommendZh: string;
  recommendEn: string;
  reason: string;
}

export const TERM_CONFLICTS: TermConflict[] = [
  {
    concept: "装备上的词条容量（◇）",
    variants: [
      { text: "器魂槽", where: "zh_cn ×6 · GDD ×11 · Javadoc" },
      { text: "器灵槽", where: "zh_cn ×4（grimoire.rules_vessel 等）" },
      { text: "Vessel Spirit / Vessel Slot / Vessel Socket / Vessel", where: "en_us 四种写法混用" },
    ],
    recommendZh: "器魂槽",
    recommendEn: "Vessel Slot",
    reason: "“器魂”出现次数最多，也是页签名“器魂铭刻”的来源。“器灵”应全部替换。英文只用 Slot 一个词，Socket 只在描述动作时用（“socket a book”）。",
  },
  {
    concept: "姊妹模组名",
    variants: [
      { text: "雕纹附魔台", where: "zh_cn ×7 · README" },
      { text: "雕錾附魔台", where: "zh_cn ×1（rules_vessel）" },
      { text: "纂刻附魔台", where: "zh_tw ×8 · GDD ×13 · README 并列" },
    ],
    recommendZh: "以姊妹模组自己的官方中文名为准（建议统一为“纂刻附魔台”）",
    recommendEn: "Chiseled Enchanting Table",
    reason: "同一款模组有三个中文名，简体和繁体还各不相同。玩家去搜也搜不到对应的模组。README 里两个名字并列写，更让人以为是两款不同的模组。",
  },
  {
    concept: "顺序相关的手工专属组合",
    variants: [
      { text: "双星签名 / 双星融合", where: "zh_cn" },
      { text: "手工共鸣 / 手工专属", where: "GDD" },
      { text: "Signature Resonance", where: "README" },
      { text: "binary fusions", where: "en_us 秘典 lore" },
    ],
    recommendZh: "签名共鸣（简称“签名”）",
    recommendEn: "Signature Resonance (Signature)",
    reason: "“双星”在 UI 里突然出现，没有任何解释；“手工”是开发者视角的说法，玩家不需要知道。英文 README 已经用了 Signature Resonance，中文应该和它对应。",
  },
  {
    concept: "失稳后生成的负面词条",
    variants: [
      { text: "畸融异变", where: "GDD ×18 · README" },
      { text: "畸变融合", where: "zh_cn 失败消息 ×3" },
      { text: "失稳畸变词条", where: "zh_cn rules_vessel" },
      { text: "畸变残卷手札", where: "物品名" },
      { text: "Aberrant Fusion / Aberration / Aberrant Mutation", where: "en_us / README" },
    ],
    recommendZh: "畸变词条（过程叫“畸变”，物品叫“畸变手札”）",
    recommendEn: "Aberrant Fusion",
    reason: "名词和动词要分开：过程是“失稳 → 畸变”，结果是“畸变词条”。“畸融异变”四个字里两个字重复表达同一个意思，读起来很拗口。",
  },
  {
    concept: "单本附魔铭刻到非原生装备",
    variants: [
      { text: "异位单附魔化形", where: "README · GDD" },
      { text: "异位单魔化形", where: "zh_cn 秘典 lore（漏了一个“附”字）" },
      { text: "异位转换 / 异位铭刻 / 跨界单附魔", where: "zh_cn 按钮与提示" },
      { text: "Cross-Domain Transmutation / Transmute", where: "en_us" },
    ],
    recommendZh: "异位化形（动作按钮写“化形铭刻”）",
    recommendEn: "Cross-Domain Transmutation",
    reason: "原名有 7 个字，在 UI 里几乎每次都被截短，而且截法不一样。把四字词定为标准名，动作统一叫“铭刻”。“跨界”留给融合词条的“可插入任意装备”这个概念，不要和化形混用。",
  },
  {
    concept: "降低失败率的道具",
    variants: [
      { text: "谐振稳定晶", where: "物品名（zh_cn）" },
      { text: "共鸣稳定剂", where: "zh_cn 秘典 rules_fees" },
      { text: "稳定晶 / 稳定剂", where: "GDD" },
      { text: "Resonance Stabilizer", where: "en_us" },
    ],
    recommendZh: "共鸣稳定晶",
    recommendEn: "Resonance Stabilizer",
    reason: "“谐振”和“共鸣”在中文里都对应 Resonance，现在两个词混用；“剂”和“晶”也不统一。建议全模组都用“共鸣”（签名共鸣、共鸣稳定晶），去掉“谐振”。",
  },
  {
    concept: "图鉴的三个阶段",
    variants: [
      { text: "未知 → 初识 → 通晓", where: "zh_cn · CHANGELOG" },
      { text: "STATE_HEARD / STATE_MASTERED", where: "代码常量" },
      { text: "Mastered（只有这一阶段有英文）", where: "en_us" },
    ],
    recommendZh: "未知 → 初识 → 通晓",
    recommendEn: "Unknown → Glimpsed → Mastered",
    reason: "中文三阶段已经比较好记，但英文缺第二阶段的名字。代码常量 HEARD 也和中文“初识”对不上，建议重命名为 GLIMPSED。",
  },
  {
    concept: "A / B 两个位置",
    variants: [
      { text: "主体 / 副用", where: "zh_cn 槽位短标签" },
      { text: "体 / 用", where: "GDD（先附为体、后融为用）" },
      { text: "主 / 副、主位 / 副位", where: "zh_cn 提示" },
      { text: "Host / Graft · Primary / Secondary", where: "en_us 两套" },
    ],
    recommendZh: "A 主 · B 副",
    recommendEn: "A · Primary  /  B · Secondary",
    reason: "英文的 “Host” 已经用来指“承载装备”（Host Gear），A 槽再叫 Host 会让人分不清。“体 / 用”可以作为 GDD 里的哲学比喻，不要写进 UI。",
  },
];

export interface NumberClaim {
  item: string;
  values: { value: string; where: string }[];
  truth: string;
}

export const NUMBER_CLAIMS: NumberClaim[] = [
  {
    item: "签名共鸣数量",
    values: [
      { value: "108", where: "README · GDD · CHANGELOG" },
      { value: "114", where: "CURRENT_BASELINE" },
    ],
    truth: "代码里有 114 次 reg()，其中 37 个另外用 regAlias 注册了对称方向",
  },
  {
    item: "异位化形数量",
    values: [
      { value: "111", where: "README · GDD 首屏" },
      { value: "115", where: "CURRENT_BASELINE" },
    ],
    truth: "ALL_VARIANTS 表中有 115 条",
  },
  {
    item: "支持的原版附魔数",
    values: [
      { value: "42", where: "README · GDD" },
      { value: "43", where: "BASELINE · 启动日志 · matrix_profiles.json" },
    ],
    truth: "43（26.1.2 新增了突进 Lunge）",
  },
  {
    item: "融合台页签数",
    values: [
      { value: "3-Tab", where: "README · GDD · Menu/Operations 的 Javadoc · lang tab.compendium" },
      { value: "2-Tab", where: "BASELINE · FusionNetworking Javadoc · 实际代码" },
    ],
    truth: "2 个页签，图鉴已经拆成独立的《融合秘典》",
  },
  {
    item: "互斥融合基础失稳率",
    values: [
      { value: "35%", where: "GDD §4 · repulsive_pairs.json · FusionMatrixRegistry" },
      { value: "45%", where: "FusionEconomyRules（实际生效的值）" },
    ],
    truth: "45%，每颗稳定晶降低 12%，最低 8%",
  },
  {
    item: "GDD 版本号",
    values: [
      { value: "v3.0 · 0.3.1", where: "docs/GDD.md 标题" },
      { value: "0.4.0", where: "gradle.properties · README · BASELINE" },
    ],
    truth: "0.4.0：GDD 落后了一个大版本",
  },
  {
    item: "仓库名 vs 模组名",
    values: [
      { value: "chiseled-enchanting-table-26.1.2-source", where: "GitHub 仓库 · fabric.mod.json contact" },
      { value: "Enchantment Fusion", where: "模组本体" },
    ],
    truth: "这个仓库实际是“融合附魔”，但仓库名是姊妹模组的名字",
  },
];

export interface Rewrite {
  key: string;
  issue: string;
  beforeZh: string;
  afterZh: string;
  beforeEn: string;
  afterEn: string;
}

export const REWRITES: Rewrite[] = [
  {
    key: "item.resonance_stabilizer.lore",
    issue: "说法错误：实际做不到 100%；中英文意思不一致",
    beforeZh: "在融合满级互斥附魔时消除排斥波动，确保100%稳定成书。",
    afterZh: "放入催化槽：每颗降低失败率。互斥融合最多可用 3 颗，最低仍有 8% 失稳。",
    beforeEn: "Eliminates instability when fusing max-level repulsive enchantments.",
    afterEn: "Catalyst slot: each lowers failure chance. Repulsive fusions use up to 3; 8% minimum remains.",
  },
  {
    key: "message.failure.normal_refund",
    issue: "强调“退还”，但没写清丢了什么；“副卷”有时并不准确",
    beforeZh: "共鸣溃散：载体无恙，损耗副卷 1 本，已返还半数经验与材料费用。",
    afterZh: "融合失败：失去【%s】。装备完好，经验和材料只扣了一半。",
    beforeEn: "Resonance faltered: host stayed safe, 1 book consumed, 50% fee refunded.",
    afterEn: "Fusion failed: lost [%s]. Gear is safe; only half the cost was charged.",
  },
  {
    key: "tip.flip.desc",
    issue: "实际消耗的不只是紫水晶碎片，也可能是青金石、稳定晶，或者 2 级经验",
    beforeZh: "消耗紫水晶碎片，将目标上的 [A ▷ B] 原地翻转为 [B ▷ A]。",
    afterZh: "把 [A ▷ B] 翻成 [B ▷ A]。费用：2 级经验，或催化槽中的 1 个紫水晶碎片 / 青金石。",
    beforeEn: "Reverses [A ▷ B] on the target item using an Amethyst Shard.",
    afterEn: "Turns [A ▷ B] into [B ▷ A]. Cost: 2 levels, or 1 Amethyst Shard / Lapis in the catalyst slot.",
  },
  {
    key: "reject.missing_input",
    issue: "和“支持多词条附魔书”的提示互相矛盾",
    beforeZh: "需在 A、B 槽各放入一本单词条附魔书",
    afterZh: "请选出两种不同的附魔（可以来自同一本多词条书）",
    beforeEn: "Requires two single-enchantment books",
    afterEn: "Pick two different enchantments (one multi-enchant book is fine)",
  },
  {
    key: "reject.duplicate_on_host",
    issue: "代码里“已有更高或相同等级”的情况也会返回这条；中文写“互斥”、英文写 conflicting，两边意思也不一样",
    beforeZh: "目标装备已承载相同或互斥的词条",
    afterZh: "装备上已有这项附魔（等级相同或更高）",
    beforeEn: "Host already carries a conflicting enchantment",
    afterEn: "Gear already has this enchantment at the same or higher level",
  },
  {
    key: "grimoire.rules_vessel.body",
    issue: "105 字一整段，混用了“器灵槽 / 跨界 / 失稳畸变 / 雕錾”四个非标准词",
    beforeZh:
      "双附魔融合词条【主 ▷ 副】占 1 枚器灵槽，可跨界铭刻于任意装备（含 26.1.2 全系长矛与铜质装备，其中金矛天生 2◇）。原生单附魔与异位单附魔均占 0 枚器灵槽；唯有失稳畸变词条须借雕錾附魔台净化剥离。",
    afterZh:
      "• 每条融合词条占 1 个器魂槽 ◇，可以插在任何装备上。\n• 普通装备有 1 槽，金质装备（含金矛）有 2 槽，上限都是 2。\n• 原版附魔和异位化形不占槽。\n• 畸变词条只能在纂刻附魔台清除。",
    beforeEn: "—",
    afterEn:
      "• Each fused pair uses 1 Vessel Slot ◇ and fits any gear.\n• Normal gear: 1 slot; gold gear (incl. golden spear): 2; max 2.\n• Vanilla enchants and transmutations use no slots.\n• Aberrant Fusions can only be cleansed at the Chiseled Enchanting Table.",
  },
  {
    key: "slot.primary_short / secondary_short",
    issue: "英文 Host 和 Host Gear 撞词；Graft 不是常用词",
    beforeZh: "A · 主体 ／ B · 副用",
    afterZh: "A · 主 ／ B · 副",
    beforeEn: "A · Host ／ B · Graft",
    afterEn: "A · Primary ／ B · Secondary",
  },
  {
    key: "btn.unsocket",
    issue: "英文 “Out” 太短，看不出是什么操作",
    beforeZh: "卸下",
    afterZh: "卸下",
    beforeEn: "Out",
    afterEn: "Remove",
  },
  {
    key: "btn.fuse（谐振融合）",
    issue: "按钮用了修饰性的词，没说清结果",
    beforeZh: "谐振融合",
    afterZh: "融合成书",
    beforeEn: "Fuse",
    afterEn: "Fuse",
  },
  {
    key: "fusion_grimoire.lore",
    issue: "“双星”“异位单魔”都是没有解释过的缩写",
    beforeZh: "手持右键翻阅：查询双星融合、异位单魔化形与三阶探索图鉴",
    afterZh: "右键翻阅：查看已发现的签名共鸣、异位化形和畸变词条",
    beforeEn: "Right-click to consult discovered binary fusions & cross-domain transmutations",
    afterEn: "Right-click to browse discovered Signatures, Transmutations and Aberrations",
  },
];

export const STYLE_RULES: { title: string; body: string; example?: string }[] = [
  {
    title: "一个概念只用一个词",
    body: "维护一份 glossary.json（中、英、繁、日），CI 扫描 lang 和 docs 时，遇到“禁用同义词”就报错。比如出现“器灵槽”时提示改成“器魂槽”。",
    example: "forbidden: { \"器灵槽\": \"器魂槽\", \"雕錾附魔台\": \"纂刻附魔台\" }",
  },
  {
    title: "提示里先写结果，再写原因",
    body: "失败或拒绝的提示先告诉玩家“发生了什么、丢了什么”，再解释原因。不要用“共鸣溃散”“斥力暴走”这类氛围词开头，氛围可以放在音效和粒子里。",
    example: "✗ 高阶斥力失稳暴走！魔力扭曲凝结为【畸变融合】！\n✓ 融合失稳：生成了畸变词条【狂血反噬】（只能在纂刻附魔台清除）",
  },
  {
    title: "数字只在一个地方定义",
    body: "README、GDD、秘典里写的数量和概率，都应该在构建时从代码或数据导出（比如 gradle 任务生成 docs/generated/stats.md），不要手抄。",
  },
  {
    title: "单条说明控制在 40 个汉字 / 80 个英文字符以内",
    body: "秘典正文超过两行就改成要点列表。当前 rules_* 的正文都在 88–105 字之间，在 360 px 宽的页面上要排 5–6 行。",
  },
  {
    title: "术语第一次出现时附带解释",
    body: "【◇】【A ▷ B】【异位】这些符号和自造词，要在秘典第一页的“图例”里统一解释，后面直接使用。",
  },
  {
    title: "英文不要逐字照搬中文",
    body: "“万物皆可铭刻”译成 “Universal Sockets” 就可以；“原地融魂”译成 “Fuse Gear” 也已经足够。重点是英文按钮的长度要和中文一致，避免溢出。",
  },
  {
    title: "Markdown 少用强调",
    body: "README 和 GDD 里几乎每句都加粗、加反引号、加感叹号，重点反而看不出来。建议每段最多加粗 1 处，感叹号只在真正的警告里用。",
  },
];

export const DEAD_KEYS = [
  "preview.idle_line1",
  "preview.idle_line2",
  "preview.flip_split_ready",
  "preview.blocked",
  "preview.expand_title",
  "preview.expand_desc",
  "preview.topup_title",
  "preview.topup_desc",
  "preview.repulsive_stability",
  "preview.harmonic_stable",
  "tip.flip.title",
  "tip.flip.desc",
  "tip.split.title",
  "tip.split.desc",
  "tip.preview.title",
  "tab.compendium",
  "slot.split_target",
  "tab2.place_book_hint",
  "btn.xp_badge",
];

export const DOC_RESTRUCTURE = [
  {
    doc: "README.md",
    now: "一句话简介后面直接跟 4 个大段落，每段有 3–6 处加粗和中英混排术语，第一屏里看不到安装方法。",
    next: "改成：一句话 → 截图 → 30 秒上手（3 步）→ 特性列表（每条 1 行）→ 安装 → 链接到 GDD。数量统计放在一个从代码生成的表格里。",
  },
  {
    doc: "docs/GDD.md",
    now: "标题写的是 0.3.1；正文开头用 Phase 3 → Phase 2 的倒序更新日志，真正的设计内容到第 40 行之后才开始；第 163 行描述的“标签兼容”实际并没有实现。",
    next: "把 Phase 摘要移到 CHANGELOG；GDD 只描述当前状态。每一节加“实现状态”标记（✅ 已实现 / 🚧 部分实现 / 📝 计划中），并定期与代码核对。",
  },
  {
    doc: "CURRENT_BASELINE.md",
    now: "所有信息挤在一个超长的 Milestone 句子里（约 600 字符）。",
    next: "改成键值表：版本、目标、Mixin 数、签名数、化形数、页签数、语言键数，并由 CI 自动更新。",
  },
  {
    doc: "游戏内《融合秘典》",
    now: "规则页有 4 段长文；没有图例；搜索框不支持输入法（GUI-03）。",
    next: "第 1 页放图例（◇、A ▷ B、异位、畸变）；规则拆成 6 张卡片，每张 ≤ 3 行；每条签名的页面显示“正向 / 反向 / 对称”标记。",
  },
];
