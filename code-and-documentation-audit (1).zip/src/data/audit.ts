export type Severity = "严重" | "高" | "中" | "低";

export type Category =
  | "源码 API"
  | "数据编解码"
  | "网络同步"
  | "GUI 输入"
  | "Mixin 注入"
  | "死代码"
  | "耦合风险"
  | "硬编码"
  | "数值与机制";

export interface Finding {
  id: string;
  title: string;
  category: Category;
  severity: Severity;
  location: string[];
  evidence?: string;
  problem: string;
  impact: string;
  fix: string;
  confidence: "已确认" | "高度可疑" | "需实机验证";
}

export const CATEGORY_META: Record<Category, { desc: string; color: string }> = {
  "源码 API": { desc: "Fabric / 26.1.2 原版 API 的使用方式与版本语义", color: "sky" },
  "数据编解码": { desc: "Codec / StreamCodec / 存档文件的读写一致性", color: "teal" },
  "网络同步": { desc: "客户端 / 服务端的权威性与状态一致", color: "indigo" },
  "GUI 输入": { desc: "Screen 鼠标、键盘、命中区和每帧开销", color: "violet" },
  "Mixin 注入": { desc: "注入点选择、副作用以及和其它模组的冲突", color: "fuchsia" },
  "死代码": { desc: "不可达分支、未使用的 API 与语言键", color: "zinc" },
  "耦合风险": { desc: "事件顺序、跨模块重复实现、隐式约定", color: "amber" },
  "硬编码": { desc: "本应交给数据包、标签、配置或注册表的常量", color: "orange" },
  "数值与机制": { desc: "平衡性、叠加规则、文案与实现不符", color: "rose" },
};

export const FINDINGS: Finding[] = [
  // ───────────── 源码 API ─────────────
  {
    id: "API-01",
    title: "异位单附魔写进原版 ENCHANTMENTS 组件，原版数据驱动效果会被一起触发",
    category: "源码 API",
    severity: "高",
    location: [
      "FusionStationOperations.java ≈L615 (INSCRIBE_SINGLE_CROSS)",
      "FusionStationOperations.java L914-919 applyFusedPairToGear",
    ],
    evidence: `mut.set(cand.holder(), Math.max(current.getLevel(cand.holder()), clampedLv));
sTarget.set(DataComponents.ENCHANTMENTS, mut.toImmutable());`,
    problem:
      "1.21 以后附魔是数据驱动的：效果按附魔 JSON 中 `slots` 里的装备槽位生效，并不检查 `supported_items`。所以“自动熔炼”镐上的火焰附加（槽位 mainhand）照样会点燃生物；“锯刃”剑上的荆棘（槽位 any）拿在主手时也会反伤。融合词条的主附魔也会通过 setGearVanillaEnchantLevel 写进原版附魔列表，所以把【锋利 ▷ X】插到镐上，镐会真的获得锋利 V。",
    impact:
      "实际效果是“原版效果 + 化形效果”两份叠加，和 GDD 里“化形后替换原附魔行为”的说法不一致。tooltip 只显示化形名，玩家看不到原版效果还在生效。",
    fix:
      "两个方案选一个：① 化形和融合只写入自定义组件（比如 `enchantment_fusion:transmuted`），完全不碰 ENCHANTMENTS；② 保留原版写入，但通过 `EnchantmentEffectComponents` 的 mixin 或 `#enchantment_fusion:suppressed` 条件，在非原生物品上把原版 effect 屏蔽掉。",
    confidence: "高度可疑",
  },
  {
    id: "API-02",
    title: "插槽可绕过原版互斥：同一件装备上锋利 + 亡灵杀手、经验修补 + 无限 可以同时生效",
    category: "源码 API",
    severity: "高",
    location: ["FusionStationOperations.java L305 readUnfusedVanillaEnchantIds", "FusionRuleEngine.java evaluateFusion"],
    problem:
      "宿主检查只看“同一个附魔 ID 是否已存在”（DUPLICATE_ON_HOST），没有调用 `Enchantment.areCompatible` 或 exclusive_set 标签。只要宿主有 2 个器魂槽，就能分两次插入【修补 ▷ X】和【无限 ▷ Y】，两个主附魔都会写进原版 ENCHANTMENTS。",
    impact:
      "“互斥必须满级 + 有失稳风险”这条设计红线被绕开了：拆成两个普通词条，就能零风险拿到原版禁止共存的组合。",
    fix:
      "插入 / 原地融合前，对宿主现有的所有原版附魔和新的 primaryId 跑一遍 `Enchantment.areCompatible(holderA, holderB)`；冲突时返回新的 RejectReason.EXCLUSIVE_ON_HOST，并单独给它写文案。",
    confidence: "已确认",
  },
  {
    id: "API-03",
    title: "BEFORE 破坏事件里直接 setBlockAndUpdate(AIR)，跳过了原版破坏流程",
    category: "源码 API",
    severity: "高",
    location: ["CrossDomainTransmutations.java L931-1000 onBeforeBlockBreak", "MatrixRuntimeHooks.java L121"],
    evidence: `level.setBlockAndUpdate(pos, Blocks.AIR.defaultBlockState());
spawnItem(level, Vec3.atCenterOf(pos), new ItemStack(Items.CHARCOAL, 1));
...
return false; // 取消原版破坏`,
    problem:
      "清巢、炭火熔伐等效果在 PlayerBlockBreakEvents.BEFORE 里就自己删掉方块，然后返回 false。这会跳过：方块破坏统计、饥饿消耗、GameEvent.BLOCK_DESTROY（幽匿感测器收不到）、破坏粒子和音效（levelEvent 2001）、`playerWillDestroy`（比如床或门的另一半），以及矿石掉经验。",
    impact:
      "如果领地保护模组也在 BEFORE 里注册监听、而且排在本模组后面，方块会在保护检查之前就被删掉，等于绕过了保护。另外，幽匿感测器无法感知这类挖掘。",
    fix:
      "BEFORE 里只做判断，不删方块。掉落替换改成走战利品表修饰（LootTableEvents / 自定义 LootItemFunction），或者在 AFTER 里处理；如果一定要自己破坏方块，就调用 `serverPlayer.gameMode.destroyBlock` 或 `level.destroyBlock(pos, false, player)`，并补上统计和 GameEvent。",
    confidence: "已确认",
  },
  {
    id: "API-04",
    title: "ALLOW_DAMAGE 中的免伤没有排除 BYPASSES_INVULNERABILITY 类伤害",
    category: "源码 API",
    severity: "中",
    location: ["MatrixRuntimeHooks.java L54", "SignaturePairs.java L383-395 lucky_golden_body", "SignaturePairs.java L398 glass_holy_shield"],
    problem:
      "招财金身、琉璃圣盾在 ALLOW_DAMAGE 里直接返回 false，没有检查 DamageSource 类型。/kill（generic_kill）、虚空伤害、饥饿、溺水都能被概率免疫；吉星高照（ALLOW_DEATH）也一样。",
    impact: "管理员 /kill 可能概率失败，地图机制和小游戏里的“必死”判定也会失效。",
    fix:
      "开头加上 `if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) || source.is(DamageTypeTags.BYPASSES_EFFECTS)) return true;`，并考虑对 `#minecraft:no_knockback` 一类环境伤害也放行。",
    confidence: "已确认",
  },
  {
    id: "API-05",
    title: "“无界挖掘”只抵消离地惩罚，没有抵消水下惩罚，和描述不符",
    category: "源码 API",
    severity: "低",
    location: ["PlayerMiningFusionMixin.java L33-36"],
    evidence: `if (SignaturePairs.stackHasSignature(tool, "boundless_mining") && !self.onGround()) {
    mult *= 5.0F;
}`,
    problem:
      "Javadoc 写的是“无视 5 倍空中 / 水下减速”。但从 1.21 开始，水下减速由 `SUBMERGED_MINING_SPEED` 属性负责，不在 getDestroySpeed 里，这里也只在离地时乘 5。水中站在地上时完全没有效果；在水中游泳且离地时，只能抵消一半惩罚。",
    impact: "说明文案和实际表现不一致。",
    fix: "改为在 MAINHAND 上挂一个 AttributeModifier，把 submerged_mining_speed 调到 1.0；离地惩罚改用 `mining_efficiency` 或保留现有乘法。",
    confidence: "已确认",
  },
  {
    id: "API-06",
    title: "第三方附魔兜底用 Math.abs(hashCode)，碰到 Integer.MIN_VALUE 会数组越界",
    category: "源码 API",
    severity: "低",
    location: ["FusionMatrixRegistry.java L34"],
    evidence: `int h = Math.abs(enchantmentId == null ? 0 : enchantmentId.hashCode());
return new MatrixProfile(triggers[h % triggers.length], ...`,
    problem: "`Math.abs(Integer.MIN_VALUE)` 还是负数，取模后下标为负，会抛 ArrayIndexOutOfBoundsException。",
    impact: "概率极低，但一旦命中就是服务端 tick 里抛异常；而且“哈希决定触发器”本身也不符合 GDD 描述（见 HC-03）。",
    fix: "改用 `Math.floorMod(h, len)`；更好的做法是按 GDD 用标签推断。",
    confidence: "已确认",
  },

  // ───────────── 数据编解码 ─────────────
  {
    id: "DATA-01",
    title: "FusedEnchantmentList 的构造器会静默截断，但 Codec 遇到超长列表直接报错，两边行为不一致",
    category: "数据编解码",
    severity: "中",
    location: ["FusedEnchantmentList.java L14-21 / L27"],
    evidence: `pairs = List.copyOf(pairs.subList(0, limit)); // 构造器：截断
FusedPair.CODEC.listOf(0, HARD_MAX_VESSEL_SLOTS)      // Codec：超长报错`,
    problem:
      "如果将来把 HARD_MAX_VESSEL_SLOTS 改小，或者有人用 /give、NBT 编辑器写入 3 条，Codec 会解码失败，整个 `fused_pairs` 组件被丢弃；而运行期构造器的做法是保留前 2 条。",
    impact: "用旧版本存档升级时可能整组词条丢失，而且日志里只有一条 DataResult error。",
    fix: "Codec 改成 `FusedPair.CODEC.listOf().xmap(FusedEnchantmentList::new, ...)`，由构造器统一截断；或者解码失败时用 `promotePartial` 保留部分结果。",
    confidence: "已确认",
  },
  {
    id: "DATA-02",
    title: "FusedPair 用裸 String 存附魔 ID，等级被静默钳制到 1..255",
    category: "数据编解码",
    severity: "中",
    location: ["FusedPair.java L18-35"],
    problem:
      "primary/secondary 用 `Codec.STRING` 存，不是 `Identifier.CODEC` 或 `Enchantment.CODEC`（Holder）。非法 ID（大小写、空格）也会被接受；数据包删掉某个附魔后，这条词条变成孤儿，静默失效。等级为负或超过 255 时也会被悄悄改写。",
    impact: "数据包作者拿不到任何报错；StreamCodec 的 STRING_UTF8 也没有长度上限（默认 32767）。",
    fix:
      "改用 `ResourceKey.codec(Registries.ENCHANTMENT)` 存附魔 ID；等级用 `ExtraCodecs.POSITIVE_INT`，并在加载时 log 一次孤儿词条；StreamCodec 改为 `ByteBufCodecs.stringUtf8(256)`。",
    confidence: "已确认",
  },
  {
    id: "DATA-03",
    title: "融合图鉴存档：主线程同步写整份 JSON，不是原子写，也没有接入自动保存",
    category: "数据编解码",
    severity: "高",
    location: ["CompendiumDiscoveryTracker.java L321 persistAndSync", "CompendiumDiscoveryTracker.java L406-425 saveWorldFile"],
    evidence: `Files.writeString(path, GSON.toJson(root), StandardCharsets.UTF_8);`,
    problem:
      "每次有新发现（合成、研读残页、实战触发）都会把所有玩家的完整图鉴序列化后同步写盘。写入不是“临时文件 + rename”，中途崩溃会得到截断的 JSON；除了 SERVER_STOPPING 以外也不跟随 /save-all 和自动保存。",
    impact: "人多的服务器上会出现主线程 IO 卡顿；崩溃后图鉴可能整份读不出来，只会 warn 然后清空。",
    fix:
      "改用 Fabric Data Attachment（`AttachmentRegistry.createPersistent` 挂在玩家身上，带 `copyOnDeath`），或者 `SavedData` + setDirty()，由原版负责保存时机和原子写入。",
    confidence: "已确认",
  },
  {
    id: "DATA-04",
    title: "VESSEL_BONUS / PAGE_TIER：持久化 Codec 有范围限制，网络 VAR_INT 没有",
    category: "数据编解码",
    severity: "低",
    location: ["FusionDataComponents.java L24-43"],
    problem: "`Codec.intRange(0,1)` 和 `ByteBufCodecs.VAR_INT` 的约束不对称。服务端用命令写入 5 时，网络同步正常，存盘时却失败。",
    impact: "调试和命令使用时会出现“看起来生效、重进就没了”的情况。",
    fix: "要么都放宽，要么用 `ByteBufCodecs.VAR_INT.map(clamp)`，让两边一致。",
    confidence: "已确认",
  },
  {
    id: "DATA-05",
    title: "数据包无法删除内置矩阵条目，也无法清空互斥组",
    category: "数据编解码",
    severity: "中",
    location: ["FusionMatrixRegistry.java L82 合并 defaults", "FusionMatrixRegistry.java L114 groups.isEmpty() 回退"],
    problem: "profiles 是在内置默认值上做 merge，exclusive_groups 为空数组时又会回退到默认值。所以整合包作者既不能移除某个附魔的矩阵映射，也不能关掉互斥失稳。",
    impact: "整合包和魔改场景下的可配置性和 README 的宣传不符。",
    fix: "加 `\"replace\": true` 字段（参照原版 tag 的语义）；空数组明确表示“没有互斥组”。",
    confidence: "已确认",
  },

  // ───────────── 网络同步 ─────────────
  {
    id: "NET-01",
    title: "矩阵和互斥表只在服务端加载，客户端预览一直用内置默认值",
    category: "网络同步",
    severity: "高",
    location: ["FusionDataLoader.java (PackType.SERVER_DATA)", "EnchantmentFusionMenu.computePreview → FusionRuleEngine → FusionMatrixRegistry.current()"],
    problem:
      "FusionMatrixRegistry 是一个静态快照。专用服务器加载数据包后，客户端没有收到任何同步包，GUI 预览里的“互斥 / 是否可执行 / 触发器名称 / 失败率”都按客户端内置表计算。单人模式因为集成服务器和客户端共享静态字段，表面上一切正常。",
    impact: "在装了自定义数据包的服务器上，预览说可以，点了却没反应（或者反过来），玩家会以为是 bug；单人测试也发现不了这个问题。",
    fix: "注册 `MatrixSyncPayload`，在 JOIN 和 /reload（`ServerLifecycleEvents.END_DATA_PACK_RELOAD`）时下发快照；客户端维护一个独立的 ClientSnapshot。",
    confidence: "已确认",
  },
  {
    id: "NET-02",
    title: "StationAction 协议直接依赖 enum ordinal，而且没有频率限制",
    category: "网络同步",
    severity: "中",
    location: ["FusionNetworking.java L105-110", "EnchantmentFusionScreen.java L951"],
    problem: "动作类型按 `action.ordinal()` 传输。以后往枚举中间插一个值，旧客户端连新服务端时动作就会错位，比如“翻转”被当成“执行”。服务端也不限速，宏可以每 tick 发 EXECUTE。",
    impact: "版本不一致时可能误操作并扣经验；按 tick 刷包会放大 inspect() 的计算量。",
    fix: "改成每个动作一个独立 payload，或者使用 `StationAction.STREAM_CODEC = ByteBufCodecs.idMapper(...)` 并配显式 id；同一菜单每 tick 最多处理 N 个动作。",
    confidence: "已确认",
  },
  {
    id: "NET-03",
    title: "多人共用同一张融合台时，下标选择会错位",
    category: "网络同步",
    severity: "中",
    location: ["EnchantmentFusionMenu.java uiState (per-menu)", "FusionStationOperations.collectCandidates (shared BE)"],
    problem: "方块实体的库存是共享的，但 A/B 选中的是“候选列表下标”，而且每个菜单单独保存。玩家甲选好 #2 之后，玩家乙往槽里换了一本书，甲点执行时 #2 指向的已经是另一条附魔。",
    impact: "可能融合出意料之外的组合，消耗的书和经验也不是玩家预期的那些。",
    fix: "选择状态改为保存 `(sourceSlot, enchantId)`，执行前重新匹配；或者一张台同时只允许一个人打开（像酿造台那样用 startOpen 计数加锁）。",
    confidence: "已确认",
  },
  {
    id: "NET-04",
    title: "客户端菜单直接绑定客户端 BlockEntity，没有用独立的 SimpleContainer",
    category: "网络同步",
    severity: "低",
    location: ["EnchantmentFusionMenu.java L113-118 resolveClientContainer"],
    problem: "客户端 BE 库存会同时被槽位同步和 BE 更新包（getUpdatePacket 存在）两条路径写入，可能短暂闪烁；startOpen/stopOpen 也会在客户端 BE 上被调用。",
    impact: "多人同时打开时可能出现物品闪烁，以及 BER（悬浮书）状态异常。",
    fix: "按原版惯例，客户端始终使用 `new SimpleContainer(4)`，只依赖菜单槽位同步。",
    confidence: "需实机验证",
  },
  {
    id: "NET-05",
    title: "CompendiumSyncPayload 每次全量发送，列表没有上限",
    category: "网络同步",
    severity: "低",
    location: ["FusionNetworking.java L69", "CompendiumDiscoveryTracker.persistAndSync"],
    problem: "`ByteBufCodecs.list()` 没有上限，每次解锁都会重发全部状态（114 + 115 + 6 条，每条一个字符串）。",
    impact: "体积不大，但属于不必要的全量同步；数据包扩展词条后会线性增长。",
    fix: "改为增量包 `CompendiumDeltaPayload(key, state)`；全量包只在 JOIN 时发送，并设置 `list(4096)`。",
    confidence: "已确认",
  },

  // ───────────── GUI 输入 ─────────────
  {
    id: "GUI-01",
    title: "每帧调用 computePreview() 两到三次，每次都完整推演一遍",
    category: "GUI 输入",
    severity: "中",
    location: ["EnchantmentFusionScreen.java L180 / L655 / L783 / L800"],
    problem: "render、背景、滚轮、点击都会单独调用 menu.computePreview()，每次都走一遍 collectCandidates → resolveSelection → evaluateFusion → SignaturePairs.resolve → 经济报价。",
    impact: "144Hz 显示器下每秒要算几百次；放入多附魔书时 FPS 明显下降。",
    fix: "按 `(槽位 ItemStack hash, uiState)` 做脏标记缓存：只在 slotsChanged / dataChanged 时重新计算，然后在 Screen 里缓存。",
    confidence: "已确认",
  },
  {
    id: "GUI-02",
    title: "按钮命中区坐标在 render 和 mouseClicked 里各写一份",
    category: "GUI 输入",
    severity: "中",
    location: ["EnchantmentFusionScreen.java L431 (render: RIGHT_X + 134)", "EnchantmentFusionScreen.java ≈L880 (click: RIGHT_X + 134, 34 + idx*25 + 3)"],
    problem: "插槽卡片上的翻转和卸下按钮，绘制坐标和点击坐标是两段重复的魔数。test_ui_readability.py 只检查常量，覆盖不到这里。",
    impact: "改一次布局就可能出现“看得见点不到”的按钮。",
    fix: "抽成 `record HitBox(int x,int y,int w,int h)`，render 和 click 共用同一份列表；更推荐直接用原生 `Button`/`AbstractWidget`，它自带键盘焦点和旁白支持。",
    confidence: "已确认",
  },
  {
    id: "GUI-03",
    title: "秘典搜索框是手写的：不能粘贴、没有光标、Backspace 处理不全",
    category: "GUI 输入",
    severity: "中",
    location: ["FusionGrimoireScreen.java L606-647"],
    problem:
      "keyPressed 在聚焦时吞掉所有按键：没有 Ctrl+V、方向键、Delete、Ctrl+A；charTyped 屏蔽了 BMP 以外的字符；没有提供 IME 预编辑区域的位置，中文输入法候选窗会停在屏幕左上角。ESC 在搜索框非空时只清空、不关闭，这个行为还可以，但界面上没有任何提示。",
    impact: "中文玩家要搜“自动熔炼”这类词时，输入体验明显不如原版。",
    fix: "直接使用原版 `EditBox`（自带 IME、粘贴、选区、光标和旁白），设置 setMaxLength(40) 和 setResponder 刷新列表即可。",
    confidence: "已确认",
  },
  {
    id: "GUI-04",
    title: "Tab 0 的翻转 / 拆解按钮只在 !preview.executable() 时才显示",
    category: "GUI 输入",
    severity: "低",
    location: ["EnchantmentFusionScreen.java mouseClicked 第 4 段"],
    problem: "如果输出槽里有融合书，同时 A/B 槽也放了两本可融合的书，翻转和拆解按钮会消失，而且没有提示原因。",
    impact: "看起来像功能被随机禁用了。",
    fix: "让按钮一直显示，只切换可用 / 禁用状态，悬停时在 tooltip 里说明原因（“请先取出 A/B 槽书本”）。",
    confidence: "已确认",
  },
  {
    id: "GUI-05",
    title: "选择交互依赖右键，而且右键已选中的 B 是“取消 B”，没有任何文字提示",
    category: "GUI 输入",
    severity: "低",
    location: ["EnchantmentFusionMenu.java PICK_SECONDARY_B (uiState=-2)"],
    problem: "单附魔异位铭刻模式只能通过“右键当前 B 行”进入，这是一个隐藏状态。触控板和单键鼠标的玩家很难发现。",
    impact: "README 里写了这个操作，但 UI 里找不到入口。",
    fix: "在 B 栏放一个显式的 [× 仅 A] 开关按钮，再给右键加 Shift+左键作为备选操作。",
    confidence: "已确认",
  },

  // ───────────── Mixin 注入 ─────────────
  {
    id: "MIX-01",
    title: "砂轮守卫只拦畸变；普通融合物品过砂轮后会留下“孤儿词条”",
    category: "Mixin 注入",
    severity: "高",
    location: ["GrindstoneAberrationGuardMixin.java L18-29", "FusionStationOperations.java L917 主附魔写入原版列表"],
    problem:
      "原版砂轮只清 ENCHANTMENTS，并按附魔返还经验，`fused_pairs` 组件会被原样复制到产物上。所以：主附魔被磨掉、返还了经验，融合词条却还在，MatrixEffectExecutor 读取的正是 FUSED_PAIRS，效果照常生效，还继续占用器魂槽。",
    impact: "等于可以反复刷砂轮经验，同时保留融合效果；另外，原版附魔列表和融合组件对不上，翻转 / 拆解时可能还原出一本已被磨掉的附魔书。",
    fix: "在 `GrindstoneMenu#removeNonCursesFrom`（或 computeResult 的 RETURN）注入：非畸变词条一并移除，或者拦截处理；更彻底的办法是见 API-01，主附魔不写入原版列表。",
    confidence: "高度可疑",
  },
  {
    id: "MIX-02",
    title: "Projectile.onHit 中，所有三叉戟命中都被当成 ON_TRIDENT_CHANNEL",
    category: "Mixin 注入",
    severity: "中",
    location: ["ProjectileImpactFusionMixin.java L72-74"],
    problem: "触发器的名字叫“引雷 / 突进”，但这里只要实体类型是 TRIDENT，就把每一次命中都分发为 ON_TRIDENT_CHANNEL，而 ON_PROJECTILE_IMPACT 永远不会对三叉戟触发。激流突进撞击并不经过 onHit，也就没有触发。",
    impact: "GDD 第 5 节“投戟命中或突进撞击”只实现了前半部分；带 ON_PROJECTILE_IMPACT 主附魔的词条铭刻在三叉戟上，投掷时不会触发。",
    fix: "三叉戟命中时同时分发两种触发器（或按 HostForm 决定）；突进撞击改用 `LivingEntity#doAutoAttackOnTouch` 注入。",
    confidence: "已确认",
  },
  {
    id: "MIX-03",
    title: "鱼钩命中实体时就调用 onFishingReel，但真正“收杆”时又调用一次",
    category: "Mixin 注入",
    severity: "中",
    location: ["ProjectileImpactFusionMixin.java L57-68", "MatrixRuntimeHooks.java UseItemCallback (收杆)"],
    problem: "鱼钩在钩中实体时（onHit）会调用 `onFishingReel(..., false)`，玩家右键收杆时又调用一次。另外 invulnerableTime 被临时清零，钩中生物的那一瞬间就会受到额外伤害。",
    impact: "收杆类签名会触发两次，伤害翻倍；“收杆”的语义变成了“命中”。",
    fix: "拆成 `onFishingHook` 和 `onFishingReel` 两个方法；命中阶段不要清零无敌帧。",
    confidence: "高度可疑",
  },
  {
    id: "MIX-04",
    title: "LivingEntity 注入了 @Unique 快照字段，没有考虑 completeUsingItem 重入",
    category: "Mixin 注入",
    severity: "低",
    location: ["LivingEntityConsumableFusionMixin.java"],
    problem: "如果 HEAD 和 TAIL 之间又触发了一次 completeUsingItem（例如其它模组在食用回调里强制 use），快照会被覆盖。另外，每个 LivingEntity 都会多出一个字段，而实际只有 ServerPlayer 用得到。",
    impact: "概率很低，属于健壮性问题。",
    fix: "改用 `@Local` / `@Share`（MixinExtras）在同一次调用内传递快照，或者把注入目标收窄到 ServerPlayer。",
    confidence: "需实机验证",
  },
  {
    id: "MIX-05",
    title: "getDestroySpeed RETURN 注入里有一个 speed <= 1 的早退",
    category: "Mixin 注入",
    severity: "低",
    location: ["PlayerMiningFusionMixin.java L25-28"],
    problem: "speed <= 1 时直接 return，原意是跳过空手。但“自动熔炼”在低等级时会降低挖掘速度，如果原速已经 ≤1（比如挖错误工具对应的方块），这条减速就不会生效。",
    impact: "边界情况下表现和描述不一致。",
    fix: "去掉早退，或者只在 `tool.isEmpty()` 时返回。",
    confidence: "已确认",
  },

  // ───────────── 死代码 ─────────────
  {
    id: "DEAD-01",
    title: "TAB_COMPENDIUM = 2 及其分支不可达",
    category: "死代码",
    severity: "低",
    location: ["FusionStationOperations.java L56 / L240", "EnchantmentFusionMenu.java L133 activeTab() 钳制 0..1"],
    problem: "activeTab() 被钳制在 0..1，SELECT_TAB 也被钳制，Tab 2 永远到不了。Javadoc 里仍然写着“3-Tab”。",
    impact: "误导后来的维护者；语言文件里还留着对应文案（tab.compendium、tab2.place_book_hint、slot.split_target）。",
    fix: "删除常量、分支和对应语言键，同步修改 Javadoc。",
    confidence: "已确认",
  },
  {
    id: "DEAD-02",
    title: "FusionRuleEngine 自己计算 instabilityChance / xpLevelsCost，结果被 EconomyRules 覆盖",
    category: "死代码",
    severity: "中",
    location: ["FusionRuleEngine.java L111-115", "FusionStationOperations.inspect → computeSynthesisQuote"],
    problem: "规则引擎会算出“0.35 失稳率 / 8 级经验”，但站点逻辑始终使用 EconomyQuote（0.45 / 7~11 级）。而数据包里可配的 base_instability_chance 只影响规则引擎这份结果，没有任何地方使用它。",
    impact: "数据包作者改了 base_instability_chance，游戏里什么都不会变（见 HC-04）。两套定价并存，单元测试测的是用不到的那一套。",
    fix: "去掉 PairEvaluation 里的定价字段，或者让 EconomyRules 读取 snapshot.baseInstabilityChance()。",
    confidence: "已确认",
  },
  {
    id: "DEAD-03",
    title: "未使用的 RejectReason 和 API",
    category: "死代码",
    severity: "低",
    location: ["FusionRuleEngine.RejectReason.PRIMARY_INCOMPATIBLE_HOST / NEEDS_CATALYST", "FusionMatrixRegistry.resetToBuiltIn()", "VesselCapacityRules.maxVesselSlots() (getMaxVesselSlots 的别名)", "EnchantInput.primaryFitsHost (永远 true)"],
    problem: "这些枚举值、方法和字段在全仓库里找不到任何生产代码调用。",
    impact: "增加理解成本；NEEDS_CATALYST 的英文文案“Requires required catalyst”还有语病，但玩家永远看不到。",
    fix: "删除；如果打算以后实现“主附魔不适配宿主”的检查，就开 issue 跟踪。",
    confidence: "已确认",
  },
  {
    id: "DEAD-04",
    title: "19 个界面语言键 × 11 种语言 = 209 条死文案",
    category: "死代码",
    severity: "低",
    location: ["lang/*.json"],
    problem: "preview.idle_line1/2、harmonic_stable、repulsive_stability、tip.flip.*、tip.split.*、btn.xp_badge 等都没有被代码引用。“661 键 11 语言对齐”这个指标把死键也算进去了。",
    impact: "翻译者会在没人看得到的文本上花时间；其中 harmonic_stable 的“100% 稳定”和当前经济系统是矛盾的。",
    fix: "在 ci_static_checks.py 里加一项“未引用键”检查（动态前缀加白名单）。",
    confidence: "已确认",
  },

  // ───────────── 耦合风险 ─────────────
  {
    id: "CPL-01",
    title: "近战附加效果在 AttackEntityCallback（原版攻击之前）里结算，并临时清零无敌帧",
    category: "耦合风险",
    severity: "高",
    location: ["MatrixRuntimeHooks.java L77-100"],
    evidence: `MatrixEffectExecutor.dispatch(... ON_MELEE_STRIKE ...);
target.invulnerableTime = 0;
...
finally { target.invulnerableTime = savedInvuln; }`,
    problem:
      "这个回调在原版攻击结算之前触发：不管这次攻击之后会不会被其它模组取消、目标是否还处在无敌帧里，附加伤害都已经打出去了。非满蓄力的点击也会分发 ON_MELEE_STRIKE。冷却按 (player, trigger, pair) 计，最短 6 tick，所以狂点仍然能稳定触发。",
    impact: "连点武器的 DPS 会被明显放大；和其它修改攻击流程的模组（战斗重做类）的执行顺序也无法预测。",
    fix: "改为注入 `Player#attack` 的尾部，或者使用 `ServerLivingEntityEvents.AFTER_DAMAGE` 并判断来源是玩家近战，只在原版命中成功后结算；非满蓄力不触发，或者按蓄力比例缩放。",
    confidence: "已确认",
  },
  {
    id: "CPL-02",
    title: "所有运行期状态都放在静态 Map<UUID,…> 里，只在 SERVER_STOPPED 时清理",
    category: "耦合风险",
    severity: "中",
    location: ["SignaturePairs.java L67-76 (10 个 Map)", "CrossDomainTransmutations.java L127-135 (9 个)", "MatrixRuntimeHooks.java L39", "MatrixEffectExecutor.java L44 COOLDOWNS"],
    problem:
      "玩家断线后，状态会一直留到停服。PICKPOCKETED_MOBS / LAUNCH_PROCESSED_PROJ 在达到 4096 条时整表清空，清空后已经处理过的对象会被重复处理。COOLDOWNS 的键是字符串拼接，永不过期。",
    impact: "长时间运行的服务器内存会缓慢增长；清空那一刻，扒窃和投射物效果会重复触发。",
    fix: "按玩家的状态改为 Data Attachment（非持久，跟着实体走）；实体相关的标记写在实体自己的 attachment 上；冷却改用 `ItemCooldowns` 或带 TTL 的 Map；在 DISCONNECT 时清理。",
    confidence: "已确认",
  },
  {
    id: "CPL-03",
    title: "每个玩家每 tick 扫描 72 格半径内的投射物，外加遍历所有维度的掉落物",
    category: "耦合风险",
    severity: "中",
    location: ["MatrixRuntimeHooks.java L185 / L192-196"],
    problem: "`getEntitiesOfClass(Projectile, inflate(72))` 是一个 145³ 的 AABB，每个玩家每 tick 查询一次；tickWorldItems 每 tick 遍历所有 ServerLevel。没有任何“玩家身上是否有相关词条”的前置判断。",
    impact: "人多或者有刷怪塔的服务器上，tick 时间会明显上升，而这部分开销对没有装备相关词条的玩家毫无意义。",
    fix: "先检查玩家装备是否带相关组件（可以缓存在 attachment 中，装备变化时更新）；投射物在发射时（`EntityJoin` 或 `shootFromRotation` 注入）打标记，不要每 tick 搜索。",
    confidence: "已确认",
  },
  {
    id: "CPL-04",
    title: "CET 联动：mod id 写的是连字符，物品命名空间写的是下划线",
    category: "耦合风险",
    severity: "中",
    location: ["CetSoftBridge.java L18-22", "FusionTooltipRenderer.java L128"],
    evidence: `CET_MOD_ID = "chiseled-enchanting-table";
Identifier.fromNamespaceAndPath("chiseled_enchanting_table", "arcane_catalyst");`,
    problem: "Fabric 的模组 ID 和资源命名空间一般是同一个值。两者至少有一个与姊妹模组的实际值不符：isCetLoaded() 可能永远返回 false，tooltip 也就一直提示“未安装”。",
    impact: "联动提示失真；用户也没办法判断联动到底生效没有。",
    fix: "把 ID 和命名空间统一放进一个常量；在 fabric.mod.json 中声明 `suggests: {\"<真实id>\": \"*\"}`；ClientSmoke 里加上联动断言。",
    confidence: "高度可疑",
  },
  {
    id: "CPL-05",
    title: "催化槽身兼三职，会出现意外扣费",
    category: "耦合风险",
    severity: "中",
    location: ["CetSoftBridge.isSplitOrFlipCatalyst L61-63", "FusionStationOperations.java L236 / L739 / L791", "FusionEconomyRules.deductFeeAndStabilizers"],
    problem:
      "青金石和紫水晶碎片既是合成费用的资材，又是翻转 / 拆解的“免经验催化剂”；稳定剂同样会被翻转 / 拆解当作催化剂吃掉一颗。资材不够时，还会自动从玩家整个背包里扣除。",
    impact: "玩家本来只想省 2 级经验去翻转，结果消耗了一颗非常珍贵的谐振稳定晶；背包里专门留给附魔台用的青金石也可能被扣掉。",
    fix: "翻转 / 拆解只认指定催化剂（并在 UI 上标明）；稳定剂永远不作为翻转材料；从背包扣费前做二次确认，或在设置里加开关。",
    confidence: "已确认",
  },
  {
    id: "CPL-06",
    title: "ALLOW_DEATH 中多件装备逐一掷骰，冷却在命中后才写入",
    category: "耦合风险",
    severity: "中",
    location: ["SignaturePairs.java L425-447 allowPlayerDeath"],
    problem: "吉星高照的冷却检查放在每件装备的循环内部，而“万物皆可铭刻”允许 6 个装备槽都带这个签名，同一次死亡会独立掷 6 次骰。",
    impact: "单件 42% 的保命率，6 件叠起来约为 96%。",
    fix: "先汇总所有装备上的最高等级，然后只掷一次；或者把同名签名设为全身唯一（见 BAL-02）。",
    confidence: "已确认",
  },

  // ───────────── 硬编码 ─────────────
  {
    id: "HC-01",
    title: "互斥组手写在代码里，没有读取 26.1 的 exclusive_set 标签",
    category: "硬编码",
    severity: "高",
    location: ["FusionMatrixRegistry.java L166-174", "repulsive_pairs.json"],
    problem:
      "原版用 `#minecraft:exclusive_set/*` 标签定义互斥关系，代码里却手写了 7 组，而且漏掉了【激流 × 引雷】（原版 exclusive_set/riptide 包含 loyalty 和 channeling）。其它模组添加的互斥关系也不会被识别。",
    impact: "原版本来就互斥的激流 / 引雷组合在本模组里被当作普通融合，不需要满级，也没有失稳。",
    fix: "运行期改为 `Enchantment.areCompatible(a,b)` 或读取 `enchantment.exclusiveSet()`；repulsive_pairs.json 只保留“额外追加”的那部分。",
    confidence: "已确认",
  },
  {
    id: "HC-02",
    title: "115 个异位化形按附魔 ID 写在 switch 里",
    category: "硬编码",
    severity: "中",
    location: ["CrossDomainTransmutations.java ≈L320-790 resolve()", "L140-297 ALL_VARIANTS 表"],
    problem: "`case \"minecraft:lure\" -> ...`，一个变体对应一个分支。变体表和 resolve 分支是两份需要手工同步的数据；第三方附魔完全接不进来。",
    impact: "改一个变体要同时改三处：表、switch、语言文件；另外，GDD 说第三方附魔“装上就能参与”，对化形来说这句话不成立。",
    fix: "把规则搬到数据包：`data/<ns>/enchantment_fusion/transmutation/*.json`，内容为 {enchantment, host_role, variant}；代码里只保留效果实现，用 variant id 注册。",
    confidence: "已确认",
  },
  {
    id: "HC-03",
    title: "GDD 承诺用标签兼容第三方附魔，实际实现是哈希",
    category: "硬编码",
    severity: "高",
    location: ["docs/GDD.md L163", "FusionMatrixRegistry.java L28-41"],
    problem: "GDD 写的是：“第三方附魔只需挂入 trigger/* 与 payload/* 标签，未挂标签的会按 slots 与 effects 自动推断”。代码里没有任何 TagKey<Enchantment>，未知附魔一律按 hashCode 取模分配触发器。",
    impact: "一个挖掘类附魔可能被分配成 ON_DAMAGE_TAKEN，而且换个 ID 就换一种行为，完全无法预测。",
    fix: "按 GDD 实现：先查 `#enchantment_fusion:trigger/*` 标签，再根据 `Enchantment.definition().slots()` 推断，最后才用默认值。",
    confidence: "已确认",
  },
  {
    id: "HC-04",
    title: "经济、失败率、经验消耗全部是代码常量",
    category: "硬编码",
    severity: "中",
    location: ["FusionEconomyRules.java L94-180", "FusionStationOperations.java (EXPAND=5, TOP_UP=2, manage=2)", "SignaturePairs.java (冷却 300L / 1200L 等)"],
    problem: "0.45 / 0.12 / 0.08 / 7+min(4,…) 这些平衡参数都写死在代码里；数据包里唯一的可调项 base_instability_chance 实际没有被使用（DEAD-02）。",
    impact: "服主和整合包作者没法调平衡，每次调整都得重新编译。",
    fix: "整理成 `data/enchantment_fusion/enchantment_fusion/economy.json`（分档、资材、基础失败率、每颗稳定剂的减免值），由 FusionDataLoader 一起加载并同步给客户端（NET-01）。",
    confidence: "已确认",
  },
  {
    id: "HC-05",
    title: "金质双槽：标签之外又写了一份硬编码 ID 白名单",
    category: "硬编码",
    severity: "低",
    location: ["VesselCapacityRules.java L35-46"],
    problem: "`innate_two_vessel_items` 标签已经存在，但代码又硬编码了 10 个 golden_* ID 作为兜底。数据包从标签里移除某个金装备，结果不会生效。",
    impact: "标签只能加、不能删，和原版标签的语义不一致。",
    fix: "删掉 BUILTIN_GOLD_ITEM_IDS，只用标签。",
    confidence: "已确认",
  },
  {
    id: "HC-06",
    title: "长矛判定的兜底是 path.endsWith(\"_spear\")；钓竿被归类为 MELEE",
    category: "硬编码",
    severity: "低",
    location: ["HostForm.java L45 / L73"],
    problem: "任何模组里名字以 _spear 结尾的物品（装饰品、食物）都会被当成长矛。钓竿、刷子、打火石、剪刀因为没有其它匹配，最后都落到 MELEE。",
    impact: "钓竿上的融合词条会按近战形态解析副效果，和 README 里“钓竿”作为独立宿主的说法不一致。",
    fix: "只用 `#minecraft:spears` 标签判定长矛；新增 UTILITY / FISHING 形态，或者用 `#enchantment_fusion:host/*` 标签来配置。",
    confidence: "已确认",
  },
  {
    id: "HC-07",
    title: "其它魔数",
    category: "硬编码",
    severity: "低",
    location: ["MatrixRuntimeHooks L194 (72 格)", "CrossDomainTransmutations L1503/L1780 (4096)", "CompendiumDiscoveryTracker (每 20 tick 扫描背包)", "FusionWorldLoot (图书管理员 0.05F)", "FusedPair (255)"],
    problem: "扫描半径、缓存上限、扫描周期、交易价格系数等都是散落在各处的常量。",
    impact: "调优时得全仓库搜索，容易漏改。",
    fix: "集中到一个 `FusionTuning` 常量类里，其中适合给服主调的部分开放到配置文件。",
    confidence: "已确认",
  },

  // ───────────── 数值与机制 ─────────────
  {
    id: "BAL-01",
    title: "招财金身：全伤害类型都能免疫、没有冷却、多件可叠加、装备永远不会坏",
    category: "数值与机制",
    severity: "严重",
    location: ["SignaturePairs.java L383-395"],
    evidence: `float procChance = 0.10F + 0.05F * pair.primaryLevel(); // 时运 III → 25%
int nextDmg = Math.min(gear.getMaxDamage() - 1, gear.getDamageValue() + extra);`,
    problem:
      "单件 25% 概率免疫本次伤害，没有冷却。万物皆可铭刻允许 6 个槽位都带这个签名：1 − 0.75⁶ ≈ 82%。耐久扣除被钳制在 maxDamage − 1，所以“双倍耐久代价”永远不会让装备损坏，配合经验修补等于没有代价。",
    impact: "这是整个模组里最直接的强度溢出，PvP 和 Boss 战都会被它破坏。",
    fix: "加内置冷却（例如 8 秒）；同名签名全身只取最高一件；耐久扣除走 `hurtAndBreak`，允许装备损坏；排除 BYPASSES_INVULNERABILITY（API-04）。",
    confidence: "已确认",
  },
  {
    id: "BAL-02",
    title: "所有签名在多件装备上都能叠加，但 GDD 里没有写叠加规则",
    category: "数值与机制",
    severity: "高",
    location: ["MatrixRuntimeHooks ARMOR_AND_HAND_SLOTS 循环", "SignaturePairs.allowIncomingDamage / allowPlayerDeath"],
    problem: "受击、落地、死亡这几类钩子都会遍历 6 个槽位，逐件独立触发。概率类效果会按 1 − (1−p)ⁿ 放大，固定数值类效果会线性叠加。",
    impact: "“克制的器魂容量（最多 2 槽）”本来是用来限制单件装备的，但全身 6 件 × 2 槽 = 12 个词条位，平衡设计假设的数量远小于这个。",
    fix: "在 GDD 里写清叠加规则：同名签名不叠加、取最高等级；不同签名可以叠加，但概率类效果合并后掷一次骰。",
    confidence: "已确认",
  },
  {
    id: "BAL-03",
    title: "稳定剂按“最多可用数”消耗，而不是按“需要数”消耗",
    category: "数值与机制",
    severity: "中",
    location: ["FusionEconomyRules.java L111 / L120 / L128"],
    problem: "低档：0.10 − 0.18×1 已经小于 0，失败率归零，但 `used = min(2, safeStab)` 仍会扣掉 2 颗。高档同理，0.28 − 0.15×2 也是这种情况。",
    impact: "稳定剂被白白浪费；UI 上也没有显示“将消耗 N 颗”。",
    fix: "`used = min(cap, ceil(base / perStab))`；预览里显示“将消耗 n 颗稳定剂”。",
    confidence: "已确认",
  },
  {
    id: "BAL-04",
    title: "谐振稳定晶的中文说明写“确保 100% 稳定”，实际互斥档最低失败率是 8%",
    category: "数值与机制",
    severity: "高",
    location: ["FusionEconomyRules.java L104 clampProb(…, 0.08, 0.85)", "zh_cn.json L5 resonance_stabilizer.lore"],
    problem: "互斥档：0.45 − 0.12×3 = 0.09，再被钳到 0.08 下限，所以永远不会到 0%。英文说明只写了 “Eliminates instability”，中文却承诺“确保 100%”，两种语言说法不一致，中文的说法还是错的。",
    impact: "玩家投入 3 颗稳定晶后仍然 8% 畸变，会认为是 bug 或者被骗了。",
    fix: "文案改成“每颗降低约 12% 失稳率（互斥融合最低 8%）”；或者把下限改成 0，让文案成立。",
    confidence: "已确认",
  },
  {
    id: "BAL-05",
    title: "普通失败会直接销毁一本书，文案却强调“退还半数费用”",
    category: "数值与机制",
    severity: "高",
    location: ["FusionStationOperations.java L522-545", "message.failure.normal_refund", "grimoire.rules_fees.body"],
    problem:
      "失败时会消耗一本书（优先 B，B 来自装备时改为消耗 A），插槽失败时则消耗整本融合书，然后只按半价扣费。玩家看到的是“退还半数”，而锋利 V 书的损失被一笔带过。低档的基础失败率是 10%，即便 1 级 + 1 级的融合也是如此。",
    impact: "把原版本来零风险的低级操作变成了赌博；提示消息里写的“副卷”在部分情况下是错的（实际被消耗的是 A 或融合书）。",
    fix: "低档的失败率归零或改成只扣资材；失败消息里写明具体被消耗的书名（%s）；预览里明确显示“失败将失去：xxx”。",
    confidence: "已确认",
  },
  {
    id: "BAL-06",
    title: "“有序 [A ▷ B] ≠ [B ▷ A]”在代码里有 37 处例外",
    category: "数值与机制",
    severity: "中",
    location: ["SignaturePairs.java regAlias × 37"],
    problem: "114 个签名 ID 里，有 37 个通过 regAlias 把正反两个方向映射到同一个效果，例如【击退 ▷ 抢夺】和【抢夺 ▷ 击退】。",
    impact: "核心卖点被打了折扣，图鉴里“定向双星签名”的叫法对这 1/3 并不准确。",
    fix: "要么补齐反向效果，要么在 UI 和文档里明确标注“对称签名（顺序无关）”，并单独统计数量。",
    confidence: "已确认",
  },
  {
    id: "BAL-07",
    title: "异位转换的成本只按等级分档，经验修补、精准采集、无限这类附魔反而最便宜",
    category: "数值与机制",
    severity: "中",
    location: ["FusionEconomyRules.computeConversionQuote L144-171"],
    problem: "maxLevel = 1 的附魔会落进最低档（2 级经验 + 3 青金石、9% 失败率），但它们恰恰是原版里最贵、最稀有的一批。",
    impact: "“凝灵成瓶”这类强力化形门槛过低。",
    fix: "引入附魔稀有度（`Enchantment.definition().weight()` 或 anvilCost）作为第二个分档维度。",
    confidence: "已确认",
  },
  {
    id: "BAL-08",
    title: "等级补强在 donor 超过上限时会变成空操作，但仍然消耗书和经验",
    category: "数值与机制",
    severity: "低",
    location: ["FusionStationOperations.java L466-478 / L657-690"],
    problem: "判断条件是 `donor.level() > existing.level`，写入的却是 `min(donor.max, donor.level)`。如果已有等级已经是上限，而 donor 是命令生成的超上限书，判断成立，写入的结果却和原来一样。",
    impact: "书和 2 级经验被白白扣掉（边界情况）。",
    fix: "用钳制后的值来做判断。",
    confidence: "已确认",
  },
  {
    id: "BAL-09",
    title: "炭火熔伐：原木 99% 直接变木炭，不需要燃料",
    category: "数值与机制",
    severity: "低",
    location: ["CrossDomainTransmutations.java L954-966"],
    problem: "等于免燃料、零时间的熔炉，还不需要等级门槛（只要斧头上有火焰附加）。同时木板类方块有 45% 概率“烧成灰”消失，用斧头拆自己的木屋会损失材料。",
    impact: "早期木炭经济被跳过；误拆建筑时会损失材料。",
    fix: "木炭率按火焰附加等级划分（I: 50%、II: 85%）；木制建筑方块默认不受影响，或者潜行时关闭效果。",
    confidence: "已确认",
  },
];

export const SEVERITY_ORDER: Severity[] = ["严重", "高", "中", "低"];
