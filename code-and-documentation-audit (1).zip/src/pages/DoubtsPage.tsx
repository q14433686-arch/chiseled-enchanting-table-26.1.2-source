import { useState } from "react";
import { DOUBTS, ROADMAP, type Doubt } from "../data/doubts";
import { PageHeader, SectionTitle } from "../components/ui";
import { cn } from "../utils/cn";

const TAGS: Doubt["tag"][] = ["定位", "设计", "工程", "流程", "体验"];

export default function DoubtsPage() {
  const [tag, setTag] = useState<Doubt["tag"] | "全部">("全部");
  const list = DOUBTS.filter((d) => tag === "全部" || d.tag === tag);

  return (
    <>
      <PageHeader kicker="第 3 页 · 怀疑与建议" title="实事求是：值得再想一想的地方">
        <p>
          先说优点：这个模组的核心想法“有序融合 [A ▷ B] ≠ [B ▷ A]”很有辨识度；代码结构清晰（model / mechanics / menu / mixin 分层），
          Mixin 只用了 4 个而且都有注释说明；作者也做了 CI 和多语言。下面的怀疑<b>不是否定</b>，
          而是希望这个项目从“功能做完”走到“经得起长期维护”。
        </p>
      </PageHeader>

      <div className="mb-6 flex flex-wrap gap-1.5">
        {(["全部", ...TAGS] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTag(t)}
            className={cn(
              "rounded-full border px-3.5 py-1 text-sm transition",
              tag === t
                ? "border-violet-600 bg-violet-600 text-white"
                : "border-stone-300 bg-white text-stone-600 hover:border-stone-400"
            )}
          >
            {t}
            <span className="ml-1 opacity-60">{t === "全部" ? DOUBTS.length : DOUBTS.filter((d) => d.tag === t).length}</span>
          </button>
        ))}
      </div>

      <ol className="space-y-4">
        {list.map((d) => (
          <li key={d.q} className="rounded-xl border border-stone-200 bg-white p-6">
            <div className="flex items-start gap-3">
              <span className="mt-0.5 shrink-0 rounded-md bg-stone-100 px-2 py-0.5 text-xs font-medium text-stone-600">
                {d.tag}
              </span>
              <h3 className="text-lg font-semibold leading-7 text-stone-900">{d.q}</h3>
            </div>
            <div className="mt-4 grid gap-4 md:grid-cols-2">
              <div className="text-[14.5px] leading-7 text-stone-600">
                <div className="mb-1 text-xs font-semibold text-stone-400">为什么这么问</div>
                {d.why}
              </div>
              <div className="rounded-lg bg-violet-50/70 p-4 text-[14.5px] leading-7 text-stone-800">
                <div className="mb-1 text-xs font-semibold text-violet-700">建议</div>
                {d.suggest}
              </div>
            </div>
          </li>
        ))}
      </ol>

      <SectionTitle n="→" title="建议的修复顺序" desc="条目编号对应第 1 页的审计 ID。" />
      <div className="grid gap-4 md:grid-cols-3">
        {ROADMAP.map((r, i) => (
          <div
            key={r.phase}
            className={cn(
              "rounded-xl border bg-white p-5",
              i === 0 ? "border-red-300" : i === 1 ? "border-amber-300" : "border-stone-200"
            )}
          >
            <h3 className="font-semibold text-stone-900">{r.phase}</h3>
            <ul className="mt-3 space-y-2">
              {r.items.map((it) => {
                const m = it.match(/^([A-Z]+-\d+(?:\s*\/\s*[A-Z]+-\d+)*)\s*(.*)$/);
                return (
                  <li key={it} className="flex gap-2 text-[14px] leading-6 text-stone-700">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-stone-400" />
                    <span>
                      {m ? (
                        <>
                          {m[1].split("/").map((id, k) => (
                            <a
                              key={id}
                              href="#/audit"
                              className="mr-1 font-mono text-xs text-violet-700 hover:underline"
                            >
                              {k > 0 && "/ "}
                              {id.trim()}
                            </a>
                          ))}
                          {m[2]}
                        </>
                      ) : (
                        it
                      )}
                    </span>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-12 rounded-xl border border-stone-200 bg-stone-100/70 p-6 text-[14.5px] leading-7 text-stone-600">
        <b className="text-stone-900">关于本报告的局限：</b>
        审计基于静态阅读，没有在 26.1.2 客户端或服务端上实际运行。标为“已确认”的条目是指代码路径明确、可以逐行推导出来；
        “高度可疑”的条目依赖原版行为的细节（例如砂轮对自定义组件的处理、数据驱动附魔的槽位规则），建议用 GameTest 复现后再修复；
        “需实机验证”的条目只是风险提示。数值平衡的判断带有主观成分，最终应以作者的设计意图为准。
      </div>
    </>
  );
}
