import { useMemo, useState } from "react";
import { CATEGORY_META, FINDINGS, SEVERITY_ORDER, type Category, type Finding, type Severity } from "../data/audit";
import { Chip, Code, PageHeader, SevBadge } from "../components/ui";
import { cn } from "../utils/cn";

const CATS = Object.keys(CATEGORY_META) as Category[];

function FindingCard({ f, open, onToggle }: { f: Finding; open: boolean; onToggle: () => void }) {
  return (
    <article
      id={f.id}
      className={cn(
        "rounded-xl border bg-white transition",
        open ? "border-violet-300 shadow-md" : "border-stone-200 hover:border-stone-300"
      )}
    >
      <button onClick={onToggle} className="flex w-full items-start gap-3 p-4 text-left">
        <span className="mt-0.5 w-16 shrink-0 font-mono text-xs text-stone-400">{f.id}</span>
        <span className="flex-1">
          <span className="block font-medium leading-6 text-stone-900">{f.title}</span>
          <span className="mt-1.5 flex flex-wrap items-center gap-1.5">
            <SevBadge s={f.severity} />
            <Chip>{f.category}</Chip>
            <Chip
              className={cn(
                f.confidence === "已确认" && "bg-emerald-50 text-emerald-700",
                f.confidence === "高度可疑" && "bg-sky-50 text-sky-700",
                f.confidence === "需实机验证" && "bg-stone-100 text-stone-500"
              )}
            >
              {f.confidence}
            </Chip>
          </span>
        </span>
        <span className={cn("mt-1 text-stone-400 transition", open && "rotate-180")}>▾</span>
      </button>

      {open && (
        <div className="space-y-4 border-t border-stone-100 px-4 pb-5 pt-4 md:pl-[5.75rem]">
          <div className="flex flex-wrap gap-1.5">
            {f.location.map((l) => (
              <code key={l} className="rounded bg-violet-50 px-2 py-0.5 font-mono text-xs text-violet-800">
                {l}
              </code>
            ))}
          </div>
          {f.evidence && <Code>{f.evidence}</Code>}
          <Block label="问题" text={f.problem} />
          <Block label="影响" text={f.impact} />
          <Block label="建议" text={f.fix} accent />
        </div>
      )}
    </article>
  );
}

function Block({ label, text, accent }: { label: string; text: string; accent?: boolean }) {
  return (
    <div className={cn("text-[14.5px] leading-7", accent && "rounded-lg bg-emerald-50/70 p-3")}>
      <span className={cn("mr-2 text-xs font-semibold", accent ? "text-emerald-700" : "text-stone-400")}>
        {label}
      </span>
      <span className="text-stone-700">{text}</span>
    </div>
  );
}

export default function AuditPage() {
  const [cat, setCat] = useState<Category | "全部">("全部");
  const [sev, setSev] = useState<Severity | "全部">("全部");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<Set<string>>(new Set(["BAL-01"]));

  const list = useMemo(() => {
    const kw = q.trim().toLowerCase();
    return FINDINGS.filter(
      (f) =>
        (cat === "全部" || f.category === cat) &&
        (sev === "全部" || f.severity === sev) &&
        (!kw || [f.id, f.title, f.problem, f.fix, ...f.location].join(" ").toLowerCase().includes(kw))
    ).sort((a, b) => SEVERITY_ORDER.indexOf(a.severity) - SEVERITY_ORDER.indexOf(b.severity));
  }, [cat, sev, q]);

  const sevCount = (s: Severity) => FINDINGS.filter((f) => f.severity === s).length;
  const toggle = (id: string) =>
    setOpen((p) => {
      const n = new Set(p);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });

  return (
    <>
      <PageHeader kicker="第 1 页 · 技术审计" title="按路径重新审计：BUG、硬编码与数值设计">
        <p>
          本页按 <b>源码 API、数据编解码、网络同步、GUI 输入、Mixin 注入、死代码、耦合风险</b> 七条路径，加上
          <b>硬编码</b>和<b>数值与机制</b>两个专题，逐个文件阅读了约 12,000 行 Java、11 份语言文件和全部文档。共整理出
          {" "}{FINDINGS.length} 条问题，每条都附有文件位置、证据、影响和修复建议。
        </p>
      </PageHeader>

      {/* Summary */}
      <div className="mb-8 grid grid-cols-2 gap-3 md:grid-cols-4">
        {SEVERITY_ORDER.map((s) => (
          <button
            key={s}
            onClick={() => setSev(sev === s ? "全部" : s)}
            className={cn(
              "rounded-xl border bg-white p-4 text-left transition",
              sev === s ? "border-violet-400 ring-2 ring-violet-100" : "border-stone-200 hover:border-stone-300"
            )}
          >
            <div className="text-3xl font-bold text-stone-900">{sevCount(s)}</div>
            <div className="mt-1 flex items-center gap-2 text-sm text-stone-500">
              <SevBadge s={s} /> 级
            </div>
          </button>
        ))}
      </div>

      {/* Path matrix */}
      <div className="mb-8 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {CATS.map((c) => {
          const items = FINDINGS.filter((f) => f.category === c);
          const worst = SEVERITY_ORDER.find((s) => items.some((i) => i.severity === s));
          return (
            <button
              key={c}
              onClick={() => setCat(cat === c ? "全部" : c)}
              className={cn(
                "flex items-start gap-3 rounded-xl border bg-white p-3.5 text-left transition",
                cat === c ? "border-violet-400 ring-2 ring-violet-100" : "border-stone-200 hover:border-stone-300"
              )}
            >
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-stone-100 font-semibold text-stone-700">
                {items.length}
              </span>
              <span className="flex-1">
                <span className="flex items-center gap-2 font-medium text-stone-900">
                  {c} {worst && <SevBadge s={worst} />}
                </span>
                <span className="mt-0.5 block text-xs leading-5 text-stone-500">{CATEGORY_META[c].desc}</span>
              </span>
            </button>
          );
        })}
      </div>

      {/* Toolbar */}
      <div className="sticky top-[61px] z-20 -mx-5 mb-4 flex flex-wrap items-center gap-2 border-y border-stone-200 bg-stone-50/95 px-5 py-3 backdrop-blur">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="搜索：类名、ID、关键词（例如 Grindstone、NET-01、稳定剂）"
          className="min-w-[240px] flex-1 rounded-lg border border-stone-300 bg-white px-3 py-2 text-sm outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100"
        />
        <span className="text-sm text-stone-500">
          {list.length} / {FINDINGS.length}
          {cat !== "全部" && ` · ${cat}`}
          {sev !== "全部" && ` · ${sev}`}
        </span>
        {(cat !== "全部" || sev !== "全部" || q) && (
          <button
            onClick={() => {
              setCat("全部");
              setSev("全部");
              setQ("");
            }}
            className="rounded-lg px-2.5 py-1.5 text-sm text-violet-700 hover:bg-violet-50"
          >
            清除筛选
          </button>
        )}
        <button
          onClick={() => setOpen(open.size ? new Set() : new Set(list.map((f) => f.id)))}
          className="rounded-lg border border-stone-300 bg-white px-2.5 py-1.5 text-sm text-stone-700 hover:bg-stone-100"
        >
          {open.size ? "全部收起" : "全部展开"}
        </button>
      </div>

      <div className="space-y-2.5">
        {list.map((f) => (
          <FindingCard key={f.id} f={f} open={open.has(f.id)} onToggle={() => toggle(f.id)} />
        ))}
        {list.length === 0 && <p className="py-16 text-center text-stone-500">没有匹配的条目。</p>}
      </div>

      <div className="mt-12 rounded-xl border border-stone-200 bg-white p-5 text-sm leading-7 text-stone-600">
        <b className="text-stone-900">也检查过、但没有发现问题的地方：</b>
        Fabric 入口和 JEI/REI 入口点名称；26.1 的 <code className="font-mono text-xs">Identifier</code> 与
        <code className="font-mono text-xs"> MouseButtonEvent / KeyEvent / CharacterEvent</code> 新输入 API；
        ExtendedMenuType 打开数据；方块被破坏时的 <code className="font-mono text-xs">affectNeighborsAfterRemoval</code> 掉落；
        服务端 StationAction 对 containerId 与 stillValid 的校验；ALLOW_DAMAGE 的 ThreadLocal 防重入；投射物发射武器的快照逻辑。
        这些部分写得比较扎实。
      </div>
    </>
  );
}
