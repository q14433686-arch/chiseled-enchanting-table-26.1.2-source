import { useState } from "react";
import { DEAD_KEYS, DOC_RESTRUCTURE, NUMBER_CLAIMS, REWRITES, STYLE_RULES, TERM_CONFLICTS } from "../data/text";
import { PageHeader, SectionTitle } from "../components/ui";
import { cn } from "../utils/cn";

export default function TextPage() {
  const [lang, setLang] = useState<"zh" | "en" | "both">("both");

  return (
    <>
      <PageHeader kicker="第 2 页 · 文字工程" title="说明、UI 与文档：易读性、准确性、统一性">
        <p>
          整体来看，文字的易读性<b>是合格的</b>：中文提示有画面感，按钮语义大体清楚，11 种语言的键也全部对齐。
          问题集中在三方面：<b>同一个东西有好几个名字</b>、<b>同一个数字在不同文档里不一样</b>、
          <b>文案承诺的效果比代码实际做到的多</b>。下面按“统一 → 准确 → 易读”的顺序给出可以直接替换的方案。
        </p>
      </PageHeader>

      <div className="grid gap-3 md:grid-cols-3">
        {[
          { n: TERM_CONFLICTS.length, t: "组术语一物多名", d: "同一概念有 3–5 种写法" },
          { n: NUMBER_CLAIMS.length, t: "组数字互相冲突", d: "README / GDD / BASELINE / 代码" },
          { n: DEAD_KEYS.length * 11, t: "条死文案", d: `${DEAD_KEYS.length} 个键 × 11 种语言` },
        ].map((s) => (
          <div key={s.t} className="rounded-xl border border-stone-200 bg-white p-5">
            <div className="text-3xl font-bold text-violet-800">{s.n}</div>
            <div className="mt-1 font-medium text-stone-900">{s.t}</div>
            <div className="text-sm text-stone-500">{s.d}</div>
          </div>
        ))}
      </div>

      {/* 1. Terms */}
      <SectionTitle n="01" title="统一性：术语表" desc="左侧是现有的各种写法，右侧是建议统一使用的标准词。" />
      <div className="space-y-3">
        {TERM_CONFLICTS.map((t) => (
          <div key={t.concept} className="grid gap-4 rounded-xl border border-stone-200 bg-white p-5 md:grid-cols-[1fr_auto_1fr]">
            <div>
              <div className="mb-2 text-sm font-semibold text-stone-500">{t.concept}</div>
              <ul className="space-y-1.5">
                {t.variants.map((v) => (
                  <li key={v.text} className="flex flex-wrap items-baseline gap-x-2 text-[14.5px]">
                    <span className="text-stone-400 line-through decoration-red-400/70">{v.text}</span>
                    <span className="text-xs text-stone-400">{v.where}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="hidden items-center text-2xl text-stone-300 md:flex">→</div>
            <div>
              <div className="rounded-lg bg-violet-50 p-3">
                <div className="text-lg font-semibold text-violet-900">{t.recommendZh}</div>
                <div className="font-mono text-sm text-violet-700">{t.recommendEn}</div>
              </div>
              <p className="mt-2 text-sm leading-6 text-stone-600">{t.reason}</p>
            </div>
          </div>
        ))}
      </div>

      {/* 2. Numbers */}
      <SectionTitle n="02" title="准确性：数字只能有一个来源" desc="同一仓库内互相冲突的数量与概率。" />
      <div className="overflow-x-auto rounded-xl border border-stone-200 bg-white">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="bg-stone-100 text-xs uppercase tracking-wide text-stone-500">
            <tr>
              <th className="px-4 py-3 font-semibold">项目</th>
              <th className="px-4 py-3 font-semibold">文档中出现的数值</th>
              <th className="px-4 py-3 font-semibold">代码中的事实</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {NUMBER_CLAIMS.map((c) => (
              <tr key={c.item} className="align-top">
                <td className="px-4 py-3.5 font-medium text-stone-900">{c.item}</td>
                <td className="px-4 py-3.5">
                  <div className="space-y-1.5">
                    {c.values.map((v) => (
                      <div key={v.value + v.where}>
                        <span className="mr-2 rounded bg-red-50 px-1.5 py-0.5 font-mono text-red-700">{v.value}</span>
                        <span className="text-stone-500">{v.where}</span>
                      </div>
                    ))}
                  </div>
                </td>
                <td className="px-4 py-3.5 text-emerald-800">{c.truth}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-sm leading-6 text-stone-500">
        建议：在 Gradle 里加一个 <code className="font-mono">generateStats</code> 任务，从注册表导出
        signature / transmutation / enchant / locale-key 等数量，生成 <code className="font-mono">docs/generated/stats.md</code>；
        README 和 GDD 都引用这份文件，CI 检测到差异时报错。
      </p>

      {/* 3. Rewrites */}
      <SectionTitle n="03" title="易读性 + 准确性：逐条改写" desc="优先选了“文案和实现不一致”或“读完仍不知道发生了什么”的条目。" />
      <div className="mb-4 flex gap-1 rounded-lg bg-stone-200/70 p-1 text-sm w-fit">
        {(
          [
            ["both", "中英对照"],
            ["zh", "仅中文"],
            ["en", "仅英文"],
          ] as const
        ).map(([k, l]) => (
          <button
            key={k}
            onClick={() => setLang(k)}
            className={cn("rounded-md px-3 py-1", lang === k ? "bg-white text-violet-800 shadow-sm" : "text-stone-600")}
          >
            {l}
          </button>
        ))}
      </div>
      <div className="space-y-4">
        {REWRITES.map((r) => (
          <div key={r.key} className="overflow-hidden rounded-xl border border-stone-200 bg-white">
            <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1 border-b border-stone-100 px-5 py-3">
              <code className="font-mono text-xs text-violet-700">{r.key}</code>
              <span className="text-sm text-stone-600">{r.issue}</span>
            </div>
            <div className="grid md:grid-cols-2">
              <div className="border-b border-stone-100 bg-red-50/40 p-5 md:border-b-0 md:border-r">
                <div className="mb-2 text-xs font-semibold text-red-700">现在</div>
                {lang !== "en" && <p className="whitespace-pre-line text-[14.5px] leading-7 text-stone-700">{r.beforeZh}</p>}
                {lang !== "zh" && <p className="mt-1 whitespace-pre-line text-sm leading-6 text-stone-500">{r.beforeEn}</p>}
              </div>
              <div className="bg-emerald-50/40 p-5">
                <div className="mb-2 text-xs font-semibold text-emerald-700">建议</div>
                {lang !== "en" && <p className="whitespace-pre-line text-[14.5px] leading-7 text-stone-900">{r.afterZh}</p>}
                {lang !== "zh" && <p className="mt-1 whitespace-pre-line text-sm leading-6 text-stone-600">{r.afterEn}</p>}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* 4. Dead keys */}
      <SectionTitle n="04" title="清理：未被代码引用的语言键" desc="翻译者为这些文本花了时间，但玩家永远看不到。" />
      <div className="rounded-xl border border-stone-200 bg-white p-5">
        <div className="flex flex-wrap gap-1.5">
          {DEAD_KEYS.map((k) => (
            <code key={k} className="rounded bg-stone-100 px-2 py-1 font-mono text-xs text-stone-600">
              gui.enchantment_fusion.{k}
            </code>
          ))}
        </div>
        <p className="mt-4 text-sm leading-6 text-stone-600">
          其中 <code className="font-mono">preview.harmonic_stable</code>（“100% 稳定”）和当前的分档失败率是矛盾的，
          <code className="font-mono"> tab.compendium</code> 等 3 个键属于已经删除的第三页签。可以在
          <code className="font-mono"> ci_static_checks.py</code> 中加入“未引用键”检查，动态拼接的前缀（signature. / transmute. / aberration.）放进白名单。
        </p>
      </div>

      {/* 5. Style guide */}
      <SectionTitle n="05" title="文字规范草案" desc="一份可以直接放进 CONTRIBUTING.md 的写作约定。" />
      <div className="grid gap-3 md:grid-cols-2">
        {STYLE_RULES.map((s, i) => (
          <div key={s.title} className="rounded-xl border border-stone-200 bg-white p-5">
            <div className="flex items-baseline gap-2">
              <span className="font-mono text-xs text-violet-600">R{i + 1}</span>
              <h3 className="font-semibold text-stone-900">{s.title}</h3>
            </div>
            <p className="mt-2 text-[14.5px] leading-7 text-stone-600">{s.body}</p>
            {s.example && (
              <pre className="mt-3 whitespace-pre-wrap rounded-lg bg-stone-100 p-3 font-mono text-xs leading-6 text-stone-700">
                {s.example}
              </pre>
            )}
          </div>
        ))}
      </div>

      {/* 6. Docs */}
      <SectionTitle n="06" title="文档结构调整" />
      <div className="space-y-3">
        {DOC_RESTRUCTURE.map((d) => (
          <div key={d.doc} className="grid gap-4 rounded-xl border border-stone-200 bg-white p-5 md:grid-cols-[160px_1fr_1fr]">
            <div className="font-mono text-sm font-semibold text-stone-900">{d.doc}</div>
            <div className="text-[14.5px] leading-7 text-stone-600">
              <span className="mr-1.5 text-xs font-semibold text-red-600">现状</span>
              {d.now}
            </div>
            <div className="text-[14.5px] leading-7 text-stone-800">
              <span className="mr-1.5 text-xs font-semibold text-emerald-700">调整</span>
              {d.next}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
