import { useEffect, useState } from "react";
import AuditPage from "./pages/AuditPage";
import TextPage from "./pages/TextPage";
import DoubtsPage from "./pages/DoubtsPage";
import { cn } from "./utils/cn";

type Route = "audit" | "text" | "doubts";

const ROUTES: { id: Route; label: string; sub: string }[] = [
  { id: "audit", label: "代码审计", sub: "按 9 条路径排查 BUG、硬编码与数值" },
  { id: "text", label: "文本与术语", sub: "易读性 · 准确性 · 统一性" },
  { id: "doubts", label: "怀疑与建议", sub: "实事求是的问题与路线图" },
];

function readRoute(): Route {
  const h = window.location.hash.replace("#/", "").replace("#", "");
  return (ROUTES.find((r) => r.id === h)?.id ?? "audit") as Route;
}

export default function App() {
  const [route, setRoute] = useState<Route>(readRoute);

  useEffect(() => {
    const on = () => {
      setRoute(readRoute());
      window.scrollTo({ top: 0 });
    };
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);

  return (
    <div className="min-h-screen bg-stone-50 text-stone-800">
      <header className="sticky top-0 z-30 border-b border-stone-200 bg-stone-50/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-6 gap-y-2 px-5 py-3">
          <a href="#/audit" className="flex items-center gap-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-violet-700 font-bold text-white">◇</span>
            <span className="leading-tight">
              <span className="block text-sm font-semibold text-stone-900">Enchantment Fusion · 审计报告</span>
              <span className="block text-xs text-stone-500">0.4.0 · Minecraft 26.1.2 · Fabric</span>
            </span>
          </a>
          <nav className="ml-auto flex gap-1 rounded-xl bg-stone-200/70 p-1">
            {ROUTES.map((r) => (
              <a
                key={r.id}
                href={`#/${r.id}`}
                className={cn(
                  "rounded-lg px-3.5 py-1.5 text-sm font-medium transition",
                  route === r.id ? "bg-white text-violet-800 shadow-sm" : "text-stone-600 hover:text-stone-900"
                )}
              >
                {r.label}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-5 pb-24 pt-10">
        {route === "audit" && <AuditPage />}
        {route === "text" && <TextPage />}
        {route === "doubts" && <DoubtsPage />}
      </main>

      <footer className="border-t border-stone-200 py-8 text-center text-xs leading-relaxed text-stone-500">
        审计对象：q14433686-arch/chiseled-enchanting-table-26.1.2-source · 分支 arena/11fcd984-chiseled-enchanting-table-26-1
        <br />
        行号基于审计时的快照，可能有 ±5 行偏差。“需实机验证”的条目只是基于静态阅读得出的推断。
      </footer>
    </div>
  );
}
