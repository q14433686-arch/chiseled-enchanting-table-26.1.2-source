import { useMemo, useState } from "react";
import {
  AlertTriangle, Bug, Calculator, CheckCircle2,
  ExternalLink, FileSearch, Gauge, GitBranch, HeartHandshake,
  Layers, Lightbulb, Scale, Search, ShieldAlert, ShieldCheck,
  Swords, Timer, XCircle, Library, FlaskConical, MessageCircleQuestion, ListChecks,
  Eye, Lock, TrendingDown, Workflow
} from "lucide-react";
import { FINDINGS, PATHS, BALANCE_NOTES, type PathId, type Severity } from "./auditData";

type Page = "audit" | "debate" | "advice";
const REPO = "https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/tree/arena%2F649fac5c-chiseled-enchanting-table-26-1";
const sevColor: Record<Severity, string> = {
  P0: "bg-red-600 text-white", P1: "bg-amber-600 text-white", P2: "bg-stone-600 text-white", "观察": "bg-emerald-700 text-white",
};

function requiredShelves(L: number, M: number) {
  if (M <= 1 || L <= 1) return 0;
  if (L >= M) return 38;
  return Math.round(38 * Math.pow((L - 1) / (M - 1), 1.25));
}

function BookshelfCalc() {
  const [M, setM] = useState(5);
  const [W, setW] = useState(16);
  const unlocked = useMemo(() => {
    let u = 1; for (let L = 1; L <= M; L++) if (requiredShelves(L, M) <= W) u = L; return u;
  }, [M, W]);
  return (
    <div className="rounded-xl border border-stone-700 bg-[#1c1917] p-5">
      <div className="flex items-center gap-2 text-amber-400 font-semibold"><Calculator size={18}/>普通书架曲线复算器</div>
      <p className="text-xs text-stone-400 mt-1">公式 W<sub>req</sub>=round(38·((L−1)/(M−1))<sup>1.25</sup>)，与 BookshelfProgression 及 Wiki §3.1 对照。拖动看看 M=2 的问题。</p>
      <div className="grid sm:grid-cols-2 gap-4 mt-4 text-sm">
        <label>附魔最高等级 M = {M}<input type="range" min={1} max={10} value={M} onChange={e=>setM(+e.target.value)} className="w-full accent-amber-500"/></label>
        <label>普通书架 W = {W}<input type="range" min={0} max={42} value={W} onChange={e=>setW(+e.target.value)} className="w-full accent-emerald-500"/></label>
      </div>
      <div className="flex flex-wrap gap-1.5 mt-4">
        {Array.from({length:M},(_,i)=>i+1).map(L=>(
          <div key={L} className={`rounded-lg px-3 py-2 text-center text-xs border ${requiredShelves(L,M)<=W?"border-emerald-600 bg-emerald-950 text-emerald-300":"border-stone-700 bg-stone-900 text-stone-500"}`}>
            <div className="text-base font-bold">{["","I","II","III","IV","V","VI","VII","VIII","IX","X"][L]}</div>{requiredShelves(L,M)} 架
          </div>))}
      </div>
      <div className="mt-3 text-sm text-stone-300">白板直附上限（无母本）：<b className="text-amber-300">{["","I","II","III","IV","V","VI","VII","VIII","IX","X"][Math.ceil(M/2)]}</b>（⌈M/2⌉） · 已有附魔靠书架可升到：<b className="text-emerald-300">{["","I","II","III","IV","V","VI","VII","VIII","IX","X"][unlocked]}</b>
      {M===2 && <span className="block mt-2 text-red-300 text-xs">⚠ 这就是 BAL-01：M=2 时只有 0→38 一跳，击退 II 和锋利 V 最后一跳同价，前 37 架零反馈。</span>}
      {M>2 && W>=12 && <span className="block mt-1 text-xs text-stone-400">经验减免：{W<12?0:Math.round(1+14*Math.min(1,(W-12)/26))}%（12 架起效，38 架满 −15%）</span>}
      </div>
    </div>
  );
}

function SuperBookSim({compact=false}:{compact?:boolean}) {
  const [N,setN]=useState(10); const [gen,setGen]=useState(0); const [sigma,setSigma]=useState(4.5); const [slots,setSlots]=useState(1); const [shelves,setShelves]=useState(38);
  const waiver = gen>2?0 : N<=4?1:Math.max(0.30, 1-0.06*(N-4));
  const shelfBonus = (shelves>=32?0.01:0)+(shelves>=38?0.02:0)+(shelves>=42?0.03:0);
  const slip = sigma<3?0:Math.min(0.25,(sigma-3)*0.035+shelfBonus);
  const unitPer = Math.pow(0.8,1.25);
  const effMastery = Math.min(3.5*slots, N*unitPer); // per-slot cap 3.5
  const globalDisc = Math.min(20, Math.floor(1.25*effMastery));
  const expectedLossPerUse = waiver===0? "回归普通耐久（4点/级）" : `免磨损率 ${(waiver*100).toFixed(0)}% · 每次期望磨损 ${(1-waiver).toFixed(2)} 点`;
  return (
    <div className="rounded-xl border border-amber-800/60 bg-[#201a15] p-5">
      <div className="flex items-center gap-2 font-semibold text-amber-300"><FlaskConical size={18}/>“一本超级附魔书”收益模拟器 <span className="text-[11px] font-normal text-stone-400">按 Wiki 公开公式复算 · 单本承载为示意近似</span></div>
      <div className={`grid ${compact?"sm:grid-cols-2":"md:grid-cols-5"} gap-3 mt-4 text-xs text-stone-300`}>
        <label>单本非诅咒词条 N={N}<input type="range" min={1} max={20} value={N} onChange={e=>setN(+e.target.value)} className="w-full accent-amber-500"/></label>
        <label>抄本代数 Gen={gen}{gen>2?"（已失免磨损）":""}<input type="range" min={0} max={5} value={gen} onChange={e=>setGen(+e.target.value)} className="w-full accent-amber-500"/></label>
        <label>全馆免磨损承载 ΣL={sigma.toFixed(1)}<input type="range" min={0} max={12} step={0.5} value={sigma} onChange={e=>setSigma(+e.target.value)} className="w-full accent-red-400"/></label>
        <label>这本（批）书占槽位={slots}<input type="range" min={1} max={12} value={slots} onChange={e=>setSlots(+e.target.value)} className="w-full accent-emerald-500"/></label>
        <label>广义书架={shelves}<input type="range" min={0} max={50} value={shelves} onChange={e=>setShelves(+e.target.value)} className="w-full accent-emerald-500"/></label>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mt-4 text-center">
        {[["免磨损", waiver===0?"失效":`${(waiver*100).toFixed(0)}%`, waiver===0?"text-red-400":waiver>=1?"text-emerald-300":"text-amber-300"],
          ["串扰“抄错”概率", `${(slip*100).toFixed(1)}%`, slip>=0.25?"text-red-400":slip>0?"text-amber-300":"text-emerald-300"],
          ["全局藏书减免贡献", `-${globalDisc}%`, "text-stone-200"],
          ["单槽精通封顶", `${effMastery.toFixed(1)} / ${(3.5*slots).toFixed(1)} 单位`, slots===1&&N>5?"text-amber-300":"text-stone-200"]].map(([k,v,c])=>(
          <div key={k} className="rounded-lg bg-stone-900 border border-stone-700 py-3 px-2"><div className="text-[11px] text-stone-500">{k}</div><div className={`text-lg font-bold ${c}`}>{v}</div></div>))}
      </div>
      <p className="text-xs text-stone-400 mt-3 leading-relaxed">{expectedLossPerUse}。抄错时 70% 降 1 级 / 25% 串成无关低阶 / 5% 串成诅咒，仅退 50% 经验与材料。把同一批附魔<b className="text-stone-200">拆到多个槽位</b>（调高槽位滑杆）才能绕开 3.5/槽的精通封顶——这正是设计想要的行为，而不是一本通吃。
      {gen>2 && <span className="text-red-300 block mt-1">第 3 代起免磨损特权直接归零：靠无限书无限复制神书给全村的路线，在代数上就被掐断了。</span>}</p>
    </div>
  );
}

export default function App(){
  const [page,setPage]=useState<Page>("audit");
  const [path,setPath]=useState<PathId|"all">("all");
  const [q,setQ]=useState("");
  const filtered = FINDINGS.filter(f=>(path==="all"||f.path===path)&&(q===""||(f.title+f.location+f.evidence+f.id).toLowerCase().includes(q.toLowerCase())));
  const counts = useMemo(()=>{const m:any={}; FINDINGS.forEach(f=>m[f.severity]=(m[f.severity]||0)+1); return m;},[]);

  return (
  <div className="min-h-screen bg-[#121110] text-stone-200 font-sans">
    <header className="sticky top-0 z-40 bg-[#121110]/95 backdrop-blur border-b border-stone-800">
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2.5 mr-auto">
          <div className="w-9 h-9 rounded-lg bg-amber-600 flex items-center justify-center text-white"><Library size={20}/></div>
          <div><div className="font-bold leading-none">纂刻附魔台 · 独立审计</div><div className="text-[11px] text-stone-500 mt-0.5">Unofficial 26.1.2 Port · Mod 1.1.0 · 静态审计，非官方结论</div></div>
        </div>
        <nav className="flex gap-1 bg-stone-900 border border-stone-800 rounded-lg p-1">
          {([["audit",FileSearch,"审计报告"],["debate",MessageCircleQuestion,"回应论调"],["advice",Lightbulb,"怀疑与建议"]] as [Page,any,string][]).map(([p,Icon,label])=>(
            <button key={p} onClick={()=>setPage(p)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm ${page===p?"bg-amber-600 text-white":"text-stone-400 hover:text-white"}`}><Icon size={15}/>{label}</button>))}
        </nav>
        <a href={REPO} target="_blank" rel="noreferrer" className="flex items-center gap-1 text-xs text-stone-400 hover:text-amber-300 border border-stone-700 rounded-lg px-2.5 py-2"><GitBranch size={14}/>被审分支 <ExternalLink size={12}/></a>
      </div>
    </header>

    {page==="audit" && <>
    <section className="max-w-7xl mx-auto px-4 pt-8 pb-4">
      <div className="flex items-start gap-3"><Bug className="text-red-400 mt-1" size={28}/><div>
        <h1 className="text-3xl font-bold text-white">仓库审计：硬编码、26.1.2 版本风险与数值合理性</h1>
        <p className="text-stone-400 mt-2 max-w-4xl text-sm leading-relaxed">审计对象为分支 <code className="text-amber-300">arena/649fac5c-chiseled-enchanting-table-26-1</code>（Minecraft 26.1.2 / Fabric Loader ≥0.19.3 / Fabric API 0.151.0+26.1.2 / Java ≥25）。方法：克隆后逐文件静态走读 105 个 Java 文件（约 39,005 行）、13 个 Mixin、11 份数据 JSON 与 Wiki 公式互校。<b className="text-stone-200">未在本环境编译或进游戏复现</b>——凡标“需运行时复现”者，都是代码层面的高概率嫌疑，需要用 CI 绿灯之外的真实存档（spark、多人、/reload、区块边缘）去证伪。README 记录的 CI 三绿（da77188）可信，但 CI 证明的是“能编、静态门齐”，证明不了下面这些。</p>
      </div></div>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mt-6 text-center">
        {[["发现总数",FINDINGS.length],["P0 启动级风险",counts.P0||0],["P1 应修",counts.P1||0],["P2 / 观察",(counts.P2||0)+(counts["观察"]||0)],["已做对的（见下）","6 项"]].map(([k,v])=>(
          <div key={k} className="rounded-xl bg-[#1c1917] border border-stone-800 py-4"><div className="text-2xl font-bold text-white">{v}</div><div className="text-xs text-stone-500 mt-1">{k}</div></div>))}
      </div>
      <div className="mt-4 rounded-xl border border-emerald-800/60 bg-emerald-950/30 p-4 text-sm">
        <div className="flex gap-2 font-semibold text-emerald-300"><ShieldCheck size={18}/>先说公道话：这仓库的工程纪律在同类移植里偏上</div>
        <div className="grid md:grid-cols-3 gap-3 mt-3 text-stone-300 text-[13px] leading-relaxed">
          <p><b className="text-white">默认值单一事实源：</b>BundledDefaults 由脚本从 library_resonance.json 生成，CI 逐字节比对，根治了“Java 与 JSON 各写一份 38/42”——本次审计没找到两处对不上的默认数值。</p>
          <p><b className="text-white">服务端权威完整：</b>Apply/Reroll/Freeze/TomePage 接收器全部校验 containerId + stillValid(player)，Apply 还有 8/tick 限流与断线清理；Apply 载荷在构造器卡 0..255、标识符 ≤512、未知 token 不回显进日志（NET-03）。</p>
          <p><b className="text-white">存档 fail-closed：</b>仪式队列解析失败是隔离+冻结+保留原文，而不是吞掉玩家物品；成本表过大会截断并标记 incomplete，客户端把缺行当 unknown 而非 0 价。这三处都是被真实事故教育过的写法。</p>
        </div>
      </div>
    </section>

    <section className="max-w-7xl mx-auto px-4 py-4">
      <div className="flex flex-wrap gap-2 items-center">
        {PATHS.map(p=><button key={p.id} onClick={()=>setPath(p.id as any)} title={p.desc} className={`px-3 py-1.5 rounded-full text-xs border ${path===p.id?"bg-amber-600 border-amber-600 text-white":"border-stone-700 text-stone-400 hover:border-amber-700 hover:text-amber-300"}`}>{p.label}</button>)}
        <div className="relative ml-auto"><Search size={15} className="absolute left-2.5 top-2.5 text-stone-500"/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="搜索编号 / 文件 / 关键词…" className="bg-stone-900 border border-stone-700 rounded-lg pl-8 pr-3 py-2 text-sm w-64 outline-none focus:border-amber-600"/></div>
      </div>
      <p className="text-xs text-stone-500 mt-2">{PATHS.find(p=>p.id===path)?.desc} · 当前 {filtered.length} 条</p>
      <div className="grid lg:grid-cols-2 gap-3 mt-3">
        {filtered.map(f=>(
          <article key={f.id} className="rounded-xl border border-stone-800 bg-[#1c1917] p-4 hover:border-stone-600 transition">
            <div className="flex items-center gap-2 flex-wrap">
              <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${sevColor[f.severity]}`}>{f.severity}</span>
              <span className="text-[11px] px-2 py-0.5 rounded bg-stone-800 text-stone-300">{PATHS.find(p=>p.id===f.path)?.label}</span>
              <span className="text-[11px] px-2 py-0.5 rounded bg-stone-900 border border-stone-700 text-stone-400">{f.confidence}</span>
              <code className="text-amber-400 text-xs font-bold ml-auto">{f.id}</code>
            </div>
            <h3 className="font-semibold text-white mt-2">{f.title}</h3>
            <p className="text-[11px] text-stone-500 mt-1 font-mono break-all">{f.location}</p>
            <p className="text-[13px] text-stone-300 mt-2 leading-relaxed"><b className="text-stone-100">证据：</b>{f.evidence}</p>
            <p className="text-[13px] text-stone-400 mt-1.5 leading-relaxed"><b className="text-red-300">风险：</b>{f.risk}</p>
            <p className="text-[13px] text-stone-400 mt-1.5 leading-relaxed"><b className="text-emerald-300">改法：</b>{f.fix}</p>
          </article>))}
        {filtered.length===0 && <div className="col-span-2 text-center text-stone-500 py-16">没有匹配的发现，换个关键词试试。</div>}
      </div>
    </section>

    <section className="max-w-7xl mx-auto px-4 py-6">
      <h2 className="text-xl font-bold text-white flex items-center gap-2"><Scale size={20} className="text-amber-400"/>数值与机制合理性总评</h2>
      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        <BookshelfCalc/>
        <div className="rounded-xl border border-stone-700 bg-[#1c1917] p-5">
          <div className="font-semibold text-emerald-300 flex gap-2 items-center"><Gauge size={18}/>逐项体检（默认 library_resonance.json）</div>
          <div className="divide-y divide-stone-800 mt-2">
            {BALANCE_NOTES.map(b=>(<div key={b.k} className="py-2.5 grid grid-cols-[110px_1fr] gap-2 text-[13px]"><span className="text-stone-400">{b.k}</span><span><b className="text-amber-200">{b.v}</b><span className="text-stone-400 block mt-0.5 leading-relaxed">{b.note}</span></span></div>))}
          </div>
        </div>
      </div>
      <SuperBookSim compact/>
      <div className="rounded-xl border border-stone-800 bg-[#1c1917] p-5 mt-4 text-sm leading-relaxed text-stone-300">
        <b className="text-white">总判断：</b>数值体系内部是自洽的——守恒退魔（telescoping conservation）、抄书 2 点 / 用书 1 点、单槽 3.5 封顶、总减免 −40% 硬顶，都能互相咬合，没有发现“改 A 忘 B”的算术矛盾。真正不合理的是三处<b className="text-amber-300">形状问题</b>而非大小问题：M=2 的 0→38 单跳（BAL-01）、温养 38/42 的断崖（BAL-02）、减免前 12 架的零反馈（BAL-03）。这三处都不会让系统崩，但都会让玩家形成错误心智模型，然后到社区发帖——第二页的两个论调，一半就诞生于此。
      </div>
    </section>
    </>}

    {page==="debate" && <Debate/>}
    {page==="advice" && <Advice/>}

    <footer className="border-t border-stone-800 mt-8"><div className="max-w-7xl mx-auto px-4 py-6 text-xs text-stone-500 flex flex-wrap gap-3 justify-between">
      <span>审计范围：arena/649fac5c 分支静态走读 · 未编译、未进游戏 · 标“需运行时复现”者请勿直接当实锤引用</span>
      <span>公式来源：docs/WIKI.md 与 library_resonance.json / shelf_gates.json 默认值 · 模拟器为公开公式复算</span>
    </div></footer>
  </div>);
}

function Debate(){
  const [tab,setTab]=useState(0);
  return (<main className="max-w-7xl mx-auto px-4 py-8">
    <h1 className="text-3xl font-bold text-white flex gap-3 items-start"><MessageCircleQuestion className="text-amber-400 mt-1" size={30}/>“都给这么大增益了，为什么还要限？”——这自相矛盾吗？</h1>
    <p className="text-stone-400 mt-3 max-w-4xl text-sm leading-relaxed">先给结论：<b className="text-emerald-300">不矛盾，而且这两组设计恰好是同一枚硬币的两面。</b>会觉得矛盾，是因为把三种不同性质的东西都笼统叫成了“增益”。拆开看，每个“给”都对应一个不同维度的“限”，限的从来不是同一个东西。</p>

    <div className="grid md:grid-cols-3 gap-3 mt-6">
      {[
        [Layers,"给的是「准入」","普通书架解锁等级、母本解锁 1..k 直附（含宝藏）、无限让母本免磨损——这些决定的是“能不能做”。准入越慷慨，毕业越早，所以必须在别处收。","text-emerald-300 border-emerald-800 bg-emerald-950/30"],
        [TrendingDown,"限的是「边际」","单槽精通 ≤3.5、总减免 −40% 硬顶、词条 >4 后免磨损率 −6%/条——这些决定的是“第 N 本书还值多少”。第一本神书很强，第二本同类就该打折，否则最优解永远是堆一本。","text-amber-300 border-amber-800 bg-amber-950/30"],
        [Timer,"限的是「速率」","母本 4 点耐久、温养 6天→1天/+1点、仪式等待 ≤300s/步、抄书代数 ≤2——这些决定的是“单位时间能产出多少”。速率不限，准入再贵也会被一夜刷穿。","text-red-300 border-red-800 bg-red-950/30"],
      ].map(([Icon,t,d,c]:any)=>(
        <div key={t} className={`rounded-xl border p-5 ${c}`}><Icon size={22}/><h3 className="font-bold text-white mt-2">{t}</h3><p className="text-[13px] text-stone-300 leading-relaxed mt-1.5">{d}</p></div>))}
    </div>
    <p className="text-sm text-stone-400 mt-4 leading-relaxed">一个现成的类比：原版给“无限”配了“与经验修补互斥”，给时运 III 配了“与精准采集互斥”——没人说原版自相矛盾，因为大家默认理解<b className="text-stone-100">“强效果必须占一个机会成本位”</b>。这个模组只是在更大的系统里重复了同一条原则，并把它从“二选一互斥”细化成了“递减曲线+全馆总量税”。真正值得批评的不是它有限制，而是<b className="text-amber-300">限制大多藏在 Wiki 公式里、游戏内 tooltip 没讲人话</b>（详见第三页）——玩家先感受到“被限”，却没被告知“为什么”，误读就是这么来的。</p>

    <div className="flex gap-2 mt-8">
      {[`论调一：“给无限+多书架这么大增益，又限单本/多书架/无限，不是自相矛盾吗？”`,`论调二：“我附一本带无限的超级书，岂不是赚麻了？”`].map((t,i)=>(
        <button key={i} onClick={()=>setTab(i)} className={`text-left px-4 py-3 rounded-xl border text-sm flex-1 ${tab===i?"border-amber-600 bg-[#201a15] text-white":"border-stone-800 bg-[#1c1917] text-stone-400"}`}>{t}</button>))}
    </div>

    {tab===0 && <section className="mt-4 space-y-3">
      {[
        ["“限制单本模板书”与“鼓励多书架”是同一句话","单槽精通封顶 3.5 的原文目的就写在 Wiki 里：‘杜绝单本全能神书独占 1 格即吃满 −20%’。它不是先鼓励多书架、又反悔限单本；而是‘多书架的收益，正是靠给单本封顶才成立的’。没有单本上限时，多摆书架的机会成本为零，多样性收藏直接死亡。","成立"],
        ["“限制周围多书架增益”限的不是书架，是书架的重复计价","书架给的三样东西——直附等级（38 封顶）、减免（−15% 封顶）、温养档位（42 后保底）——全部是‘达标制’而非‘线性制’。达标之后再堆书架，系统仍认它是广义书架（粒子、深层铭刻触发都算），只是不再重复发同一份钱。这叫边际递减，不叫收回增益。","成立"],
        ["“限制无限”恰恰是无限能存在的前提","如果无限母本无衰减、无代数、无全馆总量，那最优策略在开局第一本无限书出现时就收敛了：复制它、塞满每个书架、其余系统（耐久、温养、村民、战利品）全部作废。免磨损率随词条衰减、Gen>2 失效、ΣL≥3 串扰 25% 封顶，本质是让‘无限’从终点变回工具。删掉限制的那一版，才是没有无限可玩的版本。","成立"],
        ["唯一站得住的一半：命名与体感确实容易误读","‘无限不朽’‘最高 −40%’这类宣传词在前，衰减与封顶在 Wiki 公式在后。当玩家第一次发现自己的无限书也会磨损、减免卡在 40% 不动时，第一反应是‘说好的呢’。这是文案与 UI 的债（见 BAL-04），不是数值逻辑的矛盾。修法不是删限制，是把定价提前喊出来。","部分成立"],
      ].map(([t,d,v])=>(
        <article key={t} className="rounded-xl border border-stone-800 bg-[#1c1917] p-5 flex gap-4">
          <CheckCircle2 className="text-emerald-400 shrink-0 mt-0.5" size={20}/>
          <div><div className="flex gap-2 items-center flex-wrap"><h3 className="font-semibold text-white">{t}</h3><span className="text-[11px] bg-emerald-900 text-emerald-300 px-2 py-0.5 rounded-full">{v}</span></div>
          <p className="text-[13px] text-stone-400 leading-relaxed mt-1.5">{d}</p></div>
        </article>))}
    </section>}

    {tab===1 && <section className="mt-4 space-y-4">
      <div className="rounded-xl border border-red-900/70 bg-red-950/20 p-5 text-sm leading-relaxed text-stone-300">
        <div className="flex gap-2 font-bold text-red-300"><Swords size={18}/>先把这个“赚麻”方案完整执行一遍，看看在哪几步漏水</div>
        <ol className="list-decimal ml-5 mt-3 space-y-2 text-[13px]">
          <li><b className="text-white">你得先有一本无限书。</b>wear_immune 已被移出直附列表与宝藏顿悟池，村民交易默认拦截刷新——合法来源只剩世界战利品、原版附魔台随机、或“已有免磨损母本时复制”。也就是说这本超级书的入场券，本身就是一件稀有战利品，不是合成台上点出来的。</li>
          <li><b className="text-white">往上堆词条，每一步都单独计价。</b>每个附魔按各自 XP 公式（享受最高 −40% 减免后）+材料+可能的仪式等待逐条铭刻；堆的不是“一本书的价格”，是 N 个附魔的价格之和。互斥组（锋利/亡灵杀手/节肢杀手、各类保护、精准/时运、无限/经验修补）根本堆不到一起。</li>
          <li><b className="text-white">堆满之后，它作为装备书并不强。</b>附到一件装备上时只生效适用且不冲突的那几条，其余词条对这件装备是死重；它真正的价值在当母本——而母本价值立刻被下面三道税接管。</li>
          <li><b className="text-white">当母本用：</b>词条 &gt;4 后免磨损率每条 −6%（保底 30%）、占 1 个槽时精通贡献被 3.5 封顶（全局减免最多约 −4%）、全馆 ΣL≥3 后每次拓印最高 25% 抄错、强行跳过它退化概率上限 70%、抄成新书时子代 Gen+1 且抄书耗 2 点、Gen&gt;2 后免磨损归零。</li>
          <li><b className="text-white">它还是单点故障。</b>一本承载全部附魔的母本，退化/抄错/被锁/被队友抽走，损失的是全部；而拆成多本多槽，任何一本出事只损失一部分，且总精通、总减免反而更高。</li>
        </ol>
      </div>
      <SuperBookSim/>
      <div className="grid md:grid-cols-2 gap-3">
        <div className="rounded-xl border border-stone-800 bg-[#1c1917] p-5">
          <h3 className="font-semibold text-white flex gap-2"><Eye size={18} className="text-amber-400"/>所以“赚”在哪，又没赚在哪</h3>
          <ul className="text-[13px] text-stone-400 space-y-2 mt-3 leading-relaxed">
            <li className="flex gap-2"><CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5"/>确实赚到的：省下了反复找书/合成书的物流成本，一本在架，常用附魔 1~3 级量产。这是设计<b className="text-stone-200"> intended 的毕业奖励</b>，不是漏洞。</li>
            <li className="flex gap-2"><XCircle size={15} className="text-red-400 shrink-0 mt-0.5"/>没赚到的：经验与材料一分不少（母本只免“书的磨损”，不免玩家的 XP）；减免被单槽 3.5 封顶卡死；产量被温养回复速率卡死。</li>
            <li className="flex gap-2"><XCircle size={15} className="text-red-400 shrink-0 mt-0.5"/>更没赚到的：你没法把它复制成军团。Gen≤2 的代数上限意味着孙辈书就回归普通耐久，“一本传全服”在谱系上断头。</li>
          </ul>
        </div>
        <div className="rounded-xl border border-stone-800 bg-[#1c1917] p-5">
          <h3 className="font-semibold text-white flex gap-2"><Scale size={18} className="text-emerald-400"/>盈亏平衡点（粗算）</h3>
          <p className="text-[13px] text-stone-400 leading-relaxed mt-3">假设组装一本 10 词条超级书的沉没成本约为 10 次单独铭刻的 XP+材料之和，而它每次量产只比“每次现找母本”省下物流时间、不省 XP——那么它要靠<b className="text-stone-200">高频复用同一批附魔</b>才能回本。单人毕业装全套做完通常也就几十次铭刻，省下的主要是找书时间；多人服务器里它作为公共图书馆核心则确实强——但那时 ΣL 串扰与锁书、退化风险也由全馆共同承担。<b className="text-amber-300">结论：它是“省事的毕业奖励”，不是“印钞机”。</b>说它赚麻的人，通常默认了组装免费、复制免费、使用免费——而系统恰好对这三件事分别收了税。</p>
        </div>
      </div>
    </section>}
  </main>);
}

function Advice(){
  const doubts = [
    ["复杂度已经超过可解释上限","38/42 两套书架口径（普通/广义）、三色 XP 徽章、两段减免、三档温养、双跳过博弈、代数与串扰——需要一本游戏内秘典+45KB Wiki 才能讲清。新玩家的前 30 分钟大概率在‘为什么点了没反应’里度过。","高"],
    ["公式密度 vs 可验证性","仓库有约 2671 行测试（EconomyAndConfigVerificationTest 就 1860 行），但主要是无头公式测试；没有‘真实多人服务器跑一周’的行为数据。串扰 25%、等待 300s 这类体感数值对不对，测试证明不了。","高"],
    ["维护面与上游脱节的风险","这是非官方移植：原版 Sacramentix 的设计、26.1.2 的映射、JEI 已删 API、Fabric 权限 API，四条线任何一条动都要改。155 行协议探针与三个上帝类会让每次跟版都更贵。","中高"],
    ["‘可配置’可能只是把难题转嫁给服主","library_resonance.json 暴露了上百个参数，连 wait_curve 的 saturation 都有。没有预设档（休闲/标准/硬核）时，绝大多数服主只会用默认——那么默认值就必须是对的，调参自由不能替代默认平衡。","中"],
    ["多人公平性没有被证明","锁书、仪式队列归属 UUID、母本责任挑选都做了，但‘图书馆是谁的’在多人下仍是社交问题：一个人建的 42 架图书馆，全服蹭减免，贡献与收益不对等时靠模组解决不了。","中"],
    ["性能只有错峰，没有画像","20 tick 错峰、成本表截断都是点状优化；没有给出‘42 书架+10 名玩家同时开台’的 tick 预算。COUP-04 的区块边缘扫描是悬而未决的雷。","中"],
  ];
  const sugg: [string,string,string,string][] = [
    ["P0","进游戏前，先把三句定价喊出来","在无限书 tooltip、减免条、跳过按钮上各加一行人话：‘词条超 4 条后免磨损递减’‘减免总上限 −40%’‘强行跳过可能损坏母本（无限书最高 70%）’。这一步直接消灭第二页两个论调的一大半。","新玩家不看 Wiki 也能在第一次吃亏前看到代价；社区同类质疑帖数量下降。"],
    ["P0","给 Mixin 分级降级与目标方法自检","核心注入 require=1，装饰/世界生成类 require=0+一次性警告；CI 增加‘目标方法在 26.1.2 映射中存在’的断言（见 MIXIN-01/02）。","跟版时从‘进不去游戏’降级为‘某功能暂时失效+日志说清’。"],
    ["P1","把手写存档与手写协议收编","仪式队列迁 ListCodec+版本号、EnchantmentWithLevel 加等级界、协议改一次协商通道冻结探针（CODEC-02/03、NET-01）。","下一次改载荷不用再加一代探针；存档坏一步不再冻结整队。"],
    ["P1","数值只改形状，不改大小","优先修 BAL-01（低 M 附魔单级书架跨度设上限）、BAL-02（温养改连续函数）、BAL-03（减免第 1 架起给小额）。三处都不动总预算，只动曲线形状，风险最小、体感收益最大。","击退 II 不再需要 38 架；37→38、41→42 不再出现回复时间断崖。"],
    ["P1","扫描缓存与性能画像","书架扫描按台缓存、邻居变化才失效；用 spark 在‘42 架+多人开台+/reload’三场景各采一份画像写进 docs（COUP-04、NET-03 给其余 C2S 补限流）。","给出可引用的 tick 预算，而不是‘应该不卡’。"],
    ["P2","给服主三档预设而不是一百个旋钮","在 ConfigCatalog 上加 休闲/标准/专家 三套预设包，JSON 高级参数保留但标注‘预设之外自担风险’；Sync 配置改发 diff（NET-04）。","90% 服主只选档位；改配置不再全服广播三份 JSON。"],
    ["P2","把‘为什么’写进成就与秘典的因果链","已有‘燃魂催墨’‘心急吃不了热豆腐’这类好成就，继续沿这条路：第一次触发串扰/退化时弹一条解释性提示并指向秘典对应页，而不是只扣东西。","玩家把‘被惩罚’理解为‘我选了付这个价’，正是博弈设计想要的。"],
    ["P2","补一轮真实环境验收清单","发布前固定跑：专用服务器多人同时开台、区块边缘图书馆、/reload 后成本表一致性、旧存档（上一版）母本代数/队列迁移、JEI 与 REI 各查一次双向配方。把清单写进 docs/ci。","把‘需运行时复现’的那批发现逐条销账或转正为 bug。"],
  ];
  return (<main className="max-w-7xl mx-auto px-4 py-8">
    <h1 className="text-3xl font-bold text-white flex gap-3 items-start"><HeartHandshake className="text-emerald-400 mt-1" size={30}/>中肯的怀疑与建议</h1>
    <p className="text-stone-400 mt-3 max-w-4xl text-sm leading-relaxed">这一页不站队：先把对项目<b className="text-stone-100">最有分量的怀疑</b>摆全（有些目前没有答案，只有风险），再给可落地的建议。每条建议都带验收标准——没有验收标准的建议只是愿望。</p>

    <h2 className="text-xl font-bold text-white mt-8 flex gap-2 items-center"><ShieldAlert size={20} className="text-amber-400"/>值得认真对待的怀疑</h2>
    <div className="grid lg:grid-cols-2 gap-3 mt-4">
      {doubts.map(([t,d,s])=>(
        <article key={t} className="rounded-xl border border-stone-800 bg-[#1c1917] p-5">
          <div className="flex justify-between gap-2"><h3 className="font-semibold text-white">{t}</h3><span className={`text-[11px] px-2 py-0.5 rounded-full h-fit ${s==="高"?"bg-red-900 text-red-200":s==="中高"?"bg-amber-900 text-amber-200":"bg-stone-700 text-stone-300"}`}>分量 {s}</span></div>
          <p className="text-[13px] text-stone-400 leading-relaxed mt-2">{d}</p>
        </article>))}
    </div>
    <div className="rounded-xl border border-amber-800/60 bg-[#201a15] p-5 mt-4 text-sm leading-relaxed text-stone-300 flex gap-3">
      <AlertTriangle className="text-amber-400 shrink-0 mt-0.5" size={20}/>
      <p><b className="text-white">最尖锐的一条怀疑，单独说：</b>这套系统的全部限制（单槽封顶、代数、串扰、温养速率）都是在防“玩家找到最优解后系统收敛成单一玩法”。但如果一个服务器的玩家根本不追求最优解，这些限制就只是摩擦；如果追求，它们又是必要的税。<b className="text-amber-300">模组无法同时对两种玩家最优</b>——所以第三页建议里的“三档预设”不是锦上添花，而是承认这个取舍、把选择权明码交给服主。继续用一套默认打天下，才是这套数值最可能翻车的地方。</p>
    </div>

    <h2 className="text-xl font-bold text-white mt-8 flex gap-2 items-center"><ListChecks size={20} className="text-emerald-400"/>建议清单（按优先级）</h2>
    <div className="space-y-3 mt-4">
      {sugg.map(([p,t,d,a])=>(
        <article key={t} className="rounded-xl border border-stone-800 bg-[#1c1917] p-5 flex gap-4">
          <span className={`text-[11px] font-bold px-2 py-1 rounded h-fit ${p==="P0"?"bg-red-600 text-white":p==="P1"?"bg-amber-600 text-white":"bg-stone-600 text-white"}`}>{p}</span>
          <div className="grid md:grid-cols-2 gap-3 flex-1">
            <div><h3 className="font-semibold text-white">{t}</h3><p className="text-[13px] text-stone-400 leading-relaxed mt-1">{d}</p></div>
            <div className="rounded-lg bg-stone-900 border border-stone-800 p-3"><div className="text-[11px] text-emerald-400 font-semibold flex gap-1 items-center"><CheckCircle2 size={13}/>怎么算做完</div><p className="text-[13px] text-stone-300 leading-relaxed mt-1">{a}</p></div>
          </div>
        </article>))}
    </div>

    <div className="rounded-xl border border-stone-700 bg-[#1c1917] p-6 mt-6">
      <h3 className="font-bold text-white flex gap-2 items-center"><Workflow size={19} className="text-amber-400"/>如果只能做三件事（给维护者的最小路线）</h3>
      <div className="grid md:grid-cols-3 gap-3 mt-4 text-[13px]">
        {[["1 · 先解释，后平衡","把三句定价写进 tooltip 与按钮（P0）。成本最低，且立刻减少‘自相矛盾’类误读——很多平衡争议其实是信息争议。"],
          ["2 · 先保命，后优雅","Mixin 分级降级 + 扫描画像（P0/P1）。对非官方移植，‘新版本第一天能进游戏’比任何新玩法都重要。"],
          ["3 · 先收编，后扩张","协议协商与 Codec 化完成前，冻结新增载荷字段与新 Mixin（P1）。155 行探针就是扩张跑在收编前面的账单。"]].map(([t,d])=>(
          <div key={t} className="rounded-lg bg-stone-900 border border-stone-800 p-4"><b className="text-amber-300">{t}</b><p className="text-stone-400 leading-relaxed mt-1.5">{d}</p></div>))}
      </div>
      <p className="text-xs text-stone-500 mt-4 flex gap-1.5 items-center"><Lock size={13}/>立场声明：本页与前两页均为独立第三方静态审计意见，未与仓库维护者沟通，未运行该模组；数值结论以 Wiki 与默认 JSON 为准，实测可能修正其中“需运行时复现”的部分。</p>
    </div>
  </main>);
}
