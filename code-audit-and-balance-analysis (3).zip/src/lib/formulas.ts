// Formulas transcribed from the repo (bd61ca2) with bundled-datapack defaults.

/** InscriptionRitualMechanics.computeLoadSlipProbability with crossline_slip defaults. */
export function slipProbability(L: number, shelves: number): number {
  if (L + 1e-9 < 3.0) return 0;
  let bonus = 0;
  if (shelves >= 42) bonus = 0.03;
  else if (shelves >= 38) bonus = 0.02;
  else if (shelves >= 32) bonus = 0.01;
  const raw = 0.035 * Math.max(0, L - 3) + bonus;
  return Math.max(0, Math.min(0.18, raw));
}

/** MasterTomeWear.computeRegenIntervalTicks → seconds (defaults 7200/38→3600/42→1200). */
export function regenSeconds(s: number): number {
  const base = 7200 * 20, t1 = 3600 * 20, t2 = 1200 * 20;
  const s1 = 38, s2 = 42;
  let ticks: number;
  if (s < s1) {
    const mid1 = Math.max(t1, 0.5 * (base + t1));
    ticks = Math.max(t1, Math.round(base - ((base - mid1) * s) / s1));
  } else if (s < s2) {
    const mid2 = Math.max(t2, 0.5 * (t1 + t2));
    ticks = Math.max(t2, Math.round(t1 - ((t1 - mid2) * (s - s1)) / Math.max(1, s2 - s1)));
  } else {
    const floor = Math.max(20, t2 / 2);
    ticks = Math.max(floor, Math.min(t2, Math.round(t2 / (1 + 0.05 * (s - s2)))));
  }
  return ticks / 20;
}

/** Wait seconds for one inscription (computeSingleEnchantWaitTicks) – 0 when gate inactive. */
export function waitSeconds(shelves: number, tomeEnchants: number, relLevel = 1, app = 1): number {
  const active = shelves >= 32 || tomeEnchants >= 10; // median gate (default 32) OR >= 10 tome enchants
  if (!active) return 0;
  const shelfLoad = shelves / 42;
  const tomeLoad = tomeEnchants / 22;
  const rl = Math.min(1, Math.max(0.1, relLevel));
  const intensity = (0.42 * shelfLoad + 0.58 * tomeLoad) * (0.35 + 0.65 * Math.pow(rl, 1.15)) * Math.max(1, app);
  const sec = 300 * (1 - Math.exp(-0.62 * intensity));
  return Math.min(300, Math.max(5, sec));
}

export const SLIP_SPLIT = { drop: 0.7, junk: 0.25, curse: 0.05 };
