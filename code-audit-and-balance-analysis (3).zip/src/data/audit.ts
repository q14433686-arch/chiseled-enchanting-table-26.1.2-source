import type { Severity } from "../components/ui";

export type PathKey = "api" | "codec" | "net" | "gui" | "mixin" | "dead" | "coupling" | "design";

export const PATHS: { key: PathKey; label: string; desc: string }[] = [
  { key: "api", label: "源码 API", desc: "对 26.1.2 / Fabric API 的调用方式是否正确、是否绕过了原版机制" },
  { key: "codec", label: "数据编解码", desc: "网络包、存档、ItemStack 组件的序列化与上限" },
  { key: "net", label: "网络同步", desc: "C2S/S2C 一致性、同步频率、两端状态是否会分叉" },
  { key: "gui", label: "GUI 输入", desc: "键鼠事件、模态层、误触与重复发送" },
  { key: "mixin", label: "Mixin 注入", desc: "注入点范围、失败模式、与其他模组的冲突面" },
  { key: "dead", label: "死代码", desc: "没人调用的方法、只有测试在用的重载、残留的兼容层" },
  { key: "coupling", label: "耦合风险", desc: "语义分裂、上帝类、隐式依赖" },
  { key: "design", label: "数值 / 机制 / 文档", desc: "数值是否合理、文档与数据是否一致、机制有无漏洞" },
];

export interface Finding {
  id: string;
  path: PathKey;
  sev: Severity;
  title: string;
  where: string;
  detail: string[];
  fix: string;
  code?: string;
  verify?: boolean; // needs decompilation / runtime confirmation
}

export const FINDINGS: Finding[] = [
  // ───────── 源码 API ─────────
  {
    id: "API-01",
    path: "api",
    sev: "中",
    title: "重开界面的距离写死为 8 格，与 stillValid 的交互距离对不上，而且不检查视线",
    where: "menu/EnchantingNetworking.java · ReopenTablePayload 接收器",
    detail: [
      "接收器用 `distanceToSqr(...) > 64.0D`（8 格）判断，而菜单本身的 `stillValid` 用的是原版 `AbstractContainerMenu.stillValid(access, player, block)`，后者走玩家的方块交互距离属性（默认约 4.5 格）。",
      "结果是在 4.5～8 格之间发 Reopen：服务端会 `openMenu`，下一 tick `stillValid` 又判定失败把界面关掉，玩家看到界面闪一下就没了。",
      "这里也没有视线检查，只要区块加载着，8 格内隔墙就能打开。",
      "节流时间戳在校验之前就写入了，所以一个被拒绝的请求也会让紧接着的合法请求被丢掉。",
    ],
    fix: "改用 `player.isWithinBlockInteractionRange(pos, 1.0)` 或 `canInteractWithBlock`，和 stillValid 共用同一个判定；节流时间戳放到校验通过之后再写。",
    code: `if (player.distanceToSqr(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) > 64.0D) {
    return;
}`,
  },
  {
    id: "API-02",
    path: "api",
    sev: "中",
    title: "InventoryUtils.insertItem 自己实现了一遍原版背包插入，写死 36 格",
    where: "utils/InventoryUtils.java",
    detail: [
      "循环上限硬编码为 `36`，没看 `Container#getMaxStackSize()` 和 `canPlaceItem`，也不走 `Inventory#add` / `placeItemBackInInventory`，所以背包内容变化不会通过原版的统一路径通知出去（`setChanged`、统计、拾取相关钩子都跳过了）。",
      "其他扩展了背包的模组（饰品栏、额外格子、背包类模组）不会被考虑到。",
    ],
    fix: "直接用 `player.getInventory().placeItemBackInInventory(stack)`，原版自带“放不下就掉在地上”的语义。",
  },
  {
    id: "API-03",
    path: "api",
    sev: "低",
    title: "Shift 快速移动在 clicked() 里截获，没有放进 quickMoveStack",
    where: "menu/ChiseledEnchantingTableScreenHandler.java · clicked()",
    detail: [
      "`ContainerInput.QUICK_MOVE` 在 `clicked` 里被直接拦下，自己写了一套移动逻辑。原版里 Shift 连点、`PICKUP_ALL`、以及排序类模组调用的都是 `quickMoveStack`。现在两条路径各管一摊，行为对不齐。",
      "从附魔槽 / 费用槽 Shift 移出时是先 `set(EMPTY)` 再插入背包，背包满了物品就直接掉在玩家脚下，原版这种情况会把物品留在原槽。",
    ],
    fix: "把逻辑挪进 `quickMoveStack`，让它返回 `ItemStack.EMPTY` 或剩余堆，按原版约定处理“放不下就不动”。",
  },
  {
    id: "API-04",
    path: "api",
    sev: "低",
    title: "Fabric 接收器外面又包了一层 server.execute()",
    where: "EnchantingNetworking / ModConfigNetworking 的各个接收器",
    detail: [
      "从 1.20.5 起，Fabric 的 Play 载荷处理器本来就在服务端主线程上执行。再套一层 `server.execute()` 时，`BlockableEventLoop` 发现已经在同一线程会立刻执行，功能上没问题，但会让读代码的人以为这里存在跨线程问题。还有一个不一致：配置更新接收器就没套这层。",
    ],
    fix: "统一去掉这层包装，或者加注释说明线程模型，免得后人照着抄。",
  },
  {
    id: "API-05",
    path: "api",
    sev: "低",
    title: "自己复刻了原版雕纹书架的点击槽位算法（0.375 / 0.6875）",
    where: "mechanics/resonance/TomeLockGuards.java · hitSlot()",
    detail: [
      "为了在右键时拦住锁定书，把原版“命中位置 → 槽位”的换算常量抄了一份。原版一旦调整（比如 `SelectableSlotContainer#getHitSlot` 改了实现），这里会悄悄算错槽位：本该锁住的书被取走，或者没锁的书取不出来。",
    ],
    fix: "直接调用原版 `ChiseledBookShelfBlock` 的命中计算（可以用 accessor / invoker 暴露出来），不要复制常量。",
  },

  // ───────── 数据编解码 ─────────
  {
    id: "COD-01",
    path: "codec",
    sev: "中",
    title: "配置同步包声明的字符串上限 256 KiB，原版 C2S 自定义载荷只有约 32 KiB",
    where: "config/ModConfigNetworking.java · UpdateRuntimeConfigPayload",
    detail: [
      "`writeUtf(json, 262_144)` 的长度单位是字符。原版 `ServerboundCustomPayloadPacket` 的载荷上限是 32767 字节，中日韩字符在 UTF-8 下占 3 字节。如果配置里 per-enchant overrides 写得多，客户端点保存会因为包太大被踢下线，而不是看到“保存失败”。",
      "S2C 方向的上限比这大得多，问题主要在客户端往服务端发的这一侧。",
    ],
    fix: "C2S 只发差异（diff/patch），或者分片发送；在编码前检查字节数，超限就直接在 UI 上提示。",
    verify: true,
  },
  {
    id: "COD-02",
    path: "codec",
    sev: "中",
    title: "母本回生进度存在一个独立的 JSON 文件里，没进 SavedData，也没挂在方块实体上",
    where: "mechanics/resonance/WorldRegeneration.java · savePersistedState / loadPersistedState",
    detail: [
      "进度写在 `world/data/<SAVE_FILENAME>`，写入时机不跟存档的保存周期走。崩溃、回档、`/save-off` 期间做的备份、复制存档，都可能让区块数据和这份 JSON 对不上。",
      "条目用 BlockPos + 书签名（`custom_name` + 附魔表）来认书。两本同名、同附魔的书互换位置后，会被当成同一本。",
      "`onChunkUnloaded` 每卸载一个区块都要把全部条目扫一遍，复杂度是 O(条目数)，在大服务器上会随区块卸载频率放大。",
    ],
    fix: "改用 `SavedData`（随存档原子写入），或者把进度做成书本身的 DataComponent / 书架方块实体的附加数据；按区块建索引。",
  },
  {
    id: "COD-03",
    path: "codec",
    sev: "低",
    title: "磨损和代数写在 CUSTOM_DATA 的 NBT 键里，没有注册成 DataComponent",
    where: "mechanics/resonance/TomeWearData.java（cet_tome_wear / cet_generation）",
    detail: [
      "26.x 推荐用注册的 `DataComponentType` 配一个 Codec。现在的 CUSTOM_DATA 方案会被 `/data`、其他模组对 custom_data 的合并逻辑影响，也没法享受组件级别的网络同步和比较优化。",
      "附魔书 64 堆叠在实际中意义有限：一旦有了磨损或代数，NBT 不同的书就叠不到一起。",
    ],
    fix: "注册 `chiseled_enchanting_table:tome_wear` 组件，写一个 `Codec<TomeWear>`，再加一段一次性的旧 NBT 迁移逻辑。",
  },
  {
    id: "COD-04",
    path: "codec",
    sev: "低",
    title: "仪式队列用字符串序列化，准入上限按 encode().length() > 1024 算",
    where: "block/ChiseledEnchantingTableBlockEntity.java · enqueueInscription / ritualCorruptQueue",
    detail: [
      "队列是手写的字符串编码，坏数据保存在 `ritualCorruptQueue` 里。用字符串长度当准入门槛是脆弱的：附魔 ID 一长（比如模组命名空间较长），正常请求也会被拒绝。",
      "Apply 载荷里等级用 `writeInt`，而同一协议里其他字段都用 VarInt；`readMasterCharges` 里的 `val > 256` 和 `SyncRitualStatePayload` 里的 `> 256` 都是裸常量，没有引用 `PayloadLimits`。",
    ],
    fix: "队列条目改用 `Codec`/`StreamCodec` 的 record；上限统一放到 PayloadLimits 里，和配置的 clamp 共用同一个常量。",
  },

  // ───────── 网络同步 ─────────
  {
    id: "NET-01",
    path: "net",
    sev: "高",
    title: "附魔书最大堆叠数由两端各自读本地文件决定，没有握手校验",
    where: "ChiseledEnchantingTable.onInitialize · DefaultItemComponentEvents.MODIFY",
    detail: [
      "`enchanted_book_stack_size` 属于 RESTART_REQUIRED，客户端和服务端在启动时各读各的 `config/chiseled_enchanting_table.json`。`ModConfigNetworking` 同步的是运行时配置，不包括这一项的一致性检查。",
      "只要客户端是 1、服务端是 64（或者反过来），容器点击的预测就会和服务端算的不一样，表现为物品闪烁回弹、Shift 点击后数量不对、创造模式中键复制异常。",
    ],
    fix: "加入服务器时比对这个值，不一致就断开并提示；或者干脆把它写成数据驱动的物品组件，由服务端注册表同步过去。",
  },
  {
    id: "NET-02",
    path: "net",
    sev: "中",
    title: "每 20 tick 全量扫一次书架、全量推送一次，所有玩家挤在同一个 tick，也没有脏标记",
    where: "ChiseledEnchantingTableScreenHandler.broadcastChanges()",
    detail: [
      "条件是 `gameTime % 20 == 0`，所以每个开着界面的玩家都在同一个 tick 执行 `refreshLiveShelfState`（扫描默认 7×5×7，配置上限 17×13×17 = 3757 格，打开 LOS 时每格还要追一条射线）和 `pushRitualStateToViewer`。",
      "书架就算没变，也会重建并发送一次 `LiveShelfStatePayload`。按“1 秒内实时刷新”这个卖点，正确做法是只在变化时推送。",
      "扣费、入队、磨损这几个步骤里也分别各调一次 `refreshLiveShelfState()`，单次操作里会重复扫描好几遍。",
    ],
    fix: "按 `containerId` 错开 tick（`(gameTime + id) % 20`）；给书架内容算一个哈希，只有变化才发包；同一 tick 内缓存扫描结果。",
  },
  {
    id: "NET-03",
    path: "net",
    sev: "低",
    title: "取消仪式不退还已付的经验、材料和母本磨损，磨损在入队那一刻就扣掉了",
    where: "ChiseledEnchantingTableBlockEntity.cancelRitual → clearRitualState",
    detail: [
      "`/cet cancel-ritual` 只清空队列。文案里写了“不退还”，但这和项目反复强调的“补差价不吃亏 / XP 守恒”是矛盾的。",
      "磨损在 `EnchantmentApplication.apply` 入队时就通过 `applyShelfWearDetailed` 落到书上了，不是在仪式完成时才扣。于是“排队后取消”等于白白磨掉母本。",
    ],
    fix: "取消时按 `paidXpPoints / paidItems` 原样退还（这些字段已经记录在队列里了）；磨损改到完成时再扣，或者取消时回滚。",
  },

  // ───────── GUI 输入 ─────────
  {
    id: "GUI-01",
    path: "gui",
    sev: "中",
    title: "回车键直接发送 Apply，没有防抖，按住不放会随键盘重复连发",
    where: "gui/EnchantementListWidget.java · keyPressed()",
    detail: [
      "`KEY_RETURN` / `KEY_NUMPADENTER` 一按下就调用 `serverSendApplyEnchant()`。按住回车时操作系统的 key-repeat 会连续触发。",
      "服务端每次都会重新校验，所以刷不了物品，但多级升级会被一级一级排进仪式队列、连续扣费。玩家往往要到扣完才反应过来。",
    ],
    fix: "检查 `event.isRepeat()` / 加一个 250ms 的客户端冷却；高消耗操作要二次确认。",
  },
  {
    id: "GUI-02",
    path: "gui",
    sev: "中",
    title: "原版附魔台在 vanilla_table_mode=ALL 时仍然显示三档费用，按钮能点但没有效果",
    where: "mixin/enchanting_table/DisableBookEnchanting.java",
    detail: [
      "这里只让 `getEnchantmentList` 返回空列表。原版 `slotsChanged` 照样计算并显示 `costs[]`，按钮看起来可以点，点下去什么都不发生，也没有任何提示。",
    ],
    fix: "ALL 模式下同时把 `costs[i]` 置 0（RETURN 注入 slotsChanged），或者给一行提示文字。",
  },
  {
    id: "GUI-03",
    path: "gui",
    sev: "低",
    title: "配置界面的数字键会全局切换分类",
    where: "gui/config/ChiseledEnchantingConfigScreen.java · keyPressed()",
    detail: [
      "现在界面里没有 EditBox，所以还不会出事。但以后只要加一个数值输入框，输入数字就会被当成“切换分类”。",
    ],
    fix: "先判断 `getFocused() instanceof EditBox`，是的话就把按键交给输入框。",
  },

  // ───────── Mixin ─────────
  {
    id: "MIX-01",
    path: "mixin",
    sev: "高",
    title: "LockedBookContainerMixin 注入的是全局 ContainerHelper：范围过大，而且很可能根本没拦住书架本身",
    where: "mixin/bookshelf/LockedBookContainerMixin.java",
    detail: [
      "`ContainerHelper.removeItem/takeItem` 被几乎所有原版容器共用（箱子、木桶、潜影盒、漏斗……）。锁定书一旦进了任何容器就再也取不出来，误伤面非常大。",
      "反过来，在 1.20–1.21.x 里，原版 `ChiseledBookShelfBlockEntity#removeItem` 是直接操作 `items` 列表的，不经过 ContainerHelper。如果 26.1.2 还是这样，漏斗 / 投掷器的自动化抽取就完全没被拦住。“守卫自动化”这个说法要反编译确认。",
      "`require = 0` 让注入失败时什么都不报。描述符一变，守卫就消失了，连一条日志都没有。",
      "另外 `locked_shelf_breakable` 默认是 true：直接挖掉书架，书会带着锁掉出来，可以带去任何地方。锁机制在默认配置下等于一碰就破。",
    ],
    fix: "改为精准注入 `ChiseledBookShelfBlockEntity#removeItem` 并实现 `canTakeItem`；注入失败时在启动阶段打 WARN；默认值要么阻止挖掘，要么挖掉时自动解锁。",
    verify: true,
  },
  {
    id: "MIX-02",
    path: "mixin",
    sev: "中",
    title: "每次调用 getOffers() 都改写村民交易，而且用户回调里又重复做了一遍",
    where: "mixin/villager/VillagerInfinitySanitizeMixin.java + UseEntityCallback",
    detail: [
      "`getOffers` 会被 AI、交易界面、存档序列化等路径频繁调用，每次都要遍历全部交易并解析附魔。逻辑是幂等的，但这是热路径上的浪费。",
      "只有“无限”一个附魔的书会被替换成力量 I，价格和交易经验仍然按“无限”算，玩家拿到的是一笔明显不对等的交易。",
      "其他模组有意加的“无限”交易会被一起抹掉（有开关，但默认开启）。",
    ],
    fix: "注入 `updateTrades` / 交易生成的位置（只在生成时处理一次）；替换时按新附魔重新计算价格；去掉重复的 UseEntityCallback 路径。",
  },
  {
    id: "MIX-03",
    path: "mixin",
    sev: "中",
    title: "AddRandomTick 用覆写的方式给所有装了书的雕纹书架加上随机刻",
    where: "mixin/bookshelf/AddRandomTick.java",
    detail: [
      "Mixin 在目标类上 `@Override isRandomlyTicking/randomTick`。结构里生成的大量野生雕纹书架也会被纳入随机刻，只是为了播放粒子和声音。",
      "其他模组如果也覆写同一个方法，Mixin 合并只会保留一个，冲突时不会报错，会直接有一方失效。",
    ],
    fix: "粒子效果改到客户端 `animateTick`（原版附魔台就是这么做的）；确实需要服务端逻辑的话，用 @Inject 而不是覆写。",
  },
  {
    id: "MIX-04",
    path: "mixin",
    sev: "低",
    title: "LevelChunkPostProcessMixin 依赖 postProcessing 列表的含义",
    where: "mixin/structure/LevelChunkPostProcessMixin.java",
    detail: [
      "凡是在 postProcessing 列表里的普通书架都会被交给 `postProcessBookshelf`。但原版也会因为流体、形状更新等别的原因标记位置，所以可能误改一些非目标结构里的书架（需要实测）。",
    ],
    fix: "用自己的附加集合（chunk attachment）记录“由本模组标记”的位置，不要复用原版列表。",
    verify: true,
  },
  {
    id: "MIX-05",
    path: "mixin",
    sev: "低",
    title: "RemoveEnchantMerge 在 createResult 内部临时改输入栈数量，并调用 broadcastChanges",
    where: "mixin/anvil/RemoveEnchantMerge.java",
    detail: [
      "已经改成 try/finally，比之前安全。但同一时刻其他 mixin 在 createResult 里读到的左槽数量是 1，而不是真实值。`broadcastChanges()` 在客户端预测路径上也会执行。",
    ],
    fix: "复制一份栈去计算，不要就地修改；只在服务端广播。",
  },

  // ───────── 死代码 ─────────
  {
    id: "DEAD-01",
    path: "dead",
    sev: "低",
    title: "静态扫描找到约 32 个疑似没有调用方的 static 方法",
    where: "多个文件（正则扫描，没有排除反射调用）",
    detail: [
      "例如：`Advancement.checkAllEnchantBook`（只是转调 checkBookMilestones 的别名）、`ChiseledEnchantingTableData.additionalItemCosts / bookResearchPrimaryCost / transformationPrimaryCost / treasureEpiphanyChance / treasureEpiphanyMaxSlots / stablePositiveHash`、`MasterTomeWear.applyShelfWear`、`TomeWearData.hasInfinityEnchantment`、`InscriptionRitualMechanics.doesMatchingMasterTomeHaveInfinity`、`TomeLockData.hasLock / isOwnedBy`、`TomeLockGuards.shelfHasLockedBook`、`WorldRegeneration.regenIntervalTicks / clearExpiredLock`、`ChiseledEnchantingTableBlock.hasShelfLineOfSight`、`DisenchantmentApplication.rarityMultiplier`、`EnchantQueryIndex.forBook / forItem`、`LibraryResonance.activeConfig`、`SyncedEnchantmentCosts.onChange`。",
      "其中 `hasInfinityEnchantment` 和 `doesMatchingMasterTomeHaveInfinity` 没被用到尤其要注意：这说明“按 ID 判断无限”和“按标签判断免磨损”两套逻辑并存，最后只留下了一半（见 COUP-01）。",
    ],
    fix: "删掉，或者标 `@VisibleForTesting`；CI 里加 `-Xlint` / PMD 的 UnusedPrivateMethod 和 unused-public 检查。",
  },
  {
    id: "DEAD-02",
    path: "dead",
    sev: "低",
    title: "带 Config.DEFAULT 的便利重载只在测试里用，容易被误调",
    where: "InscriptionRitualMechanics.computeSingleEnchantWaitTicks(6 参) / computeRushDegradeChance(2 参) / MasterTomeWear.computeUnbreakingWaiverChance(int, cfg)",
    detail: [
      "这些重载会悄悄改用 `Config.DEFAULT`，而不是数据包里的实时配置。业务代码一旦调错，数据包修改就不生效，而且编译期看不出来。",
      "`computeUnbreakingWaiverChance` 有 `(cfg, int)` 和 `(int, cfg)` 两个参数顺序相反的重载，是典型的误用陷阱。",
    ],
    fix: "移到测试工具类里，或者改名为 `...ForDefaults`。",
  },
  {
    id: "DEAD-03",
    path: "dead",
    sev: "提示",
    title: "ModMenu API 用源码 shim 的方式放进了自己的源码树",
    where: "src/client/java/com/terraformersmc/modmenu/api/*",
    detail: [
      "打包时用 `exclude 'com/terraformersmc/**'` 把它剔掉了，产物里没有问题。但如果真实的 ModMenu API 签名变了（比如接口多了抽象方法），这里不会有编译期报错。",
    ],
    fix: "改成 `modCompileOnly \"com.terraformersmc:modmenu:<ver>\"`，并且和 JEI/REI 一样提供开关。",
  },

  // ───────── 耦合风险 ─────────
  {
    id: "COUP-01",
    path: "coupling",
    sev: "高",
    title: "“无限”的语义分裂成三处：免磨损看标签，抄错负载看硬编码 ID，获取限制也看硬编码 ID",
    where: "TomeWearData.hasWearImmunity（标签） vs InscriptionRitualMechanics.computeInfinityTomeQualificationLoad / isTreasureEnchantment / sanitizeVillagerInfinityOffers（ID）",
    detail: [
      "`MasterTomeWear.hasInfinityImmunity()` 名字里写着 Infinity，实际查的是 `#chiseled_enchanting_table:wear_immune` 标签。",
      "抄错负载 L 的计算是 `isInf = INFINITY_ENCHANTMENT_ID.equals(id)`，L 只在书上有 `minecraft:infinity` 时才不为 0。",
      "后果：数据包把其他附魔（比如经验修补）加进 wear_immune，那本书就获得永久免磨损，同时永远不会触发抄错，也不受村民交易和顿悟池的限制。设计里“免磨损的代价”就这样被绕开了。",
    ],
    fix: "收口成一个 `TomeTraits.isImmortal(stack)`，抄错判定、获取限制、退化上限都基于这同一个谓词；或者再加一个 `#overload_source` 标签，并要求它和 wear_immune 保持一致。",
  },
  {
    id: "COUP-02",
    path: "coupling",
    sev: "中",
    title: "母本选择顺序写死为“无限优先”，玩家没法选",
    where: "MasterTomeWear.CANDIDATE_ORDER",
    detail: [
      "排序是 `comparing(c -> !c.infinite())`。只要书架里有一本超载的无限书，所有它能支持的附魔都会走它，并承担抄错风险，旁边明明有普通母本也用不上。",
      "这本该是一个策略选择（拿磨损换风险），现在被硬塞给了玩家，唯一的规避办法是把无限书锁起来。",
    ],
    fix: "在行内加一个“优先普通 / 优先无限”的切换，或者默认先走普通母本，普通母本耗尽后才回退到无限母本。",
  },
  {
    id: "COUP-03",
    path: "coupling",
    sev: "中",
    title: "上帝类加上客户端/服务端双路径散落在几十处",
    where: "ScreenHandler 2887 行 · Data 2755 行 · Screen 1910 行",
    detail: [
      "handler 里大量出现 `world.isClientSide() ? SyncedEnchantmentCosts.x() : ChiseledEnchantingTableData.x()` 这种三元式。漏改任何一处，客户端显示和服务端结算就会不一致。",
      "mechanics.* 直接读写 handler 的 public 字段（比如 `handler.unlocked_enchantements`），所谓拆分只是换了文件，状态没有封装起来。",
    ],
    fix: "抽一个 `CostView` 接口，客户端和服务端各实现一份，handler 只持有这个接口；mechanics 通过不可变的快照拿数据。",
  },
  {
    id: "COUP-04",
    path: "coupling",
    sev: "低",
    title: "LOS 用 Math.round 取整，导致左右镜像不对称",
    where: "ChiseledEnchantingTableBlock.hasClearLineOfSight",
    detail: [
      "Java 的 `Math.round(-0.5) == 0` 而 `Math.round(0.5) == 1`。两个关于工作台对称的书架，射线经过的中间格子不一样，左右镜像的建筑可能一边计数、一边不计数（默认 LOS 关闭，开启后才会触发）。",
    ],
    fix: "改用 `Mth.floor(x + 0.5)` 并对称处理，或者直接用原版 `level.clip` 做射线检测。",
  },

  // ───────── 数值 / 机制 / 文档 ─────────
  {
    id: "DES-01",
    path: "design",
    sev: "高",
    title: "“无限贴纸”：书本目标不剔除冲突附魔，加上无限免磨损，可以零风险无限复制“无限”",
    where: "EnchantmentApplication / BlockEntity.completeActiveRitual 里的 `if (!targetWasBook)`；computeInfinityTomeQualificationLoad",
    detail: [
      "目标是书时，冲突附魔不会被移除，所以一本书可以同时带上无限、经验修补、各种保护、锋利/亡灵杀手/节肢杀手。",
      "一本只有“无限 I”的书，L = 0，抄错概率是 0%，磨损也是 0。从它复制“无限”可以无限次进行，没有任何风险。",
      "把“无限”贴到任意母本上，那本母本就永久免磨损。经验修补 + 无限这种两词条书，L 会被 `single_treasure_min_load` 抬到 3，抄错概率 = 0.035×0 + 书架加成。广义书架少于 32 个时，抄错概率就是 0%。",
      "代数衰减（generation fade）只会降低耐久上限，而免磨损的书根本不消耗耐久，所以对这条链完全无效。",
    ],
    fix: "见“怀疑与建议”页：例如从无限母本复制时不能复制“无限”本身，或者无限只能存在于代数为 0 的书上；抄错的底线不要绑在书架数上。",
  },
  {
    id: "DES-02",
    path: "design",
    sev: "高",
    title: "Wiki 和随附数据包的数值对不上",
    where: "docs/WIKI.md §3.2 vs library_resonance.json",
    detail: [
      "母本回生：Wiki 写 0 架 20 游戏日、37 架 15.2 游戏日、38 架 10 游戏日、42 架 3 游戏日、下限 1.5 游戏日。数据实际是 7200s / 约 5447s / 3600s / 1200s / 600s，即 6 / 4.5 / 3 / 1 / 0.5 游戏日，大约快了 3.3 倍。",
      "抄错上限：Wiki 写“严格封顶不超过 20%”，数据和代码都是 18%。",
      "超载条件：Wiki 写“无限 + 其他词条 > 3（单册 ≥ 5 词条）”，代码实际是“质量负载 L ≥ 3”。带任意一个宝藏附魔的无限书 L 至少是 3，两词条就满足。",
      "“原版附魔台随机附魔”被列为获得无限的途径，但默认 `vanilla_table_mode = books` 会禁止给书附魔。原版台只能产出带无限的弓，产不出无限母本。另外钓鱼宝藏这条途径没写。",
      "“游戏日”这个说法容易误解：代码算的是 gameTime tick，睡觉跳过夜晚不会让回生变快。",
    ],
    fix: "Wiki 里的数字要么由脚本根据 JSON 生成（仓库已经有 gen_bundled_defaults.py，可以照这个思路做），要么在 CI 里比对。",
  },
  {
    id: "DES-03",
    path: "design",
    sev: "中",
    title: "抄错概率很快就到顶，再往一本书上加词条没有额外代价",
    where: "computeLoadSlipProbability：P = min(18%, 0.035·(L−3) + 书架加成)",
    detail: [
      "书架加成 3% 时，L ≈ 7.3 就到 18% 封顶，大约是 5～6 个优质词条。一本 38 词条的“全都要”书，和一本 6 词条的无限书，抄错率完全一样。",
      "等待时间按“范围内所有母本的词条总数”计算，和这些词条是集中在一本书上还是分散在多本书上无关。所以没有任何机制在抑制“集中”。",
      "结论：真正的设计压力只落在“有没有无限”这一点上，“堆多少”几乎没有影响。下一页会展开讨论。",
    ],
    fix: "让上限也随 L 缓慢上升（比如软上限 `18% × (1 − e^{−L/k})` 再加一个随 L 增长的尾项），或者对单本书的词条数给出线性的等待时间惩罚。",
  },
  {
    id: "DES-04",
    path: "design",
    sev: "中",
    title: "强行跳过的退化对象可以用替罪羊书顶掉",
    where: "ScreenHandler 跳过逻辑 → degradeLowestPriorityMasterTomeInWorld / selectDegradationVictim",
    detail: [
      "跳过时退化“优先牺牲低等级、低词条、低稀有度”的母本。在书架里放一本节肢杀手 I，它就成了永远的替罪羊。",
      "因为用了无限书，退化概率上限被抬到 70%，但真正被砍的是别的书。风险的来源和承担风险的对象脱节了。",
      "能不能跳过只看“范围内有没有至少一本母本”，替罪羊书本身就满足这个条件。",
    ],
    fix: "退化对象应当是本次仪式实际用到的母本（快照里已经记录了 `chosenTomeSnapshot`），或者按本次使用的母本加权抽取。",
  },
  {
    id: "DES-05",
    path: "design",
    sev: "中",
    title: "野生书耐久权重在 max_tome_uses 调大后分布反转",
    where: "MasterTomeWear.rollWildRemainingCharges",
    detail: [
      "默认权重是 [45, 35, 15, 5]。超出列表长度的桶一律取 `max(1, last) = 5`。当 `max_tome_uses = 256` 时，第 5～256 桶各占权重 5，合计 1260，前 4 桶只有 100，所以约 92.6% 的野生书会拿到 ≥ 5 次耐久，和“野生书多半所剩无几”的设计意图正好相反。",
    ],
    fix: "把权重解释为相对剩余比例（按 maxUses 归一化分桶），或者超出列表的部分取 0。",
  },
  {
    id: "DES-06",
    path: "design",
    sev: "中",
    title: "回生速度在 38 和 42 架处有断崖",
    where: "MasterTomeWear.computeRegenIntervalTicks",
    detail: [
      "37 架 → 38 架：约 5447s 降到 3600s。41 架 → 42 架：2700s 降到 1200s，一步快了 2.25 倍。设计上叫“突破”，但 UI 和图鉴里没有明确告诉玩家“差 1 架”的代价。在 7×5×7 的扫描体积里，结果就是大家都去凑精确数字。",
      "超过 42 架后用 `tier2 / (1 + 0.05·excess)` 继续加速，下限是 `tier2/2`。这两个常量（0.05、/2）没有放进 JSON。",
    ],
    fix: "改成平滑曲线，或者在界面上显示“再放 N 架可获得 X 倍回生速度”。",
  },
  {
    id: "DES-07",
    path: "design",
    sev: "中",
    title: "“11 种语言”里大约 6 成条目没有翻译",
    where: "src/client/resources/assets/chiseled_enchanting_table/lang/*.json",
    detail: [
      "共 728 个键。de / es / fr / pt / ru 各有 443 条（长度 > 12 字符）和英文完全一样，it 446 条，ja 352 条，ko 373 条。",
      "zh_tw 大约有 195 条混入了简体字（例如 ritual_cancelled：“已取消儀式并保留输入物品…”）。",
      "术语不统一：lang 里“模板书”出现 83 次、“母本”11 次，Wiki 里“母本”出现 40 次。",
      "CI 的 lang parity 只检查键的数量，所以这些问题都能通过。",
    ],
    fix: "CI 里加一项“和 en_us 完全相同的比例”警告；zh_tw 用 OpenCC 跑一遍；定一份术语表。",
  },
  {
    id: "DES-08",
    path: "design",
    sev: "低",
    title: "“全都要”成就把所有已注册的非诅咒附魔都算进分母",
    where: "Advancement.checkBookMilestones",
    detail: [
      "装了模组之后，那些无法通过本模组获得的附魔也会被计入，成就可能永远拿不到。原版环境下没有问题。",
    ],
    fix: "分母改为“本模组可铭刻的附魔集合”（EnchantQueryIndex 里已经有了）。",
  },
];

export interface HardcodedItem {
  what: string;
  where: string;
  value: string;
  suggest: string;
}

export const HARDCODED: HardcodedItem[] = [
  { what: "高普适度附魔名单", where: "InscriptionRitualMechanics.HIGH_APPLICABILITY_IDS", value: "protection, sharpness, efficiency, fortune, looting, power, silk_touch, wind_burst, breach, density", suggest: "改成标签 #chiseled_enchanting_table:high_applicability" },
  { what: "无限 / 耐久 / 经验修补 ID", where: "TomeWearData / InscriptionRitualMechanics", value: "minecraft:infinity / unbreaking / mending", suggest: "和 wear_immune 一样改成标签（overload_source、wear_waiver）" },
  { what: "顿悟排除无限", where: "ScreenHandler.isTreasureEnchantment", value: "if (INFINITY_ID.equals(id)) return false", suggest: "已有 epiphany_exclusive 标签，再加一个 epiphany_excluded 即可" },
  { what: "重开界面的距离 / 节流", where: "EnchantingNetworking", value: "64.0D（8 格）/ 10 tick", suggest: "交互距离属性 + 配置项" },
  { what: "献祭 XP 曲线时间常数", where: "computeSacrificeXpLevels", value: "remSeconds / 240.0", suggest: "放进 ritual.sacrifice_curve" },
  { what: "强行跳过退化曲线", where: "computeRushDegradeChance", value: "/ 210.0，下限 cap × 0.02", suggest: "放进 ritual.rush_curve" },
  { what: "耐久豁免上限", where: "computeUnbreakingWaiverChance", value: "Math.min(0.30, cfg)", suggest: "配置写 >0.3 会被静默截断，属于“死配置”；要么去掉这个上限，要么在 JSON 校验里报错" },
  { what: "回生超额加速", where: "computeRegenIntervalTicks", value: "0.05·excess，下限 tier2/2，中点 0.5", suggest: "放进 chiseled_mastery.regen_curve" },
  { what: "村民交易替换", where: "sanitizeVillagerInfinityOffers", value: "Enchantments.POWER I", suggest: "可配置的替换附魔，或者直接移除这条交易" },
  { what: "背包槽数", where: "InventoryUtils.insertItem", value: "36", suggest: "用 placeItemBackInInventory" },
  { what: "冻结 / 重抽兜底费用", where: "ChiseledEnchantingTableData ≈2237–2254", value: "packed_ice×16, blue_ice×4, lapis×16, emerald×14 …", suggest: "JSON 缺失时应报错，而不是在 Java 里再写一套默认值（和 BundledDefaults 的单一事实源原则矛盾）" },
  { what: "宝藏默认费用", where: "treasure_epiphany 解析", value: "diamond×8，25 级", suggest: "同上" },
  { what: "图腾转换特判", where: "ChiseledEnchantingTableData ≈1655", value: "adventure/totem_of_undying", suggest: "改为转换配方里的 required_advancement 字段（该字段已经存在）" },
  { what: "书架命中槽位", where: "TomeLockGuards.hitSlot", value: "0.375 / 0.6875", suggest: "调用原版的方法" },
  { what: "协议常量", where: "Payloads", value: "> 256（仪式步数、母本耐久）", suggest: "统一引用 PayloadLimits，并和 ConfigCatalog 的 1..256 绑定" },
  { what: "野生权重外推", where: "rollWildRemainingCharges", value: "max(1, last)", suggest: "按比例归一化" },
];

export interface DriftRow {
  item: string;
  wiki: string;
  data: string;
}

export const DRIFT: DriftRow[] = [
  { item: "回生 · 0 广义书架", wiki: "20 游戏日 / +1", data: "7200 s = 6 游戏日" },
  { item: "回生 · 37 架", wiki: "15.2 游戏日", data: "≈5447 s ≈ 4.5 游戏日" },
  { item: "回生 · 38 架（一档）", wiki: "10 游戏日 (12,000 s)", data: "3600 s = 3 游戏日" },
  { item: "回生 · 42 架（二档）", wiki: "3 游戏日 (3,600 s)", data: "1200 s = 1 游戏日" },
  { item: "回生 · 下限", wiki: "1.5 游戏日", data: "600 s = 0.5 游戏日" },
  { item: "抄错上限", wiki: "≤ 20%", data: "18%（max_transcription_slip_chance / crossline.max_slip_chance）" },
  { item: "超载触发", wiki: "无限 + 其他词条 > 3（≥5 词条）", data: "质量负载 L ≥ 3；含任一宝藏 → L ≥ 3（2 词条即可）" },
  { item: "无限获取途径", wiki: "战利品 / 原版台随机 / 复制", data: "默认 books 模式下原版台不能给书附魔；钓鱼宝藏未提及" },
];
