import type { ReactNode } from "react";
import { cn } from "../utils/cn";

export type Severity = "严重" | "高" | "中" | "低" | "提示";

const sevStyle: Record<Severity, string> = {
  严重: "bg-red-500/20 text-red-300 ring-red-500/40",
  高: "bg-orange-500/20 text-orange-300 ring-orange-500/40",
  中: "bg-amber-400/15 text-amber-200 ring-amber-400/40",
  低: "bg-sky-500/15 text-sky-200 ring-sky-500/40",
  提示: "bg-zinc-500/20 text-zinc-300 ring-zinc-500/40",
};

export function SevBadge({ s }: { s: Severity }) {
  return (
    <span className={cn("inline-flex items-center rounded-md px-2 py-0.5 text-xs font-semibold ring-1", sevStyle[s])}>
      {s}
    </span>
  );
}

export function Tag({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span className={cn("inline-flex items-center rounded-full bg-violet-500/15 px-2.5 py-0.5 text-xs text-violet-200 ring-1 ring-violet-400/30", className)}>
      {children}
    </span>
  );
}

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn("rounded-2xl border border-white/10 bg-white/[0.035] p-5 shadow-lg shadow-black/20 backdrop-blur", className)}>
      {children}
    </div>
  );
}

export function SectionTitle({ id, kicker, title, desc }: { id?: string; kicker?: string; title: string; desc?: ReactNode }) {
  return (
    <div id={id} className="mb-5 scroll-mt-24">
      {kicker && <div className="mb-1 text-xs font-semibold uppercase tracking-[0.2em] text-teal-300/80">{kicker}</div>}
      <h2 className="text-2xl font-bold text-white md:text-3xl">{title}</h2>
      {desc && <div className="mt-2 max-w-3xl text-sm leading-7 text-zinc-400">{desc}</div>}
    </div>
  );
}

export function CodeBlock({ children }: { children: string }) {
  return (
    <pre className="mt-3 overflow-x-auto rounded-xl border border-white/10 bg-black/50 p-3 font-mono text-[12.5px] leading-6 text-zinc-200">
      <code>{children}</code>
    </pre>
  );
}

export function Callout({ tone = "violet", title, children }: { tone?: "violet" | "teal" | "amber" | "red"; title?: string; children: ReactNode }) {
  const tones = {
    violet: "border-violet-400/40 bg-violet-500/10",
    teal: "border-teal-400/40 bg-teal-500/10",
    amber: "border-amber-400/40 bg-amber-500/10",
    red: "border-red-400/40 bg-red-500/10",
  };
  return (
    <div className={cn("rounded-xl border-l-4 p-4 text-sm leading-7", tones[tone])}>
      {title && <div className="mb-1 font-semibold text-white">{title}</div>}
      <div className="text-zinc-300">{children}</div>
    </div>
  );
}

/** Renders text where `backticks` become inline code. */
export function Rich({ text }: { text: string }) {
  const parts = text.split(/(`[^`]+`)/g);
  return (
    <>
      {parts.map((p, i) =>
        p.startsWith("`") && p.endsWith("`") ? (
          <code key={i} className="inl">
            {p.slice(1, -1)}
          </code>
        ) : (
          <span key={i}>{p}</span>
        )
      )}
    </>
  );
}
