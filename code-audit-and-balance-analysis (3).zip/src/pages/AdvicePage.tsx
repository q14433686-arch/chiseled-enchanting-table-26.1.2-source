import { Callout, Card, SectionTitle, Rich } from "../components/ui";

const DOUBTS: { t: string; b: string[] }[] = [
  {
    t: "复杂度是不是已经超过玩家能感知的程度了？",
    b: [
      "四种书架概念（W / E / C / S广义）、三种经验徽章、两段减免叠加、三分支抄错、两种跳过方式、代数衰减、锁定页、残卷四档、宝藏顿悟冻结和重抽……Wiki 要靠 LaTeX 公式才能讲清楚，这本身就说明问题。",
      "玩家感知不到的机制，平衡得再好也等于没有，玩家只会觉得“随机”或者“被坑”。尤其是抄错、退化这类惩罚，如果玩家事先没理解，体验上就是“模组坑我”。",
    ],
  },
  {
    t: "数值是纸面推导出来的，还是实际玩出来的？",
    b: [
      "仓库里有大量 `Audit H-06`、`Iron Rule #2`、`docs/reports/*`、`CURRENT_AGENT_BRIEF.md`、`NEXT_TASK.md`。README 也承认开发沙箱无法编译，要靠 CI 回传日志。测试几乎都是无头数学测试（守恒、上下限）。",
      "这很严谨，但证明的是公式自洽，不是好玩。38 / 42 / 18% / 70% 这些数字找不到实测依据。Wiki 和数据对不上（回生差 3.3 倍）也说明文档没有跟着实际游玩一起校对。",
    ],
  },
  {
    t: "这还算“移植”吗？",
    b: [
      "上游的核心思路很简单：雕纹书架里放什么书，就能附什么魔。1.1.0 已经是一次大规模重做，经济、仪式、回生、抄错、村民、世界生成全都加进来了。",
      "mod id 仍然是 `chiseled-enchanting-table`。用户如果冲着上游的口碑来装，看到的是完全不同的东西，存档之间还会互相读到对方的数据（CUSTOM_DATA 键、方块实体字段）。建议在名字和简介里写明“重制 / 扩展版”，或者干脆换一个 mod id。",
    ],
  },
  {
    t: "限制是围绕一个核心目标设计的，还是一个个补丁叠出来的？",
    b: [
      "抄错、等待、退化、代数衰减、锁定，这些看起来都是在发现漏洞之后各自补上的，彼此之间没有统一的经济模型。所以会出现“超级书付全价、小无限书零成本”“替罪羊书挡掉退化”这种互相抵消的情况。",
      "比较健康的做法是先定一个总量守恒的目标，比如“单位时间内每种附魔的产出上限”，再让所有限制都服务于这个目标。",
    ],
  },
  {
    t: "服务器能扛得住吗？",
    b: [
      "每个打开界面的玩家每秒做一次全量书架扫描，并且大家挤在同一个 tick；村民每次调用 `getOffers` 都会走一遍净化；结构里生成的所有装书雕纹书架都在随机刻里；区块卸载时要遍历全部回生条目。单人存档感觉不到，到了几十人的生存服就可能成为热点。",
    ],
  },
];

const SUGGEST: { pri: string; tone: string; items: { t: string; d: string }[] }[] = [
  {
    pri: "P0 · 先修的",
    tone: "border-red-400/50",
    items: [
      { t: "堵住“无限贴纸”", d: "三选一或组合使用：①从无限母本拓印时，「无限」这个词条本身不可复制（拿到无限只能靠探索）；②无限只能存在于 generation = 0 的书上，拓出来的副本自动去掉无限；③抄错设一个和书架数无关的底线：`p ≥ 2% + 0.5% × 词条数`。" },
      { t: "锁定守卫改成精准注入", d: "直接注入 `ChiseledBookShelfBlockEntity#removeItem` / `canTakeItem`，不要碰全局的 ContainerHelper；注入失败时启动阶段打 WARN；`locked_shelf_breakable` 为 true 时，挖掉书架自动解锁，不要让锁跟着书走。" },
      { t: "附魔书堆叠数做握手校验", d: "玩家加入时比对 `enchanted_book_stack_size`，不一致就拒绝连接并提示。" },
      { t: "收口“无限”的语义", d: "免磨损、抄错、获取限制、退化上限，统一由同一个谓词（或同一组标签）决定。" },
      { t: "Wiki 数字由数据生成", d: "照 `gen_bundled_defaults.py` 的思路，生成 Wiki 里的数值表，CI 里比对；同时修掉 20 vs 18%、回生天数、超载条件这三处错误。" },
    ],
  },
  {
    pri: "P1 · 机制调整",
    tone: "border-amber-400/50",
    items: [
      { t: "抄错上限随规模软增长", d: "比如 `p = min(30%, 18% × (1 − e^{−(L−3)/4}) + 0.25% × max(0, n − 8))`，让堆满比堆一半有实际代价，超级书依然可做，但付的是累进价。" },
      { t: "退化对象绑定本次实际用到的母本", d: "`chosenTomeSnapshot` 已经记录了，直接用它，或者按本次使用次数加权抽取，替罪羊书就失效了。" },
      { t: "“无限优先”交给玩家选", d: "行内加一个切换，默认优先普通母本，普通母本耗尽后才回退到无限母本。" },
      { t: "取消仪式时退款", d: "队列里已经存了 `paidXpPoints` / `paidItems`，原样退还；磨损改到完成时再结算。" },
      { t: "回生断崖要么平滑，要么在 UI 上明示", d: "界面上显示“再放 N 架 → 回生 ×2.25”，让玩家知道断崖在哪，而不是靠猜。" },
      { t: "野生书耐久按比例分桶", d: "`max_tome_uses` 改动后，权重按 maxUses 等比例展开。" },
    ],
  },
  {
    pri: "P2 · 工程质量",
    tone: "border-teal-400/50",
    items: [
      { t: "硬编码改成标签和 JSON", d: "`HIGH_APPLICABILITY_IDS`、献祭 / 跳过曲线常数、回生超额常数、0.30 耐久豁免上限、力量 I 替换、Java 里的兜底费用。JSON 缺字段时应该报错，不应该悄悄用 Java 里另一套默认值。" },
      { t: "拆分上帝类", d: "抽出 `CostView`（客户端 / 服务端各实现一份）、`ShelfScanSnapshot`（同一 tick 内缓存）、`RitualQueue`（Codec 序列化）。mechanics 只依赖不可变快照，不再碰 handler 的字段。" },
      { t: "持久化改到正确的位置", d: "磨损和代数注册成 DataComponent；回生进度存进 SavedData，按区块建索引。" },
      { t: "网络和输入", d: "按 containerId 错开扫描 tick，书架内容哈希不变就不推送；回车加冷却并忽略 key-repeat；Reopen 使用交互距离属性。" },
      { t: "删除死代码，CI 加检查", d: "删掉约 32 个疑似没有调用方的方法，只给测试用的重载移到 test 工具类；CI 加 unused 检查、“和 en_us 完全相同”的比例告警、zh_tw 繁简检查。" },
    ],
  },
  {
    pri: "P3 · 体验",
    tone: "border-violet-400/50",
    items: [
      { t: "提供“简洁模式”预设", d: "一键关掉抄错、等待、回生、锁定页，只保留上游的核心玩法（书架有书 → 能附魔），复杂机制留给想折腾的服主。" },
      { t: "界面内置计算器", d: "鼠标悬停母本时直接显示“本次抄错率 / 期望返修 / 回生时间”。本站第二页就是这种计算器的原型。" },
      { t: "统一术语", d: "在“模板书”和“母本”中选一个（lang 里“模板书”出现 83 次、“母本”11 次；Wiki 里“母本”40 次），全仓库替换。" },
      { t: "补齐机翻空缺", d: "de / es / fr / it / pt / ru 大约 61% 是英文原文。宁可少支持几种语言，也不要标称 11 种语言实际一半是英文。" },
    ],
  },
];

export default function AdvicePage() {
  return (
    <div className="space-y-14">
      <section>
        <div className="text-xs font-semibold uppercase tracking-[0.2em] text-teal-300/80">Doubts & Advice</div>
        <h1 className="mt-2 text-3xl font-black text-white md:text-4xl">中肯的怀疑与建议</h1>
        <p className="mt-4 max-w-3xl text-sm leading-7 text-zinc-400">
          先说清楚立场：这个移植版在工程纪律上明显高于一般的社区移植（载荷上限、XP 守恒证明、worldgen 死锁修复、CI 三件套、可选 JEI/REI）。下面的怀疑针对的是方向和取舍，不是在否定作者的投入。
        </p>
      </section>

      <section>
        <SectionTitle kicker="怀疑" title="五个值得作者正面回答的问题" />
        <div className="grid gap-4 md:grid-cols-2">
          {DOUBTS.map((d, i) => (
            <Card key={d.t} className={i === 0 ? "md:col-span-2" : ""}>
              <div className="flex items-start gap-3">
                <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-violet-500/20 text-sm font-bold text-violet-200">
                  {i + 1}
                </span>
                <div>
                  <div className="font-semibold text-white">{d.t}</div>
                  <div className="mt-2 space-y-2 text-sm leading-7 text-zinc-400">
                    {d.b.map((x, j) => (
                      <p key={j}>
                        <Rich text={x} />
                      </p>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <SectionTitle kicker="建议" title="按优先级排列的改进清单" desc="P0 影响正确性或会被利用；P1 影响平衡；P2 影响可维护性和性能；P3 影响上手门槛。" />
        <div className="space-y-6">
          {SUGGEST.map((g) => (
            <div key={g.pri}>
              <div className="mb-3 text-lg font-bold text-white">{g.pri}</div>
              <div className="grid gap-3 md:grid-cols-2">
                {g.items.map((it) => (
                  <div key={it.t} className={`rounded-xl border-l-4 ${g.tone} bg-white/[0.035] p-4`}>
                    <div className="font-semibold text-white">{it.t}</div>
                    <div className="mt-1.5 text-sm leading-7 text-zinc-400">
                      <Rich text={it.d} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionTitle kicker="验证" title="建议补上的实机验证清单" />
        <Card>
          <ol className="list-decimal space-y-2 pl-5 text-sm leading-7 text-zinc-300">
            <li>漏斗接在装有锁定书的雕纹书架下方，看锁定书会不会被抽走（验证 MIX-01）。</li>
            <li>客户端 stack_size = 1、服务端 = 64，Shift 点击和拖拽附魔书（NET-01）。</li>
            <li>在 4.5～8 格距离发送 Reopen（API-01），观察界面是否闪一下就关掉。</li>
            <li>只放一本「无限 I」、不足 32 架：从它复制「无限」到 20 本书上，确认 0 抄错、0 磨损（DES-01）。</li>
            <li>放一本节肢杀手 I + 超级书，重复强行跳过 50 次，统计被退化的是哪一本（DES-04）。</li>
            <li>按住回车 2 秒，看仪式队列里排进了几步（GUI-01）。</li>
            <li>20 名玩家同时打开界面，用 spark 采样 <code className="inl">refreshLiveShelfState</code> 的耗时（NET-02）。</li>
            <li>回档测试：在两次自动保存之间消耗母本耐久，然后强制崩溃，对比回生 JSON 和书本 NBT（COD-02）。</li>
          </ol>
        </Card>
        <div className="mt-5">
          <Callout tone="violet" title="一句话总结">
            代码写得比大多数移植严谨，但设计上有些贪多。下一步最值得做的不是再加新机制，而是砍掉一部分、把剩下的统一到同一个经济目标下，然后真正去玩一遍。
          </Callout>
        </div>
      </section>
    </div>
  );
}
