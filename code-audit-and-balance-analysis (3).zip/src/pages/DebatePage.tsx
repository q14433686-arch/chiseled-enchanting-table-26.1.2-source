import { useMemo, useState } from "react";
import { Callout, Card, SectionTitle } from "../components/ui";
import { regenSeconds, slipProbability, SLIP_SPLIT, waitSeconds } from "../lib/formulas";

const PRESETS = [
  { label: "纯「无限 I」", L: 0, n: 1, note: "只带无限一个词条" },
  { label: "无限 + 经验修补", L: 3, n: 2, note: "宝藏附魔把 L 抬到 single_treasure_min_load = 3" },
  { label: "无限 + 4 个满级常用词条", L: 6.5, n: 5, note: "Wiki 所说的“超载”起点" },
  { label: "无限 + 8 个高质量词条", L: 11, n: 9, note: "此时已顶到上限" },
  { label: "「全都要」超级书", L: 40, n: 39, note: "原版大约 38 个非诅咒附魔全部堆上" },
];

const pct = (x: number, d = 1) => `${(x * 100).toFixed(d)}%`;
const days = (s: number) => `${(s / 1200).toFixed(2)} 游戏日`;

export default function DebatePage() {
  const [L, setL] = useState(11);
  const [shelves, setShelves] = useState(42);
  const [k, setK] = useState(6);

  const p = slipProbability(L, shelves);
  const clean = Math.pow(1 - p, k);
  const expDrops = k * p * SLIP_SPLIT.drop;
  const expJunk = k * p * SLIP_SPLIT.junk;
  const expCurse = k * p * SLIP_SPLIT.curse;
  const regen = regenSeconds(shelves);

  const table = useMemo(
    () =>
      PRESETS.map((pr) => {
        const pp = slipProbability(pr.L, shelves);
        return { ...pr, p: pp, clean: Math.pow(1 - pp, k), wait: waitSeconds(shelves, pr.n) };
      }),
    [shelves, k]
  );

  return (
    <div className="space-y-14">
      <section>
        <div className="text-xs font-semibold uppercase tracking-[0.2em] text-teal-300/80">Debate</div>
        <h1 className="mt-2 text-3xl font-black text-white md:text-4xl">
          “给了大增益又加限制，不是自相矛盾吗？”
          <br />
          <span className="text-violet-300">“我只做一本包含「无限」的超级书，岂不是赚麻了？”</span>
        </h1>
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <Card>
            <div className="text-sm font-semibold text-red-200">论调 A：矛盾论</div>
            <p className="mt-2 text-sm leading-7 text-zinc-300">
              “无限”让模板书免磨损，周围书架多给折扣和回生，模板书本身能直接附魔。增益都给到这份上了，为什么还要对单本模板书、书架数量、“无限”设各种上限、抄错和等待？一边给一边收，这不是左右手互搏吗？
            </p>
          </Card>
          <Card>
            <div className="text-sm font-semibold text-red-200">论调 B：超级书论</div>
            <p className="mt-2 text-sm leading-7 text-zinc-300">
              既然“无限”书拓印不掉耐久，那就把所有附魔都堆到一本“无限”书上，一格书架解决一切，永久免费量产。限制形同虚设。
            </p>
          </Card>
        </div>
      </section>

      <section>
        <SectionTitle kicker="短答" title="我的看法：A 在原则上不成立；B 说对了一半，但对的不是他以为的那一半" />
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <div className="text-3xl">⚖️</div>
            <div className="mt-2 font-semibold text-white">增益和限制管的是不同的东西</div>
            <p className="mt-2 text-sm leading-7 text-zinc-400">
              增益决定上限能到哪里，限制决定代价怎么增长。两者同时存在，强力选项才是一种取舍，而不是唯一解。这在游戏设计里是常态，谈不上矛盾。
            </p>
          </Card>
          <Card>
            <div className="text-3xl">📕</div>
            <div className="mt-2 font-semibold text-white">超级书是官方默许的终局目标</div>
            <p className="mt-2 text-sm leading-7 text-zinc-400">
              上游 TODO 里专门写了“给一本书加上所有附魔”的成就，仓库里对应的是挑战成就「全都要」(<code className="inl">all_enchant_book</code>)，还有「无尽拓本」。做出来本来就是设计的一部分。
            </p>
          </Card>
          <Card>
            <div className="text-3xl">🕳️</div>
            <div className="mt-2 font-semibold text-white">真正的漏洞是“小而纯”的无限书</div>
            <p className="mt-2 text-sm leading-7 text-zinc-400">
              按现在的数值，超级书反而要承担最高 18% 的抄错率。“纯无限 I”和“无限 + 一个宝藏附魔”这类书在少于 32 架时抄错率是 0%，免磨损的代价完全没收到。
            </p>
          </Card>
        </div>
      </section>

      <section>
        <SectionTitle
          kicker="A · 矛盾论"
          title="为什么“既给又收”不矛盾"
          desc="先看清每一个增益和每一个限制分别作用在哪一项资源上。"
        />
        <div className="overflow-x-auto rounded-2xl border border-white/10">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead className="bg-white/5 text-xs uppercase tracking-wider text-zinc-400">
              <tr>
                <th className="px-4 py-3">系统</th>
                <th className="px-4 py-3">给了什么</th>
                <th className="px-4 py-3">收了什么</th>
                <th className="px-4 py-3">作用的资源</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-zinc-300">
              <tr>
                <td className="px-4 py-3 font-medium text-white">普通书架 W</td>
                <td className="px-4 py-3">升级档位 0→38、最高 −15% 经验、32 架开启宝藏顿悟</td>
                <td className="px-4 py-3">需要空间、需要预留呼吸空间</td>
                <td className="px-4 py-3">基地空间 / 建造投入（一次性）</td>
              </tr>
              <tr>
                <td className="px-4 py-3 font-medium text-white">雕纹模板书</td>
                <td className="px-4 py-3">白板直附到书上的等级，进入 1～3 级绿色量产模式</td>
                <td className="px-4 py-3">每级 4 点耐久，拓到书上扣 2；耗尽降一级</td>
                <td className="px-4 py-3">消耗品（流量）</td>
              </tr>
              <tr>
                <td className="px-4 py-3 font-medium text-white">广义书架 S（回生）</td>
                <td className="px-4 py-3">38 / 42 架回生明显加快</td>
                <td className="px-4 py-3">≥32 架开始有铭刻等待</td>
                <td className="px-4 py-3">时间（耐久恢复 vs 单次操作的延迟）</td>
              </tr>
              <tr>
                <td className="px-4 py-3 font-medium text-white">「无限」模板书</td>
                <td className="px-4 py-3">耐久消耗为 0</td>
                <td className="px-4 py-3">抄错风险 ≤18%，强行跳过时退化上限升到 70%，获取途径受限</td>
                <td className="px-4 py-3">风险（把确定的消耗换成概率性的损失）</td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="mt-5 grid gap-4 md:grid-cols-2">
          <Callout tone="teal" title="1. 增益在一个维度上，限制在另一个维度上">
            “无限”去掉的是耐久消耗，加上的是抄错风险。这不是先给后收，而是换了一种付费方式：从“每次必付一点”变成“偶尔付一大笔”。
            原版也是这个思路：弓上的无限和经验修补互斥，选了“不耗箭”就放弃“自修复”。
          </Callout>
          <Callout tone="teal" title="2. 没有限制的大增益会变成唯一解">
            如果“无限”零代价，最优策略就只剩“找一本无限书然后什么都往上堆”，书架布局、母本管理、回生节奏这些系统全都失去意义。
            限制的作用是让这些系统还有存在的价值，而不是为了刁难玩家。
          </Callout>
          <Callout tone="teal" title="3. 对数量设门槛，是为了让投入有回报">
            12 / 32 / 38 / 42 这些里程碑，本质是告诉玩家“建得越大越强，但边际收益递减”。和原版附魔台 15 个书架封顶是同一类设计。
          </Callout>
          <Callout tone="amber" title="4. 但矛盾论的直觉也不全错">
            限制该不该有，答案是该。问题在于限制有没有放对位置。现在有三处放偏了：
            抄错上限到得太快，堆满和堆一半代价一样（DES-03）；强行跳过时退化砍的是替罪羊书（DES-04）；无限优先是强制的，玩家没得选（COUP-02）。
            这些会让玩家觉得“限制是随手加的”，进而怀疑整套设计。
          </Callout>
        </div>
      </section>

      <section>
        <SectionTitle
          kicker="B · 超级书论"
          title="算一算：超级书到底赚不赚"
          desc="下面的公式直接照抄仓库里的 computeLoadSlipProbability、computeRegenIntervalTicks、computeSingleEnchantWaitTicks，参数用随附数据包的默认值。"
        />
        <Card>
          <div className="grid gap-6 md:grid-cols-3">
            <Slider label="模板书质量负载 L" value={L} min={0} max={40} step={0.5} onChange={setL} hint="宝藏 +1；稀有度权重 ≤2 +1；适用物品 ≥12 +0.5；等级比 ≥0.6 +0.5；耐久 ≥III +1" />
            <Slider label="广义书架数 S" value={shelves} min={0} max={60} step={1} onChange={setShelves} hint="32 / 38 / 42 处抄错 +1% / +2% / +3%" />
            <Slider label="一件装备的附魔数 k" value={k} min={1} max={10} step={1} onChange={setK} hint="一件满配胸甲大约 5～6 个" />
          </div>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="单步抄错概率" value={pct(p)} sub={L < 3 ? "L < 3，完全不触发" : p >= 0.18 ? "已到 18% 上限" : "未到上限"} />
            <Stat label={`${k} 个附魔全部无误`} value={pct(clean)} sub="(1 − p)^k" />
            <Stat
              label="期望损失 / 件"
              value={`${expDrops.toFixed(2)} 降级`}
              sub={`${expJunk.toFixed(2)} 串行垃圾词条 · ${expCurse.toFixed(3)} 诅咒`}
            />
            <Stat label="普通母本回生 +1" value={days(regen)} sub={`${Math.round(regen)} s（无限书不需要回生）`} />
          </div>
        </Card>

        <div className="mt-5 overflow-x-auto rounded-2xl border border-white/10">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead className="bg-white/5 text-xs uppercase tracking-wider text-zinc-400">
              <tr>
                <th className="px-4 py-3">无限书类型（S = {shelves}，k = {k}）</th>
                <th className="px-4 py-3">L</th>
                <th className="px-4 py-3">抄错 / 步</th>
                <th className="px-4 py-3">整件无误</th>
                <th className="px-4 py-3">单步等待（满级）</th>
                <th className="px-4 py-3">评价</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-zinc-300">
              {table.map((r) => (
                <tr key={r.label} className="hover:bg-white/[0.03]">
                  <td className="px-4 py-3">
                    <div className="font-medium text-white">{r.label}</div>
                    <div className="text-xs text-zinc-500">{r.note}</div>
                  </td>
                  <td className="px-4 py-3 font-mono">{r.L}</td>
                  <td className="px-4 py-3 font-mono">{pct(r.p)}</td>
                  <td className="px-4 py-3 font-mono">{pct(r.clean)}</td>
                  <td className="px-4 py-3 font-mono">{r.wait ? `${Math.round(r.wait)} s` : "无"}</td>
                  <td className="px-4 py-3 text-xs">
                    {r.p === 0 ? (
                      <span className="text-red-300">零风险、零磨损 → 有漏洞</span>
                    ) : r.p >= 0.18 ? (
                      <span className="text-amber-200">已到上限，继续堆词条没有额外代价</span>
                    ) : (
                      <span className="text-teal-200">代价随规模增长</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-xs text-zinc-500">
          等待时间按“范围内母本词条总数”计算：这里假设书架上只有这一本书。等待只在 S ≥ 32 或母本词条总数 ≥ 10 时出现，单个附魔最多 300 s，多个附魔的等待会叠加。
        </p>

        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <Card>
            <div className="font-semibold text-white">超级书确实很强的地方</div>
            <ul className="mt-3 list-disc space-y-2 pl-5 text-sm leading-7 text-zinc-300">
              <li>永不磨损，不用管回生，一格书架顶几十格。</li>
              <li>“全局藏书减免”按去重后的附魔算，一本书就能把 −20% 拿满；残卷“阶段三全免”需要 H ≥ 6 种高阶附魔，一本书也能满足。</li>
              <li>做量产（给一整队人配装、批量铭刻书）时，超级书在吞吐量上碾压普通模板书。</li>
            </ul>
          </Card>
          <Card>
            <div className="font-semibold text-white">超级书并不白给的地方</div>
            <ul className="mt-3 list-disc space-y-2 pl-5 text-sm leading-7 text-zinc-300">
              <li>
                以 k = 6 计，每件装备只有约 <b className="text-white">{pct(Math.pow(0.82, 6), 0)}</b> 的概率全部无误；平均每件要返修 0.76 级，每 10 件里大约 1 件会被串上诅咒（期望 0.054 个/件），需要净化。
              </li>
              <li>因为无限优先，超级书会强制接管所有它覆盖的附魔，想为一件珍贵装备走零风险的普通母本，就得先把它锁起来。</li>
              <li>制作过程本身很贵：每个附魔都要先解锁到满级，再拓到书上（拓印消耗来源母本 2 点耐久），并且要付经验和材料，母本词条数 ≥10 后每一步都要等待。</li>
              <li>“无限”本身获取受限：要从结构藏书或战利品里拿到第一本（默认配置下原版附魔台不能给书附魔）。</li>
            </ul>
          </Card>
        </div>

        <div className="mt-6">
          <Callout tone="red" title="B 真正说中的地方，不在超级书上">
            按当前实现，比超级书更“赚麻了”的是这条链：
            <ol className="mt-2 list-decimal space-y-1 pl-5">
              <li>拿到一本「无限 I」（L = 0，抄错 0%，磨损 0）；</li>
              <li>从它往空书上无限次复制「无限」，没有任何风险；</li>
              <li>书本目标不会剔除冲突附魔，所以可以把「无限」贴到任何一本母本上，那本母本就永久免磨损；</li>
              <li>双词条书 L 最多是 3，在少于 32 个广义书架时抄错率 = 0%。</li>
            </ol>
            代数衰减只会削减耐久上限，对免磨损的书不起作用。结果是：“小而纯”的无限书全都绕开了代价，只有“大而全”的超级书在付代价。
            这才是数值上真正的矛盾，而且方向和论调 A 说的正好相反。
          </Callout>
        </div>
      </section>

      <section>
        <SectionTitle kicker="结论" title="怎么回应这两种说法" />
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <div className="text-sm font-semibold text-violet-200">对论调 A</div>
            <p className="mt-2 text-sm leading-7 text-zinc-300">
              “给大增益再加限制”不叫矛盾，而是把强力选项变成一种取舍。“无限”拿掉的是磨损，换来的是风险；书架给的是规模收益，代价是空间和等待。
              这套设计的毛病不在于有限制，而在于有几项限制放错了位置，或者很快就到顶了。真正该讨论的是“这个限制收到代价了没有”。
            </p>
          </Card>
          <Card>
            <div className="text-sm font-semibold text-violet-200">对论调 B</div>
            <p className="mt-2 text-sm leading-7 text-zinc-300">
              可以做，而且官方就希望你去做（「全都要」成就）。它在量产上确实赚，但对单件精品来说并不比普通母本好，每件装备大约 7 成概率要返修。
              真正白赚的是只带“无限”或者“无限 + 一个宝藏”的小书。这是一个需要修补的漏洞，具体方案见下一页。
            </p>
          </Card>
        </div>
      </section>
    </div>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step,
  onChange,
  hint,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  hint?: string;
}) {
  return (
    <label className="block">
      <div className="flex items-baseline justify-between text-sm">
        <span className="text-zinc-300">{label}</span>
        <span className="font-mono text-lg font-bold text-white">{value}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-2 w-full accent-violet-400"
      />
      {hint && <div className="mt-1 text-[11px] leading-5 text-zinc-500">{hint}</div>}
    </label>
  );
}

function Stat({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return (
    <div className="rounded-xl bg-black/30 p-4 ring-1 ring-white/5">
      <div className="text-xs text-zinc-400">{label}</div>
      <div className="mt-1 text-2xl font-bold text-white">{value}</div>
      {sub && <div className="mt-1 text-[11px] text-zinc-500">{sub}</div>}
    </div>
  );
}
