import { useMemo, useState } from "react";
import { Card, CodeBlock, SectionTitle, SevBadge, Rich, Callout, type Severity } from "../components/ui";
import { DRIFT, FINDINGS, HARDCODED, PATHS, type PathKey } from "../data/audit";
import { cn } from "../utils/cn";

const SEVS: Severity[] = ["严重", "高", "中", "低", "提示"];

export default function AuditPage() {
  const [path, setPath] = useState<PathKey | "all">("all");
  const [sev, setSev] = useState<Severity | "all">("all");
  const [open, setOpen] = useState<Record<string, boolean>>({});

  const list = useMemo(
    () => FINDINGS.filter((f) => (path === "all" || f.path === path) && (sev === "all" || f.sev === sev)),
    [path, sev]
  );

  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const f of FINDINGS) c[f.sev] = (c[f.sev] ?? 0) + 1;
    return c;
  }, []);

  return (
    <div className="space-y-16">
      {/* Overview */}
      <section>
        <div className="grid gap-4 md:grid-cols-[1.4fr_1fr]">
          <Card>
            <div className="text-xs font-semibold uppercase tracking-[0.2em] text-teal-300/80">审计范围</div>
            <h1 className="mt-2 text-3xl font-black leading-tight text-white md:text-4xl">
              纂刻附魔台 <span className="text-violet-300">26.1.2</span> 非官方移植版
              <br />
              七条路径重新审计
            </h1>
            <p className="mt-4 text-sm leading-7 text-zinc-400">
              对象：<code className="inl">q14433686-arch/chiseled-enchanting-table-26.1.2-source</code> 分支{" "}
              <code className="inl">arena/2d61e52c-…</code>，提交 <code className="inl">bd61ca2</code>（2026-10-24），mod 版本 1.1.0，
              Fabric Loader 0.19.3 / Fabric API 0.151.0+26.1.2。共约 37.5k 行 Java（112 个文件）。
            </p>
            <p className="mt-2 text-sm leading-7 text-zinc-400">
              方法：克隆后逐文件静态阅读，结合 grep/正则扫描（未引用方法、硬编码 ID、语言文件比对），再和 WIKI、JSON 数据包逐项对账。
              <span className="text-amber-200">没有编译，也没有进游戏实测</span>，标了「需验证」的条目要反编译 26.1.2 或实机确认。
            </p>
          </Card>
          <Card className="flex flex-col justify-between">
            <div className="text-xs font-semibold uppercase tracking-[0.2em] text-teal-300/80">发现概况</div>
            <div className="mt-3 grid grid-cols-2 gap-3">
              {SEVS.filter((s) => counts[s]).map((s) => (
                <div key={s} className="rounded-xl bg-black/30 p-3">
                  <SevBadge s={s} />
                  <div className="mt-1 text-3xl font-bold text-white">{counts[s]}</div>
                </div>
              ))}
              <div className="rounded-xl bg-black/30 p-3">
                <span className="text-xs text-zinc-400">硬编码点</span>
                <div className="mt-1 text-3xl font-bold text-white">{HARDCODED.length}</div>
              </div>
            </div>
            <p className="mt-4 text-xs leading-6 text-zinc-500">
              说句公道话：这个仓库已经做过多轮审计，留下了大量 Audit 注释（payload 上限、XP 守恒、worldgen 死锁修复等）。
              下面列的是剩下的、新发现的，或者“注释说修好了、其实只修了一半”的问题。
            </p>
          </Card>
        </div>
      </section>

      {/* Findings */}
      <section>
        <SectionTitle
          id="findings"
          kicker="Findings"
          title="按路径分类的问题清单"
          desc="点卡片展开详情和修复建议。严重度按“对普通玩家或服主的实际影响 × 触发概率”评估。"
        />
        <div className="mb-3 flex flex-wrap gap-2">
          <Chip active={path === "all"} onClick={() => setPath("all")}>
            全部路径
          </Chip>
          {PATHS.map((p) => (
            <Chip key={p.key} active={path === p.key} onClick={() => setPath(p.key)} title={p.desc}>
              {p.label}
              <span className="ml-1.5 text-zinc-500">{FINDINGS.filter((f) => f.path === p.key).length}</span>
            </Chip>
          ))}
        </div>
        <div className="mb-6 flex flex-wrap gap-2">
          <Chip small active={sev === "all"} onClick={() => setSev("all")}>
            全部等级
          </Chip>
          {SEVS.filter((s) => counts[s]).map((s) => (
            <Chip small key={s} active={sev === s} onClick={() => setSev(s)}>
              {s}
            </Chip>
          ))}
        </div>

        <div className="space-y-3">
          {list.map((f) => {
            const isOpen = open[f.id] ?? false;
            return (
              <Card key={f.id} className="p-0">
                <button
                  onClick={() => setOpen((o) => ({ ...o, [f.id]: !isOpen }))}
                  className="flex w-full items-start gap-3 p-4 text-left md:p-5"
                >
                  <span className="mt-0.5 shrink-0 font-mono text-xs text-zinc-500">{f.id}</span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <SevBadge s={f.sev} />
                      <span className="text-xs text-teal-300/80">{PATHS.find((p) => p.key === f.path)?.label}</span>
                      {f.verify && (
                        <span className="rounded bg-amber-500/10 px-1.5 py-0.5 text-[11px] text-amber-300 ring-1 ring-amber-400/30">需验证</span>
                      )}
                    </div>
                    <div className="mt-1.5 font-semibold text-white">{f.title}</div>
                    <div className="mt-1 font-mono text-xs text-zinc-500">{f.where}</div>
                  </div>
                  <span className={cn("mt-1 text-zinc-500 transition-transform", isOpen && "rotate-90")}>▶</span>
                </button>
                {isOpen && (
                  <div className="border-t border-white/10 px-5 pb-5 pt-4 text-sm leading-7 text-zinc-300">
                    <ul className="list-disc space-y-2 pl-5">
                      {f.detail.map((d, i) => (
                        <li key={i}>
                          <Rich text={d} />
                        </li>
                      ))}
                    </ul>
                    {f.code && <CodeBlock>{f.code}</CodeBlock>}
                    <div className="mt-4 rounded-lg bg-teal-500/10 p-3 text-teal-100 ring-1 ring-teal-400/20">
                      <span className="font-semibold text-teal-300">建议：</span>
                      <Rich text={f.fix} />
                    </div>
                  </div>
                )}
              </Card>
            );
          })}
          {list.length === 0 && <div className="text-sm text-zinc-500">该组合下没有条目。</div>}
        </div>
      </section>

      {/* Hardcoded */}
      <section>
        <SectionTitle
          id="hardcoded"
          kicker="Hardcoded"
          title="不该硬编码的地方"
          desc={
            <>
              项目本身倡导“JSON 是单一事实源”（<code className="inl">BundledDefaults</code> 由脚本生成，CI 会做字节比对），但下面这些值仍然散落在 Java 里，或者在 Java 里另写了一套兜底默认值。
            </>
          }
        />
        <div className="overflow-x-auto rounded-2xl border border-white/10">
          <table className="w-full min-w-[820px] text-left text-sm">
            <thead className="bg-white/5 text-xs uppercase tracking-wider text-zinc-400">
              <tr>
                <th className="px-4 py-3">内容</th>
                <th className="px-4 py-3">位置</th>
                <th className="px-4 py-3">当前写死的值</th>
                <th className="px-4 py-3">建议</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {HARDCODED.map((h) => (
                <tr key={h.what} className="align-top hover:bg-white/[0.03]">
                  <td className="px-4 py-3 font-medium text-white">{h.what}</td>
                  <td className="px-4 py-3 font-mono text-xs text-zinc-400">{h.where}</td>
                  <td className="px-4 py-3 font-mono text-xs text-violet-200">{h.value}</td>
                  <td className="px-4 py-3 text-zinc-300">{h.suggest}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Drift */}
      <section>
        <SectionTitle
          id="drift"
          kicker="Doc ↔ Data drift"
          title="文档和数据对账"
          desc="玩家只看 Wiki 和游戏内图鉴，所以文档数字一旦错了，实际效果就等于机制错了。"
        />
        <div className="overflow-x-auto rounded-2xl border border-white/10">
          <table className="w-full min-w-[700px] text-left text-sm">
            <thead className="bg-white/5 text-xs uppercase tracking-wider text-zinc-400">
              <tr>
                <th className="px-4 py-3">项目</th>
                <th className="px-4 py-3">docs/WIKI.md 写的</th>
                <th className="px-4 py-3">随附数据 / 代码实际</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {DRIFT.map((d) => (
                <tr key={d.item} className="hover:bg-white/[0.03]">
                  <td className="px-4 py-3 font-medium text-white">{d.item}</td>
                  <td className="px-4 py-3 text-red-200/90">{d.wiki}</td>
                  <td className="px-4 py-3 text-teal-200">{d.data}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-4">
          <Callout tone="amber" title="对 26.1.2 这个版本来说要特别留意的">
            1）MC 26.x 的 <code className="inl">ResourceLocation→Identifier</code>、<code className="inl">MouseButtonEvent/KeyEvent</code>、
            <code className="inl">PermissionLevel</code> 这些新 API 都已经迁移，CI 编译也是绿的，这部分没问题。
            2）风险集中在“依赖原版内部实现细节”的地方：<code className="inl">ChiseledBookShelfBlockEntity#removeItem</code> 是否经过 ContainerHelper（MIX-01）、
            书架命中槽位常量（API-05）、<code className="inl">postProcessing</code> 列表的语义（MIX-04）、C2S 载荷上限（COD-01）。
            这几处都是编译能过、运行时悄悄不对的类型，必须反编译 26.1.2 逐一确认。
          </Callout>
        </div>
      </section>
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
  title,
  small,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
  title?: string;
  small?: boolean;
}) {
  return (
    <button
      title={title}
      onClick={onClick}
      className={cn(
        "rounded-full ring-1 transition",
        small ? "px-3 py-1 text-xs" : "px-3.5 py-1.5 text-sm",
        active ? "bg-violet-500/30 text-white ring-violet-300/60" : "bg-white/5 text-zinc-300 ring-white/10 hover:bg-white/10"
      )}
    >
      {children}
    </button>
  );
}
