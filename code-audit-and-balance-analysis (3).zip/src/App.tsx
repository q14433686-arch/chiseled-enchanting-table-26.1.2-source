import { useEffect, useState } from "react";
import AuditPage from "./pages/AuditPage";
import DebatePage from "./pages/DebatePage";
import AdvicePage from "./pages/AdvicePage";
import { cn } from "./utils/cn";

const TABS = [
  { key: "audit", label: "源码审计", icon: "🔍" },
  { key: "debate", label: "“矛盾”与“超级书”", icon: "⚖️" },
  { key: "advice", label: "怀疑与建议", icon: "🧭" },
] as const;
type TabKey = (typeof TABS)[number]["key"];

const REPO =
  "https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/tree/arena%2F2d61e52c-chiseled-enchanting-table-26-1";

function readHash(): TabKey {
  const h = window.location.hash.replace("#/", "").replace("#", "");
  return (TABS.find((t) => t.key === h)?.key ?? "audit") as TabKey;
}

export default function App() {
  const [tab, setTab] = useState<TabKey>(readHash);

  useEffect(() => {
    const on = () => setTab(readHash());
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);

  const go = (k: TabKey) => {
    window.location.hash = `/${k}`;
    window.scrollTo({ top: 0 });
  };

  return (
    <div className="arcane-bg min-h-screen">
      <header className="sticky top-0 z-20 border-b border-white/10 bg-[#0d0b14]/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-3 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500 to-teal-500 text-lg shadow-lg shadow-violet-900/40">
              📚
            </div>
            <div>
              <div className="text-sm font-bold text-white">Chiseled Enchanting Table · 26.1.2</div>
              <div className="text-[11px] text-zinc-500">非官方移植版 · 审计与设计评议</div>
            </div>
          </div>
          <nav className="flex gap-1 overflow-x-auto rounded-xl bg-white/5 p-1 ring-1 ring-white/10">
            {TABS.map((t) => (
              <button
                key={t.key}
                onClick={() => go(t.key)}
                className={cn(
                  "whitespace-nowrap rounded-lg px-3.5 py-1.5 text-sm transition",
                  tab === t.key ? "bg-violet-500/30 text-white shadow-inner ring-1 ring-violet-300/40" : "text-zinc-400 hover:text-white"
                )}
              >
                <span className="mr-1.5">{t.icon}</span>
                {t.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-10 md:py-14">
        {tab === "audit" && <AuditPage />}
        {tab === "debate" && <DebatePage />}
        {tab === "advice" && <AdvicePage />}

        <div className="mt-16 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-zinc-500 md:flex-row">
          <span>
            基于提交 <code className="inl">bd61ca2</code> 的静态审计；行为结论以反编译或实机验证为准。
          </span>
          <div className="flex gap-2">
            {TABS.filter((t) => t.key !== tab).map((t) => (
              <button key={t.key} onClick={() => go(t.key)} className="rounded-md bg-white/5 px-3 py-1.5 text-zinc-300 ring-1 ring-white/10 hover:bg-white/10">
                {t.icon} {t.label} →
              </button>
            ))}
            <a href={REPO} target="_blank" rel="noreferrer" className="rounded-md bg-white/5 px-3 py-1.5 text-zinc-300 ring-1 ring-white/10 hover:bg-white/10">
              仓库 ↗
            </a>
          </div>
        </div>
      </main>
    </div>
  );
}
