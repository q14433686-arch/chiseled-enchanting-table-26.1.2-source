import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ShieldAlert,
  ChevronRight,
  Bug,
  Hammer,
  FileWarning,
  Gauge,
  TriangleAlert,
  GitCompareArrows,
} from "lucide-react";
import {
  FINDINGS,
  SEV_META,
  minMasterTomeCost,
  essencePotential,
  type Sev,
  type Finding,
} from "../lib/audit";
import { SectionHead, Reveal, Chip, Slider } from "./ui";

const KIND_ICON = {
  机制: Bug,
  硬编码: Hammer,
  数值: Gauge,
  "CI/文档": FileWarning,
} as const;

/* ── 套利曲线图 ── */
const ArbitrageChart = () => {
  const [maxLevel, setMaxLevel] = useState(150);
  const [anvil, setAnvil] = useState(1);
  const [treasure, setTreasure] = useState(false);

  const data = useMemo(() => {
    const pts: { m: number; cost: number; refund: number }[] = [];
    for (let m = 1; m <= 255; m += 2) {
      pts.push({
        m,
        cost: minMasterTomeCost(m, m),
        refund: essencePotential(m, m, anvil, treasure),
      });
    }
    return pts;
  }, [anvil, treasure]);

  const cur = {
    cost: minMasterTomeCost(maxLevel, maxLevel),
    refund: essencePotential(maxLevel, maxLevel, anvil, treasure),
  };
  const net = cur.refund - cur.cost;

  const W = 560;
  const H = 210;
  const maxY = 280;
  const x = (m: number) => ((m - 1) / 254) * W;
  const y = (v: number) => H - (Math.min(v, maxY) / maxY) * H;
  const path = (key: "cost" | "refund") =>
    data.map((d, i) => `${i === 0 ? "M" : "L"}${x(d.m).toFixed(1)},${y(d[key]).toFixed(1)}`).join(" ");

  const crossover = data.find((d) => d.refund > d.cost)?.m ?? null;

  return (
    <div className="pixelframe bg-vellum/70 border border-[#ff6b8a]/25 overflow-hidden">
      <div className="flex items-center justify-between px-6 md:px-8 py-4 border-b border-arcane/10">
        <p className="font-code text-[11px] tracking-[0.3em] text-[#ff6b8a] flex items-center gap-2">
          <GitCompareArrows size={13} /> F1 REPRO · 返还 vs 成本实算
        </p>
        <Chip tone={net > 0 ? "#ff6b8a" : "#8df0a4"}>
          {net > 0 ? `净产出 +${net} 点` : `净消耗 ${net} 点`}
        </Chip>
      </div>

      <div className="p-6 md:p-8 space-y-6">
        <svg viewBox={`0 0 ${W} ${H + 26}`} className="w-full h-auto">
          {[70, 140, 210, 280].map((v) => (
            <g key={v}>
              <line x1={0} x2={W} y1={y(v)} y2={y(v)} stroke="rgba(161,140,255,0.1)" strokeWidth={1} />
              <text x={2} y={y(v) - 3} fill="#6f659a" fontSize={8} fontFamily="monospace">
                {v}
              </text>
            </g>
          ))}
          {crossover && (
            <>
              <rect x={x(crossover)} y={0} width={W - x(crossover)} height={H} fill="rgba(255,107,138,0.07)" />
              <line
                x1={x(crossover)}
                x2={x(crossover)}
                y1={0}
                y2={H}
                stroke="#ff6b8a"
                strokeWidth={1}
                strokeDasharray="3 3"
              />
              <text x={x(crossover) + 4} y={14} fill="#ff6b8a" fontSize={9} fontFamily="monospace">
                越界点 maxLevel={crossover}
              </text>
            </>
          )}
          <path d={path("cost")} fill="none" stroke="#8df0a4" strokeWidth={2} />
          <path d={path("refund")} fill="none" stroke="#ff6b8a" strokeWidth={2} />
          <circle cx={x(maxLevel)} cy={y(cur.cost)} r={4} fill="#8df0a4" />
          <circle cx={x(maxLevel)} cy={y(cur.refund)} r={4} fill="#ff6b8a" />
          <line x1={x(maxLevel)} x2={x(maxLevel)} y1={0} y2={H} stroke="rgba(237,230,212,0.25)" strokeWidth={1} />
          {[1, 64, 128, 192, 255].map((m) => (
            <text key={m} x={x(m)} y={H + 16} fill="#6f659a" fontSize={8} fontFamily="monospace" textAnchor="middle">
              {m}
            </text>
          ))}
          <text x={W / 2} y={H + 26} fill="#6f659a" fontSize={8} fontFamily="monospace" textAnchor="middle">
            模组魔咒 maxLevel（满级铭刻后立即全洗）
          </text>
        </svg>

        <div className="flex flex-wrap gap-5 text-[11px] font-code">
          <span className="flex items-center gap-2 text-xp">
            <span className="w-4 h-0.5 bg-xp" />成本（母本量产 −40% 后最低实付）
          </span>
          <span className="flex items-center gap-2 text-[#ff6b8a]">
            <span className="w-4 h-0.5 bg-[#ff6b8a]" />返还（essencePotential）
          </span>
        </div>

        <div className="grid sm:grid-cols-3 gap-5 items-end">
          <Slider
            label="模组魔咒 maxLevel"
            value={maxLevel}
            min={1}
            max={255}
            onChange={setMaxLevel}
            format={(v) => `${v} 级`}
            accent="#ff6b8a"
          />
          <Slider
            label="anvilCost（稀有度因子）"
            value={anvil}
            min={1}
            max={100}
            onChange={setAnvil}
            format={(v) => `${v}`}
            accent="#e8c37c"
          />
          <button
            onClick={() => setTreasure((t) => !t)}
            className="px-4 py-2.5 rounded-sm text-[12px] font-code border transition-all"
            style={{
              color: treasure ? "#0a0913" : "#e8c37c",
              background: treasure ? "#e8c37c" : "transparent",
              borderColor: "#e8c37c44",
            }}
          >
            宝藏标签 ×1.15 {treasure ? "ON" : "OFF"}
          </button>
        </div>

        <div className="rounded-sm bg-obsidian/60 border border-arcane/10 p-4 font-code text-[11.5px] leading-6 text-mute">
          <span className="text-faint">// DisenchantmentApplication.java:81</span>
          <br />
          return Math.max(<span className="text-[#ff6b8a]">clampedLevel</span>, raw);
          <span className="text-faint ml-2">← 用「等级数」兜底，与成本曲线无关</span>
          <br />
          <span className="text-faint">// Javadoc:65 承诺 </span>
          <span className="text-xp">"Guaranteed strictly below minimum Master Tome inscription XP cost"</span>
        </div>
      </div>
    </div>
  );
};

/* ── 单条发现 ── */
const FindingCard = ({ f, idx }: { f: Finding; idx: number }) => {
  const [open, setOpen] = useState(idx < 2);
  const meta = SEV_META[f.sev];
  const Icon = KIND_ICON[f.kind];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: Math.min(idx * 0.04, 0.3) }}
      className="pixelframe bg-vellum/60 border overflow-hidden"
      style={{ borderColor: open ? `${meta.tone}44` : "rgba(161,140,255,0.12)" }}
    >
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center gap-3 md:gap-4 px-5 py-4 text-left hover:bg-vellum2/50 transition-colors"
      >
        <span
          className="font-code text-[10px] px-2 py-1 rounded-sm shrink-0 w-11 text-center"
          style={{ color: meta.tone, background: `${meta.tone}14`, border: `1px solid ${meta.tone}38` }}
        >
          {meta.label}
        </span>
        <span className="font-code text-[11px] text-faint shrink-0 w-7">{f.id}</span>
        <Icon size={14} className="shrink-0 text-mute hidden sm:block" />
        <span className="flex-1 font-medium text-[13.5px] md:text-[14.5px] text-parch leading-5">
          {f.title}
        </span>
        <motion.span animate={{ rotate: open ? 90 : 0 }} className="shrink-0">
          <ChevronRight size={15} className="text-faint" />
        </motion.span>
      </button>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 pt-1 space-y-4 border-t border-arcane/10">
              <p className="font-code text-[10.5px] text-faint break-all pt-3">📍 {f.where}</p>

              {f.evidence && (
                <div
                  className="rounded-sm px-4 py-2.5 font-code text-[11px] leading-5"
                  style={{ background: `${meta.tone}0d`, border: `1px solid ${meta.tone}26`, color: meta.tone }}
                >
                  {f.evidence}
                </div>
              )}

              {[
                { k: "现象", v: f.what, c: "#9c93bd" },
                { k: "为什么要紧", v: f.why, c: "#e8c37c" },
                { k: "建议", v: f.fix, c: "#8df0a4" },
              ].map((b) => (
                <div key={b.k} className="flex gap-3">
                  <span
                    className="font-code text-[10px] tracking-wider shrink-0 w-14 pt-0.5"
                    style={{ color: b.c }}
                  >
                    {b.k}
                  </span>
                  <p className="text-[12.5px] leading-6.5 text-mute font-light flex-1">{b.v}</p>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

const Audit = () => {
  const [filter, setFilter] = useState<Sev | "all">("all");

  const counts = useMemo(() => {
    const c: Record<string, number> = { all: FINDINGS.length };
    FINDINGS.forEach((f) => (c[f.sev] = (c[f.sev] ?? 0) + 1));
    return c;
  }, []);

  const shown = useMemo(
    () =>
      FINDINGS.filter((f) => filter === "all" || f.sev === filter).sort(
        (a, b) => SEV_META[a.sev].rank - SEV_META[b.sev].rank,
      ),
    [filter],
  );

  return (
    <section id="audit" className="relative max-w-6xl mx-auto px-6 md:px-10 py-24 md:py-32">
      <div
        className="absolute top-40 -right-20 font-display font-black text-[16rem] leading-none select-none pointer-events-none opacity-[0.035]"
        aria-hidden
      >
        审
      </div>

      <SectionHead
        numeral="审"
        kicker="CODE REVIEW · arena/d0fffdab"
        accent="#ff6b8a"
        title={<>审查报告：<span className="text-[#ff6b8a]">11 条</span>发现</>}
        blurb="已克隆该分支做实读与实算。整体观感：数据驱动的骨架搭得相当扎实（shelf_gates / disenchanting / treasure_epiphany 都做了 Config record + S2C 同步 + clamp 兜底），这在移植型仓库里属于上游水准。问题集中在三处——返还曲线与成本曲线没有共同的事实源、CI 的「证明」验的是 schema 而非不变量、以及共振系统这块最大的平衡面反而完全硬编码。"
      />

      {/* 概览 */}
      <Reveal>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-10">
          {[
            { k: "严重", v: counts.critical ?? 0, tone: "#ff6b8a", d: "可复现的经济漏洞" },
            { k: "高", v: counts.high ?? 0, tone: "#f08cc8", d: "机制塌缩 / 条件可绕过" },
            { k: "中", v: counts.medium ?? 0, tone: "#e8c37c", d: "硬编码 / 漂移隐患" },
            { k: "低", v: counts.low ?? 0, tone: "#7ee8dc", d: "口味与仓库卫生" },
          ].map((s) => (
            <div
              key={s.k}
              className="pixelframe bg-abyss/70 border p-5"
              style={{ borderColor: `${s.tone}28` }}
            >
              <div className="flex items-baseline gap-2">
                <span className="font-display text-4xl font-black" style={{ color: s.tone }}>
                  {s.v}
                </span>
                <span className="text-xs text-mute">{s.k}</span>
              </div>
              <p className="text-[11px] text-faint mt-1.5 font-light">{s.d}</p>
            </div>
          ))}
        </div>
      </Reveal>

      {/* 头号发现图表 */}
      <Reveal>
        <div className="mb-10">
          <div className="flex items-start gap-3 mb-5">
            <TriangleAlert size={18} className="text-[#ff6b8a] shrink-0 mt-0.5" />
            <p className="text-sm leading-7 text-mute font-light">
              <span className="text-parch font-medium">头号发现（F1）：</span>
              essencePotential() 末行以「等级数」给返还兜底，与成本曲线完全脱钩。
              模组魔咒 <span className="font-code text-[#ff6b8a]">maxLevel ≥ 127</span> 时，
              满级铭刻（母本量产模式最低实付 126 点）后立即全洗，返还即超过支出——
              拖动下方滑块可复现。而 CI 的反套利门禁只循环到 maxLevel=10，看不见这个区间。
            </p>
          </div>
          <ArbitrageChart />
        </div>
      </Reveal>

      {/* 过滤器 */}
      <Reveal>
        <div className="flex flex-wrap items-center gap-2 mb-5">
          <ShieldAlert size={14} className="text-mute mr-1" />
          {(["all", "critical", "high", "medium", "low"] as const).map((s) => {
            const tone = s === "all" ? "#a18cff" : SEV_META[s].tone;
            const on = filter === s;
            return (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className="px-3.5 py-1.5 rounded-sm text-[11.5px] font-code border transition-all"
                style={{
                  color: on ? "#0a0913" : tone,
                  background: on ? tone : `${tone}0d`,
                  borderColor: `${tone}40`,
                }}
              >
                {s === "all" ? "全部" : SEV_META[s].label} {counts[s] ?? 0}
              </button>
            );
          })}
        </div>
      </Reveal>

      <div className="space-y-2.5">
        {shown.map((f, i) => (
          <FindingCard key={f.id} f={f} idx={i} />
        ))}
      </div>

      {/* 收尾建议 */}
      <Reveal>
        <div className="pixelframe bg-gradient-to-br from-vellum to-vellum2/50 border border-gild/25 p-7 md:p-9 mt-10">
          <p className="font-code text-[11px] tracking-[0.3em] text-gild mb-6">
            PRIORITY · 如果只改三件事
          </p>
          <div className="space-y-4">
            {[
              {
                n: "壹",
                t: "让返还从成本函数派生，而不是另写一条曲线",
                d: "F1 + F2 + F9 其实是同一个根因：essencePotential 是独立发明的第二条曲线，于是「返还 < 成本」只能靠人工巡检维持。只要改成 refund = ρ · minCost(e, L)，这三条一次性消失，且第三方数据包改成本时返还自动跟随。",
                tone: "#ff6b8a",
              },
              {
                n: "贰",
                t: "把 ceil(M/2) 的去留写进文档，并给残卷条件去重",
                d: "F4 与 F3 都是「实现与设计意图对不上」。前者让母本失去等级独占性、WIKI 失真；后者让梯度叁可以被一本厚书绕过。两处改动都很小，但决定玩家对规则的信任。",
                tone: "#f08cc8",
              },
              {
                n: "叁",
                t: "给 LibraryResonance 补一个 Config record",
                d: "F5 是最大的一块硬编码面，而仓库里已经有三份现成的 Config + S2C 模板可以照抄。做完这一条，WIKI 第 9 节「全部数值支持数据包覆盖」才算名副其实。",
                tone: "#8df0a4",
              },
            ].map((r) => (
              <div key={r.n} className="flex gap-4">
                <span
                  className="font-display font-black text-xl shrink-0 w-8 text-center"
                  style={{ color: r.tone }}
                >
                  {r.n}
                </span>
                <div>
                  <p className="font-medium text-[14.5px] text-parch mb-1">{r.t}</p>
                  <p className="text-[12.5px] leading-6 text-mute font-light">{r.d}</p>
                </div>
              </div>
            ))}
          </div>
          <p className="mt-7 pt-5 border-t border-arcane/10 text-[11.5px] leading-6 text-faint font-light">
            另外值得肯定：Config record 普遍带 compact constructor 做 clamp、
            maxUnlockedDirectTier 对 overrides 做了越界保护、
            essencePotential 的 telescoping 性质（逐级降 = 一次全洗）在 CI 里有等价性断言、
            affinityMasteryUnits 用 canEnchant() 而非硬编码物品表——
            这些都是正确的工程直觉，F1 之所以值得一提，正是因为其余部分的严谨度衬出了它的突兀。
          </p>
        </div>
      </Reveal>
    </section>
  );
};

export default Audit;
