import {
  FileJson,
  Code2,
  Languages,
  Search,
  ShieldCheck,
  Quote,
  ExternalLink,
} from "lucide-react";
import { Reveal } from "./ui";

const ROADMAP = [
  {
    icon: FileJson,
    tone: "#e8c37c",
    title: "数据层面（数据包先行）",
    items: [
      "book_upgrades.json — 材料升级增 { mode: \"delta\", floorPct: 8 }，向后兼容旧全价字段",
      "新增 wash_costs.json — 降级 ρ、洗去 σ、蚀咒墨支付项（含 item tag）、全洗免费开关",
      "enchantment_costs.json 不动 — V(e,L) 由既有曲线换算生成，单一事实源",
    ],
  },
  {
    icon: Code2,
    tone: "#a18cff",
    title: "代码层面",
    items: [
      "InscriptionValues 纯函数工具（服务端权威）— 升/降/洗三方向共算一条曲线",
      "研退 ScreenHandler + 页签 UI；返还以经验球发放，溢出落盘为 orb",
      "S2C 成本同步复用现成通道（join / /reload），JEI/REI 增「研退」分类（可选适配器）",
    ],
  },
  {
    icon: Languages,
    tone: "#f08cc8",
    title: "物料层面",
    items: [
      "新物品 erasure_ink：1 贴图 + 1 无序配方（墨囊 × 发酵蛛眼 → ×2），零 Data Component",
      "≤14 条新 lang key × 11 语言；三种行徽标：降=反流箭头 / 洗=墨滴 / 全洗=回旋",
      "残卷管线零改动 —— 末词条洗去与全洗统一落回 depleted_tome",
    ],
  },
];

const GUARDRAILS = [
  ["升阶下限", "⌈V(new)·8%⌉", "防零元续刻，保留仪式感"],
  ["返还率上界", "ρ ≤ 0.5 < 1 − 0.4", "ρ_max 严格小于最小实付率，循环必净耗"],
  ["材料单向", "永不返还", "材料只进不出，闭环沉降"],
  ["宝藏折价", "ρ_treasure = 0.25", "与顿悟 90% 概率上限协同，防产出稀释"],
  ["诅咒反向", "洗去收 .35V，返 0", "杜绝「升诅咒 → 降级」奇技"],
  ["返点不返级", "经验球发放", "规避高等级经验宽度放大套利"],
];

const Closing = () => (
  <footer className="relative">
    <section className="max-w-6xl mx-auto px-6 md:px-10 py-24 md:py-32">
      {/* 落地清单 */}
      <Reveal>
        <div className="text-center mb-14">
          <p className="font-code text-[11px] tracking-[0.4em] text-gild uppercase mb-4">
            IMPLEMENTATION · 落地清单
          </p>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-parch">
            三面落子，一次齐活
          </h2>
        </div>
      </Reveal>

      <div className="grid md:grid-cols-3 gap-4 mb-16">
        {ROADMAP.map((r, i) => (
          <Reveal key={r.title} delay={i * 0.08}>
            <div className="pixelframe bg-vellum/70 border border-arcane/15 p-6 h-full hover:-translate-y-1 transition-transform duration-300">
              <div className="flex items-center gap-3 mb-5">
                <div
                  className="w-9 h-9 pixelframe flex items-center justify-center border"
                  style={{ background: `${r.tone}12`, borderColor: `${r.tone}35` }}
                >
                  <r.icon size={16} style={{ color: r.tone }} />
                </div>
                <p className="font-display font-bold text-[15px] text-parch">{r.title}</p>
              </div>
              <ul className="space-y-3">
                {r.items.map((it, k) => (
                  <li key={k} className="flex gap-2.5 text-[12px] leading-5.5 text-mute font-light">
                    <span className="font-code text-[10px] mt-1 shrink-0" style={{ color: r.tone }}>
                      {String(k + 1).padStart(2, "0")}
                    </span>
                    {it}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        ))}
      </div>

      {/* 护栏 */}
      <Reveal>
        <div className="pixelframe bg-abyss/80 border border-xp/20 p-7 md:p-9 mb-16">
          <p className="flex items-center gap-2 font-code text-[11px] tracking-[0.3em] text-xp mb-6">
            <ShieldCheck size={13} /> BALANCE GUARD · 数值护栏一览（兼容性的全部答案都在这里）
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {GUARDRAILS.map(([t, v, d]) => (
              <div key={t} className="rounded-sm bg-obsidian/60 border border-arcane/10 p-4">
                <div className="flex items-baseline justify-between gap-2 mb-1.5">
                  <span className="text-[12px] font-medium text-parch">{t}</span>
                  <span className="font-code text-[11px] text-xp whitespace-nowrap">{v}</span>
                </div>
                <p className="text-[11px] leading-5 text-faint font-light">{d}</p>
              </div>
            ))}
          </div>
        </div>
      </Reveal>

      {/* TL;DR */}
      <Reveal>
        <div className="relative text-center py-16 md:py-20">
          <Quote size={28} className="mx-auto text-gild/40 mb-8" />
          <p className="font-display font-black leading-snug text-parch" style={{ fontSize: "clamp(1.6rem, 4.5vw, 3.2rem)" }}>
            一条曲线，两个方向。
          </p>
          <p className="mt-6 font-display text-lg md:text-2xl leading-relaxed text-mute">
            升付<span className="text-gild">增量</span> · 降返<span className="text-xp">半值</span> ·
            洗磨<span className="text-inkd">蚀墨</span> · 全洗<span className="text-arcane">免费</span> ·
            双页<span className="text-parch">同面</span>
          </p>
          <div className="gold-rule mt-14 mx-auto max-w-md" />

          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <a
              href="https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source"
              target="_blank"
              rel="noreferrer"
              className="group flex items-center gap-2.5 px-7 py-3.5 pixelframe bg-arcane-deep/25 border border-arcane/40 text-parch font-code text-xs tracking-[0.2em] hover:bg-arcane-deep/40 transition-colors glow-arcane"
            >
              <Search size={14} />
              前往仓库 · 据此开 ISSUE 讨论
              <ExternalLink size={12} className="opacity-50 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all" />
            </a>
            <a
              href="https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/chiseled-enchanting-table-26.1.2-source/docs/WIKI.md"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 px-7 py-3.5 pixelframe bg-transparent border border-arcane/15 text-mute font-code text-xs tracking-[0.2em] hover:text-parch hover:border-arcane/35 transition-colors"
            >
              对照现行 WIKI 机制
            </a>
          </div>
        </div>
      </Reveal>
    </section>

    <div className="border-t border-arcane/10">
      <div className="max-w-6xl mx-auto px-6 md:px-10 py-8 flex flex-col md:flex-row items-center justify-between gap-3">
        <p className="font-code text-[10.5px] text-faint tracking-[0.25em]">
          退刻之间 · 纂刻附魔台（社区移植版）设计方向提案 v1.2
        </p>
        <p className="font-code text-[10.5px] text-faint/70 tracking-wider">
          数值均为提案模型 · 原版上游 Sacramentix · MIT License
        </p>
      </div>
    </div>
  </footer>
);

export default Closing;
