import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Droplets, Eraser, FlaskConical, PackageCheck, ArrowRight, BookX, BookOpen, ScrollText } from "lucide-react";
import {
  ENCHANTS,
  RARITY_LABEL,
  RARITY_COLOR,
  ROMAN,
  valueCurve,
  stripXp,
  stripInk,
  fmt,
} from "../lib/enchant";
import { SectionHead, Reveal, FormulaCard, Slider, Chip } from "./ui";

/** 三层「退制」直觉分层 */
const TIERS = [
  {
    icon: Eraser,
    name: "磨浅 · 降阶",
    verdict: "免费 + 返还",
    desc: "只削刻痕深度：免材料、按 ρ·ΔV 返经验（见第贰问）。",
    tone: "#8df0a4",
  },
  {
    icon: Droplets,
    name: "剔除 · 定向洗去",
    verdict: "蚀咒墨 + 经验",
    desc: "精准抹除单个词条而保其余——这是「手术」，理应是三种操作里最贵的一档。",
    tone: "#f08cc8",
  },
  {
    icon: BookX,
    name: "磨平 · 全洗",
    verdict: "免费 → 残卷",
    desc: "整页磨平，无需特殊材料；剥落的书页直接产出既有的「褪魔残卷」，走既有覆写管线。",
    tone: "#a18cff",
  },
];

const COMPAT_POINTS = [
  {
    title: "数据包先行，注册殿后",
    body: "洗去支付项写进 wash_costs.json，支持物品 tag。包/服主可在任意版本把支付项替换为该版本可用的任何东西——默认项失效不等于机制失效。",
  },
  {
    title: "秘法凝晶天然兜底",
    body: "现有 arcane_catalyst 即万能单件耗材的定位，让它同样可顶替蚀咒墨——服务器若不想引入新物品，一条数据包规则即可纯配置化关闭新物品。",
  },
  {
    title: "零组件、零 NBT 的新物品",
    body: "蚀咒墨不带任何 Data Component——跨 26.x 及以后组件 schema 迁移时没有任何数据负担，进注册表即完工。",
  },
  {
    title: "不进世界生成与战利品",
    body: "新物品只通过无序合成获得，不注入 loot_injections 与世界生成——卸载或降版本时按 Fabric 注册缺失的宽容路径处理，存档不留孤块。",
  },
];

const Wash = () => {
  const [enchantId, setEnchantId] = useState("fortune");
  const [level, setLevel] = useState(3);
  const e = ENCHANTS.find((x) => x.id === enchantId)!;
  const lv = Math.min(level, e.max);

  const calc = useMemo(
    () => ({ xp: stripXp(e, lv), ink: stripInk(e, lv), v: valueCurve(e, lv) }),
    [e, lv],
  );

  return (
    <section id="wash" className="relative max-w-6xl mx-auto px-6 md:px-10 py-24 md:py-36">
      <div
        className="absolute top-40 -left-20 font-display font-black text-[16rem] leading-none select-none pointer-events-none opacity-[0.035]"
        aria-hidden
      >
        褪
      </div>

      <SectionHead
        numeral="叁"
        kicker="PROBLEM 03 · SELECTIVE STRIPPING"
        accent="#f08cc8"
        title={<>洗词条是<span className="text-inkd">手术</span>，磨平是<span className="text-arcane">粗活</span></>}
        blurb="直觉的分水岭在于「精度」：保住其余词条、单独抹去某一条，是高精度操作，理应付出特殊材料与经验；而把整页暴力磨平不需要任何珍稀耗材——它只需要承担「一切归零」的代价本身。紫水晶、绿宝石是通用通货，不该是这里的钥匙。"
      />

      {/* 三层分层 */}
      <Reveal>
        <div className="grid md:grid-cols-3 gap-4 mb-12">
          {TIERS.map((t, i) => (
            <motion.div
              key={t.name}
              whileHover={{ y: -5 }}
              className="pixelframe relative bg-vellum/70 border p-6 overflow-hidden"
              style={{ borderColor: `${t.tone}30` }}
            >
              <div
                className="absolute -top-8 -right-8 w-28 h-28 rounded-full blur-3xl opacity-15"
                style={{ background: t.tone }}
              />
              <div className="flex items-center justify-between mb-4">
                <t.icon size={20} style={{ color: t.tone }} />
                <span
                  className="font-code text-[10px] px-2 py-1 rounded-sm border"
                  style={{ color: t.tone, borderColor: `${t.tone}40`, background: `${t.tone}0d` }}
                >
                  {t.verdict}
                </span>
              </div>
              <p className="font-display font-bold text-lg text-parch mb-2">
                <span className="font-code text-xs text-faint mr-2">{String(i + 1).padStart(2, "0")}</span>
                {t.name}
              </p>
              <p className="text-[12.5px] leading-6 text-mute font-light">{t.desc}</p>
            </motion.div>
          ))}
        </div>
      </Reveal>

      <div className="grid lg:grid-cols-5 gap-6 mb-12">
        {/* 新物品提案 */}
        <Reveal className="lg:col-span-2">
          <div className="pixelframe bg-gradient-to-br from-vellum to-[#241531] border border-inkd/25 p-7 md:p-8 h-full">
            <p className="flex items-center gap-2 font-code text-[11px] tracking-[0.3em] text-inkd mb-6">
              <FlaskConical size={13} /> NEW ITEM · 新增物品提案
            </p>
            <div className="flex items-center gap-5 mb-6">
              <motion.div
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 3.4, repeat: Infinity, ease: "easeInOut" }}
                className="w-16 h-16 pixelframe bg-inkd/15 border border-inkd/40 flex items-center justify-center"
                style={{ boxShadow: "0 0 30px rgba(240,140,200,0.25)" }}
              >
                <Droplets size={26} className="text-inkd" />
              </motion.div>
              <div>
                <p className="font-display font-black text-2xl text-parch">蚀咒墨</p>
                <p className="font-code text-[11px] text-faint mt-1">
                  chiseled_enchanting_table:erasure_ink
                </p>
              </div>
            </div>

            {/* 合成示意 */}
            <div className="flex items-center gap-4 mb-6">
              <div className="grid grid-cols-3 gap-1">
                {["墨囊", "发酵蛛眼", "", "", "", "", "", "", ""].map((cell, i) => (
                  <div
                    key={i}
                    className={`w-11 h-11 border flex items-center justify-center text-[9.5px] leading-tight text-center font-medium ${
                      cell
                        ? "bg-vellum2 border-arcane/30 text-parch"
                        : "bg-obsidian/50 border-arcane/8"
                    }`}
                  >
                    {cell}
                  </div>
                ))}
              </div>
              <div className="flex flex-col items-center gap-1">
                <ArrowRight size={18} className="text-gild" />
                <span className="font-code text-[9px] text-faint">无序</span>
              </div>
              <div className="w-11 h-11 bg-inkd/15 border border-inkd/50 flex flex-col items-center justify-center">
                <Droplets size={15} className="text-inkd" />
                <span className="font-code text-[9px] text-inkd mt-0.5">×2</span>
              </div>
            </div>

            <p className="text-[12.5px] leading-6.5 text-mute font-light mb-5">
              <span className="text-parch">墨囊</span>承载「书写-擦除」语义；
              <span className="text-parch">发酵蛛眼</span>在原版即是「逆转 / 腐化」触媒
              （夜视→隐身、治疗→伤害）。两者皆自远古版本存续的老物品，
              合成朴素、语义贴合、不占用任何通货型矿产——正应「不一定紫水晶绿宝石」的直觉。
            </p>

            <div className="space-y-2.5">
              {COMPAT_POINTS.map((c, i) => (
                <div key={i} className="flex gap-3 items-start text-[12px] leading-5.5">
                  <span className="font-code text-inkd text-[10px] mt-1 shrink-0">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <p className="text-mute font-light">
                    <span className="text-parch font-medium">{c.title}</span> —— {c.body}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        {/* 定价 + 计算器 */}
        <Reveal className="lg:col-span-3" delay={0.1}>
          <div className="space-y-6 h-full flex flex-col">
            <FormulaCard
              tone="#f08cc8"
              title="洗去计费 · 提案公式"
              rows={[
                { lhs: "XP_洗", rhs: "= ⌈ σ_r · V(e, L) ⌉ · 常规 .20 / 稀有 .30 / 宝藏 .45 / 诅咒 .35" },
                { lhs: "蚀咒墨", rhs: "= (1 + ⌊(L−1)/2⌋) × (稀有/宝藏 ×2)" },
                { lhs: "全洗", rhs: "0 经验 · 0 材料 → 产出褪魔残卷" },
                { lhs: "末词条", rhs: "定向洗去最后一个词条 → 同样落为残卷" },
              ]}
            />

            <div className="pixelframe bg-vellum/70 border border-inkd/20 flex-1 flex flex-col">
              <div className="flex items-center justify-between px-6 md:px-8 py-4 border-b border-arcane/10">
                <p className="font-code text-[11px] tracking-[0.3em] text-inkd flex items-center gap-2">
                  <ScrollText size={13} /> STRIPPING METER · 洗去计价器
                </p>
                <Chip tone="#6f659a">手术费 ∝ 词条价值</Chip>
              </div>
              <div className="p-6 md:p-8 space-y-6 flex-1 flex flex-col justify-between">
                <div className="flex flex-wrap gap-2">
                  {ENCHANTS.map((x) => (
                    <button
                      key={x.id}
                      onClick={() => {
                        setEnchantId(x.id);
                        setLevel(x.max);
                      }}
                      className="px-3.5 py-2 rounded-sm text-[12px] font-medium transition-all border"
                      style={{
                        color: enchantId === x.id ? "#0a0913" : RARITY_COLOR[x.rarity],
                        background: enchantId === x.id ? RARITY_COLOR[x.rarity] : `${RARITY_COLOR[x.rarity]}0d`,
                        borderColor: `${RARITY_COLOR[x.rarity]}44`,
                      }}
                    >
                      {x.name}
                      <span className="font-code text-[10px] ml-1.5 opacity-70">{RARITY_LABEL[x.rarity]}</span>
                    </button>
                  ))}
                </div>

                <Slider
                  label={`该词条当前等级（价值 ${fmt(calc.v)} pt）`}
                  value={lv}
                  min={1}
                  max={e.max}
                  onChange={setLevel}
                  format={(v) => ROMAN[v]}
                  accent="#f08cc8"
                />

                <div className="grid sm:grid-cols-2 gap-3">
                  <motion.div
                    key={`ink-${calc.ink}`}
                    initial={{ scale: 0.97, opacity: 0.6 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="pixelframe bg-inkd/5 border border-inkd/25 p-5 flex items-center gap-4"
                  >
                    <Droplets size={22} className="text-inkd" />
                    <div>
                      <p className="font-display text-3xl font-black text-inkd leading-none">
                        {calc.ink} <span className="text-sm font-medium text-mute">件</span>
                      </p>
                      <p className="text-[11px] text-mute mt-1.5">蚀咒墨（可用秘法凝晶顶替）</p>
                    </div>
                  </motion.div>
                  <motion.div
                    key={`xp-${calc.xp}`}
                    initial={{ scale: 0.97, opacity: 0.6 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="pixelframe bg-gild/5 border border-gild/25 p-5 flex items-center gap-4"
                  >
                    <FlaskConical size={22} className="text-gild" />
                    <div>
                      <p className="font-display text-3xl font-black text-gild leading-none">
                        {fmt(calc.xp)} <span className="text-sm font-medium text-mute">pt</span>
                      </p>
                      <p className="text-[11px] text-mute mt-1.5">经验消耗 · 完整等级模式扣除</p>
                    </div>
                  </motion.div>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>

      {/* 管线闭环 */}
      <Reveal>
        <div className="pixelframe bg-abyss/80 border border-arcane/15 p-7 md:p-9">
          <p className="flex items-center gap-2 font-code text-[11px] tracking-[0.3em] text-arcane mb-7">
            <PackageCheck size={13} /> LIFECYCLE · 一本书的完整生命周期（全链路复用现制，零新管线）
          </p>
          <div className="flex flex-col lg:flex-row items-stretch gap-3">
            {[
              { icon: BookOpen, t: "附魔书 · 多词条", d: "锋利 V + 时运 III + 绑定诅咒", tone: "#e8c37c" },
              { icon: Droplets, t: "定向洗去 ×n", d: "蚀咒墨 + σ·V 经验，逐条剔除", tone: "#f08cc8" },
              { icon: BookX, t: "全洗 · 免费", d: "整页磨平 → 褪魔残卷（可 64 堆叠）", tone: "#a18cff" },
              { icon: Eraser, t: "覆写：书（现制）", d: "Lv.1 + 纸/骨粉/墨囊等常见材料", tone: "#7ee8dc" },
              { icon: BookOpen, t: "纯净普通书", d: "回到附魔循环的起点", tone: "#8df0a4" },
            ].map((n, i, arr) => (
              <div key={n.t} className="flex items-center gap-3 flex-1">
                <div className="flex-1 min-w-[150px] rounded-sm bg-vellum/60 border border-arcane/12 p-4">
                  <n.icon size={17} style={{ color: n.tone }} className="mb-2.5" />
                  <p className="font-medium text-[13px] text-parch mb-1">{n.t}</p>
                  <p className="text-[11px] leading-4.5 text-faint font-light">{n.d}</p>
                </div>
                {i < arr.length - 1 && (
                  <ArrowRight size={15} className="text-faint shrink-0 rotate-90 lg:rotate-0 mx-auto" />
                )}
              </div>
            ))}
          </div>
        </div>
      </Reveal>
    </section>
  );
};

export default Wash;
