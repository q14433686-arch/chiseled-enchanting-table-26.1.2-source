import { useState } from "react";
import { motion } from "framer-motion";
import { Library, CircleAlert, Boxes } from "lucide-react";
import { LADDER } from "../lib/shelves";
import { SectionHead, Reveal, Chip } from "./ui";

const MAXW = 44;

const RISKS = [
  {
    t: "38 架会不会挤掉雕纹书架？",
    v: "不会",
    d: "7×5×7 扫描共 244 个格位，38 普通 + 6~12 雕纹仅占 20%。但建议在 UI 的书架计数条上同时显示两类余量，避免玩家盲目堆木架后发现没地方放雕纹书架。",
    tone: "#8df0a4",
  },
  {
    t: "阶梯是硬锁还是灰显？",
    v: "灰显",
    d: "锁定的升阶行应当照常列出并标注「需 38 架 · 当前 31」。隐藏条目等于隐藏目标，而这套玩法的驱动力恰恰来自「看得见的下一格书架」。",
    tone: "#a18cff",
  },
  {
    t: "阈值密度（8/12/18/32/38）",
    v: "可接受",
    d: "五个阈值分属四个子系统，且单调不冲突。若日后还要加阈值，建议优先复用既有数字而非新增——玩家能记住的书架刻度大约就是五个。",
    tone: "#e8c37c",
  },
  {
    t: "拆除书架导致降级回滚？",
    v: "只锁未来",
    d: "阶梯只限制「能否发起升阶」，已经刻进书里的等级永不因书架被拆而回退。否则玩家搬家一次全库报废——这条必须写死。",
    tone: "#f08cc8",
  },
  {
    t: "与母本路线的关系",
    v: "完全隔离",
    d: "按你的要求，母本路线一字不动：雕纹书架里有母本就是 1~L 直接解锁、走量产模式。阶梯只约束「无母本可借」的材料升级路线，两条路永不互相判定。",
    tone: "#7ee8dc",
  },
  {
    t: "旧存档玩家突然被锁？",
    v: "需宽限",
    d: "新阶梯上线后，老玩家可能发现原本能做的升阶被锁。建议 shelf_gates.json 带 enabled 开关，并在首次打开界面时给一条 toast 说明，而非让人以为是 bug。",
    tone: "#9c93bd",
  },
];

const Ladder = () => {
  const [hover, setHover] = useState<number | null>(null);

  return (
    <section id="ladder" className="relative max-w-6xl mx-auto px-6 md:px-10 py-24 md:py-36">
      <div
        className="absolute top-40 -left-16 font-display font-black text-[16rem] leading-none select-none pointer-events-none opacity-[0.035]"
        aria-hidden
      >
        架
      </div>

      <SectionHead
        numeral="陆"
        kicker="SYNTHESIS · THE UNIFIED SHELF LADDER"
        accent="#8df0a4"
        title={<>一根轴上的<span className="text-xp">五道刻度</span></>}
        blurb="你新提的两条规则共引入了三个阈值（8 / 18 / 38）。把它们和现行的 12、32 放在同一根数轴上检查：全程单调、互不覆盖、每道刻度只教会玩家一件事——这套阶梯是成立的，而且恰好把「普通书架」从一个配角数值变成了贯穿全程的成长主线。"
      />

      {/* 数轴 */}
      <Reveal>
        <div className="pixelframe bg-abyss/80 border border-arcane/15 p-7 md:p-10 mb-10">
          <div className="flex items-center justify-between mb-10">
            <p className="flex items-center gap-2 font-code text-[11px] tracking-[0.3em] text-xp">
              <Library size={13} /> WOODEN BOOKSHELF AXIS · 0 → 44
            </p>
            <div className="flex gap-2">
              <Chip tone="#f08cc8">本次新增 3 道</Chip>
              <Chip tone="#6f659a">现行 2 道</Chip>
            </div>
          </div>

          <div className="relative h-44 md:h-40">
            {/* base line */}
            <div className="absolute left-0 right-0 top-[86px] h-[2px] bg-gradient-to-r from-arcane/10 via-arcane/30 to-gild/40" />

            {LADDER.map((m, i) => {
              const pct = (m.at / MAXW) * 100;
              const up = i % 2 === 0;
              const active = hover === i;
              return (
                <div
                  key={m.at}
                  className="absolute top-0 bottom-0"
                  style={{ left: `${pct}%` }}
                  onMouseEnter={() => setHover(i)}
                  onMouseLeave={() => setHover(null)}
                >
                  {/* tick */}
                  <motion.div
                    className="absolute w-3 h-3 rotate-45 -translate-x-1/2"
                    style={{
                      top: 80,
                      background: m.tone,
                      boxShadow: `0 0 ${active ? 18 : 8}px ${m.tone}`,
                    }}
                    animate={{ scale: active ? 1.45 : 1 }}
                  />
                  {/* stem */}
                  <div
                    className="absolute w-px -translate-x-1/2"
                    style={{
                      background: `${m.tone}55`,
                      top: up ? 40 : 94,
                      height: 44,
                    }}
                  />
                  {/* label */}
                  <motion.div
                    className="absolute -translate-x-1/2 w-32 md:w-40 text-center"
                    style={{ top: up ? 0 : 140 }}
                    animate={{ y: active ? (up ? -4 : 4) : 0 }}
                  >
                    <p
                      className="font-display font-black text-xl leading-none"
                      style={{ color: m.tone }}
                    >
                      {m.at}
                      {m.isNew && (
                        <span className="font-code text-[8px] align-super ml-0.5 text-inkd">NEW</span>
                      )}
                    </p>
                    <p className="text-[10.5px] leading-4 text-parch mt-1.5">{m.label}</p>
                    <p className="font-code text-[9px] text-faint mt-0.5">{m.sys}</p>
                  </motion.div>
                </div>
              );
            })}
          </div>

          <div className="mt-6 pt-5 border-t border-arcane/10 grid sm:grid-cols-3 gap-4 text-[11.5px] leading-5.5 text-mute font-light">
            <p>
              <span className="text-xp font-medium">单调性 ✓</span>
              <br />8 &lt; 12 &lt; 18 &lt; 32 &lt; 38，无并列、无倒挂，玩家的每一格书架都在朝某个明确目标推进。
            </p>
            <p>
              <span className="text-xp font-medium">职责不重叠 ✓</span>
              <br />残卷（8/18）、计价（12/32）、顿悟（32）、升阶（38）分属四个子系统，仅 32 为双用——而那两项本就同属「毕业线」语义。
            </p>
            <p>
              <span className="text-gild font-medium">终点感 ✓</span>
              <br />38 作为全局最高刻度收尾，恰在顿悟（32）之后：玩家先拿到宝藏顿悟，再拿到满级升阶权，节奏不抢戏。
            </p>
          </div>
        </div>
      </Reveal>

      {/* 风险清单 */}
      <Reveal>
        <div className="flex items-center gap-2 mb-5">
          <CircleAlert size={14} className="text-gild" />
          <p className="font-code text-[11px] tracking-[0.3em] text-gild">
            OPEN QUESTIONS · 落地前仍需拍板的六件事
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {RISKS.map((r, i) => (
            <motion.div
              key={r.t}
              initial={{ opacity: 0, y: 22 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06, duration: 0.6 }}
              className="pixelframe bg-vellum/70 border p-5 hover:-translate-y-1 transition-transform duration-300"
              style={{ borderColor: `${r.tone}28` }}
            >
              <div className="flex items-start justify-between gap-3 mb-2.5">
                <p className="font-medium text-[13.5px] text-parch leading-5">{r.t}</p>
                <span
                  className="font-code text-[10px] px-2 py-0.5 rounded-sm shrink-0 whitespace-nowrap"
                  style={{ color: r.tone, background: `${r.tone}12`, border: `1px solid ${r.tone}35` }}
                >
                  {r.v}
                </span>
              </div>
              <p className="text-[12px] leading-5.5 text-mute font-light">{r.d}</p>
            </motion.div>
          ))}
        </div>
      </Reveal>

      {/* 数据包 */}
      <Reveal>
        <div className="pixelframe bg-vellum/60 border border-arcane/15 p-6 md:p-8 mt-10">
          <p className="flex items-center gap-2 font-code text-[11px] tracking-[0.3em] text-arcane mb-5">
            <Boxes size={13} /> DATAPACK · 两条新规则的落点（新增一个文件，改动一个文件）
          </p>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="rounded-sm bg-obsidian/60 border border-arcane/10 p-5">
              <p className="font-code text-[12px] text-gild mb-3">+ shelf_gates.json（新增）</p>
              <ul className="space-y-1.5 font-code text-[11px] leading-5 text-mute">
                <li>"enabled": true</li>
                <li>"upgrade": &#123; "maxAnchor": 38, "gamma": 0.72 &#125;</li>
                <li>"clampToDirectRoute": true</li>
                <li>"overrides": &#123; "&lt;enchant_id&gt;": [...] &#125;</li>
              </ul>
            </div>
            <div className="rounded-sm bg-obsidian/60 border border-arcane/10 p-5">
              <p className="font-code text-[12px] text-tealw mb-3">~ item_transformations.json（扩展）</p>
              <ul className="space-y-1.5 font-code text-[11px] leading-5 text-mute">
                <li>"blank_overwrite.tiers": [</li>
                <li className="pl-3">&#123; "shelves": 8, "waiveXp": true &#125;,</li>
                <li className="pl-3">&#123; "shelves": 18, "matMultiplier": 0.5 &#125;,</li>
                <li className="pl-3">&#123; "shelves": 18, "distinctTomes": 6, "free": true &#125; ]</li>
              </ul>
            </div>
          </div>
          <p className="mt-5 text-[11.5px] leading-5.5 text-faint font-light">
            两者都是<span className="text-mute">纯阈值配置</span>，不含任何版本相关的注册表引用——
            这意味着同一份数据包可以原样跨 26.x 乃至后续版本使用，这是本轮所有提案里兼容成本最低的一组。
          </p>
        </div>
      </Reveal>
    </section>
  );
};

export default Ladder;
