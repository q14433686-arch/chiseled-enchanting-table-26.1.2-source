import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Layers,
  Undo2,
  Droplets,
  BookX,
  Library,
  ArrowUpFromLine,
  Merge,
  Sparkles,
  X,
  Check,
} from "lucide-react";
import { SectionHead, Reveal, Chip } from "./ui";

/* ── 方案评分矩阵 ── */
const DIMS = ["注册与兼容成本", "跨版本风险", "玩家学习成本", "操作语义清晰", "长期维护面"];
const OPTIONS: {
  id: string;
  name: string;
  sub: string;
  scores: number[]; // 1..5, 越高越好
  tone: string;
  verdict: string;
  winner?: boolean;
}[] = [
  {
    id: "A",
    name: "同面同页",
    sub: "升/降/洗 所有行混排在现有列表",
    scores: [5, 5, 3, 1, 3],
    tone: "#9c93bd",
    verdict: "零改造，但三向操作共用同一行语义与同一材料槽，误触与预览混淆难以避免。",
  },
  {
    id: "B",
    name: "同面 · 双页签",
    sub: "「纂刻 / 研退」两页共用一方块",
    scores: [5, 5, 4, 5, 5],
    tone: "#a18cff",
    verdict: "零新注册、语义一页一向、与教育版式的既有 UI 语言一致 —— 推荐。",
    winner: true,
  },
  {
    id: "C",
    name: "新方块「研退台」",
    sub: "含雕纹书架元素的独立工作站",
    scores: [2, 2, 4, 5, 2],
    tone: "#e8c37c",
    verdict: "幻想感最强，但方块/配方/战利品/模型×11 语言全套注册面，对移植型维护节奏负担过重。可作为未来独立 Add-on 保留。",
  },
];

/* ── 游戏内 UI 模拟 ── */
const CHISEL_ROWS = [
  { icon: Sparkles, label: "附魔：锋利 V", cost: "门槛 Lv.30 · 扣 3 级", tone: "#8df0a4" },
  { icon: Merge, label: "合并：时运 II ×2 → III", cost: "12 级 · 青金石 6", tone: "#e8c37c" },
  { icon: ArrowUpFromLine, label: "升级：保护 III → IV", cost: "增量 ΔV · 紫水晶 2", tone: "#a18cff" },
];
const STRIP_ROWS = [
  { icon: Undo2, label: "降级：锋利 V → IV", cost: "免材料 · 返 +280 pt", tone: "#8df0a4" },
  { icon: Droplets, label: "洗去：时运 III 词条", cost: "蚀咒墨 ×2 · ⌈.3V⌉ 经验", tone: "#f08cc8" },
  { icon: BookX, label: "全部洗去 · 磨平整页", cost: "免费 → 褪魔残卷", tone: "#9c93bd" },
];

const GameMock = () => {
  const [tab, setTab] = useState<0 | 1>(1);
  const rows = tab === 0 ? CHISEL_ROWS : STRIP_ROWS;

  return (
    <div className="pixelframe bg-[#14101f] border-2 border-[#2c2450] overflow-hidden shadow-2xl">
      {/* title bar */}
      <div className="flex items-center justify-between px-5 py-3 bg-[#0d0a17] border-b border-[#2c2450]">
        <div className="flex gap-1">
          {[0, 1].map((i) => (
            <button
              key={i}
              onClick={() => setTab(i as 0 | 1)}
              className="relative px-5 py-2 text-[13px] font-display font-bold transition-all"
              style={{
                color: tab === i ? "#ede6d4" : "#6f659a",
                background: tab === i ? "#241d3d" : "transparent",
                clipPath:
                  "polygon(0 100%, 0 6px, 6px 0, calc(100% - 6px) 0, 100% 6px, 100% 100%)",
              }}
            >
              {i === 0 ? "纂刻" : "研退"}
              {tab === i && (
                <motion.span
                  layoutId="tab-underline"
                  className="absolute bottom-0 left-2 right-2 h-[2px]"
                  style={{ background: i === 0 ? "#a18cff" : "#e8c37c" }}
                />
              )}
            </button>
          ))}
        </div>
        <X size={14} className="text-faint" />
      </div>

      <div className="flex">
        {/* list */}
        <div className="flex-1 p-3 space-y-1.5 min-h-[210px]">
          <AnimatePresence mode="wait">
            <motion.div
              key={tab}
              initial={{ opacity: 0, x: tab === 0 ? -14 : 14 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: tab === 0 ? 14 : -14 }}
              transition={{ duration: 0.28, ease: "easeOut" }}
              className="space-y-1.5"
            >
              {rows.map((r) => (
                <div
                  key={r.label}
                  className="group flex items-center gap-3 px-3 py-2.5 rounded-sm bg-[#1a142c] border border-[#2c2450] hover:border-[#4d3f85] transition-colors cursor-pointer"
                >
                  <r.icon size={15} style={{ color: r.tone }} />
                  <span className="flex-1 text-[12.5px] text-parch">{r.label}</span>
                  <span
                    className="font-code text-[10px] px-2 py-0.5 rounded-sm"
                    style={{ color: r.tone, background: `${r.tone}12`, border: `1px solid ${r.tone}30` }}
                  >
                    {r.cost}
                  </span>
                </div>
              ))}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* slots */}
        <div className="w-[120px] p-3 border-l border-[#2c2450] flex flex-col items-center gap-3">
          <div className="w-14 h-14 bg-[#0d0a17] border border-[#3a2f63] flex flex-col items-center justify-center shadow-inner">
            <span className="text-[9px] font-code text-faint">目标</span>
            <BookX size={16} className="text-arcane mt-1" />
          </div>
          <div className="w-14 h-14 bg-[#0d0a17] border border-[#3a2f63] flex flex-col items-center justify-center shadow-inner">
            <span className="text-[9px] font-code text-faint">{tab === 0 ? "材料" : "蚀咒墨"}</span>
            <Droplets size={16} className={tab === 0 ? "text-arcane mt-1" : "text-inkd mt-1"} />
          </div>
          <span className="font-code text-[9px] text-faint text-center leading-3.5">
            {tab === 0 ? "降级/洗去时\n此槽可空" : "降级与全洗\n无需放入"}
          </span>
        </div>
      </div>

      {/* status bar */}
      <div className="px-4 py-2 bg-[#0d0a17] border-t border-[#2c2450] flex items-center justify-between">
        <span className="font-code text-[10px] text-faint">
          {tab === 0 ? "母本量产模式 · 绿球图标" : "研退模式 · 返还以经验点发放"}
        </span>
        <div className="flex items-center gap-1.5">
          <div className="h-1.5 w-20 rounded-full bg-[#241d3d] overflow-hidden">
            <div className="h-full w-2/3 rounded-full bg-gradient-to-r from-[#8df0a4] to-[#e8c37c]" />
          </div>
          <span className="font-code text-[10px] text-xp">Lv.30</span>
        </div>
      </div>
    </div>
  );
};

const Decision = () => (
  <section id="decision" className="relative max-w-6xl mx-auto px-6 md:px-10 py-24 md:py-36">
    <div
      className="absolute top-40 -right-20 font-display font-black text-[16rem] leading-none select-none pointer-events-none opacity-[0.035]"
      aria-hidden
    >
      决
    </div>

    <SectionHead
      numeral="决"
      kicker="THE DECISION · UX FORM FACTOR"
      title={<>研退栖身何处：<span className="text-arcane">双页同面</span></>}
      blurb="同面同页、双页签、还是一座带雕纹书架元素的新方块？我的答案：现在做「同面双页签」，把雕纹书架的幻想从「方块形态」转译为「增益场」，并为未来预留无迁移升级的余地。"
    />

    {/* 评分矩阵 */}
    <Reveal>
      <div className="grid md:grid-cols-3 gap-4 mb-12">
        {OPTIONS.map((o) => (
          <div
            key={o.id}
            className="pixelframe bg-vellum/70 border p-6 flex flex-col"
            style={{
              borderColor: o.winner ? "#a18cff55" : "rgba(161,140,255,0.12)",
              boxShadow: o.winner ? "0 0 40px rgba(161,140,255,0.12)" : undefined,
            }}
          >
            <div className="flex items-center justify-between mb-3">
              <span
                className="font-display font-black text-2xl"
                style={{ color: o.tone }}
              >
                {o.id}
              </span>
              {o.winner ? (
                <Chip tone="#a18cff">
                  <Check size={11} /> 推荐
                </Chip>
              ) : (
                <Chip tone="#6f659a">备选</Chip>
              )}
            </div>
            <p className="font-display font-bold text-lg text-parch">{o.name}</p>
            <p className="text-[11px] text-faint mt-0.5 mb-5">{o.sub}</p>
            <div className="space-y-2.5 mb-5 flex-1">
              {DIMS.map((d, i) => (
                <div key={d} className="flex items-center gap-2.5">
                  <span className="w-24 shrink-0 text-[10.5px] text-mute">{d}</span>
                  <div className="flex gap-1">
                    {Array.from({ length: 5 }).map((_, k) => (
                      <motion.span
                        key={k}
                        initial={{ opacity: 0, scale: 0 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        viewport={{ once: true }}
                        transition={{ delay: 0.35 + i * 0.08 + k * 0.04 }}
                        className="w-2.5 h-2.5 rotate-45"
                        style={{
                          background: k < o.scores[i] ? o.tone : "rgba(111,101,154,0.25)",
                        }}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <p className="text-[12px] leading-5.5 text-mute font-light border-t border-arcane/10 pt-4">
              {o.verdict}
            </p>
          </div>
        ))}
      </div>
    </Reveal>

    <div className="grid lg:grid-cols-2 gap-6 items-start">
      {/* 理由 */}
      <Reveal className="space-y-4">
        {[
          {
            t: "一字之蕴：「纂」本含修订",
            d: "纂，编集修订也；刻，亦刻亦磨。刻入与磨去是同一门手艺的两面——一台两页，工艺概念完整自洽，无需向世界再解释一座新方块的存在。",
            tone: "#a18cff",
          },
          {
            t: "零新增注册面 = 最佳向上兼容",
            d: "不注册新方块就没有新的存档数据、世界生成、配方迁移与 11 语言物料，跨 26.x 及后续版本的移植成本几乎为零——对「社区移植」的维护节奏尤其关键。",
            tone: "#8df0a4",
          },
          {
            t: "雕纹书架不消失，化作增益场",
            d: "研退页坐享母本的对称庇护：被母本记录的魔咒 = 留有原样档案，退刻更安全。洗去经验按 ⌈15%·r(e)^1.5⌉ 减免——直接复用现成的母本公式族，幻想与机制两全。",
            tone: "#e8c37c",
          },
          {
            t: "页状态不落盘，给方案 C 留后门",
            d: "研退逻辑实现为独立的「模式」而非方块数据，页签状态不写入方块 NBT。若日后真要拆出独立研退台，玩家世界零内容迁移、零方块替换。",
            tone: "#f08cc8",
          },
        ].map((r, i) => (
          <div
            key={r.t}
            className="flex gap-4 pixelframe bg-abyss/70 border border-arcane/12 p-5 hover:border-arcane/25 transition-colors"
          >
            <span
              className="font-display font-black text-xl shrink-0 w-8 text-center"
              style={{ color: r.tone }}
            >
              {["壹", "贰", "叁", "肆"][i]}
            </span>
            <div>
              <p className="font-medium text-[14.5px] text-parch mb-1">{r.t}</p>
              <p className="text-[12.5px] leading-6 text-mute font-light">{r.d}</p>
            </div>
          </div>
        ))}
      </Reveal>

      {/* 游戏内 UI 模拟 */}
      <Reveal delay={0.12}>
        <div className="relative">
          <div className="absolute -inset-4 bg-arcane-deep/10 blur-2xl rounded-full pointer-events-none" />
          <GameMock />
          <div className="mt-4 flex items-center justify-center gap-2 text-faint">
            <Layers size={13} />
            <span className="font-code text-[10.5px] tracking-[0.2em]">
              可交互原型 · 点击页签切换「纂刻 / 研退」
            </span>
          </div>
          <div className="mt-6 pixelframe bg-vellum/60 border border-gild/25 p-5 flex gap-4 items-start">
            <Library size={18} className="text-gild shrink-0 mt-0.5" />
            <p className="text-[12.5px] leading-6 text-mute font-light">
              <span className="text-parch font-medium">雕纹书架元素落点：</span>
              7×5×7 扫描范围内的母本为研退页提供 ⌈15%·r^1.5⌉ 的洗去减免与返还加成动画
              （符文粒子由书架流向台面，现成粒子系统直接反向播放）——
              「雕刻书架」以场而非方块的身份参与了这场研退仪式。
            </p>
          </div>
        </div>
      </Reveal>
    </div>
  </section>
);

export default Decision;
