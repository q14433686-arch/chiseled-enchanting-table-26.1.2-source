import { motion } from "framer-motion";
import type { ReactNode } from "react";
import { cn } from "../utils/cn";

export const Reveal = ({
  children,
  delay = 0,
  className,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) => (
  <motion.div
    className={className}
    initial={{ opacity: 0, y: 34 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true, margin: "-60px" }}
    transition={{ duration: 0.85, delay, ease: [0.22, 1, 0.36, 1] }}
  >
    {children}
  </motion.div>
);

export const SectionHead = ({
  numeral,
  kicker,
  title,
  blurb,
  accent = "#e8c37c",
}: {
  numeral: string;
  kicker: string;
  title: ReactNode;
  blurb: string;
  accent?: string;
}) => (
  <div className="relative mb-14 md:mb-20">
    <Reveal>
      <div className="flex items-end gap-5 md:gap-8">
        <span
          className="font-display text-[5.2rem] md:text-[7.5rem] leading-[0.85] font-black select-none"
          style={{
            color: "transparent",
            WebkitTextStroke: `1.5px ${accent}55`,
          }}
        >
          {numeral}
        </span>
        <div className="pb-2 md:pb-4">
          <p
            className="font-code text-[11px] md:text-xs tracking-[0.35em] uppercase mb-2 md:mb-3"
            style={{ color: accent }}
          >
            {kicker}
          </p>
          <h2 className="font-display text-3xl md:text-5xl font-bold leading-tight text-parch">
            {title}
          </h2>
        </div>
      </div>
    </Reveal>
    <Reveal delay={0.12}>
      <p className="mt-5 max-w-2xl text-sm md:text-[15px] leading-7 text-mute font-light">
        {blurb}
      </p>
    </Reveal>
    <div className="gold-rule mt-8 opacity-60" />
  </div>
);

export const Chip = ({
  children,
  tone = "#a18cff",
}: {
  children: ReactNode;
  tone?: string;
}) => (
  <span
    className="inline-flex items-center gap-1.5 rounded-sm px-2.5 py-1 text-[11px] font-code tracking-wider"
    style={{
      color: tone,
      background: `${tone}14`,
      border: `1px solid ${tone}33`,
    }}
  >
    {children}
  </span>
);

export const FormulaCard = ({
  title,
  rows,
  tone = "#e8c37c",
}: {
  title: string;
  rows: { lhs: string; rhs: string }[];
  tone?: string;
}) => (
  <div
    className="pixelframe relative overflow-hidden bg-vellum/80 p-6 md:p-8"
    style={{ border: "1px solid rgba(161,140,255,0.16)" }}
  >
    <div
      className="absolute -top-10 -right-10 w-40 h-40 rounded-full blur-3xl opacity-20"
      style={{ background: tone }}
    />
    <p
      className="font-code text-[11px] tracking-[0.3em] uppercase mb-5"
      style={{ color: tone }}
    >
      {title}
    </p>
    <div className="space-y-3.5">
      {rows.map((r, i) => (
        <div key={i} className="flex flex-col md:flex-row md:items-baseline gap-1 md:gap-4">
          <span className="font-code text-sm md:text-[15px] text-parch font-medium shrink-0">
            {r.lhs}
          </span>
          <span className="hidden md:block flex-1 border-b border-dashed border-arcane/20 translate-y-[-4px]" />
          <span className="font-code text-xs md:text-[13px] text-mute">{r.rhs}</span>
        </div>
      ))}
    </div>
  </div>
);

export const BarRow = ({
  label,
  value,
  max,
  color,
  suffix,
  delay = 0,
}: {
  label: string;
  value: number;
  max: number;
  color: string;
  suffix: string;
  delay?: number;
}) => (
  <div className="flex items-center gap-3">
    <span className="w-16 shrink-0 text-[11px] font-code text-mute text-right">{label}</span>
    <div className="flex-1 h-7 rounded-sm bg-obsidian/80 border border-arcane/10 overflow-hidden relative">
      <motion.div
        className="h-full rounded-sm"
        style={{
          background: `linear-gradient(90deg, ${color}cc, ${color})`,
          boxShadow: `0 0 18px ${color}55`,
        }}
        initial={false}
        animate={{ width: `${Math.max(2.5, (value / Math.max(1, max)) * 100)}%` }}
        transition={{ type: "spring", stiffness: 120, damping: 20, delay }}
      />
    </div>
    <span
      className="w-24 shrink-0 font-code text-[13px] font-semibold tabular-nums"
      style={{ color }}
    >
      {value.toLocaleString("zh-CN")}
      <span className="text-[10px] text-mute ml-1">{suffix}</span>
    </span>
  </div>
);

export const Slider = ({
  label,
  value,
  min,
  max,
  onChange,
  format,
  accent = "#e8c37c",
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  onChange: (v: number) => void;
  format?: (v: number) => string;
  accent?: string;
}) => (
  <div>
    <div className="flex justify-between items-baseline mb-2">
      <span className="text-xs text-mute">{label}</span>
      <span className="font-code text-sm font-semibold" style={{ color: accent }}>
        {format ? format(value) : value}
      </span>
    </div>
    <input
      type="range"
      className={cn("slider w-full")}
      min={min}
      max={max}
      value={value}
      onChange={(ev) => onChange(Number(ev.target.value))}
    />
  </div>
);
