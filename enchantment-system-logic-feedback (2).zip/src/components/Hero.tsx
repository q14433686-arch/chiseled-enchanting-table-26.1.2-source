import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import {
  TrendingDown,
  Undo2,
  Droplets,
  Layers,
  Library,
  BookX,
  ShieldAlert,
  ChevronDown,
  ExternalLink,
} from "lucide-react";

const GLYPHS = "ᚠᚢᚦᚨᚱᚲᚷᚹᚺᚾᛁᛃᛇᛈᛉᛊᛏᛒᛖᛗᛚᛜᛞᛟ✦✧᛭".split("");

const RuneCanvas = () => {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let w = 0;
    let h = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const mouse = { x: -9999, y: -9999 };

    const resize = () => {
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    interface P {
      x: number; y: number; vy: number; vx: number;
      g: string; s: number; a: number; ph: number; hue: number;
    }
    const count = Math.min(90, Math.floor((window.innerWidth * 700) / 16000));
    const parts: P[] = Array.from({ length: count }, () => ({
      x: Math.random() * window.innerWidth,
      y: Math.random() * 800,
      vy: 0.12 + Math.random() * 0.4,
      vx: (Math.random() - 0.5) * 0.15,
      g: GLYPHS[Math.floor(Math.random() * GLYPHS.length)],
      s: 10 + Math.random() * 22,
      a: 0.06 + Math.random() * 0.3,
      ph: Math.random() * Math.PI * 2,
      hue: Math.random() < 0.72 ? 252 : 40,
    }));

    const onMove = (e: MouseEvent) => {
      const r = canvas.getBoundingClientRect();
      mouse.x = e.clientX - r.left;
      mouse.y = e.clientY - r.top;
    };
    window.addEventListener("mousemove", onMove);

    let t = 0;
    const tick = () => {
      t += 0.016;
      ctx.clearRect(0, 0, w, h);
      for (const p of parts) {
        p.y -= p.vy;
        p.x += p.vx + Math.sin(t * 0.6 + p.ph) * 0.12;
        if (p.y < -40) {
          p.y = h + 30;
          p.x = Math.random() * w;
        }
        if (p.x < -40) p.x = w + 30;
        if (p.x > w + 40) p.x = -30;
        const dx = mouse.x - p.x;
        const dy = mouse.y - p.y;
        const d2 = dx * dx + dy * dy;
        let glow = 0;
        if (d2 < 160 * 160) {
          const f = 1 - Math.sqrt(d2) / 160;
          p.x += dx * 0.012 * f;
          p.y += dy * 0.012 * f;
          glow = f;
        }
        const tw = p.a * (0.55 + 0.45 * Math.sin(t * 1.4 + p.ph)) + glow * 0.5;
        ctx.font = `${p.s}px "Noto Serif SC", serif`;
        ctx.fillStyle =
          p.hue === 252
            ? `rgba(161,140,255,${Math.min(0.85, tw)})`
            : `rgba(232,195,124,${Math.min(0.85, tw)})`;
        ctx.fillText(p.g, p.x, p.y);
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onMove);
    };
  }, []);

  return <canvas ref={ref} className="absolute inset-0 w-full h-full" aria-hidden />;
};

const CARDS = [
  {
    icon: ShieldAlert,
    no: "新 · 审查",
    title: "11 条发现",
    desc: "已克隆分支实读实算：2 严重 / 2 高 / 4 中 / 3 低，含一个可复现的经验套利漏洞。",
    tone: "#ff6b8a",
    href: "#audit",
  },
  {
    icon: TrendingDown,
    no: "问一",
    title: "升阶当省",
    desc: "材料升级与普通附魔同价，直觉断裂。引入铭刻价值曲线，升阶只收增量 ΔV。",
    tone: "#e8c37c",
    href: "#upgrade",
  },
  {
    icon: Undo2,
    no: "问二",
    title: "降阶当返",
    desc: "磨浅刻痕不该再收费。降级免材料、按 ρ 返还经验点数——同一曲线的逆运算。",
    tone: "#8df0a4",
    href: "#refund",
  },
  {
    icon: Droplets,
    no: "问三",
    title: "洗条当费",
    desc: "定向剔除词条是精细手术：蚀咒墨 + 经验；整页磨平则免费，产出褪魔残卷。",
    tone: "#f08cc8",
    href: "#wash",
  },
  {
    icon: Library,
    no: "补一",
    title: "升阶准入",
    desc: "38 架解锁 MAX，中间等级幂次铺阶——并加一道「永不高于直附」的非回归钳制。",
    tone: "#7ee8dc",
    href: "#gate",
  },
  {
    icon: BookX,
    no: "补二",
    title: "残卷三梯",
    desc: "8 架免经验 / 18 架材料折半 / 再加六种合格母本则完全免费。去重是关键。",
    tone: "#8df0a4",
    href: "#residue",
  },
  {
    icon: Layers,
    no: "一决",
    title: "双页同面",
    desc: "不做新方块。「纂刻 / 研退」双页签共用一台——注册零增量，雕纹书架化作增益场。",
    tone: "#a18cff",
    href: "#decision",
  },
];

const Hero = () => (
  <header className="relative min-h-[100svh] flex flex-col overflow-hidden">
    <div className="absolute inset-0 grid-paper" />
    <div
      className="absolute inset-0"
      style={{
        background:
          "radial-gradient(1100px 520px at 50% 18%, rgba(109,94,240,0.16), transparent 65%), radial-gradient(700px 420px at 82% 88%, rgba(232,195,124,0.07), transparent 60%)",
      }}
    />
    <RuneCanvas />

    {/* top bar */}
    <div className="relative z-10 flex items-center justify-between px-6 md:px-12 pt-7">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 pixelframe bg-arcane-deep/25 border border-arcane/30 flex items-center justify-center glow-arcane">
          <span className="font-display font-black text-arcane text-lg">纂</span>
        </div>
        <div className="leading-tight">
          <p className="font-display font-bold text-sm tracking-wide">纂刻附魔台</p>
          <p className="font-code text-[10px] text-faint tracking-[0.25em]">
            CHISELED ENCHANTING · 26.1.2 PORT
          </p>
        </div>
      </div>
      <a
        href="https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source"
        target="_blank"
        rel="noreferrer"
        className="hidden md:flex items-center gap-2 font-code text-[11px] text-mute hover:text-parch transition-colors tracking-widest"
      >
        <ExternalLink size={14} />
        1.1.0 → 提案 1.2
      </a>
    </div>

    {/* hero core */}
    <div className="relative z-10 flex-1 flex flex-col items-center justify-center text-center px-6 pt-10 pb-8">
      <motion.p
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="font-code text-[11px] md:text-xs tracking-[0.5em] text-gild uppercase mb-6"
      >
        经济曲线 · 直觉修正 · 设计方向
      </motion.p>

      <motion.h1
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
        className="font-display font-black leading-[1.04] text-parch"
        style={{ fontSize: "clamp(3rem, 9.5vw, 8rem)" }}
      >
        刻有所值
        <br />
        <span
          style={{
            background: "linear-gradient(105deg, #a18cff 10%, #e8c37c 55%, #f08cc8 95%)",
            WebkitBackgroundClip: "text",
            backgroundClip: "text",
            color: "transparent",
          }}
        >
          退有所偿
        </span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, delay: 0.28, ease: [0.22, 1, 0.36, 1] }}
        className="mt-7 max-w-2xl text-sm md:text-base leading-8 text-mute font-light"
      >
        关于附魔书<span className="text-parch">升阶折减</span>、
        <span className="text-parch">降阶返还</span>与
        <span className="text-parch">词条褪去</span>的三个直觉问题，
        以及「研退」应当栖身何处的形态决断——
        <br className="hidden md:block" />
        答案是<span className="text-gild text-glow-gild font-medium">一条价值曲线，两个方向</span>。
      </motion.p>

      {/* anchor cards */}
      <div className="mt-12 md:mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4 w-full max-w-5xl">
        {CARDS.map((c, i) => (
          <motion.a
            key={c.no}
            href={c.href}
            initial={{ opacity: 0, y: 26 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.42 + i * 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="group pixelframe bg-vellum/60 border border-arcane/15 p-5 text-left backdrop-blur-sm hover:bg-vellum2/80 transition-all duration-300 hover:-translate-y-1"
            style={{ boxShadow: "0 1px 0 rgba(161,140,255,0.08)" }}
          >
            <div className="flex items-center justify-between mb-3">
              <span
                className="font-code text-[10px] tracking-[0.3em]"
                style={{ color: c.tone }}
              >
                {c.no}
              </span>
              <c.icon
                size={17}
                style={{ color: c.tone }}
                className="transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-6"
              />
            </div>
            <p className="font-display font-bold text-lg text-parch mb-1.5">{c.title}</p>
            <p className="text-[12px] leading-5.5 text-mute font-light">{c.desc}</p>
          </motion.a>
        ))}
      </div>
    </div>

    {/* rune marquee */}
    <div className="relative z-10 border-t border-arcane/10 py-3 overflow-hidden">
      <div className="rune-marquee flex whitespace-nowrap gap-10 w-max opacity-30">
        {Array.from({ length: 2 }).map((_, k) => (
          <div key={k} className="flex gap-10 font-display text-sm text-arcane">
            {"ᚠ ᚢ ᚦ ᚨ ᚱ ᚲ ᚷ ᚹ ᚺ ᚾ ᛁ ᛃ V(e,L) = Σ 铭刻价值 ᛇ ᛈ ᛉ ᛊ ᛏ ᛒ ΔV 付增量 ᛖ ᛗ ρ·ΔV 返半值 ᛚ ᛜ σ·V 洗词条 ᛞ ᛟ ✦".split(" ").map((g, i) => (
              <span key={i}>{g}</span>
            ))}
          </div>
        ))}
      </div>
    </div>

    <motion.div
      className="relative z-10 flex justify-center pb-6"
      animate={{ y: [0, 8, 0] }}
      transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
    >
      <ChevronDown size={18} className="text-faint" />
    </motion.div>
  </header>
);

export default Hero;
