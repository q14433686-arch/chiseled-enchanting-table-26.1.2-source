import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Library, Lock, LockOpen, TriangleAlert, GitBranch, Ruler } from "lucide-react";
import { ENCHANTS, RARITY_COLOR, ROMAN } from "../lib/enchant";
import {
  SHELF_UPGRADE_MAX,
  upgradeGateLadder,
  directEnchantGate,
} from "../lib/shelves";
import { SectionHead, Reveal, FormulaCard, Slider, Chip } from "./ui";

const GateLadder = () => {
  const [enchantId, setEnchantId] = useState("sharpness");
  const [gamma, setGamma] = useState(72);
  const [shelves, setShelves] = useState(24);

  const e = ENCHANTS.find((x) => x.id === enchantId)!;
  const ladder = useMemo(() => upgradeGateLadder(e.max, gamma / 100), [e, gamma]);
  const mid = Math.ceil(e.max / 2);
  const unlocked = ladder.filter((s) => s <= shelves).length;

  return (
    <section id="gate" className="relative max-w-6xl mx-auto px-6 md:px-10 py-24 md:py-36">
      <div
        className="absolute top-40 -left-20 font-display font-black text-[16rem] leading-none select-none pointer-events-none opacity-[0.035]"
        aria-hidden
      >
        阶
      </div>

      <SectionHead
        numeral="肆"
        kicker="ADDENDUM 01 · SHELF-GATED UPGRADE"
        accent="#f08cc8"
        title={<>升阶的<span className="text-inkd">准入</span>：38 架见顶的分级阶梯</>}
        blurb="你的规则我完全赞同，并且它恰好补上了第壹问留下的缺口：ΔV 解决了「多少钱」，书架阶梯解决了「够不够格」。两条轴正交，母本路线原样不动。但中间等级的取整算法必须服从一条硬约束，否则会和现行直附曲线打架。"
      />

      {/* 核心约束 */}
      <Reveal>
        <div className="pixelframe bg-gradient-to-br from-vellum to-vellum2/60 border border-inkd/25 p-7 md:p-9 mb-8">
          <div className="flex items-start gap-4">
            <TriangleAlert className="text-inkd shrink-0 mt-1" size={22} />
            <div>
              <p className="font-display text-xl md:text-2xl font-bold text-parch leading-relaxed">
                必须加一条「非回归钳制」：升阶门槛永不高于直附门槛。
              </p>
              <p className="mt-3 text-sm leading-7 text-mute font-light">
                现制下普通书架已能把常规魔咒<span className="text-parch">直接纂刻</span>到中阶上限
                <span className="font-code text-arcane"> ⌈M/2⌉</span>。如果纯按幂函数铺门槛，
                就可能出现「<span className="text-inkd">24 架能直接刻出 III，却要 26 架才准把 II 升成 III</span>」
                的荒谬局面——玩家会发现<span className="text-parch">把书洗掉重刻反而更快</span>，
                第壹问刚建立的「升阶更省」直觉当场崩塌。
                所以取整后必须再过一道 <span className="font-code text-xp">S_up(L) = min(S_up(L), S_直附(L))</span>，
                并强制严格单调。
              </p>
            </div>
          </div>
        </div>
      </Reveal>

      <div className="grid lg:grid-cols-5 gap-6">
        <Reveal className="lg:col-span-2 space-y-6">
          <FormulaCard
            tone="#f08cc8"
            title="分级算法 · 幂次铺台阶"
            rows={[
              { lhs: "S_up(M)", rhs: "= 38（锚点，你指定的 MAX 门槛）" },
              { lhs: "S_up(L)", rhs: "= ⌈ 38 · ((L−1)/(M−1))^γ ⌉，γ 默认 0.72" },
              { lhs: "钳制一", rhs: "≤ S_直附(L)，L ≤ ⌈M/2⌉ 时生效" },
              { lhs: "钳制二", rhs: "严格单调：S(L) > S(L−1)，撞车则 +1" },
              { lhs: "M = 1", rhs: "无升阶路线，阶梯为空（经验修补等）" },
            ]}
          />
          <div className="pixelframe bg-abyss/70 border border-arcane/15 p-6">
            <p className="flex items-center gap-2 font-code text-[11px] tracking-[0.25em] text-inkd mb-4">
              <Ruler size={13} /> 为什么是幂函数，而不是等差
            </p>
            <ul className="space-y-3 text-[13px] leading-6 text-mute font-light">
              <li className="flex gap-2.5">
                <span className="text-inkd mt-0.5">◆</span>
                <span>
                  <span className="text-parch">γ &lt; 1（凹）</span>：前段台阶陡、后段平。
                  早期每造几格书架就能看见进度，适合拓荒期正反馈——<span className="text-parch">默认选它</span>。
                </span>
              </li>
              <li className="flex gap-2.5">
                <span className="text-inkd mt-0.5">◆</span>
                <span>
                  <span className="text-parch">γ &gt; 1（凸）</span>：前段白送、最后一级筑高墙。
                  毕业感更强，但中期会有一长段「造了书架却什么都没解锁」的空窗。
                </span>
              </li>
              <li className="flex gap-2.5">
                <span className="text-inkd mt-0.5">◆</span>
                <span>
                  等差铺台阶在 <span className="font-code">M=10</span> 的模组魔咒上会退化成「每 4 格解锁一级」的流水账，
                  幂函数则天然适配任意 M——这正是<span className="text-parch">兼容第三方模组</span>的要害。
                </span>
              </li>
              <li className="flex gap-2.5">
                <span className="text-gild mt-0.5">◆</span>
                <span>
                  γ 与锚点 38 全部写进 <span className="font-code text-gild">shelf_gates.json</span>，
                  并支持 per-enchant 覆写：服主想给某个魔咒开特例，不必改代码。
                </span>
              </li>
            </ul>
          </div>
        </Reveal>

        {/* 阶梯模拟器 */}
        <Reveal className="lg:col-span-3" delay={0.1}>
          <div className="pixelframe bg-vellum/70 border border-inkd/20 overflow-hidden">
            <div className="flex items-center justify-between px-6 md:px-8 py-4 border-b border-arcane/10">
              <p className="font-code text-[11px] tracking-[0.3em] text-inkd flex items-center gap-2">
                <GitBranch size={13} /> GATE LADDER · 阶梯模拟器
              </p>
              <Chip tone={unlocked >= e.max ? "#8df0a4" : "#6f659a"}>
                已解锁 {unlocked} / {e.max} 级
              </Chip>
            </div>

            <div className="p-6 md:p-8 space-y-7">
              <div className="flex flex-wrap gap-2">
                {ENCHANTS.filter((x) => x.max > 1).map((x) => (
                  <button
                    key={x.id}
                    onClick={() => setEnchantId(x.id)}
                    className="px-3.5 py-2 rounded-sm text-[12px] font-medium transition-all border"
                    style={{
                      color: enchantId === x.id ? "#0a0913" : RARITY_COLOR[x.rarity],
                      background:
                        enchantId === x.id ? RARITY_COLOR[x.rarity] : `${RARITY_COLOR[x.rarity]}0d`,
                      borderColor: `${RARITY_COLOR[x.rarity]}44`,
                    }}
                  >
                    {x.name}
                    <span className="font-code text-[10px] ml-1.5 opacity-70">M={x.max}</span>
                  </button>
                ))}
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <Slider
                  label="范围内普通书架数"
                  value={shelves}
                  min={0}
                  max={44}
                  onChange={setShelves}
                  format={(v) => `${v} 格`}
                  accent="#e8c37c"
                />
                <Slider
                  label="曲线指数 γ"
                  value={gamma}
                  min={40}
                  max={180}
                  onChange={setGamma}
                  format={(v) => (v / 100).toFixed(2)}
                  accent="#f08cc8"
                />
              </div>

              {/* 阶梯条 */}
              <div className="space-y-2">
                {ladder.map((need, i) => {
                  const L = i + 1;
                  const ok = need <= shelves;
                  const isMax = L === e.max;
                  const direct = directEnchantGate(e.max, L);
                  return (
                    <motion.div
                      key={L}
                      layout
                      className="flex items-center gap-3 px-4 py-3 rounded-sm border transition-colors"
                      style={{
                        background: ok ? "rgba(141,240,164,0.05)" : "rgba(10,9,19,0.6)",
                        borderColor: ok ? "rgba(141,240,164,0.25)" : "rgba(161,140,255,0.1)",
                      }}
                    >
                      {ok ? (
                        <LockOpen size={14} className="text-xp shrink-0" />
                      ) : (
                        <Lock size={14} className="text-faint shrink-0" />
                      )}
                      <span
                        className="font-display font-bold text-base w-10 shrink-0"
                        style={{ color: ok ? "#ede6d4" : "#6f659a" }}
                      >
                        {ROMAN[L]}
                      </span>
                      <div className="flex-1 h-2 rounded-full bg-obsidian/80 overflow-hidden relative">
                        <motion.div
                          className="h-full rounded-full"
                          style={{
                            background: ok
                              ? "linear-gradient(90deg,#8df0a4aa,#8df0a4)"
                              : "linear-gradient(90deg,#f08cc855,#f08cc8aa)",
                          }}
                          animate={{
                            width: `${Math.min(100, (need / SHELF_UPGRADE_MAX) * 100)}%`,
                          }}
                          transition={{ type: "spring", stiffness: 140, damping: 20 }}
                        />
                      </div>
                      <span
                        className="font-code text-[11px] w-20 text-right shrink-0 tabular-nums"
                        style={{ color: ok ? "#8df0a4" : "#9c93bd" }}
                      >
                        {L === 1 ? "无门槛" : `${need} 架`}
                      </span>
                      <span className="font-code text-[9.5px] w-16 text-right shrink-0 text-faint">
                        {isMax ? "MAX" : direct !== null ? `直附${direct}` : "仅升阶"}
                      </span>
                    </motion.div>
                  );
                })}
              </div>

              <div className="flex items-start gap-2.5 text-[11px] leading-5 text-faint font-light">
                <Library size={13} className="shrink-0 mt-0.5 text-gild/60" />
                <span>
                  中阶上限 ⌈M/2⌉ = {ROMAN[mid]}：之内两路并行（取较低门槛），之上为升阶路线独占。
                  母本路线完全不受本阶梯约束——雕纹书架里有母本，照旧 1~L 级直接解锁、走量产模式。
                  38 架 &gt; 32 架（顿悟门槛），意味着解锁满级升阶的玩家<span className="text-mute">必然已经拥有顿悟</span>，阶梯顺序自洽。
                </span>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default GateLadder;
