import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { TrendingDown, BookOpen, Sparkles, AlertTriangle } from "lucide-react";
import {
  ENCHANTS,
  MATERIALS,
  RARITY_LABEL,
  RARITY_COLOR,
  ROMAN,
  valueCurve,
  materialAt,
  currentUpgradeXp,
  proposedUpgradeXp,
  proposedUpgradeMat,
  approxLevelFromPoints,
  fmt,
} from "../lib/enchant";
import { SectionHead, Reveal, FormulaCard, BarRow, Slider, Chip } from "./ui";

const Upgrade = () => {
  const [enchantId, setEnchantId] = useState("sharpness");
  const [matId, setMatId] = useState("lapis");
  const [from, setFrom] = useState(2);
  const [to, setTo] = useState(3);
  const [discount, setDiscount] = useState(0.25);

  const e = ENCHANTS.find((x) => x.id === enchantId)!;
  const mat = MATERIALS.find((m) => m.id === matId)!;

  const calc = useMemo(() => {
    const f = Math.min(from, e.max - 1);
    const t = Math.max(to, f + 1);
    const curXp = currentUpgradeXp(e, t, discount);
    const newXp = proposedUpgradeXp(e, f, t, discount);
    const curMat = materialAt(e, t, mat);
    const newMat = proposedUpgradeMat(e, f, t, mat);
    return {
      f, t, curXp, newXp, curMat, newMat,
      dv: valueCurve(e, t) - valueCurve(e, f),
      savedXp: curXp - newXp,
      savedMat: curMat - newMat,
    };
  }, [e, from, to, discount, mat]);

  const pctXp = Math.round((1 - calc.newXp / Math.max(1, calc.curXp)) * 100);
  const pctMat = Math.round((1 - calc.newMat / Math.max(1, calc.curMat)) * 100);
  const barMax = Math.max(calc.curXp, calc.newXp, 1);
  const barMaxM = Math.max(calc.curMat, calc.newMat, 1);

  return (
    <section id="upgrade" className="relative max-w-6xl mx-auto px-6 md:px-10 py-24 md:py-36">
      <div
        className="absolute top-40 -left-24 font-display font-black text-[16rem] leading-none select-none pointer-events-none opacity-[0.035]"
        aria-hidden
      >
        升
      </div>

      <SectionHead
        numeral="壹"
        kicker="PROBLEM 01 · UPGRADE PRICING"
        title={<>升阶只应付<span className="text-gild">增量</span></>}
        blurb="现状：把一本锋利 II 放入上槽、以材料直接突破至 III，竟与「从无到有直接纂刻 III」同价。直觉上，书里已被支付过的等级不该再收一次费——无论它已达到常规附魔的最高阶，还是正被雕纹书架中的母本覆盖。"
      />

      {/* 核心主张：一条价值曲线 */}
      <Reveal>
        <div className="pixelframe relative overflow-hidden bg-gradient-to-br from-vellum to-vellum2/60 border border-gild/20 p-7 md:p-10 mb-8">
          <div className="absolute -top-16 -right-16 w-64 h-64 rounded-full bg-gild/10 blur-3xl" />
          <div className="flex items-start gap-4">
            <BookOpen className="text-gild shrink-0 mt-1" size={22} />
            <div>
              <p className="font-display text-xl md:text-2xl font-bold text-parch leading-relaxed">
                定义「铭刻价值曲线」<span className="font-code text-gild">V(e, L)</span>
                ：一本 L 级附魔书 = 一份已被支付过价值的资产。
              </p>
              <p className="mt-3 text-sm leading-7 text-mute font-light">
                升阶不是重新书写，而是<span className="text-parch">续刻</span>——只收取两档之间的差额
                <span className="font-code text-xp"> ΔV = V(new) − V(cur)</span>。
                曲线只依赖<span className="text-parch">相对品阶 L / M</span>与
                <span className="text-parch">稀有度倍率</span>，与母本系统既有的
                <span className="font-code text-arcane"> r(e) = L/M </span>
                同族同源，因此对任意第三方模组魔咒自动成立——这正回答了你的「兼容性怎么算」。
              </p>
            </div>
          </div>
        </div>
      </Reveal>

      <div className="grid lg:grid-cols-5 gap-6">
        {/* 公式卡 */}
        <Reveal className="lg:col-span-2" delay={0.05}>
          <div className="space-y-6">
            <FormulaCard
              title="升阶计费 · 提案公式"
              rows={[
                { lhs: "V(e,L)", rhs: "= ⌈ 112 · L · μ_r ⌉ 经验点 · 30级宽度封顶" },
                { lhs: "XP_升", rhs: "= ⌈ ΔV · (1 − 书库减免) ⌉，下限 ⌈V(new)·8%⌉" },
                { lhs: "材料_升", rhs: "= max(1, ⌈ Mat(new) · (new−cur)/M ⌉)" },
                { lhs: "书库减免", rhs: "复用现制：公共 ≤25% + 母本 ≤15%，总顶 −40%" },
              ]}
            />
            <div className="pixelframe bg-abyss/70 border border-arcane/15 p-6">
              <p className="flex items-center gap-2 font-code text-[11px] tracking-[0.25em] text-arcane mb-4">
                <Sparkles size={13} /> 两条既有系统的衔接
              </p>
              <ul className="space-y-3 text-[13px] leading-6 text-mute font-light">
                <li className="flex gap-2.5">
                  <span className="text-gild mt-0.5">◆</span>
                  <span>某等级已被母本覆盖？直接走现有<span className="text-parch">量产模式（扣 1–3 级）</span>——折减只作用于「无母本可借」的路径，两者互不重叠、互不套利。</span>
                </li>
                <li className="flex gap-2.5">
                  <span className="text-gild mt-0.5">◆</span>
                  <span>材料按<span className="text-parch">跨越级数 / 总级数</span>折算并保底 1 件——I→II 与 IV→V 一步之差，价格梯度自然拉开。</span>
                </li>
                <li className="flex gap-2.5">
                  <span className="text-gild mt-0.5">◆</span>
                  <span>8% 经验下限防「零元续刻」，保留最低仪式感。</span>
                </li>
              </ul>
            </div>
          </div>
        </Reveal>

        {/* 交互演示 */}
        <Reveal className="lg:col-span-3" delay={0.12}>
          <div className="pixelframe bg-vellum/70 border border-arcane/20 overflow-hidden">
            <div className="flex items-center justify-between px-6 md:px-8 py-4 border-b border-arcane/10">
              <p className="font-code text-[11px] tracking-[0.3em] text-gild flex items-center gap-2">
                <TrendingDown size={13} /> REFINERY SIMULATOR · 升阶模拟器
              </p>
              <Chip tone="#6f659a">数据为提案模型演示</Chip>
            </div>

            <div className="p-6 md:p-8 space-y-7">
              {/* 选择器 */}
              <div className="flex flex-wrap gap-2">
                {ENCHANTS.filter((x) => x.rarity !== "curse" && x.max > 1).map((x) => (
                  <button
                    key={x.id}
                    onClick={() => {
                      setEnchantId(x.id);
                      setFrom(Math.min(2, x.max - 1));
                      setTo(x.max);
                    }}
                    className="px-3.5 py-2 rounded-sm text-[12px] font-medium transition-all duration-200 border"
                    style={{
                      color: enchantId === x.id ? "#0a0913" : RARITY_COLOR[x.rarity],
                      background: enchantId === x.id ? RARITY_COLOR[x.rarity] : `${RARITY_COLOR[x.rarity]}0d`,
                      borderColor: `${RARITY_COLOR[x.rarity]}44`,
                    }}
                  >
                    {x.name}
                    <span className="font-code text-[10px] ml-1.5 opacity-70">上限{ROMAN[x.max]}</span>
                  </button>
                ))}
              </div>

              <div className="grid sm:grid-cols-3 gap-6">
                <Slider
                  label="当前等级"
                  value={calc.f}
                  min={1}
                  max={Math.max(1, e.max - 1)}
                  onChange={(v) => setFrom(v)}
                  format={(v) => ROMAN[v]}
                  accent="#a18cff"
                />
                <Slider
                  label="目标等级"
                  value={calc.t}
                  min={calc.f + 1}
                  max={e.max}
                  onChange={(v) => setTo(v)}
                  format={(v) => ROMAN[v]}
                  accent="#e8c37c"
                />
                <Slider
                  label="书库减免（现制 −0%~−40%）"
                  value={Math.round(discount * 100)}
                  min={0}
                  max={40}
                  onChange={(v) => setDiscount(v / 100)}
                  format={(v) => `−${v}%`}
                  accent="#8df0a4"
                />
              </div>

              <div className="flex flex-wrap gap-2">
                {MATERIALS.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setMatId(m.id)}
                    className="px-3 py-1.5 rounded-sm text-[11px] font-code transition-all border"
                    style={{
                      color: matId === m.id ? "#0a0913" : m.tint,
                      background: matId === m.id ? m.tint : "transparent",
                      borderColor: `${m.tint}44`,
                    }}
                  >
                    {m.name}
                  </button>
                ))}
                <span className="ml-auto font-code text-[11px] text-faint self-center">
                  ΔV = {fmt(calc.dv)} pt
                </span>
              </div>

              {/* 对比条 */}
              <div className="space-y-5 pt-2">
                <div>
                  <p className="font-code text-[10px] tracking-[0.25em] text-mute mb-3">
                    经验消耗（点数 ≈ 约当 {approxLevelFromPoints(calc.curXp)} 级经验条）
                  </p>
                  <div className="space-y-2.5">
                    <BarRow label="现状 v1.1" value={calc.curXp} max={barMax} color="#f08cc8" suffix="pt" />
                    <BarRow label="提案" value={calc.newXp} max={barMax} color="#e8c37c" suffix="pt" delay={0.05} />
                  </div>
                </div>
                <div>
                  <p className="font-code text-[10px] tracking-[0.25em] text-mute mb-3">
                    材料消耗（{mat.name}）
                  </p>
                  <div className="space-y-2.5">
                    <BarRow label="现状 v1.1" value={calc.curMat} max={barMaxM} color="#f08cc8" suffix="件" />
                    <BarRow label="提案" value={calc.newMat} max={barMaxM} color="#e8c37c" suffix="件" delay={0.05} />
                  </div>
                </div>
              </div>

              {/* 结论 */}
              <div className="grid sm:grid-cols-2 gap-3">
                <motion.div
                  key={`xp-${pctXp}`}
                  initial={{ scale: 0.96, opacity: 0.6 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="pixelframe bg-xp/5 border border-xp/25 p-5 flex items-center gap-4"
                >
                  <span className="font-display text-4xl font-black text-xp">-{pctXp}%</span>
                  <span className="text-xs leading-5 text-mute">
                    经验少付
                    <br />
                    <span className="font-code text-parch">{fmt(calc.savedXp)} pt</span>
                  </span>
                </motion.div>
                <motion.div
                  key={`mat-${pctMat}`}
                  initial={{ scale: 0.96, opacity: 0.6 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="pixelframe bg-gild/5 border border-gild/25 p-5 flex items-center gap-4"
                >
                  <span className="font-display text-4xl font-black text-gild">-{pctMat}%</span>
                  <span className="text-xs leading-5 text-mute">
                    材料少付
                    <br />
                    <span className="font-code text-parch">{calc.savedMat} 件</span>
                  </span>
                </motion.div>
              </div>

              <div className="flex items-start gap-2.5 text-[11px] leading-5 text-faint font-light pt-1">
                <AlertTriangle size={13} className="shrink-0 mt-0.5 text-gild/60" />
                <span>
                  魔咒总等级 {e.max}、{RARITY_LABEL[e.rarity]}稀有度仅影响价值曲线斜率 μ_r 与材料档——
                  第三方模组魔咒无需手工配置即可套用本公式族（数据包可整体覆盖）。
                </span>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default Upgrade;
