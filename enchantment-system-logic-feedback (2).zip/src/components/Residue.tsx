import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { BookX, BookOpen, ShieldAlert, Layers3, Sparkles, Check } from "lucide-react";
import {
  RESIDUE_MATS,
  RESIDUE_T1,
  RESIDUE_T2,
  RESIDUE_TOMES,
  TIER_INFO,
  residueTier,
  residueCost,
  type ResidueTier,
} from "../lib/shelves";
import { SectionHead, Reveal, FormulaCard, Slider, Chip } from "./ui";

const TIERS: ResidueTier[] = [0, 1, 2, 3];

const Residue = () => {
  const [shelves, setShelves] = useState(12);
  const [tomes, setTomes] = useState(3);
  const [count, setCount] = useState(16);
  const [matId, setMatId] = useState("paper");

  const mat = RESIDUE_MATS.find((m) => m.id === matId)!;
  const tier = residueTier(shelves, tomes);
  const cost = useMemo(() => residueCost(count, mat.base, tier), [count, mat, tier]);
  const info = TIER_INFO[tier];

  return (
    <section id="residue" className="relative max-w-6xl mx-auto px-6 md:px-10 py-24 md:py-36">
      <div
        className="absolute top-40 -right-20 font-display font-black text-[16rem] leading-none select-none pointer-events-none opacity-[0.035]"
        aria-hidden
      >
        卷
      </div>

      <SectionHead
        numeral="伍"
        kicker="ADDENDUM 02 · RESIDUE THREE-TIER"
        accent="#7ee8dc"
        title={<>残卷三梯度：<span className="text-tealw">从收税到还债</span></>}
        blurb="这条规则的妙处在于，它把「覆写：书」从一道烦人的手续费，重新定义成图书馆规模的奖励。残卷本就是玩家自己合书产生的副产物——向成熟图书馆收税，本质上是在惩罚玩家使用这个 mod 的核心玩法。三梯度正好把它扳回来。但第三梯度的判定条件有一个必须堵上的洞。"
      />

      {/* 漏洞警告 —— 核心看法 */}
      <Reveal>
        <div className="pixelframe bg-gradient-to-br from-[#2a1620] to-vellum border border-inkd/30 p-7 md:p-9 mb-8">
          <div className="flex items-start gap-4">
            <ShieldAlert className="text-inkd shrink-0 mt-1" size={22} />
            <div className="w-full">
              <p className="font-display text-xl md:text-2xl font-bold text-parch leading-relaxed">
                「6 本 MAX 附魔书」必须按<span className="text-inkd">魔咒种类去重</span>。
              </p>
              <p className="mt-3 text-sm leading-7 text-mute font-light">
                本 mod 已把附魔书堆叠上限提到 64，而一座雕纹书架恰好 6 个槽位。
                若不去重，玩家只需量产 <span className="text-parch">6 本一模一样的锋利 V</span> 塞满一座书架即可达标——
                这既与「藏书丰度」的本意背道而驰，也让条件沦为一次性走过场。
                改为<span className="text-parch">「≥6 种互不相同的魔咒」</span>后，
                这个条件立刻读起来就是「<span className="text-tealw">你的馆藏有六门学问登峰造极</span>」，
                而且恰好 = 填满一整座雕纹书架，玩家一眼就懂该干什么。
              </p>

              <div className="mt-6 grid sm:grid-cols-2 gap-3">
                <div className="rounded-sm bg-obsidian/60 border border-inkd/20 p-4">
                  <p className="font-code text-[10px] tracking-[0.2em] text-inkd mb-2">边界：MAX−1 在 M=1 时失效</p>
                  <p className="text-[12px] leading-5.5 text-mute font-light">
                    经验修补 M=1，「MAX−1」= 0 级，是个不存在的东西。合格判定应写成
                    <span className="font-code text-parch"> L ≥ max(1, M−1)</span>，
                    等价于复用现成的相对品阶 <span className="font-code text-arcane">r(e) ≥ (M−1)/M</span>——
                    单级魔咒自动退化为「有即合格」，零特判。
                  </p>
                </div>
                <div className="rounded-sm bg-obsidian/60 border border-xp/20 p-4">
                  <p className="font-code text-[10px] tracking-[0.2em] text-xp mb-2">免费会不会太强？不会</p>
                  <p className="text-[12px] leading-5.5 text-mute font-light">
                    产物只是<span className="text-parch">一本普通书</span>——甘蔗加皮革的白菜价物品。
                    免费转化不产出任何净价值，只是免除了一道惩罚性摩擦。
                    能满足梯度叁的玩家早已是毕业图书馆主，<span className="text-parch">这里没有可刷的经济面</span>。
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Reveal>

      <div className="grid lg:grid-cols-5 gap-6">
        {/* 梯度表 */}
        <Reveal className="lg:col-span-2 space-y-6">
          <FormulaCard
            tone="#7ee8dc"
            title="梯度判定 · 自上而下短路"
            rows={[
              { lhs: "梯度 叁", rhs: "W ≥ 18 且 合格母本种类 ≥ 6 → 完全免费" },
              { lhs: "梯度 贰", rhs: "W ≥ 18 → 免经验 + 材料 −50%（下限 1）" },
              { lhs: "梯度 壹", rhs: "W ≥ 8 → 仅免经验" },
              { lhs: "梯度 零", rhs: "W < 8 → Lv.1 经验 + 全额材料（现制）" },
              { lhs: "合格母本", rhs: "L ≥ max(1, M−1)，按魔咒 ID 去重" },
            ]}
          />
          <div className="pixelframe bg-abyss/70 border border-tealw/20 p-6">
            <p className="flex items-center gap-2 font-code text-[11px] tracking-[0.25em] text-tealw mb-4">
              <Sparkles size={13} /> 三条补充建议
            </p>
            <ul className="space-y-3 text-[13px] leading-6 text-mute font-light">
              <li className="flex gap-2.5">
                <span className="text-tealw mt-0.5">◆</span>
                <span>
                  <span className="text-parch">梯度要看得见。</span>行尾徽标直接写
                  「免费 · 梯度叁」或「还差 2 种母本」，别让玩家对着 wiki 数书架。
                </span>
              </li>
              <li className="flex gap-2.5">
                <span className="text-tealw mt-0.5">◆</span>
                <span>
                  <span className="text-parch">梯度叁顺带解除批次上限。</span>既然零成本，
                  单次 8 本的限制只剩点击次数的折磨——达标后允许整组 64 本一次覆写。
                </span>
              </li>
              <li className="flex gap-2.5">
                <span className="text-gild mt-0.5">◆</span>
                <span>
                  <span className="text-parch">8 与现有的 12 不冲突。</span>
                  12 架是「百分比经验减免起算」，8 架是「残卷免掉那一整级」——
                  一个是乘法一个是减法，分属不同子系统、在不同 UI 位置呈现，不会互相干扰阅读。
                </span>
              </li>
            </ul>
          </div>
        </Reveal>

        {/* 模拟器 */}
        <Reveal className="lg:col-span-3" delay={0.1}>
          <div className="pixelframe bg-vellum/70 border border-tealw/20 overflow-hidden">
            <div className="flex items-center justify-between px-6 md:px-8 py-4 border-b border-arcane/10">
              <p className="font-code text-[11px] tracking-[0.3em] text-tealw flex items-center gap-2">
                <Layers3 size={13} /> OVERWRITE DESK · 覆写台模拟
              </p>
              <Chip tone={info.tone}>{info.name}</Chip>
            </div>

            <div className="p-6 md:p-8 space-y-7">
              <div className="grid sm:grid-cols-3 gap-6">
                <Slider
                  label="普通书架数"
                  value={shelves}
                  min={0}
                  max={30}
                  onChange={setShelves}
                  format={(v) => `${v} 格`}
                  accent="#e8c37c"
                />
                <Slider
                  label="合格母本种类数"
                  value={tomes}
                  min={0}
                  max={8}
                  onChange={setTomes}
                  format={(v) => `${v} 种`}
                  accent="#a18cff"
                />
                <Slider
                  label="待转化残卷"
                  value={count}
                  min={1}
                  max={64}
                  onChange={setCount}
                  format={(v) => `${v} 本`}
                  accent="#7ee8dc"
                />
              </div>

              {/* 梯度轨道 */}
              <div className="relative">
                <div className="grid grid-cols-4 gap-1.5">
                  {TIERS.map((t) => {
                    const on = tier === t;
                    const passed = tier > t;
                    const ti = TIER_INFO[t];
                    return (
                      <motion.div
                        key={t}
                        animate={{ scale: on ? 1 : 0.97 }}
                        className="rounded-sm border p-3 text-center transition-colors"
                        style={{
                          background: on ? `${ti.tone}18` : "rgba(10,9,19,0.55)",
                          borderColor: on ? `${ti.tone}66` : "rgba(161,140,255,0.1)",
                          boxShadow: on ? `0 0 24px ${ti.tone}22` : "none",
                          opacity: passed ? 0.55 : 1,
                        }}
                      >
                        <p
                          className="font-display font-bold text-[12.5px] mb-1"
                          style={{ color: on ? ti.tone : "#6f659a" }}
                        >
                          {ti.name.split(" · ")[1]}
                        </p>
                        <p className="font-code text-[9.5px] text-faint leading-3.5">{ti.cond}</p>
                        {on && (
                          <motion.div
                            layoutId="tier-dot"
                            className="w-1.5 h-1.5 rotate-45 mx-auto mt-2"
                            style={{ background: ti.tone }}
                          />
                        )}
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* 材料选择 */}
              <div className="flex flex-wrap gap-2">
                {RESIDUE_MATS.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setMatId(m.id)}
                    className="px-3 py-1.5 rounded-sm text-[11px] font-code transition-all border"
                    style={{
                      color: matId === m.id ? "#0a0913" : m.tint,
                      background: matId === m.id ? m.tint : "transparent",
                      borderColor: `${m.tint}44`,
                    }}
                  >
                    {m.name} ×{m.base}
                  </button>
                ))}
              </div>

              {/* 结算 */}
              <div className="grid sm:grid-cols-3 gap-3">
                <div className="pixelframe bg-obsidian/60 border border-arcane/12 p-5 text-center">
                  <p className="font-display text-3xl font-black text-parch leading-none">
                    {cost.batches}
                  </p>
                  <p className="text-[11px] text-mute mt-2">
                    批次{tier === 3 ? "（可解除上限）" : " · 每批 8 本"}
                  </p>
                </div>
                <motion.div
                  key={`xp-${cost.xpLevels}`}
                  initial={{ scale: 0.96, opacity: 0.6 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="pixelframe p-5 text-center border"
                  style={{
                    background: cost.xpLevels === 0 ? "rgba(141,240,164,0.06)" : "rgba(240,140,200,0.05)",
                    borderColor: cost.xpLevels === 0 ? "rgba(141,240,164,0.3)" : "rgba(240,140,200,0.25)",
                  }}
                >
                  <p
                    className="font-display text-3xl font-black leading-none"
                    style={{ color: cost.xpLevels === 0 ? "#8df0a4" : "#f08cc8" }}
                  >
                    {cost.xpLevels === 0 ? "0" : cost.xpLevels}
                  </p>
                  <p className="text-[11px] text-mute mt-2">经验等级</p>
                </motion.div>
                <motion.div
                  key={`mat-${cost.mat}`}
                  initial={{ scale: 0.96, opacity: 0.6 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="pixelframe p-5 text-center border"
                  style={{
                    background: cost.mat === 0 ? "rgba(141,240,164,0.06)" : "rgba(126,232,220,0.05)",
                    borderColor: cost.mat === 0 ? "rgba(141,240,164,0.3)" : "rgba(126,232,220,0.25)",
                  }}
                >
                  <p
                    className="font-display text-3xl font-black leading-none"
                    style={{ color: cost.mat === 0 ? "#8df0a4" : "#7ee8dc" }}
                  >
                    {cost.mat}
                  </p>
                  <p className="text-[11px] text-mute mt-2">
                    {mat.name}
                    {cost.mat < cost.fullMat && (
                      <span className="line-through text-faint ml-1.5">{cost.fullMat}</span>
                    )}
                  </p>
                </motion.div>
              </div>

              {/* 转化示意 */}
              <div className="flex items-center justify-center gap-5 py-2">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-14 h-14 pixelframe bg-vellum2 border border-arcane/30 flex items-center justify-center">
                    <BookX size={20} className="text-mute" />
                  </div>
                  <span className="font-code text-[10px] text-faint">残卷 ×{count}</span>
                </div>
                <div className="flex flex-col items-center">
                  <motion.div
                    className="h-px w-16 sm:w-28"
                    style={{ background: `linear-gradient(90deg, transparent, ${info.tone}, transparent)` }}
                    animate={{ opacity: [0.35, 1, 0.35] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                  <span className="font-code text-[10px] mt-2" style={{ color: info.tone }}>
                    {info.effect}
                  </span>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <div
                    className="w-14 h-14 pixelframe flex items-center justify-center border"
                    style={{ background: `${info.tone}15`, borderColor: `${info.tone}55` }}
                  >
                    <BookOpen size={20} style={{ color: info.tone }} />
                  </div>
                  <span className="font-code text-[10px] text-faint">书 ×{count}</span>
                </div>
              </div>

              {/* 达标提示 */}
              <div className="flex items-center gap-2.5 text-[11px] leading-5 font-light">
                {tier === 3 ? (
                  <>
                    <Check size={13} className="text-xp shrink-0" />
                    <span className="text-xp">
                      双条件达成：{shelves} ≥ {RESIDUE_T2} 架 且 {tomes} ≥ {RESIDUE_TOMES} 种合格母本 —— 完全免费。
                    </span>
                  </>
                ) : (
                  <>
                    <Sparkles size={13} className="text-faint shrink-0" />
                    <span className="text-faint">
                      距完全免费还差：
                      {shelves < RESIDUE_T2 && `普通书架 +${RESIDUE_T2 - shelves} 格　`}
                      {tomes < RESIDUE_TOMES && `合格母本 +${RESIDUE_TOMES - tomes} 种`}
                      {shelves < RESIDUE_T1 && `（当前尚未达到 ${RESIDUE_T1} 架的免经验线）`}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
};

export default Residue;
