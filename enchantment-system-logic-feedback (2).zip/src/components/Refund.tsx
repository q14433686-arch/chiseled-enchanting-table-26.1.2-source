import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShieldCheck, CirclePlay, Coins, Ban } from "lucide-react";
import {
  ENCHANTS,
  RARITY_LABEL,
  RARITY_COLOR,
  REFUND_RATE,
  ROMAN,
  downgradeRefund,
  proposedUpgradeXp,
  materialAt,
  MATERIALS,
  valueCurve,
  fmt,
} from "../lib/enchant";
import { SectionHead, Reveal, FormulaCard, Slider, Chip } from "./ui";

const Refund = () => {
  const [enchantId, setEnchantId] = useState("sharpness");
  const [span, setSpan] = useState(3); // cycle from (max-span) to max
  const [discount, setDiscount] = useState(0.3);
  const [phase, setPhase] = useState<-1 | 0 | 1 | 2>(-1); // -1 idle, 0 pay, 1 refund, 2 done

  const e = ENCHANTS.find((x) => x.id === enchantId)!;
  const hi = e.max;
  const lo = Math.max(1, e.max - span);

  const calc = useMemo(() => {
    const pay = proposedUpgradeXp(e, lo, hi, discount);
    const refund = downgradeRefund(e, hi, lo);
    const matCost = 1 + Math.ceil((materialAt(e, hi, MATERIALS[2]) * (hi - lo)) / e.max);
    const sink = pay - refund;
    return { pay, refund, matCost, sink };
  }, [e, lo, hi, discount]);

  useEffect(() => {
    if (phase < 0 || phase >= 2) return;
    const t = setTimeout(() => setPhase((p) => (p + 1) as 0 | 1 | 2), phase === 0 ? 1100 : 1300);
    return () => clearTimeout(t);
  }, [phase]);

  const runCycle = () => {
    setPhase(-1);
    requestAnimationFrame(() => setPhase(0));
  };

  const ratePct = Math.round(REFUND_RATE[e.rarity] * 100);

  return (
    <section id="refund" className="relative max-w-6xl mx-auto px-6 md:px-10 py-24 md:py-36">
      <div
        className="absolute top-40 -right-16 font-display font-black text-[16rem] leading-none select-none pointer-events-none opacity-[0.035]"
        aria-hidden
      >
        返
      </div>

      <SectionHead
        numeral="贰"
        kicker="PROBLEM 02 · DOWNGRADE REFUND"
        accent="#8df0a4"
        title={<>降阶必须<span className="text-xp">返还</span>，而非收费</>}
        blurb="磨浅一道刻痕不是工艺，是拆解。降级不该再收材料与经验，反而应当把该词条「剩余价值」的一部分还给玩家——经验量由相对等级与稀有度决定。兼容性的问题，本质上是一个守恒问题。"
      />

      <div className="grid lg:grid-cols-5 gap-6 mb-12">
        {/* 左侧：公式 + 点数论述 */}
        <Reveal className="lg:col-span-2 space-y-6">
          <FormulaCard
            tone="#8df0a4"
            title="还公式 · 同一曲线，逆运算"
            rows={[
              { lhs: "XP_返", rhs: "= ⌊ ρ_r · (V(hi) − V(lo)) ⌋ 经验点" },
              { lhs: "ρ（常规）", rhs: "0.50 —— 半值回收" },
              { lhs: "ρ（稀有）", rhs: "0.40" },
              { lhs: "ρ（宝藏）", rhs: "0.25 —— 顿悟有门槛，回收折价" },
              { lhs: "ρ（诅咒）", rhs: "0.00 —— 祛咒是服务，改收 σ·V" },
              { lhs: "材料", rhs: "全额免收；历史材料永不返还" },
            ]}
          />
          <div className="pixelframe bg-abyss/70 border border-xp/20 p-6">
            <p className="flex items-center gap-2 font-code text-[11px] tracking-[0.25em] text-xp mb-4">
              <Coins size={13} /> 为什么返「点数」而不是「等级」
            </p>
            <p className="text-[13px] leading-6.5 text-mute font-light">
              原版一条等级在不同等级段位价值点数不同（30 级每格 112pt，而 1 级每格仅 7pt）。
              若返还「等级」，高等级玩家获得的价值反而更多 → 可被放大套利。
              <span className="text-parch">改返纯点数</span>：在台面上以经验球形式发放，
              由玩家自行吸收——与附魔之瓶同源，天然兼容各版本经验结算，
              且对服务端反作弊与统计最友好。
            </p>
          </div>
        </Reveal>

        {/* 右侧：循环守恒演示 */}
        <Reveal className="lg:col-span-3" delay={0.1}>
          <div className="pixelframe bg-vellum/70 border border-xp/20 overflow-hidden h-full flex flex-col">
            <div className="flex items-center justify-between px-6 md:px-8 py-4 border-b border-arcane/10">
              <p className="font-code text-[11px] tracking-[0.3em] text-xp flex items-center gap-2">
                <ShieldCheck size={13} /> CLOSED-LOOP · 循环守恒证明器
              </p>
              <Chip tone="#6f659a">ρ_max 0.5 ≤ 1 − Δ_max 0.6 ⟹ 永动不可达</Chip>
            </div>

            <div className="p-6 md:p-8 space-y-6 flex-1 flex flex-col">
              <div className="flex flex-wrap gap-2">
                {ENCHANTS.filter((x) => x.rarity !== "curse" && x.max > 1).map((x) => (
                  <button
                    key={x.id}
                    onClick={() => {
                      setEnchantId(x.id);
                      setSpan(Math.min(span, x.max - 1));
                    }}
                    className="px-3.5 py-2 rounded-sm text-[12px] font-medium transition-all border"
                    style={{
                      color: enchantId === x.id ? "#0a0913" : RARITY_COLOR[x.rarity],
                      background: enchantId === x.id ? RARITY_COLOR[x.rarity] : `${RARITY_COLOR[x.rarity]}0d`,
                      borderColor: `${RARITY_COLOR[x.rarity]}44`,
                    }}
                  >
                    {x.name}
                    <span className="font-code text-[10px] ml-1.5 opacity-70">
                      ρ={Math.round(REFUND_RATE[x.rarity] * 100)}%
                    </span>
                  </button>
                ))}
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <Slider
                  label={`升降跨度（${ROMAN[lo]} ⇄ ${ROMAN[hi]}）`}
                  value={span}
                  min={1}
                  max={e.max - 1}
                  onChange={setSpan}
                  format={(v) => `${v} 级`}
                  accent="#8df0a4"
                />
                <Slider
                  label="书库减免（升阶侧）"
                  value={Math.round(discount * 100)}
                  min={0}
                  max={40}
                  onChange={(v) => setDiscount(v / 100)}
                  format={(v) => `−${v}%`}
                  accent="#a18cff"
                />
              </div>

              {/* 循环舞台 */}
              <div className="relative flex-1 min-h-[180px] rounded-sm bg-obsidian/60 border border-arcane/10 p-5 grid sm:grid-cols-3 gap-4 items-center overflow-hidden">
                {/* node A */}
                <div
                  className="text-center transition-all duration-500"
                  style={{ opacity: phase === 1 ? 0.45 : 1 }}
                >
                  <motion.div
                    animate={phase === 0 ? { scale: [1, 1.08, 1] } : {}}
                    transition={{ duration: 0.9 }}
                    className="w-16 h-16 mx-auto pixelframe bg-vellum2 border border-arcane/40 flex flex-col items-center justify-center glow-arcane"
                  >
                    <span className="font-display font-black text-lg text-parch">{ROMAN[lo]}</span>
                    <span className="font-code text-[9px] text-faint">{e.name}</span>
                  </motion.div>
                  <p className="mt-2 font-code text-[10px] text-mute">起点 · 已付价值 {fmt(valueCurve(e, lo))}pt</p>
                </div>

                {/* flow arrows */}
                <div className="flex flex-col items-center gap-2 font-code text-[11px]">
                  <div className="flex items-center gap-2">
                    <motion.span
                      className="h-px w-14 sm:w-20 origin-left"
                      style={{ background: "#f08cc8" }}
                      animate={{ scaleX: phase >= 0 ? 1 : 0.2, opacity: phase >= 0 ? 1 : 0.3 }}
                    />
                    <span className={phase >= 0 ? "text-inkd" : "text-faint"}>
                      升 −{fmt(calc.pay)}pt
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={phase >= 1 ? "text-xp" : "text-faint"}>
                      降 +{fmt(calc.refund)}pt
                    </span>
                    <motion.span
                      className="h-px w-14 sm:w-20 origin-right"
                      style={{ background: "#8df0a4" }}
                      animate={{ scaleX: phase >= 1 ? 1 : 0.2, opacity: phase >= 1 ? 1 : 0.3 }}
                    />
                  </div>
                  <span className="text-[10px] text-faint mt-1">
                    材料 −{calc.matCost} 件 · 永不返还
                  </span>
                </div>

                {/* node B */}
                <div
                  className="text-center transition-all duration-500"
                  style={{ opacity: phase === 1 ? 0.45 : 1 }}
                >
                  <motion.div
                    animate={phase === 0 ? { scale: [1, 1.08, 1], borderColor: "#e8c37c" } : {}}
                    transition={{ duration: 0.9 }}
                    className="w-16 h-16 mx-auto pixelframe bg-vellum2 border border-arcane/40 flex flex-col items-center justify-center"
                  >
                    <span className="font-display font-black text-lg text-gild">{ROMAN[hi]}</span>
                    <span className="font-code text-[9px] text-faint">{e.name}</span>
                  </motion.div>
                  <p className="mt-2 font-code text-[10px] text-mute">峰值 · 价值 {fmt(valueCurve(e, hi))}pt</p>
                </div>

                {/* sink banner */}
                <AnimatePresence>
                  {phase === 2 && (
                    <motion.div
                      initial={{ opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-2 px-4 py-1.5 rounded-full bg-gild/10 border border-gild/35"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-gild animate-pulse" />
                      <span className="font-code text-[11px] text-gild">
                        单次循环净沉淀 {fmt(calc.sink)}pt + {calc.matCost} 材料 → 无刷成立
                      </span>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <button
                onClick={runCycle}
                className="group mx-auto flex items-center gap-2.5 px-6 py-3 pixelframe bg-xp/10 border border-xp/30 text-xp font-code text-xs tracking-[0.2em] hover:bg-xp/20 transition-colors"
              >
                <CirclePlay size={15} className="group-hover:rotate-90 transition-transform duration-500" />
                执行「升 → 降」循环
              </button>

              <div className="flex items-start gap-2.5 text-[11px] leading-5 text-faint font-light">
                <Ban size={13} className="shrink-0 mt-0.5 text-inkd/70" />
                <span>
                  诅咒类（{ENCHANTS.find((x) => x.rarity === "curse")!.name}等）不进入返还通道：
                  祛咒按洗去规则反向收取 σ·V，杜绝「升诅咒刷经验」的奇技。
                </span>
              </div>
            </div>
          </div>
        </Reveal>
      </div>

      {/* 简述降阶交互 */}
      <Reveal>
        <div className="grid md:grid-cols-3 gap-4">
          {[
            {
              t: "免材料",
              d: "降级不消耗任何材料——没有新增刻痕，就没有耗材。只磨不刻。",
              tone: "#8df0a4",
            },
            {
              t: "按 ΔV 折价返点",
              d: `以现行韵级为例：${RARITY_LABEL[e.rarity]}魔咒 ρ=${ratePct}%，降一挡即回 ΔV 的 ${ratePct}% 点数，溢出取整向下，碎值沉降为系统损耗。`,
              tone: "#a18cff",
            },
            {
              t: "与升阶共享曲线",
              d: "升、降引用同一条 V(e,L)，服务器单一事实源；数据包改一处曲线，两侧自动一致，不会错版。",
              tone: "#e8c37c",
            },
          ].map((c, i) => (
            <div
              key={c.t}
              className="pixelframe bg-abyss/70 border border-arcane/12 p-6 hover:-translate-y-1 transition-transform duration-300"
            >
              <p className="font-display font-bold text-lg mb-2" style={{ color: c.tone }}>
                {String(i + 1).padStart(2, "0")} · {c.t}
              </p>
              <p className="text-[12.5px] leading-6 text-mute font-light">{c.d}</p>
            </div>
          ))}
        </div>
      </Reveal>
    </section>
  );
};

export default Refund;
