// ─────────────────────────────────────────────────────────────
// 价值曲线模型 · 一条曲线，两个方向
// V(e,L) = 一本 L 级附魔书上「已被支付过的铭刻价值」（经验点数）
// 升阶只收增量 ΔV；降阶按 ρ 返还 ΔV；洗去按 σ 收取 V 的破坏费。
// ρ_max ≤ 1 − Δ_max(书库减免) ⟹ 任意「升→降」循环净消耗 > 0，无刷。
// ─────────────────────────────────────────────────────────────

export type Rarity = "common" | "rare" | "treasure" | "curse";

export interface EnchantDef {
  id: string;
  name: string;
  max: number;
  rarity: Rarity;
  note: string;
}

export const ENCHANTS: EnchantDef[] = [
  { id: "sharpness", name: "锋利", max: 5, rarity: "common", note: "常规 · 攻击向" },
  { id: "protection", name: "保护", max: 4, rarity: "common", note: "常规 · 防御向" },
  { id: "fortune", name: "时运", max: 3, rarity: "rare", note: "稀有 · 采集向" },
  { id: "swift_sneak", name: "迅捷潜行", max: 3, rarity: "treasure", note: "宝藏 · 深暗之域" },
  { id: "mending", name: "经验修补", max: 1, rarity: "treasure", note: "宝藏 · 单级" },
  { id: "binding", name: "绑定诅咒", max: 1, rarity: "curse", note: "诅咒 · 反向计价" },
];

/** 30 级封顶后的单级经验条宽度（点数）——与现版「完整等级消耗模式」的封顶规则一致 */
export const LEVEL30_WIDTH = 112;

/** 稀有度价值倍率 μ_r */
export const RARITY_MULT: Record<Rarity, number> = {
  common: 1.0,
  rare: 1.45,
  treasure: 2.0,
  curse: 1.3,
};

/** 降级返还率 ρ_r —— 宝藏最低（顿悟有门槛），诅咒不返还 */
export const REFUND_RATE: Record<Rarity, number> = {
  common: 0.5,
  rare: 0.4,
  treasure: 0.25,
  curse: 0.0,
};

/** 定向洗去费率 σ_r（对 V 的「破坏费」，经验） */
export const STRIP_RATE: Record<Rarity, number> = {
  common: 0.2,
  rare: 0.3,
  treasure: 0.45,
  curse: 0.35,
};

export const RARITY_LABEL: Record<Rarity, string> = {
  common: "常规",
  rare: "稀有",
  treasure: "宝藏",
  curse: "诅咒",
};

export const RARITY_COLOR: Record<Rarity, string> = {
  common: "#8df0a4",
  rare: "#7ee8dc",
  treasure: "#e8c37c",
  curse: "#f08cc8",
};

/** 铭刻价值曲线 V(e,L)：单位为经验点数 */
export const valueCurve = (e: EnchantDef, level: number): number =>
  Math.round(LEVEL30_WIDTH * level * RARITY_MULT[e.rarity]);

/** 材料产量分档（与 wiki 曲线一致）：低档 1→8、中档 2→18、高档 3→20 */
export interface MaterialTier {
  id: string;
  name: string;
  lo: number;
  hi: number;
  tint: string;
}
export const MATERIALS: MaterialTier[] = [
  { id: "amethyst", name: "紫水晶碎片", lo: 1, hi: 8, tint: "#c084fc" },
  { id: "emerald", name: "绿宝石", lo: 2, hi: 18, tint: "#34d399" },
  { id: "lapis", name: "青金石", lo: 3, hi: 20, tint: "#60a5fa" },
];

export const materialAt = (e: EnchantDef, level: number, mat: MaterialTier): number => {
  if (e.max <= 1) return Math.round((mat.lo + mat.hi) / 2);
  const t = (level - 1) / (e.max - 1);
  return Math.round(mat.lo + (mat.hi - mat.lo) * t);
};

// ── 现状 v1.1.0：材料升级按目标级「全价」计费 ──
export const currentUpgradeXp = (e: EnchantDef, target: number, discount: number): number =>
  Math.ceil(valueCurve(e, target) * (1 - discount));

// ── 提案：升阶只收增量 ΔV ──
export const proposedUpgradeXp = (
  e: EnchantDef,
  from: number,
  to: number,
  discount: number,
): number => {
  const delta = valueCurve(e, to) - valueCurve(e, from);
  const floor = Math.ceil(valueCurve(e, to) * 0.08);
  return Math.max(floor, Math.ceil(delta * (1 - discount)));
};

export const proposedUpgradeMat = (
  e: EnchantDef,
  from: number,
  to: number,
  mat: MaterialTier,
): number => {
  const full = materialAt(e, to, mat);
  return Math.max(1, Math.ceil((full * (to - from)) / e.max));
};

// ── 提案：降阶返还（经验点数，非等级） ──
export const downgradeRefund = (e: EnchantDef, from: number, to: number): number =>
  Math.max(0, Math.floor(REFUND_RATE[e.rarity] * (valueCurve(e, from) - valueCurve(e, to))));

// ── 提案：定向洗去花费 ──
export const stripXp = (e: EnchantDef, level: number): number =>
  Math.ceil(STRIP_RATE[e.rarity] * valueCurve(e, level));

export const stripInk = (e: EnchantDef, level: number): number => {
  const base = 1 + Math.floor((level - 1) / 2);
  return e.rarity === "treasure" || e.rarity === "rare" ? base * 2 : base;
};

// ── 原版经验曲线换算（把点数折算成「约当等级」展示用） ──
export const xpForLevelTotal = (l: number): number => {
  if (l <= 16) return l * l + 6 * l;
  if (l <= 31) return Math.round(2.5 * l * l - 40.5 * l + 360);
  return Math.round(4.5 * l * l - 162.5 * l + 2220);
};

export const approxLevelFromPoints = (points: number): number => {
  let l = 0;
  while (l < 34 && xpForLevelTotal(l + 1) <= points) l++;
  return l;
};

export const ROMAN = ["0", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"];

export const fmt = (n: number): string => n.toLocaleString("zh-CN");
