// ─────────────────────────────────────────────────────────────
// 书架阶梯模型 · 普通书架数量 → 能力解锁
// 两条互不干涉的轴：书架数量决定「能不能」，价值曲线决定「多少钱」
// ─────────────────────────────────────────────────────────────

/** 直接升阶解锁 MAX 所需的普通书架数（用户指定锚点） */
export const SHELF_UPGRADE_MAX = 38;

/** 现制：普通书架把常规魔咒直附推到中阶上限 ceil(M/2) 的满额书架数 */
export const SHELF_DIRECT_FULL = 32;

/** 直附路线：把魔咒直接纂刻到 L 级所需的普通书架（现制推演） */
export const directEnchantGate = (M: number, L: number): number | null => {
  const mid = Math.ceil(M / 2);
  if (L > mid) return null; // 直附路线够不到，必须走升阶或母本
  if (mid <= 1) return 0;
  return Math.ceil((SHELF_DIRECT_FULL * (L - 1)) / (mid - 1));
};

/**
 * 升阶路线书架门槛 S_up(L)
 * 锚点 S(M) = 38，S(1) = 0，中间按 γ 次幂分级取整
 * 并强制：严格单调递增 + 永不高于直附路线（非回归钳制）
 */
export const upgradeGateLadder = (M: number, gamma = 0.72): number[] => {
  const out: number[] = [0];
  for (let L = 2; L <= M; L++) {
    const t = (L - 1) / (M - 1);
    let s = Math.ceil(SHELF_UPGRADE_MAX * Math.pow(t, gamma));
    // 非回归钳制：升阶不得比直附更难
    const d = directEnchantGate(M, L);
    if (d !== null) s = Math.min(s, d);
    // 严格单调
    s = Math.max(s, out[L - 2] + 1);
    out.push(Math.min(s, SHELF_UPGRADE_MAX));
  }
  if (M > 1) out[M - 1] = SHELF_UPGRADE_MAX; // 锚点归位
  return out;
};

// ── 褪魔残卷三梯度 ──
export const RESIDUE_T1 = 8;   // 免经验
export const RESIDUE_T2 = 18;  // 材料折半
export const RESIDUE_TOMES = 6; // 合格母本数（恰好填满一座雕纹书架）

export interface ResidueMat {
  id: string;
  name: string;
  base: number;
  tint: string;
}
export const RESIDUE_MATS: ResidueMat[] = [
  { id: "paper", name: "纸", base: 3, tint: "#ede6d4" },
  { id: "bonemeal", name: "骨粉", base: 3, tint: "#d9d4c0" },
  { id: "lapis", name: "青金石", base: 3, tint: "#60a5fa" },
  { id: "emerald", name: "绿宝石", base: 2, tint: "#34d399" },
  { id: "ink", name: "墨囊", base: 1, tint: "#a18cff" },
  { id: "amethyst", name: "紫水晶碎片", base: 1, tint: "#c084fc" },
];

export type ResidueTier = 0 | 1 | 2 | 3;

export const residueTier = (shelves: number, tomes: number): ResidueTier => {
  if (shelves >= RESIDUE_T2 && tomes >= RESIDUE_TOMES) return 3;
  if (shelves >= RESIDUE_T2) return 2;
  if (shelves >= RESIDUE_T1) return 1;
  return 0;
};

export const TIER_INFO: Record<
  ResidueTier,
  { name: string; cond: string; effect: string; tone: string }
> = {
  0: { name: "梯度 零 · 原价", cond: "普通书架 < 8", effect: "Lv.1 经验 + 全额材料", tone: "#9c93bd" },
  1: { name: "梯度 壹 · 免经验", cond: "普通书架 ≥ 8", effect: "经验归零 · 材料全额", tone: "#7ee8dc" },
  2: { name: "梯度 贰 · 材料折半", cond: "普通书架 ≥ 18", effect: "经验归零 · 材料 −50%", tone: "#a18cff" },
  3: { name: "梯度 叁 · 完全免费", cond: "≥18 书架 且 ≥6 合格母本", effect: "零经验 · 零材料", tone: "#8df0a4" },
};

/** 批量转化成本（单批上限 8 本） */
export const residueCost = (count: number, matBase: number, tier: ResidueTier) => {
  const batches = Math.ceil(count / 8);
  const xpLevels = tier >= 1 ? 0 : batches;
  let mat = matBase * batches;
  if (tier === 2) mat = Math.max(1, Math.floor(mat * 0.5));
  if (tier === 3) mat = 0;
  return { batches, xpLevels, mat, fullMat: matBase * batches };
};

/** 合格母本判定：L ≥ max(1, M−1)，且按魔咒种类去重 */
export const qualifies = (L: number, M: number): boolean => L >= Math.max(1, M - 1);

/** 全局书架阶梯总表 */
export const LADDER = [
  { at: 8, label: "残卷免经验", sys: "褪魔残卷", tone: "#7ee8dc", isNew: true },
  { at: 12, label: "经验减免起效 −2%", sys: "全局计价", tone: "#9c93bd", isNew: false },
  { at: 18, label: "残卷材料折半", sys: "褪魔残卷", tone: "#a18cff", isNew: true },
  { at: 32, label: "木架减免封顶 −12% · 宝藏顿悟解锁", sys: "顿悟 / 计价", tone: "#e8c37c", isNew: false },
  { at: 38, label: "直接升阶解锁 MAX", sys: "升阶路线", tone: "#f08cc8", isNew: true },
];
