// ─────────────────────────────────────────────────────────────
// 代码审查结论 · arena/d0fffdab-chiseled-enchanting-table-26-1
// 所有数值均经本地克隆 + 实算复现
// ─────────────────────────────────────────────────────────────

export type Sev = "critical" | "high" | "medium" | "low";

export const SEV_META: Record<Sev, { label: string; tone: string; rank: number }> = {
  critical: { label: "严重", tone: "#ff6b8a", rank: 0 },
  high: { label: "高", tone: "#f08cc8", rank: 1 },
  medium: { label: "中", tone: "#e8c37c", rank: 2 },
  low: { label: "低", tone: "#7ee8dc", rank: 3 },
};

export interface Finding {
  id: string;
  sev: Sev;
  kind: "机制" | "硬编码" | "数值" | "CI/文档";
  title: string;
  where: string;
  what: string;
  why: string;
  fix: string;
  evidence?: string;
}

export const FINDINGS: Finding[] = [
  {
    id: "F1",
    sev: "critical",
    kind: "机制",
    title: "高 maxLevel 模组魔咒可无限刷经验",
    where: "mechanics/enchanting/DisenchantmentApplication.java:81",
    what: "essencePotential() 末行 return Math.max(clampedLevel, raw) 用「等级数」给返还值兜底。当模组魔咒 maxLevel ≥ 127 时，这个兜底值超过母本量产模式的最低实付经验（126 点），净产出为正。",
    why: "该方法的 Javadoc 明确承诺「Guaranteed strictly below minimum Master Tome inscription XP cost at every tier」，而兜底分支恰好绕过了这个保证。mod 自身文档宣称支持 maxLevel 1..255，所以这不是理论边界——任何一个高等级模组魔咒（如某些 RPG 模组的 100~255 级词条）都能把附魔台变成经验泵：铭刻扣 3 级（18 级处 = 126 点）→ 全洗返 maxLevel 点。",
    fix: "把兜底改为与成本同源的上界封顶，例如 Math.min(minMasterTomeCostPoints(maxLevel, level) - 1, Math.max(1, raw))；或直接去掉 clampedLevel 兜底，改用 Math.max(1, raw)。根因是「返还曲线」与「成本曲线」是两套互不引用的公式，建议让返还强制从成本函数派生。",
    evidence: "maxLevel=126 → 净 ±0　｜　127 → +1　｜　150 → +24　｜　255 → +129 点/次",
  },
  {
    id: "F2",
    sev: "critical",
    kind: "CI/文档",
    title: "反套利 CI 门禁的成本模型与实际代码不一致",
    where: "scripts/compat_check.py:860 vs XpCostConversion.java:92",
    what: "CI 的 min_master_tome_enchant_points() 用 raw_req = round(8 + 22·r)、档位边界 0.40/0.75；而真实 Java 用 rawThreshold = clamp(round(30·r), tier, 30)、边界 0.4001/0.7999。两者是不同函数，仅在 r=1 处巧合相等。",
    why: "CI 系统性高估真实成本最多 46%（max5 L1：CI 认为 19 点，实际 13 点），因此门禁报告的安全裕度全部偏乐观。更关键的是循环上界 range(1, 11) 只覆盖 maxLevel 1~10，而 F1 的越界点在 127——这个「证明」在设计上就看不见自己要防的那类风险。",
    fix: "两条路：①（推荐）把 XP 曲线抽成单一事实源，由 Java 生成 JSON 快照供 Python 读取，杜绝双实现漂移；② 至少把循环上界提到 256 并对齐公式，同时把函数名里的「prove」降级为「check」——它目前验的是 schema，不是不变量。",
    evidence: "max5 L1: CI 19pts / 实际 13pts　｜　max3 L2: 64 / 56　｜　覆盖区间 1–10，漏洞在 127",
  },
  {
    id: "F3",
    sev: "high",
    kind: "机制",
    title: "残卷梯度叁的「6 本」未按魔咒去重，条件可被刷满",
    where: "mechanics/resonance/BookshelfProgression.java:241 / ChiseledEnchantingTableBlock.java:356",
    what: "countQualifyingHighTierEnchantments() 遍历 STORED_ENCHANTMENTS 的每个 entry 累加，上层 countQualifying...InShelf() 再按槽位求和、跨书架累加，全程没有按 enchantment ID 去重。",
    why: "这正是我上一轮提醒过的洞，而且 Javadoc 把它写成了有意设计（「a book storing 4 MAX enchantments contributes all 4」）。后果：① 6 本一模一样的锋利 V 即可达标；② 极端情况下一本 6 词条满级合并书 + 任意一本就达标。条件本意是「馆藏广度」，实际退化成「堆一本厚书」。",
    fix: "同一文件上方 calculateShelfPower() 里已经有一个按 ID 去重的 storedMasterLevels（用 mergeHighestLevel 维护）。直接改为统计该 Map 中满足 level ≥ max(1, maxLevel−1) 的条目数即可，零新增扫描开销。",
    evidence: "highTierChiseledBooks += countQualifying...InShelf(cbsbe) ← 跨书架纯累加",
  },
  {
    id: "F4",
    sev: "high",
    kind: "机制",
    title: "ceil(M/2) 中阶天花板已被静默移除，双轨设计塌缩",
    where: "block/ChiseledEnchantingTableBlock.java:265 注释 vs 380 代码",
    what: "withWoodenShelfBoost() 现在直接调用 maxUnlockedDirectTier()，上限为 maxLevel。全仓库已搜不到任何 ceil(maxLevel/2) 实现，只剩第 265 行那条声称「scale up to the mid-tier ceiling ceil(maxLevel/2.0) at +1 per 5 wooden bookshelves」的陈旧注释。",
    why: "原设计支柱是「木书架只到中阶，满级必须靠雕纹书架母本」。现在 38 个木书架即可直接解锁 MAX，母本在「等级准入」这一维度上彻底失去独占价值，只剩经验折扣与量产模式。WIKI 第 3.1 节仍在宣传旧规则，属于文档—代码漂移。另外早期反而变难了：M=5 的 III 级从旧规则的 10 架涨到 18 架。",
    fix: "先确认这是否是有意的。若有意，需同步改 WIKI 3.1 / README 并删除陈旧注释；若无意，应在 withWoodenShelfBoost 里对非母本路线保留 min(..., ceil(M/2)) 钳制，把 38 架阶梯只用于「已持有该魔咒的升阶」而非「从零直附」。",
    evidence: "M=5 阶梯 0/8/18/28/38；旧规则 III 需 10 架，新规则需 18 架",
  },
  {
    id: "F5",
    sev: "high",
    kind: "硬编码",
    title: "LibraryResonance 全部平衡常数不可数据包覆盖",
    where: "mechanics/resonance/LibraryResonance.java:40-51",
    what: "MIN_DISCOUNT_BOOKSHELVES=12、MAX_WOODEN_DISCOUNT_PERCENT=12、MAX_GLOBAL_MASTERY=13、MAX_BASE=25、MAX_SPECIFIC=15、MAX_TOTAL=40、AFFINITY_CHANCE_PER_UNIT=0.055、GLOBAL_SLOT_WEIGHT=1.8、AFFINITY_SLOT_WEIGHT=3.6，以及 masteryUnit 里的 0.45/0.55 和 specificMastery 的指数 1.5——全部是 public static final 编译期常量，没有任何 Config record、没有任何 JSON 加载路径。",
    why: "同一个仓库里 shelf_gates.json、disenchanting.json、treasure_epiphany.json 都已做成可覆盖的 Config record，唯独影响面最大的共振系统没有。WIKI 第 9 节承诺「全部数值支持数据包覆盖」，与实现不符。服主想调「−40% 上限」只能改源码重编译。",
    fix: "照 BookshelfProgression.Config 的模式补一个 library_resonance.json + Config record，并复用现成的 S2C 同步通道（SyncedEnchantmentCosts）。这是本次审查里收益/成本比最高的一项重构。",
    evidence: "9 个常量 + 3 个内联魔数，0 个 JSON 入口",
  },
  {
    id: "F6",
    sev: "medium",
    kind: "硬编码",
    title: "残卷批量上限 64/8 写死在业务逻辑里",
    where: "menu/ChiseledEnchantingTableScreenHandler.java:718-720",
    what: "depletedTomeMaxBatchSize() 直接返回三元式 tier == TIER_3_FREE ? 64 : 8。",
    why: "梯度叁解除批次上限本身是对的（我上轮就建议了），但这两个数字属于「梯度效果」，理应与 tier1_bookshelves、tier2_material_multiplier 并列住在 shelf_gates.json 的 depleted_tome_gradients 里。现在配置项在 JSON、效果值在 Java，服主改不了，也容易被未来的堆叠上限变更打脸。",
    fix: "在 depleted_tome_gradients 增加 base_batch_size: 8 与 tier3_batch_size: 64，并在 Config record 里做 clamp(1, 64)。",
  },
  {
    id: "F7",
    sev: "medium",
    kind: "硬编码",
    title: "7×5×7 扫描体积三处写死且与注释容量不符",
    where: "block/ChiseledEnchantingTableBlock.java:381-390",
    what: "streamLibraryPositions() 用字面量 dx −3..3 / dy −2..2 / dz −3..3 三重循环，预分配 new ArrayList<>(195)。",
    why: "半径是整个 mod 最核心的空间参数（决定书架门槛 8/12/18/32/38 的实际难度），却唯独它不可配。另外 7×5×7 = 245 格、扣除中心 244，预分配写 195 偏小，会触发一次 ArrayList 扩容——小事，但说明这个数字是手写而非算出来的。",
    fix: "提取 scan_radius_horizontal / scan_radius_vertical 到 shelf_gates.json；容量按 (2h+1)²(2v+1)−1 计算。注意半径变大时需同步复核 38 架门槛的合理性。",
  },
  {
    id: "F8",
    sev: "medium",
    kind: "CI/文档",
    title: "disenchanting.json 在 Java 里有一份文本块副本",
    where: "data/ChiseledEnchantingTableData.java:1517",
    what: "DisenchantingRules.BUILT_IN_JSON 是一段把 disenchanting.json 全文复制进来的 Java 文本块，作为 resource 缺失时的 fallback；且 fromJson() 在缺 options 时会再次 parse 整段字符串。",
    why: "同一份默认值存在两处且必须手工保持同步。compat_check.py 对 item_transformations 做了 Java-vs-JSON 漂移比对，但对 disenchanting 只验 schema，没验这份副本——漂移发生时 CI 不会发现。",
    fix: "要么让构建期从 JSON 生成该常量，要么在 compat_check.py 里补一条 disenchanting 的 Java-fallback ↔ JSON 等价性断言（复用已有的 normalise 逻辑）。",
  },
  {
    id: "F9",
    sev: "medium",
    kind: "数值",
    title: "默认返还裕度偏薄，且 xp_refund_scale 无交叉校验",
    where: "disenchanting.json:4 / DisenchantmentApplication.java:68",
    what: "实算默认裕度：锋利 V 2.62×、迅捷潜行 III 1.66×、锋利 II 1.73×、maxLevel=100 模组魔咒 1.26×。xp_refund_scale 可配到 5.0（代码里 clamp 上界就是 5.0），而 enchantment_costs.json 可独立调低。",
    why: "两个旋钮分属两个文件、互不知情。任何数据包只要把 scale 调到 2.0（远在允许范围内）或把成本调低一半，就能立刻造出经验复制器，而没有任何运行期校验或启动警告会提示。",
    fix: "① 把 xp_refund_scale 的 clamp 上界从 5.0 收到 1.0；② 在数据加载完成后跑一次启动自检，对 maxLevel ∈ {1..255} 采样比对 refund < minCost，不通过则 LOGGER.warn 并自动回落 scale。这等于把 CI 里那段检查搬到运行期，才真正覆盖第三方数据包。",
    evidence: "最薄处 1.26×（maxLevel=100）；scale 允许区间 [0, 5]",
  },
  {
    id: "F10",
    sev: "low",
    kind: "数值",
    title: "γ = 1.11 与「前段陡、后段平」的直觉相反",
    where: "shelf_gates.json:7",
    what: "配置取 γ=1.11（凸），产出 M=5 的阶梯 0/8/18/28/38，近似等差。",
    why: "不是 bug，是取向问题。凸曲线意味着前两级门槛相对偏高（II 级就要 8 架），拓荒期正反馈来得晚；而 M=2 的魔咒直接是 0→38，中间毫无过渡。考虑到该 mod 的核心乐趣是「造书架看解锁」，γ<1 的凹曲线更贴合。",
    fix: "建议默认 γ≈0.75 并对 M=2 单独给一档中间值（override 机制已就位，填 overrides 即可）。属于口味调整，可留给服主。",
  },
  {
    id: "F11",
    sev: "low",
    kind: "CI/文档",
    title: "仓库根目录残留 22 个开发中间产物",
    where: "repo root",
    what: "fix3.patch、fix4.patch、fix_apply.py、fix_blit.py、fix_screen.py、fix_ui.patch 等 22 个 fix*.patch / fix*.py 文件躺在根目录。",
    why: "对一个以「社区移植、欢迎 PR」为定位的仓库，根目录的信噪比直接影响贡献者的第一印象；这些文件也容易被误当作需要执行的构建步骤。",
    fix: "删除或移入 docs/dev-archive/，并在 .gitignore 补 fix*.patch / fix*.py。",
  },
];

/** 返还 vs 成本的实算曲线（用于图表） */
export const xpForLevelTotalMc = (l: number): number => {
  if (l <= 16) return l * l + 6 * l;
  if (l <= 31) return Math.round(2.5 * l * l - 40.5 * l + 360);
  return Math.round(4.5 * l * l - 162.5 * l + 2220);
};

/** 复刻 XpCostConversion.forMasterTomeEnchant 的最低实付点数（40% 减免下） */
export const minMasterTomeCost = (maxLevel: number, level: number): number => {
  const cm = Math.max(1, maxLevel);
  let tier: number;
  let raw: number;
  if (cm === 1) {
    tier = 3;
    raw = 30;
  } else {
    const r = level / cm;
    tier = r <= 0.4001 ? 1 : r < 0.7999 ? 2 : 3;
    raw = Math.min(Math.max(Math.round(30 * r), tier), 30);
  }
  const req = Math.max(tier, Math.round(raw * 0.6));
  return xpForLevelTotalMc(req) - xpForLevelTotalMc(Math.max(0, req - tier));
};

/** 复刻 DisenchantmentApplication.essencePotential */
export const essencePotential = (
  maxLevel: number,
  level: number,
  anvilCost = 1,
  treasure = false,
  scale = 1,
): number => {
  if (level <= 0) return 0;
  const cm = Math.max(1, maxLevel);
  const cl = Math.min(level, cm);
  const r = cl / cm;
  const rf =
    Math.min(1.45, Math.max(1.0, 1.0 + 0.18 * Math.log(Math.max(1, anvilCost)))) *
    (treasure ? 1.15 : 1.0);
  const base = cm === 1 ? 34.0 : 48.0;
  const raw = Math.round(scale * base * rf * Math.pow(r, 1.65));
  return Math.max(cl, raw); // ← F1 的病灶
};
