import { Callout, Divider, Kicker, Reveal, SectionTitle, SevTag } from "@/components/Bits";
import { FindingCard } from "@/components/FindingCard";
import { FINDINGS, PATHS, SEV_META, type PathId } from "@/data/findings";

const CONTEXT: Record<PathId, { intro: string; method: string; note?: string }> = {
  api: {
    intro:
      "这一路只看「别人怎么调用它」：公开类型的名字是否说明了自己装的是什么、契约是否只有一份、参数形状是否让错误无法通过编译。融合附魔的公开面很窄（工具类全 final、数据全 record），所以问题集中在少数几个名字与一处方向接反的静态读取口。",
    method:
      "读法：对每个 public record / enum / static 方法，问三件事——(1) 名字说的和装的是同一个东西吗；(2) 同一个字段有几套校验；(3) 调用方在客户端还是服务端，而它读到的状态属于哪一边。",
  },
  codec: {
    intro:
      "一个物品组件在这个 mod 里有四条序列化路径：Codec（世界存档）、StreamCodec（网络）、隐式组件（BlockEntity ↔ ItemStack）、以及自己写的 JSON 文件（秘典进度）。四条路径的边界必须对齐，否则数据会在某一条上合法、在另一条上爆炸。",
    method:
      "读法：把每个 DataComponentType 的 persistent 与 networkSynchronized 并排写下上界；把每个 JSON 读取点的类型守卫列出来；把落盘路径的失败半径（一个坏条目影响多少数据）算清楚。",
  },
  net: {
    intro:
      "协议层的骨架是全仓库最讲究的部分之一：显式线序 ID、逐字段钳制、canSend 守卫、三关校验、速率桶。问题不在骨架，在落点——防竞态的 token 恰好没有覆盖唯一会产生不可逆后果的那个动作，而失败反馈只覆盖了八分之一的动作类型。",
    method:
      "读法：把每个 payload 的方向、上限、以及客户端实际发送的实参列成一张表；对每个服务端 return false 出口，问「玩家会看到什么」。",
    note: "对照下表看 NET-1：token 列里唯一的空字符串，落在最贵的那一行。",
  },
  gui: {
    intro:
      "融合台是一个共享方块实体上的 308×214 双页界面，输入路径是「鼠标 → sendAction(wireId, paramA, paramB, token) → 服务端 switch → ContainerData 回同步」。这一路的主题是状态编码：三种含义挤在一个同步整数里，一个按钮对应三种服务端行为，五次点击被吞掉却不出声。",
    method:
      "读法：先画 uiState 三格的取值空间，再把每个 StationAction 的客户端实参与服务端分支一一对照，最后检查每个 return true 是否都伴随可感知的反馈。",
  },
  mixin: {
    intro:
      "15 个 mixin：6 个核心（铁砧守卫、砂轮守卫、 consumable 快照、挖掘、投射物命中、 harvest 管线），9 个 @Pseudo 桥接姊妹 mod《纂刻附魔台》的净化列表。可选依赖那 9 个的处理是教科书级的；核心 6 个里有两处注入逻辑与它自己的注释不一致。",
    method:
      "读法：对每个 mixin 问四件事——目标类是否过宽、注入点字符串能否被现有测试验证、豁免条件是否与注释一致、失败时是否可观测。",
    note:
      "注意 MIX-2：src/test 下 741 行全部是纯 JVM，无法解析 method = \"…\" 字符串；能验证它们的只有 CI 的 server-smoke 作业，而那取决于脚本覆盖了哪些交互。",
  },
  dead: {
    intro:
      "19,675 行非测试代码里，可确认的死代码只有 8 个零引用成员、2 处逐字节重复、1 个从未被读取的 JSON 字段，外加一段为绕开局部 record 作用域而写的反射。总量很低——低到值得表扬，也低到让那段反射格外显眼。",
    method:
      "读法：grep 每个 public 成员的全仓库引用（排除声明行）；对成对出现的同义方法逐字节比对；对每个 JSON 字段确认至少有一处读取。",
  },
  coupling: {
    intro:
      "耦合这一路问的不是「这段代码对不对」，而是「改它会连带影响什么」。最重的两条：畸变词条的唯一撤销手段挂在一个 suggests 级别的可选依赖上；以及 Java 里有一份 tag 的硬编码镜像，而单元测试把镜像当成了真值。",
    method:
      "读法：找出所有「同一事实的第二份副本」（Java ↔ JSON、Java ↔ Python、类 ↔ 类之间的字面量），逐个判断有没有一道检查在维持它们相等。",
  },
};

export default function AuditPath({ id }: { id: PathId }) {
  const meta = PATHS.find((p) => p.id === id)!;
  const ctx = CONTEXT[id];
  const fs = FINDINGS.filter((f) => f.path === id).sort(
    (a, b) => SEV_META[a.sev].rank - SEV_META[b.sev].rank,
  );
  const counts = (["P0", "P1", "P2", "P3", "OK"] as const)
    .map((s) => ({ s, n: fs.filter((f) => f.sev === s).length }))
    .filter((c) => c.n > 0);

  return (
    <div>
      <Kicker color={meta.accent}>
        pass {meta.n} / 07 · {meta.en}
      </Kicker>
      <div className="mt-4 flex flex-wrap items-end justify-between gap-x-8 gap-y-4">
        <SectionTitle n={meta.n} zh={meta.zh} en={meta.en} />
        <div className="flex flex-wrap items-center gap-1.5">
          {counts.map((c) => (
            <span key={c.s} className="flex items-center gap-1.5">
              <SevTag sev={c.s} compact />
              <span className="tabnum font-mono text-[12px] text-cream/75">{c.n}</span>
            </span>
          ))}
        </div>
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-[minmax(0,1fr)_300px]">
        <p className="max-w-[70ch] text-[15px] leading-[1.88] text-cream/72">{ctx.intro}</p>
        <div className="border border-rule bg-ink-900/55 p-4">
          <div className="mb-2 font-mono text-[9.5px] uppercase tracking-[0.24em] text-muted/70">
            读法 / how this pass was run
          </div>
          <p className="text-[13px] leading-[1.78] text-cream/62">{ctx.method}</p>
        </div>
      </div>

      {ctx.note && (
        <Callout label="注意" color={meta.accent}>{ctx.note}</Callout>
      )}

      <Divider label={`${fs.length} findings`} />

      <ul className="space-y-4">
        {fs.map((f, i) => (
          <FindingCard key={f.id} f={f} index={i + 1} />
        ))}
      </ul>

      <Reveal>
        <div className="mt-10 border border-rule bg-ink-900/45 p-5">
          <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted">
            本路小结 / pass summary
          </div>
          <p className="mt-2.5 max-w-[76ch] text-[14px] leading-[1.85] text-cream/70">
            {SUMMARY[id]}
          </p>
        </div>
      </Reveal>
    </div>
  );
}

const SUMMARY: Record<PathId, string> = {
  api:
    "公开面的形状是好的，坏的是两处语义：一个字段名说谎（API-1），一个服务端权威读取口指向客户端状态（API-2）。后者是本次审计里唯一需要立刻改的 API 问题——它今天无症状，只因为单机下两份快照内容恰好相同。",
  codec:
    "四条序列化路径里有三条边界不对齐：组件的落盘/网络上限（DATA-1）、等级的四种校验策略（DATA-2）、数据包的多包叠加缺失（DATA-3）。加上秘典 JSON 的全量失败半径（DATA-5），共同点是「写入宽松、读出严格」或反过来，而两侧从未被放在一起看过。",
  net:
    "骨架 A，落点 C。所有防御机制都存在且实现正确，但它们被安装在了不产生后果的动作上（NET-1），而真正产生后果的动作既没有 token（NET-1）也没有失败反馈（NET-5）。修这两条不需要重构协议，只需要把已有的机制多接三根线。",
  gui:
    "输入层的核心问题是状态编码：一个整数承载三种含义（GUI-3/4），一个按钮承载三种行为（GUI-1），五次点击承载零次反馈（GUI-2）。这三条合起来解释了为什么界面「看起来能用但说不清在干什么」——它们都是同一个根因的不同表现：UI 状态没有被建模成状态。",
  mixin:
    "9 个可选依赖 mixin 的处理值得抄；6 个核心 mixin 里有 1 个的豁免条件认错了物品（MIX-1）、1 个的目标类过宽（MIX-3）。真正的系统性风险是 MIX-5：桥接用 require=0 + @Pseudo，静默失效没有任何观测点，而它承载的是某些物品状态唯一的撤销通道。",
  dead:
    "死代码总量低得反常（19,675 行里 11 处），说明有人定期清理，而且 AssetAndLocaleContractTest 里的两条负向断言证明清理被固化成了回归测试。唯一显眼的是 DEAD-1 那段反射——它的存在理由只是 record 声明的位置，修复代价是把它往上挪一层。",
  coupling:
    "这一路的结论最重：CPL-1 不是代码 bug 而是设计缺口（不可逆状态的撤销手段外包给可选依赖），CPL-2 是「测试测的是副本」这一类最危险的假安全感。其余几条（setChanged 广播、表现数据住在 src/main、材料白名单三写）都是标准的漂移风险，改起来便宜，但需要一道静态检查来防止回潮。",
};
