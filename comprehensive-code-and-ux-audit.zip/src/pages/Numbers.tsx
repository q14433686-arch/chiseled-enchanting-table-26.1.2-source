import { useMemo, useState } from "react";
import { cn } from "@/utils/cn";
import { Callout, Divider, Kicker, Meter, Reveal, SectionTitle } from "@/components/Bits";
import { FindingCard } from "@/components/FindingCard";
import { SEV_META } from "@/data/findings";
import { EXPOSED_KNOBS, HIDDEN_CONSTANTS, NUM_FINDINGS } from "@/data/numbers";

/* ── faithful re-implementation of FusionEconomyRules.computeSynthesisQuote ── */
const CEIL = { repulsive: 0.85, high: 0.75, mid: 0.65, low: 0.5 };

function neededStabilizers(base: number, floor: number, per: number, cap: number, avail: number) {
  if (avail <= 0 || cap <= 0 || base <= floor + 1e-6 || per <= 1e-6) return 0;
  const needed = Math.ceil((base - floor - 1e-9) / per);
  return Math.max(0, Math.min(avail, Math.min(cap, needed)));
}
const clampProb = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));

interface Eco {
  low: number;
  mid: number;
  high: number;
  repFail: number;
  repFloor: number;
  redRep: number;
  redNorm: number;
  capRep: number;
}
const DEFAULT_ECO: Eco = {
  low: 0.0, mid: 0.18, high: 0.28, repFail: 0.45,
  repFloor: 0.08, redRep: 0.13, redNorm: 0.18, capRep: 3,
};

function tiersFor(eco: Eco, sumLv: number, bothMax: boolean, signature: boolean, stabs: number) {
  const L = Math.max(2, sumLv);
  const out: {
    key: string; zh: string; base: number; floor: number; step: number; cap: number;
    hi: number; used: number; fail: number; xp: number; mats: number; reagent: string;
  }[] = [];

  out.push({
    key: "repulsive", zh: "互斥强融", base: eco.repFail, floor: eco.repFloor,
    step: eco.redRep, cap: eco.capRep, hi: CEIL.repulsive, used: 0, fail: 0,
    xp: 7 + Math.min(4, Math.floor(L / 3)), mats: bothMax ? 3 : 2, reagent: "绿宝石",
  });
  out.push({
    key: "high", zh: "双满高阶", base: signature ? eco.high : Math.max(0, eco.high - 0.06),
    floor: 0, step: eco.redNorm, cap: 2, hi: CEIL.high, used: 0, fail: 0,
    xp: Math.min(9, 4 + Math.floor(L / 2)), mats: 2, reagent: "绿宝石",
  });
  out.push({
    key: "mid", zh: "中阶 / 签名", base: eco.mid + 0.02 * Math.max(0, L - 5),
    floor: 0, step: eco.redNorm, cap: 2, hi: CEIL.mid, used: 0, fail: 0,
    xp: Math.max(3, Math.min(7, 2 + Math.floor(L / 2))), mats: Math.max(1, Math.min(3, Math.floor(L / 3))),
    reagent: "紫水晶",
  });
  out.push({
    key: "low", zh: "低阶入门", base: eco.low, floor: 0, step: eco.redNorm, cap: 1,
    hi: CEIL.low, used: 0, fail: 0,
    xp: Math.max(2, 1 + Math.floor(L / 2)), mats: Math.max(2, Math.min(4, 1 + L)),
    reagent: "青金石",
  });

  for (const t of out) {
    t.used = neededStabilizers(t.base, t.floor, t.step, t.cap, stabs);
    t.fail = clampProb(t.base - t.step * t.used, t.floor, t.hi);
  }
  return out;
}

function Slider({
  label, k, value, onChange, min = 0, max = 1, step = 0.01, fmt,
}: {
  label: string; k: string; value: number; onChange: (v: number) => void;
  min?: number; max?: number; step?: number; fmt?: (v: number) => string;
}) {
  return (
    <label className="block py-1.5">
      <span className="flex items-baseline justify-between gap-2">
        <span className="font-mono text-[10.5px] text-cyan/80">{k}</span>
        <span className="tabnum font-mono text-[11.5px] text-cream">{fmt ? fmt(value) : value.toFixed(2)}</span>
      </span>
      <span className="mt-1 flex items-center gap-2">
        <input
          type="range" min={min} max={max} step={step} value={value}
          onChange={(e) => onChange(parseFloat(e.target.value))}
          className="h-1 w-full cursor-pointer appearance-none rounded-none bg-ink-700 accent-gold
                     [&::-webkit-slider-thumb]:size-3 [&::-webkit-slider-thumb]:appearance-none
                     [&::-webkit-slider-thumb]:bg-gold [&::-webkit-slider-thumb]:shadow-[0_0_0_1px_#12151b]"
        />
      </span>
      <span className="mt-0.5 block text-[10.5px] leading-tight text-muted/55">{label}</span>
    </label>
  );
}

function Simulator() {
  const [eco, setEco] = useState<Eco>(DEFAULT_ECO);
  const [sumLv, setSumLv] = useState(8);
  const [stabs, setStabs] = useState(3);
  const [bothMax, setBothMax] = useState(true);
  const [signature, setSignature] = useState(false);
  const set = (k: keyof Eco) => (v: number) => setEco((e) => ({ ...e, [k]: v }));

  const rows = useMemo(
    () => tiersFor(eco, sumLv, bothMax, signature, stabs),
    [eco, sumLv, bothMax, signature, stabs],
  );
  const clamped = rows.filter((r) => r.base > r.hi + 1e-9);

  return (
    <div className="border border-rule bg-ink-900/60">
      <div className="flex flex-wrap items-center gap-3 border-b border-rule bg-ink-950/60 px-4 py-2.5">
        <span className="font-mono text-[10px] uppercase tracking-[0.24em] text-gold">
          经济曲线模拟器 / economy.json → 生效值
        </span>
        <button
          type="button"
          onClick={() => { setEco(DEFAULT_ECO); setSumLv(8); setStabs(3); setBothMax(true); setSignature(false); }}
          className="ml-auto border border-rule px-2 py-[3px] font-mono text-[10px] uppercase tracking-[0.16em] text-muted transition-colors hover:border-gold/60 hover:text-gold"
        >
          恢复默认
        </button>
      </div>

      <div className="grid gap-6 p-4 sm:p-5 lg:grid-cols-[290px_minmax(0,1fr)]">
        <div>
          <div className="mb-2 font-mono text-[9.5px] uppercase tracking-[0.24em] text-muted/70">
            economy.json 的 8 个可调项
          </div>
          <Slider k="low_fail_chance" label="低阶失败率" value={eco.low} onChange={set("low")} />
          <Slider k="mid_fail_chance" label="中阶失败率" value={eco.mid} onChange={set("mid")} />
          <Slider k="high_fail_chance" label="高阶失败率" value={eco.high} onChange={set("high")} />
          <Slider k="repulsive_fail_chance" label="互斥档失败率" value={eco.repFail} onChange={set("repFail")} />
          <Slider k="repulsive_min_floor" label="互斥档不可击穿下限" value={eco.repFloor} onChange={set("repFloor")} />
          <Slider k="stabilizer_reduction_repulsive" label="每枚稳定晶（互斥）" value={eco.redRep} onChange={set("redRep")} />
          <Slider k="stabilizer_reduction_normal" label="每枚稳定晶（常规）" value={eco.redNorm} onChange={set("redNorm")} />
          <Slider k="max_repulsive_stabilizers" label="互斥档稳定晶上限" value={eco.capRep} onChange={set("capRep")} min={0} max={8} step={1} fmt={(v) => `${v} 枚`} />

          <div className="mt-4 border-t border-rule/70 pt-3">
            <div className="mb-2 font-mono text-[9.5px] uppercase tracking-[0.24em] text-muted/70">
              场景 / scenario（不可配，硬编码在 Java）
            </div>
            <Slider k="pLv + sLv" label="两侧等级之和 sumLv" value={sumLv} onChange={setSumLv} min={2} max={20} step={1} fmt={(v) => `${v}`} />
            <Slider k="stabilizerCount" label="槽 2 里的稳定晶数量" value={stabs} onChange={setStabs} min={0} max={8} step={1} fmt={(v) => `${v} 枚`} />
            <div className="mt-2 flex flex-wrap gap-2">
              {[
                { on: bothMax, set: setBothMax, t: "双方满级" },
                { on: signature, set: setSignature, t: "签名共鸣" },
              ].map((b) => (
                <button
                  key={b.t} type="button" onClick={() => b.set(!b.on)}
                  className={cn(
                    "border px-2 py-[3px] font-mono text-[10.5px] transition-colors",
                    b.on ? "border-cyan/60 bg-cyan/10 text-cyan" : "border-rule text-muted hover:border-cyan/40",
                  )}
                >
                  {b.on ? "◈" : "◇"} {b.t}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[520px] border-collapse text-left">
              <thead>
                <tr className="border-b border-rule font-mono text-[9.5px] uppercase tracking-[0.16em] text-muted/70">
                  <th className="py-2 pr-3 font-normal">档位</th>
                  <th className="py-2 pr-3 font-normal">base</th>
                  <th className="py-2 pr-3 font-normal">用晶</th>
                  <th className="py-2 pr-3 font-normal">生效失败率</th>
                  <th className="py-2 pr-3 font-normal">写死天花板</th>
                  <th className="py-2 pr-3 font-normal">经验</th>
                  <th className="py-2 font-normal">材料</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => {
                  const hit = r.base > r.hi + 1e-9;
                  return (
                    <tr key={r.key} className="border-b border-rule/40 align-middle">
                      <td className="py-3 pr-3">
                        <div className="text-[13.5px] font-medium text-cream">{r.zh}</div>
                        <div className="font-mono text-[9.5px] text-muted/55">{r.key}</div>
                      </td>
                      <td className={cn("tabnum py-3 pr-3 font-mono text-[12.5px]", hit ? "text-alarm" : "text-cream/75")}>
                        {(r.base * 100).toFixed(1)}%
                        {hit && <span className="ml-1 text-[9.5px]">↯</span>}
                      </td>
                      <td className="tabnum py-3 pr-3 font-mono text-[12.5px] text-amethyst">
                        {r.used}/{r.cap}
                      </td>
                      <td className="py-3 pr-3">
                        <div className="tabnum font-mono text-[13px]" style={{ color: r.fail > 0.3 ? "#ff7a7a" : r.fail > 0 ? "#ffb86c" : "#8cffb0" }}>
                          {(r.fail * 100).toFixed(1)}%
                        </div>
                        <div className="relative mt-1 h-[5px] w-[132px] bg-ink-700">
                          <div
                            className="absolute inset-y-0 left-0 transition-[width] duration-300"
                            style={{
                              width: `${(r.base / 1) * 100}%`,
                              background: hit ? "#ff7a7a55" : "#ffb86c44",
                            }}
                          />
                          <div
                            className="absolute inset-y-0 left-0 transition-[width] duration-300"
                            style={{
                              width: `${r.fail * 100}%`,
                              background: r.fail > 0.3 ? "#ff7a7a" : r.fail > 0 ? "#ffb86c" : "#8cffb0",
                            }}
                          />
                          <div
                            className="absolute inset-y-[-2px] w-[2px] bg-cream/85"
                            style={{ left: `${r.hi * 100}%` }}
                            title={`clampProb 上界 ${r.hi}`}
                          />
                        </div>
                      </td>
                      <td className="tabnum py-3 pr-3 font-mono text-[12px] text-muted/70">
                        {(r.hi * 100).toFixed(0)}%
                      </td>
                      <td className="tabnum py-3 pr-3 font-mono text-[12.5px] text-gold">{r.xp} 级</td>
                      <td className="py-3 font-mono text-[11.5px] text-cream/65">
                        {r.mats}× {r.reagent}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="mt-4 border-l-2 pl-3.5" style={{ borderColor: clamped.length ? "#ff7a7a" : "#8cffb0" }}>
            {clamped.length ? (
              <p className="text-[13.5px] leading-relaxed text-cream/78">
                <strong className="text-alarm">{clamped.length} 个档位的配置值被静默钳制。</strong>{" "}
                {clamped.map((r) => `${r.zh} ${((r.base) * 100).toFixed(0)}% → ${((r.hi) * 100).toFixed(0)}%`).join("；")}。
                <code className="font-mono text-[12px] text-cyan">readDouble(…, 0.0, 1.0)</code> 接受了你填的值，
                <code className="font-mono text-[12px] text-cyan"> clampProb(…, 0.0, {clamped[0].hi})</code> 在末端把它压了回去，
                日志里显示的是加载成功。这就是 NUM-1。
              </p>
            ) : (
              <p className="text-[13.5px] leading-relaxed text-cream/70">
                当前所有档位的配置值都落在各自的写死天花板之下，所以配置生效。<span className="text-grass">试着把 low_fail_chance 拉到 0.5 以上</span>
                ——你会看到它被钳回 50%，而这就是包作者永远无法把入门档变难的原因。
              </p>
            )}
          </div>

          <div className="mt-3 flex items-center gap-4 font-mono text-[9.5px] uppercase tracking-[0.14em] text-muted/55">
            <span className="flex items-center gap-1.5"><i className="inline-block h-[7px] w-3 bg-cream/85" /> clampProb 上界（不可配）</span>
            <span className="flex items-center gap-1.5"><i className="inline-block h-[7px] w-3 bg-warn/45" /> 配置值</span>
            <span className="flex items-center gap-1.5"><i className="inline-block h-[7px] w-3 bg-grass" /> 生效值</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Numbers() {
  const hidden = HIDDEN_CONSTANTS.reduce((n, g) => n + g.items.length, 0);
  const sorted = [...NUM_FINDINGS].sort((a, b) => SEV_META[a.sev].rank - SEV_META[b.sev].rank);

  return (
    <div>
      <Kicker color="#ffdf88">pass 08 · numbers &amp; mechanics</Kicker>
      <div className="mt-4">
        <SectionTitle n="08" zh="数值与机制设计的合理性" en="Balance, curves, and what is actually configurable" />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
        <p className="max-w-[72ch] text-[15px] leading-[1.88] text-cream/72">
          GDD 的小节标题写着「阶梯资费、诚实风险曲线与「畸变词条」（<code className="font-mono text-[13px] text-cyan">economy.json</code> 数据包可配）」。
          这句话的方向是对的——失败率确实是可配的，稳定晶的减益与上限也是，而且默认参数下 UI 引用的每一个数字都与代码逐项吻合（见 NUM-11 的验算）。
          但「可配」的边界比标题暗示的窄得多：<strong className="text-cream">{EXPOSED_KNOBS.length} 个暴露的参数，对着约 {hidden} 个写死在 Java 里的曲线常量</strong>，
          其中包括六道会静默覆盖配置的失败率天花板。
        </p>
        <div className="border border-rule bg-ink-900/55 p-4">
          <div className="font-mono text-[9.5px] uppercase tracking-[0.24em] text-muted/70">可配 vs 写死</div>
          <div className="mt-3 space-y-3">
            <div>
              <div className="mb-1 flex items-baseline justify-between font-mono text-[10.5px]">
                <span className="text-grass">economy.json</span>
                <span className="tabnum text-cream/80">{EXPOSED_KNOBS.length}</span>
              </div>
              <Meter value={EXPOSED_KNOBS.length} max={EXPOSED_KNOBS.length + hidden} color="#8cffb0" />
            </div>
            <div>
              <div className="mb-1 flex items-baseline justify-between font-mono text-[10.5px]">
                <span className="text-alarm">Java 字面量</span>
                <span className="tabnum text-cream/80">{hidden}</span>
              </div>
              <Meter value={hidden} max={EXPOSED_KNOBS.length + hidden} color="#ff7a7a" />
            </div>
          </div>
          <p className="mt-3 text-[12.5px] leading-relaxed text-muted/70">
            统计口径：经验公式的基数/斜率/上下界、档位判据、失败率折扣、材料数量、稳定晶档位上限、
            套书基础失败率、翻面与卸除经验、8 种触发的冷却 tick、近战蓄力阈值。
          </p>
        </div>
      </div>

      <Divider label="interactive" />
      <Reveal>
        <Simulator />
      </Reveal>
      <p className="mt-3 max-w-[80ch] font-mono text-[11px] leading-relaxed text-muted/55">
        模拟器按 FusionEconomyRules.java 的原始表达式逐行复现（含 Java 整数除法的向下取整、computeNeededStabilizers 的 1e-6/1e-9 双 epsilon、
        clampProb 的上下界）。它是本页论点 NUM-1 / NUM-2 的可交互证据，不是游戏内截图。
      </p>

      <Divider label="exposed knobs" />
      <div className="grid gap-x-8 gap-y-0 sm:grid-cols-2">
        {EXPOSED_KNOBS.map((k, i) => (
          <Reveal key={k.k} delay={i * 30}>
            <div className="flex items-baseline gap-3 border-b border-rule/50 py-2">
              <code className="font-mono text-[12px] text-cyan/85">{k.k}</code>
              <span className="tabnum ml-auto font-mono text-[12.5px] text-gold">{k.v}</span>
              <span className="w-[150px] shrink-0 text-right text-[12px] text-muted/65">{k.note}</span>
            </div>
          </Reveal>
        ))}
      </div>

      <Divider label="hardcoded" />
      <div className="space-y-5">
        {HIDDEN_CONSTANTS.map((g, gi) => (
          <Reveal key={g.group} delay={gi * 40}>
            <div className="border border-rule/70 bg-ink-900/40">
              <div className="flex items-baseline gap-3 border-b border-rule/60 bg-ink-950/40 px-4 py-2">
                <span className="font-mono text-[11px] tracking-[0.1em] text-warn">{g.group}</span>
                <span className="ml-auto font-mono text-[10px] text-muted/55">{g.items.length} 处</span>
              </div>
              <ul className="divide-y divide-rule/35">
                {g.items.map((it) => (
                  <li key={it.c + it.where} className="flex flex-wrap items-baseline gap-x-3 gap-y-1 px-4 py-2">
                    <code className="font-mono text-[12.5px] text-alarm/85">{it.c}</code>
                    <span className="font-mono text-[10px] text-muted/45">
                      {it.where.startsWith(":") ? `FusionEconomyRules.java${it.where}` : it.where}
                    </span>
                    <span className="ml-auto text-[12.5px] text-cream/62">{it.meaning}</span>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        ))}
      </div>

      <Callout label="为什么这不只是洁癖" color="#ffb86c">
        一个整合包作者想把本 mod 的节奏调慢一倍：他能改的只有失败概率 8 格。经验、材料、冷却、档位划分、
        天花板一律改不了——而「把入门档失败率调高」这条最自然的设计路线，在任何数据包里都走不通，因为
        <code className="font-mono text-[12px] text-cyan"> clampProb(…, 0.0, 0.50)</code> 会把它压回 50%。
        文档说这条曲线可配，实现说只有它的概率维度可配。
      </Callout>

      <Divider label={`${sorted.length} findings`} />
      <ul className="space-y-4">
        {sorted.map((f, i) => (
          <FindingCard key={f.id} f={{ ...f, conf: f.conf }} index={i + 1} />
        ))}
      </ul>
    </div>
  );
}
