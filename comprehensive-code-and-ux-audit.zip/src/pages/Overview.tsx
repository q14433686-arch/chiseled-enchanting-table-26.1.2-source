import { useMemo, useState } from "react";
import { cn } from "@/utils/cn";
import { Callout, Counter, Divider, Kicker, Meter, Reveal, SectionTitle, SevTag } from "@/components/Bits";
import { FINDINGS, PATHS, SCAN, SEV_META, type Severity } from "@/data/findings";
import { NUM_FINDINGS } from "@/data/numbers";
import { TEXT_FINDINGS } from "@/data/text";

const ALL = [
  ...FINDINGS.map((f) => ({ id: f.id, sev: f.sev, title: f.title, href: `#/audit/${f.path}`, home: "paths" as const })),
  ...NUM_FINDINGS.map((f) => ({ id: f.id, sev: f.sev, title: f.title, href: "#/numbers", home: "numbers" as const })),
  ...TEXT_FINDINGS.map((f) => ({ id: f.id, sev: f.sev, title: f.title, href: "#/text", home: "text" as const })),
];

const SEV_ORDER: Severity[] = ["P0", "P1", "P2", "P3", "OK"];

export default function Overview() {
  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const s of SEV_ORDER) c[s] = ALL.filter((a) => a.sev === s).length;
    return c;
  }, []);
  const [hover, setHover] = useState<Severity | null>(null);
  const total = ALL.length;
  const p0 = ALL.filter((a) => a.sev === "P0");

  return (
    <div>
      {/* ── docket strip ── */}
      <div className="mb-8 flex flex-wrap items-center gap-x-5 gap-y-2 border-y border-rule/70 py-2.5 font-mono text-[10.5px] uppercase tracking-[0.16em] text-muted/70">
        <span className="text-gold">审计档案 / audit dossier</span>
        <span>repo · {SCAN.repo.split("/")[1]}</span>
        <span className="hidden sm:inline">branch · arena/11fcd984</span>
        <span>tree · {SCAN.commitTree}</span>
        <span className="ml-auto flex items-center gap-1.5 text-grass">
          <span className="size-[5px] animate-pulse rounded-full bg-grass" />
          static reading · 未编译未运行
        </span>
      </div>

      {/* ── asymmetric cover ── */}
      <div className="grid gap-x-10 gap-y-8 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div>
          <Kicker color="#7cf0ff">enchantment_fusion · fabric · minecraft 26.1.2</Kicker>
          <h1 className="mt-4 font-display text-[clamp(3.4rem,10.5vw,7.6rem)] leading-[0.84] tracking-[-0.02em] text-cream">
            融合附魔
            <span className="ml-3 align-super font-mono text-[clamp(0.8rem,1.6vw,1.05rem)] tracking-[0.2em] text-gold">
              0.6.0
            </span>
          </h1>
          <p className="mt-3 font-display text-[clamp(1.35rem,3.1vw,2.15rem)] italic leading-tight text-muted">
            Enchantment Fusion — Source Audit
          </p>
          <p className="mt-6 max-w-[62ch] text-[15.5px] leading-[1.85] text-cream/72">
            按七条路径重读了一遍这个仓库：<span className="text-cyan">源码 API、数据编解码、网络同步、GUI 输入、Mixin 注入、死代码、耦合风险</span>
            ，另加数值与机制设计的合理性。结论是——
            <strong className="font-semibold text-cream">骨架比多数同类 mod 讲究</strong>
            （显式线序 ID、逐字段钳制、原子落盘、11 语言 829 键零漂移、可选依赖 Mixin 三件套齐全），
            但有三处结构性问题会在真实服务器上咬人，另有一批「防护装错了门」的错位。
          </p>

          <div className="mt-7 border-l-2 border-alarm bg-alarm/[0.07] py-3 pl-4 pr-4">
            <div className="mb-2 font-mono text-[10px] uppercase tracking-[0.24em] text-alarm">
              如果只修五件事 / if you fix nothing else
            </div>
            <ol className="space-y-1.5">
              {p0.map((f, i) => (
                <li key={f.id} className="flex items-baseline gap-2.5 text-[14px] leading-snug">
                  <span className="font-mono text-[11px] text-alarm/80">{i + 1}.</span>
                  <a href={f.href} className="linkish text-cream/85 transition-colors hover:text-alarm">
                    <span className="font-mono text-[11px] text-alarm/70">{f.id}</span> {f.title}
                  </a>
                </li>
              ))}
            </ol>
          </div>
        </div>

        {/* ledger */}
        <aside className="lg:pt-14">
          <div className="border border-rule bg-ink-900/60">
            <div className="border-b border-rule bg-ink-950/60 px-4 py-2 font-mono text-[10px] uppercase tracking-[0.24em] text-muted">
              扫描面 / scan surface
            </div>
            <dl className="divide-y divide-rule/60">
              <Row k="非测试 Java" v={<><Counter to={SCAN.locNonTest} /> <span className="text-[11px] text-muted">行</span></>} />
              <Row k="测试 Java" v={<><Counter to={SCAN.locTest} /> <span className="text-[11px] text-muted">行 · 占 {((SCAN.locTest / SCAN.locNonTest) * 100).toFixed(1)}%</span></>} />
              <Row k="Java 文件" v={<Counter to={SCAN.files.java} suffix=" 个" />} />
              <Row k="语言 / 键数" v={<><Counter to={SCAN.files.lang} /> <span className="text-muted/60">×</span> <Counter to={SCAN.files.langKeys} /></>} />
              <Row k="Mixin" v={<><Counter to={SCAN.files.mixins} /> <span className="text-[11px] text-muted">个（9 个 @Pseudo 门控）</span></>} />
              <Row k="GUI 贴图" v={<Counter to={SCAN.files.textures} suffix=" 张" />} />
              <Row k="审计条目" v={<><Counter to={total} /> <span className="text-[11px] text-muted">条</span></>} />
            </dl>
          </div>

          <div className="mt-4 border border-rule bg-ink-900/60 p-4">
            <div className="mb-3 font-mono text-[10px] uppercase tracking-[0.24em] text-muted">
              严重度分布 / severity
            </div>
            <div className="flex h-3 w-full overflow-hidden">
              {SEV_ORDER.map((s) => (
                <button
                  key={s}
                  type="button"
                  onMouseEnter={() => setHover(s)}
                  onMouseLeave={() => setHover(null)}
                  onFocus={() => setHover(s)}
                  onBlur={() => setHover(null)}
                  onClick={() => setHover(hover === s ? null : s)}
                  aria-label={`${SEV_META[s].label}: ${counts[s]}`}
                  className="h-full transition-all duration-300 hover:brightness-125"
                  style={{
                    width: `${(counts[s] / total) * 100}%`,
                    background: SEV_META[s].color,
                    opacity: hover && hover !== s ? 0.32 : 1,
                  }}
                />
              ))}
            </div>
            <ul className="mt-3 space-y-1">
              {SEV_ORDER.map((s) => (
                <li
                  key={s}
                  onMouseEnter={() => setHover(s)}
                  onMouseLeave={() => setHover(null)}
                  className={cn(
                    "flex items-center gap-2 font-mono text-[10.5px] transition-opacity",
                    hover && hover !== s ? "opacity-40" : "opacity-100",
                  )}
                >
                  <i className="size-2 rotate-45" style={{ background: SEV_META[s].color }} />
                  <span style={{ color: SEV_META[s].color }}>{SEV_META[s].label}</span>
                  <span className="text-muted/60">{SEV_META[s].zh}</span>
                  <span className="ml-auto tabnum text-cream/85">{counts[s]}</span>
                </li>
              ))}
            </ul>
            <div className="mt-3 min-h-[52px] border-t border-rule/60 pt-2">
              {hover ? (
                <ul className="space-y-0.5">
                  {ALL.filter((a) => a.sev === hover)
                    .slice(0, 4)
                    .map((a) => (
                      <li key={a.id} className="truncate font-mono text-[10px] text-cream/60">
                        <a href={a.href} className="hover:text-gold">{a.id}</a> {a.title}
                      </li>
                    ))}
                  {ALL.filter((a) => a.sev === hover).length > 4 && (
                    <li className="font-mono text-[10px] text-muted/50">
                      … 另 {ALL.filter((a) => a.sev === hover).length - 4} 条
                    </li>
                  )}
                </ul>
              ) : (
                <p className="font-mono text-[10px] leading-relaxed text-muted/45">
                  ↑ 悬停色块查看该级别的条目
                </p>
              )}
            </div>
          </div>
        </aside>
      </div>

      <Divider label="identity" />

      {/* ── the repo/mod identity problem, up front because it is the most
             characteristic thing about this repository ── */}
      <Reveal>
        <div className="grid gap-6 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
          <div className="border border-warn/35 bg-warn/[0.05] p-5">
            <Kicker color="#ffb86c">仓库名 ≠ 里面的 mod</Kicker>
            <h2 className="mt-3 font-display text-[clamp(1.6rem,3.4vw,2.5rem)] leading-[1.06] text-cream">
              一个叫 <span className="text-warn">chiseled-enchanting-table</span> 的仓库，
              <br />
              装着 <span className="text-gold">enchantment_fusion</span>。
            </h2>
            <p className="mt-4 max-w-[64ch] text-[14.5px] leading-[1.85] text-cream/72">
              仓库地址与默认分支的 README 讲的是「Chiseled Enchanting Table 非官方 26.1.2 移植 · 1.1.0」；
              本次审计的 arena 分支上，<code className="font-mono text-[13px] text-cyan">fabric.mod.json</code> 的 id 是
              <code className="font-mono text-[13px] text-cyan"> enchantment_fusion</code>、
              <code className="font-mono text-[13px] text-cyan"> gradle.properties</code> 的版本是 0.6.0、
              文档是《融合附魔》GDD。两个项目共享的只有 CI 脚本骨架，但身份已经互相污染了三处：
            </p>
            <ul className="mt-4 space-y-2">
              {[
                [".github/workflows/publish.yml", "VERSION: 1.1.0 · RELEASE_NAME: “Chiseled Enchanting Table 1.1.0 (Unofficial 26.1.2 Port)” —— 手动触发即以此身份发布本 mod"],
                [".github/workflows/build.yml", "artifact 名 chiseled-enchanting-table-${{ github.sha }}，里面是 enchantment-fusion-0.6.0.jar"],
                ["默认分支 README", "把 docs/WIKI.md 与 docs/reports/SYNC_FROM_26_3_REPORT.md 作为主要入口强调，两个文件在本分支都不存在"],
              ].map(([a, b]) => (
                <li key={a} className="flex gap-3 border-l border-warn/40 pl-3">
                  <code className="shrink-0 font-mono text-[11.5px] text-warn">{a}</code>
                  <span className="text-[13.5px] leading-relaxed text-cream/68">{b}</span>
                </li>
              ))}
            </ul>
            <p className="mt-4 text-[13.5px] leading-relaxed text-muted">
              一致性脚本知道这件事，但把它降级成一行非致命 WARN →{" "}
              <a href="#/text" className="linkish text-gold hover:text-cream">文案页 TXT-9</a>
            </p>
          </div>

          <div className="flex flex-col gap-4">
            <div className="border border-rule bg-ink-900/60 p-5">
              <Kicker color="#b5ac9e">代码集中度 / concentration</Kicker>
              <p className="mt-3 text-[13.5px] leading-relaxed text-cream/68">
                两个文件占了全部非测试 Java 的{" "}
                <strong className="font-semibold text-cream">
                  {(((SCAN.biggest[0].n + SCAN.biggest[1].n) / SCAN.locNonTest) * 100).toFixed(1)}%
                </strong>
                。它们都是手写内容表（化形变体、签名共鸣），而不是逻辑。
              </p>
              <ul className="mt-4 space-y-2.5">
                {SCAN.biggest.map((b) => (
                  <li key={b.f}>
                    <div className="flex items-baseline justify-between gap-2 font-mono text-[10.5px]">
                      <span className="truncate text-cream/75">{b.f.split("/").pop()}</span>
                      <span className="tabnum shrink-0 text-muted">{b.n}</span>
                    </div>
                    <Meter value={b.n} max={SCAN.biggest[0].n} color={b.n > 2000 ? "#ff7a7a" : b.n > 1000 ? "#ffb86c" : "#7cf0ff"} height={4} style={{ marginTop: 3 }} />
                  </li>
                ))}
              </ul>
            </div>
            <Callout label="本次审计的性质" color="#7cf0ff">
              全部结论来自对仓库文本的静态阅读：每条都给出 <code className="font-mono text-[12px]">文件:行</code>
              ，并标注可信度（<span className="text-grass">已逐行核对</span> /{" "}
              <span className="text-gold">静态推断</span> /{" "}
              <span className="text-cyan">需运行时验证</span>）。
              沙箱内没有 JDK、也没有 <code className="font-mono text-[12px]">maven.fabricmc.net</code>
              的访问权，因此<strong className="text-cream">没有编译、没有启动游戏、没有跑任何测试</strong>。
              凡涉及 Minecraft 26.1.2 映射名的判断，都按「风险」而非「事实」陈述——见{" "}
              <a href="#/skeptic" className="linkish text-gold">怀疑与建议</a>。
            </Callout>
          </div>
        </div>
      </Reveal>

      <Divider label="seven passes" />

      {/* ── path index: a table-list, not a card grid ── */}
      <section>
        <SectionTitle n="§" zh="七路审计" en="Seven passes over the same tree" />
        <p className="mt-3 max-w-[70ch] text-[14.5px] leading-[1.85] text-cream/68">
          同一棵树按七种关注点各走一遍。每条路径的条目都带 <code className="font-mono text-[12.5px] text-cyan">文件:行</code>{" "}
          与「现象 → 为什么是问题 → 建议」三段式；标为 <span className="text-grass">CREDIT</span> 的是该路径下确实做得好的部分，
          列出来是为了让「哪里不用改」和「哪里必须改」同样明确。
        </p>

        <ul className="mt-7 divide-y divide-rule/70 border-y border-rule/70">
          {PATHS.map((p, i) => {
            const fs = FINDINGS.filter((f) => f.path === p.id);
            const worst = fs.filter((f) => f.sev === "P0").length
              ? "P0"
              : fs.filter((f) => f.sev === "P1").length
                ? "P1"
                : fs.filter((f) => f.sev === "P2").length
                  ? "P2"
                  : "P3";
            return (
              <Reveal as="li" key={p.id} delay={i * 45} className="list-none">
                <a
                  href={`#/audit/${p.id}`}
                  className="group relative flex flex-col gap-3 py-4 pl-4 pr-2 transition-colors duration-300 hover:bg-cream/[0.035] sm:flex-row sm:items-center sm:gap-6 sm:pl-5"
                >
                  <span
                    className="absolute inset-y-0 left-0 w-[3px] origin-top scale-y-0 transition-transform duration-300 group-hover:scale-y-100"
                    style={{ background: p.accent }}
                  />
                  <span className="flex shrink-0 items-baseline gap-3">
                    <span className="font-mono text-[12px] tracking-[0.14em]" style={{ color: p.accent }}>
                      {p.n}
                    </span>
                    <span className="w-[104px] text-[16px] font-semibold tracking-tight text-cream">
                      {p.zh}
                    </span>
                  </span>
                  <span className="hidden w-[150px] shrink-0 font-mono text-[10px] uppercase tracking-[0.16em] text-muted/60 sm:block">
                    {p.en}
                  </span>
                  <span className="min-w-0 flex-1 text-[13.5px] leading-relaxed text-cream/60">
                    {p.blurb}
                  </span>
                  <span className="flex shrink-0 items-center gap-2.5">
                    <SevTag sev={worst as Severity} compact />
                    <span className="tabnum font-mono text-[12px] text-cream/70">
                      {fs.length}
                    </span>
                    <span className="font-mono text-[13px] text-muted/50 transition-transform duration-300 group-hover:translate-x-1 group-hover:text-gold">
                      →
                    </span>
                  </span>
                </a>
              </Reveal>
            );
          })}
        </ul>
      </section>

      <Divider label="two special pages" />

      <section className="grid gap-5 lg:grid-cols-2">
        <Reveal>
          <a
            href="#/text"
            className="paper group flex h-full flex-col p-6 transition-transform duration-300 hover:-translate-y-1"
          >
            <div className="font-mono text-[10px] uppercase tracking-[0.28em]" style={{ color: "#8c5308" }}>
              09 · special page
            </div>
            <h3 className="mt-2 font-display text-[clamp(1.7rem,3.4vw,2.4rem)] leading-[1.05]" style={{ color: "#3a2210" }}>
              说明、UI 内、文档内文字的
              <br />
              易读性 · 准确性 · 同一性
            </h3>
            <p className="mt-3 text-[14px] leading-[1.8]" style={{ color: "#4e331b" }}>
              先说结论：<strong>易读性合格，甚至偏好</strong>——829 键 × 11 语言双向零漂移，
              全部动态拼接键可解析，术语中英对照成体系。真正的欠账在三处：
              渲染规则不统一（同一段算法两个缩放地板、14 个散落字号、阴影开关两处相反）、
              文案把配置默认值抄成了字面量（11 种语言齐声说「8%」）、
              以及跨文档的身份与版本漂移（四处 GDD 章节引用全部悬空、三个版本号、发布工作流仍是另一个 mod）。
            </p>
            <div className="mt-auto flex items-center gap-3 pt-5 font-mono text-[10.5px] uppercase tracking-[0.18em]" style={{ color: "#165b63" }}>
              <span className="border px-2 py-[3px]" style={{ borderColor: "#165b6355" }}>
                {TEXT_FINDINGS.length} 条 · 含实测数据
              </span>
              <span className="transition-transform duration-300 group-hover:translate-x-1">→</span>
            </div>
          </a>
        </Reveal>

        <Reveal delay={90}>
          <a
            href="#/skeptic"
            className="group flex h-full flex-col border border-cyan/25 bg-ink-900/70 p-6 transition-all duration-300 hover:-translate-y-1 hover:border-cyan/60 hover:bg-cyan/[0.05]"
          >
            <div className="font-mono text-[10px] uppercase tracking-[0.28em] text-cyan">
              10 · special page
            </div>
            <h3 className="mt-2 font-display text-[clamp(1.7rem,3.4vw,2.4rem)] leading-[1.05] text-cream">
              中肯的怀疑
              <br />
              与建议
            </h3>
            <p className="mt-3 text-[14px] leading-[1.8] text-cream/70">
              这一页反过来审我自己：哪些结论<strong className="text-cream">无法</strong>在沙箱里验证、
              哪几条我可能读错了意图、哪些「问题」其实是合理取舍。
              然后是排序过的建议——P0 五条当天可做，P1 一周内，P2/P3 随重构顺带。
              最后单独列一节「这个仓库做对了什么」，因为一份只讲毛病的审计对维护者没有用。
            </p>
            <div className="mt-auto flex flex-wrap items-center gap-2 pt-5 font-mono text-[10.5px] uppercase tracking-[0.18em] text-muted">
              <span className="border border-cyan/30 px-2 py-[3px] text-cyan/85 transition-colors group-hover:border-cyan/70">
                自我怀疑 · 7 条
              </span>
              <span className="border border-rule px-2 py-[3px] transition-colors group-hover:border-gold/50 group-hover:text-gold">
                路线图 · 4 档
              </span>
              <span className="ml-auto transition-transform duration-300 group-hover:translate-x-1 text-cyan">→</span>
            </div>
          </a>
        </Reveal>
      </section>
    </div>
  );
}

function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-3 px-4 py-2">
      <dt className="font-mono text-[10.5px] uppercase tracking-[0.12em] text-muted/70">{k}</dt>
      <dd className="font-display text-[19px] leading-none text-cream">{v}</dd>
    </div>
  );
}
