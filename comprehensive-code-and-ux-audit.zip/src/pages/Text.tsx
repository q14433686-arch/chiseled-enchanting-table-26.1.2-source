import { useEffect, useMemo, useRef, useState } from "react";
import { cn } from "@/utils/cn";
import { Callout, Divider, Kicker, Meter, Reveal, SectionTitle } from "@/components/Bits";
import { FindingCard } from "@/components/FindingCard";
import { SEV_META } from "@/data/findings";
import {
  BUTTON_OVERFLOW, KIND_META, LANG_AUDIT, SCALE_LITERALS, TEXT_FINDINGS, TEXTURE_SCALE,
} from "@/data/text";

/* approximate Minecraft default-font glyph widths (lowercase 5, caps/digits 6,
   narrow 2, space 4). Stated as ±10% — used for magnitude, not for typesetting. */
const NARROW = new Set("il.,:;'|![]()");
const MID = new Set("fkmtj\" ");
function mcWidth(s: string) {
  let w = 0;
  for (const ch of s) {
    if (NARROW.has(ch)) w += 2;
    else if (MID.has(ch)) w += 4;
    else if (ch === " ") w += 4;
    else if (/[a-z]/.test(ch)) w += 5;
    else w += 6;
  }
  return w;
}

function ShrinkSim() {
  const [text, setText] = useState("Перевернуть");
  const [boxW, setBoxW] = useState(38);
  const [minScale, setMinScale] = useState<0.5 | 0.52>(0.5);
  const [shadow, setShadow] = useState(true);
  const [maxScale] = useState(1.0);

  const r = useMemo(() => {
    const rawW = mcWidth(text);
    let scale = maxScale;
    let shown = text;
    let truncated = false;
    if (rawW > 0 && rawW * scale > boxW) {
      const fit = boxW / rawW;
      if (fit >= minScale) scale = fit;
      else {
        scale = minScale;
        const maxRaw = Math.max(8, Math.round(boxW / scale - 2));
        let acc = 0;
        let cut = text.length;
        for (let i = 0; i < text.length; i++) {
          acc += mcWidth(text[i]);
          if (acc > maxRaw) { cut = i; break; }
        }
        shown = text.slice(0, cut) + "\u2026";
        truncated = true;
      }
    }
    return { rawW, scale, shown, truncated, drawnW: mcWidth(shown) * scale };
  }, [text, boxW, minScale, maxScale]);

  return (
    <div className="border border-rule bg-ink-900/60">
      <div className="flex flex-wrap items-center gap-3 border-b border-rule bg-ink-950/60 px-4 py-2.5">
        <span className="font-mono text-[10px] uppercase tracking-[0.24em] text-cyan">
          缩排模拟器 / drawCenteredBoundedText 逐行复现
        </span>
        <span className="ml-auto font-mono text-[9.5px] text-muted/50">
          字宽为近似表（±10%），阴影按 CSS transform 同步缩放 —— 与 pose.scale 的行为一致
        </span>
      </div>

      <div className="grid gap-5 p-4 sm:p-5 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div>
          {/* the button box, drawn to scale */}
          <div className="relative mx-auto" style={{ width: boxW + 12, height: 40 }}>
            <div
              className="absolute inset-0 border"
              style={{
                borderColor: "#8c530866",
                background: "linear-gradient(180deg,#3a2c1a,#241a10)",
                boxShadow: "inset 0 1px 0 #ffdf8833",
              }}
            />
            <div
              className="absolute inset-y-0 border-x border-dashed border-alarm/45"
              style={{ left: 3, right: 3 }}
              title={`可用内宽 ${boxW}px`}
            />
            <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
              <span
                className="whitespace-nowrap font-mono text-[16px] leading-none text-cream"
                style={{
                  transform: `scale(${r.scale})`,
                  transformOrigin: "center",
                  textShadow: shadow ? "1px 1px 0 rgba(0,0,0,.62)" : "none",
                }}
              >
                {r.shown}
              </span>
            </div>
          </div>

          <dl className="mt-5 grid grid-cols-2 gap-x-5 gap-y-2 border-t border-rule/60 pt-4 sm:grid-cols-4">
            {[
              ["rawW", `${r.rawW}px`, "#7cf0ff"],
              ["fit = boxW/rawW", (boxW / Math.max(1, r.rawW)).toFixed(3), "#e3b2ff"],
              ["生效 scale", r.scale.toFixed(3), r.scale < 0.6 ? "#ff7a7a" : r.scale < 1 ? "#ffb86c" : "#8cffb0"],
              ["是否省略号", r.truncated ? "是 ✂" : "否", r.truncated ? "#ff7a7a" : "#8cffb0"],
            ].map(([k, v, c]) => (
              <div key={k as string}>
                <dt className="font-mono text-[9.5px] uppercase tracking-[0.16em] text-muted/60">{k}</dt>
                <dd className="tabnum font-mono text-[15px]" style={{ color: c as string }}>{v}</dd>
              </div>
            ))}
          </dl>

          <div className="mt-4 border-l-2 pl-3.5" style={{ borderColor: r.scale < 0.6 ? "#ff7a7a" : r.scale < 1 ? "#ffb86c" : "#8cffb0" }}>
            <p className="text-[13.5px] leading-relaxed text-cream/75">
              {r.scale < 0.6 ? (
                <>已跌破可读阈值并触发省略号。此时若仍开着阴影（当前：<b className={shadow ? "text-alarm" : "text-grass"}>{shadow ? "开" : "关"}</b>），
                1px 的阴影偏移被压到 {(1 * r.scale).toFixed(2)}px，与笔画落在同一像素格里 —— 试试把阴影关掉对比。</>
              ) : r.scale < 1 ? (
                <>正在硬缩，尚未触发省略号。注意缩放是任意小数（{r.scale.toFixed(4)}），像素字体在非整数倍下的笔画粗细会不均。</>
              ) : (
                <>当前文本放得下，无需缩放。把文本换成 <button type="button" onClick={() => setText("Перевернуть")} className="linkish text-gold">Перевернуть</button> 或把内宽拉到 38 试试。</>
              )}
            </p>
          </div>
        </div>

        <div className="space-y-3">
          <label className="block">
            <span className="mb-1 block font-mono text-[9.5px] uppercase tracking-[0.2em] text-muted/70">标签文本</span>
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="w-full border border-rule bg-ink-950 px-2.5 py-1.5 font-mono text-[13px] text-cream outline-none transition-colors focus:border-cyan/60"
            />
          </label>
          <div className="flex flex-wrap gap-1.5">
            {["Flip", "Перевернуть", "Inverser", "翻面", "Aufteilen", "Разделить"].map((t) => (
              <button key={t} type="button" onClick={() => setText(t)}
                className={cn("border px-1.5 py-[2px] font-mono text-[10px] transition-colors",
                  text === t ? "border-gold/70 bg-gold/10 text-gold" : "border-rule text-muted hover:border-cyan/40 hover:text-cyan")}>
                {t}
              </button>
            ))}
          </div>
          <label className="block">
            <span className="mb-1 flex items-baseline justify-between font-mono text-[9.5px] uppercase tracking-[0.2em] text-muted/70">
              控件内宽 <span className="tabnum text-[11.5px] text-cream">{boxW}px</span>
            </span>
            <input type="range" min={20} max={120} value={boxW}
              onChange={(e) => setBoxW(parseInt(e.target.value))}
              className="h-1 w-full cursor-pointer appearance-none bg-ink-700
                         [&::-webkit-slider-thumb]:size-3 [&::-webkit-slider-thumb]:appearance-none
                         [&::-webkit-slider-thumb]:bg-cyan [&::-webkit-slider-thumb]:shadow-[0_0_0_1px_#12151b]" />
          </label>
          <div className="flex gap-2">
            {([0.5, 0.52] as const).map((v) => (
              <button key={v} type="button" onClick={() => setMinScale(v)}
                className={cn("flex-1 border px-2 py-1.5 font-mono text-[11px] transition-colors",
                  minScale === v ? "border-alarm/70 bg-alarm/10 text-alarm" : "border-rule text-muted hover:border-alarm/40")}>
                minScale {v.toFixed(2)}
              </button>
            ))}
          </div>
          <button type="button" onClick={() => setShadow((s) => !s)}
            className={cn("w-full border px-2 py-1.5 font-mono text-[11px] transition-colors",
              shadow ? "border-warn/60 bg-warn/10 text-warn" : "border-rule text-muted hover:border-warn/40")}>
            {shadow ? "◈ shadow = true（现状）" : "◇ shadow = false（建议）"}
          </button>
          <p className="text-[11.5px] leading-relaxed text-muted/60">
            两个 minScale 值来自 <code className="font-mono text-[10.5px] text-cyan">FusionGuiSkin.java:204</code> 与
            <code className="font-mono text-[10.5px] text-cyan"> :239</code> —— 同一段算法，两个地板（TXT-1）。
          </p>
        </div>
      </div>
    </div>
  );
}

function OverflowChart() {
  const [i, setI] = useState(0);
  const g = BUTTON_OVERFLOW[i];
  const max = Math.max(...g.rows.map((r) => r.px), g.inner);
  return (
    <div className="border border-rule bg-ink-900/60">
      <div className="flex flex-wrap items-center gap-2 border-b border-rule bg-ink-950/60 px-4 py-2.5">
        <span className="font-mono text-[10px] uppercase tracking-[0.24em] text-gold">
          实测溢出 / 按语言估算的字宽 vs 控件内宽
        </span>
        <div className="ml-auto flex gap-1.5">
          {BUTTON_OVERFLOW.map((b, bi) => (
            <button key={b.key} type="button" onClick={() => setI(bi)}
              className={cn("border px-2 py-[3px] font-mono text-[10px] transition-colors",
                bi === i ? "border-gold/70 bg-gold/10 text-gold" : "border-rule text-muted hover:border-gold/40")}>
              {b.key.split(".").pop()} · 内宽 {b.inner}px
            </button>
          ))}
        </div>
      </div>
      <div className="p-4 sm:p-5">
        <div className="mb-3 font-mono text-[10.5px] text-muted/60">
          {g.key} <span className="text-muted/40">· 控件 {g.box}</span>
        </div>
        <ul className="space-y-1.5">
          {g.rows.map((r) => {
            const over = r.px > g.inner;
            return (
              <li key={r.loc} className="flex items-center gap-3">
                <span className="w-12 shrink-0 font-mono text-[10.5px] text-muted/70">{r.loc}</span>
                <span className="w-[92px] shrink-0 truncate font-mono text-[11px] text-cream/70">{r.text}</span>
                <div className="relative h-[14px] min-w-0 flex-1 bg-ink-800">
                  <div className="absolute inset-y-0 left-0 transition-[width] duration-500"
                    style={{ width: `${(r.px / max) * 100}%`, background: over ? "#ff7a7a" : "#8cffb0", opacity: over ? 0.85 : 0.6 }} />
                  <div className="absolute inset-y-[-3px] w-[2px] bg-gold" style={{ left: `${(g.inner / max) * 100}%` }} />
                  <span className="absolute inset-y-0 right-1.5 flex items-center font-mono text-[9.5px] text-cream/55">
                    {r.px}px
                  </span>
                </div>
                <span className={cn("w-[52px] shrink-0 text-right font-mono text-[10.5px]",
                  r.scale < 0.85 ? "text-alarm" : r.scale < 1 ? "text-warn" : "text-grass")}>
                  ×{r.scale.toFixed(2)}
                </span>
              </li>
            );
          })}
        </ul>
        <div className="mt-3 flex items-center gap-4 font-mono text-[9.5px] uppercase tracking-[0.14em] text-muted/55">
          <span className="flex items-center gap-1.5"><i className="inline-block h-[8px] w-[2px] bg-gold" /> 控件内宽（{g.inner}px）</span>
          <span className="flex items-center gap-1.5"><i className="inline-block h-[8px] w-3 bg-alarm/85" /> 溢出 → 触发缩排</span>
          <span className="ml-auto normal-case tracking-normal text-muted/45">×n = 实际生效的缩放系数</span>
        </div>
        <p className="mt-3 border-t border-rule/60 pt-3 text-[13px] leading-relaxed text-cream/68">
          注意最后两行：<code className="font-mono text-[12px] text-cyan">btn.flip</code> 与{" "}
          <code className="font-mono text-[12px] text-cyan">btn.split</code> 在界面上是<strong className="text-cream">并排的两个按钮</strong>，
          而 ru_ru 下它们分别被缩到 ×0.79 与 ×0.76 —— 相邻控件字号不一致。en_us 下同一对按钮是 ×1.00 与 ×1.00。
        </p>
      </div>
    </div>
  );
}

function ScaleScatter() {
  const all = SCALE_LITERALS.files.flatMap((f) => f.vals.map((v) => ({ v, f: f.f })));
  const min = 0.4, max = 0.78;
  return (
    <div className="border border-rule bg-ink-900/60 p-4 sm:p-5">
      <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-amethyst">
        散落的字号令牌 / {SCALE_LITERALS.distinctGuiScales} 个不同的缩放系数，0 个具名
      </div>
      <div className="relative mt-6 h-[92px] border-b border-rule">
        <div className="absolute inset-x-0 bottom-0 h-px bg-rule" />
        {[0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75].map((t) => (
          <div key={t} className="absolute bottom-0 h-2 w-px bg-rule/80" style={{ left: `${((t - min) / (max - min)) * 100}%` }}>
            <span className="absolute top-3 -translate-x-1/2 font-mono text-[9px] text-muted/45">{t.toFixed(2)}</span>
          </div>
        ))}
        {all.map((a, i) => (
          <span key={i} title={`${a.f} → ${a.v}`}
            className="absolute size-[7px] -translate-x-1/2 rotate-45 transition-transform duration-200 hover:scale-150"
            style={{
              left: `${((a.v - min) / (max - min)) * 100}%`,
              bottom: 8 + (i % 7) * 10,
              background: a.f.includes("Grimoire") ? "#e3b2ff" : a.f.includes("Skin") ? "#ff7a7a" : a.f.includes("Micro") ? "#b5ac9e" : "#7cf0ff",
              opacity: 0.9,
            }}
          />
        ))}
        {/* the 0.50 / 0.52 pair */}
        <div className="absolute bottom-[-2px] h-[86px] w-[2.6%] border-x border-alarm/45 bg-alarm/[0.07]"
          style={{ left: `${((0.5 - min) / (max - min)) * 100}%` }} />
        <span className="absolute bottom-[88px] font-mono text-[9.5px] text-alarm"
          style={{ left: `${((0.5 - min) / (max - min)) * 100 - 2}%` }}>
          0.50 vs 0.52 · 同一算法两个地板
        </span>
      </div>
      <div className="mt-4 flex flex-wrap gap-3 font-mono text-[9.5px] uppercase tracking-[0.14em] text-muted/60">
        {[["#7cf0ff", "EnchantmentFusionScreen"], ["#e3b2ff", "FusionGrimoireScreen"], ["#ff7a7a", "FusionGuiSkin"], ["#b5ac9e", "FusionGuiMicroEffects"]].map(([c, n]) => (
          <span key={n} className="flex items-center gap-1.5"><i className="size-2 rotate-45" style={{ background: c }} />{n}</span>
        ))}
      </div>
      <p className="mt-3 text-[13px] leading-relaxed text-cream/68">
        对比一下颜色侧：<code className="font-mono text-[12px] text-grass">COLOR_GOLD / CREAM / CYAN / AMETHYST / GREEN / WARN / RED / MUTED</code> 加 5 个{" "}
        <code className="font-mono text-[12px] text-grass">COLOR_INK_*</code>，13 个具名令牌，全仓库统一引用。
        尺寸侧完全没有对应物 —— 这不是能力问题，是这一层还没做。
      </p>
    </div>
  );
}

export default function TextPage() {
  const kinds = ["readability", "accuracy", "identity"] as const;
  const [active, setActive] = useState<(typeof kinds)[number] | "all">("all");
  const shown = TEXT_FINDINGS
    .filter((f) => active === "all" || f.kind === active)
    .sort((a, b) => SEV_META[a.sev].rank - SEV_META[b.sev].rank);
  const counts = useMemo(() => {
    const c: Record<string, number> = { all: TEXT_FINDINGS.length };
    for (const k of kinds) c[k] = TEXT_FINDINGS.filter((f) => f.kind === k).length;
    return c;
  }, []);

  const paperRef = useRef<HTMLDivElement>(null);
  const [ink, setInk] = useState(0);
  useEffect(() => {
    const el = paperRef.current;
    if (!el) return;
    const io = new IntersectionObserver((e) => {
      if (e[0]?.isIntersecting) { setInk(1); io.disconnect(); }
    }, { threshold: 0.2 });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div>
      <Kicker color="#e3b2ff">pass 09 · special page</Kicker>
      <div className="mt-4">
        <SectionTitle n="09" zh="说明、UI 内、文档内文字" en="Readability · Accuracy · Consistency" />
      </div>
      <p className="mt-2 font-display text-[clamp(1.2rem,2.6vw,1.75rem)] italic leading-tight text-muted">
        易读性 · 准确性 · 同一性
      </p>

      {/* verdict */}
      <div className="mt-7 grid gap-5 lg:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
        <div>
          <p className="max-w-[74ch] text-[15.5px] leading-[1.9] text-cream/75">
            先给结论，因为你已经给了一个：<strong className="text-grass">易读性是合格的</strong>。我核对完数据之后同意，甚至想把它调高一点——
            829 个键 × 11 种语言，双向零漂移；全部动态拼接的键组（trigger / payload / effect / reagent / reject / aberration / signature 348 条 / transmute 280 条）都能解析；
            10 个非英语语言的 GUI 标签相对英文的<strong className="text-cream">长度中位数是 1.00</strong>，说明翻译时被有意识地控制在了控件能容纳的范围内。
            术语的中英对照成体系，符号（◇ / ▷ / [A ▷ B]）跨文档一致。
          </p>
          <p className="mt-4 max-w-[74ch] text-[15.5px] leading-[1.9] text-cream/75">
            但「可以再努力一下」这句也说对了，而且努力的方向不在易读性，在它旁边两条：
            <strong className="text-warn"> 准确性</strong>（文案把配置默认值抄成了字面量，11 种语言齐声说「8%」；四处 GDD 章节引用全部悬空）与
            <strong className="text-amethyst"> 同一性</strong>（同一段算法两个缩放地板、14 个散落字号、阴影开关两处相反、
            aberrant/aberration 两种词形、姊妹 mod 四种写法、一份文档三个版本号）。
            外加一条不属于文字但直接影响文字的：<strong className="text-alarm">发布工作流仍会以另一个 mod 的身份发布本 mod</strong>。
          </p>
        </div>

        <div ref={paperRef} className="paper relative overflow-hidden p-5">
          <div className="absolute inset-x-0 top-0 h-[3px] origin-left transition-transform duration-[1200ms]"
            style={{ background: "#8c5308", transform: `scaleX(${ink})` }} />
          <div className="font-mono text-[9.5px] uppercase tracking-[0.26em]" style={{ color: "#8c5308" }}>
            判定 / verdict
          </div>
          <ul className="mt-3 space-y-3">
            {([
              ["易读性", "Readability", "合格偏好", 0.86, "#165b63"],
              ["准确性", "Accuracy", "有系统性缺口", 0.52, "#8c5308"],
              ["同一性", "Consistency", "最薄的一环", 0.44, "#5d2675"],
            ] as const).map(([zh, en, verdict, v, c]) => (
              <li key={zh}>
                <div className="flex items-baseline justify-between gap-2">
                  <span className="text-[15px] font-semibold" style={{ color: "#3a2210" }}>{zh}</span>
                  <span className="font-mono text-[9.5px] uppercase tracking-[0.16em]" style={{ color: "#4e331b99" }}>{en}</span>
                </div>
                <div className="mt-1 h-[6px] w-full" style={{ background: "#3a221018" }}>
                  <div className="h-full transition-[width] duration-[1400ms] ease-out"
                    style={{ width: ink ? `${v * 100}%` : "0%", background: c }} />
                </div>
                <div className="mt-1 text-[12.5px]" style={{ color: c }}>{verdict}</div>
              </li>
            ))}
          </ul>
          <p className="mt-4 border-t pt-3 text-[12.5px] leading-relaxed" style={{ color: "#4e331bcc", borderColor: "#3a221022" }}>
            评分依据本页下方的实测项，不是印象分。三条各自独立：一份文案可以极易读而不准确（TXT-6），
            也可以完全准确而不同一（TXT-1/2）。
          </p>
        </div>
      </div>

      <Divider label="measured" />

      <div className="grid gap-5 xl:grid-cols-2">
        <Reveal>
          <div className="h-full border border-rule bg-ink-900/60 p-4 sm:p-5">
            <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-grass">
              语言覆盖实测 / {LANG_AUDIT.locales.length} locales × {LANG_AUDIT.keysPerLocale} keys
            </div>
            <div className="mt-4 grid grid-cols-3 gap-3">
              {[
                ["缺失键", LANG_AUDIT.missingVsEn, "#8cffb0"],
                ["多余键", LANG_AUDIT.extraVsEn, "#8cffb0"],
                ["GUI 面向键", LANG_AUDIT.guiFacingKeys, "#7cf0ff"],
              ].map(([k, v, c]) => (
                <div key={k as string} className="border border-rule/60 bg-ink-950/40 p-3">
                  <div className="tabnum font-display text-[30px] leading-none" style={{ color: c as string }}>{v as number}</div>
                  <div className="mt-1 font-mono text-[9.5px] uppercase tracking-[0.14em] text-muted/65">{k as string}</div>
                </div>
              ))}
            </div>
            <div className="mt-4">
              <div className="mb-2 font-mono text-[9.5px] uppercase tracking-[0.2em] text-muted/60">
                各语言 GUI 标签长度 / 相对 en_us（中位数 · P90 · 最大）
              </div>
              <ul className="space-y-1">
                {LANG_AUDIT.ratios.map((r) => (
                  <li key={r.loc} className="flex items-center gap-2.5">
                    <span className="w-12 shrink-0 font-mono text-[10.5px] text-muted/70">{r.loc}</span>
                    <div className="flex min-w-0 flex-1 items-center gap-[3px]">
                      <div className="h-[9px] transition-all duration-700" style={{ width: `${r.median * 42}px`, background: "#8cffb0", opacity: 0.85 }} title={`中位数 ${r.median}`} />
                      <div className="h-[9px] transition-all duration-700" style={{ width: `${Math.max(1, (r.p90 - r.median) * 42)}px`, background: "#ffdf88", opacity: 0.8 }} title={`P90 ${r.p90}`} />
                      <div className="h-[9px] transition-all duration-700" style={{ width: `${Math.max(1, (r.max - r.p90) * 42)}px`, background: "#ff7a7a", opacity: 0.75 }} title={`最大 ${r.max}`} />
                    </div>
                    <span className="tabnum w-[76px] shrink-0 text-right font-mono text-[10px] text-cream/65">
                      {r.median.toFixed(2)} / {r.p90.toFixed(2)} / {r.max.toFixed(2)}
                    </span>
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-[12.5px] leading-relaxed text-cream/62">
                中位数 1.00 意味着<strong className="text-cream">半数以上的键在各语言里与英文等长或更短</strong>——这是翻译纪律，不是巧合。
                zh_cn / zh_tw 的 0.38 是汉字的信息密度。溢出只集中在极少数几个短按钮上，见右侧。
              </p>
            </div>
          </div>
        </Reveal>
        <Reveal delay={80}><OverflowChart /></Reveal>
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-2">
        <Reveal><ScaleScatter /></Reveal>
        <Reveal delay={80}>
          <div className="h-full border border-rule bg-ink-900/60 p-4 sm:p-5">
            <div className="font-mono text-[10px] uppercase tracking-[0.24em] text-cyan">
              贴图实尺寸 vs 绘制尺寸 / {TEXTURE_SCALE.filter((t) => t.exact).length} 类 1:1，其余非整数倍
            </div>
            <ul className="mt-4 space-y-2">
              {TEXTURE_SCALE.map((t) => (
                <li key={t.tex}>
                  <div className="flex items-baseline gap-2 font-mono text-[10.5px]">
                    <span className="truncate text-cream/75">{t.tex}</span>
                    <span className="text-muted/45">{t.native} → {t.drawn}</span>
                    <span className={cn("ml-auto tabnum shrink-0", t.exact ? "text-grass" : t.ratio > 2 ? "text-alarm" : "text-warn")}>
                      ×{t.ratio.toFixed(2)}
                    </span>
                  </div>
                  <Meter value={t.ratio} max={6.5} color={t.exact ? "#8cffb0" : t.ratio > 2 ? "#ff7a7a" : "#ffb86c"} height={4} style={{ marginTop: 3 }} />
                </li>
              ))}
            </ul>
            <p className="mt-4 border-t border-rule/60 pt-3 text-[13px] leading-relaxed text-cream/68">
              <code className="font-mono text-[12px] text-cyan">drawNineSlice</code> 的 javadoc 承诺「corner studs and borders stay 1:1 razor-sharp at any target rectangle size」。
              四个角确实 1:1；<strong className="text-cream">边与中心按上表的比例被非整数倍拉伸</strong>——而像素美术在非整数倍下恰恰会发虚。
              主面板 48→308（×6.42）是整套界面的骨架。详见 TXT-5。
            </p>
          </div>
        </Reveal>
      </div>

      <Divider label="interactive" />
      <Reveal><ShrinkSim /></Reveal>

      <Callout label="这一页想解决的那「一大问题」" color="#e3b2ff">
        把三个词拆开看，它们的修法完全不同。<strong className="text-cream">易读性</strong>是渲染层的工程问题：建立字号令牌、
        统一 minScale、在小字号下关掉阴影、给截断加省略号与续页。<strong className="text-cream">准确性</strong>是数据流问题：
        文案里的数字必须从已同步的 <code className="font-mono text-[12px] text-cyan">EconomyConfig</code> 格式化出来，而不是抄进 11 个语言文件；
        章节引用必须有静态检查兜底。<strong className="text-cream">同一性</strong>是治理问题：一份术语表、一处 mod id 对照、
        一个版本戳，然后让 <code className="font-mono text-[12px] text-cyan">check_release_consistency.sh</code> 的检查范围覆盖 GDD 与 CHANGELOG。
        三条都不是「重写文案」，都是「给文案加上让它不会腐烂的结构」。
      </Callout>

      <Divider label={`${TEXT_FINDINGS.length} findings`} />

      <div className="mb-5 flex flex-wrap items-center gap-2">
        <span className="mr-1 font-mono text-[9.5px] uppercase tracking-[0.22em] text-muted/60">按维度筛选</span>
        {(["all", ...kinds] as const).map((k) => {
          const on = active === k;
          const color = k === "all" ? "#f6efe2" : KIND_META[k as keyof typeof KIND_META].color;
          return (
            <button key={k} type="button" onClick={() => setActive(k as typeof active)}
              className={cn("border px-2.5 py-1 font-mono text-[10.5px] uppercase tracking-[0.14em] transition-all duration-200",
                on ? "bg-cream/[0.07]" : "border-rule text-muted hover:border-current/40")}
              style={{ borderColor: on ? color : undefined, color: on ? color : undefined }}>
              {k === "all" ? `全部 ${counts.all}` : `${KIND_META[k as keyof typeof KIND_META].zh} ${counts[k]}`}
            </button>
          );
        })}
      </div>

      <ul className="space-y-4">
        {shown.map((f, i) => (
          <FindingCard key={f.id} f={{
            ...f,
            kindLabel: (
              <span className="border px-1.5 py-[2px] font-mono text-[9.5px] uppercase tracking-[0.14em]"
                style={{ color: KIND_META[f.kind].color, borderColor: `${KIND_META[f.kind].color}44` }}>
                {KIND_META[f.kind].zh}
              </span>
            ),
          }} index={i + 1} />
        ))}
      </ul>
    </div>
  );
}
