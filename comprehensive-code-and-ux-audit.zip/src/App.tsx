import { useCallback, useEffect, useState } from "react";
import { PageFooter, Shell } from "@/components/Shell";
import { PATHS, type PathId } from "@/data/findings";
import Overview from "@/pages/Overview";
import AuditPath from "@/pages/AuditPath";
import Numbers from "@/pages/Numbers";
import TextPage from "@/pages/Text";
import Skeptic from "@/pages/Skeptic";

const VALID_PATHS = new Set<string>(PATHS.map((p) => p.id));

function readHash(): string {
  const h = window.location.hash.replace(/^#/, "");
  return h === "" || h === "/" ? "/" : h;
}

export default function App() {
  const [route, setRoute] = useState<string>(() =>
    typeof window === "undefined" ? "/" : readHash(),
  );

  useEffect(() => {
    const onHash = () => setRoute(readHash());
    window.addEventListener("hashchange", onHash);
    if (!window.location.hash) window.history.replaceState(null, "", "#/");
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
    const label = titleFor(route);
    if (label) document.title = `${label} · 融合附魔 0.6.0 源码审计`;
  }, [route]);

  const render = useCallback(() => {
    if (route === "/numbers") return <Numbers />;
    if (route === "/text") return <TextPage />;
    if (route === "/skeptic") return <Skeptic />;
    if (route.startsWith("/audit/")) {
      const id = route.slice("/audit/".length) as PathId;
      if (VALID_PATHS.has(id)) return <AuditPath id={id} />;
      return <NotFound route={route} />;
    }
    if (route === "/") return <Overview />;
    return <NotFound route={route} />;
  }, [route]);

  return (
    <Shell route={route} footer={<PageFooter route={route} />}>
      {render()}
    </Shell>
  );
}

function titleFor(route: string): string {
  if (route === "/") return "审计总览";
  if (route === "/numbers") return "数值与机制";
  if (route === "/text") return "文案三性";
  if (route === "/skeptic") return "怀疑与建议";
  if (route.startsWith("/audit/")) {
    const p = PATHS.find((x) => `#/audit/${x.id}`.slice(1) === route);
    return p ? `${p.n} ${p.zh}` : "";
  }
  return "";
}

function NotFound({ route }: { route: string }) {
  return (
    <div className="py-20 text-center">
      <div className="font-display text-[clamp(3rem,9vw,6rem)] leading-none text-alarm/80">404</div>
      <p className="mt-3 font-mono text-[12px] uppercase tracking-[0.2em] text-muted">
        未知路径 · {route}
      </p>
      <a
        href="#/"
        className="mt-6 inline-block border border-gold/50 px-4 py-2 font-mono text-[11px] uppercase tracking-[0.18em] text-gold transition-colors hover:bg-gold/10"
      >
        ← 回到审计总览
      </a>
    </div>
  );
}
