import { useEffect, useState, type ReactNode } from "react";
import { cn } from "@/utils/cn";
import { PATHS } from "@/data/findings";

export const NAV: { href: string; n: string; zh: string; en: string }[] = [
  { href: "#/", n: "00", zh: "审计总览", en: "Overview" },
  { href: "#/numbers", n: "08", zh: "数值与机制", en: "Numbers & Design" },
  { href: "#/text", n: "09", zh: "文案三性", en: "Text: Read · Accurate · Same" },
  { href: "#/skeptic", n: "10", zh: "怀疑与建议", en: "Skepticism & Proposals" },
];

const RUNES = "ᚠᚢᚦᚨᚱᚲᚷᚹᚺᚾᛁᛃᛇᛈᛉᛊᛏᛒᛖᛗᛚᛜᛞᛟ⌁⌂⌇◇◆▷▣▤▥";

function RuneColumn({ side }: { side: "left" | "right" }) {
  const chars = Array.from({ length: 90 }, (_, i) => RUNES[(i * 7 + (side === "left" ? 0 : 11)) % RUNES.length]);
  return (
    <div
      aria-hidden
      className={cn(
        "pointer-events-none fixed top-0 z-0 hidden h-screen w-8 overflow-hidden xl:block",
        side === "left" ? "left-0" : "right-0",
      )}
    >
      <div className="animate-rune flex flex-col gap-3 pt-4 font-mono text-[13px] leading-none text-cyan/[0.13]">
        {chars.map((c, i) => (
          <span key={i} className={cn("block text-center", i % 5 === 0 && "text-amethyst/[0.16]")}>
            {c}
          </span>
        ))}
        {chars.map((c, i) => (
          <span key={`b${i}`} className="block text-center">
            {c}
          </span>
        ))}
      </div>
    </div>
  );
}

export function Ambient() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
      <div className="absolute inset-0 bg-ink-950" />
      <div className="bg-grid absolute inset-0 opacity-[0.55]" />
      <div
        className="absolute -left-[18%] top-[-14%] size-[62vw] animate-breathe rounded-full"
        style={{
          background:
            "radial-gradient(circle at 50% 50%, rgba(22,91,99,.42), rgba(22,91,99,0) 66%)",
          filter: "blur(14px)",
        }}
      />
      <div
        className="absolute -right-[16%] bottom-[-20%] size-[56vw] animate-breathe rounded-full"
        style={{
          background:
            "radial-gradient(circle at 50% 50%, rgba(93,38,117,.34), rgba(93,38,117,0) 68%)",
          filter: "blur(16px)",
          animationDelay: "-9s",
        }}
      />
      <div className="bg-grain absolute inset-0 opacity-[0.035] mix-blend-overlay" />
      <div
        className="absolute inset-x-0 top-0 h-px opacity-40"
        style={{ background: "linear-gradient(90deg,transparent,#7cf0ff,transparent)" }}
      />
      <div className="absolute inset-0 shadow-[inset_0_0_220px_60px_rgba(0,0,0,.72)]" />
      <RuneColumn side="left" />
      <RuneColumn side="right" />
    </div>
  );
}

function ScrollProgress() {
  const [p, setP] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setP(h > 0 ? (window.scrollY / h) * 100 : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);
  return (
    <div className="fixed inset-x-0 top-0 z-50 h-[2px] bg-ink-800">
      <div
        className="h-full transition-[width] duration-150 ease-out"
        style={{
          width: `${p}%`,
          background: "linear-gradient(90deg,#165b63,#7cf0ff 55%,#ffdf88)",
        }}
      />
    </div>
  );
}

function NavList({
  route,
  onNavigate,
  dense,
}: {
  route: string;
  onNavigate?: () => void;
  dense?: boolean;
}) {
  const Item = ({
    href,
    n,
    zh,
    en,
  }: {
    href: string;
    n: string;
    zh: string;
    en: string;
  }) => {
    const active = route === href.replace("#", "");
    return (
      <a
        href={href}
        onClick={onNavigate}
        className={cn(
          "group relative flex items-baseline gap-2.5 border-l-2 py-[7px] pl-3 pr-2 transition-all duration-200",
          active
            ? "border-gold bg-gold/[0.07]"
            : "border-transparent hover:border-cyan/50 hover:bg-cream/[0.035]",
        )}
      >
        <span
          className={cn(
            "font-mono text-[10px] tracking-widest transition-colors",
            active ? "text-gold" : "text-muted/70 group-hover:text-cyan",
          )}
        >
          {n}
        </span>
        <span className="min-w-0 flex-1">
          <span
            className={cn(
              "block truncate text-[13.5px] leading-tight transition-colors",
              active ? "text-cream" : "text-cream/72 group-hover:text-cream",
            )}
          >
            {zh}
          </span>
          <span className="block truncate font-mono text-[9.5px] uppercase tracking-[0.14em] text-muted/55">
            {en}
          </span>
        </span>
      </a>
    );
  };

  return (
    <nav className={cn("flex flex-col", dense && "gap-0")}>
      <Item {...NAV[0]} />
      <div className="mt-3 mb-1 flex items-center gap-2 pl-3">
        <span className="font-mono text-[9.5px] uppercase tracking-[0.28em] text-muted/60">
          七路审计 / Seven passes
        </span>
        <span className="h-px flex-1 bg-rule/70" />
      </div>
      {PATHS.map((p) => (
        <Item key={p.id} href={`#/audit/${p.id}`} n={p.n} zh={p.zh} en={p.en} />
      ))}
      <div className="mt-3 mb-1 flex items-center gap-2 pl-3">
        <span className="font-mono text-[9.5px] uppercase tracking-[0.28em] text-muted/60">
          专页 / Special pages
        </span>
        <span className="h-px flex-1 bg-rule/70" />
      </div>
      {NAV.slice(1).map((n) => (
        <Item key={n.href} {...n} />
      ))}
    </nav>
  );
}

export function Shell({
  route,
  children,
  footer,
}: {
  route: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [route]);

  return (
    <div className="relative min-h-screen">
      <Ambient />
      <ScrollProgress />

      {/* mobile bar */}
      <header className="sticky top-0 z-40 flex items-center justify-between border-b border-rule bg-ink-950/92 px-4 py-2.5 backdrop-blur-sm lg:hidden">
        <a href="#/" className="flex items-baseline gap-2">
          <span className="font-display text-[19px] leading-none text-gold">融合附魔</span>
          <span className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-muted">
            audit · 0.6.0
          </span>
        </a>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          className="border border-rule px-2.5 py-1 font-mono text-[10.5px] uppercase tracking-[0.18em] text-cream/80 transition-colors hover:border-gold/60 hover:text-gold"
        >
          {open ? "关闭 ✕" : "目录 ☰"}
        </button>
      </header>
      {open && (
        <div className="fixed inset-x-0 top-[45px] bottom-0 z-40 overflow-y-auto border-b border-rule bg-ink-950/97 px-3 py-4 lg:hidden">
          <NavList route={route} onNavigate={() => setOpen(false)} dense />
        </div>
      )}

      <div className="relative z-10 mx-auto flex w-full max-w-[1500px]">
        {/* desktop rail */}
        <aside className="sticky top-0 hidden h-screen w-[248px] shrink-0 overflow-y-auto border-r border-rule/70 bg-ink-950/55 px-3 py-6 lg:block">
          <a href="#/" className="mb-6 block pl-3">
            <div className="font-display text-[26px] leading-[0.95] text-gold">
              融合附魔
            </div>
            <div className="mt-1 font-mono text-[9.5px] uppercase leading-relaxed tracking-[0.18em] text-muted">
              enchantment_fusion
              <br />
              source audit dossier
            </div>
            <div className="mt-2.5 inline-flex items-center gap-1.5 border border-grass/30 bg-grass/[0.06] px-1.5 py-[2px] font-mono text-[9.5px] tracking-[0.14em] text-grass">
              <span className="size-[5px] animate-pulse rounded-full bg-grass" />
              v0.6.0 · MC 26.1.2
            </div>
          </a>
          <NavList route={route} />
          <div className="mt-7 border-t border-rule/70 pl-3 pt-4 font-mono text-[9.5px] leading-relaxed tracking-[0.1em] text-muted/55">
            静态审计 · 未编译 · 未运行
            <br />
            <span className="text-muted/40">static reading only</span>
          </div>
        </aside>

        <main className="min-w-0 flex-1 px-4 pb-24 pt-6 sm:px-7 lg:px-11 lg:pt-10">
          {children}
          {footer}
        </main>
      </div>
    </div>
  );
}

export function PageFooter({ route }: { route: string }) {
  const order = [
    "#/",
    ...PATHS.map((p) => `#/audit/${p.id}`),
    "#/numbers",
    "#/text",
    "#/skeptic",
  ];
  const href = order.includes(route) ? route : "#/";
  const i = order.indexOf(href);
  const prev = i > 0 ? order[i - 1] : null;
  const next = i < order.length - 1 ? order[i + 1] : null;
  const label = (h: string) => {
    if (h === "#/") return "审计总览";
    if (h === "#/numbers") return "数值与机制";
    if (h === "#/text") return "文案三性";
    if (h === "#/skeptic") return "怀疑与建议";
    return PATHS.find((p) => `#/audit/${p.id}` === h)?.zh ?? h;
  };
  return (
    <footer className="mt-20 flex flex-col gap-3 border-t border-rule pt-6 sm:flex-row sm:items-center sm:justify-between">
      {prev ? (
        <a
          href={prev}
          className="group flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.16em] text-muted transition-colors hover:text-cyan"
        >
          <span className="transition-transform group-hover:-translate-x-1">←</span>
          {label(prev)}
        </a>
      ) : (
        <span />
      )}
      <span className="font-mono text-[10px] tracking-[0.14em] text-muted/45">
        q14433686-arch/chiseled-enchanting-table-26.1.2-source · arena/11fcd984 · tree dbbd808
      </span>
      {next ? (
        <a
          href={next}
          className="group flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.16em] text-muted transition-colors hover:text-gold sm:justify-end"
        >
          {label(next)}
          <span className="transition-transform group-hover:translate-x-1">→</span>
        </a>
      ) : (
        <span />
      )}
    </footer>
  );
}
