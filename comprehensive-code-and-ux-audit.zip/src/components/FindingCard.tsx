import { useState, type ReactNode } from "react";
import { cn } from "@/utils/cn";
import { ConfTag, Code, Reveal, SevTag } from "@/components/Bits";
import { SEV_META, type Confidence, type Severity } from "@/data/findings";

export interface CardShape {
  id: string;
  sev: Severity;
  conf?: Confidence;
  title: string;
  titleEn?: string;
  where?: string;
  claim?: string;
  why?: string;
  fix?: string;
  code?: string;
  kind?: string;
  kindLabel?: ReactNode;
}

export function FindingCard({
  f,
  index,
  codeCaption,
  defaultOpen = false,
}: {
  f: CardShape;
  index?: number;
  codeCaption?: string;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen || !!f.code && f.sev === "P0");
  const m = SEV_META[f.sev];
  const isCredit = f.sev === "OK";

  return (
    <Reveal as="li" className="list-none">
      <article
        className={cn(
          "group relative border bg-ink-900/55 transition-all duration-300",
          isCredit
            ? "border-grass/25 hover:border-grass/55 hover:bg-grass/[0.045]"
            : "border-rule hover:bg-ink-850/70",
        )}
        style={{ boxShadow: `inset 3px 0 0 ${isCredit ? "#8cffb055" : `${m.color}44`}` }}
      >
        {/* header */}
        <header className="flex flex-wrap items-start gap-x-3 gap-y-2 px-4 pt-3.5 sm:px-5">
          <span className="mt-[3px] font-mono text-[11px] font-medium tracking-[0.1em]" style={{ color: m.color }}>
            {f.id}
          </span>
          <div className="min-w-0 flex-1">
            <h3
              className={cn(
                "text-[16.5px] font-semibold leading-snug tracking-tight",
                isCredit ? "text-grass" : "text-cream",
              )}
            >
              {f.title}
            </h3>
            {f.titleEn && (
              <p className="mt-0.5 font-display text-[14.5px] italic leading-snug text-muted/80">
                {f.titleEn}
              </p>
            )}
          </div>
          <div className="flex shrink-0 flex-wrap items-center justify-end gap-1.5">
            {f.kindLabel}
            <SevTag sev={f.sev} compact />
          </div>
        </header>

        {/* meta strip */}
        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1.5 border-y border-rule/60 bg-ink-950/40 px-4 py-2 sm:px-5">
          {f.where && (
            <span className="font-mono text-[10.5px] leading-relaxed text-cyan/75">
              <span className="text-muted/55">↳ </span>
              {f.where}
            </span>
          )}
          {f.conf && <ConfTag conf={f.conf} />}
          {typeof index === "number" && (
            <span className="ml-auto font-mono text-[10px] tracking-[0.16em] text-muted/40">
              #{String(index).padStart(2, "0")}
            </span>
          )}
        </div>

        {/* body */}
        <div className="px-4 py-3.5 sm:px-5">
          {f.claim && (
            <Block label="现象 / what the code does" color="#7cf0ff">
              {f.claim}
            </Block>
          )}
          {f.why && (
            <Block label={isCredit ? "为什么值得学 / why it matters" : "为什么是问题 / why it bites"} color={isCredit ? "#8cffb0" : "#ffb86c"}>
              {f.why}
            </Block>
          )}
          {f.fix && (
            <Block label="建议 / proposed fix" color={isCredit ? "#7cf0ff" : "#ffdf88"}>
              {f.fix}
            </Block>
          )}

          {f.code && (
            <div className="mt-3">
              <button
                type="button"
                onClick={() => setOpen((v) => !v)}
                aria-expanded={open}
                className="inline-flex items-center gap-2 border border-rule bg-ink-950/70 px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.18em] text-muted transition-all duration-200 hover:border-cyan/50 hover:text-cyan"
              >
                <span
                  className={cn(
                    "inline-block transition-transform duration-200",
                    open && "rotate-90",
                  )}
                >
                  ▸
                </span>
                {open ? "收起证据" : "查看证据代码"}
              </button>
              <div
                className={cn(
                  "grid transition-[grid-template-rows,opacity] duration-300 ease-out",
                  open ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                )}
              >
                <div className="overflow-hidden">
                  <Code tone={isCredit ? "ok" : f.sev === "P0" || f.sev === "P1" ? "bad" : "warn"} caption={codeCaption ?? f.where?.split(" · ")[0]}>
                    {f.code}
                  </Code>
                </div>
              </div>
            </div>
          )}
        </div>
      </article>
    </Reveal>
  );
}

function Block({
  label,
  color,
  children,
}: {
  label: string;
  color: string;
  children: ReactNode;
}) {
  return (
    <div className="mb-3 last:mb-0">
      <div
        className="mb-1 font-mono text-[9.5px] uppercase tracking-[0.22em]"
        style={{ color: `${color}bb` }}
      >
        {label}
      </div>
      <p className="text-[14.5px] leading-[1.82] text-cream/78">{children}</p>
    </div>
  );
}
