import {
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import { cn } from "@/utils/cn";
import { CONF_META, SEV_META, type Confidence, type Severity } from "@/data/findings";

/* ───────────────────────── scroll reveal ───────────────────────── */
export function Reveal({
  children,
  delay = 0,
  className,
  as: As = "div",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  as?: "div" | "section" | "li" | "article" | "tr";
}) {
  const ref = useRef<HTMLElement | null>(null);
  const [seen, setSeen] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) {
            setSeen(true);
            io.disconnect();
          }
        }
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.06 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const Comp = As as "div";
  return (
    <Comp
      ref={ref as never}
      className={cn("reveal", seen && "is-in", className)}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Comp>
  );
}

/* ───────────────────────── count-up ───────────────────────── */
export function Counter({
  to,
  suffix = "",
  duration = 1100,
  className,
}: {
  to: number;
  suffix?: string;
  duration?: number;
  className?: string;
}) {
  const [n, setN] = useState(0);
  const ref = useRef<HTMLSpanElement | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let raf = 0;
    const io = new IntersectionObserver(
      (entries) => {
        if (!entries[0]?.isIntersecting) return;
        io.disconnect();
        const t0 = performance.now();
        const tick = (t: number) => {
          const p = Math.min(1, (t - t0) / duration);
          const eased = 1 - Math.pow(1 - p, 3);
          setN(Math.round(to * eased));
          if (p < 1) raf = requestAnimationFrame(tick);
        };
        raf = requestAnimationFrame(tick);
      },
      { threshold: 0.4 },
    );
    io.observe(el);
    return () => {
      io.disconnect();
      cancelAnimationFrame(raf);
    };
  }, [to, duration]);

  return (
    <span ref={ref} className={cn("tabnum", className)}>
      {n.toLocaleString("en-US")}
      {suffix}
    </span>
  );
}

/* ───────────────────────── severity / confidence chips ───────────────────────── */
export function SevTag({ sev, compact }: { sev: Severity; compact?: boolean }) {
  const m = SEV_META[sev];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 font-mono uppercase tracking-[0.14em] border",
        compact ? "px-1.5 py-[1px] text-[9.5px]" : "px-2 py-[3px] text-[10.5px]",
      )}
      style={{ color: m.color, borderColor: `${m.color}55`, background: m.bg }}
    >
      <i
        className="inline-block size-[5px] rotate-45"
        style={{ background: m.color }}
      />
      {compact ? sev : m.label}
      {!compact && <span className="opacity-60 normal-case tracking-normal">/ {m.zh}</span>}
    </span>
  );
}

export function ConfTag({ conf }: { conf: Confidence }) {
  const m = CONF_META[conf];
  const color =
    conf === "verified" ? "#8cffb0" : conf === "static-high" ? "#ffdf88" : "#7cf0ff";
  return (
    <span
      title={m.note}
      className="inline-flex cursor-help items-center gap-1 border border-current/25 px-1.5 py-[2px] font-mono text-[9.5px] uppercase tracking-[0.12em]"
      style={{ color }}
    >
      {conf === "verified" ? "◈" : conf === "static-high" ? "◇" : "?"} {m.zh}
    </span>
  );
}

/* ───────────────────────── typography furniture ───────────────────────── */
export function Kicker({
  children,
  color = "#7cf0ff",
  className,
}: {
  children: ReactNode;
  color?: string;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex items-center gap-2.5 font-mono text-[10.5px] uppercase tracking-[0.3em]",
        className,
      )}
      style={{ color }}
    >
      <span className="inline-block h-px w-6" style={{ background: color, opacity: 0.5 }} />
      {children}
    </div>
  );
}

export function SectionTitle({
  n,
  zh,
  en,
  color = "#f6efe2",
}: {
  n?: string;
  zh: string;
  en?: string;
  color?: string;
}) {
  return (
    <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1">
      {n && (
        <span className="font-mono text-[13px] tracking-widest" style={{ color: "#b5ac9e" }}>
          {n}
        </span>
      )}
      <h2
        className="font-display text-[clamp(1.9rem,4.4vw,3.3rem)] leading-[1.02] tracking-tight"
        style={{ color }}
      >
        {zh}
      </h2>
      {en && (
        <span className="font-mono text-[11px] uppercase tracking-[0.24em] text-muted">
          {en}
        </span>
      )}
    </div>
  );
}

export function Code({
  children,
  caption,
  tone = "neutral",
}: {
  children: string;
  caption?: string;
  tone?: "neutral" | "bad" | "warn" | "ok";
}) {
  const bar =
    tone === "bad"
      ? "#ff7a7a"
      : tone === "warn"
        ? "#ffb86c"
        : tone === "ok"
          ? "#8cffb0"
          : "#3d4859";
  return (
    <figure className="my-4 overflow-hidden border border-rule bg-ink-950/80">
      <div className="flex items-center gap-2 border-b border-rule bg-ink-900 px-3 py-1.5">
        <span className="inline-block h-2 w-2" style={{ background: bar }} />
        <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-muted">
          {caption ?? "source"}
        </span>
      </div>
      <pre className="codeblock overflow-x-auto px-3.5 py-3 text-cream/85">
        <code>{children}</code>
      </pre>
    </figure>
  );
}

export function Callout({
  label,
  color,
  children,
}: {
  label: string;
  color: string;
  children: ReactNode;
}) {
  return (
    <div
      className="my-4 border-l-2 bg-ink-900/60 py-3 pl-4 pr-4"
      style={{ borderColor: color }}
    >
      <div
        className="mb-1.5 font-mono text-[10px] uppercase tracking-[0.24em]"
        style={{ color }}
      >
        {label}
      </div>
      <div className="text-[14.5px] leading-[1.75] text-cream/80">{children}</div>
    </div>
  );
}

export function Meter({
  value,
  max,
  color,
  height = 6,
  style,
}: {
  value: number;
  max: number;
  color: string;
  height?: number;
  style?: CSSProperties;
}) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div
      className="relative w-full overflow-hidden bg-ink-700/70"
      style={{ height, ...style }}
    >
      <div
        className="absolute inset-y-0 left-0 transition-[width] duration-[1100ms] ease-out"
        style={{ width: `${pct}%`, background: color }}
      />
    </div>
  );
}

export function Divider({ label }: { label?: string }) {
  return (
    <div className="my-10 flex items-center gap-3">
      <span className="h-px flex-1 bg-rule" />
      {label && (
        <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-muted">
          {label}
        </span>
      )}
      <span className="h-px flex-1 bg-rule" />
    </div>
  );
}
