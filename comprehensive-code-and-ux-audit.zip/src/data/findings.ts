export type Severity = "P0" | "P1" | "P2" | "P3" | "OK";
export type PathId =
  | "api"
  | "codec"
  | "net"
  | "gui"
  | "mixin"
  | "dead"
  | "coupling";

export type Confidence = "verified" | "static-high" | "needs-runtime";

export interface Finding {
  id: string;
  path: PathId;
  sev: Severity;
  conf: Confidence;
  title: string;
  titleEn: string;
  where: string;
  claim: string;
  why: string;
  fix: string;
  code?: string;
}

export const PATHS: {
  id: PathId;
  n: string;
  zh: string;
  en: string;
  blurb: string;
  accent: string;
}[] = [
  {
    id: "api",
    n: "01",
    zh: "源码 API",
    en: "Source API",
    blurb:
      "公开面的命名、契约与形状：一个叫 baseInstabilityChance 却装着 repulsiveFailChance 的字段、一个会被客户端快照污染的服务端权威读取口、8 参数 4 布尔的评估函数。",
    accent: "#7cf0ff",
  },
  {
    id: "codec",
    n: "02",
    zh: "数据编解码",
    en: "Data codec",
    blurb:
      "Codec / StreamCodec / NBT / JSON 四条序列化路径的边界是否对齐：持久化无界而网络上限 64 条的组件、三种互相矛盾的等级校验策略、只读最上层数据包的资源加载器。",
    accent: "#e3b2ff",
  },
  {
    id: "net",
    n: "03",
    zh: "网络同步",
    en: "Network sync",
    blurb:
      "自定义 payload 的方向、上限、幂等与失败反馈：防竞态 token 恰好没有盖住唯一会花钱的那个动作、以无序 fastutil map 的下标当线序参数、静默 4096 截断。",
    accent: "#ffdf88",
  },
  {
    id: "gui",
    n: "04",
    zh: "GUI 输入",
    en: "GUI input",
    blurb:
      "鼠标／键盘到服务端动作的整条链：一个按钮三种语义、点击被吃掉却毫无反馈、-1/-2 哨兵值挤在同一个同步字段里、切页顺手关掉单附魔模式。",
    accent: "#ffb86c",
  },
  {
    id: "mixin",
    n: "05",
    zh: "Mixin 注入",
    en: "Mixin injection",
    blurb:
      "注入点、目标类与作用域：铁砧守卫的豁免条件写错了物品、为 ServerPlayer 的逻辑给所有 LivingEntity 加了字段、以类名前缀 \".Cet\" 当配置开关。",
    accent: "#ff7a7a",
  },
  {
    id: "dead",
    n: "06",
    zh: "死代码",
    en: "Dead code",
    blurb:
      "零调用者的公开方法、逐字节重复的两份判定、为绕开局部 record 作用域而写的反射、以及一个从未被读取的 schema_version。",
    accent: "#b5ac9e",
  },
  {
    id: "coupling",
    n: "07",
    zh: "耦合风险",
    en: "Coupling risk",
    blurb:
      "改一处会连带崩几处：Java 里硬编码的 tag 镜像被测试当成真值、setChanged() 每次换物都广播整包、Python 测试复刻 Java 像素常量、以及唯一撤销手段挂在可选依赖上。",
    accent: "#8cffb0",
  },
];

export const FINDINGS: Finding[] = [
  /* ───────────────────────── 01 源码 API ───────────────────────── */
  {
    id: "API-1",
    path: "api",
    sev: "P1",
    conf: "verified",
    title: "Snapshot.baseInstabilityChance 是个假字段名",
    titleEn: "A record component whose name lies about its contents",
    where:
      "data/FusionMatrixRegistry.java:77 · :267 · :369 / menu/FusionNetworking.java:198",
    claim:
      "Snapshot 的第三个分量声明为 baseInstabilityChance（基础失稳概率），但全仓库三处构造点传入的都是 economy.repulsiveFailChance()（互斥强融失败率，默认 0.45）。网络层反序列化时同样把 eco.repulsiveFailChance() 塞进这个位置。",
    why:
      "同一个数值在代码里有三个名字：JSON 的 base_instability_chance、EconomyConfig 的 repulsiveFailChance、Snapshot 的 baseInstabilityChance。任何读到 snapshot.baseInstabilityChance() 的人都会以为拿到了一个全局失稳率，实际拿到的是互斥档专属失败率。这不是风格问题——它是 API 语义错误，且因为名字听起来合理，编译器和评审都不会拦。",
    fix: "删掉 Snapshot.baseInstabilityChance，统一走 snapshot.economy().repulsiveFailChance()；如果确实想保留一个全局失稳率，就在 economy.json 里给它独立的一格，并让 parseEconomy 分开读取。",
    code: `// FusionMatrixRegistry.parseFromJson — 结尾
return new Snapshot(
    Collections.unmodifiableMap(mergedProfiles),
    Collections.unmodifiableList(groups),
    eco.repulsiveFailChance(),   // ← 装进名为 baseInstabilityChance 的分量
    eco
);

// FusionNetworking.MatrixSyncPayload.read — 同样的错位
return new MatrixSyncPayload(new FusionMatrixRegistry.Snapshot(
    ..., eco.repulsiveFailChance(), eco));`,
  },
  {
    id: "API-2",
    path: "api",
    sev: "P0",
    conf: "verified",
    title: "服务端权威逻辑读取的是「客户端覆盖快照」",
    titleEn: "Server-authoritative rules read a client-owned override",
    where:
      "data/FusionMatrixRegistry.java:163-167 → mechanics/FusionRuleEngine.java:85 · mechanics/FusionEconomyRules.java:125,200,245 · mechanics/MatrixEffectExecutor.java:167",
    claim:
      "current() 的实现是「clientOverride 非空就返回它，否则返回 serverActive」。而 FusionRuleEngine.evaluateFusion（合法性判定）、FusionEconomyRules（报价／失败率）、MatrixEffectExecutor（效果执行）全部调用 current()。setClientSnapshot 由客户端 MatrixSyncPayload 接收器写入。",
    why:
      "在单机／局域网（集成服务端）里，客户端线程与服务端线程共享同一个 JVM 的同一批 static。玩家进服 → 服务端把 serverActive 同步给客户端 → 客户端写 clientOverride → 此后服务端的规则判定与扣费全部走 clientOverride 这条分支。今天两者内容相同所以无症状；一旦出现「同步滞后一帧」「/reload 后 END_DATA_PACK_RELOAD 尚未跑完就有玩家操作」「未来加入客户端本地预览覆写」，服务端就会以客户端手里的旧数据为准。这是把权威性方向接反了。",
    fix:
      "服务端路径一律改为 serverSnapshot()，客户端渲染路径单独提供 clientView()。或者把 current() 改名为 viewFor(EnvType) 并强制调用方声明自己所处的边。同时给 check_architecture_boundaries.py 加一条：mechanics/** 不得出现 current()。",
    code: `public static Snapshot current() {
    Snapshot override = clientOverride;   // 客户端写入的
    return override != null ? override : serverActive;
}
// FusionRuleEngine.evaluateFusion(...)  ← 服务端判定
FusionMatrixRegistry.Snapshot matrix = FusionMatrixRegistry.current();
// FusionEconomyRules.computeSynthesisQuote(...)  ← 服务端扣费
EconomyConfig eco = FusionMatrixRegistry.current().economy();`,
  },
  {
    id: "API-3",
    path: "api",
    sev: "P2",
    conf: "verified",
    title: "evaluateFusion：8 个位置参数，其中 4 个是布尔",
    titleEn: "Boolean-blind 8-argument validator",
    where: "mechanics/FusionRuleEngine.java:69-79",
    claim:
      "evaluateFusion(primary, secondary, targetingEquipment, existingHostFusions, existingHostEnchantIds, maxHostVesselSlots, extraRuntimeIncompatiblePair, incompatibleWithExistingHost)。第 3、7、8 位都是 boolean，第 6 位是 int。",
    why:
      "布尔盲（boolean blindness）：把 targetingEquipment 和 incompatibleWithExistingHost 写反，编译器完全无异议，运行时表现为「本该拒绝的融合被放行」——正是这个函数唯一要防的事。三个连续布尔在调用点读起来是 (…, true, false, true)，评审者必须回去数参数位置。",
    fix:
      "收成参数对象：evaluateFusion(EnchantInput a, EnchantInput b, FusionContext ctx)，ctx 用 builder 或 record 承载 host 相关状态；布尔改为具名方法 ctx.targetsEquipment() / ctx.hasRuntimeIncompatiblePair()。",
  },
  {
    id: "API-4",
    path: "api",
    sev: "P3",
    conf: "verified",
    title: "为「外部调用者」保留的兼容重载，一个外部调用者都没有",
    titleEn: "Back-compat overloads for consumers that do not exist",
    where:
      "FusionRuleEngine.java:44 (EnchantInput 4 参) · FusionEconomyRules.java:75 (EconomyQuote 6 参) · :181 (computeConversionQuote 4 参) · FusionStationOperations.java:130 (StationPreview 9 参) · FusionMatrixRegistry.java:80 / :188",
    claim:
      "至少 6 处「少一个参数的旧签名」重载，转发到全参版本并硬编码默认值。其中 EnchantInput 的第 4 个形参直接命名为 ignoredLegacyFitsHost 并被丢弃。",
    why:
      "这是一个 0.6.0、未发布到 Modrinth/CurseForge、没有公开 API 面的 mod。兼容重载的唯一作用是让调用点少写一个参数，代价是每个类型都有两条构造路径、默认值散落在重载里而不是集中在 canonical 构造器。ignoredLegacyFitsHost 更糟：测试代码在用它（FusionRuleEngineTest 里 6 处），传 true/false 都毫无效果，读者会以为它改变了判定。",
    fix: "删掉全部转发重载，调用点补全参数；把 ignoredLegacyFitsHost 从测试里一并清掉。如果确有对外 API 计划，先写 package-info 声明哪些类是 public API，再谈兼容层。",
    code: `public record EnchantInput(String id, int level, int maxLevel) {
    public EnchantInput(String id, int level, int maxLevel,
                        boolean ignoredLegacyFitsHost) {
        this(id, level, maxLevel);   // 第 4 个参数被吃掉
    }
}`,
  },
  {
    id: "API-5",
    path: "api",
    sev: "P1",
    conf: "verified",
    title: "FusedPair 对同一个字段有两套互相矛盾的校验契约",
    titleEn: "One field, two contradictory validation contracts",
    where: "model/FusedPair.java:23-33 · :37-48 · :59-66",
    claim:
      "ENCHANT_ID_CODEC 用 Identifier.tryParse 校验，失败返回 DataResult.error（拒绝）；紧凑构造器同样 tryParse，但失败时执行 primaryId = primaryId.trim() 并把垃圾留下（放行）；STREAM_CODEC 用 stringUtf8(128) 完全不校验，超长直接抛 EncoderException。",
    why:
      "读盘（JSON/NBT）会拒绝非法 ID，而任何 Java 代码路径都能造出一个 ID 非法的 FusedPair。这个对象一旦被 set 到物品组件上，落盘时 CODEC 的编码端是恒等函数 s -> s，不再校验，于是非法 ID 被写进世界存档；下次读档 CODEC 解码端报错 → 组件解析失败 → 物品损坏或区块加载报错。网络路径则是另一种死法：>128 字符在写包时抛异常，玩家被踢。同一个类型，三种失败模式，其中两种是延迟爆炸。",
    fix:
      "紧凑构造器改为 Objects.requireNonNull + 校验失败抛 IllegalArgumentException（快速失败，编程错误就该炸），或统一走 ENCHANT_ID_CODEC 的拒绝语义；STREAM_CODEC 前置一个长度断言并给出可读错误。三处契约必须同源。",
    code: `// codec：拒绝
Identifier parsed = Identifier.tryParse(raw.trim());
return parsed != null ? DataResult.success(parsed.toString())
                      : DataResult.error(() -> "Invalid enchantment identifier: " + raw);

// 紧凑构造器：放行垃圾
primaryId = pParsed != null ? pParsed.toString() : primaryId.trim();

// stream：不校验，超长即抛
ByteBufCodecs.stringUtf8(128), FusedPair::primaryId,`,
  },
  {
    id: "API-6",
    path: "api",
    sev: "OK",
    conf: "verified",
    title: "值得肯定：API 面整体是「窄而显式」的",
    titleEn: "Credit where due: a narrow, explicit surface",
    where: "全仓库",
    claim:
      "所有工具类都是 final + private 构造器；record 是主要的数据载体；RejectReason 把 langKey 绑在枚举上而不是散在 switch 里；PayloadType/TriggerType/HostForm 都自带 translationKey()，翻译键由枚举名机械推导，不存在手抄键名的空间。",
    why:
      "这套习惯让「文案同一性」在枚举派生的那一大批键上做到了结构性保证——这也是 829×11 语言零漂移能成立的底层原因之一。",
    fix: "保持。唯一建议：把 translationKey() 的前缀字符串（\"fusion.enchantment_fusion.trigger.\" 等）也收进一个 Keys 常量类，目前 5 个类各自拼前缀。",
  },

  /* ───────────────────────── 02 数据编解码 ───────────────────────── */
  {
    id: "DATA-1",
    path: "codec",
    sev: "P0",
    conf: "verified",
    title: "TRANSMUTED_ENCHANTS：落盘无界，上网限 64 条",
    titleEn: "Unbounded on disk, capped at 64 on the wire",
    where: "registry/FusionDataComponents.java:33-49",
    claim:
      "persistent 用 Codec.unboundedMap(Codec.STRING, Codec.intRange(1,255))；networkSynchronized 用 ByteBufCodecs.map(HashMap::new, stringUtf8(128), VAR_INT, 64)。",
    why:
      "两个边界不对齐就是一个延迟炸弹。通过 /give 或任何服务端逻辑造出第 65 条化形附魔的物品 → 存档写入成功（无界）→ 之后每一次同步该物品（打开容器、丢出、展示框、发给客户端）都会触发 EncoderException → 玩家被断开，或该物品所在区块无法正常下发。而且它不会在制造时炸，只会在传播时炸，排查现场离病因很远。键长同理：落盘接受任意长度 STRING，上网限 128。",
    fix:
      "两条路径共享同一个上界常量（例如 MAX_TRANSMUTED = 64），persistent 端改用有界 map 或在写入前截断并记日志；或者把网络端的上限提到与业务上限一致并加断言。任何成对的 codec/streamCodec 都应该由同一个常量驱动。",
    code: `.persistent(
    Codec.unboundedMap(Codec.STRING, Codec.intRange(1, 255))   // 无界
        .xmap(Collections::unmodifiableMap, m -> m))
.networkSynchronized(
    ByteBufCodecs.map(HashMap::new,
        ByteBufCodecs.stringUtf8(128),
        ByteBufCodecs.VAR_INT.map(...),
        64)                                                     // 上限 64
    .map(Collections::unmodifiableMap, HashMap::new))`,
  },
  {
    id: "DATA-2",
    path: "codec",
    sev: "P2",
    conf: "verified",
    title: "同一个「附魔等级」概念有四种校验策略",
    titleEn: "Four validation strategies for one integer",
    where:
      "model/FusedPair.java:52-58 · registry/FusionDataComponents.java:38,44,55,64",
    claim:
      "VESSEL_BONUS / PAGE_TIER 用 Codec.intRange（越界即拒绝）；TRANSMUTED_ENCHANTS 的值用 intRange(1,255)（拒绝）+ 网络端 Math.clamp（钳制）；FusedPair 的等级用 Codec.INT（不校验）+ 紧凑构造器 clamp + 网络端 clamp。",
    why:
      "「拒绝」和「钳制」是两种完全不同的产品决定：拒绝会让整条组件解析失败（可能连带物品丢失），钳制会静默改变玩家的数据。混用时没人能说清一个越界存档到底会发生什么。同一个 mod 内部对同一语义给出四种答案，后续加字段时只能靠猜。",
    fix:
      "定一条规则并写进 docs/GDD.md：所有来自世界存档的数值一律 clamp（保护玩家数据），所有来自数据包配置的数值一律 reject（保护包作者尽早发现错误）。然后让 LevelCodec 工具类统一实现，字段只声明区间。",
  },
  {
    id: "DATA-3",
    path: "codec",
    sev: "P1",
    conf: "verified",
    title: "资源加载只取最上层数据包，economy.json 无法叠加",
    titleEn: "getResource() instead of getResourceStack(): no multi-pack merge",
    where: "data/FusionDataLoader.java:57-64",
    claim:
      "readJson 用 manager.getResource(path)，只在存在时返回最上层那一个 Resource；三个 JSON（matrix_profiles / repulsive_pairs / economy）都是这个路径。matrix_profiles 走 parseFromJson 与内建默认合并，但合并的基准是 Java 里的 createBuiltInSnapshot()，不是「下层数据包的版本」。",
    why:
      "两个整合包都想调 economy.json 时，只有一个生效，且是整文件覆盖——想改 repulsive_min_floor 一格，必须把其余 7 格连同未来新增的格全部抄一遍，抄漏的那格会静默回到 Java 默认值。这与 vanilla 注册表目录（data/<ns>/<type>/）逐文件叠加的直觉相反，也与 README/GDD 宣称的「数据包可配」不匹配：可配，但不可组合。",
    fix:
      "改用 manager.getResourceStack(path) 自下而上逐层深合并（JsonObject 级别），或把 economy 拆成 data/enchantment_fusion/economy/<name>.json 目录式注册，交给 vanilla 的多包叠加机制。",
  },
  {
    id: "DATA-4",
    path: "codec",
    sev: "P2",
    conf: "verified",
    title: "repulsive 分支缺 isJsonPrimitive 守卫，坏 JSON 静默回退",
    titleEn: "Asymmetric JSON guards; malformed packs fail silently",
    where: "data/FusionMatrixRegistry.java:210-235 vs :196-206",
    claim:
      "matrix 分支写的是 matrixObj.get(\"replace\").isJsonPrimitive() && …getAsBoolean()；repulsive 分支直接 repulsiveObj.get(\"replace\").getAsBoolean()、p.get(\"remove\").getAsBoolean()、idEl.getAsString()，没有类型检查。外层 FusionDataLoader 用 catch (Exception) 兜住并「保留上一份快照」。",
    why:
      "把 \"replace\": \"yes\" 写成字符串、或 exclusive_groups 里塞进一个对象，Gson 会抛 UnsupportedOperationException；被 catch 吞掉后 /reload 表面上成功，日志里只有一行 error，游戏里跑的是旧配置。包作者会得到「我改了但没生效」的反馈，而这正是最难自查的一类故障。同一个文件里两个分支守卫强度不同，说明这不是有意的策略而是遗漏。",
    fix:
      "抽一个 readBool(obj,key,def) / readStringArray(...) 工具，与 readDouble/readInt 同一套风格；并且把 reload 失败升级为玩家可见反馈（给 OP 发一条 systemMessage），而不只是 LOGGER.error。",
  },
  {
    id: "DATA-5",
    path: "codec",
    sev: "P1",
    conf: "verified",
    title: "秘典存档：一个坏条目会清空所有人的进度",
    titleEn: "One malformed player record wipes every player's progress",
    where: "mechanics/CompendiumDiscoveryTracker.java:443-472",
    claim:
      "loadWorldFile 把整个 for (entry : root.entrySet()) 循环包在一个 try 里；循环体内 UUID.fromString(entry.getKey()) 与 kv.getValue().getAsInt() 都会抛异常；catch 记一行 warn 后返回。",
    why:
      "存档文件里只要有一个键不是合法 UUID（手工编辑、别的 mod 误写、半截写入）或有一个值不是整数，整个加载在第一个坏条目处中断，SERVER_STATES 停在「已 clear、部分填充」的状态——所有排在该条目之后的玩家进度全部丢失，而日志只有一行 warn。这不是降级，是全量数据损坏。",
    fix:
      "把 try/catch 移到循环体内，逐玩家隔离；坏条目计数并在结束时汇总一行日志（含最多 5 个样本键）。同时给写入端加一个 magic/version 字段，读到不认识的版本时保留原文件不覆盖（另存 .corrupt）。",
    code: `try {
    String raw = Files.readString(path, UTF_8);
    JsonObject root = JsonParser.parseString(raw).getAsJsonObject();
    for (Map.Entry<String, JsonElement> entry : root.entrySet()) {
        UUID uuid = UUID.fromString(entry.getKey());   // ← 抛则整个循环终止
        ...
        states.put(kv.getKey(), Math.clamp(kv.getValue().getAsInt(), ...));
    }
} catch (Exception ex) {
    LOGGER.warn("Failed to read compendium file {}: {}", path, ex.toString());
}`,
  },
  {
    id: "DATA-6",
    path: "codec",
    sev: "P2",
    conf: "verified",
    title: "秘典存档绕过 LevelSavedData，且在服务端线程上整文件重写",
    titleEn: "Raw file in <world>/data, rewritten wholesale on the tick thread",
    where: "mechanics/CompendiumDiscoveryTracker.java:117-126（tick 节流）· :438-441（路径）· :475-503（原子写）",
    claim:
      "resolveSaveFile 指向 <world>/data/enchantment_fusion_compendium.json；SERVER_STATES 是 static Map<UUID, Map<String,Integer>>，只在 SERVER_STOPPING 时 clear；保存由 END_SERVER_TICK 的 tick % 200 == 0 触发，用 setPrettyPrinting 的 Gson 序列化全部玩家后同步写盘。",
    why:
      "三个叠加的问题：(1) 不走 LevelSavedData，所以拿不到 vanilla 的存档生命周期钩子，也不能被依赖该机制的工具正确识别；(2) Map 只增不减，历史上登录过的每个玩家都永久驻留内存与磁盘——1 万名老玩家 × 174 键 × 约 30 字节，pretty-print 后是一份数 MB 的 JSON，每 10 秒重写一次；(3) 重写发生在服务端主线程，一次同步磁盘 IO 就是一次可感知的 TPS 抖动。",
    fix:
      "迁到 LevelSavedData（或 Fabric 的 PersistentStateManager 等价物）；给离线超过 N 天的玩家条目做惰性淘汰；写盘移到 Util.ioPool()，主线程只负责生成不可变快照；关掉 pretty-printing 或只在 --debug 时开。",
  },
  {
    id: "DATA-7",
    path: "codec",
    sev: "OK",
    conf: "verified",
    title: "值得肯定：原子落盘与优雅截断做对了",
    titleEn: "Atomic temp-file + move, and graceful truncation",
    where:
      "CompendiumDiscoveryTracker.java:490-500 · model/FusedEnchantmentList.java:19-27",
    claim:
      "保存走 临时文件 → ATOMIC_MOVE，并捕获 IOException 回退到非原子 move；FusedEnchantmentList 的构造器与 CODEC 都会把超量 pairs 截断到 HARD_MAX_VESSEL_SLOTS 而不是整体拒绝。",
    why:
      "「旧命令生成的超限物品不该让玩家丢光所有词条」是一个真实的运维考虑，截断而非拒绝是对的选择；原子替换也是这类小 JSON 存档唯一正确的写法。两处都注明了动机（DATA-01 / DATA-03），可追溯。",
    fix: "保持。补一条测试：截断发生时应当记一行 warn，目前是静默的。",
  },

  /* ───────────────────────── 03 网络同步 ───────────────────────── */
  {
    id: "NET-1",
    path: "net",
    sev: "P0",
    conf: "verified",
    title: "防竞态 token 恰好没有盖住唯一会花钱的动作",
    titleEn: "The race token guards the harmless actions, not the expensive one",
    where:
      "menu/FusionNetworking.java:36-42（NET-03 注释）· client/gui/EnchantmentFusionScreen.java:976, 949-972, 909",
    claim:
      "StationActionPayload 带 expectedToken，服务端 resolveCandidateIndex 在 token 非空时按 selectionToken 匹配、匹配不到就返回 -1（拒绝）。但客户端发送 EXECUTE_PRIMARY 时写死 sendAction(EXECUTE_PRIMARY, 0, 0, \"\")；FLIP_SOCKET 与 UNSOCKET_OR_SPLIT 同样是 \"\"。只有 PICK_PRIMARY_A / PICK_SECONDARY_B 传了真实 token。",
    why:
      "融合台是共享 Container（多人可同时打开同一台）。注释明确说 token 是为了防「shared-table slot races」。但 PICK_* 只改一个下标、无副作用；真正不可逆、扣经验、消耗材料、可能生成畸变词条的是 EXECUTE_PRIMARY，它走的却是服务端自己记的 preferredPrimaryIndex/preferredSecondaryIndex。甲玩家点了执行，乙玩家在这一瞬间抽走了槽 0 的书，甲付了钱、拿到了另一个组合。防护装在了错误的门上。",
    fix:
      "EXECUTE_PRIMARY 必须携带 token 对（primary + secondary 各一个，或一个组合哈希）；服务端在 executePrimaryOperation 里先校验 token，不匹配则拒绝并回一条 action_rejected。FLIP_SOCKET / UNSOCKET_OR_SPLIT 应携带被操作 pair 的稳定指纹（primaryId+secondaryId+levels 的哈希）而不是列表下标。",
    code: `// EnchantmentFusionScreen.mouseClicked
sendAction(StationAction.EXECUTE_PRIMARY, 0, 0, "");   // ← token 为空

// FusionNetworking：token 机制本身是对的
private static int resolveCandidateIndex(List<EnchantCandidate> cands,
                                         int fallbackIndex, String expectedToken) {
    if (expectedToken != null && !expectedToken.isEmpty()) {
        for (int i = 0; i < cands.size(); i++)
            if (expectedToken.equals(cands.get(i).selectionToken())) return i;
        return -1;                       // 拒绝
    }
    return (fallbackIndex >= 0 && fallbackIndex < cands.size()) ? fallbackIndex : -1;
}`,
  },
  {
    id: "NET-2",
    path: "net",
    sev: "P1",
    conf: "static-high",
    title: "行下标来自无序 map，却当作线序参数传输",
    titleEn: "Row indices derived from an unordered fastutil map are sent on the wire",
    where:
      "mechanics/FusionStationOperations.java:143-179（collectCandidates / appendBookEnchantments）",
    claim:
      "候选列表由 gearEnchants.entrySet()（ItemEnchantments 内部的 Object2IntOpenHashMap）与 stored.entrySet() 的遍历顺序构建；这个 List 的下标随后作为 paramA 发给服务端，也决定 UI 里第几行显示什么。",
    why:
      "fastutil 开放寻址表的迭代顺序取决于插入顺序与哈希分布，不是稳定序。服务端的原始物品与同步到客户端的副本，其 map 重建顺序可以不同（反序列化按写入序插入，而写入序来自另一次遍历）。结果：同一件装备，客户端可能把「时运 III」画在第 1 行、服务端认为第 1 行是「效率 V」。token 机制在执行时能挡住错配（前提是传了 token，见 NET-1），但挡不住显示顺序在两个客户端之间不一致，也挡不住列表增删后下标整体漂移。",
    fix:
      "collectCandidates 出口处按稳定键排序（sourceSlot → enchantmentId → level），让下标成为确定性函数；或者干脆不传下标，全程只传 selectionToken，服务端自己反查。",
  },
  {
    id: "NET-3",
    path: "net",
    sev: "P2",
    conf: "verified",
    title: "秘典同步静默截断到 4096，客户端无从得知",
    titleEn: "Silent 4096-entry truncation with no client-side signal",
    where:
      "menu/FusionNetworking.java:117-121 · :307-314 · mechanics/CompendiumDiscoveryTracker.java:373-383",
    claim:
      "CompendiumSyncPayload 的 codec 是 stringUtf8(128).apply(list(4096))；sendCompendiumSync 在超过 4096 时 subList 截断后再发，不记日志、不设标志位。encodeStates 先 Collections.sort 再输出，所以被丢掉的永远是字典序最大的那批键。",
    why:
      "截断策略与业务语义冲突：排序后砍尾意味着 aberration/…、sig/…、transmute/… 这三类前缀里字典序靠后的会被系统性丢弃（transmute/ 排在最后，280 条化形词条首当其冲）。玩家看到的是「这些我永远解锁不了」，而实际上服务端有记录。没有任何诊断能让人区分「真没解锁」和「被截断了」。",
    fix:
      "要么把上限提到覆盖理论最大条目数（sig 348 + transmute 280 + pair + aberrant ≈ 800 量级，4096 其实够用——那就把截断改成断言+日志，因为触发即 bug），要么改用位图/分段增量协议。至少：截断时 LOGGER.warn 并在 payload 里带一个 truncated 布尔，客户端在秘典页脚显示提示。",
  },
  {
    id: "NET-4",
    path: "net",
    sev: "P2",
    conf: "verified",
    title: "最高频的那条路径绕开了增量通道",
    titleEn: "The highest-frequency path bypasses the delta channel built for it",
    where: "mechanics/CompendiumDiscoveryTracker.java:117-126 · :176-180",
    claim:
      "END_SERVER_TICK 每 20 tick 对每个在线玩家跑 scanPlayerInventory；一旦 bulkChanged 为真，就 sendCompendiumSync(player, encodeStates(...))——整表重发。而 CompendiumDeltaPayload（注释标为 NET-05，专为单条解锁设计）只在 advanceState / recordDiscovery / unlockCandidateWithDelta 里用。scanPlayerInventory 内部调的是 advanceStateInternal（不发 delta）。",
    why:
      "玩家在刷怪塔里捡书、或身上带着多件融合装备时，每秒都可能触发一次全量重发：编码 800 条字符串、排序、写包、客户端重建整张 map。增量协议已经写好并且更便宜，却因为 scan 路径调了内部方法而被绕过。这是「性能优化做了但没接到最需要的地方」。",
    fix:
      "让 scanPlayerInventory 收集本次变更的 (key, stage) 列表，逐条走 sendCompendiumDelta；只在 JOIN 与检测到客户端状态可能失步时做全量。顺便把 20 tick 的轮询换成事件驱动（InventoryChangeEvents / SlotClick 回调）。",
  },
  {
    id: "NET-5",
    path: "net",
    sev: "P2",
    conf: "verified",
    title: "翻面／卸除失败时服务端完全沉默",
    titleEn: "Server stays mute when flip / unsocket fails",
    where:
      "menu/FusionNetworking.java:295-303 · mechanics/FusionStationOperations.java:867-872, 923-928",
    claim:
      "接收器里只有 if (!ok && action == EXECUTE_PRIMARY) 才 sendSystemMessage。executeFlipSocket / executeUnsocketOrSplit 有 6 个不同的 return false 出口：目标为空、下标越界、canFlipPair 拒绝（畸变锁定）、与载体不兼容、经验不足、化形附魔查不到。",
    why:
      "六种失败原因，零种反馈。玩家点「⇄ 翻面」，没声音、没消息、按钮不变灰、tooltip 不解释，只能猜是钱不够还是这东西不能翻。RejectReason 枚举已经为每个原因准备好了 langKey（ABERRANT_LOCKED 等），基础设施齐全，只是没接上。这是最廉价的一处体验修复。",
    fix:
      "把这两个操作的返回类型从 boolean 改为 RejectReason（NONE 表示成功），接收器统一对非 NONE 发 sendSystemMessage(translatable(reason.langKey()), RED)。顺带覆盖 EXECUTE_PRIMARY 之外的所有动作。",
  },
  {
    id: "NET-6",
    path: "net",
    sev: "P3",
    conf: "verified",
    title: "视觉事件广播遍历全服玩家，半径 48 硬编码",
    titleEn: "Visual events iterate every player on the level with a hardcoded radius",
    where: "menu/FusionNetworking.java:344-361",
    claim:
      "broadcastVisualEvent 对 level.players() 全量遍历，用 distanceToSqr <= 48.0*48.0 过滤，中心点写死 pos + 0.5D。",
    why:
      "48 格与 vanilla 的实体追踪距离（默认 10 区块 / 视距相关）无关，是一个凭手感选的值；O(在线玩家) 的遍历在 200 人服上每次融合仪式都要跑一遍，而这类事件本来就该走区块追踪集合。0.5D 偏移也应当用 Vec3.atCenterOf(pos)。",
    fix:
      "改用 PlayerFinderLayerEvent / ChunkMap 的追踪玩家集合（Fabric 提供 PlayerLookup.tracking(blockEntity)），半径常量提到类顶部并加注释说明取值依据。",
  },
  {
    id: "NET-7",
    path: "net",
    sev: "OK",
    conf: "verified",
    title: "值得肯定：协议层的防御密度高于同类 mod 平均水平",
    titleEn: "Above-average protocol discipline",
    where: "menu/FusionNetworking.java 全文",
    claim:
      "显式稳定的 wire ID（10–17）而非 enum.ordinal()；每个解码字段都过 Math.clamp（含 profiles 2048、groups 256、每组 64、概率 0..1、stabilizers 0..16）；发送前一律 canSend 守卫；派发前连过三关（containerMenu instanceof / containerId 相等 / stillValid）；DISCONNECT 清理速率桶与客户端快照；每 tick 10 次的动作速率上限。",
    why:
      "这一层的作者显然想过「恶意客户端」与「共享方块实体」两种威胁模型。可惜威胁模型的落点选错了（NET-1），但骨架是对的——修 NET-1 只需要加两个 token 参数，不需要重构。",
    fix: "保持，并按 NET-1 把 token 覆盖到 EXECUTE / FLIP / UNSOCKET。",
  },

  /* ───────────────────────── 04 GUI 输入 ───────────────────────── */
  {
    id: "GUI-1",
    path: "gui",
    sev: "P0",
    conf: "verified",
    title: "一个「⇄」按钮，三种互不相干的服务端行为",
    titleEn: "One swap button, three unrelated server behaviours",
    where: "menu/EnchantmentFusionMenu.java:226-244",
    claim:
      "SWAP_ORDER 分支：若已有 A/B 选择且处于 TAB_FUSE 且两者来自不同槽位且 cands.size() == 2 → 物理交换槽 0/1 的物品；否则若已有 A/B 选择 → 只交换 uiState 里的下标；若完全没有选择 → 又回到物理交换物品。客户端只发 sendAction(SWAP_ORDER, 0, 0, \"\")。",
    why:
      "同一个图标、同一次点击，可能「换书的位置」也可能「换 A/B 的指派」，取决于一个玩家看不见也推不出的条件（候选数是否恰好为 2）。当一本书带 3 条附魔时 cands.size() > 2，按钮语义悄悄从「动物品」变成「动选择」。这是把三态逻辑压进一个二态控件，而且判定条件是隐式的。",
    fix:
      "拆成两个控件：⇄ 交换输入槽（动物品，图标带两个方块）、⇅ 交换 A/B 指派（动选择，图标带两个字母），各自有 tooltip 与禁用态。若必须保留单按钮，则行为由「点击时是否已有 A/B 选择」单一条件决定，并在按钮 tooltip 里实时写明本次点击会做什么。",
    code: `case SWAP_ORDER -> {
    ...
    if (cur.primaryIndex() >= 0 && cur.secondaryIndex() >= 0) {
        if (activeTab() == TAB_FUSE && p != null && s != null
            && p.sourceSlot() != s.sourceSlot()
            && cands.size() == 2) {                 // ← 隐式三态开关
            changed = FusionStationOperations.swapInputSlots(stationInv);
        } else {
            uiState.set(1, cur.secondaryIndex());   // 只动选择
            uiState.set(2, cur.primaryIndex());
        }
    } else {
        changed = FusionStationOperations.swapInputSlots(stationInv);  // 又动物品
    }
}`,
  },
  {
    id: "GUI-2",
    path: "gui",
    sev: "P1",
    conf: "verified",
    title: "点击被吃掉却不给任何反馈（5 处）",
    titleEn: "Clicks are consumed with zero feedback in five places",
    where: "client/gui/EnchantmentFusionScreen.java:949-975",
    claim:
      "if (clickedFlip) { if (mState.canExecute()) sendAction(...); playClickSound(...); return true; } —— return true 在 if 外面。EXECUTE 按钮同样先判 preview.executable() && canAffordPreview(preview) 才发；Tab1 的行内按钮先判 p.isAberrant() || !canAffordXp(...) 再 continue。所有分支都 return true 吞掉事件。",
    why:
      "吞掉事件 = 告诉 Minecraft「这里有个控件」；不发声音不发消息 = 告诉玩家「你的点击没有意义」。这两件事同时发生，是最典型的「按钮看起来能按但按了没反应」。皮肤层其实已经准备好了 BTN_DISABLED 贴图，只在 EXECUTE 上用了（!ready 时切换），Flip/Split 路径没有接。",
    fix:
      "每个可点区域先算 enabled，再决定：enabled → 发送 + 音效；!enabled → 播一个低音「拒绝」音效 + 在按钮下方一行显示具体原因（复用 RejectReason.langKey）+ 使用 BTN_DISABLED 皮肤。永远不要在 !enabled 时静默 return true。",
  },
  {
    id: "GUI-3",
    path: "gui",
    sev: "P1",
    conf: "verified",
    title: "切页会顺手关掉「仅单附魔」开关",
    titleEn: "Switching tabs silently clears the single-mode toggle",
    where:
      "menu/EnchantmentFusionMenu.java:140-146（isSingleModeToggled / singleOnlyMode）· :180-186（SELECT_TAB）· :245-252（EXECUTE_PRIMARY）",
    claim:
      "uiState[2] 同时承载三种含义：-1 = 未选 B、-2 = 单附魔模式开启、>=0 = 候选行下标。SELECT_TAB 与 EXECUTE_PRIMARY 成功后都执行 uiState.set(1,-1); uiState.set(2,-1)。isSingleModeToggled() 的判据就是 uiState.get(2) == -2。",
    why:
      "切页与执行成功都会把 -2 冲掉，于是「仅单附魔」被无声关闭。玩家在 Tab② 打开了单附魔模式，切去 Tab① 看一眼再切回来，模式已经没了，而按钮皮肤（singleSprite 的 64×18 / 32×32 二选一）会跟着变——但这个变化发生在一次页面切换里，几乎没人会注意到是自己丢的。执行成功后重置也值得商榷：连续做几次单附魔化形是常见操作。",
    fix:
      "把 SimpleContainerData(3) 扩到 (4)，单附魔模式独占一格布尔；或者用 -2 之外的独立字段。执行成功后只重置 A/B 选择，不动模式位。",
  },
  {
    id: "GUI-4",
    path: "gui",
    sev: "P2",
    conf: "verified",
    title: "-2 这个哨兵值在两个类里各写了一遍，没有名字",
    titleEn: "The -2 sentinel is duplicated across two classes with no name",
    where:
      "menu/EnchantmentFusionMenu.java:140-146, 205, 219 · mechanics/FusionStationOperations.java:192",
    claim:
      "resolveSelection 里写 if (preferredB == -2) return new ResolvedSelection(candidates, a, -1);；菜单里写 if (uiState.get(2) == -2) 与 uiState.set(2, -2)。没有任何常量声明。",
    why:
      "跨类的裸魔法数是最容易在重构中失散的耦合：有人把菜单侧改成 -3，服务端侧的 == -2 就永远不成立，表现为「单附魔模式点了没反应」，而两边代码看起来都没错。ContainerData 同步为 short 也意味着未来任何超过 32767 的取值都会被静默截断——目前安全，但没有任何注释说明这条约束。",
    fix:
      "public static final int SINGLE_MODE_SENTINEL = -2; NO_SECONDARY = -1; 放在一个共享常量类里，两处引用；并在 uiState 字段上补注释说明它是 short 同步的。更彻底的方案见 GUI-3。",
  },
  {
    id: "GUI-5",
    path: "gui",
    sev: "P2",
    conf: "verified",
    title: "过期下标静默回落到「第 0 行」，而不是「无选择」",
    titleEn: "A stale index silently falls back to row 0 instead of nothing",
    where:
      "mechanics/FusionStationOperations.java:182-207（resolveSelection）· menu/EnchantmentFusionMenu.java:160-167",
    claim:
      "int a = (preferredA >= 0 && preferredA < n) ? preferredA : 0; —— 越界时取 0。菜单侧的 resolveCandidateIndex 越界时取 -1。两者对「过期下标」的态度相反。",
    why:
      "玩家从槽 0 抽走一本书，候选表整体缩短，服务端的 preferredPrimaryIndex 变成越界值 → resolveSelection 把它当成「第 0 行」→ 预览面板立刻显示一个玩家从未选择过的、可执行的融合。玩家如果此时点执行：传了 token 会被拒（好），没传 token（EXECUTE_PRIMARY 正是没传，见 NET-1）就会真的执行这个自动选择。",
    fix:
      "resolveSelection 越界一律返回 (-1,-1)（无选择），让预览进入 idle 态；同时 quickMoveStack / setItem 后主动清空 uiState 的选择位。",
  },
  {
    id: "GUI-6",
    path: "gui",
    sev: "P3",
    conf: "verified",
    title: "isDoubleClick 被接收后丢弃；命中盒几何在 3 处各写一遍",
    titleEn: "Double-click ignored; hitbox geometry triplicated",
    where:
      "client/gui/EnchantmentFusionScreen.java:868, 1006 · :856-861 vs :914-918 · scripts/test_ui_readability.py:41-52",
    claim:
      "mouseClicked(MouseButtonEvent, boolean isDoubleClick) 与 mouseDragged 都转发 isDoubleClick 给 overlay，但主屏从不使用它。行高 17 / 行内高 16 / 起始 Y 86 或 36 / 可见行数 2 或 3 / 行宽 122 或 RIGHT_W 这组数字，在 mouseScrolled、mouseClicked 和 Python 测试里各出现一次。for (idx = 0; idx < socketed.size() && idx < 2; idx++) 又把 HARD_MAX_VESSEL_SLOTS 写成了字面量 2。",
    why:
      "双击整组移动是 vanilla 容器的既有肌肉记忆，在自定义列表上不生效会被当成 bug 报上来。几何三写的问题更实际：改行高要同时改两个 Java 方法和一个 Python 文件，漏一处就得到「点第 3 行选中第 4 行」这类难复现的偏移。",
    fix:
      "抽 record RowGeometry(int startY, int pitch, int rowH, int rows, int width) 由 tab 派生，三处共用；Python 测试改为从 Java 源里正则提取常量（或干脆让 clientSmoke 在真实客户端里量）。双击补上「连续点击同一行 → 执行」的语义。",
  },
  {
    id: "GUI-7",
    path: "gui",
    sev: "OK",
    conf: "verified",
    title: "值得肯定：预览按帧缓存，overlay 转发链完整一致",
    titleEn: "Frame-cached preview and a complete overlay forwarding chain",
    where:
      "client/gui/EnchantmentFusionScreen.java:680（cachedFramePreview）· :848-1042",
    claim:
      "渲染路径用 cachedFramePreview 而不是每帧重算 computePreview()（后者会扫全部 41 格玩家背包来数材料）；mouseScrolled / mouseClicked / mouseDragged / mouseReleased / keyPressed / charTyped 六个入口全部先转发给 grimoireOverlay 再落回 super，顺序一致。",
    why:
      "把「每帧一次全背包扫描」这个显而易见的性能陷阱提前避开了，说明作者 profile 过或至少想过。六个输入方法转发顺序一致也不是必然的——很多 mod 会漏掉 mouseReleased 或 charTyped，导致 overlay 打开时按键穿透。",
    fix: "保持。建议把 cachedFramePreview 的失效条件写进注释（目前只能靠读代码推断）。",
  },

  /* ───────────────────────── 05 Mixin 注入 ───────────────────────── */
  {
    id: "MIX-1",
    path: "mixin",
    sev: "P1",
    conf: "verified",
    title: "铁砧守卫的豁免条件认错了物品",
    titleEn: "The anvil guard's carve-out checks the wrong item",
    where: "mixin/AnvilCrossDomainGuardMixin.java:48-70",
    claim:
      "注释写「Book + Book merges stay vanilla」，实现是 if (left.is(Items.ENCHANTED_BOOK)) return;。随后 if (!right.is(Items.ENCHANTED_BOOK)) 时检查右侧是否带 FUSED_PAIRS / TRANSMUTED_ENCHANTS，若有则清空结果槽并把 cost 设为 0。本 mod 自己的 FUSED_ENCHANTED_BOOK 是 FusionItems 里的独立物品，不等于 Items.ENCHANTED_BOOK。",
    why:
      "把一本「融合附魔书」放进铁砧右格、左边放工具，是玩家最自然的尝试。代码判定它「不是附魔书」→ 进入 fused 检查 → 结果槽清空、cost 归零。玩家看到的是铁砧输出格空白、没有任何提示，也拿不回原因（注释里那句「stay vanilla」在这里恰恰没有生效）。豁免应该按语义（是不是 donor book）而不是按具体物品实例。",
    fix:
      "豁免条件改为 left.is(ENCHANTED_BOOK) || left.is(FusionItems.FUSED_ENCHANTED_BOOK)；右侧的 fused 保护同理，并在触发时给玩家一条 message.enchantment_fusion.anvil_blocked 提示。更稳的做法是引入 #enchantment_fusion:donor_books 物品标签，让数据包能扩展。",
  },
  {
    id: "MIX-2",
    path: "mixin",
    sev: "P2",
    conf: "needs-runtime",
    title: "注入点目标名无法被单元测试验证",
    titleEn: "Injection target strings are invisible to the unit test suite",
    where:
      "mixin/GrindstoneAberrationGuardMixin.java:21,33 · mixin/AnvilCrossDomainGuardMixin.java:50 · src/test/*（741 行，纯 JVM）",
    claim:
      "@Inject(method = \"computeResult\", …) 与 @Inject(method = \"createResult\", …) 用字符串指定目标；@Shadow @Final private DataSlot cost 用字段名指定。src/test 下 6 个测试类全部是纯 JVM（无 Minecraft 运行时），无法解析这些字符串。mixin 配置里 defaultRequire: 1、required: true，目标缺失会在启动时硬失败。",
    why:
      "compile-check / build 两个 CI 作业只能证明 Java 编译通过，证明不了 method = \"computeResult\" 在 26.1.2 的 GrindstoneMenu 里存在。真正能证明的只有 server-smoke 作业——但它是否覆盖了铁砧与砂轮这两条路径，取决于 scripts/server_smoke.py 的脚本内容，而不是取决于 mixin 本身。这类失败的表现是「启动即崩」或（require = 0 时）「功能静默失效」，两者都很难从编译日志里看出来。",
    fix:
      "在 server-smoke 里为每个 mixin 加一条可观察断言：铁砧放入 fused 书 → 结果槽必须为空；砂轮放入畸变物品 → 结果槽必须为空。让「注入点存在且生效」成为 CI 的一等结论，而不是「服务端能启动」的副产品。",
  },
  {
    id: "MIX-3",
    path: "mixin",
    sev: "P2",
    conf: "verified",
    title: "为 ServerPlayer 的逻辑，给所有 LivingEntity 加了字段",
    titleEn: "A ServerPlayer-only hook adds a field to every LivingEntity",
    where: "mixin/LivingEntityConsumableFusionMixin.java:20-30",
    claim:
      "@Mixin(LivingEntity.class) + @Unique private ItemStack ef$consumableSnapshot = ItemStack.EMPTY;。HEAD 注入里第一件事就是 if (self instanceof ServerPlayer && …)，非玩家一律走 else 把它置回 EMPTY。",
    why:
      "作用域过宽：世界里每个僵尸、每只牛、每个盔甲架上的 LivingEntity 都多了一个引用字段和两次注入调用，而 100% 的有效逻辑只对 ServerPlayer 生效。单看内存是一个引用，但 500 实体 × 每次 completeUsingItem 两次注入 + instanceof 判定，是纯粹的白开销；更重要的是它让「这个 mixin 关心谁」变得不可读。",
    fix:
      "改为 @Mixin(ServerPlayer.class)，@Shadow useItem 从 LivingEntity 继承照样可用，instanceof 判定整块删除。",
  },
  {
    id: "MIX-4",
    path: "mixin",
    sev: "P2",
    conf: "verified",
    title: "用类名里有没有 \".Cet\" 当 mixin 开关",
    titleEn: "A naming convention is doing the job of configuration",
    where: "mixin/FusionMixinConfigPlugin.java:28-36",
    claim:
      "shouldApplyMixin 的两条规则：targetClassName.startsWith(\"chiseled_enchanting_table.\") → 看 cetLoaded；mixinClassName.contains(\".Cet\") → 看 cetLoaded。跳过时不记日志。CURRENT_BASELINE.md 声明 15 个 mixin 中 9 个由该插件门控。",
    why:
      "约定即配置：将来有人写一个与姊妹 mod 无关、但名字里带 Cet 的 mixin（比如 CetXpCurveMixin 想表达别的意思），它会被静默跳过，且因为 defaultRequire 不适用于「未应用」，没有任何报错。反过来，一个门控 mixin 若被重命名去掉 Cet 前缀，就会在没装姊妹 mod 的环境里尝试注入并崩溃。命名是唯一的安全网，而命名不受任何检查约束。",
    fix:
      "改成显式清单：private static final Set<String> CET_GATED = Set.of(\"CetCleanseMechanicsBridgeMixin\", …); 并在 onLoad 里记一行 INFO 说明本次跳过了哪些、原因是什么。再加一条静态检查（scripts/ci_static_checks.py 已在做 mixin 配置完整性）验证「清单 ≡ mixins.json 里所有 Cet* 条目」。",
    code: `public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
    if (targetClassName != null && targetClassName.startsWith("chiseled_enchanting_table."))
        return this.cetLoaded;
    if (mixinClassName != null && mixinClassName.contains(".Cet"))   // ← 约定当配置
        return this.cetLoaded;
    return true;
}`,
  },
  {
    id: "MIX-5",
    path: "mixin",
    sev: "P1",
    conf: "verified",
    title: "姊妹 mod 桥接可以静默失效，且没有任何人会发现",
    titleEn: "The sister-mod bridge can silently stop working, forever",
    where:
      "mixin/CetDisenchantBridgeMixin.java:14-30 · compat/CetCleanseServerBridge.java · 其余 8 个 Cet* mixin",
    claim:
      "@Pseudo + @Mixin(targets = \"chiseled_enchanting_table.mechanics.enchanting.DisenchantmentApplication\", remap = false)，注入点是完整硬编码描述符字符串 \"apply(Lchiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler;Lchiseled_enchanting_table/menu/ChiseledEnchantingMenuPayloads$ApplyEnchantmentPayload;)V\"，并带 require = 0。全仓库找不到「注入未命中」时的日志。",
    why:
      "require = 0 + @Pseudo 是正确做法（缺类不崩），但它同时意味着姊妹 mod 只要重命名一个内部类或改一个方法签名，本 mod 的净化桥就会 100% 静默失效。玩家侧表现是「净化列表里不再出现融合词条」——一个很难归因的症状。而 GDD 明确写着 6 种畸变词条「唯《纂刻附魔台》可净化」，也就是说这条静默失效的桥，是某些物品状态唯一的撤销通道。",
    fix:
      "在 preApply/postApply 里记录每个 Cet* mixin 的应用结果；启动时若 isCetLoaded() 为真但没有任何桥接注入命中，LOGGER.error 一条明确警告。再加一条 CI 作业：拉取姊妹 mod 的最新 jar，用 ASM 校验这些描述符是否仍然存在（不需要运行游戏）。",
  },
  {
    id: "MIX-6",
    path: "mixin",
    sev: "P3",
    conf: "verified",
    title: "姊妹 mod 的两种拼法散落在三个文件",
    titleEn: "Two spellings of the sister mod id, in three places",
    where:
      "resources/fabric.mod.json (suggests) · mixin/FusionMixinConfigPlugin.java:20-22 · compat/CetSoftBridge.java:19-20",
    claim:
      "CetSoftBridge 定义了 CET_MOD_ID = \"chiseled-enchanting-table\" 与 CET_NAMESPACE = \"chiseled_enchanting_table\"；FusionMixinConfigPlugin 把这两个字面量重新抄了一遍（isModLoaded(…) || isModLoaded(…)）；fabric.mod.json 的 suggests 只列了连字符那一种。",
    why:
      "插件不能 import mod 类是有正当理由的（config plugin 在极早期加载，过早触发 mod 类初始化会连带拉起 Minecraft 类），所以这份重复本身可以接受——但代码里没有一行注释说明这一点，看起来就像单纯的复制粘贴。而 suggests 只声明一种拼法意味着：如果上游实际用的是下划线 id，Mod 列表里的「建议安装」提示不会出现。",
    fix:
      "在 FusionMixinConfigPlugin 顶部加注释说明为何必须内联字面量；把两个 id 也加进 fabric.mod.json 的 suggests；或者把常量放进一个不含任何 Minecraft 依赖的纯字符串类（如 CetIds），让插件可以安全 import。",
  },
  {
    id: "MIX-7",
    path: "mixin",
    sev: "OK",
    conf: "verified",
    title: "值得肯定：可选依赖的 mixin 处理是教科书级的",
    titleEn: "Textbook handling of optional-dependency mixins",
    where:
      "resources/enchantment_fusion.mixins.json · mixin/FusionMixinConfigPlugin.java · scripts/check_baseline_mixins.py · .github/workflows/build.yml (no-viewers job)",
    claim:
      "@Pseudo + remap = false + require = 0 三件套齐全；config plugin 门控；minVersion 0.8、compatibilityLevel 显式声明；injectors.defaultRequire = 1 对核心 mixin 保持严格；配套脚本检查「注册在 mixins.json 里的类确实被编译出来了」；CI 还有一个关掉 JEI/REI 的 no-viewers 作业验证可选依赖逃生口。",
    why:
      "大多数 mod 在可选依赖 mixin 上会踩两个坑：忘了 @Pseudo 导致缺类崩溃，或者 require 设成默认值导致上游改名就崩。这里两个都避开了，而且还写了脚本防止「mixin 类被删了但配置里还留着」这种低频高危错误。",
    fix: "保持。唯一缺口是 MIX-5：静默失效没有被观测到。",
  },

  /* ───────────────────────── 06 死代码 ───────────────────────── */
  {
    id: "DEAD-1",
    path: "dead",
    sev: "P2",
    conf: "verified",
    title: "为绕开局部 record 作用域而写的反射",
    titleEn: "Reflection written to dodge a local-record scope problem",
    where: "mechanics/CompendiumDiscoveryTracker.java:293, 350-368",
    claim:
      "record Candidate(String key, String pairMirrorKey, Component title, int curState) 声明在方法体内；辅助方法 unlockCandidateWithDelta(ServerPlayer, Record candRec, int stage) 的形参类型是 java.lang.Record，方法体里用 candRec.getClass().getDeclaredMethod(\"key\").invoke(candRec) 取值，catch (ReflectiveOperationException ignored) 时回退到全量秘典同步。",
    why:
      "整段反射的存在理由只是「Candidate 声明在了方法里，别的方法看不见」。代价是：每次解锁走两次反射查找 + invoke；异常被 ignored 静默吞掉；失败回退是最贵的那条路径（全量 4096 条重发）。而修复只需要把 record 往上挪一层。这也是全仓库唯一一处反射，风格上极其突兀。",
    fix:
      "把 Candidate 提为 private static record CompendiumDiscoveryTracker.Candidate(…)；unlockCandidateWithDelta 的形参改成 Candidate；删掉 try/catch 与全量回退。净减约 15 行，去掉一次反射与一条静默失败路径。",
    code: `private static void unlockCandidateWithDelta(ServerPlayer player, Record candRec, int stage) {
    if (candRec != null) {
        try {
            String k = (String) candRec.getClass().getDeclaredMethod("key").invoke(candRec);
            String mirror = (String) candRec.getClass().getDeclaredMethod("pairMirrorKey").invoke(candRec);
            ...
        } catch (ReflectiveOperationException ignored) {
            FusionNetworking.sendCompendiumSync(player, encodeStates(pid));  // 最贵的回退
        }
    }
}`,
  },
  {
    id: "DEAD-2",
    path: "dead",
    sev: "P3",
    conf: "verified",
    title: "8 个零调用者的公开成员",
    titleEn: "Eight public members with zero callers",
    where: "CompendiumDiscoveryTracker.java:380,425 · AberrantRegistry.java:88 · VesselCapacityRules.java:88 · FusedPair.java:82 · EnchantmentFusionMenu.java:144,171 · FusionNetworking.java:90-105",
    claim:
      "经全仓库 grep（排除声明行）确认零引用：CompendiumDiscoveryTracker.clientMasteredCount() · CompendiumDiscoveryTracker.getUnlockedFor(UUID) · AberrantRegistry.pickRandomAberration(RandomSource) · VesselCapacityRules.getUsedVesselSlots(ItemStack) · FusedPair.withPrimaryLevel(int) · EnchantmentFusionMenu.viewer() · EnchantmentFusionMenu.performAction(4 参重载) · StationActionPayload.paramB()（无任何 case 读取它）。",
    why:
      "单独看每一条都无害，合起来是一个信号：公开面在增长而消费面没有。pickRandomAberration 尤其可惜——它的函数体 ALL_IDS.get(rng.nextInt(ALL_IDS.size())) 在 pickAberration 的末尾被逐字重写了一遍，所以「死方法」和「活副本」同时存在。getUnlockedFor 返回的是 ConcurrentHashMap 的 keySet 活视图却取了个快照式的名字，一旦有人开始用它，就会拿到一个会在脚下变化的集合。paramB 则是每个动作包都要多编解码一个 varint。",
    fix:
      "删掉全部 8 处；pickAberration 的末尾改调 pickRandomAberration(rng)（二选一，不要都留）；performAction 只保留 5 参版本；StationActionPayload 若确实需要第二个参数，就让它被某个动作使用，否则从 composite codec 里移除。",
  },
  {
    id: "DEAD-3",
    path: "dead",
    sev: "P3",
    conf: "verified",
    title: "两份逐字节相同的判定，与一次多余的重复初始化",
    titleEn: "Byte-identical predicates and a redundant re-initialisation",
    where:
      "mechanics/FusionRuleEngine.java:126-145 · data/FusionMatrixRegistry.java:236-247",
    claim:
      "canFlipPair(FusedPair) 与 canUnsocketOrSplitPair(FusedPair) 的方法体完全一致（null → MISSING_INPUT；isAberrant() → ABERRANT_LOCKED；否则 NONE）。parseFromJson 里 parsedGroups 在声明时已按 replaceGroups 决定初值，紧接着 else 分支里又写了一次 if (!replaceGroups) parsedGroups = new ArrayList<>(defaults.exclusiveGroups());。",
    why:
      "两个同义方法的问题不是行数，是将来必然分叉：有人只会改其中一个（「翻面应该允许畸变，卸除不允许」），另一个悄悄保持旧语义，而两个名字看起来 equally 权威。重复初始化则是纯粹的噪声，会让读者怀疑上面那次初始化是不是有条件没满足。",
    fix:
      "抽 private static RejectReason rejectIfAberrantLocked(FusedPair, RejectReason onNull)，两个公开方法各自 return 它——保留两个名字（语义确实不同）但只保留一份逻辑。删掉 else 分支里的重复赋值。",
  },
  {
    id: "DEAD-4",
    path: "dead",
    sev: "P3",
    conf: "verified",
    title: "economy.json 里的 schema_version 从未被读取",
    titleEn: "A schema_version field nobody reads",
    where:
      "resources/data/enchantment_fusion/enchantment_fusion/economy.json:2 · data/FusionMatrixRegistry.java:272-291",
    claim:
      "JSON 首行是 \"schema_version\": 1；parseEconomy 只读 low/mid/high_fail_chance、repulsive_fail_chance、repulsive_min_floor、stabilizer_reduction_*、max_repulsive_stabilizers 八个键，schema_version 既不被校验也不被记录。",
    why:
      "一个声明了版本却不做版本检查的字段，比没有版本字段更糟：它给包作者一种「升级会被检测到」的错误安全感。将来真的改 schema（比如把标量拆成对象）时，旧包会走进新解析器，八个 readDouble 全部返回默认值，静默地把包作者的配置清零。",
    fix:
      "读取它：不等于当前版本时 LOGGER.warn 并拒绝加载该文件（保留上一份快照），或按版本分派解析器。若暂不做迁移，就先删掉这个字段，别留半套机制。",
  },
  {
    id: "DEAD-5",
    path: "dead",
    sev: "OK",
    conf: "verified",
    title: "值得肯定：死代码总量很低，而且有两道防回潮的闸",
    titleEn: "Low dead-code volume, with two gates against regrowth",
    where:
      "scripts/check_repository_hygiene.py · scripts/check_architecture_boundaries.py · src/test/AssetAndLocaleContractTest.java:31-32",
    claim:
      "19,675 行非测试 Java 里，可确认的零引用公开成员只有 8 处、重复逻辑 2 处、无效字段 1 个。AssetAndLocaleContractTest 里还有两条负向断言，明确钉住两个已被清除的键（gui.enchantment_fusion.tab.compendium、preview.idle_line1）不许回潮。",
    why:
      "用「assertFalse(contains(deadKey))」把一次清理固化成回归测试，是很少见的自律。多数项目清完就忘，三个月后死键带着新拼写回来。",
    fix: "保持。建议把 DEAD-2 的 8 个成员也加进同类负向断言（用反射扫零引用公开方法），让清理不可逆。",
  },

  /* ───────────────────────── 07 耦合风险 ───────────────────────── */
  {
    id: "CPL-1",
    path: "coupling",
    sev: "P0",
    conf: "verified",
    title: "畸变词条的唯一撤销手段挂在一个可选依赖上",
    titleEn: "The only undo for an irreversible state lives in an optional dependency",
    where:
      "resources/fabric.mod.json (suggests) · mixin/GrindstoneAberrationGuardMixin.java:28 · mechanics/FusionRuleEngine.java:126-145 · compat/CetCleanse*.java（9 个 @Pseudo mixin 驱动）· docs/GDD.md:42",
    claim:
      "所有净化畸变的实现都在 enchantment_fusion.compat.CetCleanse* 里，由 9 个注入 chiseled_enchanting_table.* 的 @Pseudo mixin 驱动。本 mod 自身的三条撤销路径全部拒绝畸变物品：砂轮返回 EMPTY、canFlipPair 返回 ABERRANT_LOCKED、canUnsocketOrSplitPair 同样。GDD 写明「唯《纂刻附魔台》可净化」。fabric.mod.json 只把姊妹 mod 列为 suggests。",
    why:
      "畸变是失败掷骰的产物——玩家没有选择进入这个状态。进入之后，若未安装一个「建议安装」的第三方 mod，这件物品就永久带着一个负面词条，无法翻面、无法卸除、无法砂轮清洗、无法用本 mod 的任何功能移除。README、GDD、以及游戏内 UI 都没有在执行前告知这一点（tip.risk_high 只说「失败会凝为畸变词条」，没说撤销需要别的 mod）。这是把不可逆状态的可逆性外包给了可选依赖，属于设计层面的耦合缺陷，不是实现 bug。",
    fix:
      "三选一，按侵入性递增：(a) 在 tip.risk_high 与 GDD 里明确写出「净化需要安装《纂刻附魔台》」，并在未安装时于 UI 上显示这条前置；(b) 提供本 mod 自带的高代价净化路径（例如 3 枚共鸣稳定晶 + 30 级经验，把畸变词条降级为普通融合）；(c) 让畸变可被「重新融合覆盖」——目前 FusionStationOperations:504,732 已经在跳过 isAberrant() 的旧词条，改成允许覆盖即可。推荐 (b)+(a)。",
  },
  {
    id: "CPL-2",
    path: "coupling",
    sev: "P1",
    conf: "verified",
    title: "Java 里硬编码了一份 tag 镜像，而测试把镜像当真值",
    titleEn: "A hardcoded Java mirror of a datapack tag, asserted as truth by tests",
    where:
      "mechanics/VesselCapacityRules.java:35-47, 59-62 · resources/data/enchantment_fusion/tags/item/innate_two_vessel_items.json",
    claim:
      "DEFAULT_TAG_ITEM_IDS 用 Set.of 列了 10 个黄金装备 id；javadoc 自述为「Pure-JVM helper mirroring the default innate_two_vessel_items.json tag contents for unit tests」。运行时实际走的是 isInnateTwoSlotStack → stack.is(INNATE_TWO_VESSEL_ITEMS)，即真 tag。类注释同时宣称该机制「purely tag-driven in runtime so datapacks can add or remove entries (HC-05)」。",
    why:
      "两句话都对，合起来就是一个陷阱：测试断言的是 Java 里的那份名单，而游戏读的是 JSON 里的那份。数据包把金镐从 tag 里删掉之后，HC-05 的承诺兑现了（运行时确实变了），测试依然全绿（它测的是镜像）。这类「测试测的是副本」的结构，会给维护者一种被验证过的错觉——比没有测试更危险。",
    fix:
      "让测试直接解析 resources 下的 JSON 并与 DEFAULT_TAG_ITEM_IDS 对比（相等则通过，不等则失败并打印差集），把镜像关系变成被检查的不变量；或者干脆删掉 Java 镜像，测试改为加载真实 tag JSON。",
    code: `/** Pure-JVM helper mirroring the default {@code innate_two_vessel_items.json} tag contents for unit tests. */
public static boolean isInnateTwoSlotItemId(String itemId) {
    return itemId != null && DEFAULT_TAG_ITEM_IDS.contains(itemId);
}
// 运行时走的是这一条：
public static boolean isInnateTwoSlotStack(ItemStack stack) {
    return stack.is(INNATE_TWO_VESSEL_ITEMS);
}`,
  },
  {
    id: "CPL-3",
    path: "coupling",
    sev: "P1",
    conf: "verified",
    title: "setChanged() 每次都广播整包 BlockEntity 更新",
    titleEn: "Every slot mutation broadcasts a full block-entity packet",
    where:
      "block/EnchantmentFusionTableBlockEntity.java:136-142（setChanged）· :113-132（removeItem / setItem）",
    claim:
      "覆写的无参 setChanged() 在 super.setChanged() 之后无条件执行 level.sendBlockUpdated(worldPosition, state, state, UPDATE_CLIENTS)；getUpdatePacket() 返回 ClientboundBlockEntityDataPacket.create(this)，getUpdateTag() 走 saveCustomOnly → ContainerHelper.saveAllItems，序列化全部 4 个槽（含所有物品组件）。setItem / removeItem / clearContent 都调用它。",
    why:
      "AbstractContainerMenu.broadcastChanges 已经把槽内容同步给正在看这个容器的玩家了；这里额外向所有追踪该方块的玩家再发一份完整 BlockEntity NBT。带 FUSED_PAIRS + TRANSMUTED_ENCHANTS 组件的物品，一份序列化可达数百字节。按住 Shift 连续点击移动一组物品时，每次 setItem 都会触发一轮，即一次操作几十个全量包。动画状态（surgeTicks / animTicks）本来就不需要走这条路——它已经有专门的 FusionVisualEventPayload。",
    fix:
      "无参 setChanged() 只标脏不广播；确实需要让周围玩家看到方块状态变化时，显式调用一个 setChangedAndSync()，并做 2–4 tick 的合并节流。渲染所需的动画状态继续走 visual event 通道。",
  },
  {
    id: "CPL-4",
    path: "coupling",
    sev: "P2",
    conf: "verified",
    title: "客户端表现数据住在 src/main，且被跨类魔法数绑定",
    titleEn: "Presentation data in the common source set, bound by cross-class magic numbers",
    where:
      "model/PayloadType.java:11-25 · block/EnchantmentFusionTableBlockEntity.java:52-55 · client/gui/FusionGuiMicroEffects.java:130-147 · mechanics/FusionStationOperations.java:1103-1122",
    claim:
      "PayloadType（src/main，公共源集）为 14 个枚举值各硬编码了一个 ARGB 强调色。BlockEntity.triggerClientSurge 写 this.surgeTicks = (kind == 2) ? 36 : 28;——其中的 2 是 FusionNetworking.VISUAL_FUSE_ABERRANT 的字面量副本，36/28 是纯客户端动画时长。同一段 switch 在 FusionGuiMicroEffects 与 FusionStationOperations 里各出现一次。",
    why:
      "两重耦合：(1) 服务端类里携带纯渲染常量，dedicated server 也要加载这些颜色，而 check_architecture_boundaries.py 显然没有拦；(2) kind == 2 这种跨类字面量意味着改 FusionNetworking 里的枚举值会让「畸变闪光」变成「普通闪光」，编译器与测试都不会出声。动画时长在两个类里各写一份，改一处只会让方块动画和 GUI 动画不同步。",
    fix:
      "颜色移到 src/client 下的 Palette 类（或改为从 PayloadType 派生的客户端映射表）；kind == 2 改为 FusionNetworking.VISUAL_FUSE_ABERRANT；36/28 提为 SURGE_TICKS_ABERRANT / SURGE_TICKS_NORMAL 常量并放在两处都能引用的位置。",
  },
  {
    id: "CPL-5",
    path: "coupling",
    sev: "P2",
    conf: "verified",
    title: "quickMoveStack 里手抄了一份材料白名单",
    titleEn: "A hand-copied reagent whitelist inside quickMoveStack",
    where:
      "menu/EnchantmentFusionMenu.java:277-311（含 :278 的字面量 40）· mechanics/FusionEconomyRules.java:47-53 · compat/CetSoftBridge.java:63-71",
    claim:
      "quickMoveStack 用 source.is(LAPIS_LAZULI) || is(AMETHYST_SHARD) || is(EMERALD) 决定送去催化剂槽，用 is(ENCHANTED_BOOK) || is(ECHO_SHARD) || is(AMETHYST_CLUSTER) 决定送去 A/B 槽；同一批物品在 ReagentKind.asVanillaItem() 与 CetSoftBridge.isSplitOrFlipCatalyst() 里各自又列了一遍。槽位下标写作字面量 4 / 40 / 2 / 3 / 0，而不是 CONTAINER_SIZE / slots.size() / SLOT_CATALYST。",
    why:
      "三份名单，一份决定「Shift 点会去哪」，两份决定「什么能被消耗」。加入一种新材料（或数据包扩展 ReagentKind）时必须同时改三处，漏掉 quickMoveStack 的后果是「这东西能用但 Shift 点不进去」——玩家会当成 bug 报，而逻辑层其实是对的。硬编码的 40 更脆：一旦容器加一格，Shift 反向移动就会漏掉最后一格玩家背包。",
    fix:
      "把材料判定收敛到 ReagentKind.matches / CetSoftBridge 这两个已有的权威函数，quickMoveStack 只调用它们；槽位下标全部换成已有常量；40 换成 this.slots.size()。",
  },
  {
    id: "CPL-6",
    path: "coupling",
    sev: "P3",
    conf: "verified",
    title: "版本一致性闸门把散文当成了断言对象",
    titleEn: "A version gate that asserts against prose",
    where: "scripts/check_release_consistency.sh:31-45",
    claim:
      "脚本断言 fabric.mod.json 的 description 字段里必须包含 minecraft_version 子串（assert mc_ver in fmj[\"description\"]），并断言 README 里存在四处固定格式的字符串。它不检查 docs/GDD.md、CHANGELOG.md、.github/workflows/build.yml 的 artifact 名，也不检查 .github/workflows/publish.yml（后者只发一条非致命 WARN）。",
    why:
      "把「描述文案里要提到版本号」设成硬闸门，等于让散文承担机器可验证的义务——某天有人把 description 改得更简洁，CI 就红，而红的原因与发布正确性无关。反过来，真正会伤到用户的那处漂移（publish.yml 的 VERSION/RELEASE_NAME 仍是姊妹 mod 的 1.1.0）被降级成 WARN，见文案页 TXT-11。闸门的严格程度与风险大小成反比。",
    fix:
      "删掉 description 断言（版本号不该是文案义务）；把 .github/workflows/publish.yml 的 VERSION/RELEASE_NAME 升级为 --strict 下的硬失败，并在脚本注释里写清「若因 workflows 权限无法自动修复，则必须由人工确认」；把 build.yml 的 artifact 名与 GDD/CHANGELOG 的版本号纳入检查范围。",
  },
  {
    id: "CPL-7",
    path: "coupling",
    sev: "OK",
    conf: "verified",
    title: "值得肯定：清理钩子与运行时状态边界划得很清",
    titleEn: "Disciplined runtime-state eviction boundaries",
    where: "mechanics/MatrixRuntimeHooks.java:52-80",
    claim:
      "SERVER_STOPPING 冲刷世界改动（霜冰牢笼、飞剑、弹道缓存）；SERVER_STOPPED 清空冷却与三份运行时状态并清 PEAK_FALL_DISTANCE；DISCONNECT 逐个驱逐 7 类 per-player 缓存（SignaturePairs / CrossDomainTransmutations / FlyingBladeManager / ProjectilePathTracker / MatrixEffectExecutor / CompendiumDiscoveryTracker / PEAK_FALL_DISTANCE），且注释标了 CPL-02。",
    why:
      "静态 Map 泄漏是 Fabric mod 最常见的内存问题，尤其是在客户端切服时。这里把「世界生命周期」与「玩家会话生命周期」两层清理分开写，并且给每个 per-player 缓存都提供了 onPlayerDisconnect 入口——结构上是对的。AberrantRegistry 的霜冰牢笼在 STOPPING 阶段尝试还原世界，动机也正确（缺陷见数值页 NUM-9）。",
    fix: "保持。补一条：SERVER_STOPPED 里也应 setClientSnapshot(null)，目前该职责只在客户端 DISCONNECT 事件里（单机退出路径依赖它，值得双保险）。",
  },
];

export const SEV_META: Record<
  Severity,
  { label: string; zh: string; color: string; bg: string; rank: number }
> = {
  P0: { label: "P0 CRITICAL", zh: "阻断级", color: "#ff7a7a", bg: "rgba(255,122,122,.12)", rank: 0 },
  P1: { label: "P1 HIGH", zh: "高危", color: "#ffb86c", bg: "rgba(255,184,108,.12)", rank: 1 },
  P2: { label: "P2 MEDIUM", zh: "中危", color: "#ffdf88", bg: "rgba(255,223,136,.10)", rank: 2 },
  P3: { label: "P3 LOW", zh: "低危", color: "#b5ac9e", bg: "rgba(181,172,158,.10)", rank: 3 },
  OK: { label: "CREDIT", zh: "值得肯定", color: "#8cffb0", bg: "rgba(140,255,176,.10)", rank: 4 },
};

export const CONF_META: Record<Confidence, { zh: string; note: string }> = {
  verified: {
    zh: "已在源码中逐行核对",
    note: "结论只依赖本仓库文本，可离线复核。",
  },
  "static-high": {
    zh: "静态推断，把握高",
    note: "依赖对 Minecraft / fastutil 既有行为的理解，未在本仓库内直接可见。",
  },
  "needs-runtime": {
    zh: "需运行时验证",
    note: "本次审计无法编译或启动游戏；结论是风险陈述而非既成事实。",
  },
};

export function findingsFor(path: PathId): Finding[] {
  return FINDINGS.filter((f) => f.path === path).sort(
    (a, b) => SEV_META[a.sev].rank - SEV_META[b.sev].rank,
  );
}

export const SCAN = {
  repo: "q14433686-arch/chiseled-enchanting-table-26.1.2-source",
  branch: "arena/11fcd984-chiseled-enchanting-table-26-1",
  commitTree: "dbbd808",
  modId: "enchantment_fusion",
  modName: "Enchantment Fusion / 融合附魔",
  version: "0.6.0",
  target: "Minecraft 26.1.2 · Fabric Loader 0.19.3 · Fabric API 0.151.0 · Java 25",
  locNonTest: 19675,
  locTest: 741,
  files: { java: 62, lang: 11, langKeys: 829, mixins: 15, textures: 27 },
  biggest: [
    { f: "mechanics/CrossDomainTransmutations.java", n: 3120 },
    { f: "mechanics/SignaturePairs.java", n: 2661 },
    { f: "mechanics/FusionStationOperations.java", n: 1129 },
    { f: "client/gui/EnchantmentFusionScreen.java", n: 1105 },
    { f: "client/gui/FusionGrimoireScreen.java", n: 776 },
  ],
};
