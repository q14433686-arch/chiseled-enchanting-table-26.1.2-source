export interface NumFinding {
  id: string;
  sev: "P0" | "P1" | "P2" | "P3" | "OK";
  conf: "verified" | "static-high" | "needs-runtime";
  title: string;
  where: string;
  claim: string;
  why: string;
  fix: string;
  code?: string;
}

/* ── economy.json 暴露的 8 个可调参数 ───────────────────────── */
export const EXPOSED_KNOBS = [
  { k: "low_fail_chance", v: "0.0", note: "低阶失败率" },
  { k: "mid_fail_chance", v: "0.18", note: "中阶失败率" },
  { k: "high_fail_chance", v: "0.28", note: "高阶失败率" },
  { k: "repulsive_fail_chance", v: "0.45", note: "互斥强融失败率" },
  { k: "repulsive_min_floor", v: "0.08", note: "互斥档不可击穿的下限" },
  { k: "stabilizer_reduction_repulsive", v: "0.13", note: "每枚稳定晶（互斥）" },
  { k: "stabilizer_reduction_normal", v: "0.18", note: "每枚稳定晶（常规）" },
  { k: "max_repulsive_stabilizers", v: "3", note: "互斥档最多用几枚" },
];

/* ── 未暴露、写死在 Java 里的曲线常量 ───────────────────────── */
export const HIDDEN_CONSTANTS: {
  group: string;
  items: { c: string; where: string; meaning: string }[];
}[] = [
  {
    group: "合成经验曲线 · computeSynthesisQuote",
    items: [
      { c: "7 + min(4, sumLv/3)", where: ":130", meaning: "互斥档经验基数与增量上限" },
      { c: "min(9, 4 + sumLv/2)", where: ":145", meaning: "双满高阶经验上限" },
      { c: "max(3, min(7, 2 + sumLv/2))", where: ":157", meaning: "中阶经验区间" },
      { c: "max(2, 1 + sumLv/2)", where: ":171", meaning: "低阶经验下限" },
      { c: "max(2, pLv + sLv)", where: ":128", meaning: "sumLv 的地板" },
      { c: "pMax >= 3 || sMax >= 3", where: ":143", meaning: "「高阶」的判据" },
      { c: "signature || sumLv >= 5", where: ":156", meaning: "「中阶」的判据" },
      { c: "-0.06", where: ":149", meaning: "非签名高阶的失败率折扣" },
      { c: "+0.02 * max(0, sumLv-5)", where: ":162", meaning: "中阶超出 5 级后的递增" },
      { c: "mats ∈ {1,2,3,4}", where: ":131,158,172", meaning: "材料数量，按档位硬编码" },
      { c: "cap = 2 / 2 / 1", where: ":151,164,174", meaning: "各档稳定晶上限（互斥档走配置，其余写死）" },
    ],
  },
  {
    group: "失败率天花板 · clampProb 上界",
    items: [
      { c: "0.85", where: ":139", meaning: "互斥档上限" },
      { c: "0.75", where: ":152", meaning: "双满高阶上限" },
      { c: "0.65", where: ":165", meaning: "中阶上限" },
      { c: "0.50", where: ":175", meaning: "低阶上限" },
      { c: "0.60 / 0.50 / 0.40", where: ":214,227,236", meaning: "化形三档上限" },
      { c: "0.40", where: ":255", meaning: "套书上限" },
    ],
  },
  {
    group: "化形报价 · computeConversionQuote",
    items: [
      { c: "safeAnvil >= 8", where: ":206", meaning: "稀有判据之一" },
      { c: "max(5, min(8, 3 + safeAnvil/2))", where: ":207", meaning: "稀有化形经验" },
      { c: "-0.04", where: ":212", meaning: "稀有化形的失败率折扣" },
      { c: "safeAnvil >= 4 || safeLv >= 3", where: ":218", meaning: "中阶化形判据" },
      { c: "max(3, max(safeLv, safeAnvil))", where: ":219", meaning: "中阶化形经验" },
      { c: "1 + safeLv / 2 + safeLv", where: ":233,234", meaning: "低阶化形经验与材料" },
    ],
  },
  {
    group: "套书与其他",
    items: [
      { c: "xp = 2", where: ":248", meaning: "把融合书套进装备的经验" },
      { c: "base = 0.15", where: ":253", meaning: "畸变套书失败率，完全写死，economy.json 无此项" },
      { c: "xpCost = 2", where: "FusionStationOperations:867,923", meaning: "翻面／卸除的经验，两处各写一遍" },
      { c: "1e-6 / 1e-9", where: ":106,109", meaning: "同一个比较里的两个不同 epsilon" },
    ],
  },
  {
    group: "冷却与触发",
    items: [
      { c: "30/25/20/30/20/60/40/30", where: "TriggerType.java:11-18", meaning: "8 种触发载体的冷却 tick，枚举内硬编码" },
      { c: "charge < 0.55F", where: "MatrixRuntimeHooks.java:116", meaning: "低于此蓄力直接忽略近战触发" },
      { c: "charge >= 0.90F", where: "MatrixRuntimeHooks.java:119", meaning: "视为满蓄力（vanilla 满蓄力是 1.0）" },
      { c: "0.5F", where: "MatrixRuntimeHooks.java:114", meaning: "getAttackStrengthScale 的偏移" },
    ],
  },
];

export const NUM_FINDINGS: NumFinding[] = [
  {
    id: "NUM-1",
    sev: "P0",
    conf: "verified",
    title: "六道写死的失败率天花板会静默覆盖 economy.json",
    where: "mechanics/FusionEconomyRules.java:139,152,165,175,214,227,236,255",
    claim:
      "readDouble(obj, \"low_fail_chance\", def, 0.0, 1.0) 接受 0 到 1 的任何值；clampProb(v, lo, hi) 在计算末端把结果压到 0.50（低阶）/0.65（中阶）/0.75（高阶）/0.85（互斥）等档位上限。包作者写 low_fail_chance: 0.9，配置被接受、被加载、被记进日志，最终生效值是 0.50。",
    why:
      "「可配置区间」与「实际生效区间」不一致，而且不一致的方向是静默收紧。包作者拿到的反馈是「我调了但没变化」，而日志会明确说加载成功、参数是 0.9。这比不允许配置更糟：不允许至少会报错。同时这六道天花板本身也是平衡的一部分——它们决定了「把失败率调高」这条设计路线在任何数据包里都走不通，但 GDD 把 economy.json 描述为「阶梯资费、诚实风险曲线」的可配来源。",
    fix:
      "二选一：(a) 把六道天花板提进 economy.json（fail_ceiling_low / _mid / _high / _repulsive / _conversion_* / _socket），与现有 8 格并列；(b) 把 readDouble 的 hi 收紧到与各档天花板一致，并在越界时 LOGGER.warn 明确告知被钳到了多少。推荐 (a)——天花板本来就该是平衡参数。",
    code: `// 读取：接受 0..1
readDouble(obj, "low_fail_chance", d.lowFailChance(), 0.0, 1.0)

// 使用：压到 0.50
double fail = clampProb(base - eco.stabilizerReductionNormal() * used, 0.0, 0.50);
private static double clampProb(double v, double lo, double hi) {
    return Math.max(lo, Math.min(hi, v));
}`,
  },
  {
    id: "NUM-2",
    sev: "P1",
    conf: "verified",
    title: "约 35 个曲线常量写在 Java 里，economy.json 只暴露 8 个",
    where: "mechanics/FusionEconomyRules.java · FusionStationOperations.java:867,923 · TriggerType.java:11-18",
    claim:
      "见上方「未暴露常量」清单：经验公式的基数／斜率／上下界、档位判据（sumLv>=5、safeAnvil>=8、pMax>=3）、失败率折扣（-0.06、-0.04、+0.02/级）、材料数量、稳定晶档位上限、套书的 0.15 基础失败率、翻面／卸除的 2 级经验、8 种触发的冷却 tick。全部为字面量。",
    why:
      "这不是「常量多了」的洁癖问题，而是能力边界问题：一个整合包作者想把本 mod 的节奏调慢一倍，能动的只有失败概率 8 格；经验、材料、冷却、档位划分一律改不了。而 GDD 的标题写着「阶梯资费、诚实风险曲线与「畸变词条」（economy.json 数据包可配）」——括号把整条曲线都归给了 economy.json，实际只覆盖失败率与稳定晶。文档承诺的范围大于实现的范围。",
    fix:
      "把 EconomyConfig 扩成完整曲线配置：经验基数/斜率/上下界、档位阈值、材料表、冷却表。一次性做完比逐步做划算——现在每加一格都要改 record、write、read、parseEconomy、DEFAULT 五处，扩到 20 格时应改成 codec 驱动（RecordCodecBuilder + 反射式字段遍历），而不是继续手写。",
  },
  {
    id: "NUM-3",
    sev: "P1",
    conf: "verified",
    title: "手写矩阵与文档化的 slot 推断给出系统性不同的答案",
    where:
      "data/FusionMatrixRegistry.java:110-135（推断）vs :308-352（内建表）",
    claim:
      "推断规则：FEET → ON_MOVEMENT_OR_LAND/TIDE；ARMOR/HEAD/CHEST/LEGS → ON_DAMAGE_TAKEN/AEGIS；MAINHAND|HAND → ON_MELEE_STRIKE/EDGE；ANY → ON_UTILITY_CYCLE/MEND；OFFHAND 未被检查。而内建表里 soul_speed（FEET）→ ON_DAMAGE_TAKEN/AEGIS、swift_sneak（LEGS）→ ON_UTILITY_CYCLE/MEND、respiration（HEAD）→ ON_MOVEMENT_OR_LAND/AEGIS、silk_touch 与 fortune（MAINHAND）→ ON_BLOCK_HARVEST、looting/luck_of_the_sea/lure/mending/unbreaking（MAINHAND 或 ANY）→ ON_UTILITY_CYCLE。",
    why:
      "第三方附魔拿到的正是这条推断链（或它之后的 hashCode 兜底）。也就是说：一个 mod 加的「挖掘类主手附魔」会被判成 ON_MELEE_STRIKE/EDGE，而 vanilla 的同类附魔全部在 ON_BLOCK_HARVEST/FORTUNE。同一语义的原生附魔与外来附魔落进不同矩阵格，触发时机与载荷类型都不同——玩家会觉得「这个 mod 的附魔手感不对」，而原因是推断链只是原表的粗略近似，且这个近似程度没有被任何文档说明。OFFHAND 缺失则让所有副手附魔直接掉进 hashCode 兜底。",
    fix:
      "补 OFFHAND 分支；更重要的是，把推断结果与内建表做一次离线对账（写一个测试：对 43 个 vanilla 附魔跑推断，统计与内建表的吻合率），把吻合率写进 GDD 作为「第三方附魔的近似质量」的公开说明。若吻合率过低，考虑改为按 Enchantment 的 supported_items / 类别推断而非纯 slot。",
  },
  {
    id: "NUM-4",
    sev: "P2",
    conf: "verified",
    title: "兜底把矩阵格位置交给 String.hashCode()",
    where: "data/FusionMatrixRegistry.java:137-147",
    claim:
      "当 id 不在表内、tag 未命中、slot 推断不出结果时：h = id.hashCode(); finalT = triggers[floorMod(h, 8)]; finalP = payloads[floorMod(h / 8, 14)]。注释称其为「Overflow-safe deterministic floorMod fallback (API-06)」。",
    why:
      "确定性有了（String.hashCode 跨 JVM 稳定），但语义是随机的：两个毫不相干的 mod 附魔可能落进同一个 (trigger, payload) 格，从而被判定为可融合并触发同一个 MatrixEffectExecutor 分支——一个没有任何人设计过的组合。h/8 再 floorMod 14 的分散性也差（整数除法丢掉了低位信息，trigger 与 payload 之间产生相关性）。对一个「任意附魔都能融合」的 mod 来说，兜底路径其实是主路径：装 20 个附魔 mod 时，绝大多数附魔走的都是这里。",
    fix:
      "至少改为显式的 UNKNOWN trigger/payload（例如新增 TriggerType.ON_GENERIC / PayloadType.NULL），让未知附魔进入一条被设计过的保守分支，而不是被哈希分配到某个具体效果格；或强制要求 tag 声明、未声明则拒绝融合并给出可读提示。同时把 h/8 换成 (h >>> 3) 或直接用第二个哈希函数，减少相关性。",
    code: `int h = enchantmentId == null ? 0 : enchantmentId.hashCode();
TriggerType finalT = inferredTrigger != null ? inferredTrigger
    : triggers[Math.floorMod(h, triggers.length)];
PayloadType finalP = inferredPayload != null ? inferredPayload
    : payloads[Math.floorMod(h / triggers.length, payloads.length)];`,
  },
  {
    id: "NUM-5",
    sev: "P2",
    conf: "verified",
    title: "畸变类型靠子串匹配附魔名决定",
    where: "mechanics/AberrantRegistry.java:90-114",
    claim:
      "pickAberration 把两个 id 拼成 primaryId + \"|\" + secondaryId，然后用 6 个 pair.contains(\"…\") 依次判定：smite|sharpness|bane_of_arthropods → BLOOD_FRENZY；channeling|riptide|loyalty → ROGUE_LIGHTNING；fortune|silk_touch|mending|infinity → GREEDY_ABYSS；frost_walker|depth_strider → MUTUAL_GLACIER；fire_protection|fire_aspect|flame → HOT_POTATO；blast_protection|projectile_protection|protection|lunge → RECOIL_SKID；都不中则随机。",
    why:
      "contains 是子串匹配，而附魔 id 之间本来就存在包含关系：protection 会命中 fire_protection / blast_protection / projectile_protection，于是「哪种保护」完全由 if 链顺序决定，而这个顺序没有任何文档。flame 也会命中任何含 flame 的 mod id。更实际的问题是扩展性：任何 mod 加一个叫 dark_sharpness 的附魔就会被判成 BLOOD_FRENZY。ALL_IDS 的声明顺序（…RECOIL_SKID, MUTUAL_GLACIER, HOT_POTATO）与 if 链的判定顺序（…MUTUAL_GLACIER, HOT_POTATO, RECOIL_SKID）也不一致，读者会误以为前者是优先级。",
    fix:
      "改为解析成两个 Identifier 后做精确比较：Set<String> of = Set.of(primaryPath, secondaryPath)，再用 of.contains(\"sharpness\")；或直接用物品标签 #enchantment_fusion:aberrant_affinity/<type> 让数据包决定亲和。同时把 ALL_IDS 的顺序与判定顺序统一，或在 ALL_IDS 上加注释说明它只是枚举、不是优先级。",
  },
  {
    id: "NUM-6",
    sev: "P1",
    conf: "verified",
    title: "霜冰牢笼声称「未加载区块保留」，实现是「未加载即遗忘」",
    where: "mechanics/AberrantRegistry.java:29-32（javadoc）· :73-87（flushAllCages）",
    claim:
      "javadoc：「manages temporary Blocks.FROSTED_ICE prisons & snares with unloaded-chunk retention and shutdown cleanup (EF-012)」。flushAllCages 遍历时条件是 level != null && level.isLoaded(cell.pos()) && state.is(FROSTED_ICE)，只有满足才还原为 wasWater ? WATER : AIR；循环结束后无条件 TRACKED_FROSTED_ICE.clear()。TRACKED_FROSTED_ICE 是内存 Map，不落盘。",
    why:
      "两个后果：(1) 关服时若牢笼所在区块未加载，记录被 clear 丢弃，方块永久留在世界里——如果原位置是水，那格水就永久消失了（世界改动泄漏）；(2) 服务器崩溃时根本不会走 SERVER_STOPPING，全部牢笼记录丢失，同样留下永久 FROSTED_ICE 与消失的水。「retention」这个词在 javadoc 里出现，但代码里没有任何保留机制。FROSTED_ICE 自身会融化，所以视觉上会自愈，但被它替换掉的水不会回来。",
    fix:
      "把牢笼记录持久化（LevelSavedData 或复用秘典那套 JSON），启动时载入并在区块加载事件里补做还原；flushAllCages 对未加载的条目改为「保留在 map 中」而不是 clear；或者最简方案——不要用 setBlockAndUpdate 替换原方块，改为在原位置放一个带 BlockEntity 的临时方块，破坏时由 BE 自己恢复，这样状态天然随区块持久化。",
    code: `public static void flushAllCages(MinecraftServer server) {
    for (TrackedFrostedCell cell : TRACKED_FROSTED_ICE.values()) {
        ServerLevel level = server.getLevel(cell.dimension());
        if (level != null && level.isLoaded(cell.pos())          // ← 未加载则跳过
                && level.getBlockState(cell.pos()).is(Blocks.FROSTED_ICE)) {
            level.setBlockAndUpdate(cell.pos(),
                cell.wasWater() ? Blocks.WATER.defaultBlockState() : Blocks.AIR.defaultBlockState());
        }
    }
    TRACKED_FROSTED_ICE.clear();                                 // ← 然后全部遗忘
}`,
  },
  {
    id: "NUM-7",
    sev: "P2",
    conf: "verified",
    title: "互斥检查只比对既有词条的 primary，漏掉 secondary",
    where: "mechanics/FusionRuleEngine.java:106-112",
    claim:
      "for (FusedPair existingPair : hostList.pairs()) { if (matrix.areRepulsiveExclusives(primary.id(), existingPair.primaryId())) return EXCLUSIVE_ON_HOST; } —— 只取 existingPair.primaryId()，从不取 secondaryId()。同一段里对 existingHostEnchantIds（原生附魔集合）则做了完整遍历。",
    why:
      "装备上已有的融合词条是有序对 [X ▷ Y]，Y 同样是一条生效的附魔语义。若新 primary 与 Y 互斥（例如已有 [效率 ▷ 时运]，新来一本精准采集），检查会放行——而精准采集与时运在 exclusiveGroups 里明确互斥。FusedPair 已经有 involves(id) 方法且被 containsEnchantmentId 正确使用，说明作者知道该怎么做，这里是一次遗漏而非设计。",
    fix:
      "改为 if (matrix.areRepulsiveExclusives(primary.id(), existingPair.primaryId()) || matrix.areRepulsiveExclusives(primary.id(), existingPair.secondaryId()))；或直接 existingPair.involves(...) 配合一个 areRepulsiveWithAny(id, pair) 辅助方法。补一条测试：已有 [fortune ▷ efficiency]，新 primary = silk_touch，必须被拒。",
  },
  {
    id: "NUM-8",
    sev: "P2",
    conf: "verified",
    title: "近战蓄力阈值 0.55 / 0.90 与 vanilla 的 1.0 不对齐",
    where: "mechanics/MatrixRuntimeHooks.java:114-119",
    claim:
      "float charge = serverPlayer.getAttackStrengthScale(0.5F); if (charge < 0.55F && !riptideSpin) return PASS; boolean fullCharge = charge >= 0.90F || riptideSpin;",
    why:
      "vanilla 的「满蓄力暴击」判据是 getAttackStrengthScale(0.5F) >= 1.0。这里把 0.90 当作满蓄力，意味着比 vanilla 更早触发满档效果；把 0.55 当作下限，意味着半蓄力的挥砍也会触发融合效果（只是走非满档分支）。这两个数字直接决定了 mod 的手感与 DPS，却既不可配也没有注释说明取值理由。装有攻速类 mod 或攻速附魔时，charge 的爬升速度改变，这两个阈值会连带改变触发频率——而 0.55 这种「略过半」的值对攻速变化特别敏感。",
    fix:
      "把两个阈值提为具名常量并注释取值依据（例如「0.90 而非 1.0，是为了容忍 1 tick 的采样误差」——如果这就是理由，写下来）；更好的做法是提进配置，让玩家能在「严格 vanilla 手感」与「宽松触发」之间选择。",
  },
  {
    id: "NUM-9",
    sev: "P2",
    conf: "verified",
    title: "材料从整个玩家背包静默扣除，稳定晶只认槽 2",
    where:
      "mechanics/FusionEconomyRules.java:99-104（countStabilizers）· :266-283（countAvailableReagent）· :292-330（deductFeeAndStabilizers）",
    claim:
      "countAvailableReagent 先数槽 2，再遍历 player.getInventory() 的全部 41 格累加同种材料；deductFeeAndStabilizers 同样先扣槽 2，不足时遍历背包 st.shrink(take)。countStabilizers 只读槽 2（isStabilizerCatalyst(catalystSlot) ? getCount() : 0）。",
    why:
      "两种货币的取用规则不对称：材料可以来自全身背包，稳定晶只能来自槽 2。玩家无法从 UI 得知这一点，也无法预知会被扣哪一堆。更值得讨论的是设计层面——vanilla 附魔只消耗经验等级，从不消耗背包物品；本 mod 会在一次点击里从玩家背包深处静默 shrink 掉若干青金石/紫水晶/绿宝石，没有确认步骤、没有单堆上限、没有「本次将消耗 X」的预览（预览只显示数量，不显示将从哪里取）。带一箱绿宝石在身上去打怪，回来发现少了几十个，是很难自查的。",
    fix:
      "(a) 预览里明确标注材料来源（槽 2 / 背包）；(b) 给背包扣除设一个上限或改为「只从槽 2 与快捷栏取」；(c) 把稳定晶也允许从背包取，消除不对称；(d) 无论选哪种，都应在执行前让玩家看到即将消耗的确切堆。至少 (a) 是必须的。",
  },
  {
    id: "NUM-10",
    sev: "P3",
    conf: "verified",
    title: "ON_DAMAGE_TAKEN 的冷却是 ON_PROJECTILE_IMPACT 的三倍，无理由",
    where: "model/TriggerType.java:11-18",
    claim:
      "8 个触发载体的冷却 tick：ON_MELEE_STRIKE 30、ON_SWEEP_OR_CLEAVE 25、ON_PROJECTILE_IMPACT 20、ON_TRIDENT_CHANNEL 30、ON_BLOCK_HARVEST 20、ON_DAMAGE_TAKEN 60、ON_MOVEMENT_OR_LAND 40、ON_UTILITY_CYCLE 30。",
    why:
      "60 与 20 相差三倍，且这两个数字都写死在枚举里、不可配、无注释。ON_DAMAGE_TAKEN 承载的是护甲系（protection 家族、thorns），冷却长有道理（受击频率高）；ON_PROJECTILE_IMPACT 承载弓箭系，冷却短也有道理（命中频率低）。方向是合理的，但比例关系完全是隐性的——一个想调整护甲系强度的整合包作者，必须去改 Java 枚举并重新编译。",
    fix:
      "把冷却表移入 economy.json（或新开 triggers.json），按 TriggerType 名索引；在 GDD 里补一张表说明每档冷却的取值理由，让「60 是 20 的三倍」从一个事实变成一个有据可查的决定。",
  },
  {
    id: "NUM-11",
    sev: "OK",
    conf: "verified",
    title: "值得肯定：默认参数下，UI 引用的每个数字都对得上代码",
    where:
      "assets/lang/en_us.json (tip.risk_high / tip.risk_normal) · FusionEconomyRules 全文",
    claim:
      "逐项验算：tip.risk_high 说「稳定晶最低可压至 8%」——repulsive 档 base 0.45、floor 0.08、step 0.13、cap 3，needed = ceil((0.45-0.08)/0.13) = 3，fail = clampProb(0.45-0.39, 0.08, 0.85) = 0.08 ✓。tip.risk_normal 说「稳定晶可达 100%」——mid 档 0.18/0.18 → needed 1 → 0.00 ✓；high 档 0.28/0.18 → needed 2 → clamp 到 0.00 ✓。说「失败收取 50% 费用」——halfChargedXp = xpLevels/2、halfChargedReagents = reagentCount/2 ✓。说「失败不损失书与装备」——所有非互斥档的 destroysBookOnFail 均为 false ✓。",
    why:
      "这不是碰巧：computeNeededStabilizers 用 ceil 而不是 floor，正是为了「按实际需要的枚数消耗，多余的稳定晶不会被浪费」，而这条性质恰好让「能压到 0%/8%」的文案在数学上成立。互斥档要求双方都满级（REPULSIVE_REQUIRES_MAX_LEVEL）、中阶失败只收半价不毁物、低阶 0% 失败率——这三条合起来是一个有明确设计意图的「诚实风险曲线」，玩家承担的风险与他能看到的信息是一致的。",
    fix:
      "保持。唯一提醒：这些数字今天对得上，是因为文案把它们抄成了字面量（见文案页 TXT-8）；一旦 economy.json 被改，文案立刻失真。把它们改成 %s 占位符，这份「对得上」才能持续成立。",
  },
  {
    id: "NUM-12",
    sev: "OK",
    conf: "verified",
    title: "值得肯定：器魂槽的容量设计是自洽的",
    where:
      "mechanics/VesselCapacityRules.java:24-56 · model/FusedEnchantmentList.java:14",
    claim:
      "DEFAULT_SLOTS 1、GOLD_INNATE_SLOTS 2、HARD_CAP_SLOTS 直接引用 FusedEnchantmentList.HARD_MAX_VESSEL_SLOTS（2）；computeMaxSlots = min(HARD_CAP, base + clamp(bonus,0,1))；VESSEL_BONUS 的 codec 是 intRange(0,1)；canExpandSlots 用 < HARD_CAP 判定。化形（Cross-Domain）明确占 0 槽，与融合词条分开计。",
    why:
      "容量上限只有一个来源（HARD_MAX_VESSEL_SLOTS），组件 codec 的区间、扩容判定、UI 的 ◇ 数量都从它派生——这是全仓库硬编码治理做得最好的一处：数值写死了，但只写死了一次。黄金装备天生 2◇ 因此永远无法扩容，这个结论是 min() 自然得出的，不需要额外的特例分支。",
    fix:
      "保持。小提醒：VESSEL_BONUS 仍可被命令写成 1 而对黄金装备毫无效果，UI 应当在这种情况下不显示「+1」以免误导。",
  },
];
