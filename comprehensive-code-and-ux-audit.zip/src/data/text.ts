/* 本页全部数字均来自对仓库文本的直接测量，测量方法随每项标注。 */

export const LANG_AUDIT = {
  locales: [
    "de_de", "en_us", "es_es", "fr_fr", "it_it", "ja_jp",
    "ko_kr", "pt_br", "ru_ru", "zh_cn", "zh_tw",
  ],
  keysPerLocale: 829,
  missingVsEn: 0,
  extraVsEn: 0,
  dynamicKeyGroups: [
    { pattern: "fusion.enchantment_fusion.trigger.<8>", resolved: "8 / 8" },
    { pattern: "fusion.enchantment_fusion.payload.<14>", resolved: "14 / 14" },
    { pattern: "fusion.enchantment_fusion.effect.<14>.{combat,utility}", resolved: "28 / 28" },
    { pattern: "fusion.enchantment_fusion.host.<n>", resolved: "全部命中" },
    { pattern: "gui.enchantment_fusion.reagent.{none,lapis,amethyst,emerald}", resolved: "4 / 4" },
    { pattern: "gui.enchantment_fusion.reject.<11>", resolved: "11 / 11" },
    { pattern: "aberration.enchantment_fusion.<6>.{title,desc}", resolved: "12 / 12" },
    { pattern: "signature.enchantment_fusion.*", resolved: "348 键在册" },
    { pattern: "transmute.enchantment_fusion.*", resolved: "280 键在册" },
  ],
  guiFacingKeys: 146,
  ratios: [
    { loc: "de_de", median: 1.0, p90: 1.0, max: 1.5, worst: "btn.fuse (6 vs 4 字符)" },
    { loc: "es_es", median: 1.0, p90: 1.0, max: 2.0, worst: "btn.fuse (8 vs 4)" },
    { loc: "fr_fr", median: 1.0, p90: 1.09, max: 2.25, worst: "btn.fuse (9 vs 4)" },
    { loc: "it_it", median: 1.0, p90: 1.02, max: 1.75, worst: "btn.flip (7 vs 4)" },
    { loc: "ja_jp", median: 1.0, p90: 1.0, max: 1.4, worst: "grimoire.chapter.signatures (14 vs 10)" },
    { loc: "ko_kr", median: 1.0, p90: 1.0, max: 1.4, worst: "grimoire.chapter.signatures (14 vs 10)" },
    { loc: "pt_br", median: 1.0, p90: 1.0, max: 2.0, worst: "btn.flip (8 vs 4)" },
    { loc: "ru_ru", median: 1.0, p90: 1.0, max: 2.0, worst: "btn.flip (8 vs 4)" },
    { loc: "zh_cn", median: 0.38, p90: 0.59, max: 1.0, worst: "transmute_single (4 vs 4)" },
    { loc: "zh_tw", median: 0.38, p90: 0.59, max: 1.0, worst: "transmute_single (4 vs 4)" },
  ],
};

/* 用近似 Minecraft 默认字体字宽表估算（小写 5px、大写与数字 6px、窄字符 2px、空格 4px）。
   误差约 ±10%，用于判断量级而非精确排版。 */
export const BUTTON_OVERFLOW = [
  {
    key: "gui.enchantment_fusion.btn.flip",
    box: "btn_book_flip (140, 98, 44, 20)",
    inner: 38,
    rows: [
      { loc: "ja_jp", text: "反転", px: 12, scale: 1.0 },
      { loc: "zh_cn", text: "翻面", px: 12, scale: 1.0 },
      { loc: "en_us", text: "Flip", px: 15, scale: 1.0 },
      { loc: "it_it", text: "Inverti", px: 32, scale: 1.0 },
      { loc: "de_de", text: "Drehen", px: 31, scale: 1.0 },
      { loc: "es_es", text: "Voltear", px: 37, scale: 0.99 },
      { loc: "pt_br", text: "Virar?", px: 40, scale: 0.95 },
      { loc: "fr_fr", text: "Inverser", px: 41, scale: 0.93 },
      { loc: "ru_ru", text: "Переверн", px: 48, scale: 0.79 },
    ],
  },
  {
    key: "gui.enchantment_fusion.btn.split",
    box: "btn_book_split (187, 98, 47, 20)",
    inner: 41,
    rows: [
      { loc: "ja_jp", text: "分割", px: 12, scale: 1.0 },
      { loc: "zh_cn", text: "拆分", px: 12, scale: 1.0 },
      { loc: "en_us", text: "Split", px: 19, scale: 1.0 },
      { loc: "it_it", text: "Dividi", px: 31, scale: 1.0 },
      { loc: "fr_fr", text: "Scinder", px: 33, scale: 1.0 },
      { loc: "es_es", text: "Dividir", px: 36, scale: 1.0 },
      { loc: "de_de", text: "Aufteilen", px: 36, scale: 1.0 },
      { loc: "pt_br", text: "Dividir", px: 36, scale: 1.0 },
      { loc: "ru_ru", text: "Разделить", px: 54, scale: 0.76 },
    ],
  },
];

export const SCALE_LITERALS = {
  files: [
    { f: "EnchantmentFusionScreen.java", vals: [0.47, 0.48, 0.5, 0.52, 0.54, 0.56, 0.58, 0.62, 0.65, 0.72] },
    { f: "FusionGrimoireScreen.java", vals: [0.54, 0.56, 0.58, 0.6, 0.65, 0.66, 0.7] },
    { f: "FusionGuiSkin.java", vals: [0.5, 0.52] },
    { f: "FusionGuiMicroEffects.java", vals: [0.45, 0.5, 0.55, 0.65, 0.7, 0.75, 0.78] },
  ],
  distinctGuiScales: 14,
  nineSliceBorders: [
    { tex: "panel_frame.png (48×48)", borders: [4, 5, 6], sites: 4 },
    { tex: "button_*.png (32×32)", borders: [4], sites: 4 },
    { tex: "row_*.png (64×18)", borders: [4], sites: 3 },
    { tex: "socket_card_*.png (96×40)", borders: [7], sites: 2 },
  ],
};

/* 27 张 GUI 贴图的实际尺寸 vs 绘制尺寸。比值来自 test_ui_readability.py 的区域表
   与 drawNineSlice 调用点的实参。 */
export const TEXTURE_SCALE = [
  { tex: "grimoire_spread.png", native: "360×224", drawn: "360×224", ratio: 1.0, exact: true },
  { tex: "swap_button.png", native: "24×24", drawn: "24×24", ratio: 1.0, exact: true },
  { tex: "vessel_gem_*.png", native: "12×12", drawn: "12×12", ratio: 1.0, exact: true },
  { tex: "slot_*.png", native: "18×18", drawn: "18×18", ratio: 1.0, exact: true },
  { tex: "tab_*.png", native: "64×22", drawn: "104×20", ratio: 1.63, exact: false },
  { tex: "socket_card_*.png", native: "96×40", drawn: "186×23", ratio: 1.94, exact: false },
  { tex: "row_*.png", native: "64×18", drawn: "186×16", ratio: 2.91, exact: false },
  { tex: "button_*.png", native: "32×32", drawn: "61×26 (EXEC)", ratio: 1.91, exact: false },
  { tex: "panel_frame.png", native: "48×48", drawn: "308×196", ratio: 6.42, exact: false },
];

export interface TextFinding {
  id: string;
  kind: "readability" | "accuracy" | "identity";
  sev: "P0" | "P1" | "P2" | "P3" | "OK";
  title: string;
  titleEn: string;
  where: string;
  claim: string;
  why: string;
  fix: string;
  code?: string;
}

export const TEXT_FINDINGS: TextFinding[] = [
  {
    id: "TXT-1",
    kind: "readability",
    sev: "P1",
    title: "同一段算法，两个不同的最小缩放地板：0.50 与 0.52",
    titleEn: "One algorithm, two shrink floors",
    where: "client/gui/FusionGuiSkin.java:204（drawCenteredBoundedText）vs :239（drawLeftBoundedText）",
    claim:
      "两个方法的溢出处理完全一致：rawW*scale > box → 试 fit = boxW/rawW；fit >= minScale 就用 fit，否则钉在 minScale 并用 font.plainSubstrByWidth 截断后补 U+2026。唯一差别是 minScale：居中版 0.50F，左对齐版 0.52F。",
    why:
      "找不到任何注释、常量或提交信息解释这 0.02 的差别。它带来的实际后果是：同一行 UI 里，居中标签可以缩到 50%，左对齐标签只缩到 52%，两者在临界长度上会走不同分支——一个开始省略号，另一个还在硬缩。这就是「同一性」问题最纯粹的样本：不是翻译不一致，是渲染规则不一致，而规则本身是复制粘贴出来的。",
    fix:
      "抽一个 private static String fitText(Font, String, int boxW, float maxScale, float minScale, Align) 供两者调用；minScale 提为具名常量 MIN_TEXT_SCALE = 0.52F（选一个值），若确需按对齐方式区分，则在常量名里写明理由。",
    code: `public static void drawCenteredBoundedText(...) {
    float minScale = 0.50F;      // ← 居中：0.50
    ...
}
public static void drawLeftBoundedText(...) {
    float minScale = 0.52F;      // ← 左对齐：0.52
    ...
}`,
  },
  {
    id: "TXT-2",
    kind: "readability",
    sev: "P1",
    title: "有命名的调色板，没有命名的字阶：14 个散落的缩放系数",
    titleEn: "A named colour palette, an unnamed type scale",
    where: "client/gui/*.java（4 个文件）· FusionGuiSkin.java:71-85",
    claim:
      "颜色侧做得很好：COLOR_GOLD / CREAM / CYAN / AMETHYST / GREEN / WARN / RED / MUTED 加 5 个 COLOR_INK_*，共 13 个具名令牌。字号侧：两个屏幕类里出现 0.47 / 0.48 / 0.50 / 0.52 / 0.54 / 0.56 / 0.58 / 0.60 / 0.62 / 0.65 / 0.66 / 0.70 / 0.72 共 14 个不同缩放系数，全部为就地字面量，无一具名。九宫格 border 同样有 4 / 5 / 6 / 7 四个值，其中 panel_frame.png 一张贴图就用了 4、5、6 三种。",
    why:
      "同一张 48×48 的边框贴图在三处以不同的 border 值绘制（主面板 6、预览框 5、右侧面板 5），意味着三个面板的圆角半径与描边粗细在像素上不一致——这在一张 308×214 的小界面里是肉眼可见的。而 0.47 与 0.48 之间的差别则肉眼不可见，纯粹是调参残留。两者合起来说明：视觉体系缺一个「字阶 + 边框阶」的令牌层，颜色有而尺寸没有。",
    fix:
      "建立与 COLOR_* 平行的尺寸令牌：SCALE_MICRO=0.52 / SCALE_SMALL=0.58 / SCALE_BODY=0.66 / SCALE_LABEL=0.72 / SCALE_TITLE=0.98，把 14 个字面量收敛到这 5 个；border 同理收敛到 BORDER_PANEL=6 / BORDER_CARD=5 / BORDER_BTN=4，并把它们与对应贴图尺寸放在一起声明。收敛之后再做一次像素对比，多半会发现原本 0.47/0.48/0.50 三档本来就应该是同一档。",
  },
  {
    id: "TXT-3",
    kind: "readability",
    sev: "P1",
    title: "缩到一半还带阴影：小字号下最糊的那种组合",
    titleEn: "Half-scale text still renders with a drop shadow",
    where: "client/gui/FusionGuiSkin.java:262-273 vs client/gui/FusionGrimoireScreen.java:365-372",
    claim:
      "drawScaledText 一律 ctx.text(font, text, 0, 0, argbColor, true)——shadow 为 true，且它承载全部按钮与受限标签，包括缩到 0.50/0.52 的那些。秘典正文则是 ctx.text(this.font, seq, 0, curY, COLOR_INK_BODY, false)——shadow 为 false。",
    why:
      "Minecraft 的字体阴影是偏移 1 单位的暗色副本。pose.scale(0.5) 之后这 1 单位变成 0.5 像素，阴影与本体在同一个像素格里部分重叠，结果是笔画被加粗、字腔被填掉——恰好发生在字号已经最小、最需要清晰度的场合。而秘典正文用的 COLOR_INK_BODY（#4E331B 深棕）画在羊皮纸底上，本来就有足够对比度，不需要阴影；按钮标签画在深色皮肤上，也不需要阴影，因为它们用的是 COLOR_CREAM / COLOR_GOLD 这类亮色。也就是说：阴影在这里既非必要，又在最坏的时刻有害。两处不一致则说明它不是决定，是默认值。",
    fix:
      "drawScaledText 增加一个 shadow 参数，或按缩放自动决定：scale < 0.75F 时传 false。同时统一秘典与主屏的取值——建议全部关闭阴影，改由 COLOR_INK_* / COLOR_CREAM 的明度差保证对比度（这套调色板已经足够）。",
    code: `// FusionGuiSkin：全部按钮与受限标签
ctx.text(font, text, 0, 0, argbColor, true);      // shadow = true，含 0.50 缩放

// FusionGrimoireScreen：正文
ctx.text(this.font, seq, 0, curY, COLOR_INK_BODY, false);   // shadow = false`,
  },
  {
    id: "TXT-4",
    kind: "readability",
    sev: "P2",
    title: "秘典正文超出 116px 就断在句中，没有省略号也没有续页提示",
    titleEn: "Body text stops mid-sentence at an undocumented 116px",
    where: "client/gui/FusionGrimoireScreen.java:361-374",
    claim:
      "float scale = 0.60F; int wrapWidth = Math.max(80, Math.round(rw / scale)); lines = font.split(Component.literal(item.bodyText()), wrapWidth); 循环里 if (curY * scale > 116.0F) break; 每行 curY += 11。",
    why:
      "三个问题叠在一起。(1) 116 是个没有出处的数字：右侧详情面板高 178，正文起点在 ry+56，可用高度约 122，取 116 意味着留了 6px——但这个 6px 与 drawNineSlice 用的 border=7 对不上，看不出是刻意留白还是凑数。(2) 触顶时直接 break，最后一行可能是半句话，既没有 U+2026 也没有「续下页」，读者无法区分「说完了」和「被截了」——而秘典的三段式知识系统（未知/初识/通晓）的全部价值就在这段正文里。(3) Math.max(80, …) 的 80 与面板宽度无关：rw=141、scale=0.6 时算出 235，80 永远不生效；但一旦布局收窄到 rw<48，wrapWidth 会被强行钉在 80 字符（约 440px），文本直接溢出面板——一个休眠的溢出 bug，且这个下限的存在恰好抵消了 rw/scale 计算的意义。",
    fix:
      "把 116 提为具名常量并由面板几何推导（DETAIL_H - BODY_TOP - PADDING）；触顶时在最后一行末尾追加 U+2026 并（更好）支持翻页/滚动；删掉 Math.max(80, …) 或改为 Math.max(font 能容纳的最小列宽, …) 并加注释说明为何需要下限。",
  },
  {
    id: "TXT-5",
    kind: "readability",
    sev: "P2",
    title: "27 张 GUI 贴图只有 4 类是 1:1 绘制的，而注释承诺「razor-sharp」",
    titleEn: "Four of twenty-seven textures are drawn 1:1; the javadoc promises razor-sharp",
    where:
      "client/gui/FusionGuiSkin.java:118-120（javadoc）· 14 处 drawNineSlice 调用 · assets/textures/gui/*.png",
    claim:
      "javadoc 写：「Renders a pixel-art 9-slice frame (panel_frame.png 48x48 or button_*.png 32x32) so corner studs and borders stay 1:1 razor-sharp at any target rectangle size.」实测贴图尺寸与绘制尺寸：grimoire_spread 360×224→360×224（1.00）、swap_button 24×24→24×24（1.00）、vessel_gem 12×12（1.00）、slot_* 18×18（1.00）；tab_* 64×22→104×20（1.63× / 0.91×）、socket_card 96×40→186×23（1.94×）、row_* 64×18→186×16（2.91×）、button_* 32×32→61×26（1.91×）、panel_frame 48×48→308×196（6.42×）。",
    why:
      "九宫格确实能让四个角保持 1:1——这句话本身没错。但边与中心会被按 1.63× / 1.94× / 2.91× / 6.42× 这样的非整数倍拉伸，而像素美术在非整数倍缩放下的表现恰恰是「边缘发虚、线宽不均」。也就是说：这个 mod 的整个界面骨架（主面板、行底、卡片、按钮）都处在非整数倍缩放下，而代码注释告诉维护者它们是 razor-sharp 的。后续维护者据此不会去检查贴图分辨率是否该重做——注释在这里起了误导作用。附带一处硬伤：单个 sprite 的 texW/texH 由运行时布尔决定（texW = singleMode ? 64 : 32, texH = singleMode ? 18 : 32），必须与 sprite 选择表达式严格同步，否则 UV 静默错位。",
    fix:
      "(a) 把 javadoc 改成实话：「四角保持 1:1，边与中心按目标尺寸线性拉伸」；(b) 若要真正的像素锐利，把 panel_frame 重做为 308×196 的整图（或提供 2× 版本并让所有目标尺寸成为贴图尺寸的整数倍）；(c) 把 texW/texH 与 sprite 绑定成一个 record SkinSprite(Identifier id, int texW, int texH, int border)，消灭那个三元表达式。",
    code: `// 单个 sprite 的贴图尺寸由运行时布尔决定 —— 必须与 sprite 选择保持同步
drawNineSlice(ctx, singleSprite, gx, gy, SINGLE_MODE_BTN.w(), SINGLE_MODE_BTN.h(),
    singleMode ? 64 : 32, singleMode ? 18 : 32, 4);

// 同一张 48×48 贴图，三种 border
drawNineSlice(ctx, PANEL_FRAME, ..., this.imageWidth, this.imageHeight - 18, 48, 48, 6);
drawNineSlice(ctx, PANEL_FRAME, ..., RIGHT_W, TAB0_PREVIEW_BOX.h(), 48, 48, 5);
drawNineSlice(ctx, PANEL_FRAME, ..., TAB0_PREVIEW_BOX.w(), TAB0_PREVIEW_BOX.h(), 48, 48, 5);`,
  },
  {
    id: "TXT-6",
    kind: "accuracy",
    sev: "P1",
    title: "UI 文案把 economy.json 的默认值抄成了字面量",
    titleEn: "Tooltip prose hardcodes the default config values",
    where:
      "assets/lang/*/…:gui.enchantment_fusion.tip.risk_high · tip.risk_normal · data/…/economy.json",
    claim:
      "tip.risk_high（en_us，102 字符）：\"Instability Risk: %s%% (Failure mutates into Aberrant Fusion or Curse; Stabilizers lower to 8%% floor)\"。tip.risk_normal：\"Fluctuation Chance: %s%% (No books or gear lost on failure, 50%% fee spent; Stabilizers reach 100%%)\"。对应的可配项是 repulsive_min_floor = 0.08、halfChargedXp() = xpLevels/2、以及常规档 floor 0.0。",
    why:
      "这三处数字今天在默认配置下是准确的（见数值页 NUM-11 的逐项验算），但它们是被抄进 11 个语言文件的字面量，而不是从已同步到客户端的 EconomyConfig 里格式化出来的。包作者把 repulsive_min_floor 改成 0.15，游戏里 11 种语言仍然齐声说「8%」；把稳定晶减益调小，仍然说「可达 100%」。这是「文案准确性」最典型的失效模式：文案不是写错了，是写对了一次然后就冻住了。而 MatrixSyncPayload 已经把整个 EconomyConfig 同步给客户端了——数据就在手边，只是没用。",
    fix:
      "把 8%% / 50%% / 100%% 改成 %s 占位符，由 FusionTooltipRenderer 从 FusionMatrixRegistry.current().economy() 取值填入（客户端已有这份快照）。11 个语言文件同步改一遍——scripts/ci_static_checks.py 已经在做键位对齐检查，可以顺便加一条「同一键在各语言的占位符数量必须一致」的断言，防止翻译时漏改。",
    code: `"gui.enchantment_fusion.tip.risk_high":
  "Instability Risk: %s%% (Failure mutates into Aberrant Fusion or Curse; Stabilizers lower to 8%% floor)"
                                                                                       ↑
                                              repulsive_min_floor 的默认值，写死在 11 个语言文件里`,
  },
  {
    id: "TXT-7",
    kind: "accuracy",
    sev: "P1",
    title: "源码里四处 GDD 章节引用全部指向不存在的编号",
    titleEn: "All four GDD section references in the source are dangling",
    where:
      "VesselCapacityRules.java:15（GDD §3）· TriggerType.java:5（§5.1）· PayloadType.java:5（§5.2）· GrindstoneAberrationGuardMixin.java:14（§6.1）→ docs/GDD.md",
    claim:
      "docs/GDD.md 的全部标题是：《融合附魔》…(GDD v5.0 · 0.5.0) / 核心特性总览（0.4.1 实装基线）/ 阶梯资费、诚实风险曲线与「畸变词条」（economy.json 数据包可配）/ 6 种实装「畸变词条」… / 数据组件与网络同步架构（Minecraft 26.1.2）/ 四项核心数据组件 / 数据包目录与网络协议。没有任何编号章节，不存在 §3、§5.1、§5.2、§6.1。",
    why:
      "代码注释里的章节引用是设计意图与实现之间唯一的可追溯链路，四处全断意味着：想知道「器魂槽为什么是 1/2/2」的人，从 VesselCapacityRules 的 javadoc 出发找不到任何落点。而且这四个引用看起来是同一批写下的（编号连续、风格一致），说明 GDD 曾经有过编号版本，后来重写成中文标题体时没有回头改代码——这是文档重构未完成的典型残留。",
    fix:
      "给 docs/GDD.md 恢复编号章节（## 3. 器魂槽容量、## 5.1 触发载体、## 5.2 载荷核心、## 6.1 畸变与净化），或者把代码里的 §引用改成锚点链接（docs/GDD.md#器魂槽容量）。再加一条静态检查：grep 出所有 \"GDD §\" 引用，逐个验证目标锚点在 GDD.md 里存在——这类检查用 10 行 Python 就能写，而 scripts/ 下已经有 8 个同类脚本。",
  },
  {
    id: "TXT-8",
    kind: "accuracy",
    sev: "P2",
    title: "一份文档里三个版本号，代码是第四个",
    titleEn: "Three version stamps in one document; the code carries a fourth",
    where:
      "docs/GDD.md:1（v5.0 · 0.5.0）· :9（0.4.1 实装基线）· gradle.properties:11（0.6.0）· CURRENT_BASELINE.md（0.6.0）· CHANGELOG.md（0.6.0）",
    claim:
      "GDD 标题自称「GDD v5.0 · 0.5.0」，其下的特性总览小节标题是「核心特性总览（0.4.1 实装基线）」，而 gradle.properties / CURRENT_BASELINE / CHANGELOG 一致为 0.6.0。CHANGELOG 显示 0.1.0→0.6.0 六个版本全部落在 2026-10-28 与 10-29 两天内。",
    why:
      "GDD 落后一个小版本、其总览落后两个小版本，读者无法判断哪一段描述的是当前实现。CHANGELOG 的日期分布还带来第二层问题：两天六个版本意味着版本号在跟踪提交批次而不是玩家可感知的里程碑，那么「0.6.0 Playtest Mechanics」这类里程碑叙述与实际平衡状态之间的关系就很松——这也让 NUM-1/NUM-2 那类平衡问题更难被版本历史定位。check_release_consistency.sh --strict 检查了 gradle.properties ↔ README ↔ fabric.mod.json ↔ docs/ci/publish.yml，唯独不检查 docs/GDD.md 与 CHANGELOG.md。",
    fix:
      "GDD 只保留一个版本戳（文档自己的 v 号）并显式写明「对应 mod 版本 0.6.0」；把 GDD.md 与 CHANGELOG.md 纳入 check_release_consistency.sh 的检查范围；小节标题里的「0.4.1 实装基线」删除或改为「本节描述自 0.4.1 起未变的基线特性」——把版本戳从标题移到正文，避免每次发版都要改标题。",
  },
  {
    id: "TXT-9",
    kind: "identity",
    sev: "P0",
    title: "publish.yml 仍会以姊妹 mod 的身份发布本 mod",
    titleEn: "publish.yml would release this mod under another mod's identity",
    where:
      ".github/workflows/publish.yml:6-9 · docs/ci/publish.yml:6-9 · .github/workflows/build.yml:102 · scripts/check_release_consistency.sh:52-56",
    claim:
      ".github/workflows/publish.yml 里是 MINECRAFT_VERSION: 26.1.2 / VERSION: 1.1.0 / RELEASE_NAME: \"Chiseled Enchanting Table 1.1.0 (Unofficial 26.1.2 Port)\"；docs/ci/publish.yml 里是 VERSION: 0.6.0 / RELEASE_NAME: \"Enchantment Fusion 0.6.0 (Minecraft 26.1.2 Fabric)\"。build.yml 的 artifact 名是 chiseled-enchanting-table-${{ github.sha }}。一致性脚本对这条漂移只输出一行非致命 WARN，注释理由是「token 缺少 workflows: write 权限，无法自动同步」。",
    why:
      "这是本次审计里后果最直接的一条。publish.yml 由 workflow_dispatch 手动触发，一旦有人按下那个按钮，GitHub Release / Modrinth 上出现的会是名为「Chiseled Enchanting Table 1.1.0 (Unofficial 26.1.2 Port)」、版本号 1.1.0 的条目，内容却是 enchantment-fusion 0.6.0 的 jar。对一个明确声明「不隶属原作者、bug 请报到本仓库」的社区移植来说，把另一个 mod 的名字与版本挂在发布页上，是会伤到上游作者与玩家的问题。而 WARN 级别的门禁意味着它不会被任何人拦下。artifact 名同理：下载者拿到的压缩包叫 chiseled-enchanting-table-<sha>.zip，里面是 enchantment-fusion-0.6.0.jar。",
    fix:
      "立即人工修正 .github/workflows/publish.yml 与 build.yml（一次带 workflows: write 权限的提交即可，之后 install.sh --check 就不会再报漂移）；把这条漂移在 --strict 下升级为硬失败，并在脚本里注明「若 CI 因权限无法自愈，必须由人工确认后手动放行」；给 publish.yml 增加一道发布前断言：VERSION 必须等于 gradle.properties 的 mod_version，否则 job 失败。",
    code: `# .github/workflows/publish.yml —— 实际会执行的那一份
  MINECRAFT_VERSION: 26.1.2
  VERSION: 1.1.0
  RELEASE_NAME:  Chiseled Enchanting Table 1.1.0 (Unofficial 26.1.2 Port)

# docs/ci/publish.yml —— 正确但没有生效权限的那一份
  VERSION: 0.6.0
  RELEASE_NAME: Enchantment Fusion 0.6.0 (Minecraft 26.1.2 Fabric)

# check_release_consistency.sh
echo "WARN: .github/workflows/publish.yml differs from docs/ci/publish.yml (workflows permission required to sync)"`,
  },
  {
    id: "TXT-10",
    kind: "identity",
    sev: "P1",
    title: "仓库默认分支描述的是另一个 mod，并链接到不存在的文档",
    titleEn: "The default branch describes a different mod and links to absent docs",
    where:
      "默认分支 chiseled-enchanting-table-26.1.2-source 的 README.md · 本分支 docs/（仅 GDD.md 与 ci/）",
    claim:
      "访问仓库根地址（默认分支）看到的是「Chiseled Enchanting Table — Unofficial 26.1.2 Port」、Current version 1.1.0、以及一个醒目的 📖 链接指向 docs/WIKI.md（「中文机制详解与上游差异完整对照」）和 docs/reports/SYNC_FROM_26_3_REPORT.md。本次审计的分支上 docs/ 只有 GDD.md 与 ci/，两个被链接的文件都不存在。默认分支 README 还有若干 Markdown 脱字：链接后缺空格（…chiseled-enchanting-table)updated to、…issues/3)worldgen deadlock fix），以及 `CURRENT_BASELINE.md` 未加反引号导致下划线被当作强调标记、渲染成 CURRENTBASELINE.md。",
    why:
      "一个仓库同时承载两个不同 mod 的分支，而默认分支是另一个 mod 的门面——这是「同一性」问题的最大尺度版本：读者从 GitHub 搜索、issue 链接、或 CI 徽章进来，看到的第一份说明与本分支的源码毫无关系。docs/WIKI.md 被 README 用加粗+📖 强调为「完整玩法维基」，却是不存在的文件；这是最强的引导语指向最空的落点。Markdown 脱字与下划线吞噬则让文件名本身变成错的，读者复制粘贴会失败。",
    fix:
      "短期：在本分支 README 顶部加一行说明「本分支为 Enchantment Fusion（融合附魔），与仓库默认分支描述的 Chiseled Enchanting Table 移植是两个不同项目」；修正默认分支 README 的三处 Markdown 脱字（补空格、给文件名加反引号）；把 docs/WIKI.md 的死链改为存在的路径或删除。长期：把两个 mod 拆成两个仓库——它们共享的只有 CI 脚本骨架，而共享仓库的代价已经体现在 publish.yml、build.yml artifact 名与 README 三处身份污染上。",
  },
  {
    id: "TXT-11",
    kind: "identity",
    sev: "P2",
    title: "同一概念在代码里有两种词形：aberrant 与 aberration",
    titleEn: "Two spellings of one concept across the codebase",
    where:
      "mechanics/AberrantRegistry.java · model/FusedPair.aberrationId · assets/lang/*:aberration.enchantment_fusion.* · CompendiumDiscoveryTracker.aberrantKey()",
    claim:
      "类名 AberrantRegistry、方法 isAberrant() / hasAberration() / recordAberrantMastered() / aberrantKey()、常量 PREFIX_ABERRANT = \"cet_aberrant/\"；同时字段名 aberrationId、翻译键前缀 aberration.enchantment_fusion.<id>.{title,desc}、方法 pickAberration() / pickRandomAberration() / executeAberration()。状态键用 \"aberrant/\"，翻译键用 \"aberration.\"。",
    why:
      "两种词形都语法正确（aberrant 形容词、aberration 名词），但它们被混用在同一个概念的不同层面：字段叫 aberrationId，读它的键函数叫 aberrantKey，它拼出的状态前缀是 \"aberrant/\"，而它最终要查的翻译键前缀是 \"aberration.\"。grep 一个词形会漏掉一半。这不是命名品味问题——它直接提高了排查成本：查「畸变相关的全部逻辑」必须搜两个词根，而 CompendiumDiscoveryTracker 里两者相距不到 20 行。",
    fix:
      "定一条规则并写进 CONTRIBUTING：类型/概念名统一用名词 aberration，布尔判定用形容词 aberrant（isAberrant / hasAberration 保留）。据此重命名 AberrantRegistry → AberrationRegistry、aberrantKey() → aberrationKey()、PREFIX_ABERRANT → PREFIX_ABERRATION；状态键前缀 \"aberrant/\" 因为已落盘，需要写一次读档兼容映射。翻译键 aberration.* 已经是对的，不动。",
  },
  {
    id: "TXT-12",
    kind: "identity",
    sev: "P2",
    title: "姊妹 mod 在文档里有四种写法",
    titleEn: "Four spellings of one sister mod",
    where:
      "docs/GDD.md:42 · compat/CetSoftBridge.java:19-20 · resources/fabric.mod.json · mixin/FusionMixinConfigPlugin.java:20-22",
    claim:
      "《纂刻附魔台》（GDD）、Chiseled Enchanting Table（注释与文档英译）、chiseled-enchanting-table（CET_MOD_ID，连字符，用于 isModLoaded 与 suggests）、chiseled_enchanting_table（CET_NAMESPACE，下划线，用于 Identifier 命名空间与 mixin 目标类前缀）。",
    why:
      "前两个是给人看的名字，后两个是机器 id，四者并存本身合理——问题在于没有任何一处把这张对应表写下来。fabric.mod.json 的 suggests 只列了连字符形式；FusionMixinConfigPlugin 把两个字面量重新抄了一遍（有正当理由：config plugin 加载极早，不宜 import mod 类，但代码里没有说明）；mixin 目标类前缀用下划线形式。一个新贡献者读到 suggests 里只有一个 id，会以为另一个是笔误。",
    fix:
      "在 CetSoftBridge 的 javadoc 里加一张四行对照表（显示名 / 英文文档名 / Fabric mod id / 资源命名空间），并在 FusionMixinConfigPlugin 顶部注明「此处字面量必须内联，因为 config plugin 在 mod 初始化之前运行，不可引用 CetSoftBridge」；suggests 里同时列出两种 id 形式。",
  },
  {
    id: "TXT-13",
    kind: "readability",
    sev: "P2",
    title: "名为「UI 易读性」的测试，一行文字都没有检查",
    titleEn: "The test named for UI readability never inspects a single glyph",
    where: "scripts/test_ui_readability.py（全文 84 行）",
    claim:
      "5 个测试方法：4 个对一份手写的区域字典做矩形不相交与不越界断言（COMMON 里 10 个区域，各 tab 再补 2-3 个，上限写死 308×214 与 360×224）；第 5 个 test_screens_use_gpu_scissor_and_zero_solid_fills 对两个 Java 源文件做三次字符串断言：assertIn(\"enableScissor\")、assertIn(\"disableScissor\")、assertNotIn(\".fill(\")。",
    why:
      "名字承诺的是 readability，交付的是 geometry + grep。三个具体缺陷：(1) 区域字典是 Java 常量的手抄副本，测试断言的是这份副本——Java 里把按钮挪到 (300,200) 而 Python 不改，测试依然全绿；它防的是「有人改错了 Python 字典」。(2) 完全没有文字维度：没有行长、没有字号、没有截断、没有换行宽度、没有对比度、没有各语言溢出——也就是本页 TXT-1 到 TXT-6 那六类问题，一个都测不到。(3) assertNotIn(\".fill(\") 既过宽又过窄：过宽是因为它禁掉了 GuiGraphics 一个合法且常用的原语，过窄是因为它不拦 .fillGradient(、也不拦通过 helper 间接调用的 fill。",
    fix:
      "改名 test_ui_geometry.py，诚实地描述它做的事；另建真正的 readability 测试：(a) 用一张按语言 × 键的估算字宽表（本页 BUTTON_OVERFLOW 的方法）断言所有 btn.* 键在 11 个语言下的缩放系数不低于某阈值（例如 0.85），把 TXT-6 那类溢出变成 CI 结论；(b) 断言所有动态生成的翻译键在每个语言文件里存在（AssetAndLocaleContractTest 已经做了一部分，把 signature./transmute./aberration. 三组补齐）；(c) 把 .fill( 的负面断言换成对具体 helper 的正面断言，或干脆删掉，交给 review。",
    code: `def test_screens_use_gpu_scissor_and_zero_solid_fills(self) -> None:
    for rel in (".../EnchantmentFusionScreen.java", ".../FusionGrimoireScreen.java"):
        src = (ROOT / rel).read_text(encoding="utf-8")
        self.assertIn("enableScissor", src)
        self.assertIn("disableScissor", src)
        self.assertNotIn(".fill(", src)      # ← 不拦 .fillGradient(，却禁掉一个合法原语`,
  },
  {
    id: "TXT-14",
    kind: "accuracy",
    sev: "P1",
    title: "不可逆状态的前置条件没有出现在任何玩家可见文本里",
    titleEn: "The precondition for an irreversible state appears in no player-facing text",
    where:
      "docs/GDD.md:42 · assets/lang/*:gui.enchantment_fusion.tip.risk_high · resources/fabric.mod.json (suggests)",
    claim:
      "GDD 的小节标题写明「6 种实装「畸变词条」（Aberrant Fusion · 唯《纂刻附魔台》可净化）」。游戏内 tip.risk_high 只说 \"Failure mutates into Aberrant Fusion or Curse; Stabilizers lower to 8% floor\"，没有提到净化需要另一个 mod。fabric.mod.json 把姊妹 mod 列为 suggests 而非 depends。README 与 GDD 正文也没有把「未安装姊妹 mod 时畸变不可移除」作为一条独立警告。",
    why:
      "玩家在看到的唯一一句风险提示里，得到的是「失败会变成畸变词条」加一个可以用稳定晶压到 8% 的数字——这是一个鼓励他承担风险的表述。他没有被告知的是：一旦失败，在只装了本 mod 的环境里这件物品永久无法翻面、无法卸除、无法砂轮清洗（三条路径全部返回拒绝或空结果）。设计文档知道这件事，UI 不知道。这是「文档准确但文案不完整」——而完整的那一半恰好是玩家做决定时需要的那一半。",
    fix:
      "在执行按钮的确认区增加一条条件文案：若 !CetSoftBridge.isCetLoaded()，显示 message.enchantment_fusion.warn.aberrant_irreversible（「畸变词条在本环境中无法净化——建议安装《纂刻附魔台》」），并在 tip.risk_high 的括号里补一句。同时落实耦合页 CPL-1 的建议：提供本 mod 自带的高代价净化路径，让这条警告最终可以被删掉。",
  },
  {
    id: "TXT-15",
    kind: "identity",
    sev: "OK",
    title: "值得肯定：829 键 × 11 语言，双向零漂移",
    titleEn: "829 keys across 11 locales with zero drift in either direction",
    where: "assets/enchantment_fusion/lang/*.json · scripts/ci_static_checks.py · src/test/AssetAndLocaleContractTest.java",
    claim:
      "实测：11 个语言文件各 829 键，相对 en_us 的缺失数为 0、多余数为 0。所有动态拼接的键组全部可解析：trigger 8/8、payload 14/14、effect 28/28、reagent 4/4、reject 11/11、aberration 12/12，另有 signature.* 348 键、transmute.* 280 键在册。146 个 GUI/tooltip 面向键的相对英文长度中位数，10 个非英语语言全部为 1.00（zh_cn/zh_tw 为 0.38，即显著更短）；最长的单键膨胀是 fr_fr 的 btn.fuse，2.25×。ci_static_checks.py 把语言键对齐列为静态门禁之一；AssetAndLocaleContractTest 还用两条 assertFalse 钉住了已被清除的死键不许回潮。",
    why:
      "这是本次审计里质量最高的一项，而且不是运气：中位数 1.00 说明翻译时被要求（或自觉地）控制在与英文相近的长度内，这正是让 TXT-6 那类溢出只出现在少数几个键上的原因。829 键含 348 条签名共鸣与 280 条化形词条——这两组是内容量最大的部分，11 种语言全数到位，工作量不小。用负向断言固化死键清理，则是很少见的自律。",
    fix:
      "保持，并把这份纪律延伸到尚未覆盖的地方：(a) 补一条占位符一致性断言（同一键在各语言的 %s / %% 数量必须相同），为 TXT-6 的改造兜底；(b) 把「按语言估算字宽 vs 目标控件内宽」做成断言，让 TXT-6 那类溢出在 CI 里可见；(c) ja_jp 文件比其余语言大约 2KB（91,617 vs 89,6xx），值得看一眼是否有键携带了额外的注释性文本。",
  },
  {
    id: "TXT-16",
    kind: "readability",
    sev: "OK",
    title: "值得肯定：中英混排的术语处理是有意识的",
    titleEn: "Bilingual terminology is handled deliberately, not accidentally",
    where: "README.md · docs/GDD.md · CURRENT_BASELINE.md · 源码 javadoc",
    claim:
      "中文术语一律带反引号或书名号并给出英文对照：「器魂槽」(Vessel Slots)、「衍生语义共鸣」(Signature Resonances)、「路径暂缓存判定」(Trajectory Path-Cache)、「异位化形」(Cross-Domain Transmutations)、《融合秘典》(Fusion Grimoire)、「纂刻附魔台」(Chiseled Enchanting Table)。javadoc 里也保持同一套对照（例如 \"Order-sensitive Vanilla+ enchantment fusion\" 与 [A ▷ B] ≠ [B ▷ A] 的记号）。README 用 ◇ 表示槽位、用 ▷ 表示有序对，两个符号在文档、UI 与代码注释里含义一致。",
    why:
      "这套约定让「易读性」在一个天然双语的项目里成立了：读者不需要在两套术语间做心算映射，符号系统（◇ / ▷ / [A ▷ B]）跨文档一致，而且中文术语用书名号与引号区分了「作品名」与「机制名」——《融合秘典》是一件物品，「器魂槽」是一个概念。整体判断：易读性合格，问题集中在准确性（TXT-6/7/8）与同一性（TXT-11/12），而不是可读性本身。",
    fix:
      "把这套对照抽成 docs/GLOSSARY.md 一张表（中文 / 英文 / 符号 / 首次出现的文件），让 TXT-11 与 TXT-12 那两类词形漂移有一个权威落点；术语表同时可作为翻译者的参考，降低 11 语言未来出现同义分叉的概率。",
  },
];

export const KIND_META = {
  readability: { zh: "易读性", en: "Readability", color: "#7cf0ff" },
  accuracy: { zh: "准确性", en: "Accuracy", color: "#ffb86c" },
  identity: { zh: "同一性", en: "Consistency", color: "#e3b2ff" },
} as const;
