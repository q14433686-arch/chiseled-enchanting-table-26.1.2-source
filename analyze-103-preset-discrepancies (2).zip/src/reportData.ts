export const repository =
  "https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source";

export const currentRevision = "b9e9da9";
export const reviewedBranch = "arena/8eb3bb9e-chiseled-enchanting-table-26-1";
export const legacyRevision = "26.1.2_1.0.3";

type Revision = "old" | "current";

export type Evidence = {
  label: string;
  url: string;
  revision: "1.0.3" | "当前" | "API";
};

export type Category = "mechanic" | "economy" | "copy" | "content";
export type Priority = "P0" | "P1" | "P2";
export type Status = "fixed" | "partial" | "open";

export type Finding = {
  id: string;
  number: string;
  category: Category;
  priority: Priority;
  status: Status;
  title: string;
  summary: string;
  baseline: string;
  current: string;
  recommendations: string[];
  acceptance: string;
  caveat?: string;
  evidence: Evidence[];
};

const java = "src/main/java/chiseled_enchanting_table/";
const client = "src/client/java/chiseled_enchanting_table/";
const lang = "src/client/resources/assets/chiseled_enchanting_table/lang/zh_cn.json";
const data = "src/main/resources/data/chiseled_enchanting_table/chiseled_enchanting_table/";
const recipe = "src/main/resources/data/chiseled_enchanting_table/recipe/";

export function sourceUrl(revision: Revision, path: string, lines?: string) {
  const ref = revision === "old" ? legacyRevision : currentRevision;
  return `${repository}/blob/${ref}/${path}${lines ? `#${lines}` : ""}`;
}

const evidence = (label: string, revision: Revision, path: string, lines: string): Evidence => ({
  label,
  url: sourceUrl(revision, path, lines),
  revision: revision === "old" ? "1.0.3" : "当前",
});

export const reviewSummary = {
  headline: "第三次复检（b9e9da9）：上轮 6 项残留收敛为 3 项部分修复，同时新增 2 个由新改动带来的问题。",
  body:
    "自 620b092 后新增 2 个实质提交（1a90ffb Round 3、d805e1b）。经典模式改为「模式旗标 + 可编辑数值档案」，硬门禁（顿悟 0、共鸣子上限 0、抄错 NONE、经典成本/升书/置换表、盐值选料）全部直接挂在 classic103Mode 上，与数值编辑解耦——这是正确方向。秘典 1–9 章全部挂上经典提示，JEI/REI 站点信息也有经典版本，预设正式更名「1.0.3 玩法规则」。残留：页签总述一句旧文案；预设短名/状态栏仍写「原味/原汁原味」与新命名自相矛盾；新加的锁书绕过门禁读的是本地配置文件而非服务端有效值。",
  metrics: [
    { label: "本轮复检问题", value: "16" },
    { label: "已修复", value: "11" },
    { label: "部分修复", value: "4" },
    { label: "仍存在", value: "1" },
  ],
};

export const findings: Finding[] = [
  {
    id: "ritual-slip",
    number: "01",
    category: "mechanic",
    priority: "P0",
    status: "fixed",
    title: "0 秒铭刻仍可能抄错/串行 —— 已修复",
    summary: "经典模式结算路径已把 slip 概率钉死为 0，上一轮最危险的结果偏差已经关闭。",
    baseline:
      "1.0.3 的附魔应用直接写入目标物品。旧版没有排队铭刻、过载负载或随机串行的结算路径。",
    current:
      "新分支在 completeActiveRitual 内显式识别 classic103Mode，并把 queued step 的 stepSlipProb 置 0；headless fallback 也把 slipChance 置 0。经典模式继续借用 1 tick ritual 作为内部传输，但不再触发 post-1.0.3 的抄错结算。",
    recommendations: [
      "保留这条经典门禁，并补一个针对 `wear_immune` 母本的回归测试，防止并行改动再次把经典路径带回 ritual 风险结算。",
      "在说明文档中明确：经典模式仍复用内部 ritual 容器，但结果语义按 1.0.3 处理，不代表玩家可见存在等待或串行机制。",
    ],
    acceptance:
      "构造高负载免磨损母本，经典模式反复铭刻不发生降阶、杂项或诅咒串行；标准模式同一条件仍遵循配置概率。再验证 headless fallback 路径同样为 0。",
    evidence: [
      evidence("旧版直接施加附魔", "old", `${java}mechanics/enchanting/EnchantmentApplication.java`, "L28-L34"),
      evidence("当前经典即时铭刻仍入队", "current", `${java}mechanics/enchanting/EnchantmentApplication.java`, "L166-L238"),
      evidence("当前 ritual 结算对经典强制 0 概率", "current", `${java}block/ChiseledEnchantingTableBlockEntity.java`, "L351-L436"),
      evidence("当前 headless fallback 也归零", "current", `${java}mechanics/enchanting/EnchantmentApplication.java`, "L242-L256"),
    ],
  },
  {
    id: "epiphany-gate",
    number: "02",
    category: "mechanic",
    priority: "P0",
    status: "fixed",
    title: "零概率顿悟不等于关闭刷新 —— 已修复",
    summary: "经典模式下顿悟从服务端能力层就被禁用了，不再只是“把概率调成 0”。",
    baseline:
      "1.0.3 的 OptionType 只有普通附魔、物品置换、双书合并与单书进修，没有顿悟、刷新或锁定操作。",
    current:
      "新分支把 `epiphanyChance()`、`epiphanyMaxSlots()`、`computeActiveTreasureEpiphanies()` 在经典模式下分别硬返回 `0 / 0 / empty`，`canAffordRerollEpiphany()` 与 `canAffordFreezeEpiphany()` 也直接 `return false`。同时 treasure rules 的 per-shelf / per-tome chance 在 runtime frame 里对经典清零。",
    recommendations: [
      "维持当前多层门禁：规则层、结果层、付费层都拦截，避免未来单点回退。",
      "若保留旧冻结字段以兼容存档，可在文档里说明它们在经典模式下是惰性数据，不提供玩法入口。",
    ],
    acceptance:
      "在至少 32 个普通书架下伪造合法容器 ID 的刷新/锁定包：经典模式 XP、材料、种子与冻结时间均不变；再用数据包把概率设为 100% 验证经典仍不可触发，标准模式照常工作。",
    evidence: [
      evidence("旧版选项类型", "old", `${java}menu/ChiseledEnchantingMenuPayloads.java`, "L35-L39"),
      evidence("runtime frame 对经典清零顿悟增量", "current", `${java}data/ChiseledEnchantingTableData.java`, "L948-L971"),
      evidence("经典模式 epiphanyChance / slots 直接归零", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2226-L2266"),
      evidence("经典模式 active epiphany 直接为空", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2342-L2345"),
      evidence("经典模式 reroll / freeze 直接不可支付", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2485-L2501"),
    ],
  },
  {
    id: "incremental-copy",
    number: "03",
    category: "copy",
    priority: "P0",
    status: "partial",
    title: "“仅补差价”已修，仅剩页签总述一句未分流",
    summary: "行注释、来源浮窗、JEI/REI 均已按经典切换；唯一残留是 tab.inscribe.desc 仍是静态的“自动扣除已付材料与经验”。",
    baseline:
      "1.0.3 的处理器取目标等级的完整材料与 XP 成本，扣除对应经验点；没有逐级补差结算。",
    current:
      "新分支让 `EnchantementListWidget` 只在非经典模式显示 `upgrade_from` 注释，已修掉你点名的“仅补差价”主问题；但 `tab.inscribe.desc` 仍写“升级已有附魔时自动扣除已付材料与经验”，属于经典模式下的静态残留总述。",
    recommendations: [
      "把页签总述改为按当前模式分支显示：经典写“按目标等级完整计价”，标准再保留差额抵扣说明。",
      "检查其他语言同键位是否也同步拆分，避免中文修了、其他语言继续错误。",
    ],
    acceptance:
      "经典模式下附魔 II 升 III：列表不显示“仅补差价”，页签悬停也不再承诺自动抵扣；标准模式仍保留差额说明。",
    evidence: [
      evidence("旧版完整成本与经验扣除", "old", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L412-L439"),
      evidence("当前经典模式不显示 upgrade_from 注释", "current", `${client}gui/EnchantementListWidget.java`, "L1330-L1340"),
      evidence("当前经典模式仍是完整 XP 计价", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2104-L2109"),
      evidence("页签总述仍是静态抵扣说法", "current", lang, "L105-L107"),
      evidence("页签浮窗无经典分支", "current", `${client}gui/ChiseledEnchantingTableScreen.java`, "L1241-L1246"),
    ],
  },
  {
    id: "pricing-source",
    number: "04",
    category: "copy",
    priority: "P0",
    status: "fixed",
    title: "计价来源与盐值选料已统一到服务端一份结果",
    summary: "Round 3 把 1.0.3 的按玩家 UUID 盐值选料（单选项 + 范围数量）原样恢复，handler 扣费与 EnchantCostTablePayload 同步行走同一函数；JEI/REI/行浮窗读取的即是服务端结果。",
    baseline:
      "1.0.3 直接通过目标等级的成本扣经验点；两种物品置换标价分别是 3 级与 1 级，不存在母本 1-3 级量产计价。",
    current:
      "新分支新增 `pricing.classic_1_0_3` 与 `pricing.book_transfer_classic`，行浮窗已按经典模式切换；JEI / REI 附魔类别也改为 full XP 文案，不再强行显示 stored-book 1-3 级。但整体架构仍未把所有界面完全收敛到一份服务端 quote DTO，部分总述仍靠静态语言键推断。",
    recommendations: [
      "保留 classicSaltedItemCosts / classicSaltedResearchCosts 为唯一入口；任何新 UI 不得再自行从 costTables 取首选项。",
      "ConfigurationSafetyTest 已覆盖 Sharpness III 研读 floor=7；建议再补一条“同一 UUID 下 payload 行 == handler 扣费”的等价断言。",
    ],
    acceptance:
      "经典模式下依次悬停已存书附魔、无存书附魔与两项置换：XP 徽章与来源说明一致，且不再出现 1-3 级量产暗示。",
    evidence: [
      evidence("旧版置换 3 / 1 级", "old", `${data}item_transformations.json`, "L1-L24"),
      evidence("当前 XP 徽章已分 classic/full", "current", `${client}compat/jei/EnchantingRecipeCategory.java`, "L85-L100"),
      evidence("当前 REI 也分 classic/full", "current", `${client}compat/rei/ReiEnchantingCategory.java`, "L80-L96"),
      evidence("当前行浮窗有 classic 专用来源键", "current", lang, "L318-L325"),
      evidence("当前行浮窗按 classic 切换来源", "current", `${client}gui/ChiseledEnchantingTableScreen.java`, "L1671-L1761"),
      evidence("handler 经典盐值选料", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L1440-L1455"),
      evidence("同步 payload 走同一盐值函数", "current", `${java}menu/EnchantCostTablePayload.java`, "L213-L290"),
      evidence("研读 XP 经典向下取整", "current", `${java}data/ChiseledEnchantingTableData.java`, "L281-L301"),
    ],
  },
  {
    id: "resonance-text",
    number: "05",
    category: "copy",
    priority: "P1",
    status: "fixed",
    title: "共鸣减免残留提示 —— 已修复",
    summary: "经典模式已在源头把所有相关子上限清零，并且材料浮窗补了 classic 门禁。",
    baseline:
      "1.0.3 有普通书架对附魔等级的 +floor(W/3) 提升，没有书库 XP 共鸣减免体系。",
    current:
      "`applyRuntimeConfig` 在 classic103Mode 下把 wooden/global/base/specific/total 等子上限全部归零；`hoveredCost` 浮窗也增加了 `!isClassic103Mode()` 条件，之前“额外 -15%（共 -0%）”的残留提示已不再成立。",
    recommendations: [
      "维持当前做法：从数据源与文案门禁两层同时约束，避免只靠 UI 隐藏。",
      "后续若引入更多细项提示，也统一以 `discountApplied > 0` 或 classic 门禁驱动。",
    ],
    acceptance:
      "经典模式在满级藏书旁悬停材料、行与 XP 徽章，不出现正数减免承诺；普通模式仍显示真实比例。",
    evidence: [
      evidence("旧版只有书架提级逻辑", "old", `${java}block/ChiseledEnchantingTableBlock.java`, "L153-L203"),
      evidence("当前 classic 时清零全部减免子上限", "current", `${java}data/ChiseledEnchantingTableData.java`, "L855-L915"),
      evidence("当前材料浮窗加 classic 门禁", "current", `${client}gui/ChiseledEnchantingTableScreen.java`, "L1439-L1458"),
    ],
  },
  {
    id: "cost-table",
    number: "06",
    category: "economy",
    priority: "P1",
    status: "fixed",
    title: "完整收费仍用 1.1.0 价格表 —— 已修复",
    summary: "经典运行帧现在明确装载 `enchantment_costs_classic_1_0_3.json`。",
    baseline:
      "1.0.3 的 enchantment_costs.json：I 级基数 5、常规满级 25、稀有单级 35，经验修补 I 的覆盖值为 35；材料还使用不同附魔的多选方案。",
    current:
      "新分支在 classic103Mode 下把 `frameCostTables` 切换到 bundled `enchantment_costs_classic_1_0_3.json`，配置测试也新增了对 Mending I = 35 与 common max = 25 的断言。",
    recommendations: [
      "保留当前经典专用成本表做法，并为至少一种第三方 enchantment 再补覆盖测试，验证“旧过滤 + 新安全钳制”组合不引入越级问题。",
      "在报告或 Wiki 中明确这属于“经典数据集切换”，和保留的 26.1.2 网络/存档修复是两回事。",
    ],
    acceptance:
      "对比经验修补 I、保护 IV 与一种第三方附魔的报价：经典模式与 1.0.3 标签一致；标准模式仍保持现价。",
    evidence: [
      evidence("1.0.3 XP 基数与覆盖", "old", `${data}enchantment_costs.json`, "L1-L37"),
      evidence("当前 classic frame 切换旧成本表", "current", `${java}data/ChiseledEnchantingTableData.java`, "L918-L938"),
      evidence("当前回归测试断言旧价格", "current", `src/test/java/chiseled_enchanting_table/ConfigurationSafetyTest.java`, "L124-L155"),
    ],
  },
  {
    id: "book-upgrades",
    number: "07",
    category: "economy",
    priority: "P1",
    status: "fixed",
    title: "升书材料规则未回退 —— 已修复",
    summary: "经典运行帧已改为读取 `book_upgrades_classic_1_0_3.json`，不再沿用现行触媒曲线。",
    baseline:
      "1.0.3 的 book_upgrades.json：双书 XP 倍率 1.0、单书 XP 倍率 0.5、单书材料倍率 0.5，且为锋利等魔咒指定了主题材料。",
    current:
      "新分支在 classic103Mode 下先解析 `book_upgrades_classic_1_0_3.json` 再组装 BookUpgradeRules；测试也补了对 classic frame XP 和 transformation 数据集的断言。多词条双书合并仍保留当前“按所有实际升阶词条收费”的反漏洞修复，这属于刻意不回退。",
    recommendations: [
      "把“保留反套利修复”作为经典模式的明示偏差列在文档里，避免用户把该修复再当 bug 报回。",
      "若后续补严格经典资源包，也无需回退这类经济漏洞；只需在“保留修复”章节说明。",
    ],
    acceptance:
      "单词条锋利 II→III 单书进修与双书合并，对照旧材料和倍率；多词条双书则验证保留逐条计费修复。",
    caveat:
      "旧版多词条合并仅按点击词条收费，现行逐条计费属于应保留的经济修复，不能为追求字面一致而恢复漏洞。",
    evidence: [
      evidence("旧版升书规则", "old", `${data}book_upgrades.json`, "L1-L16"),
      evidence("当前 classic frame 切换旧升书表", "current", `${java}data/ChiseledEnchantingTableData.java`, "L918-L935"),
      evidence("当前多词条合并收费修复仍保留", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2004-L2033"),
      evidence("当前测试覆盖 classic 升书语义", "current", `src/test/java/chiseled_enchanting_table/ConfigurationSafetyTest.java`, "L124-L153"),
    ],
  },
  {
    id: "apple-emerald",
    number: "08",
    category: "economy",
    priority: "P1",
    status: "fixed",
    title: "金苹果 2-5 绿宝石范围报价 —— 已修复",
    summary: "经典转化成本现在通过 `classicTransformationCosts()` 读取规则，不再硬编码 2。",
    baseline:
      "1.0.3 金苹果置换是 3 级 + 8 金块 + 2-5 绿宝石的可变附加成本；经验之瓶是 1 级 + 6 青金石 + 2 紫水晶碎片。",
    current:
      "新分支删除了经典下硬编码 x2 绿宝石的做法，改为从 classic transformation 表按玩家 salt 解析 bundle；注释里也直接点名修复了 ranged emerald cost。",
    recommendations: [
      "保留当前 rule-driven 读取，不再在 handler 内散写经典常量。",
      "如要展示“可变报价”语义，可在报告或 Wiki 里补一句说明它仍然是每玩家稳定选价，而非每次随机波动。",
    ],
    acceptance:
      "使用多个玩家 UUID 验证金苹果置换可按旧版规则选价，任一玩家的预览与实扣一致；附魔之瓶仍为旧值。",
    evidence: [
      evidence("旧版 2-5 绿宝石", "old", `${data}item_transformations.json`, "L2-L24"),
      evidence("当前经典 bundle 读取 rule 而非硬编码", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L1428-L1438"),
      evidence("当前 classicTransformationCosts 入口", "current", `${java}data/ChiseledEnchantingTableData.java`, "L552-L558"),
    ],
  },
  {
    id: "unlock-filter",
    number: "09",
    category: "mechanic",
    priority: "P1",
    status: "fixed",
    title: "第三方双标签默认解锁过滤 —— 已修复",
    summary: "经典模式下 `defaultEnchantments()` 已不再先做 treasure / epiphany_exclusive 排除。",
    baseline:
      "1.0.3 默认表显式列出 7 种宝藏附魔，再展开 #minecraft:in_enchanting_table；展开逻辑没有宝藏或 epiphany_exclusive 排除条件。",
    current:
      "新分支在 `defaultEnchantments(lookup)` 里显式分支：经典模式使用空排除集合，并跳过 defaultExcludedTags 的展开过滤。这样第三方同时位于 `in_enchanting_table` 与 treasure / epiphany_exclusive 的附魔也能按旧逻辑默认解锁。",
    recommendations: [
      "保留现有实现，并补一个真正的双标签测试数据包样例，避免以后又退回‘先过滤后补 7 个 ID’的简化写法。",
      "文档里说明：经典模式恢复旧 unlock 口径，但仍保留当前的 maxLevel 安全钳制。",
    ],
    acceptance:
      "原版七种与旧版一致；双标签自定义附魔在经典模式按旧版标签展开，在标准模式仍遵循新排除规则。",
    evidence: [
      evidence("旧版七种与标签展开", "old", `${data}default_enchantments.json`, "L3-L14"),
      evidence("当前经典模式不做排除过滤", "current", `${java}data/ChiseledEnchantingTableData.java`, "L175-L220"),
      evidence("当前实现说明修复双标签问题", "current", `${java}data/ChiseledEnchantingTableData.java`, "L176-L183"),
    ],
  },
  {
    id: "world-loot",
    number: "10",
    category: "economy",
    priority: "P1",
    status: "fixed",
    title: "野生雕纹书架附魔书率 0.03 —— 已恢复",
    summary: "经典预设已经把 `bookshelfEnchantedProb` 明确写回 0.03，配置测试也覆盖了它。",
    baseline:
      "1.0.3 的 bookshelf_book_pool.json 设置 enchanted_book_probability = 0.03，书本数量范围 3-5。",
    current:
      "新分支在 classic preset applyTo 和 classic103Mode standalone build 语义测试里都恢复了 0.03；worldgen 仍受 `NEW_GENERATION` 生效域约束，只影响以后生成的新结构。",
    recommendations: [
      "维持当前数值恢复，并在界面继续强调它只影响未来新生成结构。",
      "若将来开放严格经典资源包，可考虑同时比对 loot weight 细节；当前主要偏差已收敛。",
    ],
    acceptance:
      "比较新生成结构的配置值及抽样分布；已生成雕纹书架不被追溯改写，切回标准恢复 0.12。",
    evidence: [
      evidence("1.0.3 概率 0.03", "old", `${data}bookshelf_book_pool.json`, "L4-L15"),
      evidence("当前 classic preset 恢复 0.03", "current", `${java}config/ModRuntimeConfig.java`, "L228-L231"),
      evidence("当前 classic flag 单独测试 0.03", "current", `src/test/java/chiseled_enchanting_table/ConfigurationSafetyTest.java`, "L95-L122"),
      evidence("世界生成配置属 NEW_GENERATION", "current", `${java}config/ConfigCatalog.java`, "L842-L864"),
    ],
  },
  {
    id: "recipe-scope",
    number: "11",
    category: "content",
    priority: "P1",
    status: "partial",
    title: "静态配方边界已说明，但配方本体仍未切换",
    summary: "这不再是“未说明的偏差”，而是“已说明但仍保留的边界”。",
    baseline:
      "旧版纂刻附魔台配方中的 D 是 diamond_block，O 是 obsidian；该标签下没有秘法凝晶、退魔砂或秘典合成配方。",
    current:
      "运行时预设仍不会热切换 recipe JSON，当前配方还是 `diamond + crying_obsidian` 且额外新物品配方继续加载；但经典预设悬停说明已补充“合成配方与新物品内容仍沿用 1.1.0，配方是静态数据，无法随此开关切换”。因此现在属于已告知边界，而非无提示偏差。",
    recommendations: [
      "如果目标只是‘玩法规则经典’，当前说明已够；若目标升级为‘内容也经典’，才需要另做内建资源包或条件化 recipe 集。",
      "报告页面应把这一项从 P0/误导类降级为‘边界说明’，避免与前面真正影响结果的服务端问题混淆。",
    ],
    acceptance:
      "分别检查预设保存前后、/reload 后的配方书与提示语：玩家能被明确告知这不是随开关热切换的内容层经典。",
    evidence: [
      evidence("旧版附魔台配方", "old", `${recipe}chiseled_enchanting_table.json`, "L1-L17"),
      evidence("现行附魔台配方", "current", `${recipe}chiseled_enchanting_table.json`, "L1-L17"),
      evidence("现行额外秘法凝晶配方", "current", `${recipe}arcane_catalyst.json`, "L1-L19"),
      evidence("经典预设 inert note 已写明静态配方边界", "current", lang, "L760-L764"),
    ],
  },
  {
    id: "viewer-manual",
    number: "12",
    category: "copy",
    priority: "P1",
    status: "fixed",
    title: "秘典、JEI、REI 均已挂经典提示",
    summary: "经典提示现已覆盖秘典除首页外全部章节；JEI 站点/书架信息页有 classic 变体，模式切换时客户端提示信息页需重进世界刷新。",
    baseline:
      "1.0.3 没有九章节《纂刻秘典》或新版本的 1-3 级母本经济叙事；JEI/REI 当时只展示旧附魔与旧成本。",
    current:
      "JEI / REI 的 XP 行和 tooltip 已按经典模式显示 full XP，并去掉 bookshelf stored-book 1-3 级说明。Grimoire 则只在首页/导航加入 `classic_notice`，但第 4、5、6 章正文仍继续讲共鸣、母本耐久与顿悟。也就是说，外部查看器基本适配了，手册正文尚未分流。",
    recommendations: [
      "当前是“保留原章节 + 叠加经典说明”，可接受；若追求更干净，可在经典模式下把 ch4–ch6 正文折叠为一段。",
      "JEI/REI 信息页注册一次的限制已用 msg.compat_info_refresh 明示，属于 26.1.2 查看器 API 边界，无需再追。",
    ],
    acceptance:
      "经典模式打开秘典时，不会在正文步骤里继续教授顿悟/母本磨损/共鸣减免作为当前可用机制；JEI/REI 仍保持正确。",
    evidence: [
      evidence("旧版中文文案范围", "old", lang, "L1-L16"),
      evidence("JEI 当前已切 classic/full XP", "current", `${client}compat/jei/EnchantingRecipeCategory.java`, "L85-L146"),
      evidence("REI 当前已切 classic/full XP", "current", `${client}compat/rei/ReiEnchantingCategory.java`, "L80-L114"),
      evidence("Grimoire 非首页全部章节挂经典提示", "current", `${client}gui/grimoire/ArcaneGrimoireScreen.java`, "L1122-L1128"),
      evidence("JEI 站点信息经典变体", "current", `${client}compat/jei/ChiseledEnchantingJeiPlugin.java`, "L125-L138"),
      evidence("模式切换提示 JEI/REI 需重进", "current", `${client}ChiseledEnchantingTableClient.java`, "L245-L260"),
      evidence("经典提示中文文案", "current", lang, "L187-L188"),
    ],
  },
  {
    id: "config-links",
    number: "13",
    category: "mechanic",
    priority: "P1",
    status: "fixed",
    title: "配置联动：锁定列表补齐，并新增“经典合并页”",
    summary: "CLASSIC_LOCKED_KEYS 已扩到全部经典相关键（含 tier/early_unlock/regen/refund/strip/purge 子项）；经典下在普通分类里灰显并给出原因，在新“1.0.3 经典”合并页可集中编辑。",
    baseline:
      "1.0.3 不存在顿悟、共鸣折扣或退魔页设置，不会形成这些配置值与有效行为的冲突。",
    current:
      "新分支引入 `CLASSIC_LOCKED_KEYS`，在 `evaluate()` 里对 classic no-op 选项统一返回 reason.classic_1_0_3，已明显改善上一轮“仍可编辑但不生效”的问题。剩余不足主要是它靠枚举列表维护，不是所有 runtime 强制逻辑都来自同一声明源；因此长期仍有漂移风险。",
    recommendations: [
      "现在经典值可编辑，锁定列表与 applyClassic103Overrides 仍是两份清单；建议从同一常量派生，防止再漂移。",
      "状态栏对“经典但已改值”的表达见问题 14。",
    ],
    acceptance:
      "经典模式下修改顿悟概率、退魔开关或共鸣上限时，面板给出 classic_1_0_3 原因；退出经典模式后恢复可编辑且保留草稿值。",
    evidence: [
      evidence("旧版仅有四种操作类型", "old", `${java}menu/ChiseledEnchantingMenuPayloads.java`, "L29-L40"),
      evidence("当前 evaluate 增加 classic 锁定原因", "current", `${java}config/ConfigCatalog.java`, "L284-L299"),
      evidence("当前 classic 锁定字段集合（已扩充）", "current", `${java}config/ConfigCatalog.java`, "L345-L380"),
      evidence("经典合并页", "current", `${client}gui/config/ChiseledEnchantingConfigScreen.java`, "L204-L222"),
      evidence("经典页分类入口", "current", `${client}gui/config/ChiseledEnchantingConfigScreen.java`, "L415-L436"),
      evidence("中文提示键已新增", "current", lang, "L524-L524"),
    ],
  },
  {
    id: "policy-truth",
    number: "14",
    category: "content",
    priority: "P2",
    status: "partial",
    title: "预设已更名“1.0.3 玩法规则”，但短名、状态栏、载入提示仍写“原味/原汁原味”",
    summary: "desc / inert_note 已诚实列出保留差异；可同一按钮的 short 仍是「1.0.3 原味」，applied_notice 和 msg.classic_1_0_3_active 仍是「原汁原味」。且经典值变为可编辑后，Preset.matches() 对“经典但改过值”返回 false，状态栏却继续显示经典激活。",
    baseline:
      "1.0.3 以数据包 JSON 和服务器权威计价为基础，不存在“预设匹配”这个对外承诺；移植时的世界生成死锁和成本同步修复无需回退。",
    current:
      "`applyTo()` 仍保留 `overrideDatapacks`；`Preset.matches()` 仍只比较草稿。外部数据包与 lock policy 依然能覆盖 classic 预设的一部分有效规则，只是本轮分支已经在提示文案里补充了许多边界说明。这个问题没有坏结果 bug，但它仍影响‘原味’一词的精确性。",
    recommendations: [
      "把 preset.classic_1_0_3.short、applied_notice、msg.classic_1_0_3_active 三个键与 title/desc 统一为“1.0.3 玩法规则”，11 种语言同步。",
      "状态栏区分两种态：`classic103Mode && matches()` 显示“1.0.3 规则”；`classic103Mode && !matches()` 显示“基于 1.0.3 的自定义规则”，这正是审计文档自己声明的语义。",
    ],
    acceptance:
      "服务端锁定配置与外部数据包覆盖各做一轮；玩家看到的状态、服务器报价、客户端同步值一致，且知道哪些是经典草稿、哪些是实际生效。",
    evidence: [
      evidence("旧版 64 堆叠尚为 TODO", "old", `${java}ChiseledEnchantingTable.java`, "L20-L28"),
      evidence("经典改为可编辑档案（不再构造期强制）", "current", `${java}config/ModRuntimeConfig.java`, "L1148-L1156"),
      evidence("build() 不再强制经典值", "current", `${java}config/ModRuntimeConfig.java`, "L1365-L1368"),
      evidence("短名/载入提示/状态栏仍写原味", "current", lang, "L764-L768"),
      evidence("状态栏只看 classic103Mode 不看 matches", "current", `${client}gui/config/ChiseledEnchantingConfigScreen.java`, "L846-L848"),
    ],
  },
  {
    id: "lock-bypass-side",
    number: "15",
    category: "mechanic",
    priority: "P1",
    status: "open",
    title: "新增的经典锁书绕过门禁读的是本地文件，而非服务端有效配置",
    summary: "R2-11 让经典模式忽略母本锁定，但 EnchantmentFinder 与 MasterTomeWear 用 ModRuntimeConfig.get()（磁盘本地值），与 028a2d6 专门引入的 forSide()/runtimeConfiguration() 隔离口径不一致。",
    baseline: "1.0.3 没有母本锁定，忽略锁定本身符合旧版；问题在读取来源，不在语义。",
    current: "EnchantmentFinder.java L26 与 MasterTomeWear.java L535 调用 ModRuntimeConfig.get().classic103Mode()。get() 返回 localInstance（配置文件），而数据层其余经典门禁都用 runtimeConfiguration()（已解析的服务端有效帧）或 forSide()。当服务端由数据包/策略或远端 S2C 决定经典状态、而本地文件不同步时（专用服、局域网客机、datapack 锁定 classic 键），两处会与其他门禁判断不一致：可能在非经典下跳过锁定，或在经典下仍尊重锁定。",
    recommendations: [
      "两处改为 ChiseledEnchantingTableData.runtimeConfiguration().classic103Mode()（服务端线程）或 ModRuntimeConfig.forSide(level.isClientSide())，与同文件其余门禁对齐。",
      "补一个 PackPolicy 锁定 classic_1_0_3_mode 且本地文件相反的测试，断言候选母本收集与解锁集合一致。",
    ],
    acceptance: "本地 json classic=false、服务端策略 classic=true：已锁母本应可被选为候选；反向亦然。局域网客机不受本地文件影响。",
    evidence: [
      evidence("旧版 EnchantmentFinder 无锁定概念", "old", `${java}utils/EnchantmentFinder.java`, "L1-L25"),
      evidence("EnchantmentFinder 用 get()", "current", `${java}utils/EnchantmentFinder.java`, "L24-L30"),
      evidence("MasterTomeWear 用 get()", "current", `${java}mechanics/resonance/MasterTomeWear.java`, "L531-L538"),
      evidence("数据层其余门禁用 runtimeConfiguration()", "current", `${java}data/ChiseledEnchantingTableData.java`, "L183-L190"),
      evidence("get() 只读本地实例", "current", `${java}config/ModRuntimeConfig.java`, "L570-L580"),
    ],
  },
  {
    id: "profile-drift",
    number: "16",
    category: "content",
    priority: "P2",
    status: "partial",
    title: "经典值可编辑后，哪些是“规则”哪些是“偏好”需要一张明确清单",
    summary: "Round 3 的设计是合理的：机制门禁挂旗标，数值可调。但现在同一个“经典”页里既有真正被旗标覆盖、改了也无效的数值（如顿悟概率、XP 倍率），也有改了就生效的数值（扫描半径、书架阶梯），面板没有区分。",
    baseline: "1.0.3 没有配置系统；任何“可编辑的经典”都是移植版的新概念，需自行定义边界。",
    current: "runtime frame 在经典下忽略 cfg 的 epiphanyBase/Max、bookCombine/ResearchXpMultiplier、减免上限，改用旗标常量或经典 JSON；但 horizontalScanRadius、directGatesEnabled、tomeConsumptionMode 等仍直接从 cfg 读。经典合并页把两类放在一起并都标为“均可修改”。",
    recommendations: [
      "在经典合并页按“旗标锁死（改动无效）/ 可调偏好”分两组展示，前者沿用 reason.classic_1_0_3 灰显，不要在经典页解锁。",
      "或者更简单：把经典下被旗标覆盖的键从 applyClassic103Overrides 和经典页中移除，只保留真正可调的键。",
    ],
    acceptance: "经典页中修改顿悟基础概率/升书倍率后保存，服务器有效帧不变且面板显示为无效；修改扫描半径后有效帧随之改变。",
    evidence: [
      evidence("旧版无配置系统", "old", `${java}ChiseledEnchantingTable.java`, "L20-L32"),
      evidence("经典下 cfg 倍率/概率被旗标覆盖", "current", `${java}data/ChiseledEnchantingTableData.java`, "L955-L992"),
      evidence("经典页宣称全部可修改", "current", lang, "L383-L384"),
      evidence("经典页解锁锁定行", "current", `${client}gui/config/ChiseledEnchantingConfigScreen.java`, "L215-L222"),
    ],
  },
];

export const categoryLabels: Record<Category, string> = {
  mechanic: "机制与门禁",
  economy: "数据与经济",
  copy: "界面与文案",
  content: "内容与边界",
};

export const statusLabels: Record<Status, string> = {
  fixed: "已修复",
  partial: "部分修复",
  open: "仍存在",
};

export const statusDescriptions: Record<Status, string> = {
  fixed: "与上一轮对比，分支已给出明确代码修复或完整门禁。",
  partial: "核心结果已基本对齐，但静态说明、入口说明或统一架构仍有残留。",
  open: "仍建议继续跟进，避免“预设名”和“实际生效”之间继续混淆。",
};

export const auditApi = [
  {
    title: "网络与服务端校验",
    code: "PayloadTypeRegistry.serverboundPlay()",
    text: "26.1.2 API 提供服务端收包注册与 canSend 能力判断。新分支已经把顿悟刷新/锁定的 classic 门禁收进 handler，而不再只靠按钮隐藏。现有协议仍带 revision_16，新增线协议字段时要考虑版本升级。",
    source: sourceUrl("current", `${java}menu/EnchantingNetworking.java`, "L82-L117"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/networking/v1/ServerPlayNetworking.html",
  },
  {
    title: "资源重载与静态数据边界",
    code: "PackType.SERVER_DATA / ResourceConditions",
    text: "成本、升书与置换表可随 runtime frame 切到经典数据集，但 recipe JSON 仍属静态资源。新分支已在 preset inert note 明说这一点，这也是当前最合理的 26.1.2 口径。",
    source: sourceUrl("current", `${java}data/ChiseledEnchantingTableData.java`, "L152-L155"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/resource/conditions/v1/ResourceConditions.html",
  },
  {
    title: "附魔书堆叠上限",
    code: "DefaultItemComponentEvents.MODIFY",
    text: "当前继续通过 26.1.2 的默认组件事件在启动期设置 MAX_STACK_SIZE。经典预设恢复 64 没问题，但仍然不是“保存后立刻热切换”的字段。",
    source: sourceUrl("current", `${java}ChiseledEnchantingTable.java`, "L38-L50"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/item/v1/DefaultItemComponentEvents.html",
  },
  {
    title: "配置生效与客户端同步",
    code: "RuntimeFrame + S2C cost snapshot",
    text: "这轮分支的关键进步是：经典价格表、经典升书表与经典转化表都进入了 RuntimeFrame，而不是只改 UI 提示。剩下的主要是状态表达和内容层切换边界。",
    source: sourceUrl("current", `${java}config/ModConfigNetworking.java`, "L188-L213"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/networking/v1/PayloadTypeRegistry.html",
  },
];

export const testCases = [
  { scenario: "高负载免磨损母本", expected: "经典无串行 / 标准仍按概率结算", layer: "服务端结算" },
  { scenario: "32+ 普通书架，直接发送刷新包", expected: "经典不扣费、不改种子和冻结状态", layer: "网络门禁" },
  { scenario: "已有附魔 II 升 III", expected: "经典无“补差价”承诺，且按完整费用结算", layer: "经济 + UI" },
  { scenario: "经验修补 I / 金苹果置换", expected: "按 1.0.3 旧数据和玩家盐值报价", layer: "数据表" },
  { scenario: "第三方宝藏附魔双标签", expected: "经典按旧标签展开，标准保留排除", layer: "数据包兼容" },
  { scenario: "切换预设、/reload、重启", expected: "动态规则、静态资源、堆叠分别提示生效时机", layer: "生命周期" },
  { scenario: "经典模式阅读秘典与 JEI/REI", expected: "每章可见经典提示；JEI/REI 站点信息为经典变体", layer: "文案与外显说明" },
  { scenario: "本地 json 与服务端策略的 classic 不一致", expected: "锁书绕过与其余门禁判断一致（问题 15）", layer: "多端同步" },
  { scenario: "经典页修改顿悟概率后保存", expected: "有效帧不变，面板不误报为生效（问题 16）", layer: "配置真实性" },
];