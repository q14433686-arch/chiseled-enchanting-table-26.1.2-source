/**
 * “1.0.3 规则”单开关背后的行为原子拆解。
 * 每个原子 = 源码里一处（或一组等价的）classic103Mode 门禁；
 * 归属分类 = 拆分后该原子应该出现在配置页的哪个领域。
 */
export type AtomKind = "toggle" | "enum";

export type Atom = {
  id: string;
  domain: Domain;
  section: string;
  label: string;
  kind: AtomKind;
  options?: string[];
  legacy: string;
  current: string;
  what: string;
  gates: string[];
  risk?: string;
};

export type Domain = "unlock" | "pricing" | "tomes" | "epiphany" | "cleanse" | "world" | "ux";

export const domainMeta: Record<Domain, { title: string; sub: string; accent: string }> = {
  unlock: { title: "解锁与书架", sub: "哪些附魔能选、等级怎么算", accent: "#287385" },
  pricing: { title: "经验与材料计价", sub: "扣多少、怎么扣、是否抵扣", accent: "#8C6220" },
  tomes: { title: "模板书", sub: "耐久、锁、回充与谱系", accent: "#6B3FA0" },
  epiphany: { title: "宝藏顿悟", sub: "随机宝藏、锁定与刷新", accent: "#9B4A7C" },
  cleanse: { title: "退魔与置换", sub: "洗练、置换、残卷与村民", accent: "#237A5B" },
  world: { title: "世界与原版联动", sub: "生成、村民、铁砧、原版台", accent: "#87443A" },
  ux: { title: "界面与说明", sub: "页签、面板、秘典、查看器", accent: "#4D6258" },
};

export const atoms: Atom[] = [
  {
    id: "shelf_boost_model",
    domain: "unlock", section: "等级来源",
    label: "普通书架提级模型", kind: "enum",
    options: ["经典 +⌊W/3⌋（单一最高档）", "现行 直附曲线（1..上限全部开放）"],
    legacy: "经典 +⌊W/3⌋", current: "现行曲线",
    what: "决定默认魔咒与雕纹藏书如何随普通书架数量提升，以及是否同时开放更低等级。",
    gates: ["block/ChiseledEnchantingTableBlock.java:402-446"],
  },
  {
    id: "default_unlock_filter",
    domain: "unlock", section: "等级来源",
    label: "默认解锁排除规则", kind: "enum",
    options: ["经典 不排除（含宝藏/诅咒/顿悟专属）", "现行 排除宝藏、诅咒、顿悟专属"],
    legacy: "不排除", current: "排除",
    what: "是否把 treasure / curse / epiphany_exclusive 标签从 in_enchanting_table 默认展开中剔除。",
    gates: ["data/ChiseledEnchantingTableData.java:185-192"],
  },
  {
    id: "direct_tier_upgrade",
    domain: "unlock", section: "升级路径",
    label: "已附魔装备的直升阶梯", kind: "toggle",
    legacy: "关", current: "开",
    what: "装备已带 ≥1 级时，是否允许按书架曲线直接升到更高档（1.0.3 只能升到当前解锁的那一档）。",
    gates: ["mechanics/enchanting/EnchantmentApplication.java:74", "gui/EnchantementListWidget.java:640", "menu/…ScreenHandler.java:1946"],
  },
  {
    id: "incremental_credit",
    domain: "pricing", section: "计价方式",
    label: "升级补差价抵扣", kind: "toggle",
    legacy: "关（全额）", current: "开（抵扣已付）",
    what: "升级已有附魔时是否只收目标与现有等级的材料/经验差额。",
    gates: ["menu/…ScreenHandler.java:1667", "menu/…ScreenHandler.java:2144"],
  },
  {
    id: "xp_mode",
    domain: "pricing", section: "计价方式",
    label: "经验结算模式", kind: "enum",
    options: ["经典 全额等级点数", "现行 双模式（藏书 1–3 级 / 无藏书全额）"],
    legacy: "全额", current: "双模式",
    what: "是否对已存母本的附魔启用 1–3 级量产扣法。",
    gates: ["menu/…ScreenHandler.java:2144"],
  },
  {
    id: "material_selection",
    domain: "pricing", section: "材料来源",
    label: "材料选取方式", kind: "enum",
    options: ["经典 按玩家盐值选 1 种、区间计数", "现行 全部选项可选、取中点"],
    legacy: "盐值", current: "全部可选",
    what: "每位玩家看到一种稳定材料（1.0.3），还是列出全部可接受材料。",
    gates: ["menu/…ScreenHandler.java:1442-1463", "menu/EnchantCostTablePayload.java:213-285"],
  },
  {
    id: "cost_table",
    domain: "pricing", section: "材料来源",
    label: "价格表数据集", kind: "enum",
    options: ["经典 1.0.3 表（可数据包覆盖）", "现行 1.1.0 表"],
    legacy: "1.0.3 表", current: "1.1.0 表",
    what: "附魔成本 / 升书 / 置换三张表走哪一套；经典表允许同路径数据包替换。",
    gates: ["data/ChiseledEnchantingTableData.java:948-1039"],
  },
  {
    id: "research_rounding",
    domain: "pricing", section: "材料来源",
    label: "研读经验取整", kind: "enum",
    options: ["经典 向下取整", "现行 四舍五入"],
    legacy: "floor", current: "round",
    what: "单书研读的 XP 倍率结果如何取整（锋利 III：7 vs 8）。",
    gates: ["data/ChiseledEnchantingTableData.java:285"],
  },
  {
    id: "library_discount",
    domain: "pricing", section: "减免",
    label: "书库经验减免", kind: "toggle",
    legacy: "关", current: "开",
    what: "普通书架 / 雕纹藏书 / 同种藏书三层减免是否参与计算（关时所有子上限归零）。",
    gates: ["data/ChiseledEnchantingTableData.java:905-916"],
  },
  {
    id: "tome_wear_system",
    domain: "tomes", section: "耐久",
    label: "模板书耐久与回充", kind: "toggle",
    legacy: "关（永不磨损）", current: "开",
    what: "等价于消耗模式 ≠ KEEP 且回充开启；关时野生书磨损、代际谱系、免磨损豁免一并失效。",
    gates: ["data/ChiseledEnchantingTableData.java:964", "mechanics/enchanting/EnchantmentApplication.java:181"],
    risk: "与现有 tome_consumption_mode / tome_regen_enabled 重叠，拆分时应合并为同一控件。",
  },
  {
    id: "tome_locks",
    domain: "tomes", section: "保护",
    label: "模板书保护锁", kind: "toggle",
    legacy: "关（忽略锁）", current: "开",
    what: "锁定的母本是否被扫描与计价忽略；关时即便物品带锁也当作普通母本。",
    gates: ["utils/EnchantmentFinder.java:26", "mechanics/resonance/MasterTomeWear.java:535"],
  },
  {
    id: "provenance",
    domain: "tomes", section: "溯源",
    label: "附魔溯源记录", kind: "toggle",
    legacy: "关（清空）", current: "开",
    what: "是否在物品上记录本台铭刻的来源与代际；关闭后退魔返还与墨污失去依据。",
    gates: ["mechanics/enchanting/EnchantmentApplication.java:283", "mechanics/enchanting/BookUpgradeApplication.java:75,139"],
  },
  {
    id: "ritual_queue",
    domain: "tomes", section: "仪式",
    label: "深层铭刻等待与抄错", kind: "toggle",
    legacy: "关（即时、确定）", current: "开",
    what: "是否启用排队等待、过载母本抄错与串行补偿。",
    gates: ["mechanics/enchanting/EnchantmentApplication.java:167,245", "block/ChiseledEnchantingTableBlockEntity.java:356,424"],
  },
  {
    id: "epiphany_system",
    domain: "epiphany", section: "总开关",
    label: "宝藏顿悟", kind: "toggle",
    legacy: "关", current: "开",
    what: "关时：不抽取、不推进种子、不可锁定/刷新、面板隐藏；其余顿悟数值项随之灰显。",
    gates: ["menu/…ScreenHandler.java:445,2251,2284,2363,2506,2514", "data/ChiseledEnchantingTableData.java:985-999"],
  },
  {
    id: "cleanse_system",
    domain: "cleanse", section: "退魔",
    label: "退魔与洗练页", kind: "toggle",
    legacy: "关", current: "开",
    what: "等价于 disenchant_enabled；关时页签隐藏、服务端拒绝退魔类操作。",
    gates: ["menu/…ScreenHandler.java:1579", "data/ChiseledEnchantingTableData.java:1027"],
    risk: "与现有 disenchant_enabled 完全重叠，应直接复用而非新增。",
  },
  {
    id: "transformation_set",
    domain: "cleanse", section: "置换",
    label: "物品置换集合", kind: "enum",
    options: ["经典 仅金苹果 / 经验瓶", "现行 全部 6 种 + 探索解锁"],
    legacy: "2 种", current: "6 种",
    what: "置换表走经典 2 项还是现行 6 项；前者不参与 require_prior_discovery。",
    gates: ["data/ChiseledEnchantingTableData.java:1039", "menu/ChiseledEnchantingMenuPayloads.java:470-496"],
  },
  {
    id: "drained_book_result",
    domain: "cleanse", section: "残卷",
    label: "榨干书本的返还物", kind: "enum",
    options: ["经典 普通书", "现行 褪魔残卷"],
    legacy: "普通书", current: "褪魔残卷",
    what: "合书 / 转移后空掉的源书变成什么；连带决定残卷经济是否成立。",
    gates: ["mechanics/enchanting/EnchantmentApplication.java:373", "mechanics/enchanting/BookUpgradeApplication.java:96"],
  },
  {
    id: "tome_page",
    domain: "cleanse", section: "残卷",
    label: "「纂刻的书」页与残卷献祭", kind: "toggle",
    legacy: "关", current: "开",
    what: "是否开放书页、残卷献祭解锁与提前解锁；关时服务端拒绝 TomePageAction。",
    gates: ["menu/…ScreenHandler.java:540,554,660"],
  },
  {
    id: "librarian_offers",
    domain: "world", section: "村民",
    label: "图书管理员残卷交易", kind: "toggle",
    legacy: "关", current: "开",
    what: "是否向图书管理员注入残卷回收 / 修复 / 重绘交易。",
    gates: ["mechanics/loot/DepletedTomeWorldMechanics.java:565"],
  },
  {
    id: "classic_presentation",
    domain: "ux", section: "说明口径",
    label: "界面与说明走经典口径", kind: "toggle",
    legacy: "开", current: "关",
    what: "页签 / 面板 / 来源文案 / 秘典提示 / JEI·REI 的经典分支。建议由上述原子推导，而不是独立开关。",
    gates: ["gui/ChiseledEnchantingTableScreen.java（16 处）", "gui/grimoire/ArcaneGrimoireScreen.java:1122", "compat/jei|rei（11 处）"],
    risk: "派生项：当其它原子全部为经典值时自动为开；否则按每个原子各自切换对应文案。",
  },
];

export const designPrinciples = [
  "开关 ≠ 预设：`classic_1_0_3_mode` 退化为「规则档案」按钮，点一下把 20 个原子写成 1.0.3 值；之后任何原子都可单独改，状态条显示「基于 1.0.3，已偏离 N 项」。",
  "原子归领域：每个原子放到它天然所属的分类里（解锁 / 计价 / 模板书 / 顿悟 / 退魔置换 / 世界），不再堆在一张 57 行的经典页。",
  "经典页改为「规则溯源」视图：同样 20 个原子，但按 1.0.3 ↔ 现行 两列并排，一眼看出哪些偏离；支持「全部切回 1.0.3」「全部切回现行」「仅同步本领域」。",
  "重叠项复用：tome_wear_system / cleanse_system / epiphany_system 直接映射到现有 tome_consumption_mode、disenchant_enabled、epiphany_* 父开关，不新增重复键。",
  "派生而非独立：界面口径（文案、JEI/REI、秘典提示）跟随所属原子推导，避免出现“机制已改、说明没改”的旧问题。",
  "每行三值：默认 / 已保存 / 当前生效 + 来源徽章（默认·配置·数据包·锁定·需重启）；经典档案值在行内以淡色小标「1.0.3: ×」常驻。",
  "服务端仍以原子为门禁：所有 handler / runtime frame 检查改为读取具体原子（如 `rules.incrementalCredit()`），`classic103Mode` 不再出现在机制代码中。",
];
