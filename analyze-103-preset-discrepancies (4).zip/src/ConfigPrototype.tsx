import { ArrowLeftRight, Lock, RotateCcw, Search as SearchIcon } from "lucide-react";
import { useMemo, useState } from "react";
import { atoms, domainMeta, type Atom, type Domain } from "./ruleAtoms";

type View = Domain | "trace";
type Values = Record<string, 0 | 1>; // 0 = legacy, 1 = current

const legacyValues: Values = Object.fromEntries(atoms.map((a) => [a.id, 0 as const]));
const currentValues: Values = Object.fromEntries(atoms.map((a) => [a.id, 1 as const]));

const domains: Domain[] = ["unlock", "pricing", "tomes", "epiphany", "cleanse", "world", "ux"];

function valueLabel(a: Atom, v: 0 | 1) {
  if (a.kind === "enum" && a.options) return a.options[v];
  return v === 0 ? a.legacy : a.current;
}

export function ConfigPrototype() {
  const [values, setValues] = useState<Values>(legacyValues);
  const [view, setView] = useState<View>("unlock");
  const [query, setQuery] = useState("");

  const deviated = atoms.filter((a) => values[a.id] !== 0 && a.id !== "classic_presentation");
  const allLegacy = deviated.length === 0;
  const allCurrent = atoms.every((a) => a.id === "classic_presentation" || values[a.id] === 1);
  const effectivePresentation: 0 | 1 = allLegacy ? 0 : 1;

  const listed = useMemo(() => {
    const q = query.trim().toLowerCase();
    let base = view === "trace" ? atoms : atoms.filter((a) => a.domain === view);
    if (q) base = atoms.filter((a) => [a.label, a.what, a.section, a.id, domainMeta[a.domain].title].join(" ").toLowerCase().includes(q));
    return base;
  }, [view, query]);

  const sections = useMemo(() => {
    const map = new Map<string, Atom[]>();
    for (const a of listed) {
      const key = view === "trace" || query ? domainMeta[a.domain].title : a.section;
      map.set(key, [...(map.get(key) ?? []), a]);
    }
    return [...map.entries()];
  }, [listed, view, query]);

  const set = (id: string, v: 0 | 1) => setValues((p) => ({ ...p, [id]: v }));
  const modeText = allLegacy ? "1.0.3 玩法规则 · 生效中" : allCurrent ? "现行规则（1.1.0 默认）" : `基于 1.0.3 · 已偏离 ${deviated.length} 项`;
  const modeClass = allLegacy ? "mode-legacy" : allCurrent ? "mode-current" : "mode-custom";

  return (
    <div className="proto" role="group" aria-label="配置页交互原型">
      {/* L0 模式条 */}
      <div className={`proto-mode ${modeClass}`}>
        <span className="proto-mode-dot" />
        <strong>{modeText}</strong>
        <span className="proto-mode-actions">
          <button type="button" onClick={() => setValues(legacyValues)} disabled={allLegacy}><RotateCcw size={11} /> 载入 1.0.3 档案</button>
          <button type="button" onClick={() => setValues(currentValues)} disabled={allCurrent}>载入现行默认</button>
          <button type="button" className={view === "trace" ? "is-on" : ""} onClick={() => setView("trace")}><ArrowLeftRight size={11} /> 规则溯源</button>
        </span>
      </div>

      <div className="proto-body">
        {/* L1 领域栏 */}
        <nav className="proto-rail" aria-label="领域">
          {domains.map((d, i) => {
            const n = atoms.filter((a) => a.domain === d).length;
            const dev = atoms.filter((a) => a.domain === d && values[a.id] !== 0 && a.id !== "classic_presentation").length;
            return (
              <button key={d} type="button" className={`proto-rail-item ${view === d && !query ? "is-active" : ""}`} onClick={() => { setView(d); setQuery(""); }} style={{ ["--accent" as string]: domainMeta[d].accent }}>
                <span className="proto-rail-num">{i + 1}</span>
                <span className="proto-rail-text"><b>{domainMeta[d].title}</b><small>{n} 项{dev ? ` · 偏离 ${dev}` : ""}</small></span>
              </button>
            );
          })}
          <button type="button" className={`proto-rail-item proto-rail-trace ${view === "trace" && !query ? "is-active" : ""}`} onClick={() => { setView("trace"); setQuery(""); }}>
            <span className="proto-rail-num">0</span>
            <span className="proto-rail-text"><b>规则溯源</b><small>1.0.3 ↔ 现行 并排</small></span>
          </button>
        </nav>

        {/* L2/L3 */}
        <div className="proto-main">
          <div className="proto-toolbar">
            <label className="proto-search">
              <SearchIcon size={13} />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="搜索规则：标签 / 说明 / 键名（/ 聚焦）" />
              {query ? <button type="button" onClick={() => setQuery("")} aria-label="清除">×</button> : null}
            </label>
            <span className="proto-count">{listed.length} / {atoms.length}</span>
          </div>

          {view !== "trace" && !query ? (
            <div className="proto-domain-head" style={{ ["--accent" as string]: domainMeta[view].accent }}>
              <b>{domainMeta[view].title}</b><span>{domainMeta[view].sub}</span>
            </div>
          ) : null}

          <div className="proto-scroll">
            {sections.map(([title, items]) => (
              <section key={title} className="proto-section">
                <h4 className="proto-section-title">{title}</h4>
                {items.map((a) => {
                  const derived = a.id === "classic_presentation";
                  const v: 0 | 1 = derived ? effectivePresentation : values[a.id];
                  const isLegacy = v === 0;
                  return (
                    <div key={a.id} className={`proto-row ${derived ? "is-derived" : ""}`}>
                      <div className="proto-row-main">
                        <div className="proto-row-top">
                          <span className="proto-row-label">{a.label}</span>
                          <span className={`proto-chip ${isLegacy ? "chip-legacy" : "chip-current"}`}>{isLegacy ? "1.0.3 值" : "现行值"}</span>
                          {derived ? <span className="proto-chip chip-derived"><Lock size={9} /> 派生</span> : null}
                        </div>
                        <p className="proto-row-what">{a.what}</p>
                        <div className="proto-row-three">
                          <span>默认 <b>{valueLabel(a, 1)}</b></span>
                          <span>1.0.3 <b>{valueLabel(a, 0)}</b></span>
                          <span className="is-effective">当前生效 <b>{valueLabel(a, v)}</b></span>
                        </div>
                        {a.risk ? <p className="proto-row-risk">{a.risk}</p> : null}
                      </div>
                      <div className="proto-row-ctrl">
                        {a.kind === "toggle" ? (
                          <button type="button" className={`proto-toggle ${v === 1 ? "is-on" : ""}`} disabled={derived} onClick={() => set(a.id, v === 1 ? 0 : 1)} aria-pressed={v === 1}>
                            <span /><em>{v === 1 ? "开" : "关"}</em>
                          </button>
                        ) : (
                          <div className="proto-enum">
                            {(a.options ?? []).map((opt, idx) => (
                              <button key={opt} type="button" className={v === idx ? "is-on" : ""} disabled={derived} onClick={() => set(a.id, idx as 0 | 1)}>{opt.split(" ")[0]}</button>
                            ))}
                          </div>
                        )}
                        {view === "trace" && !derived ? (
                          <button type="button" className="proto-mini" onClick={() => set(a.id, v === 0 ? 1 : 0)}>切到{v === 0 ? "现行" : "1.0.3"}</button>
                        ) : null}
                      </div>
                    </div>
                  );
                })}
              </section>
            ))}
            {!sections.length ? <div className="proto-empty">没有匹配的规则。</div> : null}
          </div>

          <div className="proto-foot">
            <span>● 未保存 · 原型不写入任何文件</span>
            <span className="proto-foot-right"><button type="button">取消</button><button type="button" className="is-primary">保存并同步</button></span>
          </div>
        </div>
      </div>
    </div>
  );
}
