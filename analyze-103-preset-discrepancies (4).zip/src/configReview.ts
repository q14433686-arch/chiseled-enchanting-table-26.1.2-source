export const configAudit = {
  scope: "以 5334137 的 ConfigCatalog / ChiseledEnchantingConfigScreen / 语言文件与数据层消费方为准，逐键核对经典页的覆盖与有效性。",
  coverage: {
    totalOptions: 64,
    categories: [
      { name: "通用与原版兼容", options: 8 },
      { name: "书架与呼吸空间", options: 8 },
      { name: "模板书与附魔经济", options: 22 },
      { name: "宝藏顿悟", options: 9 },
      { name: "退魔与置换", options: 12 },
      { name: "世界与战利品", options: 5 },
    ],
    classicPageRows: 57,
    masterSwitch: 1,
    lockedKeys: 56,
    profileFields: 29,
    presetFields: 31,
  },
  effectiveness: [
    {
      group: "规则接管（已标注并锁定）",
      count: 22,
      verdict: "无效 — 已正确标注",
      detail:
        "顿悟 9 项、经验减免 2 项、双书/研读倍率 2 项、退魔与返还 7 项、献祭与书页门槛 2 项。经典运行帧把这些值直接清零或改从经典数据表取价，配置值不起作用。",
      keys: "epiphany_* · max_wooden/total_xp_discount · book_combine/research_xp_multiplier · disenchant_enabled · allow_curse_purge · xp_refund_scale · external_xp_refund_scale · strip_xp_min/max · curse_purge_xp_cost · sacrifice_required · tome_page_required_shelves",
    },
    {
      group: "条件生效（父开关正确门禁）",
      count: 9,
      verdict: "有效 — 仅在偏离 profile 后生效",
      detail:
        "母本耐久与温养 9 项。经典 profile 把消耗模式设为 KEEP（不磨损），因此默认无效；但它们仍受「消耗模式 = 充能损耗」这个父条件约束，一旦用户主动改模式就会生效——这是合理的可编辑偏好，不是误标。",
      keys: "max_tome_uses · book_copy_wear_cost · tome_deplete_behavior · tome_regen_enabled · tome_regen_base_seconds · tome_regen_tier1/2_shelves · tome_regen_tier1/2_seconds",
    },
    {
      group: "误标为可修改（实际无效）",
      count: 6,
      verdict: "无效 — 但仍显示为可编辑，建议修正",
      detail:
        "tier1/tier2/tier3 只喂给褪魔残卷还原档位与仪式等待中位数；early_unlock 两项只作用于被隐藏的「纂刻的书」页；require_prior_discovery 在经典分支不参与（经典置换表无 discovery 字段，显示层还硬编码 unlocked=true）。这 6 项在经典下都不产生行为，却归在「可修改」组。",
      keys: "tier1_bookshelves · tier2_bookshelves · tier3_qualifying_enchantments · early_unlock_xp_levels · early_unlock_grit_count · require_prior_discovery",
    },
    {
      group: "真实生效",
      count: 19,
      verdict: "有效",
      detail:
        "扫描半径与门禁、原版台与铁砧、堆叠上限（需重启）、野生书架附魔率（仅新区块）、置换批量、母本锁、双书/研读总开关等。其中两项带生效时机限制：堆叠上限需重启、世界生成项只影响未来区块。",
      keys: "horizontal/vertical_scan_radius · direct_gates_enabled · blank_max_tier_mode · require_breathing_room/line_of_sight · vanilla_table_mode · anvil_* · restrict_villager_infinity_books · grindstone_depleted_tome · enchanted_book_stack_size · bookshelf_enchanted_prob · transformation_max_batch_size · locked_shelf_breakable · locked_book_extraction_blocked · tome_consumption_mode · book_combine/research_enabled",
    },
  ],
  coverageGaps: [
    "配方与新增物品：静态数据，预设不切换，也不在游戏内配置范围内（已在预设说明中披露）。",
    "三张经典数据表（成本/升书/置换）：只能用同路径数据包覆盖，不是游戏内选项；且客户端预览尚未优先读服务端同步行（见问题 15）。",
    "战利品池权重与箱子注入表：数据包领域，预设不重写。",
    "vanilla_chest_books_mode 与 bookshelf_pool_enabled：预设会写回默认值，但单独打开经典开关不重置它们，也不在经典页里。",
    "保留的修复（按经验点扣费、世界生成死锁、成本同步、存档兼容注册）：有意不回退，也不提供开关。",
  ],
  pagination: {
    good: [
      "分类按玩家意图而非内部子系统命名，且每项带描述 tooltip 与生效范围徽章（立即/新区块/需重启）。",
      "「仅看已修改」过滤、分类重置、全部默认、保存前状态提示（含堆叠收缩风险与重启提示）都已具备。",
      "键盘路径完整：1–6 切分类、7 进经典页、Tab/方向键/Enter 操作，滚动与焦点可见性已处理。",
      "锁定原因分层清晰：服务器只读、整合包锁定、数据包优先、经典接管、父开关不适用，各有独立文案。",
    ],
    bad: [
      "经典页是一张 57 行的扁平列表，只按「是否规则接管」排序，没有任何分组标题或子系统小节。",
      "面板最大 266px 高、行高 31px，一屏只能看到 5 行：经典页要翻约 11.4 屏，模板书分类 22 行也要 4.4 屏。",
      "全 64 项没有文本搜索，只能靠分类浏览；「找到某一格」的平均成本偏高。",
      "经典页是注入的第 7 个伪分类，但文档仍写「6 大逻辑分类（共 64 项）」，口径已经漂移。",
      "「模板书与附魔经济」22 项远超单页合理容量，且没有小节锚点或折叠。",
      "规则接管组只靠锁图标 + 悬停原因区分，页首没有「N 项由规则接管」的摘要，用户要先滚到列表尾部才看到被锁的 22 项。",
    ],
  },
  ui: {
    headline: "游戏内主界面是手绘贴图，配置页却是纯程序绘制——两者不是一套美术。",
    facts: [
      { label: "主界面贴图", value: "43 张", note: "含页签、行底、面板、经验球、秘典跨页等，风格统一" },
      { label: "配置页贴图", value: "0 张", note: "全部为 ARGB 矩形填充 + 缩放文字，无任何 blit 调用" },
      { label: "最小文字缩放", value: "0.64×", note: "行副标题与预设标签，约 5px 字高，中文可读性差" },
      { label: "分类栏文字", value: "0.72×", note: "7 个入口共用约 94–118px 宽的窄栏，长词易截断" },
      { label: "一屏可见行", value: "5 行", note: "行高 31px × 列表高 173px（面板 266px 上限）" },
      { label: "状态表达", value: "仅颜色", note: "可编辑/禁用/锁定靠底色与文字色区分，无图标或形状冗余" },
    ],
    verdict:
      "不算「简陋」到不可用——层级、徽章、原因提示的信息架构其实领先多数模组；问题在于它紧挨着一个手绘风格的表格界面，视觉上像两套模组，而且文字尺度低于 Minecraft 常规可读下限，状态只靠颜色区分。",
  },
  artPlan: {
    verdict: "建议做，但必须是「先定规范、AI 出稿、人工收尾」的流程，而不是直接把生成图贴进去。",
    steps: [
      "先锁设计系统：从现有手绘 GUI 提取调色板（深紫 #241838 / #392B56、金 #FFDF82 / #E6B566、奶白文字、青绿点缀）、1px 描边与内阴影规范，写成文档再开工。",
      "只补配置页与图标，不要重画已经统一的表格贴图；目标是让配置页与主界面同族，而不是引入第二种画风。",
      "AI 用于概念稿与贴图候选：用受限提示词（像素风、限定调色板、透明底、无文字、单元素居中）批量出稿，人工挑选。",
      "强制后处理：调色板量化（≤32 色）、手工修 1px 边缘、去半透明噪点、保证 mipmap 安全；文字绝不烘焙进贴图（11 种语言靠 lang 键）。",
      "CI 加门槛：校验贴图尺寸/命名与 UV 表一致、检测含文字像素的贴图直接失败，避免回归。",
      "记录来源与许可：MIT 仓库内注明「AI 辅助生成 + 人工修整」，避免后续来源争议。",
    ],
    assets: [
      { name: "配置面板九宫格", size: "256×256", note: "替代纯色底，带描边与内阴影" },
      { name: "分类图标 ×7", size: "16×16", note: "通用/书架/模板书/顿悟/退魔/世界/经典，经典用沙漏或日晷" },
      { name: "经典模式横幅", size: "220×24", note: "开启经典时的页首提示条" },
      { name: "开关两态", size: "28×16", note: "含悬停/禁用共 6 帧" },
      { name: "滑杆轨道 + 滑块", size: "64×8 / 8×12", note: "含拖动高亮" },
      { name: "步进 − / + 按钮", size: "12×12", note: "替代当前纯文字按钮" },
      { name: "生效范围徽章 ×3", size: "9×9", note: "立即/新区块/需重启，形状+颜色双编码" },
      { name: "来源/状态徽章", size: "9×9", note: "默认·配置·数据包·锁定·重启" },
      { name: "滚动条轨道 + 滑块", size: "8×64 / 8×16", note: "替代当前细矩形" },
      { name: "分组小节标题条", size: "200×12", note: "经典页与超长分类内部再分组" },
      { name: "搜索框底图", size: "120×14", note: "配合新增的全局搜索" },
      { name: "空状态插画", size: "48×48", note: "「无修改项」时不再只有一行灰字" },
    ],
  },
  reference: {
    levels: [
      { level: "L0 模式条", detail: "常驻页首：当前模式 + 偏离项计数（如「1.0.3 规则 · 已偏离 3 项」），点击展开预设。" },
      { level: "L1 领域（6–8 个）", detail: "按玩家目标分域，单域不超过 12 行；把 22 项的「模板书与经济」拆成「模板书与耐久」和「经验经济与减免」。" },
      { level: "L2 小节", detail: "域内用粘性小节标题（如「解锁与扫描」「消耗与减免」），可折叠，支持锚点跳转。" },
      { level: "L3 行", detail: "标签 + 控件 + 状态徽章；悬停显示默认值/已保存值/当前生效值与来源。" },
    ],
    rules: [
      "64 项规模下，「每域一页 + 锚点栏 + 搜索」优于任意分页；不要把一个子系统拆到两页。",
      "搜索是一等公民：按标签、描述、原始键名模糊匹配，显示「n / 64」，Ctrl+F 或 / 聚焦。",
      "每行三值模型：默认 / 已保存 / 当前生效，配来源徽章（默认·配置·数据包·锁定·需重启）。",
      "经典应当是「模式」而不是第 7 个分类：开启后整页换主题色并收起规则接管项为一张摘要卡（「22 项由 1.0.3 规则接管」），展开才见明细。",
      "渐进披露：描述进 tooltip，高级项默认折叠，「仅看已修改」之外再给「仅看本模式无效项」。",
      "可读性下限：正文缩放 ≥ 0.85、次要 ≥ 0.75，行高 ≥ 26px，对比度 ≥ 4.5:1，状态永远形状+颜色双编码。",
      "国际化余量：标签列要容忍德语/俄语 +40% 宽度，超长换行或进 tooltip，不做语义截断。",
      "键盘：1–6 域、7 模式摘要、Tab/方向键、Enter 保存、Esc 取消、/ 聚焦搜索；每个锁定项的原因一悬停即达。",
    ],
  },
};
