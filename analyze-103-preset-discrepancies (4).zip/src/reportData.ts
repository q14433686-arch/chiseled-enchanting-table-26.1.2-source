export const repository =
  "https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source";

export const currentRevision = "87e3fc5";
export const previousRevision = "5334137";
export const reviewedBranch = "arena/8eb3bb9e-chiseled-enchanting-table-26-1";
export const legacyRevision = "26.1.2_1.0.3";

type Revision = "old" | "current";

export type Evidence = {
  label: string;
  url: string;
  revision: "1.0.3" | "当前" | "API";
};

export type Category = "mechanic" | "economy" | "copy" | "content";
export type Priority = "P0" | "P1" | "P2";
export type Status = "fixed" | "partial" | "open";

export type Finding = {
  id: string;
  number: string;
  category: Category;
  priority: Priority;
  status: Status;
  title: string;
  summary: string;
  baseline: string;
  current: string;
  recommendations: string[];
  acceptance: string;
  caveat?: string;
  evidence: Evidence[];
};

const java = "src/main/java/chiseled_enchanting_table/";
const client = "src/client/java/chiseled_enchanting_table/";
const lang = "src/client/resources/assets/chiseled_enchanting_table/lang/zh_cn.json";
const data = "src/main/resources/data/chiseled_enchanting_table/chiseled_enchanting_table/";
const recipe = "src/main/resources/data/chiseled_enchanting_table/recipe/";

export function sourceUrl(revision: Revision, path: string, lines?: string) {
  const ref = revision === "old" ? legacyRevision : currentRevision;
  return `${repository}/blob/${ref}/${path}${lines ? `#${lines}` : ""}`;
}

const evidence = (label: string, revision: Revision, path: string, lines: string): Evidence => ({
  label,
  url: sourceUrl(revision, path, lines),
  revision: revision === "old" ? "1.0.3" : "当前",
});

export const reviewSummary = {
  headline: "Round 5 关掉了 overlay 跨端缺口：15 项中 13 项已修复，剩 2 项说明层残留，0 项机制缺口。",
  body:
    "87e3fc5 相比上一轮新增 Round 5：客户端 getEnchantmentItemCostOptions / getBaseEnchantmentXpLevelCost 都先读服务端同步行，再回退本地经典表；经典置换 XP 不再写死 3/1，而是读（可数据包覆盖的）经典表。上一轮唯一 open 项已闭合；剩余 2 个部分项都是说明层：6 个误标为可修改的无效键，以及选项标签仍写「原汁原味」。",
  metrics: [
    { label: "本轮复核项", value: "15" },
    { label: "已修复", value: "13" },
    { label: "部分修复", value: "2" },
    { label: "仍存在", value: "0" },
  ],
};

export const findings: Finding[] = [
  {
    id: "ritual-slip",
    number: "01",
    category: "mechanic",
    priority: "P0",
    status: "fixed",
    title: "0 秒铭刻仍可能抄错/串行 —— 已修复",
    summary: "结算路径与 headless fallback 都对经典模式强制零失误概率，上一轮最危险的结果偏差已关闭。",
    baseline:
      "1.0.3 的附魔应用直接写入目标物品。旧版没有排队铭刻、过载负载或随机串行的结算路径。",
    current:
      "新分支仍让经典模式以 1 tick 内部队列复用 ritual 容器，但在 completeActiveRitual 内识别 classic103Mode，并把 stepSlipProb 置 0；headless fallback 也把 slipChance 置 0。经典铭刻不会降阶、串行或写入其他词条。",
    recommendations: [
      "保留当前门禁，并补一个针对 `wear_immune` 母本与切换模式时遗留队列的回归测试，防止并行改动把它带回经典路径。",
      "文档继续说明：复用 ritual 只是内部传输，玩家看到的经典语义仍是即时、确定性铭刻。",
    ],
    acceptance:
      "构造高负载免磨损母本，经典模式反复铭刻不发生降阶、杂项或诅咒串行；标准模式同一条件仍遵循配置概率。再验证 headless fallback 与中途切换模式。",
    evidence: [
      evidence("旧版直接施加附魔", "old", `${java}mechanics/enchanting/EnchantmentApplication.java`, "L28-L76"),
      evidence("经典即时铭刻仍入队", "current", `${java}mechanics/enchanting/EnchantmentApplication.java`, "L163-L238"),
      evidence("经典 ritual 结算强制零失误", "current", `${java}block/ChiseledEnchantingTableBlockEntity.java`, "L351-L436"),
      evidence("headless fallback 也归零", "current", `${java}mechanics/enchanting/EnchantmentApplication.java`, "L242-L256"),
    ],
  },
  {
    id: "epiphany-gate",
    number: "02",
    category: "mechanic",
    priority: "P0",
    status: "fixed",
    title: "零概率顿悟不等于关闭刷新 —— 已修复",
    summary: "经典模式下顿悟从运行帧、抽取、槽位、付费到结果列表都被关闭，不再只是概率为 0。",
    baseline:
      "1.0.3 的 OptionType 只有普通附魔、物品置换、双书合并与单书进修，没有顿悟、刷新或锁定操作。",
    current:
      "runtime frame 对 classic 把 base/max/per-shelf/per-tome 概率归零；handler 的 epiphanyChance、epiphanyMaxSlots、computeActiveTreasureEpiphanies 直接返回 0 / 0 / 空列表；canAffordRerollEpiphany 与 canAffordFreezeEpiphany 也直接 false。即使数据包覆盖概率，经典仍不可触发。",
    recommendations: [
      "维持当前多层门禁：规则层、结果层、付费层都拦截，避免未来单点回退。",
      "旧冻结字段可继续作为惰性存档数据保留，并在文档中说明它不会在经典模式提供入口。",
    ],
    acceptance:
      "在至少 32 个普通书架下伪造合法容器 ID 的刷新/锁定包：经典模式 XP、材料、种子与冻结时间均不变；再用数据包把概率设为 100% 验证经典仍不可触发。",
    evidence: [
      evidence("旧版选项类型", "old", `${java}menu/ChiseledEnchantingMenuPayloads.java`, "L35-L39"),
      evidence("runtime frame 对经典清零顿悟概率", "current", `${java}data/ChiseledEnchantingTableData.java`, "L954-L990"),
      evidence("经典 epiphanyChance / slots 归零", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2226-L2266"),
      evidence("经典 active epiphany 为空", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2342-L2350"),
      evidence("经典 reroll / freeze 不可支付", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2485-L2501"),
    ],
  },
  {
    id: "incremental-copy",
    number: "03",
    category: "copy",
    priority: "P1",
    status: "fixed",
    title: "“仅补差价”文案 —— Round 4 已补经典页签说明",
    summary: "列表注释与附魔页签 tooltip 现在都按经典模式切换，不再承诺自动抵扣。",
    baseline:
      "1.0.3 的处理器取目标等级的完整材料与 XP 成本，扣除对应经验点；没有逐级补差结算。",
    current:
      "Round 4 新增 `tab.inscribe.desc_classic`（“升级按目标等级完整计价 — 不抵扣已付成本”）并在页签 tooltip 处按 `isClassic103Mode()` 选择；此前行注释已加经典门禁，XP 仍走完整 `forFullArcaneRitual(rawCost, 0)`。11 个语言文件同步新增该键。",
    recommendations: [
      "保持现状，并把这条文案纳入 lang parity 门（CI 已有 11 语言键位一致性检查）。",
      "后续若新增价格类页签说明，直接复用“按模式选键”的模式，避免再出现单一静态键。",
    ],
    acceptance:
      "经典模式下附魔 II→III：列表不显示“仅补差价”，附魔页签悬停也不承诺自动抵扣；标准模式仍保留差额说明。",
    evidence: [
      evidence("旧版完整成本与经验扣除", "old", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L412-L439"),
      evidence("当前经典模式不显示 upgrade_from", "current", `${client}gui/EnchantementListWidget.java`, "L1330-L1340"),
      evidence("当前经典模式按完整 XP 计价", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2138-L2143"),
      evidence("页签 tooltip 仍无条件使用旧说明", "current", `${client}gui/ChiseledEnchantingTableScreen.java`, "L1241-L1246"),
      evidence("旧静态文案", "current", lang, "L106-L109"),
    ],
  },
  {
    id: "pricing-source",
    number: "04",
    category: "copy",
    priority: "P1",
    status: "fixed",
    title: "经典计价来源与 XP 显示 —— 已修复",
    summary: "经典行浮窗、JEI/REI、服务端同步成本都改用经典语义；上一轮的“来源各说各话”已关闭。",
    baseline:
      "1.0.3 直接通过目标等级的成本扣经验点；两种物品置换标价分别是 3 级与 1 级，不存在母本 1-3 级量产计价。",
    current:
      "classic 行浮窗使用 `pricing.classic_1_0_3` 与 `pricing.book_transfer_classic`；JEI/REI 的 XP 行与 tooltip 走 classic/full 分支，并隐藏经典下的书架减免行。材料改为每玩家 salt 解析，服务端 `EnchantCostTablePayload` 也发送相同 salted 行；经典研读 XP 使用 floor（锋利 III 为 7）。",
    recommendations: [
      "继续把这份 classic 报价语义收敛到统一 quote 对象，避免以后新增界面再次各自判断。",
      "把本轮新增的数据包 overlay 客户端缺口单独处理，不要因为常规经典路径已对就宣布同步链完全闭环。",
    ],
    acceptance:
      "经典模式下悬停已存书附魔、无存书附魔与两项置换：XP 徽章、来源、材料和 JEI/REI 显示一致，不再出现 1-3 级量产暗示。",
    evidence: [
      evidence("旧版置换 3 / 1 级", "old", `${data}item_transformations.json`, "L2-L24"),
      evidence("当前 classic 来源文案", "current", lang, "L319-L320"),
      evidence("当前经典 salted 材料分支", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L1428-L1458"),
      evidence("当前经典 salted 研究成本入口", "current", `${java}data/ChiseledEnchantingTableData.java`, "L284-L300"),
      evidence("当前服务端同步 salted 成本行", "current", `${java}menu/EnchantCostTablePayload.java`, "L210-L290"),
      evidence("JEI 已分 classic/full XP", "current", `${client}compat/jei/EnchantingRecipeCategory.java`, "L85-L101"),
      evidence("JEI 经典隐藏共鸣行", "current", `${client}compat/jei/EnchantingRecipeCategory.java`, "L127-L150"),
      evidence("REI 已分 classic/full XP", "current", `${client}compat/rei/ReiEnchantingCategory.java`, "L80-L112"),
    ],
  },
  {
    id: "resonance-text",
    number: "05",
    category: "copy",
    priority: "P1",
    status: "fixed",
    title: "共鸣减免残留提示 —— 已修复",
    summary: "经典模式从源头清零所有减免子项，材料浮窗也加了 classic 门禁。",
    baseline:
      "1.0.3 有普通书架对附魔等级的 +floor(W/3) 提升，没有书库 XP 共鸣减免体系。",
    current:
      "runtime frame 在 classic103Mode 下把 wooden/global/base/specific/total 等子上限全部归零；材料悬停只在 `!isClassic103Mode()` 且 `specBonus > 0` 时显示。之前“额外 -15%（共 -0%）”的残留不再成立。",
    recommendations: [
      "继续保持“数据源归零 + UI 条件”双层约束。",
      "以后新增任何减免细项，都以实际生效的 discountApplied 或 classic 门禁作为显示条件。",
    ],
    acceptance:
      "经典模式在满级藏书旁悬停材料、行与 XP 徽章，不出现正数减免承诺；普通模式仍显示真实比例。",
    evidence: [
      evidence("旧版只有书架提级逻辑", "old", `${java}block/ChiseledEnchantingTableBlock.java`, "L153-L203"),
      evidence("当前 classic 清零全部减免上限", "current", `${java}data/ChiseledEnchantingTableData.java`, "L855-L915"),
      evidence("当前材料浮窗加 classic 门禁", "current", `${client}gui/ChiseledEnchantingTableScreen.java`, "L1439-L1458"),
    ],
  },
  {
    id: "cost-table",
    number: "06",
    category: "economy",
    priority: "P1",
    status: "fixed",
    title: "完整收费仍用 1.1.0 价格表 —— 已修复",
    summary: "经典 runtime frame 明确装载 1.0.3 成本表，并已覆盖为可用数据包替换的 classic overlay。",
    baseline:
      "1.0.3 的 enchantment_costs.json：I 级基数 5、常规满级 25、稀有单级 35，经验修补 I 的覆盖值为 35；材料还使用不同附魔的多选方案。",
    current:
      "classic103Mode 下 runtime frame 使用 `classicCostTables`（默认来自 `enchantment_costs_classic_1_0_3.json`，可通过同路径数据包替换）；测试断言 Mending I = 35、common max = 25。常规经典路径不再把 1.1.0 价格表当作“完整价”。",
    recommendations: [
      "保留专属 classic 表加载，并继续用测试锁定旧价格；不要只验证一个高价值魔咒。",
      "把 overlay 客户端同步缺口作为单独测试面，见本页新增问题。",
    ],
    acceptance:
      "对比经验修补 I、保护 IV、锋利 III 与一种第三方附魔的报价：经典模式与 1.0.3 标签一致；标准模式仍保持现价；数据包覆盖时服务端实际结算正确。",
    evidence: [
      evidence("1.0.3 XP 基数与覆盖", "old", `${data}enchantment_costs.json`, "L1-L37"),
      evidence("当前经典帧切换旧成本表", "current", `${java}data/ChiseledEnchantingTableData.java`, "L954-L990"),
      evidence("当前经典表可通过 ResourceManager 覆盖", "current", `${java}data/ChiseledEnchantingTableData.java`, "L731-L736"),
      evidence("当前测试锁定旧价格", "current", `src/test/java/chiseled_enchanting_table/ConfigurationSafetyTest.java`, "L162-L190"),
    ],
  },
  {
    id: "book-upgrades",
    number: "07",
    category: "economy",
    priority: "P1",
    status: "fixed",
    title: "升书材料规则未回退 —— 已修复",
    summary: "经典升书表与 XP 倍率成组切换，研读 XP 还补了向下取整。",
    baseline:
      "1.0.3 的 book_upgrades.json：双书 XP 倍率 1.0、单书 XP 倍率 0.5、单书材料倍率 0.5，且为锋利等魔咒指定了主题材料。",
    current:
      "classic103Mode 下 `bu = classicBookUpgradeRules`，XP 倍率取经典表的 1.0 / 0.5（不再从 cfg 取新版倍率），材料倍率也来自经典表；`classicResearchXpCost` 使用 floor，锋利 III 研读为 7。多词条双书合并仍保留当前反套利修复。",
    recommendations: [
      "继续把“保留反套利修复”列为有意不回退的偏差，避免用户误报为 bug。",
      "补一条真实材料比对测试，确认经典书中 `count_per_level` 与附加材料都被解析，而不只是 XP 数值。",
    ],
    acceptance:
      "单词条锋利 II→III、材料升阶与双书合并分别对照旧材料和倍率；多词条双书仍按所有实际升阶词条计费。",
    caveat:
      "旧版多词条合并仅按点击词条收费，现行逐条计费属于应保留的经济修复，不能为追求字面一致而恢复漏洞。",
    evidence: [
      evidence("旧版升书规则", "old", `${data}book_upgrades.json`, "L1-L16"),
      evidence("当前经典升书表与倍率", "current", `${java}data/ChiseledEnchantingTableData.java`, "L954-L972"),
      evidence("当前研读使用 floor", "current", `${java}data/ChiseledEnchantingTableData.java`, "L284-L287"),
      evidence("当前测试覆盖经典升书语义", "current", `src/test/java/chiseled_enchanting_table/ConfigurationSafetyTest.java`, "L162-L218"),
    ],
  },
  {
    id: "apple-emerald",
    number: "08",
    category: "economy",
    priority: "P1",
    status: "fixed",
    title: "金苹果 2-5 绿宝石与按玩家盐值选价 —— 已修复",
    summary: "经典转化成本现在从规则读取，并按玩家 salt 解析，不再写死 2 或取中点。",
    baseline:
      "1.0.3 金苹果置换是 3 级 + 8 金块 + 2-5 绿宝石的可变附加成本；经验之瓶是 1 级 + 6 青金石 + 2 紫水晶碎片。",
    current:
      "handler 的经典 transformation 分支调用 `classicTransformationCosts(id, uuid)`；数据层从 classic transformation 表读取主材料与附加材料，ranged count 使用与 1.0.3 相同的 stable hash。服务端 payload 也按玩家 salt 发送转化成本。",
    recommendations: [
      "保留当前 rule-driven 读取与 per-player salt；不要再在 handler 里散写经典常量。",
      "对同一玩家与不同玩家各做一组快照测试，锁定“稳定但不同”的语义。",
    ],
    acceptance:
      "使用多个玩家 UUID 验证金苹果置换按旧版规则选价，同一玩家稳定；预览、服务端实扣与 JEI/REI 一致。",
    evidence: [
      evidence("旧版 2-5 绿宝石", "old", `${data}item_transformations.json`, "L2-L24"),
      evidence("当前经典 transformation 分支", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L1428-L1438"),
      evidence("当前 classicTransformationCosts 入口", "current", `${java}data/ChiseledEnchantingTableData.java`, "L575-L600"),
      evidence("当前服务端发送 salted 置换成本", "current", `${java}menu/EnchantCostTablePayload.java`, "L220-L240"),
    ],
  },
  {
    id: "unlock-filter",
    number: "09",
    category: "mechanic",
    priority: "P1",
    status: "fixed",
    title: "第三方双标签默认解锁过滤 —— 已修复",
    summary: "经典模式不再对 in_enchanting_table 展开先做 treasure / epiphany_exclusive 排除。",
    baseline:
      "1.0.3 默认表显式列出 7 种宝藏附魔，再展开 #minecraft:in_enchanting_table；展开逻辑没有宝藏或 epiphany_exclusive 排除条件。",
    current:
      "`defaultEnchantments(lookup)` 在 classic103Mode 下使用空排除集合，并跳过 `defaultExcludedTags` 的展开过滤；第三方同时位于 in_enchanting_table 与 treasure / epiphany_exclusive 的附魔可以按旧逻辑默认解锁，同时仍保留 maxLevel 安全钳制。",
    recommendations: [
      "保留当前实现，并补一个真正的双标签测试数据包样例，防止以后又回到“先过滤再补 7 个 ID”。",
      "文档中明确：经典模式恢复旧 unlock 口径，但不撤销安全上限钳制。",
    ],
    acceptance:
      "原版七种与旧版一致；双标签自定义附魔在经典模式按旧标签展开，在标准模式仍遵循新排除规则。",
    evidence: [
      evidence("旧版七种与标签展开", "old", `${data}default_enchantments.json`, "L3-L14"),
      evidence("旧版展开不排除", "old", `${java}data/ChiseledEnchantingTableData.java`, "L88-L96"),
      evidence("当前经典模式不做排除过滤", "current", `${java}data/ChiseledEnchantingTableData.java`, "L175-L220"),
    ],
  },
  {
    id: "world-loot",
    number: "10",
    category: "economy",
    priority: "P1",
    status: "fixed",
    title: "野生雕纹书架附魔书率 0.03 —— 已恢复",
    summary: "经典预设写回 0.03，滑杆步长也改为 0.01，手动编辑后可准确选回。",
    baseline:
      "1.0.3 的 bookshelf_book_pool.json 设置 enchanted_book_probability = 0.03，书本数量范围 3-5。",
    current:
      "classic preset applyTo 与 classic profile 都设置 `bookshelfEnchantedProb = 0.03`；测试断言 0.03。配置 catalog 的 step 已从 0.02 改为 0.01，因此经典页可精确恢复 0.03。该设置仍只影响 NEW_GENERATION。",
    recommendations: [
      "维持 0.03 与 0.01 步长；在界面里继续强调只影响未来新生成结构。",
      "如果以后要严格对齐世界生成池权重，再单独比对各 loot 注入条目，不与概率混在一起。",
    ],
    acceptance:
      "比较新生成结构的配置值及抽样分布；已生成雕纹书架不被追溯改写，切回标准恢复 0.12；经典页可精确选回 0.03。",
    evidence: [
      evidence("1.0.3 概率 0.03", "old", `${data}bookshelf_book_pool.json`, "L4-L15"),
      evidence("当前 classic profile 恢复 0.03", "current", `${java}config/ModRuntimeConfig.java`, "L228-L231"),
      evidence("当前 classic 测试断言 0.03", "current", `src/test/java/chiseled_enchanting_table/ConfigurationSafetyTest.java`, "L124-L135"),
      evidence("当前滑杆步长为 0.01", "current", `${java}config/ConfigCatalog.java`, "L905-L909"),
    ],
  },
  {
    id: "recipe-scope",
    number: "11",
    category: "content",
    priority: "P1",
    status: "fixed",
    title: "静态配方边界已告知，预设也已改名为“玩法规则”",
    summary: "仍不会热切换配方，但这一边界已写进预设说明，而不再被“原汁原味”名称掩盖。",
    baseline:
      "旧版纂刻附魔台配方中的 D 是 diamond_block，O 是 obsidian；该标签下没有秘法凝晶、退魔砂或秘典合成配方。",
    current:
      "运行时预设仍不会热切换 recipe JSON，当前配方仍是 diamond + crying_obsidian，额外新物品配方继续加载；但预设标题改为“1.0.3 玩法规则”，描述与 inert_note 明确写出“配方仍为现行版数据，无法随此开关切换”。这满足了上一轮要求的“若无资源包切换，就改名并披露边界”。",
    recommendations: [
      "如果目标只是玩法规则复刻，当前披露已经足够；若目标是内容层也复刻，才另建内建资源包或条件加载 recipe 集。",
      "把“当前配方仍为 1.1.0”放在预设主 tooltip，而不是只埋在 inert_note 中。",
    ],
    acceptance:
      "保存经典预设前后、/reload 后检查配方书与预设 tooltip：玩家能清楚知道静态配方不随开关切换，且不会再把它误认为完整内容复刻。",
    evidence: [
      evidence("旧版附魔台配方", "old", `${recipe}chiseled_enchanting_table.json`, "L1-L17"),
      evidence("现行附魔台配方", "current", `${recipe}chiseled_enchanting_table.json`, "L1-L17"),
      evidence("当前预设标题已改", "current", lang, "L765-L767"),
      evidence("Wiki 已写明保留差异", "current", "docs/WIKI.md", "L264-L266"),
    ],
  },
  {
    id: "viewer-manual",
    number: "12",
    category: "copy",
    priority: "P1",
    status: "fixed",
    title: "JEI/REI 已适配经典说明，秘典每章前置提示 —— 已修复",
    summary: "查看器不再在经典下教 1-3 级量产；秘典从仅首页提示改为每个非首页章节前置 classic notice。",
    baseline:
      "1.0.3 没有九章节《纂刻秘典》或新版本的 1-3 级母本经济叙事；JEI/REI 当时只展示旧附魔与旧成本。",
    current:
      "JEI 信息页按 classic 选择 `info.station_classic` / `info.bookshelf_classic`；JEI/REI 附魔类别与 tooltip 都分 classic/full XP，并隐藏经典共振减免行。秘典在 `ch != 0` 的每个章节前置 `grimoire.classic_notice`，明确“本章讲的是标准模式系统，在经典下均禁用”。正文没有逐段重写，但误导已被显式标注；换模式后查看器信息页需重进世界，客户端已弹出提示。",
    recommendations: [
      "保留 per-chapter notice；如果后续追求“纯净经典手册”，再把 ch4–ch9 的正文替换为经典精简版。",
      "把 info page 重进世界提示写进预设保存后的 toast，而不只写在说明文档里（当前已有 `compat_info_refresh`）。",
    ],
    acceptance:
      "经典模式逐章翻阅秘典，每章均有清晰的双模式提示；JEI/REI 不再显示经典下不存在的 1-3 级/共鸣减免；切换模式后提示重新进入世界。",
    caveat:
      "秘典采用“每章前置声明”而不是正文重写，因此标准模式教程文字仍留在页面中，但不会再被当作经典规则直接传授。",
    evidence: [
      evidence("旧版中文文案范围", "old", lang, "L1-L16"),
      evidence("当前 JEI 选择 classic 信息页", "current", `${client}compat/jei/ChiseledEnchantingJeiPlugin.java`, "L124-L139"),
      evidence("当前 JEI/REI 经典 XP 显示", "current", `${client}compat/jei/EnchantingRecipeCategory.java`, "L85-L101"),
      evidence("当前秘典每章前置 classic notice", "current", `${client}gui/grimoire/ArcaneGrimoireScreen.java`, "L1118-L1132"),
      evidence("当前 classic notice 文案", "current", lang, "L187-L188"),
      evidence("切换模式后查看器刷新提示", "current", `${client}ChiseledEnchantingTableClient.java`, "L254-L261"),
    ],
  },
  {
    id: "config-links",
    number: "13",
    category: "mechanic",
    priority: "P1",
    status: "partial",
    title: "经典页已区分“规则接管/可修改”，但仍有 6 项无效却标为可修改",
    summary: "Round 4 用 CLASSIC_OVERRIDDEN_KEYS 把 22 项明确锁定并给出独立原因；剩余问题是 tier / early-unlock / require_prior_discovery 这 6 项。",
    baseline:
      "1.0.3 不存在顿悟、共鸣折扣或退魔页设置，不会形成这些配置值与有效行为的冲突。",
    current:
      "Round 4 新增 `CLASSIC_OVERRIDDEN_KEYS`（22 项）：顿悟 9 项、减免 2 项、双书/研读倍率 2 项、退魔与返还 7 项、献祭与书页门槛 2 项，在经典页保持锁定并显示「经典开启时由 1.0.3 规则接管 — 此值不生效」；经典页改为「可修改项在前、规则接管项在后」排序，副标题同步改写。残余：`tier1/tier2/tier3_bookshelves`、`early_unlock_xp_levels`、`early_unlock_grit_count`、`require_prior_discovery` 这 6 项仍归为可修改，但它们只喂给褪魔残卷还原档位、被隐藏的书页和经典分支不读取的 discovery 判定，在经典下实际不产生行为。",
    recommendations: [
      "把这 6 项并入 `CLASSIC_OVERRIDDEN_KEYS`，或引入第三种原因键（如「经典下无此子系统」）。",
      "在经典页页首加一张摘要卡：「N 项由规则接管」，避免用户滚到列表末尾才发现被锁的 22 项。",
      "补一条测试：断言经典页「可修改集合」中的每个键在经典分支都有真实消费方，防止以后再出现误标。",
    ],
    acceptance:
      "经典页 57 行中每一行要么真实生效（含条件生效并说明父开关），要么明确给出不生效原因；不存在「可修改但实际无效」的行。",
    evidence: [
      evidence("旧版仅有四种操作类型", "old", `${java}menu/ChiseledEnchantingMenuPayloads.java`, "L29-L40"),
      evidence("当前 evaluate 的 classic 旧注释/原因", "current", `${java}config/ConfigCatalog.java`, "L284-L300"),
      evidence("当前 classic 锁定键集合", "current", `${java}config/ConfigCatalog.java`, "L345-L369"),
      evidence("Classic 页移除原因并允许编辑", "current", `${client}gui/config/ChiseledEnchantingConfigScreen.java`, "L201-L226"),
      evidence("经典页副标题“均可修改”", "current", lang, "L383-L384"),
      evidence("经典开关一次性应用 profile", "current", `${java}config/ModRuntimeConfig.java`, "L1145-L1155"),
    ],
  },
  {
    id: "policy-truth",
    number: "14",
    category: "content",
    priority: "P2",
    status: "partial",
    title: "命名已统一为“玩法规则”，仅剩选项标签仍写“原汁原味 / Purist”",
    summary: "短名、应用提示与状态条都已改；Round 4 还把状态条拆成「生效中 / 已自定义」两种。",
    baseline:
      "1.0.3 以数据包 JSON 和服务器权威计价为基础，不存在“预设匹配”这个对外承诺；移植时的世界生成死锁和成本同步修复无需回退。",
    current:
      "Round 4 把短名改为「1.0.3 规则」、应用提示改为「1.0.3 玩法规则已载入草稿」，并把状态条拆成 `classic_1_0_3_active`（「1.0.3 玩法规则生效中」）与 `classic_1_0_3_custom`（「基于 1.0.3 的自定义规则（数值已偏离预设）」），由 `Preset.matches(draft)` 判定。残余：选项标签 `opt.classic_1_0_3_mode` 在中文仍是「1.0.3 原汁原味模式」、英文仍是「1.0.3 Classic Purist Mode」，与「玩法规则」口径不一致。",
    recommendations: [
      "把 `opt.classic_1_0_3_mode` 与其 desc 同步改为「1.0.3 玩法规则 / 1.0.3 Gameplay Rules」，11 个语言一起改。",
      "预设 tooltip 把「配方仍为现行版数据」从 inert_note 提到主描述首行，让静态边界第一眼可见。",
    ],
    acceptance:
      "保存后、编辑经典页后、退出经典后再进入：预设短名、标题、选项标签、应用提示、状态条五处名称一致；偏离预设时状态明确显示自定义。",
    evidence: [
      evidence("旧版 64 堆叠尚为 TODO", "old", `${java}ChiseledEnchantingTable.java`, "L20-L28"),
      evidence("短名与标题已改为玩法规则", "current", lang, "L766-L770"),
      evidence("选项标签仍写原汁原味", "current", lang, "L759-L760"),
      evidence("状态条已区分生效中/自定义", "current", lang, "L783-L784"),
      evidence("状态条按 Preset.matches 判定", "current", `${client}gui/config/ChiseledEnchantingConfigScreen.java`, "L848-L854"),
      evidence("预设匹配只比较草稿", "current", `${java}config/ModRuntimeConfig.java`, "L323-L334"),
      evidence("Wiki 已改为玩法规则与保留差异", "current", "docs/WIKI.md", "L264-L266"),
    ],
  },
  {
    id: "overlay-sync",
    number: "15",
    category: "economy",
    priority: "P1",
    status: "fixed",
    title: "经典 overlay 跨端优先级 —— Round 5 已修复",
    summary: "客户端现在先读服务端同步行，本地经典表只是回退；经典置换 XP 也改为读表。",
    baseline:
      "1.0.3 的处理器从数据包成本表解析材料，并以玩家 salt 选取；没有“服务端 overlay 与客户端本地表”的双份路径。",
    current:
      "Round 5 把 `syncedRow` 与“表被截断则 fail-closed”提到所有经典本地分支之前；`getBaseEnchantmentXpLevelCost` 同样先读同步行，再从 `classicTransformationXpCost()` 读经典表（含数据包覆盖），不再写死 3/1。专用服 overlay 场景下预览、JEI/REI 与实扣现在共用服务端结果。",
    recommendations: [
      "在客户端把 `syncedRow` 提到所有 classic 本地降价分支之前：有服务端行就用服务端行，只有没有同步行时才退回本地 classic 表。",
      "经典 transformation 的 XP 不要写死 3/1；从 `ItemTransformation`/同步行读取，使数据包覆盖同样作用于服务端扣费与客户端预览。",
      "增加一条端到端测试：带 classic overlay 的专用服 + 无同名数据包的客户端，确认材料与 XP 行、实扣、JEI/REI 共用同一结果。",
    ],
    acceptance:
      "部署一个修改经典成本/置换 XP 的服务器数据包，连接普通客户端：表内预览、JEI/REI、实际扣费和 `/reload` 后结果一致；移除 overlay 后回退到 bundled 1.0.3 表。",
    caveat:
      "仍建议补一条带 overlay 的专用服 + 普通客户端端到端测试；目前只有静态代码核对。",
    evidence: [
      evidence("客户端先读同步行再回退本地表", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L1424-L1442"),
      evidence("syncedRow 只在物理客户端读取", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2596-L2603"),
      evidence("服务端 classic overlay 加载", "current", `${java}data/ChiseledEnchantingTableData.java`, "L731-L736"),
      evidence("服务端发送 salted 成本行", "current", `${java}menu/EnchantCostTablePayload.java`, "L210-L290"),
      evidence("客户端缓存服务端成本行", "current", `${java}compat/SyncedEnchantmentCosts.java`, "L49-L61"),
      evidence("经典置换 XP 改为读表", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L1532-L1545"),
    ],
  },
];

export const categoryLabels: Record<Category, string> = {
  mechanic: "机制与门禁",
  economy: "数据与经济",
  copy: "界面与文案",
  content: "内容与边界",
};

export const statusLabels: Record<Status, string> = {
  fixed: "已修复",
  partial: "部分修复",
  open: "仍存在",
};

export const statusDescriptions: Record<Status, string> = {
  fixed: "本轮代码检查确认修复已落地，且默认经典数据集下不依赖单一 UI 隐藏。",
  partial: "核心结果已基本对齐，但仍有静态说明、配置页语义或命名不一致。",
  open: "新功能或跨端链路仍有实际缺口，建议在发布前继续跟进。",
};

export const auditApi = [
  {
    title: "网络与服务端校验",
    code: "PayloadTypeRegistry.serverboundPlay()",
    text: "经典顿悟刷新/锁定现在不仅隐藏按钮，还在 handler 的 canAfford 路径直接拒绝；服务端仍保留 revision_16 协议与容器 ID 校验。新增 cost overlay 后，应继续用服务端行而不是 UI 侧推断价格。",
    source: sourceUrl("current", `${java}menu/EnchantingNetworking.java`, "L82-L117"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/networking/v1/ServerPlayNetworking.html",
  },
  {
    title: "资源重载与经典 overlay",
    code: "PackType.SERVER_DATA / ResourceManager",
    text: "三张 classic 成本/升书/置换表现在经 `ResourceManager#getResource` 在服务器 reload 时加载，可由同路径数据包替换；但客户端仍先读本地经典表。资源条件只解决资源加载，不会自动把服务器数据包传送到客机。",
    source: sourceUrl("current", `${java}data/ChiseledEnchantingTableData.java`, "L731-L736"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/resource/conditions/v1/ResourceConditions.html",
  },
  {
    title: "附魔书堆叠上限",
    code: "DefaultItemComponentEvents.MODIFY",
    text: "Round 3 修正了 classic profile 与 startup-only 的冲突：经典开关不再在 build() 强制 64，预设/开关键只把 64 写为草稿建议，实际默认组件仍在启动期注册，需重启生效。",
    source: sourceUrl("current", `${java}ChiseledEnchantingTable.java`, "L38-L50"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/item/v1/DefaultItemComponentEvents.html",
  },
  {
    title: "配置生效与客户端同步",
    code: "RuntimeFrame + S2C cost snapshot",
    text: "`EnchantCostTablePayload.build(player)` 现在为经典材料/置换行带上玩家 salt，并和客户端 `SyncedEnchantmentCosts` 对齐。接下来只需把客户端 classic 分支的优先级改为“先同步行、后本地表”，即可关闭新增 overlay 缺口。",
    source: sourceUrl("current", `${java}menu/EnchantCostTablePayload.java`, "L210-L290"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/networking/v1/PayloadTypeRegistry.html",
  },
];

export const testCases = [
  { scenario: "高负载免磨损母本", expected: "经典无串行 / 标准仍按概率结算", layer: "服务端结算" },
  { scenario: "32+ 普通书架，伪造刷新/锁定包", expected: "经典不扣费、不改种子和冻结状态", layer: "网络门禁" },
  { scenario: "经典 II→III 悬停页签与列表", expected: "无“补差价”承诺，按完整经典费用", layer: "文案 + 经济" },
  { scenario: "同一玩家 / 不同玩家经典材料", expected: "salt 稳定、跨玩家不同、预览=实扣", layer: "盐值成本" },
  { scenario: "带 classic overlay 的专用服 + 普通客户端", expected: "材料、置换 XP、JEI/REI 都以服务器行为准", layer: "新 overlay 跨端" },
  { scenario: "经典页改值后状态条", expected: "明确显示“基于 1.0.3 的自定义规则”", layer: "配置语义" },
  { scenario: "切换经典开关并重进世界", expected: "JEI/REI 信息页刷新，配方条目实时跟随", layer: "生命周期" },
];