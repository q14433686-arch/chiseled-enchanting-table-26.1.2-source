import { Card, Code, Callout, SectionTitle } from "../components/ui";

function Quote({ children }: { children: React.ReactNode }) {
  return (
    <blockquote className="rounded-xl border border-rose-500/30 bg-rose-500/5 p-4 text-sm leading-relaxed text-rose-100/90">
      <span className="mr-1 text-lg text-rose-400">“</span>
      {children}
      <span className="ml-1 text-lg text-rose-400">”</span>
    </blockquote>
  );
}

export default function Debate() {
  return (
    <div className="space-y-8">
      <Card className="bg-gradient-to-r from-slate-900/80 to-rose-950/40">
        <h1 className="text-2xl font-extrabold text-slate-50">争议回应:这套设计自相矛盾吗?</h1>
        <p className="mt-2 text-sm leading-relaxed text-slate-300">
          两类论调在社区里很有代表性。下面逐条回应 —— 既为设计辩护该辩护的部分,
          也诚实承认论者说中的部分(承认的部分延伸到「怀疑与建议」页)。
        </p>
      </Card>

      {/* ---- 论调一 ---- */}
      <section className="space-y-4">
        <SectionTitle icon="🗣️" title="论调一 ·「给了大增益又加限制,不是自相矛盾吗?」" />
        <Quote>
          都给"无限"和周围内多书架 / 模板书这么大增益了,为什么还有限制单本模板书 / 周围多书架 /
          "无限"的增益?这不是自相矛盾吗?
        </Quote>

        <Card>
          <h3 className="mb-3 font-bold text-indigo-300">回应一:增益与限制作用在不同的轴上,所以根本不构成「矛盾」</h3>
          <div className="space-y-3 text-sm leading-relaxed text-slate-300">
            <p>
              把这套机制的增益和限制各自列出来,会发现它们<strong>没有一条作用在同一个变量上</strong>:
            </p>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-lg bg-emerald-500/5 p-3 ring-1 ring-emerald-500/20">
                <p className="mb-1.5 text-xs font-bold text-emerald-300">增益全部在「流量 / 效率」轴</p>
                <ul className="list-inside list-disc space-y-1 text-xs text-slate-300">
                  <li>母本直附 1~3 级量产模式(更便宜)</li>
                  <li>两段 XP 减免,封顶 −40%(更便宜)</li>
                  <li>38/42 架温养自动回复(更省维护)</li>
                  <li>「无限」母本零磨损(免耗材)</li>
                  <li>宝藏顿悟(拓宽获取面)</li>
                </ul>
              </div>
              <div className="rounded-lg bg-amber-500/5 p-3 ring-1 ring-amber-500/20">
                <p className="mb-1.5 text-xs font-bold text-amber-300">限制全部在「存量 / 垄断」轴</p>
                <ul className="list-inside list-disc space-y-1 text-xs text-slate-300">
                  <li>白板直附只到 ⌈M/2⌉(防跳过养成)</li>
                  <li>「无限」获取途径收窄(防量产本金)</li>
                  <li>超载抄错 ≤18%(只打全词条超级书)</li>
                  <li>强跳退化 ≤50%/70%(给急躁定价)</li>
                  <li>书架阈值 12/32/38/42(是解锁梯,不是天花板)</li>
                </ul>
              </div>
            </div>
            <p>
              「矛盾」要求对<em>同一事物</em>同时主张 A 与非 A。这里是给
              <strong>吞吐率</strong>踩油门、给<strong>一次性资本化</strong>踩刹车 ——
              说这叫自相矛盾,等于说油门和刹车不该装在同一辆车上。
              所有带进度系统的游戏都是这台双踏板机器:增益定义「你能变多强」,
              摩擦定义「变强需要穿过什么」。去掉后者,前者就不再是进度,而是开局送满级。
            </p>
          </div>
        </Card>

        <Card>
          <h3 className="mb-3 font-bold text-indigo-300">回应二:零边际成本 + 零限制 = 整个经济循环当场死亡</h3>
          <div className="space-y-3 text-sm leading-relaxed text-slate-300">
            <p>
              这个模组的核心经济是一个闭环:
              <Code>母本磨损 → 退化成褪魔残卷 → 残卷回收/温养回复 → 书墙维护</Code>,
              加上 XP 作为贯穿的水位。"无限"母本是这个闭环上
              <strong>唯一的零磨损节点</strong> —— 它免除的是循环里最根本的那项成本。
            </p>
            <p>
              假设按论者的意思,去掉对"无限"的一切限制:拿到第一本无限书的那一刻,
              磨损经济、残卷回收、温养机制、强跳博弈、耗材配方 ——
              <strong>全部同时变成死代码</strong>。不是变弱,是变得没有任何理由再被触发一次。
              限制不是对增益的否定;<em>恰恰因为这个增益给得足够大,它才必须带着对冲出生</em>。
              这和"既然银行利息高,为什么还要有存款上限"是同构的问题:上限不是跟利息过不去,
              是跟挤兑过不去。
            </p>
            <Callout tone="indigo" title="原版早就是这么干的">
              <p>
                原版 Minecraft 同样一边给(15 书架解锁 30 级)一边限(先前加工惩罚指数翻倍直到
                Too Expensive)。本模组反而<strong>删掉了</strong>原版最被诟病的那堵硬墙
                (<Code>RemoveXpCostScaling</Code> mixin 把 2n+1 翻倍惩罚拍平),
                把摩擦换成了可解释、可规避、可数据包配置的形式(磨损 / 温养 / 抄错 / 等待)。
                就"增益配限制"这件事而言,它比原版做得更宽松、也更讲道理。
              </p>
            </Callout>
            <p>
              再逐条看被点名的"限制":<strong>单本模板书</strong>的 1~3 级扣费是
              <em>量产绿色通道</em>的价格而非惩罚(对照直附模式全额扣费);
              <strong>周围多书架</strong>的 12/32/38/42 是解锁阶梯 —— 书架越多你拿到的
              <em>只增不减</em>(减免更深、温养更快、顿悟开启),唯一例外是超载抄错,而它有自己的触发前提;
              <strong>"无限"的限制</strong>只收窄获取途径和打击一种特定构型,
              对"正常持有并使用无限母本"的玩家是纯增益(零磨损)。
            </p>
          </div>
        </Card>
      </section>

      {/* ---- 论调二 ---- */}
      <section className="space-y-4">
        <SectionTitle icon="📖" title="论调二 ·「一本无限+全附魔超级书,我不就赚麻了?」" />
        <Quote>
          我不能只附魔一本包含"无限"的超级附魔书,上面有所有附魔我不就赚麻了吗?
        </Quote>

        <Card>
          <h3 className="mb-3 font-bold text-indigo-300">回应一:你描述的正是「超载抄错」机制唯一的打击对象</h3>
          <div className="space-y-3 text-sm leading-relaxed text-slate-300">
            <p>
              触发条件写得非常窄:母本<strong>同时</strong>携带 <Code>minecraft:infinity</Code>{" "}
              且其他词条数 <Code>&gt; 3</Code>(即单册 ≥5 词条)。
              一旦存在这样的超载母本,范围内拓印就有概率"抄错"——
              概率随单册词条数与广义书架总数递增,默认封顶 18%(代码与数据包均为 0.18)。
              抄错后三分支:
            </p>
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="rounded-lg bg-slate-800/60 p-3 ring-1 ring-slate-700/50">
                <p className="text-lg font-extrabold text-sky-300">70%</p>
                <p className="mt-1 text-slate-300">笔误成瑕:产出降一级</p>
              </div>
              <div className="rounded-lg bg-slate-800/60 p-3 ring-1 ring-slate-700/50">
                <p className="text-lg font-extrabold text-amber-300">25%</p>
                <p className="mt-1 text-slate-300">抄串行:串成低价值杂词条</p>
              </div>
              <div className="rounded-lg bg-slate-800/60 p-3 ring-1 ring-slate-700/50">
                <p className="text-lg font-extrabold text-red-300">5%</p>
                <p className="mt-1 text-slate-300">抄串行:串成诅咒</p>
              </div>
            </div>
            <p>
              算一笔期望账:超级书量产线的不良率最高 18%,其中约{" "}
              <Code>18% × 5% ≈ 0.9%</Code> 的产出直接带诅咒(还得花退魔砂返工洗)。
              "赚麻"的前提是产线稳定 —— 设计故意让超级书<strong>能用,但吵</strong>。
              此外强跳机制对无限母本单独加价:常规退化封顶 50%,用无限母本附魔时拔到 70% ——
              急躁的代价对"无限"持有者更高,而不是更低。
            </p>
          </div>
        </Card>

        <Card>
          <h3 className="mb-3 font-bold text-indigo-300">回应二:「本金」也不免费 —— 获取端已经三重限流</h3>
          <div className="space-y-3 text-sm leading-relaxed text-slate-300">
            <p>想攒出这本超级书,先过三道闸:</p>
            <ul className="list-inside list-disc space-y-1.5">
              <li>
                「无限」被移出默认直附列表<strong>和</strong>宝藏顿悟池 —— 纂刻附魔台自己不产无限;
              </li>
              <li>
                村民交易被 <Code>VillagerInfinitySanitizeMixin</Code> 在 <Code>getOffers()</Code>{" "}
                全路径消毒(含流浪商人与程序化开单),刷图书管理员这条捷径被封死;
              </li>
              <li>
                仅剩探索战利品、原版附魔台随机、以及"已有无限母本时复制/铭刻" ——
                而复制走铭刻流程,受等待 / 献祭 XP(≤15 级)/ 强跳退化(无限母本 70% 封顶)约束。
              </li>
            </ul>
            <p>
              所以"赚麻"的完整成本表是:稀缺的无限本体 + 逐词条铭刻的等待或献祭 +
              量产期最高 18% 不良率 + 返工用的退魔耗材。能不能赚?能。麻不麻?在默认数值下,
              大概到"温热"。
            </p>
          </div>
        </Card>

        <Card>
          <h3 className="mb-3 font-bold text-indigo-300">回应三(诚实的部分):它是软约束,论者的直觉并没有全错</h3>
          <div className="space-y-3 text-sm leading-relaxed text-slate-300">
            <p>
              必须承认:这套机制<strong>没有禁止</strong>超级书,它只是给超级书<strong>定了价</strong>。
              而且存在一条明牌出路 —— 把词条拆到多本
              「无限 + ≤3 词条」的母本上,就同时拿到零磨损<em>和</em>零抄错。
              系统实际上在用抄错概率引导你从"一本圣经"走向"一面策展书墙":
              这是刻意的设计语言(雕纹书架本来就是展示型方块),不是没堵住的漏洞。
            </p>
            <p>
              但"引导"的力度取决于数值,而 18% 封顶 × 70% 仅掉级 × 母本零磨损可无限重试,
              对一个铁了心用超级书的玩家,实际威慑力有多少?这个质疑是成立的 ——
              它不推翻设计意图,但对<em>默认参数</em>构成有效批评。具体的修补方案,
              见「怀疑与建议」页的 S-1 / S-2。
            </p>
            <Callout tone="emerald" title="一句话总结">
              <p>
                「自相矛盾」的指控不成立 —— 增益买的是吞吐,限制卖的是垄断,两者共同构成一个有价格体系的经济,
                而且所有限制都可以在数据包里调成你喜欢的样子(包括调没)。
                但「超级书惩罚偏软」的直觉<em>部分</em>成立,值得在默认值上再拧半圈。
              </p>
            </Callout>
          </div>
        </Card>
      </section>
    </div>
  );
}
