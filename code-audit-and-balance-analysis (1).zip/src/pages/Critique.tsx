import { Card, Code, Callout, SectionTitle, SevBadge } from "../components/ui";

function Suggestion({
  id,
  title,
  doubt,
  fix,
}: {
  id: string;
  title: string;
  doubt: React.ReactNode;
  fix: React.ReactNode;
}) {
  return (
    <div className="rounded-xl border border-slate-700/40 bg-slate-900/50 p-4">
      <div className="flex items-center gap-2">
        <span className="font-mono text-xs font-bold text-slate-500">{id}</span>
        <h4 className="font-semibold text-slate-100">{title}</h4>
      </div>
      <div className="mt-3 grid gap-3 lg:grid-cols-2">
        <div className="rounded-lg bg-rose-500/5 p-3 ring-1 ring-rose-500/20">
          <p className="mb-1.5 text-xs font-bold tracking-wide text-rose-300">怀疑</p>
          <div className="space-y-1.5 text-sm leading-relaxed text-slate-300">{doubt}</div>
        </div>
        <div className="rounded-lg bg-emerald-500/5 p-3 ring-1 ring-emerald-500/20">
          <p className="mb-1.5 text-xs font-bold tracking-wide text-emerald-300">建议</p>
          <div className="space-y-1.5 text-sm leading-relaxed text-slate-300">{fix}</div>
        </div>
      </div>
    </div>
  );
}

const techFixes: { sev: "高" | "中" | "低"; text: React.ReactNode }[] = [
  {
    sev: "高",
    text: (
      <>
        <strong>修 N-1:</strong>把 <Code>REVISION_11/12/13_COST_TYPE</Code> 补进{" "}
        <Code>peerHasAnyCostChannel</Code>(若曾公开发布),或删除常量并在 CHANGELOG 声明;
        根治法是把探针收进 <Code>List&lt;Type&lt;?&gt;&gt; PROBES</Code> 常量,检查链遍历它,
        让"声明即被检查"成为结构保证。
      </>
    ),
  },
  {
    sev: "中",
    text: (
      <>
        <strong>N-2 轮询改事件:</strong>每秒全服 <Code>buildTransformationDisplays</Code> diff
        改为进度/配置变更打脏标,或仅对打开菜单的玩家轮询。
      </>
    ),
  },
  {
    sev: "中",
    text: (
      <>
        <strong>D-1 编解码声明式化:</strong>巨型 payload 拆嵌套子结构 +{" "}
        <Code>StreamCodec.composite</Code>,并补全字段 round-trip 单测;字节预算改{" "}
        <Code>writerIndex()</Code> 实测(D-2)。
      </>
    ),
  },
  {
    sev: "中",
    text: (
      <>
        <strong>C-2 双端配置窗口:</strong>客户端 mixin 读配置改为"同步快照未就绪则不干预",
        消除 JOIN/重载窗口期的铁砧预测分叉。
      </>
    ),
  },
  {
    sev: "低",
    text: (
      <>
        <strong>H-1 距离属性化:</strong>重开校验改读 <Code>block_interaction_range</Code> 属性 +
        原版容差;<strong>H-3</strong> 断连消息 <Code>translatable</Code> 化;
        <strong>N-3</strong> apply 通道加同款 10 tick 节流。
      </>
    ),
  },
  {
    sev: "低",
    text: (
      <>
        <strong>C-4 文档即 API:</strong>WIKI 数值由脚本从 datapack JSON 生成(或至少把 20% 改成 18%),
        docs drift 检查从 warn 升 error;<strong>X-3</strong> 在 CI 加"产物 jar 不含{" "}
        <Code>com/terraformersmc</Code>"断言。
      </>
    ),
  },
  {
    sev: "低",
    text: (
      <>
        <strong>G-2 回归容器约定:</strong>QUICK_MOVE 特判迁回 <Code>quickMoveStack</Code> +{" "}
        <Code>Slot#mayPickup</Code>,修复与背包整理类模组的兼容面;
        <strong>X-2</strong> 给测试专用包装标 <Code>@VisibleForTesting</Code>。
      </>
    ),
  },
];

export default function Critique() {
  return (
    <div className="space-y-8">
      <Card className="bg-gradient-to-r from-slate-900/80 to-emerald-950/40">
        <h1 className="text-2xl font-extrabold text-slate-50">中肯的怀疑与建议</h1>
        <p className="mt-2 text-sm leading-relaxed text-slate-300">
          这一页刻意唱反调:前半部分质疑<strong>设计本身</strong>(不是实现错误,而是"这样设计真的对吗"),
          每条都附可落地的修补方案;后半部分汇总技术修复清单。基调先说明:
          之所以值得这样吹毛求疵,正因为这个仓库的工程质量撑得起认真对待。
        </p>
      </Card>

      <section>
        <SectionTitle icon="🤨" title="对设计的怀疑(附方案)" />
        <div className="space-y-3">
          <Suggestion
            id="S-1"
            title="「4 词条漏洞」让抄错机制对知情玩家近似不存在"
            doubt={
              <>
                <p>
                  抄错仅在「无限 + 其他词条 &gt; 3」时触发。最优策略一目了然:N 本
                  「无限 + 恰好 3 词条」母本 —— 零磨损、零抄错、全覆盖。
                  于是这个机制实际惩罚的只有<em>不读 Wiki 的玩家</em>,
                  对照设计目标("给超级书定价")恰好打空。
                </p>
                <p>
                  更尖锐地说:当一个"限制"存在严格占优的绕行路径时,它产生的不是平衡,
                  而是信息税。
                </p>
              </>
            }
            fix={
              <>
                <p>
                  三选一(可叠加):① 抄错强度改按<strong>范围内零磨损母本总数</strong>缩放,
                  而非单册词条数 —— 书墙里无限书越多越吵,拆书不再是免费午餐;
                  ② 无限免磨损降格为<strong>磨损大减免</strong>(如 −75%),保留微量损耗,
                  让温养机制对无限书仍有意义;③ 保持现状但把"拆书规避"写成明牌教学
                  (秘典页直说),把信息税变成教学内容 —— 若设计初衷就是引导策展书墙,
                  这是最低成本的自洽方案。
                </p>
              </>
            }
          />

          <Suggestion
            id="S-2"
            title="18% 封顶 × 70% 仅掉级 × 零磨损重试 = 期望威慑不足"
            doubt={
              <>
                <p>
                  对铁了心用超级书的玩家:抄错期望约等于 18% 返工率,且 70% 的失败只是掉一级、
                  母本不掉耐久可立刻重抄。实际有效惩罚 ≈ 每 100 次拓印多花 ~18 次操作 +
                  0.9 次诅咒清洗。这更像消费税,不像威慑。
                </p>
              </>
            }
            fix={
              <>
                <p>
                  引入<strong>「过热」累积</strong>:同一超载母本连续触发抄错时,
                  下次抄错概率与恶性分支占比递增,冷却随温养周期回落 ——
                  偶尔用超级书无感,拿它当量产主力则成本陡升。
                  同时让抄错时<strong>不退还材料</strong>(现在的返工只花时间),
                  把时间税升级为资源税。两改都只动 <Code>library_resonance.json</Code>{" "}
                  现有 schema 可承载的数值层,不碰代码结构。
                </p>
              </>
            }
          />

          <Suggestion
            id="S-3"
            title="四类书架计数 × 六档阈值:概念复杂度已超出可心算范围"
            doubt={
              <>
                <p>
                  普通书架 W / 空雕纹 E / 有书雕纹 C / 广义书架 S 四个计数器,
                  分别门控不同机制,阈值散布在 12/16/27/32/38/42 —— 不翻秘典无法推断
                  "我现在差几个书架解锁什么"。复杂度本身可以是深度,
                  但<em>不可见的</em>复杂度只会流失玩家。
                </p>
              </>
            }
            fix={
              <>
                <p>
                  界面常驻一块<strong>「生效计数面板」</strong>:当前 W / S 实际值 +
                  距下一档还差几个 + 哪条机制被哪个计数门控(现在只有粒子与 1 秒刷新暗示)。
                  数据已经全部在 <Code>LiveShelfStatePayload</Code> 里同步到了客户端,
                  缺的只是一个把它画出来的 HUD —— 纯客户端改动,收益/成本比极高。
                </p>
              </>
            }
          />

          <Suggestion
            id="S-4"
            title="温养按墙上钟回复:挂机与多人共享下边际成本趋零"
            doubt={
              <>
                <p>
                  母本耐久按游戏日自动回复(38 架 10 日 / 42 架 3 日,超出后保底 1.5 日),
                  与附魔台实际使用强度完全无关。单人生存里这是优雅的"休耕"节奏;
                  但在常开服务器上,时间白送 —— 多玩家共享一面满配书墙时,
                  人均磨损成本可以摊到接近零,磨损经济在服务器语境下退化为摆设。
                </p>
              </>
            }
            fix={
              <>
                <p>
                  回复速率与「上一周期内该书墙的拓印次数」负相关(用得越狠回得越慢),
                  或给温养加 per-player 受益冷却。配置键已有 schema 容身之处
                  (<Code>library_resonance.json</Code> 的 regeneration 节),
                  默认值可保持单人友好、提供服务器预设。
                </p>
              </>
            }
          />

          <Suggestion
            id="S-5"
            title="wire 协议 14 次修订:震荡本身是个信号"
            doubt={
              <>
                <p>
                  频道名后缀一路 bump 到 revision_14,说明费用表 wire 格式在这个移植周期内
                  平均每次功能迭代都要破坏一次兼容。每次 bump 都要人肉维护手写
                  write/read 对称 + 探针退役政策 + 握手链(N-1 正是这条流水线上掉的链环)。
                </p>
              </>
            }
            fix={
              <>
                <p>
                  两步走:短期把探针表与握手链合一(数组驱动);中期把 payload 改声明式
                  codec 组合 + 可选字段段(新字段带默认值追加在尾段),
                  让"加一个配置项"不再必然等于"破一次协议"。
                </p>
              </>
            }
          />
        </div>
      </section>

      <section>
        <SectionTitle icon="🧰" title="技术修复清单(映射审计编号,按优先级)" />
        <Card>
          <ul className="space-y-3">
            {techFixes.map((f, i) => (
              <li key={i} className="flex items-start gap-3 text-sm leading-relaxed text-slate-300">
                <SevBadge sev={f.sev} />
                <span>{f.text}</span>
              </li>
            ))}
          </ul>
        </Card>
      </section>

      <section>
        <SectionTitle icon="🏁" title="结语" />
        <Callout tone="emerald" title="总体评价">
          <p>
            这是一个罕见地把"自我审计"做成工程习惯的社区移植:代码里有带编号的审计标注与翻车史、
            数值有守恒测试、默认值有单一事实源门禁、死代码有成文退役政策、CI 在不可联网的开发沙箱约束下
            仍然闭环。本报告的全部批评 —— 一个真实的握手缺口、几处硬编码口径、一个软得可以商榷的抄错税率、
            一面需要 HUD 的复杂度之墙 —— 都建立在"它值得被按高标准对待"的前提上。
            修掉 N-1,拧半圈 S-1/S-2 的默认值,把 S-3 的面板画出来,这个移植就不只是能用,而是能当范本。
          </p>
        </Callout>
      </section>
    </div>
  );
}
