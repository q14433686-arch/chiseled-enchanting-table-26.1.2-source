import { Card, Code, Callout, SectionTitle, FileRef } from "../components/ui";

const stats = [
  { label: "Java 源文件", value: "106", note: "main / client / test 三源集" },
  { label: "Java 总行数", value: "≈37,500", note: "含 6 个纯 JVM 测试套件" },
  { label: "活跃 Mixin", value: "13", note: "defaultRequire: 1,失败即炸" },
  { label: "Wire 协议修订", value: "rev 14", note: "频道名内嵌 revision 后缀" },
  { label: "语言文件", value: "11", note: "CI 做 key 对齐校验" },
  { label: "静态 CI 门", value: "PASS", note: "本次审计实际复跑通过" },
];

const verdicts = [
  { sev: "高", n: 1, color: "text-red-400" },
  { sev: "中", n: 6, color: "text-amber-400" },
  { sev: "低", n: 11, color: "text-sky-400" },
  { sev: "信息", n: 6, color: "text-slate-400" },
  { sev: "正面", n: 9, color: "text-emerald-400" },
];

export default function Overview() {
  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-indigo-950/80 via-slate-900/70 to-purple-950/60">
        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
          <span className="rounded-full bg-purple-500/20 px-2.5 py-1 font-semibold text-purple-300 ring-1 ring-purple-400/30">
            审计对象
          </span>
          <span className="font-mono">
            q14433686-arch/chiseled-enchanting-table-26.1.2-source
          </span>
          <span className="font-mono text-slate-500">@ arena/2d61e52c-chiseled-enchanting-table-26-1</span>
        </div>
        <h1 className="mt-3 text-2xl font-extrabold text-slate-50 sm:text-3xl">
          纂刻附魔台(26.1.2 非官方移植)· 全路径源码审计
        </h1>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-slate-300">
          本报告基于对该分支的完整克隆与逐文件抽样精读,沿
          <strong className="text-indigo-300">
            「源码 API · 数据编解码 · 网络同步 · GUI 输入 · Mixin 注入 · 死代码 · 耦合风险」
          </strong>
          七条路径重新审计,附加「硬编码清单」与「数值 / 机制设计合理性」两条横切维度;并对社区中
          「增益与限制自相矛盾」「无限超级书赚麻」两类论调给出回应,以及一页中肯的怀疑与建议。
        </p>
        <div className="mt-4 flex flex-wrap gap-4">
          {verdicts.map((v) => (
            <div key={v.sev} className="flex items-baseline gap-1.5">
              <span className={`text-2xl font-extrabold ${v.color}`}>{v.n}</span>
              <span className="text-xs text-slate-400">{v.sev}级发现</span>
            </div>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {stats.map((s) => (
          <Card key={s.label} className="!p-4 text-center">
            <p className="text-xl font-extrabold text-indigo-300">{s.value}</p>
            <p className="mt-1 text-xs font-semibold text-slate-300">{s.label}</p>
            <p className="mt-0.5 text-[11px] leading-tight text-slate-500">{s.note}</p>
          </Card>
        ))}
      </div>

      <Card>
        <SectionTitle
          icon="🧭"
          title="总体判断"
          subtitle="先说结论,再看细节 —— 细节都在「技术审计」页"
        />
        <div className="space-y-3 text-sm leading-relaxed text-slate-300">
          <p>
            这是一个<strong className="text-emerald-300">工程纪律显著高于社区平均水平</strong>的移植仓库:
            代码内嵌自家审计编号(<Code>NET-03</Code>、<Code>MX-04</Code>、<Code>R-01</Code>、<Code>DEAD-03</Code>…)并在注释里解释历史翻车与修复;
            XP 公式带<strong>伸缩守恒测试</strong>(对 <Code>maxLevel = 1..255</Code> 全量验证{" "}
            <Code>V[k] − V[j] ≤ Cost_min(j→k)</Code>);数值默认值有{" "}
            <Code>BundledDefaults ≡ datapack JSON</Code> 的 CI 一致性门;网络层对入站长度/等级/标识符做了统一上界校验;
            静态门脚本在本次审计环境中<strong>实际复跑通过</strong>(<Code>compat_check: PASS</Code>、
            <Code>ci_static_checks: PASS</Code>)。
          </p>
          <p>
            但它并非无懈可击。本次审计最实质的发现是一个
            <strong className="text-red-300">网络握手缺口(N-1)</strong>:协议文件声明了 rev 11/12/13 三个旧频道探针,
            但服务端"对端装了本模组吗"的检查链止步于 rev 10 —— 运行这三个修订版本的旧客户端连入 rev 14 服务器时,
            既不会被优雅断连,也收不到费用表,表现为<em>静默半残</em>,恰恰违背了它自己写在注释里的 DEAD-03 退役政策。
            其余发现多为硬编码口径、版本脆弱点、轮询开销与文档数值漂移,详见审计页。
          </p>
          <p>
            数值与机制设计上,「无限零磨损 × 超载抄错 ≤18% × 强跳退化 ≤70%」构成一个刻意的三角对冲,
            设计意图自洽(见「争议回应」页);但存在一个真实的策略洼地 ——{" "}
            <strong className="text-amber-300">「4 词条漏洞」</strong>:无限 + 恰好 3 条其他词条的母本,
            同时享受零磨损与零抄错。这是"软约束设计"的必然代价还是需要修补的缺口,在「怀疑与建议」页展开。
          </p>
        </div>
      </Card>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <SectionTitle icon="🔬" title="审计方法" />
          <ul className="space-y-2 text-sm text-slate-300">
            <li className="flex gap-2">
              <span className="text-indigo-400">①</span>
              <span>
                完整浅克隆分支,统计源集结构;对 <Code>menu/</Code>、<Code>mechanics/</Code>、
                <Code>mixin/</Code>、<Code>config/</Code>、<Code>gui/</Code> 五个高风险包精读关键文件全文。
              </span>
            </li>
            <li className="flex gap-2">
              <span className="text-indigo-400">②</span>
              <span>
                正则横扫:硬编码标识符(<Code>minecraft:</Code> 字面量)、魔法数字、<Code>TODO/FIXME</Code>、
                探针常量引用图、<Code>@Shadow</Code> 私有字段、显式方法描述符。
              </span>
            </li>
            <li className="flex gap-2">
              <span className="text-indigo-400">③</span>
              <span>
                实际运行仓库自带静态门(<Code>compat_check.py</Code>、<Code>ci_static_checks.py</Code>)
                验证其自检体系的真实性,而非仅凭 README 声称。
              </span>
            </li>
            <li className="flex gap-2">
              <span className="text-indigo-400">④</span>
              <span>
                对照 <Code>docs/WIKI.md</Code> 宣称数值与 <Code>BundledDefaults.java</Code> /
                datapack JSON 实际默认值,查找文档—代码漂移。
              </span>
            </li>
          </ul>
          <p className="mt-3 text-xs text-slate-500">
            限制声明:无法在审计环境内对 MC 26.1.2 运行时做动态验证(该版本 jar 不可得,与仓库 CI 的处境相同),
            所有运行时行为推断均基于代码阅读与其 CI 绿色记录。
          </p>
        </Card>

        <Card>
          <SectionTitle icon="📦" title="仓库自带的防线(值得点名)" />
          <ul className="space-y-2.5 text-sm text-slate-300">
            <li className="flex gap-2">
              <span className="text-emerald-400">✓</span>
              <span>
                <strong>入站防御纪律:</strong>所有长度前缀经{" "}
                <Code>PayloadLimits.readBoundedCount</Code> 界限检查,负数即抛;等级封顶 255、标识符 512 字符、
                token 64 字符,在 record 紧凑构造器里做而非埋进业务逻辑。
              </span>
            </li>
            <li className="flex gap-2">
              <span className="text-emerald-400">✓</span>
              <span>
                <strong>生命周期纪律:</strong>静态 per-player 状态(重开节流表、费用表缓存)均挂{" "}
                <Code>DISCONNECT</Code> + <Code>SERVER_STOPPED</Code> 清理,长跑服务器不积内存。
              </span>
            </li>
            <li className="flex gap-2">
              <span className="text-emerald-400">✓</span>
              <span>
                <strong>信任边界正确:</strong>客户端点击只发意图,服务端{" "}
                <Code>applyEnchantementConditionWithReceipt</Code> 重算 XP 与材料束、先验后扣,创造模式单独分支。
              </span>
            </li>
            <li className="flex gap-2">
              <span className="text-emerald-400">✓</span>
              <span>
                <strong>Mixin 修复有记忆:</strong>铁砧 <Code>createResult</Code> 曾因 HEAD/RETURN
                注入对在异常路径吞玩家书堆(M-07),已改为 <Code>@WrapMethod</Code> + <Code>try/finally</Code>,
                并把修复原因写进 Javadoc。
              </span>
            </li>
            <li className="flex gap-2">
              <span className="text-emerald-400">✓</span>
              <span>
                <strong>worldgen 死锁修复:</strong>书架填充从 worldgen 工作线程挪到{" "}
                <Code>postProcessGeneration</Code>(主线程、FULL 之后),注入点选择(HEAD 而非 TAIL)
                的理由在注释里论证到了原版实现细节级别。
              </span>
            </li>
          </ul>
          <div className="mt-3 flex flex-wrap gap-1.5">
            <FileRef>menu/PayloadLimits.java</FileRef>
            <FileRef>menu/EnchantCostSync.java</FileRef>
            <FileRef>mixin/anvil/RemoveEnchantMerge.java</FileRef>
            <FileRef>mixin/structure/LevelChunkPostProcessMixin.java</FileRef>
          </div>
        </Card>
      </div>

      <Callout tone="indigo" title="如何读这份报告">
        <p>
          「技术审计」页按七条路径 + 两条横切维度组织,每条发现有编号、严重度、涉及文件与建议;
          「争议回应」页回应两类常见论调并给出期望值计算;「怀疑与建议」页是刻意唱反调的部分 ——
          包括对设计本身(而不只是实现)的质疑。严重度口径:
          <strong className="text-red-300">高</strong>=影响真实玩家且难排查;
          <strong className="text-amber-300">中</strong>=有条件触发或维护性风险;
          <strong className="text-sky-300">低</strong>=打磨项;
          <strong className="text-slate-300">信息</strong>=中性事实;
          <strong className="text-emerald-300">正面</strong>=值得保留并推广的做法。
        </p>
      </Callout>
    </div>
  );
}
