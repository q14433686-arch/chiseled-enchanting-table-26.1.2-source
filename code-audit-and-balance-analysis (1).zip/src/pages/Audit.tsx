import { Card, Code, Callout, Finding, SectionTitle } from "../components/ui";

export default function Audit() {
  return (
    <div className="space-y-8">
      <Card className="bg-gradient-to-r from-slate-900/80 to-indigo-950/50">
        <h1 className="text-2xl font-extrabold text-slate-50">技术审计:七路径 + 两横切</h1>
        <p className="mt-2 text-sm leading-relaxed text-slate-300">
          路径顺序:源码 API / 硬编码 → 数据编解码 → 网络同步 → GUI 输入 → Mixin 注入 → 死代码 →
          耦合风险;最后是版本脆弱点与数值设计评估。全部发现均给出文件定位与可操作建议。
        </p>
      </Card>

      {/* ---- 1 源码 API 与硬编码 ---- */}
      <section>
        <SectionTitle
          icon="🔩"
          title="路径一 · 源码 API 与不应硬编码之处"
          subtitle="大多数数值已数据驱动且有 CI 一致性门;剩下的硬编码集中在网络层与时间常数"
        />
        <div className="space-y-3">
          <Finding
            id="H-1"
            sev="中"
            title="重开菜单的交互距离硬编码为 64.0D(8 格)平方距离"
            files={["menu/EnchantingNetworking.java"]}
          >
            <p>
              <Code>ReopenTablePayload</Code> 校验{" "}
              <Code>player.distanceToSqr(...) &gt; 64.0D</Code> 即拒绝。26.x 中玩家交互距离已经属性化
              (<Code>block_interaction_range</Code> 可被信标类/模组效果修改),硬编码 8 格会误拒
              合法的远触及玩家;且与原版容器 <Code>stillValid</Code> 的口径(基于属性 + 容差)不一致 ——
              同一玩家可能"菜单还开着却不许重开"。
            </p>
            <p className="text-slate-400">
              建议:改读玩家交互距离属性并加原版同款容差;顺带把 <Code>10L</Code> tick
              的重开节流窗口提为具名常量或配置项。
            </p>
          </Finding>

          <Finding
            id="H-2"
            sev="低"
            title="方块实体 ID 字符串字面量,未从注册表派生"
            files={["mechanics/structure/BookshelfBookFiller.java:134"]}
          >
            <p>
              <Code>BOOKSHELF_BLOCK_ENTITY_ID = "minecraft:chiseled_bookshelf"</Code>{" "}
              以裸字符串写死用于 NBT 结构处理。若原版更名(历史上发生过 BE ID 调整)将静默失配而非编译期报错。
              建议由 <Code>BlockEntityType.CHISELED_BOOKSHELF</Code> 的注册键派生。
            </p>
          </Finding>

          <Finding
            id="H-3"
            sev="低"
            title="协议不匹配断连消息:英文硬编码 + 内嵌版本号,不可本地化"
            files={["menu/EnchantingProtocol.java"]}
          >
            <p>
              <Code>MISMATCH_MESSAGE</Code> 是模组里唯一一处面向玩家却绕过 11 语言体系的文案,还把{" "}
              <Code>"26.1.2"</Code> 写进字符串 —— <Code>consistency.yml</Code> 的"版本只改一处漏四处"
              门恰恰管不到这里。断连时客户端已握手,可用 <Code>Component.translatable</Code>(带英文回落)。
            </p>
          </Finding>

          <Finding
            id="H-4"
            sev="低"
            title="仪式数学的时间常数硬编码,与同函数内已配置化的封顶值口径不一"
            files={["mechanics/ritual/InscriptionRitualMechanics.java:781,806"]}
          >
            <p>
              献祭 XP 与强跳退化概率曲线用 <Code>exp(−remSeconds / 240.0)</Code>、
              <Code>exp(−remSeconds / 210.0)</Code> 饱和 —— 封顶值(50%/70%/18%/15 级)全部走{" "}
              <Code>BundledDefaults</Code> + datapack,唯独曲线斜率写死。调封顶不调斜率,
              实际手感变化可能与数据包作者预期不符。
            </p>
          </Finding>

          <Finding
            id="H-5"
            sev="信息"
            title="PayloadLimits 的字节预算是启发式估算,依赖「成本物品无自定义组件」假设"
            files={["menu/PayloadLimits.java"]}
          >
            <p>
              <Code>96 B/行、96 B/栈、900,000 B 总预算</Code>(对照原版 1,048,576 上限)。注释自认
              "plain cost stacks carry no custom components" —— 数据包若配置带大组件的成本物品,
              估算会偏小。见 D-2 的实测建议。
            </p>
          </Finding>

          <Finding
            id="H-6"
            sev="正面"
            title="数值默认值单一事实源:BundledDefaults ≡ datapack JSON,由 CI 门强制"
            files={["BundledDefaults.java", "scripts/ci_static_checks.py"]}
          >
            <p>
              本次审计实际复跑 <Code>ci_static_checks.py</Code>,其中{" "}
              <Code>"BundledDefaults.java matches datapack JSON (single source of truth)"</Code>{" "}
              检查通过。绝大多数可平衡数值(磨损、减免、阈值、概率封顶)确实做到了数据驱动 ——
              这正是上面几条硬编码显得刺眼的原因:体系内的例外。
            </p>
          </Finding>
        </div>
      </section>

      {/* ---- 2 数据编解码 ---- */}
      <section>
        <SectionTitle
          icon="🧬"
          title="路径二 · 数据编解码"
          subtitle="入站防御扎实;风险在手写对称性与巨型 record"
        />
        <div className="space-y-3">
          <Finding
            id="D-1"
            sev="中"
            title="EnchantCostTablePayload:约 30 字段巨型 record,手写 write/read 对称,字段顺序即协议"
            files={["menu/EnchantCostTablePayload.java (733 行)"]}
          >
            <p>
              编解码为手写镜像函数,任何一次插字段插错位置都不会在编译期暴露,只会在运行期读歪 ——
              频道名后缀已经演进到 <Code>revision_14</Code>,侧面说明 wire 格式仍在高频震荡,
              每次震荡都要人肉维护两份顺序。
            </p>
            <p className="text-slate-400">
              建议:拆为嵌套子结构并改用 <Code>StreamCodec.composite</Code> 声明式组合
              (自动对称),或至少为 write→read round-trip 增加覆盖全部字段的单测
              (现有 <Code>NetworkCompatibilityTest</Code> 只覆盖部分路径)。
            </p>
          </Finding>

          <Finding
            id="D-2"
            sev="低"
            title="字节预算靠估不靠测:建议用 writerIndex 实测替代 per-row 估算"
            files={["menu/EnchantCostTablePayload.java", "menu/PayloadLimits.java"]}
          >
            <p>
              成本表构建端以 <Code>ESTIMATED_BYTES_PER_ROW/STACK</Code> 估算截断(R-01)。
              由于 <Code>ItemStack.OPTIONAL_STREAM_CODEC</Code> 全组件上送,估算与实际的偏差上不封顶。
              更稳的做法是边写边读 <Code>buf.writerIndex()</Code>,超预算即回滚最后一行 —— 零估算误差。
            </p>
          </Finding>

          <Finding
            id="D-3"
            sev="正面"
            title="解码端统一上界校验,负数长度即抛;枚举 token 走 fromToken 白名单"
            files={["menu/PayloadLimits.java", "menu/ChiseledEnchantingMenuPayloads.java"]}
          >
            <p>
              等级封顶 255(0 为 DISENCHANT_ALL 哨兵)、标识符 ≤512、token ≤64、集合 ≤65,536,
              且在 record 紧凑构造器中强制(NET-03)—— 恶意长度前缀无法触发大分配。
              这是很多大型模组都没做到的入站纪律。
            </p>
          </Finding>
        </div>
      </section>

      {/* ---- 3 网络同步 ---- */}
      <section>
        <SectionTitle
          icon="📡"
          title="路径三 · 网络同步"
          subtitle="本次审计最实质的发现在这里"
        />
        <div className="space-y-3">
          <Finding
            id="N-1"
            sev="高"
            title="握手缺口:rev 11/12/13 探针已声明,但 peerHasAnyCostChannel 检查链止于 rev 10"
            files={["menu/EnchantingProtocol.java", "menu/EnchantCostSync.java:36-43"]}
          >
            <p>
              <Code>EnchantingProtocol</Code> 为 rev 4~13 保留了查询用旧频道常量,注释(DEAD-03)明言
              保留目的是"让 JOIN 握手能优雅断连过期对端,而非之后裸解码报错"。但{" "}
              <Code>EnchantCostSync.peerHasAnyCostChannel()</Code> 的 <Code>canSend</Code> 链实际只查到{" "}
              <Code>REVISION_10_COST_TYPE</Code>:
            </p>
            <pre className="overflow-x-auto rounded-lg bg-slate-950/80 p-3 font-mono text-xs leading-relaxed text-slate-300 ring-1 ring-slate-700/50">
{`// EnchantCostSync.java — 链在 rev 10 截止
|| ServerPlayNetworking.canSend(player, EnchantingProtocol.REVISION_9_COST_TYPE)
|| ServerPlayNetworking.canSend(player, EnchantingProtocol.REVISION_10_COST_TYPE);
// EnchantingProtocol.java 中声明却从未被引用:
REVISION_11_COST_TYPE / REVISION_12_COST_TYPE / REVISION_13_COST_TYPE`}
            </pre>
            <p>
              后果:运行 rev 11~13 构建的客户端连入 rev 14 服务器,服务端判定"对端没装本模组"→{" "}
              <Code>incompatible()</Code> 返回 false → 不断连、不发费用表。玩家进服后附魔台界面
              <strong>静默半残</strong>(无费用、无变换行),比直接断连难排查一个数量级 ——
              恰好落入该模组自己在注释里警告过的失败模式。
            </p>
            <p className="text-slate-400">
              建议:把 11~13 补进链(若这三个修订曾公开发布),或按政策删除常量并在 CHANGELOG
              声明放弃兼容;更根本地,把探针列表收进一个数组常量,让检查链自动等于声明表,
              结构上消灭"声明了忘了查"这类漂移。
            </p>
          </Finding>

          <Finding
            id="N-2"
            sev="中"
            title="每秒全服轮询重建变换展示表,与玩家是否在用附魔台无关"
            files={["menu/EnchantCostSync.java:75-82"]}
          >
            <p>
              <Code>END_SERVER_TICK</Code> 每 20 tick 对每个在线玩家调用{" "}
              <Code>buildTransformationDisplays(player)</Code> 再与缓存 diff,相同才不发包。
              构建成本 O(变换表 × 玩家数),空载服务器也常转。数据包重载与配置变更已各有专用钩子,
              这条轮询只为兜底"散户状态变化",性价比存疑。
            </p>
            <p className="text-slate-400">
              建议:改为事件驱动失效(解锁进度/配置变更时打脏标),或至少只对
              "打开着纂刻附魔台菜单的玩家"轮询。
            </p>
          </Finding>

          <Finding
            id="N-3"
            sev="低"
            title="apply 通道无节流,每次服务端处理先做 244 格书架重扫"
            files={["menu/EnchantingNetworking.java", "menu/ChiseledEnchantingTableScreenHandler.java"]}
          >
            <p>
              <Code>ReopenTablePayload</Code> 有 10 tick 节流,但{" "}
              <Code>ApplyEnchantmentPayload</Code> 没有 —— 虽然服务端重验证让垃圾请求无法白嫖物品,
              每个入站包仍会先执行 <Code>refreshLiveShelfState()</Code>(7×5×7 = 244 格扫描 +
              雕纹书架槽位遍历)。恶意客户端可用无效 payload 白嫖服务器扫描成本。建议同款 per-tick 节流。
            </p>
          </Finding>

          <Finding
            id="N-4"
            sev="正面"
            title="接收端纪律完整:主线程调度、containerId 绑定、stillValid、会话号校验、生命周期清理"
            files={["menu/EnchantingNetworking.java", "menu/EnchantCostSync.java"]}
          >
            <p>
              全部 serverbound receiver 走 <Code>server.execute</Code>;SkipRitual 额外校验{" "}
              <Code>ritualSession()</Code> 防跨会话重放;<Code>LAST_DISPLAYS</Code> 用 WeakHashMap +
              显式 DISCONNECT 清理双保险;<Code>sendTo</Code> 把异常吞成 warn,"展示性同步永不打断加入流程"
              的取舍标注清晰。
            </p>
          </Finding>
        </div>
      </section>

      {/* ---- 4 GUI 输入 ---- */}
      <section>
        <SectionTitle
          icon="🖱️"
          title="路径四 · GUI 输入"
          subtitle="信任边界正确;非标准 QUICK_MOVE 路径是主要兼容面"
        />
        <div className="space-y-3">
          <Finding
            id="G-1"
            sev="正面"
            title="客户端只发意图,服务端先验后扣:XP 与材料束重算、收据模式、创造分支分离"
            files={["menu/ChiseledEnchantingTableScreenHandler.java:2650-2744"]}
          >
            <p>
              <Code>applyEnchantementConditionWithReceipt</Code> 返回{" "}
              <Code>PaymentReceipt(accepted, paidXpPoints, paidCopies)</Code>,扣费前重查{" "}
              <Code>findMatchingAffordableCostBundle</Code>;锁定母本(TomeLock)在 apply
              入口统一拦截。客户端 UI 状态不参与任何授权决策。
            </p>
          </Finding>

          <Finding
            id="G-2"
            sev="低"
            title="clicked() 重写 QUICK_MOVE 为「复制→清槽→插背包」,绕开原版 quickMoveStack 约定"
            files={["menu/ChiseledEnchantingTableScreenHandler.java:2747+"]}
          >
            <p>
              行为上合理(仪式进行中禁 shift 取目标槽),但绕开 <Code>quickMoveStack</Code>{" "}
              意味着任何 hook 该约定的模组(背包整理、物流类)在此容器失效或行为不一致;
              且自定义插入路径需要自己保证与 <Code>setChanged</Code> 的时序。建议尽量回归原版约定,
              把"仪式锁"做进 <Code>Slot#mayPickup</Code>。
            </p>
          </Finding>

          <Finding
            id="G-3"
            sev="信息"
            title="法式拼写 API 名(Enchantement)已成公共约定,改名即破坏面"
            files={["gui/EnchantementListWidget.java", "menu/…applyEnchantement()"]}
          >
            <p>
              上游遗留拼写被网络层、JEI/REI 适配层、测试套件广泛引用。这是"约定债":
              不值得为正字法冒破坏风险,但新增 API 不应再延续该拼写,避免两套并存。
            </p>
          </Finding>
        </div>
      </section>

      {/* ---- 5 Mixin ---- */}
      <section>
        <SectionTitle
          icon="💉"
          title="路径五 · Mixin 注入(含对 26.1.2 的版本脆弱点)"
          subtitle="13 个 mixin,defaultRequire:1 —— 失败即炸是正确选择;脆弱点集中在铁砧与结构两组"
        />
        <div className="space-y-3">
          <Finding
            id="M-1"
            sev="中"
            title="RemoveEnchantMerge:@Shadow 私有字段 + 依赖原版 onTake 语义细节,是对小版本重构最敏感的一块"
            files={["mixin/anvil/RemoveEnchantMerge.java"]}
          >
            <p>
              该 mixin <Code>@Shadow</Code> 了 <Code>AnvilMenu</Code> 私有字段{" "}
              <Code>cost</Code> / <Code>onlyRenaming</Code>,并依赖
              "右槽非空且不贡献附魔成本时 <Code>onlyRenaming==true</Code> 但 onTake 仍清左槽"
              这一实现细节(M-07 修复的由来)。26.x 任何一次 AnvilMenu 内部重构都可能让
              这些假设过期 —— 字段消失会炸(好),<em>语义</em>漂移不会炸(坏)。
              建议为 M-07 场景补一个 CI 可跑的行为级测试锚点。
            </p>
          </Finding>

          <Finding
            id="M-2"
            sev="中"
            title="LevelChunkPostProcessMixin:显式描述符 + 依赖「原版循环内 clear 列表」的实现细节"
            files={["mixin/structure/LevelChunkPostProcessMixin.java"]}
          >
            <p>
              目标 <Code>postProcessGeneration(Lnet/minecraft/server/level/ServerLevel;)V</Code>,
              HEAD 注入的正确性建立在"vanilla 在 TAIL 前已排空 postProcessing 列表"之上(注释有完整论证)。
              签名变化会被 <Code>require:1</Code> 兜住;但若原版改为<em>复制后清空</em>或改打包编码,
              注入点仍在、书架却静默漏填。<Code>ProtoChunk.unpackOffsetCoordinates</Code>{" "}
              的选用(用原版自己的解包器)已经是对后者的正确防御,值得肯定。
            </p>
          </Finding>

          <Finding
            id="M-3"
            sev="低"
            title="ReloadableServerRegistries.reload 参数表是 MC 大小版本间的高频变动区"
            files={["mixin/loot/ReloadableServerRegistriesMixin.java"]}
          >
            <p>
              该方法签名(LayeredRegistryAccess / PendingTags / Executor…)在 1.21.x → 26.x
              间已多次变化,是未来跟版的第一批适配点。注入体只做 <Code>preloadForLootRegistries</Code>{" "}
              预载,逻辑解耦良好,断了也易修 —— 风险在于必须有人记得修。
            </p>
          </Finding>

          <Finding
            id="M-4"
            sev="低"
            title="VillagerInfinitySanitizeMixin 挂在 getOffers() RETURN:全路径覆盖,但每次调用都跑"
            files={["mixin/villager/VillagerInfinitySanitizeMixin.java"]}
          >
            <p>
              从 UseEntityCallback 改到 getOffers RETURN 修复了"生成即暴露"的绕过(流浪商人、程序化开单),
              代价是每次开交易界面/序列化都重消毒。幂等、有配置门控、客户端侧判空 —— 正确但非最省;
              若原版提供 offers 生成后事件,可迁移。
            </p>
          </Finding>

          <Finding
            id="M-5"
            sev="低"
            title="wrapCreateResult 恢复计数用引用相等(current == left),第三方替换实例时不恢复"
            files={["mixin/anvil/RemoveEnchantMerge.java"]}
          >
            <p>
              方向安全(不会污染新实例),但如果另一 mixin 在 <Code>createResult</Code> 中换掉槽内{" "}
              <Code>ItemStack</Code> 实例,被压成 1 的原栈不被恢复。极边角,记录在案即可。
            </p>
          </Finding>

          <Finding
            id="M-6"
            sev="正面"
            title="Mixin 工程面:全量注册校验入 CI、JAVA_25 兼容级显式声明、修复史写入 Javadoc"
            files={["chiseled-enchanting-table-port.mixins.json", "scripts/ci_static_checks.py"]}
          >
            <p>
              CI 静态门校验"mixin 配置可解析 + 已注册 mixin 未被排除";<Code>defaultRequire: 1</Code>{" "}
              确保任何注入失败在启动期爆炸而非运行期静默。MX-04/M-07 的翻车-修复链条完整记录在注释里,
              后来者可追溯。
            </p>
          </Finding>
        </div>
      </section>

      {/* ---- 6 死代码 ---- */}
      <section>
        <SectionTitle
          icon="🪦"
          title="路径六 · 死代码"
          subtitle="有成文的退役政策是亮点;问题恰恰是政策执行出了缺口"
        />
        <div className="space-y-3">
          <Finding
            id="X-1"
            sev="中"
            title="rev 11/12/13 探针常量:零引用,是「声明性死代码」—— 与 N-1 同一问题的两面"
            files={["menu/EnchantingProtocol.java"]}
          >
            <p>
              全仓库检索确认这三个常量除声明外无任何引用。按其 DEAD-03 政策,"公开发布过的 revision
              的探针必须保留<em>并参与握手</em>";现在是保留了、没参与。二选一:补进检查链,或删除并记录。
              悬在中间是最差状态 —— 它让读者误以为兼容性被覆盖了。
            </p>
          </Finding>

          <Finding
            id="X-2"
            sev="低"
            title="applyEnchantementCondition(payload) 薄包装疑似仅存测试用途"
            files={["menu/ChiseledEnchantingTableScreenHandler.java:2646"]}
          >
            <p>
              生产路径已全部走 <Code>WithReceipt</Code> 版本。保留无妨,但应标注{" "}
              <Code>@VisibleForTesting</Code> 或下沉到测试辅助,避免未来贡献者误用
              无收据版本做扣费(会丢失支付审计信息)。
            </p>
          </Finding>

          <Finding
            id="X-3"
            sev="信息"
            title="Vendored ModMenu API 编译桩:非常规但有防线"
            files={["src/client/java/com/terraformersmc/modmenu/api/*", "build.gradle:158-159"]}
          >
            <p>
              仓库内联了 <Code>com.terraformersmc.modmenu.api</Code> 两个接口作编译桩
              (沙箱无法访问第三方 maven 的产物),<Code>build.gradle</Code> 用{" "}
              <Code>exclude 'com/terraformersmc/**'</Code> 保证不打进成品 jar。
              防线存在,但它只有一行 —— 换构建脚本或复制配置时极易遗漏,届时将与真 ModMenu
              产生类路径冲突。建议在 CI 加一条"产物 jar 内不得含 com/terraformersmc"断言。
            </p>
          </Finding>

          <Finding
            id="X-4"
            sev="正面"
            title="死代码有成文退役政策(DEAD-03),探针保留与否有判据而非凭感觉"
            files={["menu/EnchantingProtocol.java(注释)"]}
          >
            <p>
              "公开发布过的频道保留探针、内部修订可删"是清晰可执行的政策,配合 X-1 的修复,
              这套做法值得同类多修订模组借鉴。
            </p>
          </Finding>
        </div>
      </section>

      {/* ---- 7 耦合 ---- */}
      <section>
        <SectionTitle
          icon="🕸️"
          title="路径七 · 耦合风险"
          subtitle="god-class 拆分只完成了一半;静态全局配置贯穿双端 mixin"
        />
        <div className="space-y-3">
          <Finding
            id="C-1"
            sev="中"
            title="拆分后的 ScreenHandler 仍 2,887 行,Data 类 2,755 行 —— 菜单/经济/持久化/数据加载仍同体"
            files={[
              "menu/ChiseledEnchantingTableScreenHandler.java",
              "data/ChiseledEnchantingTableData.java",
            ]}
          >
            <p>
              2026-10-24 的 god-class split 把网络接线抽成了 <Code>EnchantingNetworking</Code>,
              但 handler 仍同时承担:槽位约束、支付经济、仪式状态机、母本页分发、箱式持久化、
              实时书架态刷新。两个 2,700+ 行类是全仓库回归风险最集中的地方 ——
              任何机制改动的 diff 都会穿过它们。
            </p>
            <p className="text-slate-400">
              建议下一刀:支付经济(<Code>resolveXpRequirement</Code> /{" "}
              <Code>findMatchingAffordableCostBundle</Code> / <Code>PaymentReceipt</Code>)独立成{" "}
              <Code>PaymentService</Code>;仪式状态机独立;handler 只剩容器职责。
            </p>
          </Finding>

          <Finding
            id="C-2"
            sev="中"
            title="ModRuntimeConfig.effective() 全局静态被双端执行的铁砧 mixin 直接读取:存在短暂双端分叉窗口"
            files={["mixin/anvil/RemoveXpCostScaling.java", "config/ModConfigNetworking.java"]}
          >
            <p>
              <Code>AnvilMenu.createResult</Code> 在客户端也跑(结果预测)。配置经{" "}
              <Code>ModConfigNetworking.sendToPlayer</Code> 在 JOIN/重载时下发,但在包到达前的窗口、
              或服务端 <Code>/reload</Code> 改配置到广播完成之间,客户端预测的铁砧结果与服务端判定可能分叉
              (显示费用闪烁/结果槽跳变)。非损坏性,但属"玄学现象"来源。
            </p>
            <p className="text-slate-400">
              建议:mixin 读取处区分 <Code>Level.isClientSide</Code>,客户端一律用"已同步快照 +
              未同步则取保守默认",并在快照未就绪时跳过干预。
            </p>
          </Finding>

          <Finding
            id="C-3"
            sev="低"
            title="包间依赖呈网状:mixin → mechanics/config 直连、menu → registry 直连"
            files={["mixin/anvil/RemoveEnchantMerge.java", "menu/EnchantingNetworking.java"]}
          >
            <p>
              <Code>RemoveEnchantMerge</Code> 以全限定名直接调用{" "}
              <Code>mechanics.resonance.TomeLockData</Code> 与 <Code>config.ModRuntimeConfig</Code>;
              注入层与机制层互相可见意味着机制重构必须同步审查注入层。建议立一个窄接口包
              (mixin 只依赖 <Code>api/</Code>,机制实现它),把"可被注入层调用的面"显式化。
            </p>
          </Finding>

          <Finding
            id="C-4"
            sev="低"
            title="文档—代码数值漂移:WIKI 宣称抄错「封顶不超过 20%」,代码默认 0.18;docs drift 检查仅 warn"
            files={["docs/WIKI.md", "BundledDefaults.java:79", "library_resonance.json:63"]}
          >
            <p>
              <Code>MAX_TRANSCRIPTION_SLIP_CHANCE = 0.18</Code>、datapack{" "}
              <Code>max_transcription_slip_chance: 0.18</Code>,而 WIKI 写"严格封顶不超过 20%"。
              18% ≤ 20% 技术上不算说谎,但对做攻略/配平的玩家是误导口径;文档就是对外 API,
              这类漂移应让 consistency 门从 warn 升为 error,或让 WIKI 数值由脚本从 JSON 生成。
            </p>
          </Finding>
        </div>
      </section>

      {/* ---- 数值设计 ---- */}
      <section>
        <SectionTitle
          icon="⚖️"
          title="横切 · 数值与机制设计合理性"
          subtitle="工程验证严谨;设计张力集中在「无限」三角对冲上"
        />
        <div className="grid gap-3 lg:grid-cols-2">
          <Card>
            <h4 className="mb-2 font-bold text-emerald-300">✓ 经得起推敲的部分</h4>
            <ul className="space-y-2 text-sm leading-relaxed text-slate-300">
              <li>
                <strong>幂律升级曲线:</strong>
                <Code>W_req = round(38·((L−1)/(M−1))^1.25)</Code>,5 级附魔台阶 0/7/16/27/38 ——
                前期便宜后期陡,与"书架是长期基建"的定位一致;γ=1.25 对 M=1..255 的模组附魔平滑外插,
                无分段断崖。
              </li>
              <li>
                <strong>XP 守恒有测试锚:</strong>全清与逐级降级满足{" "}
                <Code>V[k] − V[j] ≤ Cost_min(j→k)</Code> 的伸缩不等式,对全部 maxLevel 1..255
                归纳验证 —— "退魔返经验"不构成永动机,这在同类模组里几乎绝无仅有。
              </li>
              <li>
                <strong>减免有封顶有去重:</strong>藏书精通按{" "}
                <Code>Σ min(1, L/M)^1.25</Code> 计且同名附魔不重复计分,全局 −40% 硬顶;
                普通书架减免 12 架起步、38 架 −15% —— 两段都无法靠堆同一本书刷穿。
              </li>
              <li>
                <strong>顿悟池反普适加权:</strong>经验修补这类万金油宝藏权重被压低,
                专精型宝藏出现更均衡 —— 正确地对冲了"宝藏池被一本书垄断期望值"的经典问题。
              </li>
            </ul>
          </Card>
          <Card>
            <h4 className="mb-2 font-bold text-amber-300">⚠ 存在张力的部分(详见后两页)</h4>
            <ul className="space-y-2 text-sm leading-relaxed text-slate-300">
              <li>
                <strong>「4 词条漏洞」:</strong>抄错只对「无限 + 其他词条 &gt; 3」的超载母本生效 ——
                无限 + 恰好 3 条词条 = 零磨损 <em>且</em> 零抄错。最优解是 N 本 4 词条无限书,
                抄错机制对知情玩家近似不存在。
              </li>
              <li>
                <strong>期望惩罚偏软:</strong>抄错封顶 18%,其中 70% 只是掉一级、25% 串行垃圾、5% 串行诅咒;
                母本零磨损意味着次品可无限重试,超级书的"税率"上限约为每次 18% 的返工率。
              </li>
              <li>
                <strong>温养走墙上钟:</strong>母本耐久按游戏日自动回复(38 架 10 日 / 42 架 3 日),
                与使用强度无关 —— 挂机服白嫖回复,多人共享书墙时边际成本进一步趋零。
              </li>
              <li>
                <strong>概念复杂度:</strong>普通书架 W / 空雕纹 E / 有书雕纹 C / 广义书架 S 四类计数 ×
                阈值 12/16/27/32/38/42 × 三种消耗模式 —— 不翻秘典无法心算,学习曲线是最大留存风险。
              </li>
            </ul>
          </Card>
        </div>
        <div className="mt-3">
          <Callout tone="indigo" title="设计评议的基准线">
            <p>
              以上张力并不自动等于缺陷 —— 其中一部分是"软约束设计"的自觉取舍(见「争议回应」页的论证),
              另一部分则值得修补(见「怀疑与建议」页的具体方案)。把两者分开,才是对这套设计公平的评法。
            </p>
          </Callout>
        </div>
      </section>
    </div>
  );
}
