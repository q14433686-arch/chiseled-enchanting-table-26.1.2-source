import type { ReactNode } from "react";

export type Severity = "高" | "中" | "低" | "信息" | "正面";

const sevStyle: Record<Severity, string> = {
  高: "bg-red-500/15 text-red-300 ring-red-500/40",
  中: "bg-amber-500/15 text-amber-300 ring-amber-500/40",
  低: "bg-sky-500/15 text-sky-300 ring-sky-500/40",
  信息: "bg-slate-500/15 text-slate-300 ring-slate-500/40",
  正面: "bg-emerald-500/15 text-emerald-300 ring-emerald-500/40",
};

export function SevBadge({ sev }: { sev: Severity }) {
  return (
    <span
      className={`inline-flex shrink-0 items-center rounded-md px-2 py-0.5 text-xs font-bold ring-1 ${sevStyle[sev]}`}
    >
      {sev === "正面" ? "✓ 正面" : sev === "信息" ? "ⓘ 信息" : `⚠ ${sev}`}
    </span>
  );
}

export function Code({ children }: { children: ReactNode }) {
  return (
    <code className="rounded bg-slate-800/80 px-1.5 py-0.5 font-mono text-[0.82em] text-amber-200/90 ring-1 ring-slate-700/60">
      {children}
    </code>
  );
}

export function FileRef({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-md bg-indigo-500/10 px-2 py-0.5 font-mono text-xs text-indigo-300 ring-1 ring-indigo-500/30">
      <svg className="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2}>
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
        <path d="M14 2v6h6" />
      </svg>
      {children}
    </span>
  );
}

export function SectionTitle({
  icon,
  title,
  subtitle,
}: {
  icon: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="mb-5 flex items-start gap-3">
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500/30 to-purple-600/30 text-xl ring-1 ring-indigo-400/30">
        {icon}
      </div>
      <div>
        <h2 className="text-xl font-bold text-slate-100">{title}</h2>
        {subtitle && <p className="mt-0.5 text-sm text-slate-400">{subtitle}</p>}
      </div>
    </div>
  );
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={`rounded-2xl border border-slate-700/50 bg-slate-900/60 p-5 shadow-lg shadow-black/20 backdrop-blur ${className}`}
    >
      {children}
    </div>
  );
}

export function Finding({
  id,
  sev,
  title,
  files,
  children,
}: {
  id: string;
  sev: Severity;
  title: string;
  files?: string[];
  children: ReactNode;
}) {
  return (
    <div className="rounded-xl border border-slate-700/40 bg-slate-900/50 p-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-mono text-xs font-bold text-slate-500">{id}</span>
        <SevBadge sev={sev} />
        <h4 className="font-semibold text-slate-100">{title}</h4>
      </div>
      {files && files.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1.5">
          {files.map((f) => (
            <FileRef key={f}>{f}</FileRef>
          ))}
        </div>
      )}
      <div className="mt-2.5 space-y-2 text-sm leading-relaxed text-slate-300">{children}</div>
    </div>
  );
}

export function Callout({
  tone,
  title,
  children,
}: {
  tone: "amber" | "emerald" | "red" | "indigo";
  title: string;
  children: ReactNode;
}) {
  const tones = {
    amber: "border-amber-500/40 bg-amber-500/5 text-amber-200",
    emerald: "border-emerald-500/40 bg-emerald-500/5 text-emerald-200",
    red: "border-red-500/40 bg-red-500/5 text-red-200",
    indigo: "border-indigo-500/40 bg-indigo-500/5 text-indigo-200",
  };
  return (
    <div className={`rounded-xl border-l-4 ${tones[tone]} border border-l-4 p-4`}>
      <p className="mb-1.5 font-bold">{title}</p>
      <div className="space-y-2 text-sm leading-relaxed text-slate-300">{children}</div>
    </div>
  );
}
