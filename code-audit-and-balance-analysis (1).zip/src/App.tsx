import { useEffect, useState } from "react";
import Overview from "./pages/Overview";
import Audit from "./pages/Audit";
import Debate from "./pages/Debate";
import Critique from "./pages/Critique";

const tabs = [
  { id: "overview", label: "总览", icon: "🧭" },
  { id: "audit", label: "技术审计", icon: "🔬" },
  { id: "debate", label: "争议回应", icon: "🗣️" },
  { id: "critique", label: "怀疑与建议", icon: "🤨" },
] as const;

type TabId = (typeof tabs)[number]["id"];

function initialTab(): TabId {
  const h = window.location.hash.replace("#", "");
  return (tabs.find((t) => t.id === h)?.id ?? "overview") as TabId;
}

export default function App() {
  const [tab, setTab] = useState<TabId>(initialTab);

  useEffect(() => {
    window.location.hash = tab;
    window.scrollTo({ top: 0 });
  }, [tab]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 [background-image:radial-gradient(ellipse_60%_40%_at_50%_-10%,rgba(99,102,241,0.18),transparent),radial-gradient(ellipse_40%_30%_at_90%_10%,rgba(168,85,247,0.10),transparent)]">
      <header className="sticky top-0 z-40 border-b border-slate-800/70 bg-slate-950/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 text-lg shadow-lg shadow-indigo-900/50">
            📕
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-bold text-slate-100">
              纂刻附魔台 26.1.2 移植版 · 源码审计与机制评议
            </p>
            <p className="truncate font-mono text-[11px] text-slate-500">
              chiseled-enchanting-table-26.1.2-source @ arena/2d61e52c
            </p>
          </div>
          <nav className="ml-auto hidden gap-1 sm:flex">
            {tabs.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`rounded-lg px-3 py-1.5 text-sm font-semibold transition ${
                  tab === t.id
                    ? "bg-indigo-500/20 text-indigo-200 ring-1 ring-indigo-400/40"
                    : "text-slate-400 hover:bg-slate-800/60 hover:text-slate-200"
                }`}
              >
                <span className="mr-1">{t.icon}</span>
                {t.label}
              </button>
            ))}
          </nav>
        </div>
        {/* mobile nav */}
        <nav className="flex gap-1 overflow-x-auto px-4 pb-2 sm:hidden">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`shrink-0 rounded-lg px-3 py-1.5 text-sm font-semibold transition ${
                tab === t.id
                  ? "bg-indigo-500/20 text-indigo-200 ring-1 ring-indigo-400/40"
                  : "text-slate-400 hover:bg-slate-800/60"
              }`}
            >
              <span className="mr-1">{t.icon}</span>
              {t.label}
            </button>
          ))}
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8">
        {tab === "overview" && <Overview />}
        {tab === "audit" && <Audit />}
        {tab === "debate" && <Debate />}
        {tab === "critique" && <Critique />}
      </main>

      <footer className="border-t border-slate-800/70 py-6 text-center text-xs text-slate-500">
        <p>
          基于分支 arena/2d61e52c-chiseled-enchanting-table-26-1 的浅克隆静态审计 ·
          仓库静态门已实际复跑通过 · 无运行时动态验证(MC 26.1.2 jar 在审计环境不可得)
        </p>
        <p className="mt-1">
          审计发现编号(N/D/H/G/M/X/C/S-xx)仅为本报告口径,与仓库自带审计标注(NET/MX/R/DEAD-xx)相互印证但独立。
        </p>
      </footer>
    </div>
  );
}
