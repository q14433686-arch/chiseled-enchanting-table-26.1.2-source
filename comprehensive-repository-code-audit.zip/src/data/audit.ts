export const REPOSITORY =
  "https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source";
export const COMMIT = "d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5";
export const SHORT_COMMIT = COMMIT.slice(0, 7);
export const REFERENCE_COMMIT = "74720c2890f22942b72d7d84958eff1b3f72b95b";

export type Category =
  | "api"
  | "codec"
  | "network"
  | "gui"
  | "mixin"
  | "dead"
  | "coupling"
  | "balance";
export type Severity = "high" | "medium" | "low";
export type FindingKind = "bug" | "risk" | "design" | "maintenance";

export const categories: { id: Category; name: string; description: string }[] =
  [
    { id: "api", name: "源码 API", description: "版本接口、注册表与构建依赖" },
    {
      id: "codec",
      name: "数据编解码",
      description: "规则解析、材料账本与协议边界",
    },
    {
      id: "network",
      name: "网络同步",
      description: "菜单身份、服务端权威与延迟请求",
    },
    {
      id: "gui",
      name: "GUI 输入",
      description: "SDL 键位、快捷移动与槽位保护",
    },
    {
      id: "mixin",
      name: "Mixin 注入",
      description: "注入目标与跨配置行为一致性",
    },
    {
      id: "dead",
      name: "死代码",
      description: "编译排除的遗留实现与无调用方法",
    },
    {
      id: "coupling",
      name: "耦合风险",
      description: "规则覆盖、类型边界与单一数据来源",
    },
    {
      id: "balance",
      name: "数值与机制",
      description: "恢复时长、仪式门槛与可配置性",
    },
  ];

export const severityMeta: Record<
  Severity,
  { label: string; priority: string; color: string }
> = {
  high: { label: "高风险", priority: "P1", color: "#d95355" },
  medium: { label: "中风险", priority: "P2", color: "#d29532" },
  low: { label: "低风险", priority: "P3", color: "#64849b" },
};

export const kindMeta: Record<FindingKind, string> = {
  bug: "源码确认",
  risk: "条件风险",
  design: "设计取舍",
  maintenance: "维护建议",
};

export interface Evidence {
  path: string;
  start: number;
  end: number;
  description: string;
  code?: string;
  external?: string;
}

export interface Finding {
  id: string;
  title: string;
  summary: string;
  severity: Severity;
  category: Category;
  kind: FindingKind;
  impact: string;
  analysis: string;
  reproduce: string[];
  recommendation: string;
  validation: string[];
  evidence: Evidence[];
}

const main = "src/main/java/chiseled_enchanting_table/";
const client = "src/client/java/chiseled_enchanting_table/";
const handler = `${main}menu/ChiseledEnchantingTableScreenHandler.java`;
const data = `${main}data/ChiseledEnchantingTableData.java`;
const blockEntity = `${main}block/ChiseledEnchantingTableBlockEntity.java`;
const payloads = `${main}menu/ChiseledEnchantingMenuPayloads.java`;

export const findings: Finding[] = [
  {
    id: "CET-001",
    title: "仪式期间的快捷移动绕过槽位锁",
    summary:
      "Shift 点击背包物品时先替换源槽，再尝试写入已锁定的目标槽，存在物品丢失和重复引用路径。",
    severity: "high",
    category: "gui",
    kind: "bug",
    impact:
      "普通玩家操作即可进入该分支。正在仪式中的物品可能同时被背包和附魔台引用，而被 Shift 点击的另一件物品丢失。实际持久化后的表现仍需游戏复现。",
    analysis:
      "QUICK_MOVE 只禁止从 ENCHANTABLE_SLOT 取出，没有禁止背包向该槽写入。2299 行把旧目标直接放到玩家源槽，2300 行再写新目标。方块实体 setItem 在有仪式时静默拒绝后一次写入；Slot.set 本身不调用 mayPlace。相同物品的 grow 分支同样绕过锁，会使仪式目标数量异常。",
    reproduce: [
      "放入一件可附魔装备，布置足以启动等待仪式的书架并开始铭刻。",
      "仪式尚未完成时，按住 Shift 点击背包中的另一件可附魔装备。",
      "核对两个槽位的物品、数量与组件，再关闭菜单、重开及重启存档检查。",
    ],
    recommendation:
      "在任何 QUICK_MOVE 源槽变更前校验目标 mayPlace、源槽 mayPickup 和方块实体 hasActiveRitual。通过统一的移动事务提交两端变更，不要先交换源槽再依赖静默拒写。",
    validation: [
      "覆盖仪式中从背包移入、从台子移出、同物品合并和不同物品交换。",
      "断言操作前后物品总量、组件和对象归属不变，并加入多人共享台子测试。",
    ],
    evidence: [
      {
        path: handler,
        start: 2252,
        end: 2305,
        description: "QUICK_MOVE 仅对源槽 0 上锁，随后直接交换槽位。",
        code: "if (slotIndex == ENCHANTABLE_SLOT && isRitualActive()) return;\n// ... inventory -> enchantable slot\nthis.getSlot(slotIndex).set(this.getSlot(ENCHANTABLE_SLOT).getItem());\nthis.getSlot(ENCHANTABLE_SLOT).set(tempStack);",
      },
      {
        path: blockEntity,
        start: 142,
        end: 148,
        description: "仪式期间对目标槽的 setItem 静默返回。",
        code: "if (slot == ChiseledEnchantingTableScreenHandler.ENCHANTABLE_SLOT\n    && hasActiveRitual()) return;\nthis.items.set(slot, stack);",
      },
      {
        path: "net/minecraft/world/inventory/Slot.java",
        start: 62,
        end: 76,
        description:
          "26.3 参考实现：set 直接调用 Container.setItem，不检查 mayPlace。",
        external: `https://github.com/0khs/minecraft_source_26.3/blob/${REFERENCE_COMMIT}/net/minecraft/world/inventory/Slot.java#L62-L76`,
      },
    ],
  },
  {
    id: "CET-002",
    title: "附魔列表仍使用 GLFW 回车键编号",
    summary:
      "257 / 335 不再是 26.3 的 Enter / 小键盘 Enter，键盘确认路径失效。",
    severity: "medium",
    category: "gui",
    kind: "bug",
    impact:
      "键盘导航用户按回车无法触发预期确认。鼠标左键已迁移到平台常量，本问题仅指附魔列表遗留的键盘判断。",
    analysis:
      "KeyEvent.key() 在 26.3 使用 InputConstants 的 SDL 扫描码。参考源码的 KEY_RETURN 为 40，KEY_NUMPADENTER 为 88；列表仍比较旧 GLFW 编号 257、335。触发后还忽略消费事件的返回值，主屏继续调用 super.keyPressed。",
    reproduce: [
      "用方向键聚焦一条可执行的附魔选项。",
      "分别按主键盘 Enter 与小键盘 Enter，对比左键点击效果。",
    ],
    recommendation:
      "使用 InputConstants.KEY_RETURN 和 KEY_NUMPADENTER；成功处理时返回 true，并让主屏尊重子组件的事件消费结果。",
    validation: [
      "在真实 26.3 客户端覆盖两种回车、方向键和 Esc。",
      "断言一次确认只发送一个操作请求。",
    ],
    evidence: [
      {
        path: `${client}gui/EnchantementListWidget.java`,
        start: 167,
        end: 175,
        description: "遗留的 GLFW 数字常量。",
        code: "int keyCode = event.key();\nif (keyCode == 257 || keyCode == 335) {\n    var focusedEntry = this.getFocused();\n    if (focusedEntry != null) focusedEntry.serverSendApplyEnchant();\n}",
      },
      {
        path: "com/mojang/blaze3d/platform/InputConstants.java",
        start: 104,
        end: 145,
        description: "26.3 参考源码的 SDL 常量分别为 88 和 40。",
        external: `https://github.com/0khs/minecraft_source_26.3/blob/${REFERENCE_COMMIT}/com/mojang/blaze3d/platform/InputConstants.java#L104-L145`,
      },
      {
        path: `${client}gui/ChiseledEnchantingTableScreen.java`,
        start: 492,
        end: 502,
        description: "主屏没有使用子组件的返回值。",
      },
    ],
  },
  {
    id: "CET-003",
    title: "重复材料条目没有合并为统一账本",
    summary:
      "同一材料出现在多个附加费用中时，检查阶段会重复使用同一份库存，扣费可能不足。",
    severity: "medium",
    category: "codec",
    kind: "bug",
    impact:
      "自定义数据包可形成低于声明费用的配方。默认配方不一定触发，不能将此描述为已证实的默认经济漏洞。",
    analysis:
      "maxBundleUnitsAvailable 针对每个 add 分别检查库存，未按物品及组件汇总全部需求。主材料不同、两个附加条目均为 8 个绿宝石时，背包只有 8 个也能分别通过。consumeAdditionalCosts 扣完第一个后，第二个不足不会回滚或阻止产物。",
    reproduce: [
      "建立主费用为 1 钻石、附加费用为 8 绿宝石 + 8 绿宝石的转化规则。",
      "费用槽放 1 钻石，背包仅放 8 绿宝石，执行一次转化。",
      "预期应拒绝；当前计数分支会把两个附加条目分别视为可支付。",
    ],
    recommendation:
      "按 ItemStack.isSameItemSameComponents 等价关系归并需求，并明确主材料可用池与附加材料可用池。先生成完整扣费计划，全部可支付后再原子提交。",
    validation: [
      "测试主材料重复、附加材料重复、三个重复条目和组件不同但物品相同的情况。",
      "检查单次和批量操作的实际扣费均等于汇总账本。",
    ],
    evidence: [
      {
        path: handler,
        start: 1318,
        end: 1339,
        description: "逐条检查，未累计同类附加材料。",
        code: "for (int i = 1; i < unitBundle.size(); i++) {\n    ItemStack add = unitBundle.get(i);\n    // Each entry compares against the full pool again.\n    units = Math.min(units, totalPool / unitNeed);\n}",
      },
      {
        path: handler,
        start: 2110,
        end: 2122,
        description: "不足时不会使整个操作失败。",
      },
      {
        path: data,
        start: 1285,
        end: 1289,
        description: "additional_costs 允许多个相同材料条目。",
      },
    ],
  },
  {
    id: "CET-004",
    title: "备选主材料路径跳过独立附加费用",
    summary:
      "同时声明 cost_options 与 additional_costs 的转化规则，会只返回备选费用 Bundle。",
    severity: "medium",
    category: "codec",
    kind: "bug",
    impact:
      "数据包作者声明的公共附加成本可能未被收取。仅在同时使用两个字段时触发。",
    analysis:
      "transformationCostOptions 在有 alternativePrimaryOptions 时直接返回 alternativeBundles；后面的 additionalCostStacks 仅在没有备选项时加入。alternativeBundles 只展开每个备选项自身的 extras，没有拼接转化级的 additionalCosts。",
    reproduce: [
      "定义两个 cost_options，并在转化顶层声明 additional_costs 为 1 钻石。",
      "分别选择两种备选主材料，检查显示及实际扣费是否都包含该钻石。",
    ],
    recommendation:
      "先为每个备选项构建主材料 Bundle，再将顶层公共附加费用拼接到每个 Bundle 并归一化；或者在 schema 中明确拒绝这个组合。",
    validation: [
      "增加 cost_options + additional_costs 的解析到执行集成测试。",
      "覆盖备选项自身 extras 与公共费用重复的情况。",
    ],
    evidence: [
      {
        path: data,
        start: 442,
        end: 451,
        description: "提前返回绕过下面的附加费用拼接。",
        code: 'if (!transformation.alternativePrimaryOptions().isEmpty()) {\n    return transformation.alternativeBundles();\n}\nList<ItemStack> bundle = new ArrayList<>();\nbundle.add(transformation.primaryCostStack(""));\nbundle.addAll(transformation.additionalCostStacks(""));',
      },
      {
        path: data,
        start: 1330,
        end: 1335,
        description: "每个备选项只展开自己的费用。",
      },
    ],
  },
  {
    id: "CET-005",
    title: "折扣终点被升级书架上限隐式覆盖",
    summary:
      "max_discount_bookshelves 虽能解析，却在有效配置组装时被 maxDirectBookshelves 替代。",
    severity: "medium",
    category: "coupling",
    kind: "bug",
    impact:
      "数据包单独修改折扣曲线终点不会生效，书架升级与 XP 折扣两个规则域被意外绑在一起。",
    analysis:
      "LibraryResonance.Config.fromJson 读取 max_discount_bookshelves，费用包也同步它；但 applyRuntimeConfig 构造有效 LibraryResonance.Config 时使用 Math.max(lr.minDiscountBookshelves() + 1, maxDirect)。因此默认值碰巧同为 38，掩盖了配置覆盖。",
    reproduce: [
      "保持 max_direct_bookshelves = 38，把木书架 max_discount_bookshelves 设置为 60。",
      "重载后检查有效配置及 38 书架时的折扣，确认终点是否仍为 38。",
    ],
    recommendation:
      "保留 lr.maxDiscountBookshelves() 为独立输入，只做自身合法性约束。若产品有意统一终点，应删除重复配置键并提供迁移说明。",
    validation: [
      "分别修改升级终点和折扣终点，断言互不改写。",
      "测试完整路径：JSON -> RuntimeFrame -> S2C -> GUI 费用。",
    ],
    evidence: [
      {
        path: data,
        start: 674,
        end: 688,
        description: "有效配置组装时替换了数据包给出的折扣终点。",
        code: "new LibraryResonance.Config(\n    lr.minDiscountBookshelves(),\n    Math.max(lr.minDiscountBookshelves() + 1, maxDirect),\n    woodDisc,\n    // ...\n)",
      },
      {
        path: `${main}mechanics/resonance/LibraryResonance.java`,
        start: 263,
        end: 275,
        description: "解析器确实读取该独立配置键。",
      },
    ],
  },
  {
    id: "CET-006",
    title: "普通操作请求没有绑定菜单实例",
    summary:
      "附魔、重掷和冻结请求只作用于“当前同类型菜单”，没有 containerId 或会话校验。",
    severity: "medium",
    category: "network",
    kind: "risk",
    impact:
      "延迟或重放请求可能在快速关开菜单后作用到另一张台子。服务端仍计算真实费用，这不是任意远程免费附魔漏洞。",
    analysis:
      "ApplyEnchantmentPayload 只有 type、id、level，Reroll 和 Freeze 为空包。接收器仅检查当前菜单类型，再次 execute 后读取玩家的当前菜单。SkipRitual 已使用 containerId + session，普通操作尚未采用同样约束。普通 TCP 有序传输本身不能证明会误投；必须验证额外任务延后或人为重放等触发条件。",
    reproduce: [
      "在网络延迟环境向台子 A 发送冻结或附魔请求，随后立即关菜单并打开台子 B。",
      "通过受控网络测试延迟该请求的执行，检查它能否误作用于 B。",
    ],
    recommendation:
      "统一操作信封：containerId、菜单 nonce、规则 revision 和操作参数；服务端验证 stillValid 及目标实例，拒绝过期请求。",
    validation: [
      "真实双端延迟、快速重开、重复请求和两张台子切换。",
      "保留费用、权限、物品与书架状态的服务端二次校验。",
    ],
    evidence: [
      {
        path: payloads,
        start: 493,
        end: 512,
        description: "附魔请求没有菜单标识。",
        code: "public record ApplyEnchantmentPayload(\n    OptionType option_type,\n    Identifier enchantment_id,\n    int enchantment_level\n) implements CustomPacketPayload",
      },
      {
        path: handler,
        start: 57,
        end: 90,
        description: "按执行时的当前菜单类型派发。",
      },
      {
        path: handler,
        start: 100,
        end: 107,
        description: "SkipRitual 已有可复用的实例校验模式。",
      },
    ],
  },
  {
    id: "CET-007",
    title: "不可信附魔 ID 直接进入 getOrThrow",
    summary:
      "可解码但未注册的附魔 ID 会沿服务端操作路径抛出异常，缺少统一的语义拒绝边界。",
    severity: "medium",
    category: "api",
    kind: "bug",
    impact:
      "修改客户端可重复触发任务异常和日志噪声。没有证据证明这会使专服崩溃，不应将其表述为远程崩服漏洞。",
    analysis:
      "Identifier 解码只验证 ID 格式，不验证注册表存在性。EnchantmentApplication.apply 在进行解锁检查前调用 IdentifierToEnchantment，后者使用 getOrThrow；接收器没有针对非法操作的受控拒绝处理。",
    reproduce: [
      "在打开本模组菜单后，发送合法格式但不存在的 audit:missing_enchantment ID。",
      "检查服务器日志及处理结果，再覆盖非法等级和已移除的注册项。",
    ],
    recommendation:
      "先用 Optional 查询注册表，校验 optionType、level、目标可用性及解锁集合；无效请求安静拒绝并做限速诊断，不要吞掉真正的内部错误。",
    validation: [
      "未知命名空间、未知 ID、等级 0 / 负值 / 超上限均有显式拒绝。",
      "在不改变物品或 XP 的前提下返回可诊断结果。",
    ],
    evidence: [
      {
        path: handler,
        start: 2068,
        end: 2069,
        description: "通用查询助手直接抛异常。",
        code: "return world.registryAccess()\n    .lookupOrThrow(Registries.ENCHANTMENT)\n    .getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, id));",
      },
      {
        path: `${main}mechanics/enchanting/EnchantmentApplication.java`,
        start: 34,
        end: 49,
        description: "在解锁检查之前处理客户端给出的 ID。",
      },
    ],
  },
  {
    id: "CET-008",
    title: "无效转化物品被硬编码替换为苹果",
    summary:
      "缺失输出 ID 时仍然扣费并产出 apple；缺失材料 ID 则回退为 lapis_lazuli。",
    severity: "medium",
    category: "codec",
    kind: "bug",
    impact:
      "可选模组缺失或数据包拼写错误时，配方语义被静默改变，玩家可能用昂贵材料换得苹果。WARN 并不能代替安全拒绝。",
    analysis:
      "ItemTransformation.outputStack 在未知输出或 AIR 时选择 Items.APPLE。ItemTransformationApplication 在构建产物前已调用 applyEnchantementCondition 扣费。ItemCostOption.candidateItems 对未知材料或空标签也回退为青金石。",
    reproduce: [
      "添加输出为 missing_mod:artifact 的转化规则，并准备所有声明费用。",
      "执行转化，检查是否扣费后得到苹果；再对缺失材料 ID 和空物品标签进行测试。",
    ],
    recommendation:
      "资源加载阶段验证输出与材料 ID；未知必需项应禁用该规则或让重载失败。可选集成使用明确的加载条件，不用通用物品兜底改变经济。",
    validation: [
      "测试缺失模组、未知输出、AIR 输出、空标签和未知费用。",
      "所有无效规则都必须保证不扣物品、不扣 XP、不生成替代产物。",
    ],
    evidence: [
      {
        path: data,
        start: 1338,
        end: 1345,
        description: "未知输出的苹果兜底。",
        code: 'if (item == null || item == Items.AIR) {\n    LOGGER.warn("Unknown transformation output {}; using apple fallback", outputItemId);\n    item = Items.APPLE;\n}',
      },
      {
        path: data,
        start: 1660,
        end: 1674,
        description: "材料或标签无法解析时改用青金石。",
      },
      {
        path: `${main}mechanics/transformation/ItemTransformationApplication.java`,
        start: 49,
        end: 60,
        description: "扣费发生在构造输出之前。",
      },
    ],
  },
  {
    id: "CET-009",
    title: "费用表的发送端没有匹配解码预算",
    summary:
      "解码限制每个集合 65,536 项，但发送端按全部附魔等级展开，没有分片或总预算。",
    severity: "medium",
    category: "codec",
    kind: "risk",
    impact:
      "高等级附魔数据包或大型整合包可能生成客户端必然拒绝的费用表。嵌套集合还有放大分配风险，但包大小与实际阈值需要运行测试。",
    analysis:
      "每个 maxLevel=M 的附魔产生 4M + 2(M-1) = 6M-2 行。43 个上限为 255 的附魔就产生 65,704 行，已超过 readCount 的 65,536 限制，尚未计入其他附魔和转化。写入方只写 costs.size()，未对齐此上限。",
    reproduce: [
      "用测试数据包注册 43 个 max_level=255 的附魔。",
      "连接服务器并捕获费用表生成和解码，检查行数、字节数与内存占用。",
    ],
    recommendation:
      "规定发送与接收共享的总行数、总物品数、嵌套深度及字节预算；超预算使用 revision + 分片同步，或按可见操作按需生成费用。",
    validation: [
      "增加 65,535 / 65,536 / 65,537 边界的真实 codec 测试。",
      "验证非空、带自定义组件的 registry-aware ItemStack 往返。",
    ],
    evidence: [
      {
        path: `${main}menu/EnchantCostTablePayload.java`,
        start: 69,
        end: 123,
        description: "按所有附魔的所有等级无界展开费用行。",
      },
      {
        path: `${main}menu/EnchantCostTablePayload.java`,
        start: 269,
        end: 278,
        description: "写入前没有共同预算检查。",
        code: "buf.writeVarInt(costs.size());\nfor (CostEntry entry : costs) {\n    // Each row also contains nested cost options and ItemStacks.\n}",
      },
      {
        path: `${main}menu/PayloadLimits.java`,
        start: 6,
        end: 16,
        description: "接收端的单集合上限。",
      },
    ],
  },
  {
    id: "CET-010",
    title: "长恢复周期与会话进度重置互相放大",
    summary:
      "42 书架时每点恢复约 1 小时；离开持续观察范围或重启，会丢失尚未结算的恢复进度。",
    severity: "medium",
    category: "balance",
    kind: "design",
    impact:
      "短时游玩的玩家可能多次游玩仍无法恢复 1 点。它是反套利与游玩节奏的取舍，不是单位换算错误；不能直接断言必须缩短为旧注释的数值。",
    analysis:
      "实际默认恢复间隔为 0 书架 24,000 秒、38 书架 12,000 秒、42 书架 3,600 秒。按 16 点完整磨损预算计算，42 书架需约 16 小时，复制一次的 4 点成本需约 4 小时。RegenerationScheduler 是纯会话状态，缺观察窗口会重置，停服也清空；原有部分注释仍写 30s / 10s，与实现不符。",
    reproduce: [
      "42 书架下放入有磨损的母本，持续加载并观察 59 分钟。",
      "卸载相关区块或重启，再加载并观察恢复所需时间。",
      "与连续加载超过 1 小时的控制组比较。",
    ],
    recommendation:
      "先确定是“连续驻留奖励”还是“累计恢复”。若目标是累计恢复，持久化服务端拥有的恢复进度，绑定世界、书架、槽位与书本身份，保持重叠台子不叠加、防移动套利。同步修正旧时长注释。",
    validation: [
      "覆盖 0 / 37 / 38 / 41 / 42 / 62 书架的精确间隔。",
      "验证离线、区块卸载、重启、换书和改变恢复档位的产品约定。",
    ],
    evidence: [
      {
        path: `${main}mechanics/resonance/MasterTomeWear.java`,
        start: 57,
        end: 68,
        description: "恢复周期的真实默认值。",
        code: "DEFAULT_REGEN_BASE_SECONDS = 24_000;\nDEFAULT_REGEN_TIER1_SECONDS = 12_000;\nDEFAULT_REGEN_TIER2_SECONDS = 3_600;",
      },
      {
        path: `${main}mechanics/resonance/RegenerationScheduler.java`,
        start: 33,
        end: 67,
        description: "缺失窗口、对象或速率变化会重置驻留进度。",
      },
      {
        path: `${main}mechanics/resonance/WorldRegeneration.java`,
        start: 27,
        end: 39,
        description: "停服清空会话状态，没有保存部分恢复进度。",
      },
    ],
  },
  {
    id: "CET-011",
    title: "原版附魔上限对齐仍固定为半级上限",
    summary:
      "ALIGN_CAPS 固定 ceil(maxLevel / 2)，没有跟随可配置的 blankMaxTierMode。",
    severity: "low",
    category: "mixin",
    kind: "risk",
    impact:
      "同时使用 ALIGN_CAPS 和 full_curve / level_one_only 时，两套台子的上限语义不一致。是否应跟随配置，需要先明确该模式的产品定义。",
    analysis:
      "DisableBookEnchanting 的 RETURN 注入始终执行 (maxLvl + 1) / 2；BookshelfProgression.maxBlankWoodenTier 已支持三个模式。如果 ALIGN_CAPS 的含义是对齐当前空白铭刻策略，应复用统一的 cap 解析器，而不是复制默认公式。现有证据不表明注入签名在 26.3 失效。",
    reproduce: [
      "设置 vanilla_table_mode=align_caps，分别选择三种 blank_max_tier_mode。",
      "比较同一附魔在原版台子和纂刻台上的上限。",
    ],
    recommendation:
      "明确 ALIGN_CAPS 是“固定半级”还是“跟随当前策略”。前者应改名和补充说明，后者提取无世界依赖的统一上限函数。",
    validation: [
      "覆盖 3 种 blank 策略与 ALL / NONE / BOOKS / ALIGN_CAPS 的组合。",
      "铁砧和结构注入仍需在非平坦真实世界里执行验收。",
    ],
    evidence: [
      {
        path: `${main}mixin/enchanting_table/DisableBookEnchanting.java`,
        start: 45,
        end: 70,
        description: "注入中复制了固定的半级公式。",
        code: "int maxLvl = Math.max(1, inst.enchantment().value().getMaxLevel());\nint cap = Math.max(1, (maxLvl + 1) / 2);\nclamped.add(new EnchantmentInstance(inst.enchantment(), Math.min(inst.level(), cap)));",
      },
      {
        path: `${main}mechanics/resonance/BookshelfProgression.java`,
        start: 483,
        end: 499,
        description: "业务规则已经有可配置的三分支上限。",
      },
    ],
  },
  {
    id: "CET-012",
    title: "遗留实现与无调用费用方法仍留在源码树",
    summary:
      "旧结构、战利品和集成实现被编译排除；Handler 内另有未使用的 XP 与材料检查方法。",
    severity: "low",
    category: "dead",
    kind: "maintenance",
    impact:
      "主要影响维护与审计准确性，不是运行时重复注入。误把排除目录当作现行实现，容易修错代码或重新引入旧 API。",
    analysis:
      "build.gradle 86-90 行明确排除 legacy 路径。相关四组目录约 2,027 行，另有被排除的工具文件。calculateXpCostToLevel 与 hasAdditionalCosts 在当前仓库中只有定义，没有调用，现行 XP 路径使用 XpCostConversion。",
    reproduce: [
      "比对 sourceSets.main.java.exclude 与当前 mixin 配置。",
      "对两个方法进行全仓调用搜索，并检查构建产物是否包含旧类。",
    ],
    recommendation:
      "移入明确的 archive 目录或删除已被 Git 历史保存的旧实现；删除私有无调用方法，公共方法先确认外部二进制兼容需求。让静态门禁区分活跃与归档源码。",
    validation: [
      "检查发布 JAR 中没有遗留类。",
      "保留新旧实现迁移说明，确保编译排除项不能意外被重新启用。",
    ],
    evidence: [
      {
        path: "build.gradle",
        start: 64,
        end: 90,
        description: "编译排除项是判断死代码范围的依据。",
      },
      {
        path: handler,
        start: 2076,
        end: 2108,
        description: "两处方法当前只有定义，无内部调用。",
      },
    ],
  },
  {
    id: "CET-013",
    title: "转化目录通过 Object[] 位置契约传递",
    summary:
      "数据层和网络层依赖 0..7 的字段顺序与强制类型转换，缺少编译期保护。",
    severity: "low",
    category: "coupling",
    kind: "maintenance",
    impact:
      "当前字段顺序一致，未发现现存字段错位。后续添加门槛、标签或解锁字段时容易引入 ClassCastException 或同步语义漂移。",
    analysis:
      "transformationDisplayTuples 构造 List<Object[]>，Payload 层根据 tuple.length 和下标读取 Identifier、int、boolean。领域模型变化不能由编译器完整追踪。",
    reproduce: [
      "检查数据层 tuple 构造与 Payload 的八个下标。",
      "在独立测试分支模拟插入字段，观察编译器是否能识别所有消费者。",
    ],
    recommendation:
      "引入不依赖网络类型的 TransformationDescriptor record，并由领域层生成不可变描述；网络与查看器适配器仅做明确字段映射。",
    validation: [
      "类型化后用非默认字段值做端到端映射测试。",
      "空目录仍必须作为服务端权威值，不回退本地默认。",
    ],
    evidence: [
      {
        path: data,
        start: 401,
        end: 419,
        description: "数据层输出弱类型位置数组。",
        code: "List<Object[]> result = new ArrayList<>();\nresult.add(new Object[] {\n    transformation.id(), transformation.inputItemId(),\n    transformation.outputItemId(), transformation.level(),\n    // ...\n});",
      },
      {
        path: payloads,
        start: 276,
        end: 294,
        description: "消费者按位置强制转换。",
      },
    ],
  },
  {
    id: "CET-014",
    title: "Loom 仍使用可漂移的 SNAPSHOT 版本",
    summary:
      "Minecraft 与查看器依赖已固定，但构建插件 1.17-SNAPSHOT 仍会随时间解析到不同构建。",
    severity: "low",
    category: "api",
    kind: "maintenance",
    impact:
      "同一提交未来重建可能解析不同工具链，难以回溯“相应版本”的编译差异。不是当前 API 不兼容的证明。",
    analysis:
      "build.gradle 注释提及 1.17.20 参考版本，实际声明却为 1.17-SNAPSHOT。JEI / REI 已使用固定版本且排除了工具链传递覆盖，这些现有保护应保留。",
    reproduce: [
      "在两个空 Gradle 缓存环境解析插件，记录实际解析的 Loom 构建。",
      "比较构建时间变化后的依赖解析与产物。",
    ],
    recommendation:
      "固定经 26.3 CI 验证的精确 Loom 发布版本或时间戳构建，记录 Gradle/JDK 版本，并加入依赖验证元数据。不要未经验证直接套用注释中的版本。",
    validation: [
      "用 Java 25 完成有查看器与无查看器两条构建。",
      "在干净缓存中复建并保留解析依赖清单。",
    ],
    evidence: [
      {
        path: "build.gradle",
        start: 1,
        end: 7,
        description: "构建插件仍为浮动快照。",
        code: "plugins {\n    id 'net.fabricmc.fabric-loom' version '1.17-SNAPSHOT'\n    id 'java-library'\n    id 'maven-publish'\n}",
      },
      {
        path: "gradle.properties",
        start: 19,
        end: 40,
        description: "其他可选查看器版本已经固定，不应误报为浮动。",
      },
    ],
  },
  {
    id: "CET-015",
    title: "仪式平衡参数没有进入统一规则域",
    summary:
      "5 分钟上限、10 附魔门槛、50% / 70% 退化与 20% 抄错上限都在 Java 中固定。",
    severity: "low",
    category: "balance",
    kind: "design",
    impact:
      "整合包无法只用数据包调整仪式节奏。书架数增加反而触发等待并提高强度，需要清晰告知玩家，而不是自动视为实现 BUG。",
    analysis:
      "InscriptionRitualMechanics 既持有 256 步等安全边界，也直接持有大量平衡参数和原版附魔 ID 权重。应区分不能被玩家配置放大的资源上限、原版时间常量，以及应由服主调整的玩法参数。32 附近的等待从 0 突然跳到非零，与平滑升级曲线不是同一种设计。",
    reproduce: [
      "比较默认 31 / 32 个广义书架且无母本时的同等级铭刻等待。",
      "在高级母本和超载 Infinity 母本情况下检查等待、跳过费用与抄错提示。",
    ],
    recommendation:
      "将玩法参数提取为 RitualRules，纳入校验、规则来源和 S2C 同步；保留硬性的队列、字符和时间资源预算。考虑等待门槛的渐进开启或提供明确的风险预览。",
    validation: [
      "参数变化后服务端行为、GUI 提示和秘典须使用同一快照。",
      "保留 XP 势能守恒及批量顺序等价的既有测试，不用“平衡调整”绕开它们。",
    ],
    evidence: [
      {
        path: `${main}mechanics/ritual/InscriptionRitualMechanics.java`,
        start: 59,
        end: 86,
        description: "玩法常量与安全常量混在业务类内。",
        code: "MAX_SINGLE_WAIT_TICKS = 20 * 300;\nMIN_TOME_ENCHANTS_FOR_WAIT = 10;\nMAX_RUSH_DEGRADE_NORMAL = 0.50;\nMAX_RUSH_DEGRADE_INFINITY = 0.70;\nMAX_TRANSCRIPTION_SLIP_CHANCE = 0.20;",
      },
      {
        path: `${main}mechanics/ritual/InscriptionRitualMechanics.java`,
        start: 246,
        end: 265,
        description: "等待强度使用固定归一化分母 42、22 与固定系数。",
      },
    ],
  },
];

export interface AuditCheck {
  name: string;
  command: string;
  result: string;
  detail: string;
  state: "pass" | "warning";
  log?: string;
}

export const checks: AuditCheck[] = [
  {
    name: "静态一致性检查",
    command: "python3 scripts/ci_static_checks.py",
    result: "通过",
    detail:
      "9 个 Mixin 引用、11 种语言 / 621 个键、470 个文案引用与文档链接均通过。",
    state: "pass",
  },
  {
    name: "26.3 源码回归",
    command: "python3 scripts/test_sync_26_3.py",
    result: "15 项通过",
    detail: "源码断言测试，不等同于 GUI 或实际网络行为测试。",
    state: "pass",
  },
  {
    name: "数据包兼容检查",
    command: "python3 scripts/compat_check.py",
    result: "Tier 1 / 2 通过",
    detail:
      "获取目标 MC JAR 后重跑，原版 ID 与标签存在性 Tier 2 也通过，0 条 WARN。",
    state: "pass",
  },
  {
    name: "发布版本一致性",
    command: "bash scripts/check_release_consistency.sh --strict",
    result: "12 项通过",
    detail:
      "确认 mod 1.1.0 / Minecraft 26.3 / Loader 0.19.5 / Fabric API 0.162.0+26.3。",
    state: "pass",
  },
  {
    name: "CI 镜像一致性",
    command: "bash docs/ci/install.sh --check",
    result: "4 份一致",
    detail: "docs/ci 与 .github/workflows 的四个工作流一致。",
    state: "pass",
  },
  {
    name: "标准构建与现有 JUnit",
    command: "./gradlew --no-daemon build",
    result: "52 项通过",
    detail:
      "Java 25.0.5 / Gradle 9.5.1，JEI / REI 均启用。52 个测试，0 失败、0 错误、0 跳过。实际解析 Loom 1.17.21。",
    state: "pass",
    log: "/audit/gradle-build.log",
  },
  {
    name: "无查看器干净构建",
    command: "./gradlew clean build -Penable_jei=false -Penable_rei=false",
    result: "构建通过",
    detail:
      "独立 clean 后重建，无 JEI / REI 依赖编译成功，现有 52 项 JUnit 再次全部通过。",
    state: "pass",
    log: "/audit/gradle-no-viewers.log",
  },
  {
    name: "真实专服生命周期探针",
    command: "python3 scripts/server_smoke.py",
    result: "运行通过",
    detail:
      "隔离平坦世界：启动、reload、命名/染色/冻结掉落、条件战利品、持久仪式完成、坏注册项隔离、破坏返还库存及正常停服。无真实玩家连接，不覆盖 GUI / 多人。预期隔离 WARN 不作为失败。",
    state: "pass",
    log: "/audit/server-smoke.log",
  },
  {
    name: "审计反例与源码断言",
    command: "python3 audit/verify_findings.py",
    result: "8 项通过",
    detail:
      "核对分支源码与物品别名、重复材料、费用行数等反例模型；这些是源码断言和模型，不是 Minecraft 玩家操作测试。",
    state: "pass",
    log: "/audit/source-assertions.log",
  },
];

export const safeguards = [
  {
    title: "协议按 revision 隔离",
    detail: "当前为 26_3_revision_6，同为 1.1.0 不代表 wire 兼容。",
  },
  {
    title: "坏集合与未知操作已拒绝",
    detail: "负长度、过大集合和未知操作 token 不再静默进入业务。",
  },
  {
    title: "已采用 SDL 鼠标常量",
    detail: "主屏与秘典的左右键修复仍在，不能重复报为现存缺陷。",
  },
  {
    title: "重载与断连有清理路径",
    detail:
      "菜单会关闭、费用重同步、客户端缓存清空。持久库存不会按旧注释自动返还。",
  },
];

export function evidenceUrl(evidence: Evidence) {
  return (
    evidence.external ??
    `${REPOSITORY}/blob/${COMMIT}/${evidence.path}#L${evidence.start}-L${evidence.end}`
  );
}

export function categoryName(category: Category) {
  return categories.find((entry) => entry.id === category)?.name ?? category;
}
