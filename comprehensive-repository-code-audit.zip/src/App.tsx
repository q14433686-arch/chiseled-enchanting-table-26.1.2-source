import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import {
  ArrowDownToLine,
  ArrowRight,
  ArrowUpRight,
  BookOpen,
  Boxes,
  Braces,
  Check,
  CheckCheck,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronsUpDown,
  Circle,
  CircleAlert,
  CircleHelp,
  ClipboardCheck,
  Clock3,
  Code2,
  Copy,
  Download,
  ExternalLink,
  FileCode2,
  FileDown,
  FileText,
  Filter,
  GitBranch,
  GitCommitHorizontal,
  Layers,
  LayoutDashboard,
  ListChecks,
  LockKeyhole,
  Menu,
  Network,
  PanelLeftClose,
  Search,
  Settings2,
  Shield,
  ShieldCheck,
  SlidersHorizontal,
  Terminal,
  TriangleAlert,
  Unplug,
  Waypoints,
  X,
  type LucideIcon,
} from "lucide-react";
import {
  categories,
  categoryName,
  checks,
  COMMIT,
  evidenceUrl,
  findings,
  kindMeta,
  REPOSITORY,
  safeguards,
  severityMeta,
  SHORT_COMMIT,
  type Category,
  type Finding,
  type FindingKind,
  type Severity,
} from "./data/audit";
import {
  buildMarkdownReport,
  duration,
  regenSeconds,
  ritualSeconds,
} from "./lib/report";

type View = "overview" | "findings" | "balance" | "verification" | "roadmap";
const categoryIcons: Record<Category, LucideIcon> = {
  api: Braces,
  codec: Boxes,
  network: Network,
  gui: PanelLeftClose,
  mixin: Layers,
  dead: Unplug,
  coupling: Waypoints,
  balance: SlidersHorizontal,
};
const severityRank: Record<Severity, number> = { high: 0, medium: 1, low: 2 };

function Github({ size = 18 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden="true"
    >
      <path d="M12 .8A11.3 11.3 0 0 0 8.43 22.82c.57.1.77-.24.77-.54v-2.1c-3.15.68-3.81-1.34-3.81-1.34-.51-1.31-1.26-1.66-1.26-1.66-1.03-.7.08-.69.08-.69 1.14.08 1.73 1.17 1.73 1.17 1.01 1.73 2.65 1.23 3.3.94.1-.73.4-1.23.72-1.51-2.52-.29-5.17-1.26-5.17-5.6 0-1.24.45-2.25 1.17-3.04-.12-.28-.51-1.44.11-3 0 0 .95-.3 3.11 1.16A10.8 10.8 0 0 1 12 6.23c.96 0 1.92.13 2.82.38 2.16-1.46 3.1-1.16 3.1-1.16.62 1.56.23 2.72.11 3 .73.79 1.17 1.8 1.17 3.04 0 4.35-2.65 5.31-5.18 5.59.41.36.77 1.05.77 2.11v3.09c0 .3.2.65.78.54A11.3 11.3 0 0 0 12 .8Z" />
    </svg>
  );
}

function readStorage<T>(key: string, fallback: T): T {
  try {
    const value = localStorage.getItem(key);
    return value ? (JSON.parse(value) as T) : fallback;
  } catch {
    return fallback;
  }
}

function Icon({
  icon: Component,
  size = 18,
  ...props
}: {
  icon: LucideIcon;
  size?: number;
  className?: string;
}) {
  return (
    <Component size={size} strokeWidth={1.7} aria-hidden="true" {...props} />
  );
}

function Logo() {
  return (
    <div className="brand">
      <span className="brand-symbol">
        <Braces size={23} strokeWidth={2.1} />
        <i />
      </span>
      <span>
        Source<span className="brand-light">Lens</span>
        <small>源码审计工作台</small>
      </span>
    </div>
  );
}

function SeverityLabel({
  severity,
  withPriority = false,
}: {
  severity: Severity;
  withPriority?: boolean;
}) {
  return (
    <span className={`severity severity-${severity}`}>
      <span />
      {withPriority && `${severityMeta[severity].priority} · `}
      {severityMeta[severity].label}
    </span>
  );
}

function AppDialog({
  children,
  onClose,
  label,
  className = "",
}: {
  children: ReactNode;
  onClose: () => void;
  label: string;
  className?: string;
}) {
  const dialog = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const oldOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    dialog.current
      ?.querySelector<HTMLElement>("button, a, input, textarea")
      ?.focus();
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
      }
      if (event.key !== "Tab") return;
      const focusable = Array.from(
        dialog.current?.querySelectorAll<HTMLElement>(
          'button:not(:disabled), a[href], input, textarea, select, [tabindex="0"]',
        ) ?? [],
      );
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last?.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first?.focus();
      }
    };
    document.addEventListener("keydown", handleKey);
    return () => {
      document.removeEventListener("keydown", handleKey);
      document.body.style.overflow = oldOverflow;
      previous?.focus();
    };
  }, [onClose]);
  return (
    <div
      className={`dialog-backdrop ${className}`}
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div
        ref={dialog}
        role="dialog"
        aria-modal="true"
        aria-label={label}
        className="dialog-shell"
      >
        {children}
      </div>
    </div>
  );
}

function FindingDetail({
  finding,
  reviewed,
  note,
  onClose,
  onReview,
  onNote,
  onCopy,
}: {
  finding: Finding;
  reviewed: boolean;
  note: string;
  onClose: () => void;
  onReview: () => void;
  onNote: (value: string) => void;
  onCopy: () => void;
}) {
  const [tab, setTab] = useState<"analysis" | "source" | "fix">("analysis");
  const CategoryIcon = categoryIcons[finding.category];
  return (
    <AppDialog
      onClose={onClose}
      label={finding.title}
      className="finding-dialog"
    >
      <div className="detail-topline">
        <span>
          <Icon icon={FileCode2} size={16} />
          发现详情<span className="detail-top-divider">/</span>
          <code>{finding.id}</code>
        </span>
        <button className="icon-button" onClick={onClose} aria-label="关闭详情">
          <X size={20} />
        </button>
      </div>
      <header className="detail-heading">
        <div className="detail-labels">
          <SeverityLabel severity={finding.severity} withPriority />
          <span className="kind-label">{kindMeta[finding.kind]}</span>
        </div>
        <h2>{finding.title}</h2>
        <p>
          <Icon icon={CategoryIcon} size={15} />
          {categoryName(finding.category)}
          <span>·</span>基于 {SHORT_COMMIT}
        </p>
      </header>
      <div className="detail-tabs" role="tablist" aria-label="发现详情标签">
        {(
          [
            ["analysis", "问题分析"],
            ["source", "源码证据"],
            ["fix", "修复与验证"],
          ] as const
        ).map(([id, label]) => (
          <button
            role="tab"
            aria-selected={tab === id}
            key={id}
            className={tab === id ? "active" : ""}
            onClick={() => setTab(id)}
          >
            {label}
            {id === "source" && <span>{finding.evidence.length}</span>}
          </button>
        ))}
      </div>
      <div className="detail-body" key={tab}>
        {tab === "analysis" && (
          <>
            <div className={`impact-note impact-${finding.severity}`}>
              <Icon icon={CircleAlert} size={19} />
              <div>
                <strong>影响范围</strong>
                <p>{finding.impact}</p>
              </div>
            </div>
            <section className="detail-section">
              <h3>
                <Braces size={17} />
                根因分析
              </h3>
              <p>{finding.analysis}</p>
            </section>
            <section className="detail-section">
              <h3>
                <ListChecks size={17} />
                复现与核查
              </h3>
              <ol className="step-list">
                {finding.reproduce.map((step, index) => (
                  <li key={step}>
                    <span>{index + 1}</span>
                    <p>{step}</p>
                  </li>
                ))}
              </ol>
              <p className="detail-caution">
                <Icon icon={Clock3} size={13} />
                此处为待执行步骤，不代表游戏内复现已完成。
              </p>
            </section>
            <section className="detail-section note-section">
              <h3>
                <FileText size={17} />
                复核备注<span>仅保存在当前浏览器</span>
              </h3>
              <textarea
                aria-label="复核备注"
                placeholder="记录你的复现结果、修复提交或待确认的问题..."
                value={note}
                onChange={(event) => onNote(event.target.value)}
              />
              <small>
                <LockKeyhole size={11} />
                不上传至远程仓库，导出报告时将包含备注。
              </small>
            </section>
          </>
        )}
        {tab === "source" && (
          <>
            <div className="source-intro">
              <GitCommitHorizontal size={16} />
              <span>
                链接固定至 <code>{SHORT_COMMIT}</code>，不随分支更新漂移。
              </span>
            </div>
            {finding.evidence.map((evidence, index) => (
              <section
                className="evidence-block"
                key={evidence.path + evidence.start}
              >
                <div className="evidence-number">
                  证据 {String(index + 1).padStart(2, "0")}
                </div>
                <h3>{evidence.description}</h3>
                <a
                  href={evidenceUrl(evidence)}
                  target="_blank"
                  rel="noreferrer"
                  className="evidence-path"
                >
                  <FileCode2 size={15} />
                  <span>{evidence.path}</span>
                  <span className="line-ref">
                    L{evidence.start}-{evidence.end}
                  </span>
                  <ArrowUpRight size={15} />
                </a>
                {evidence.code && (
                  <div className="code-block">
                    <div>
                      <span>JAVA</span>
                      <span>关键逻辑摘录，省略上下文</span>
                    </div>
                    <pre>
                      <code>{evidence.code}</code>
                    </pre>
                  </div>
                )}
                {evidence.external && (
                  <p className="detail-caution">
                    外部参考：非官方 Minecraft 26.3 反编译源码镜像。
                  </p>
                )}
              </section>
            ))}
          </>
        )}
        {tab === "fix" && (
          <>
            <section className="detail-section">
              <h3>
                <Settings2 size={17} />
                建议修复
              </h3>
              <p>{finding.recommendation}</p>
            </section>
            <section className="detail-section">
              <h3>
                <ClipboardCheck size={17} />
                回归验收计划
              </h3>
              <ul className="validation-list">
                {finding.validation.map((validation) => (
                  <li key={validation}>
                    <span className="empty-check" />
                    <span>{validation}</span>
                  </li>
                ))}
              </ul>
            </section>
            <div className="verification-notice">
              <ShieldCheck size={20} />
              <div>
                <strong>修复应由行为测试闭环</strong>
                <p>
                  本报告未修改远程源码。自动测试已通过，但本项的玩家操作仍需单独复现。标记“已复核”只代表你已审阅该项。
                </p>
              </div>
            </div>
          </>
        )}
      </div>
      <footer className="detail-footer">
        <button className="button button-secondary" onClick={onCopy}>
          <Copy size={15} />
          复制发现链接
        </button>
        <button
          className={`button ${reviewed ? "button-reviewed" : "button-primary"}`}
          onClick={onReview}
        >
          {reviewed ? <CheckCheck size={16} /> : <Check size={16} />}
          {reviewed ? "已复核，点击撤销" : "标记为已复核"}
        </button>
      </footer>
    </AppDialog>
  );
}

function Coverage({
  onVerify,
  onCategory,
}: {
  onVerify: () => void;
  onCategory: (category: Category) => void;
}) {
  return (
    <aside className="report-aside">
      <section className="coverage-section">
        <div className="aside-section-title">
          <h3>审计覆盖</h3>
          <span>
            8 <i>/ 8</i>
          </span>
        </div>
        <div className="coverage-segments">
          {categories.map((item, index) => (
            <i key={item.id} style={{ animationDelay: `${index * 65}ms` }} />
          ))}
        </div>
        <p className="aside-subtitle">已沿 8 条路径进行静态审阅</p>
        <div className="coverage-list">
          {categories.map((item) => (
            <button key={item.id} onClick={() => onCategory(item.id)}>
              <Icon icon={categoryIcons[item.id]} size={15} />
              <span>{item.name}</span>
              <small>
                {
                  findings.filter((finding) => finding.category === item.id)
                    .length
                }{" "}
                项
              </small>
              <Check size={13} />
            </button>
          ))}
        </div>
      </section>
      <section className="baseline-section">
        <h3>版本基线</h3>
        <dl>
          <div>
            <dt>Minecraft</dt>
            <dd>26.3</dd>
          </div>
          <div>
            <dt>Fabric Loader</dt>
            <dd>0.19.5</dd>
          </div>
          <div>
            <dt>Fabric API</dt>
            <dd>0.162.0+26.3</dd>
          </div>
          <div>
            <dt>Java</dt>
            <dd>25</dd>
          </div>
          <div>
            <dt>Mod / Protocol</dt>
            <dd>
              1.1.0 <span>/</span> rev. 6
            </dd>
          </div>
        </dl>
      </section>
      <section className="scope-aside">
        <div className="scope-aside-icon">
          <Shield size={18} />
        </div>
        <h3>有证据，也有边界</h3>
        <p>
          构建、52 项 JUnit 与隔离专服探针已通过。客户端
          GUI、多人联机与结构行为仍需验收。
        </p>
        <button onClick={onVerify}>
          查看验证记录
          <ArrowUpRight size={14} />
        </button>
      </section>
    </aside>
  );
}

function BalanceView({ onFinding }: { onFinding: (finding: Finding) => void }) {
  const [shelves, setShelves] = useState(42);
  const [ritualShelves, setRitualShelves] = useState(32);
  const [tomeEnchants, setTomeEnchants] = useState(0);
  const points = Array.from(
    { length: 65 },
    (_, shelf) =>
      `${42 + (shelf / 64) * 590},${198 - (regenSeconds(shelf) / 24000) * 162}`,
  ).join(" ");
  const pointX = 42 + (shelves / 64) * 590;
  const pointY = 198 - (regenSeconds(shelves) / 24000) * 162;
  return (
    <div className="balance-view view-enter">
      <div className="section-heading">
        <div>
          <h2>数值与机制评估</h2>
          <p>先还原真实参数，再区分实现缺陷与玩法取舍。</p>
        </div>
        <span className="subtle-tag">
          <SlidersHorizontal size={13} />
          默认规则模拟
        </span>
      </div>
      <section className="mechanism-section">
        <div className="mechanism-heading">
          <span className="section-index">01</span>
          <div>
            <h3>母本恢复，真正需要多久？</h3>
            <p>
              根据 MasterTomeWear 的默认公式计算，按 20
              TPS；不包含观察窗口首秒。
            </p>
          </div>
          <button
            className="text-link"
            onClick={() =>
              onFinding(findings.find((finding) => finding.id === "CET-010")!)
            }
          >
            CET-010
            <ArrowUpRight size={14} />
          </button>
        </div>
        <div className="simulation-panel">
          <div className="simulation-controls">
            <label htmlFor="shelves">
              广义书架数量
              <strong>
                {shelves}
                <small>个</small>
              </strong>
            </label>
            <input
              id="shelves"
              aria-label="恢复书架数量"
              type="range"
              min="0"
              max="64"
              value={shelves}
              onChange={(event) => setShelves(Number(event.target.value))}
              style={
                {
                  "--range-progress": `${(shelves / 64) * 100}%`,
                } as CSSProperties
              }
            />
            <div className="range-labels">
              <span>0</span>
              <span>32</span>
              <span>64</span>
            </div>
            <div className="preset-buttons">
              {[0, 38, 42].map((value) => (
                <button
                  key={value}
                  className={shelves === value ? "selected" : ""}
                  onClick={() => setShelves(value)}
                >
                  {value === 0 ? "基础状态" : `${value} 书架`}
                </button>
              ))}
            </div>
            <div className="simulation-value">
              <small>恢复 1 点磨损</small>
              <strong data-testid="regen-result">
                {duration(regenSeconds(shelves))}
              </strong>
            </div>
            <dl className="simulation-calcs">
              <div>
                <dt>复制一次的 4 点成本</dt>
                <dd>{duration(regenSeconds(shelves) * 4)}</dd>
              </div>
              <div>
                <dt>16 点完整磨损预算</dt>
                <dd>{duration(regenSeconds(shelves) * 16)}</dd>
              </div>
            </dl>
          </div>
          <div className="chart-container">
            <div className="chart-heading">
              <span>
                <i />
                每点恢复时长
              </span>
              <small>小时 / 点</small>
            </div>
            <svg
              viewBox="0 0 660 240"
              role="img"
              aria-label="书架数与恢复时间曲线，38 和 42 书架处存在档位变化"
            >
              <defs>
                <linearGradient id="chart-fill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#209872" stopOpacity="0.13" />
                  <stop offset="100%" stopColor="#209872" stopOpacity="0.015" />
                </linearGradient>
              </defs>
              {[36, 90, 144, 198].map((y, index) => (
                <g key={y}>
                  <line
                    x1="42"
                    x2="632"
                    y1={y}
                    y2={y}
                    stroke="#e8eeeb"
                    strokeDasharray="4 5"
                  />
                  <text x="27" y={y + 4} textAnchor="end">
                    {["6.7", "4.4", "2.2", "0"][index]}
                  </text>
                </g>
              ))}
              <polygon
                points={`42,198 ${points} 632,198`}
                fill="url(#chart-fill)"
              />
              <polyline
                className="chart-line"
                points={points}
                fill="none"
                stroke="#239472"
                strokeWidth="2.7"
                strokeLinejoin="round"
              />
              {[38, 42].map((value) => (
                <g key={value}>
                  <line
                    x1={42 + (value / 64) * 590}
                    x2={42 + (value / 64) * 590}
                    y1="26"
                    y2="198"
                    stroke="#c2d9ce"
                    strokeDasharray="4 4"
                  />
                  <text x={42 + (value / 64) * 590} y="222" textAnchor="middle">
                    {value}
                  </text>
                </g>
              ))}
              <line
                x1={pointX}
                x2={pointX}
                y1={pointY}
                y2="198"
                stroke="#239472"
                strokeDasharray="3 3"
                opacity=".6"
              />
              <circle
                cx={pointX}
                cy={pointY}
                r="7"
                fill="#239472"
                opacity=".12"
              />
              <circle
                cx={pointX}
                cy={pointY}
                r="4"
                fill="#239472"
                stroke="white"
                strokeWidth="2"
              />
              {[0, 16, 32, 64].map((value) => (
                <text
                  key={value}
                  x={42 + (value / 64) * 590}
                  y="222"
                  textAnchor="middle"
                >
                  {value}
                </text>
              ))}
            </svg>
            <p className="chart-caption">
              <CircleAlert size={13} />
              重启或缺失观察窗口会重置未结算的驻留进度。
            </p>
          </div>
        </div>
      </section>
      <section className="mechanism-section ritual-section">
        <div className="mechanism-heading">
          <span className="section-index">02</span>
          <div>
            <h3>更多书架，也意味着更多等待</h3>
            <p>
              单步为最高相对等级，适用性系数 1.0。母本附魔按条目数计，不做去重。
            </p>
          </div>
        </div>
        <div className="ritual-simulator">
          <div className="ritual-inputs">
            <label>
              广义书架<strong>{ritualShelves}</strong>
              <input
                aria-label="仪式书架数量"
                type="range"
                min="0"
                max="64"
                value={ritualShelves}
                onChange={(event) =>
                  setRitualShelves(Number(event.target.value))
                }
              />
            </label>
            <label>
              母本附魔条目<strong>{tomeEnchants}</strong>
              <input
                aria-label="母本附魔条目"
                type="range"
                min="0"
                max="40"
                value={tomeEnchants}
                onChange={(event) =>
                  setTomeEnchants(Number(event.target.value))
                }
              />
            </label>
          </div>
          <div className="ritual-output">
            <Clock3 size={21} />
            <div>
              <span>单步等待时长</span>
              <strong data-testid="ritual-result">
                {duration(ritualSeconds(ritualShelves, tomeEnchants))}
              </strong>
            </div>
            <small>硬上限 5 分钟</small>
          </div>
        </div>
        <p className="mechanism-comment">
          默认门槛为 32 个广义书架或 10 条母本附魔。等待存在门槛跳变，而不是从 0
          平滑增长。这属于应明确展示给玩家的设计取舍。
        </p>
      </section>
      <div className="preserve-note">
        <ShieldCheck size={22} />
        <div>
          <h3>不要把所有常量都变成配置</h3>
          <p>
            队列步数、字符预算、扫描体积等资源安全边界应保持有界；仪式概率、恢复节奏等平衡参数才适合进入统一规则域。已有
            XP 守恒与批量顺序等价测试应继续保留。
          </p>
        </div>
      </div>
    </div>
  );
}

function VerificationView() {
  const unverified = [
    {
      icon: PanelLeftClose,
      title: "真实客户端与多人操作",
      text: "Shift 移物、回车键、菜单切换、延迟请求、JEI / REI 刷新及共享库存仍需要真实 26.3 双端验收。",
    },
    {
      icon: Layers,
      title: "结构生成与延迟注入",
      text: "本轮专服使用平坦世界并禁用结构生成。9 个 Mixin 引用检查通过，不等于全部注入行为已执行。",
    },
    {
      icon: Boxes,
      title: "非空组件的真实网络往返",
      text: "JUnit codec 与专服组件掉落已验证，但不能替代 registry-aware 非空 ItemStack 的客户端网络往返。",
    },
    {
      icon: Network,
      title: "大型整合包与复杂经济环路",
      text: "高等级费用表、重复材料和备选费用等新发现尚未加入生产行为回归；现有 52 项测试通过不代表覆盖所有环路。",
    },
  ];
  return (
    <div className="verification-view view-enter">
      <div className="section-heading">
        <div>
          <h2>验证记录与审计边界</h2>
          <p>只把本轮实际运行的检查计作通过。</p>
        </div>
        <span className="subtle-tag">
          <Terminal size={13} />
          源码 + 自动运行验证
        </span>
      </div>
      <div className="check-summary">
        <span className="check-summary-icon">
          <CheckCheck size={24} />
        </span>
        <div>
          <h3>{checks.length} 个验证入口已通过</h3>
          <p>
            标准与无查看器构建、52 项 JUnit、真实专服探针和目标资源 Tier 2
            均已验证。
          </p>
        </div>
        <span className="checks-date">
          固定提交 <code>{SHORT_COMMIT}</code>
        </span>
      </div>
      <div className="checks-table">
        <div className="checks-table-heading">
          <span>检查项 / 执行命令</span>
          <span>本轮结果</span>
        </div>
        {checks.map((check) => (
          <div className="check-row" key={check.name}>
            <Icon
              icon={check.state === "warning" ? CircleAlert : CheckCircle2}
              size={18}
              className={
                check.state === "warning" ? "amber-text" : "green-text"
              }
            />
            <div>
              <h3>{check.name}</h3>
              <code>{check.command}</code>
              <p>{check.detail}</p>
            </div>
            <div className="check-actions">
              <span className={`check-result ${check.state}`}>
                {check.result}
              </span>
              {check.log && (
                <a
                  className="log-link"
                  href={check.log}
                  target="_blank"
                  rel="noreferrer"
                >
                  运行日志
                  <ArrowUpRight size={12} />
                </a>
              )}
            </div>
          </div>
        ))}
      </div>
      <section className="unverified-section">
        <h3>
          <CircleAlert size={18} />
          以下项目尚未验证
        </h3>
        <div className="unverified-grid">
          {unverified.map((item) => (
            <div className="unverified-item" key={item.title}>
              <Icon icon={item.icon} size={18} />
              <h4>{item.title}</h4>
              <p>{item.text}</p>
            </div>
          ))}
        </div>
      </section>
      <section className="safeguards-section">
        <h3>
          <ShieldCheck size={18} />
          已存在的保护，不重复误报
        </h3>
        {safeguards.map((safeguard) => (
          <div key={safeguard.title}>
            <Check size={15} />
            <strong>{safeguard.title}</strong>
            <p>{safeguard.detail}</p>
          </div>
        ))}
      </section>
      <div className="reference-note">
        <BookOpen size={17} />
        <p>
          主要证据是固定提交源码与本轮运行日志。Fabric API 0.162.0+26.3 官方
          Javadoc 用于线程契约；非官方 26.3 反编译镜像用于输入与槽位 API
          对照。专服坏注册项隔离中的预期 WARN 不应描述为零警告，历史 CI
          也不计作本轮实测。
        </p>
      </div>
    </div>
  );
}

function RoadmapView({
  reviewed,
  onFinding,
}: {
  reviewed: string[];
  onFinding: (finding: Finding) => void;
}) {
  const stages = [
    {
      label: "首先修复",
      title: "保护物品与材料守恒",
      text: "先关闭正常玩家可触发的物品风险，再修复费用组装与扣费账本。",
      ids: ["CET-001", "CET-003", "CET-004", "CET-008"],
    },
    {
      label: "第二阶段",
      title: "收紧输入与同步边界",
      text: "迁移 SDL 键位，为请求绑定菜单实例，为发送与接收设定共同预算。",
      ids: ["CET-002", "CET-006", "CET-007", "CET-009"],
    },
    {
      label: "第三阶段",
      title: "统一规则与玩法预期",
      text: "独立配置不应互相覆盖；恢复与等待规则需要先确定产品语义，再实现。",
      ids: ["CET-005", "CET-010", "CET-011", "CET-015"],
    },
    {
      label: "持续治理",
      title: "让下一次升级更可控",
      text: "清理编译排除的旧实现，替换位置数组契约，并固定经 CI 验证的构建工具。",
      ids: ["CET-012", "CET-013", "CET-014"],
    },
  ];
  return (
    <div className="roadmap-view view-enter">
      <div className="section-heading">
        <div>
          <h2>建议修复路线</h2>
          <p>按影响优先级推进，每一阶段都以行为回归验收收尾。</p>
        </div>
        <span className="subtle-tag">
          <CheckCheck size={14} />
          {reviewed.length} / {findings.length} 已复核
        </span>
      </div>
      <div className="roadmap-timeline">
        {stages.map((stage, index) => (
          <section className="roadmap-stage" key={stage.title}>
            <span className={`stage-marker stage-${index}`}>
              {String(index + 1).padStart(2, "0")}
            </span>
            <div className="stage-content">
              <span className="stage-label">{stage.label}</span>
              <h3>{stage.title}</h3>
              <p>{stage.text}</p>
              <div className="stage-findings">
                {stage.ids.map((id) => {
                  const finding = findings.find((entry) => entry.id === id)!;
                  return (
                    <button key={id} onClick={() => onFinding(finding)}>
                      <span className={`stage-dot ${finding.severity}`} />
                      <code>{id}</code>
                      <span>{finding.title}</span>
                      {reviewed.includes(id) ? (
                        <CheckCheck size={16} className="green-text" />
                      ) : (
                        <ChevronRight size={16} />
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </section>
        ))}
      </div>
      <p className="roadmap-footnote">
        <LockKeyhole size={13} />
        这是只读审计的建议顺序，不代表远程仓库中的问题已被修复。
      </p>
    </div>
  );
}

export default function App() {
  const [view, setView] = useState<View>("overview");
  const [category, setCategory] = useState<Category | "all">("all");
  const [severity, setSeverity] = useState<Severity | "all">("all");
  const [kind, setKind] = useState<FindingKind | "all">("all");
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);
  const [sortAscending, setSortAscending] = useState(true);
  const [onlyUnreviewed, setOnlyUnreviewed] = useState(false);
  const [reviewed, setReviewed] = useState<string[]>(() => {
    const stored = readStorage<unknown>("sourcelens-reviewed-v1", []);
    return Array.isArray(stored)
      ? stored.filter(
          (id): id is string =>
            typeof id === "string" &&
            findings.some((finding) => finding.id === id),
        )
      : [];
  });
  const [notes, setNotes] = useState<Record<string, string>>(() => {
    const stored = readStorage<unknown>("sourcelens-notes-v1", {});
    if (stored && typeof stored === "object" && !Array.isArray(stored))
      return Object.fromEntries(
        Object.entries(stored).filter(([, value]) => typeof value === "string"),
      );
    return {};
  });
  const [selected, setSelected] = useState<Finding | null>(
    () =>
      findings.find(
        (finding) => finding.id === window.location.hash.slice(1),
      ) ?? null,
  );
  const [scopeOpen, setScopeOpen] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [exportMenu, setExportMenu] = useState(false);
  const [branchOpen, setBranchOpen] = useState(false);
  const [toast, setToast] = useState("");
  const searchInput = useRef<HTMLInputElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const notify = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 3200);
  }, []);

  useEffect(() => {
    document.title = "SourceLens · CET 26.3 源码审计报告";
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem("sourcelens-reviewed-v1", JSON.stringify(reviewed));
      localStorage.setItem("sourcelens-notes-v1", JSON.stringify(notes));
    } catch {
      notify("浏览器存储不可用，本次备注仅在当前会话保留");
    }
  }, [reviewed, notes, notify]);
  useEffect(
    () => () => {
      if (toastTimer.current) clearTimeout(toastTimer.current);
    },
    [],
  );
  useEffect(() => {
    setPage(1);
  }, [
    query,
    severity,
    category,
    kind,
    onlyUnreviewed,
    pageSize,
    sortAscending,
  ]);
  useEffect(() => {
    const onHash = () =>
      setSelected(
        findings.find(
          (finding) => finding.id === window.location.hash.slice(1),
        ) ?? null,
      );
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const editing =
        event.target instanceof HTMLElement &&
        ["INPUT", "TEXTAREA", "SELECT"].includes(event.target.tagName);
      if (
        !selected &&
        !scopeOpen &&
        ((event.key === "/" && !editing) ||
          ((event.ctrlKey || event.metaKey) && event.key === "k"))
      ) {
        event.preventDefault();
        setView("findings");
        setTimeout(() => searchInput.current?.focus(), 30);
      }
      if (event.key === "Escape") {
        setExportMenu(false);
        setBranchOpen(false);
        setMobileMenu(false);
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [selected, scopeOpen]);

  const openFinding = useCallback((finding: Finding) => {
    setSelected(finding);
    history.replaceState(
      null,
      "",
      `${location.pathname}${location.search}#${finding.id}`,
    );
  }, []);
  const closeFinding = useCallback(() => {
    setSelected(null);
    history.replaceState(null, "", `${location.pathname}${location.search}`);
  }, []);
  const closeScope = useCallback(() => setScopeOpen(false), []);
  const navigate = (next: View) => {
    setView(next);
    setCategory("all");
    setMobileMenu(false);
    if (next === "overview" || next === "findings") {
      setSeverity("all");
      setKind("all");
      setQuery("");
      setOnlyUnreviewed(false);
    }
  };
  const filterCategory = (next: Category) => {
    setCategory(next);
    setView("findings");
    setSeverity("all");
    setKind("all");
    setQuery("");
    setMobileMenu(false);
  };
  const copy = async (value: string, success: string) => {
    try {
      if (navigator.clipboard && window.isSecureContext)
        await navigator.clipboard.writeText(value);
      else {
        const field = document.createElement("textarea");
        field.value = value;
        field.style.position = "fixed";
        field.style.opacity = "0";
        document.body.appendChild(field);
        field.select();
        const copied = document.execCommand("copy");
        field.remove();
        if (!copied) throw new Error("Clipboard unavailable");
      }
      notify(success);
    } catch {
      notify("复制失败，请从地址栏或源码链接手动复制");
    }
  };
  const download = (format: "md" | "json") => {
    const text =
      format === "md"
        ? buildMarkdownReport(reviewed, notes)
        : JSON.stringify(
            {
              repository: REPOSITORY,
              commit: COMMIT,
              scope:
                "source audit + Gradle/JUnit + isolated dedicated-server smoke; no client GUI, multiplayer or structure behavior tests",
              findings,
              reviewed,
              notes,
              checks,
            },
            null,
            2,
          );
    const objectUrl = URL.createObjectURL(
      new Blob([text], {
        type:
          format === "md"
            ? "text/markdown;charset=utf-8"
            : "application/json;charset=utf-8",
      }),
    );
    const anchor = document.createElement("a");
    anchor.href = objectUrl;
    anchor.download = `CET-26.3-audit-${SHORT_COMMIT}.${format}`;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    setExportMenu(false);
    notify(`${format === "md" ? "Markdown" : "JSON"} 完整报告已导出`);
  };
  const filtered = useMemo(() => {
    const term = query.trim().toLocaleLowerCase();
    return findings
      .filter(
        (finding) =>
          (category === "all" || finding.category === category) &&
          (severity === "all" || finding.severity === severity) &&
          (kind === "all" || finding.kind === kind) &&
          (!onlyUnreviewed || !reviewed.includes(finding.id)) &&
          (!term ||
            [
              finding.id,
              finding.title,
              finding.summary,
              finding.analysis,
              categoryName(finding.category),
              ...finding.evidence.map((item) => item.path),
            ]
              .join(" ")
              .toLocaleLowerCase()
              .includes(term)),
      )
      .sort(
        (a, b) =>
          (sortAscending ? 1 : -1) *
          (severityRank[a.severity] - severityRank[b.severity] ||
            a.id.localeCompare(b.id)),
      );
  }, [
    category,
    severity,
    kind,
    onlyUnreviewed,
    reviewed,
    query,
    sortAscending,
  ]);
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const activePage = Math.min(page, totalPages);
  const visible = filtered.slice(
    (activePage - 1) * pageSize,
    activePage * pageSize,
  );
  const isFindings = view === "overview" || view === "findings";
  const filtersActive =
    category !== "all" ||
    severity !== "all" ||
    kind !== "all" ||
    !!query ||
    onlyUnreviewed;

  return (
    <div className="app-shell">
      {mobileMenu && (
        <div className="mobile-scrim" onClick={() => setMobileMenu(false)} />
      )}
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <a
          className="brand-link"
          href="#"
          onClick={(event) => {
            event.preventDefault();
            navigate("overview");
          }}
          aria-label="SourceLens 审计总览"
        >
          <Logo />
        </a>
        <div className="workspace-label">
          工作空间<span>PERSONAL</span>
        </div>
        <button
          className="workspace-selector"
          onClick={() => setScopeOpen(true)}
        >
          <span className="workspace-icon">
            <Code2 size={18} />
          </span>
          <span>
            仓库审计<small>Repository audit</small>
          </span>
          <ChevronsUpDown size={15} />
        </button>
        <div className="nav-section-label">审计工作台</div>
        <nav className="main-navigation" aria-label="主导航">
          {(
            [
              { id: "overview", title: "审计总览", icon: LayoutDashboard },
              { id: "findings", title: "全部发现", icon: FileCode2 },
              { id: "balance", title: "数值与机制", icon: SlidersHorizontal },
              { id: "roadmap", title: "修复路线", icon: ListChecks },
              { id: "verification", title: "验证记录", icon: ShieldCheck },
            ] as { id: View; title: string; icon: LucideIcon }[]
          ).map((item) => (
            <button
              key={item.id}
              className={view === item.id && category === "all" ? "active" : ""}
              onClick={() => navigate(item.id)}
            >
              <Icon icon={item.icon} size={18} />
              <span>{item.title}</span>
              {item.id === "findings" && <small>{findings.length}</small>}
              {item.id === "verification" && <i className="nav-status-dot" />}
            </button>
          ))}
        </nav>
        <div className="nav-section-label category-label">
          审计路径<span>8</span>
        </div>
        <nav className="category-navigation" aria-label="审计路径">
          {categories.map((item) => (
            <button
              key={item.id}
              className={category === item.id ? "active" : ""}
              onClick={() => filterCategory(item.id)}
            >
              <Icon icon={categoryIcons[item.id]} size={17} />
              <span>{item.name}</span>
              <small>
                {
                  findings.filter((finding) => finding.category === item.id)
                    .length
                }
              </small>
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="read-only-note">
            <span className="read-only-icon">
              <LockKeyhole size={15} />
            </span>
            <div>
              <strong>只读审计，证据可追溯</strong>
              <p>不修改远程仓库源码</p>
            </div>
          </div>
          <button className="sidebar-help" onClick={() => setScopeOpen(true)}>
            <CircleHelp size={16} />
            <span>审计方法与边界</span>
            <ArrowUpRight size={14} />
          </button>
          <div className="sidebar-footer">
            <span className="owner-avatar">Q</span>
            <div>
              个人工作空间<small>q14433686-arch</small>
            </div>
            <span className="online-dot" />
          </div>
        </div>
      </aside>
      <div className="main-shell">
        <header className="topbar">
          <div className="breadcrumbs">
            <button
              className="mobile-menu-button icon-button"
              aria-label="打开导航"
              onClick={() => setMobileMenu(!mobileMenu)}
            >
              <Menu size={20} />
            </button>
            <span className="breadcrumb-icon">
              <Icon icon={Boxes} size={16} />
            </span>
            <span>工作空间</span>
            <ChevronRight size={13} />
            <button onClick={() => navigate("overview")}>仓库审计</button>
            <ChevronRight size={13} />
            <strong>26.3 分支</strong>
          </div>
          <div className="topbar-actions">
            <button
              className="quick-search"
              onClick={() => {
                setView("findings");
                setTimeout(() => searchInput.current?.focus(), 30);
              }}
            >
              <Search size={15} />
              <span>快捷搜索</span>
              <kbd>Ctrl K</kbd>
            </button>
            <span className="topbar-divider" />
            <a
              href={REPOSITORY}
              aria-label="在 GitHub 查看仓库"
              target="_blank"
              rel="noreferrer"
            >
              <Github size={19} />
            </a>
            <span className="topbar-avatar">Q</span>
          </div>
        </header>
        <main className="main-content">
          <header className="repository-header">
            <div className="repository-eyebrow">
              <span />
              REPOSITORY AUDIT
              <span className="audit-status">
                <span />
                源码审计完成
              </span>
            </div>
            <div className="repository-title-row">
              <div>
                <h1>Chiseled Enchanting Table</h1>
                <p>
                  深入源码，定位风险。面向 Minecraft 26.3 的多路径审计报告。
                </p>
              </div>
              <div className="repository-actions">
                <a
                  className="button button-secondary"
                  href={`${REPOSITORY}/tree/26.3`}
                  target="_blank"
                  rel="noreferrer"
                >
                  <Github size={16} />
                  查看仓库
                  <ArrowUpRight size={14} />
                </a>
                <div className="export-wrapper">
                  <button
                    className="button button-primary export-button"
                    onClick={() => {
                      setExportMenu(!exportMenu);
                      setBranchOpen(false);
                    }}
                    aria-expanded={exportMenu}
                  >
                    <Download size={16} />
                    导出报告
                    <ChevronDown size={13} />
                  </button>
                  {exportMenu && (
                    <>
                      <div
                        className="popover-dismiss"
                        onClick={() => setExportMenu(false)}
                      />
                      <div className="export-dropdown">
                        <span>导出完整审计报告</span>
                        <button onClick={() => download("md")}>
                          <FileDown size={16} />
                          <div>
                            Markdown<small>包含证据链接与本地备注</small>
                          </div>
                          <ArrowDownToLine size={14} />
                        </button>
                        <button onClick={() => download("json")}>
                          <Braces size={16} />
                          <div>
                            JSON<small>结构化发现与验证记录</small>
                          </div>
                          <ArrowDownToLine size={14} />
                        </button>
                        <button
                          onClick={() => {
                            setExportMenu(false);
                            window.print();
                          }}
                        >
                          <FileText size={16} />
                          <div>
                            打印当前视图<small>可另存为 PDF</small>
                          </div>
                          <ExternalLink size={14} />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
            <div className="repository-meta">
              <div className="branch-wrapper">
                <button
                  className="branch-button"
                  onClick={() => {
                    setBranchOpen(!branchOpen);
                    setExportMenu(false);
                  }}
                  aria-expanded={branchOpen}
                >
                  <GitBranch size={14} />
                  26.3
                  <ChevronDown size={11} />
                </button>
                {branchOpen && (
                  <>
                    <div
                      className="popover-dismiss"
                      onClick={() => setBranchOpen(false)}
                    />
                    <div className="branch-popover">
                      <strong>本次审计基线</strong>
                      <div>
                        <GitBranch size={14} />
                        <span>26.3</span>
                        <Check size={15} />
                      </div>
                      <p>报告固定至提交 {SHORT_COMMIT}，不随远程分支变动。</p>
                      <a
                        href={`${REPOSITORY}/commit/${COMMIT}`}
                        target="_blank"
                        rel="noreferrer"
                      >
                        查看固定提交
                        <ArrowUpRight size={13} />
                      </a>
                    </div>
                  </>
                )}
              </div>
              <span className="meta-divider" />
              <span className="repo-owner">
                q14433686-arch<span>/</span>chiseled-enchanting-table
              </span>
              <span className="meta-divider" />
              <button
                className="commit-button"
                onClick={() => copy(COMMIT, "完整提交 SHA 已复制")}
                title="复制完整提交 SHA"
              >
                <GitCommitHorizontal size={15} />
                <code>{SHORT_COMMIT}</code>
                <Copy size={11} />
              </button>
              <span className="meta-date">基线 2026.10.24</span>
            </div>
          </header>

          <section className="audit-metrics" aria-label="风险统计">
            <button
              className={`metric metric-total ${isFindings && severity === "all" && !filtersActive ? "metric-selected" : ""}`}
              onClick={() => {
                setView("findings");
                setSeverity("all");
                setCategory("all");
                setKind("all");
                setQuery("");
                setOnlyUnreviewed(false);
              }}
            >
              <span className="metric-label">
                审计发现
                <Icon icon={FileCode2} size={15} />
              </span>
              <div>
                <strong>{findings.length.toString().padStart(2, "0")}</strong>
                <span>项待关注</span>
              </div>
              <div className="risk-distribution">
                <i className="high" />
                <i className="medium" />
                <i className="low" />
              </div>
            </button>
            {(["high", "medium", "low"] as const).map((level) => (
              <button
                key={level}
                className={`metric metric-${level} ${isFindings && severity === level ? "metric-selected" : ""}`}
                onClick={() => {
                  setView("findings");
                  setSeverity(level);
                  setCategory("all");
                  setKind("all");
                  setQuery("");
                  setOnlyUnreviewed(false);
                }}
              >
                <span className="metric-label">
                  <span className={`metric-dot ${level}`} />
                  {severityMeta[level].label}
                  <ArrowUpRight size={14} />
                </span>
                <div>
                  <strong>
                    {String(
                      findings.filter((finding) => finding.severity === level)
                        .length,
                    ).padStart(2, "0")}
                  </strong>
                  <span>
                    {level === "high"
                      ? "建议优先修复"
                      : level === "medium"
                        ? "需结合场景处理"
                        : "维护与设计建议"}
                  </span>
                </div>
                <p>
                  {level === "high"
                    ? "物品完整性与核心交互"
                    : level === "medium"
                      ? "边界校验、配置与同步"
                      : "解耦、可维护性与可复现性"}
                </p>
              </button>
            ))}
          </section>

          <div className="audit-advisory">
            <span className="advisory-icon">
              <TriangleAlert size={17} />
            </span>
            <p>
              <strong>建议先修复高风险项，再进入多人联机验收。</strong>
              <span>
                源码确认不等同于游戏内复现，设计取舍不直接判定为 BUG。
              </span>
            </p>
            <button onClick={() => setView("verification")}>
              了解验证边界
              <ArrowUpRight size={14} />
            </button>
          </div>
          <nav className="content-tabs" aria-label="报告视图">
            {(
              [
                { id: "overview", label: "审计发现", icon: FileCode2 },
                { id: "balance", label: "数值与机制", icon: SlidersHorizontal },
                { id: "verification", label: "验证与边界", icon: ShieldCheck },
                { id: "roadmap", label: "修复路线", icon: ListChecks },
              ] as { id: View; label: string; icon: LucideIcon }[]
            ).map((tab) => (
              <button
                key={tab.id}
                className={
                  (tab.id === "overview" ? isFindings : tab.id === view)
                    ? "active"
                    : ""
                }
                onClick={() => {
                  if (tab.id === "overview") {
                    setView("overview");
                    setCategory("all");
                  } else setView(tab.id);
                }}
              >
                <Icon icon={tab.icon} size={16} />
                {tab.label}
                {tab.id === "overview" && <span>{findings.length}</span>}
              </button>
            ))}
            <div className="tab-trailing">
              <span />
              提交级源码追溯
            </div>
          </nav>

          {isFindings && (
            <div className="report-grid view-enter">
              <section className="findings-section" ref={resultsRef}>
                <div className="findings-heading">
                  <h2>
                    {category === "all" ? "审计发现" : categoryName(category)}
                    <span>{filtered.length}</span>
                  </h2>
                  <button
                    className="sort-button"
                    onClick={() => setSortAscending(!sortAscending)}
                  >
                    <ChevronsUpDown size={14} />
                    {sortAscending ? "按风险优先" : "按风险倒序"}
                  </button>
                </div>
                <div className="findings-toolbar">
                  <div className="search-field">
                    <Search size={16} />
                    <input
                      ref={searchInput}
                      aria-label="搜索审计发现"
                      placeholder="搜索问题、文件或关键词..."
                      value={query}
                      onChange={(event) => setQuery(event.target.value)}
                      onKeyDown={(event) => {
                        if (event.key === "Escape") {
                          setQuery("");
                          searchInput.current?.blur();
                        }
                      }}
                    />
                    {query ? (
                      <button
                        aria-label="清空搜索"
                        onClick={() => setQuery("")}
                      >
                        <X size={13} />
                      </button>
                    ) : (
                      <kbd>/</kbd>
                    )}
                  </div>
                  <div className="filter-select">
                    <Filter size={14} />
                    <select
                      aria-label="风险等级"
                      value={severity}
                      onChange={(event) =>
                        setSeverity(event.target.value as Severity | "all")
                      }
                    >
                      <option value="all">全部风险</option>
                      {(["high", "medium", "low"] as const).map((level) => (
                        <option key={level} value={level}>
                          {severityMeta[level].label}
                        </option>
                      ))}
                    </select>
                    <ChevronDown size={12} />
                  </div>
                  <div className="filter-select kind-filter">
                    <select
                      aria-label="证据类型"
                      value={kind}
                      onChange={(event) =>
                        setKind(event.target.value as FindingKind | "all")
                      }
                    >
                      <option value="all">全部类型</option>
                      {Object.entries(kindMeta).map(([id, name]) => (
                        <option key={id} value={id}>
                          {name}
                        </option>
                      ))}
                    </select>
                    <ChevronDown size={12} />
                  </div>
                </div>
                <div className="result-meta">
                  <div>
                    {category !== "all" && (
                      <button
                        className="active-filter"
                        onClick={() => setCategory("all")}
                      >
                        {categoryName(category)}
                        <X size={11} />
                      </button>
                    )}
                    {filtersActive ? (
                      <span>
                        找到<strong>{filtered.length}</strong>项匹配发现
                        <button
                          className="clear-filters"
                          onClick={() => {
                            setCategory("all");
                            setSeverity("all");
                            setKind("all");
                            setQuery("");
                            setOnlyUnreviewed(false);
                          }}
                        >
                          重置筛选
                        </button>
                      </span>
                    ) : (
                      <span>
                        全部<strong>{findings.length}</strong>项发现
                        <span className="result-meta-dot">·</span>
                        严重性与证据类型独立评估
                      </span>
                    )}
                  </div>
                  <label className="unreviewed-filter">
                    <input
                      type="checkbox"
                      checked={onlyUnreviewed}
                      onChange={(event) =>
                        setOnlyUnreviewed(event.target.checked)
                      }
                    />
                    仅看待复核
                  </label>
                </div>
                <div className="findings-table">
                  <div className="findings-table-header">
                    <span>问题与源码位置</span>
                    <span>风险等级</span>
                    <span>审计路径</span>
                    <span />
                  </div>
                  {visible.map((finding, index) => {
                    const source = finding.evidence[0];
                    const CategoryIcon = categoryIcons[finding.category];
                    return (
                      <article
                        className={`finding-row ${reviewed.includes(finding.id) ? "finding-reviewed" : ""}`}
                        key={finding.id}
                        style={
                          { "--row-delay": `${index * 45}ms` } as CSSProperties
                        }
                      >
                        <button
                          className="finding-main"
                          onClick={() => openFinding(finding)}
                        >
                          <div
                            className={`finding-indicator indicator-${finding.severity}`}
                          >
                            <Icon
                              icon={
                                finding.severity === "high"
                                  ? TriangleAlert
                                  : finding.severity === "medium"
                                    ? CircleAlert
                                    : Circle
                              }
                              size={17}
                            />
                          </div>
                          <div className="finding-description">
                            <div className="finding-id">
                              <code>{finding.id}</code>
                              {reviewed.includes(finding.id) && (
                                <span>
                                  <CheckCheck size={11} />
                                  已复核
                                </span>
                              )}
                            </div>
                            <h3>{finding.title}</h3>
                            <p>{finding.summary}</p>
                            <span
                              className="finding-source"
                              title={source.path}
                            >
                              <FileCode2 size={12} />
                              <span>
                                {source.path
                                  .replace(
                                    "src/main/java/chiseled_enchanting_table/",
                                    "",
                                  )
                                  .replace(
                                    "src/client/java/chiseled_enchanting_table/",
                                    "",
                                  )}
                              </span>
                              <code>:{source.start}</code>
                            </span>
                          </div>
                        </button>
                        <div className="finding-severity">
                          <SeverityLabel severity={finding.severity} />
                          <small>{kindMeta[finding.kind]}</small>
                        </div>
                        <button
                          className="finding-category"
                          onClick={() => filterCategory(finding.category)}
                        >
                          <Icon icon={CategoryIcon} size={14} />
                          <span>{categoryName(finding.category)}</span>
                        </button>
                        <button
                          className="finding-open icon-button"
                          onClick={() => openFinding(finding)}
                          aria-label={`查看 ${finding.id} 详情`}
                        >
                          <ChevronRight size={17} />
                        </button>
                      </article>
                    );
                  })}
                  {!visible.length && (
                    <div className="empty-results">
                      <Search size={32} />
                      <h3>没有匹配的审计发现</h3>
                      <p>试试其他关键词，或放宽风险和证据类型筛选。</p>
                      <button
                        className="button button-secondary"
                        onClick={() => {
                          setCategory("all");
                          setSeverity("all");
                          setKind("all");
                          setQuery("");
                          setOnlyUnreviewed(false);
                        }}
                      >
                        重置全部筛选
                      </button>
                    </div>
                  )}
                </div>
                <div className="pagination">
                  <span>
                    {filtered.length
                      ? `显示 ${(activePage - 1) * pageSize + 1}-${Math.min(activePage * pageSize, filtered.length)} 项，共 ${filtered.length} 项`
                      : "0 项结果"}
                  </span>
                  <div>
                    <label>
                      <select
                        aria-label="每页条数"
                        value={pageSize}
                        onChange={(event) =>
                          setPageSize(Number(event.target.value))
                        }
                      >
                        <option value="5">5 条 / 页</option>
                        <option value="10">10 条 / 页</option>
                        <option value="15">全部</option>
                      </select>
                      <ChevronDown size={11} />
                    </label>
                    <button
                      disabled={activePage === 1}
                      aria-label="上一页"
                      onClick={() => setPage(activePage - 1)}
                    >
                      <ChevronLeft size={15} />
                    </button>
                    {Array.from({ length: totalPages }, (_, index) => (
                      <button
                        key={index}
                        className={activePage === index + 1 ? "current" : ""}
                        aria-label={`第 ${index + 1} 页`}
                        aria-current={
                          activePage === index + 1 ? "page" : undefined
                        }
                        onClick={() => setPage(index + 1)}
                      >
                        {index + 1}
                      </button>
                    ))}
                    <button
                      disabled={activePage === totalPages}
                      aria-label="下一页"
                      onClick={() => setPage(activePage + 1)}
                    >
                      <ChevronRight size={15} />
                    </button>
                  </div>
                </div>
                <p className="findings-footnote">
                  <GitCommitHorizontal size={13} />
                  所有源码链接已固定至提交<code>{SHORT_COMMIT}</code>
                  <span>·</span>点击发现查看分析、证据与修复建议
                </p>
              </section>
              <Coverage
                onVerify={() => setView("verification")}
                onCategory={filterCategory}
              />
            </div>
          )}
          {view === "balance" && <BalanceView onFinding={openFinding} />}
          {view === "verification" && <VerificationView />}
          {view === "roadmap" && (
            <RoadmapView reviewed={reviewed} onFinding={openFinding} />
          )}
          <footer className="page-footer">
            <span>
              <span className="footer-logo">
                <Braces size={14} />
              </span>
              SourceLens<span className="footer-dot">·</span>
              每一条结论，都有源码依据。
            </span>
            <span>
              <LockKeyhole size={12} />
              只读报告<span className="footer-dot">·</span>不修改远程仓库
            </span>
          </footer>
        </main>
      </div>
      {selected && (
        <FindingDetail
          key={selected.id}
          finding={selected}
          reviewed={reviewed.includes(selected.id)}
          note={notes[selected.id] ?? ""}
          onClose={closeFinding}
          onReview={() => {
            const already = reviewed.includes(selected.id);
            setReviewed((current) =>
              already
                ? current.filter((id) => id !== selected.id)
                : [...current, selected.id],
            );
            notify(
              already
                ? "已撤销本地复核标记"
                : "已标记为已复核，记录保存在当前浏览器",
            );
          }}
          onNote={(value) =>
            setNotes((current) => ({ ...current, [selected.id]: value }))
          }
          onCopy={() =>
            copy(
              `${location.origin}${location.pathname}#${selected.id}`,
              "发现详情链接已复制",
            )
          }
        />
      )}
      {scopeOpen && (
        <AppDialog
          onClose={closeScope}
          label="审计方法与边界"
          className="scope-dialog"
        >
          <div className="detail-topline">
            <span>
              <ShieldCheck size={17} />
              审计方法与边界
            </span>
            <button
              className="icon-button"
              aria-label="关闭审计方法"
              onClick={closeScope}
            >
              <X size={19} />
            </button>
          </div>
          <div className="scope-dialog-content">
            <span className="scope-big-icon">
              <ShieldCheck size={30} />
            </span>
            <h2>结论可以追溯，边界也要透明。</h2>
            <p>
              本报告固定审阅 26.3 分支的 <code>{SHORT_COMMIT}</code>。15
              项发现中，确定性源码缺陷、条件风险、设计取舍和维护建议分别标注，不把猜测写成已复现
              BUG。
            </p>
            <dl>
              <div>
                <dt>已执行</dt>
                <dd>
                  源码路径审阅、平台 API 对照、9
                  个验证入口，包含真实构建与隔离专服探针。
                </dd>
              </div>
              <div>
                <dt>未执行</dt>
                <dd>
                  真实客户端 GUI、玩家 Shift
                  移物、双端延迟与多人联机、非平坦世界结构行为。
                </dd>
              </div>
              <div>
                <dt>重要限制</dt>
                <dd>
                  Tier 2 已在获取目标 MC JAR
                  后重跑通过。专服探针没有真实玩家且禁用结构生成，不能替代交互验收。
                </dd>
              </div>
              <div>
                <dt>你的复核记录</dt>
                <dd>
                  仅保存在浏览器，可随完整 Markdown / JSON
                  报告导出；不等同于远程代码已修复。
                </dd>
              </div>
            </dl>
            <button
              className="button button-primary"
              onClick={() => {
                setScopeOpen(false);
                setView("verification");
              }}
            >
              查看完整验证记录
              <ArrowRight size={15} />
            </button>
          </div>
        </AppDialog>
      )}
      {toast && (
        <div className="toast" role="status">
          <CheckCircle2 size={17} />
          <span>{toast}</span>
          <button onClick={() => setToast("")} aria-label="关闭提示">
            <X size={14} />
          </button>
        </div>
      )}
    </div>
  );
}
