import {
  categories,
  categoryName,
  checks,
  COMMIT,
  evidenceUrl,
  findings,
  kindMeta,
  REPOSITORY,
  severityMeta,
} from "../data/audit";

export function buildMarkdownReport(
  reviewed: string[] = [],
  notes: Record<string, string> = {},
) {
  const head = [
    "# Chiseled Enchanting Table 26.3 源码审计",
    "",
    `仓库：${REPOSITORY}`,
    `固定提交：${COMMIT}`,
    "基线提交日期：2026-10-24（不是游戏实测日期）",
    "目标：Minecraft 26.3 / Fabric Loader 0.19.5 / Fabric API 0.162.0+26.3 / Java 25 / mod 1.1.0 / protocol revision 6。",
    "",
    "## 结论与边界",
    "",
    `${findings.length} 项发现：1 项高风险、9 项中风险、5 项低风险。严重性与证据确定性分开记录。`,
    "本报告为固定提交的源码审计与自动验证，没有修改远程仓库。源码确认不等于已用玩家操作在游戏中复现。",
    "本轮补装并校验 Temurin Java 25.0.5，完成 Gradle 9.5.1 标准构建、无 JEI/REI 的干净构建，现有 52 项 JUnit 在两条构建中均全部通过。实际解析 Loom 1.17.21。",
    "本轮完成真实专服 smoke：隔离平坦世界启动、reload、组件掉落、条件战利品、仪式持久状态/自然完成、坏注册项隔离、破坏返还库存与正常停服。预期的隔离 WARN 不应描述为零警告。",
    "未执行真实客户端 GUI、玩家 Shift 移物、双端握手/延迟请求或多人测试；专服禁用结构生成，不能声称执行了所有延迟 Mixin。历史 CI 不计为本轮实测。",
    "26.3 输入和槽位 API 额外对照了非官方反编译源码镜像；Fabric 回调线程契约对照目标版本 Javadoc。",
    "初次离线检查跳过原版 ID / 标签 Tier 2；获取目标 MC JAR 后已重跑通过，最终 0 条 WARN。",
    "",
    "## 审计路径",
    "",
    ...categories.map(
      (category) => `- ${category.name}：${category.description}。`,
    ),
    "",
    "## 发现",
    "",
  ];
  const body = findings.flatMap((finding) => [
    `### ${finding.id} ${finding.title}`,
    "",
    `级别：${severityMeta[finding.severity].priority} ${severityMeta[finding.severity].label} | 路径：${categoryName(finding.category)} | 证据：${kindMeta[finding.kind]}`,
    `本地复核：${reviewed.includes(finding.id) ? "已复核（不代表已修复）" : "待复核"}`,
    "",
    finding.summary,
    "",
    "**影响**",
    "",
    finding.impact,
    "",
    "**根因**",
    "",
    finding.analysis,
    "",
    "**复现 / 核查步骤**",
    "",
    ...finding.reproduce.map((step, i) => `${i + 1}. ${step}`),
    "",
    "**建议**",
    "",
    finding.recommendation,
    "",
    "**回归验收**",
    "",
    ...finding.validation.map((entry) => `- ${entry}`),
    "",
    "**源码证据**",
    "",
    ...finding.evidence.map(
      (entry) =>
        `- [${entry.path}:${entry.start}-${entry.end}](${evidenceUrl(entry)})：${entry.description}`,
    ),
    ...(notes[finding.id] ? ["", "**本地备注**", "", notes[finding.id]] : []),
    "",
  ]);
  return [
    ...head,
    ...body,
    "## 本轮验证记录",
    "",
    ...checks.map(
      (check) =>
        `- ${check.command}：${check.result}。${check.detail}${check.log ? ` 日志：public${check.log}` : ""}`,
    ),
    "",
    "## 数值与机制判断",
    "",
    "- 38 书架升级曲线与 XP 势能守恒的现有 Java 测试已重跑通过，但不能据此声称覆盖了所有数据包经济环路。重复材料与备选费用分支仍需要新增行为回归。",
    "- 0 / 38 / 42 书架恢复间隔分别为 24,000 / 12,000 / 3,600 秒。42 书架下一次 4 点复制成本约需 4 小时恢复；16 点预算约 16 小时。",
    "- 持久库存是当前实现，关闭菜单不会自动返还台子内物品；重载验收必须按此行为检查，不应沿用旧报告的返回物品断言。",
    "- 65,536 集合上限、256 队列步数、32,000 字符、扫描体积上限属于资源安全边界，不应全部暴露为无约束平衡配置。",
    "",
    "## 建议顺序",
    "",
    "1. 先修复 CET-001，保护物品守恒。",
    "2. 修复 SDL 输入、材料账本和缺失物品校验，补充数据包集成回归。",
    "3. 为请求加实例绑定、为费用表加双端总预算，然后进行真实双端延迟测试。",
    "4. 再决定恢复进度与仪式节奏，最后清理旧代码和类型契约。",
    "",
  ].join("\n");
}

export function regenSeconds(shelves: number) {
  const s = Math.max(0, shelves);
  if (s < 38) return Math.round(480_000 - ((480_000 - 360_000) * s) / 38) / 20;
  if (s < 42)
    return Math.round(240_000 - ((240_000 - 156_000) * (s - 38)) / 4) / 20;
  return (
    Math.max(
      36_000,
      Math.min(72_000, Math.round(72_000 / (1 + 0.05 * (s - 42)))),
    ) / 20
  );
}

export function ritualSeconds(shelves: number, tomeEnchants: number) {
  if (shelves < 32 && tomeEnchants < 10) return 0;
  const intensity = (0.42 * shelves) / 42 + (0.58 * tomeEnchants) / 22;
  return (
    Math.min(
      6000,
      Math.max(100, Math.round(300 * (1 - Math.exp(-0.62 * intensity)) * 20)),
    ) / 20
  );
}

export function duration(seconds: number) {
  const rounded = Math.round(seconds);
  if (rounded < 60) return `${rounded} 秒`;
  if (rounded < 3600)
    return `${Math.floor(rounded / 60)} 分 ${rounded % 60} 秒`;
  const totalMinutes = Math.round(rounded / 60);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return minutes ? `${hours} 小时 ${minutes} 分` : `${hours} 小时`;
}
