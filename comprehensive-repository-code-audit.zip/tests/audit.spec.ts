import { test, expect } from "@playwright/test";
import { readFile } from "node:fs/promises";

test.beforeEach(async ({ page }) => {
  await page.goto("/");
});

test("baseline, totals and priority order render without runtime errors", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));
  await expect(
    page.getByRole("heading", {
      name: "Chiseled Enchanting Table",
      exact: true,
    }),
  ).toBeVisible();
  await expect(page.locator(".finding-row")).toHaveCount(5);
  await expect(page.locator(".finding-row").first()).toContainText("CET-001");
  await expect(page.locator(".metric-total strong")).toHaveText("15");
  await expect(page.locator(".metric-high strong")).toHaveText("01");
  await expect(page.locator(".metric-medium strong")).toHaveText("09");
  await expect(page.locator(".metric-low strong")).toHaveText("05");
  await expect(page.locator(".coverage-list button")).toHaveCount(8);
  expect(errors).toEqual([]);
});

test("risk, evidence-type, search and reset filters work together", async ({
  page,
}) => {
  await page.getByLabel("风险等级", { exact: true }).selectOption("high");
  await expect(page.locator(".finding-row")).toHaveCount(1);
  await expect(page.locator(".finding-row")).toContainText("CET-001");
  await page.getByRole("button", { name: "重置筛选", exact: true }).click();
  await page.getByLabel("证据类型", { exact: true }).selectOption("design");
  await expect(page.locator(".finding-row")).toHaveCount(2);
  await expect(page.locator(".result-meta")).toContainText("2");
  await page.getByLabel("搜索审计发现").fill("恢复");
  await expect(page.locator(".finding-row")).toHaveCount(1);
  await expect(page.locator(".finding-row")).toContainText("CET-010");
  await page.getByRole("button", { name: "重置筛选", exact: true }).click();
  await page.getByLabel("搜索审计发现").fill("does-not-exist");
  await expect(page.getByText("没有匹配的审计发现")).toBeVisible();
  await page.getByRole("button", { name: "重置全部筛选", exact: true }).click();
  await expect(page.locator(".finding-row")).toHaveCount(5);
});

test("sidebar category selection and pagination are functional", async ({
  page,
}) => {
  await page
    .getByRole("navigation", { name: "审计路径", exact: true })
    .getByRole("button", { name: /GUI 输入/ })
    .click();
  await expect(page.locator(".finding-row")).toHaveCount(2);
  await expect(page.locator(".findings-heading")).toContainText("GUI 输入");
  await page
    .getByRole("navigation", { name: "主导航" })
    .getByRole("button", { name: /全部发现/ })
    .click();
  await page.getByRole("button", { name: "第 3 页", exact: true }).click();
  await expect(page.locator(".finding-row").first()).toContainText("CET-011");
  await expect(page.locator(".pagination")).toContainText(
    "显示 11-15 项，共 15 项",
  );
  await page.getByLabel("每页条数").selectOption("15");
  await expect(page.locator(".finding-row")).toHaveCount(15);
  await expect(
    page.getByRole("button", { name: "下一页", exact: true }),
  ).toBeDisabled();
});

test("detail drawer exposes fixed source evidence and closes by Escape", async ({
  page,
}) => {
  await page
    .getByRole("button", { name: "查看 CET-001 详情", exact: true })
    .click();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toBeVisible();
  await expect(page).toHaveURL(/#CET-001$/);
  await expect(dialog).toContainText("源码确认");
  await dialog.getByRole("tab", { name: /源码证据/ }).click();
  const firstSource = dialog.locator(".evidence-path").first();
  await expect(firstSource).toHaveAttribute(
    "href",
    /blob\/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5\/.*#L2252-L2305$/,
  );
  await expect(dialog.locator(".code-block")).toHaveCount(2);
  await dialog.getByRole("tab", { name: "修复与验证", exact: true }).click();
  await expect(dialog).toContainText("统一的移动事务");
  await page.keyboard.press("Escape");
  await expect(dialog).not.toBeVisible();
  await expect(page).not.toHaveURL(/#CET-001$/);
});

test("local review and notes persist without implying a remote fix", async ({
  page,
}) => {
  await page
    .getByRole("button", { name: "查看 CET-001 详情", exact: true })
    .click();
  await page
    .getByLabel("复核备注", { exact: true })
    .fill("待双端复现：Shift 移动与存档完整性。");
  await page.getByRole("button", { name: "标记为已复核", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "已复核，点击撤销", exact: true }),
  ).toBeVisible();
  await page.reload();
  await expect(page.getByLabel("复核备注", { exact: true })).toHaveValue(
    "待双端复现：Shift 移动与存档完整性。",
  );
  await expect(
    page.getByRole("button", { name: "已复核，点击撤销", exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "关闭详情", exact: true }).click();
  await page.getByLabel("仅看待复核", { exact: true }).check();
  await expect(page.locator(".finding-row").first()).toContainText("CET-002");
  await expect(page.locator(".result-meta")).toContainText("14");
});

test("exports complete Markdown and JSON rather than only the visible page", async ({
  page,
}) => {
  await page.getByRole("button", { name: /导出报告/ }).click();
  const downloadEvent = page.waitForEvent("download");
  await page.getByRole("button", { name: /Markdown 包含证据链接/ }).click();
  const download = await downloadEvent;
  expect(download.suggestedFilename()).toBe("CET-26.3-audit-d2abe21.md");
  const content = await readFile((await download.path())!, "utf8");
  expect(content).toContain("### CET-015");
  expect(content).toContain("1 项高风险、9 项中风险、5 项低风险");
  expect(content).toContain("未执行真实客户端 GUI");
  await page.getByRole("button", { name: /导出报告/ }).click();
  const jsonEvent = page.waitForEvent("download");
  await page.getByRole("button", { name: /JSON 结构化发现/ }).click();
  const json = JSON.parse(
    await readFile((await (await jsonEvent).path())!, "utf8"),
  );
  expect(json.findings).toHaveLength(15);
  expect(json.commit).toBe("d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5");
});

test("mechanism simulator matches the audited defaults and threshold", async ({
  page,
}) => {
  await page
    .getByRole("navigation", { name: "报告视图" })
    .getByRole("button", { name: "数值与机制", exact: true })
    .click();
  await expect(page.getByTestId("regen-result")).toHaveText("1 小时");
  await page.getByRole("button", { name: "38 书架", exact: true }).click();
  await expect(page.getByTestId("regen-result")).toHaveText("3 小时 20 分");
  await page.getByRole("button", { name: "基础状态", exact: true }).click();
  await expect(page.getByTestId("regen-result")).toHaveText("6 小时 40 分");
  await page.getByLabel("仪式书架数量", { exact: true }).fill("31");
  await expect(page.getByTestId("ritual-result")).toHaveText("0 秒");
  await page.getByLabel("仪式书架数量", { exact: true }).fill("32");
  await expect(page.getByTestId("ritual-result")).toHaveText("54 秒");
});

test("verification boundaries and roadmap links remain explicit", async ({
  page,
}) => {
  await page
    .getByRole("navigation", { name: "报告视图" })
    .getByRole("button", { name: "验证与边界", exact: true })
    .click();
  await expect(page.locator(".check-row")).toHaveCount(9);
  await expect(page.locator(".unverified-section")).toContainText(
    "仍需要真实 26.3 双端验收",
  );
  await expect(
    page.locator(".check-row").filter({ hasText: "数据包兼容检查" }),
  ).toContainText("Tier 2 也通过");
  await expect(
    page.locator(".check-row").filter({ hasText: "标准构建与现有 JUnit" }),
  ).toContainText("52 项通过");
  await page
    .getByRole("navigation", { name: "报告视图" })
    .getByRole("button", { name: "修复路线", exact: true })
    .click();
  await expect(page.locator(".roadmap-stage")).toHaveCount(4);
  await page
    .locator(".stage-findings button")
    .filter({ hasText: "CET-008" })
    .click();
  await expect(page.getByRole("dialog")).toContainText("苹果");
});

test("keyboard search and copy buttons provide feedback", async ({
  page,
  context,
}) => {
  await context.grantPermissions(["clipboard-read", "clipboard-write"]);
  await page.keyboard.press("/");
  await expect(page.getByLabel("搜索审计发现")).toBeFocused();
  await page.getByLabel("搜索审计发现").fill("CET-013");
  await expect(page.locator(".finding-row")).toHaveCount(1);
  await page.getByLabel("搜索审计发现").press("Escape");
  await page.getByTitle("复制完整提交 SHA", { exact: true }).click();
  await expect(page.getByRole("status")).toContainText("完整提交 SHA 已复制");
  const clipboard = await page.evaluate(() => navigator.clipboard.readText());
  expect(clipboard).toBe("d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5");
});

test("responsive layouts do not overflow and mobile navigation works", async ({
  page,
}) => {
  for (const width of [1440, 1024, 768, 390]) {
    await page.setViewportSize({ width, height: 900 });
    expect(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
    ).toBe(true);
  }
  await page.getByRole("button", { name: "打开导航", exact: true }).click();
  await page
    .getByRole("navigation", { name: "主导航" })
    .getByRole("button", { name: "验证记录", exact: true })
    .click();
  await expect(
    page.getByRole("heading", { name: "验证记录与审计边界", exact: true }),
  ).toBeVisible();
  await expect(page.locator(".sidebar")).not.toHaveClass(/sidebar-open/);
});
