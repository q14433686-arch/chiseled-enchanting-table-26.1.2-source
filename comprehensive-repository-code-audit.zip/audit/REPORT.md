# Chiseled Enchanting Table 26.3 源码审计

仓库：https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source
固定提交：d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5
基线提交日期：2026-10-24（不是游戏实测日期）
目标：Minecraft 26.3 / Fabric Loader 0.19.5 / Fabric API 0.162.0+26.3 / Java 25 / mod 1.1.0 / protocol revision 6。

## 结论与边界

15 项发现：1 项高风险、9 项中风险、5 项低风险。严重性与证据确定性分开记录。
本报告为固定提交的源码审计与自动验证，没有修改远程仓库。源码确认不等于已用玩家操作在游戏中复现。
本轮补装并校验 Temurin Java 25.0.5，完成 Gradle 9.5.1 标准构建、无 JEI/REI 的干净构建，现有 52 项 JUnit 在两条构建中均全部通过。实际解析 Loom 1.17.21。
本轮完成真实专服 smoke：隔离平坦世界启动、reload、组件掉落、条件战利品、仪式持久状态/自然完成、坏注册项隔离、破坏返还库存与正常停服。预期的隔离 WARN 不应描述为零警告。
未执行真实客户端 GUI、玩家 Shift 移物、双端握手/延迟请求或多人测试；专服禁用结构生成，不能声称执行了所有延迟 Mixin。历史 CI 不计为本轮实测。
26.3 输入和槽位 API 额外对照了非官方反编译源码镜像；Fabric 回调线程契约对照目标版本 Javadoc。
初次离线检查跳过原版 ID / 标签 Tier 2；获取目标 MC JAR 后已重跑通过，最终 0 条 WARN。

## 审计路径

- 源码 API：版本接口、注册表与构建依赖。
- 数据编解码：规则解析、材料账本与协议边界。
- 网络同步：菜单身份、服务端权威与延迟请求。
- GUI 输入：SDL 键位、快捷移动与槽位保护。
- Mixin 注入：注入目标与跨配置行为一致性。
- 死代码：编译排除的遗留实现与无调用方法。
- 耦合风险：规则覆盖、类型边界与单一数据来源。
- 数值与机制：恢复时长、仪式门槛与可配置性。

## 发现

### CET-001 仪式期间的快捷移动绕过槽位锁

级别：P1 高风险 | 路径：GUI 输入 | 证据：源码确认
本地复核：待复核

Shift 点击背包物品时先替换源槽，再尝试写入已锁定的目标槽，存在物品丢失和重复引用路径。

**影响**

普通玩家操作即可进入该分支。正在仪式中的物品可能同时被背包和附魔台引用，而被 Shift 点击的另一件物品丢失。实际持久化后的表现仍需游戏复现。

**根因**

QUICK_MOVE 只禁止从 ENCHANTABLE_SLOT 取出，没有禁止背包向该槽写入。2299 行把旧目标直接放到玩家源槽，2300 行再写新目标。方块实体 setItem 在有仪式时静默拒绝后一次写入；Slot.set 本身不调用 mayPlace。相同物品的 grow 分支同样绕过锁，会使仪式目标数量异常。

**复现 / 核查步骤**

1. 放入一件可附魔装备，布置足以启动等待仪式的书架并开始铭刻。
2. 仪式尚未完成时，按住 Shift 点击背包中的另一件可附魔装备。
3. 核对两个槽位的物品、数量与组件，再关闭菜单、重开及重启存档检查。

**建议**

在任何 QUICK_MOVE 源槽变更前校验目标 mayPlace、源槽 mayPickup 和方块实体 hasActiveRitual。通过统一的移动事务提交两端变更，不要先交换源槽再依赖静默拒写。

**回归验收**

- 覆盖仪式中从背包移入、从台子移出、同物品合并和不同物品交换。
- 断言操作前后物品总量、组件和对象归属不变，并加入多人共享台子测试。

**源码证据**

- [src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java:2252-2305](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java#L2252-L2305)：QUICK_MOVE 仅对源槽 0 上锁，随后直接交换槽位。
- [src/main/java/chiseled_enchanting_table/block/ChiseledEnchantingTableBlockEntity.java:142-148](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/block/ChiseledEnchantingTableBlockEntity.java#L142-L148)：仪式期间对目标槽的 setItem 静默返回。
- [net/minecraft/world/inventory/Slot.java:62-76](https://github.com/0khs/minecraft_source_26.3/blob/74720c2890f22942b72d7d84958eff1b3f72b95b/net/minecraft/world/inventory/Slot.java#L62-L76)：26.3 参考实现：set 直接调用 Container.setItem，不检查 mayPlace。

### CET-002 附魔列表仍使用 GLFW 回车键编号

级别：P2 中风险 | 路径：GUI 输入 | 证据：源码确认
本地复核：待复核

257 / 335 不再是 26.3 的 Enter / 小键盘 Enter，键盘确认路径失效。

**影响**

键盘导航用户按回车无法触发预期确认。鼠标左键已迁移到平台常量，本问题仅指附魔列表遗留的键盘判断。

**根因**

KeyEvent.key() 在 26.3 使用 InputConstants 的 SDL 扫描码。参考源码的 KEY_RETURN 为 40，KEY_NUMPADENTER 为 88；列表仍比较旧 GLFW 编号 257、335。触发后还忽略消费事件的返回值，主屏继续调用 super.keyPressed。

**复现 / 核查步骤**

1. 用方向键聚焦一条可执行的附魔选项。
2. 分别按主键盘 Enter 与小键盘 Enter，对比左键点击效果。

**建议**

使用 InputConstants.KEY_RETURN 和 KEY_NUMPADENTER；成功处理时返回 true，并让主屏尊重子组件的事件消费结果。

**回归验收**

- 在真实 26.3 客户端覆盖两种回车、方向键和 Esc。
- 断言一次确认只发送一个操作请求。

**源码证据**

- [src/client/java/chiseled_enchanting_table/gui/EnchantementListWidget.java:167-175](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/client/java/chiseled_enchanting_table/gui/EnchantementListWidget.java#L167-L175)：遗留的 GLFW 数字常量。
- [com/mojang/blaze3d/platform/InputConstants.java:104-145](https://github.com/0khs/minecraft_source_26.3/blob/74720c2890f22942b72d7d84958eff1b3f72b95b/com/mojang/blaze3d/platform/InputConstants.java#L104-L145)：26.3 参考源码的 SDL 常量分别为 88 和 40。
- [src/client/java/chiseled_enchanting_table/gui/ChiseledEnchantingTableScreen.java:492-502](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/client/java/chiseled_enchanting_table/gui/ChiseledEnchantingTableScreen.java#L492-L502)：主屏没有使用子组件的返回值。

### CET-003 重复材料条目没有合并为统一账本

级别：P2 中风险 | 路径：数据编解码 | 证据：源码确认
本地复核：待复核

同一材料出现在多个附加费用中时，检查阶段会重复使用同一份库存，扣费可能不足。

**影响**

自定义数据包可形成低于声明费用的配方。默认配方不一定触发，不能将此描述为已证实的默认经济漏洞。

**根因**

maxBundleUnitsAvailable 针对每个 add 分别检查库存，未按物品及组件汇总全部需求。主材料不同、两个附加条目均为 8 个绿宝石时，背包只有 8 个也能分别通过。consumeAdditionalCosts 扣完第一个后，第二个不足不会回滚或阻止产物。

**复现 / 核查步骤**

1. 建立主费用为 1 钻石、附加费用为 8 绿宝石 + 8 绿宝石的转化规则。
2. 费用槽放 1 钻石，背包仅放 8 绿宝石，执行一次转化。
3. 预期应拒绝；当前计数分支会把两个附加条目分别视为可支付。

**建议**

按 ItemStack.isSameItemSameComponents 等价关系归并需求，并明确主材料可用池与附加材料可用池。先生成完整扣费计划，全部可支付后再原子提交。

**回归验收**

- 测试主材料重复、附加材料重复、三个重复条目和组件不同但物品相同的情况。
- 检查单次和批量操作的实际扣费均等于汇总账本。

**源码证据**

- [src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java:1318-1339](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java#L1318-L1339)：逐条检查，未累计同类附加材料。
- [src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java:2110-2122](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java#L2110-L2122)：不足时不会使整个操作失败。
- [src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java:1285-1289](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java#L1285-L1289)：additional_costs 允许多个相同材料条目。

### CET-004 备选主材料路径跳过独立附加费用

级别：P2 中风险 | 路径：数据编解码 | 证据：源码确认
本地复核：待复核

同时声明 cost_options 与 additional_costs 的转化规则，会只返回备选费用 Bundle。

**影响**

数据包作者声明的公共附加成本可能未被收取。仅在同时使用两个字段时触发。

**根因**

transformationCostOptions 在有 alternativePrimaryOptions 时直接返回 alternativeBundles；后面的 additionalCostStacks 仅在没有备选项时加入。alternativeBundles 只展开每个备选项自身的 extras，没有拼接转化级的 additionalCosts。

**复现 / 核查步骤**

1. 定义两个 cost_options，并在转化顶层声明 additional_costs 为 1 钻石。
2. 分别选择两种备选主材料，检查显示及实际扣费是否都包含该钻石。

**建议**

先为每个备选项构建主材料 Bundle，再将顶层公共附加费用拼接到每个 Bundle 并归一化；或者在 schema 中明确拒绝这个组合。

**回归验收**

- 增加 cost_options + additional_costs 的解析到执行集成测试。
- 覆盖备选项自身 extras 与公共费用重复的情况。

**源码证据**

- [src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java:442-451](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java#L442-L451)：提前返回绕过下面的附加费用拼接。
- [src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java:1330-1335](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java#L1330-L1335)：每个备选项只展开自己的费用。

### CET-005 折扣终点被升级书架上限隐式覆盖

级别：P2 中风险 | 路径：耦合风险 | 证据：源码确认
本地复核：待复核

max_discount_bookshelves 虽能解析，却在有效配置组装时被 maxDirectBookshelves 替代。

**影响**

数据包单独修改折扣曲线终点不会生效，书架升级与 XP 折扣两个规则域被意外绑在一起。

**根因**

LibraryResonance.Config.fromJson 读取 max_discount_bookshelves，费用包也同步它；但 applyRuntimeConfig 构造有效 LibraryResonance.Config 时使用 Math.max(lr.minDiscountBookshelves() + 1, maxDirect)。因此默认值碰巧同为 38，掩盖了配置覆盖。

**复现 / 核查步骤**

1. 保持 max_direct_bookshelves = 38，把木书架 max_discount_bookshelves 设置为 60。
2. 重载后检查有效配置及 38 书架时的折扣，确认终点是否仍为 38。

**建议**

保留 lr.maxDiscountBookshelves() 为独立输入，只做自身合法性约束。若产品有意统一终点，应删除重复配置键并提供迁移说明。

**回归验收**

- 分别修改升级终点和折扣终点，断言互不改写。
- 测试完整路径：JSON -> RuntimeFrame -> S2C -> GUI 费用。

**源码证据**

- [src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java:674-688](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java#L674-L688)：有效配置组装时替换了数据包给出的折扣终点。
- [src/main/java/chiseled_enchanting_table/mechanics/resonance/LibraryResonance.java:263-275](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/mechanics/resonance/LibraryResonance.java#L263-L275)：解析器确实读取该独立配置键。

### CET-006 普通操作请求没有绑定菜单实例

级别：P2 中风险 | 路径：网络同步 | 证据：条件风险
本地复核：待复核

附魔、重掷和冻结请求只作用于“当前同类型菜单”，没有 containerId 或会话校验。

**影响**

延迟或重放请求可能在快速关开菜单后作用到另一张台子。服务端仍计算真实费用，这不是任意远程免费附魔漏洞。

**根因**

ApplyEnchantmentPayload 只有 type、id、level，Reroll 和 Freeze 为空包。接收器仅检查当前菜单类型，再次 execute 后读取玩家的当前菜单。SkipRitual 已使用 containerId + session，普通操作尚未采用同样约束。普通 TCP 有序传输本身不能证明会误投；必须验证额外任务延后或人为重放等触发条件。

**复现 / 核查步骤**

1. 在网络延迟环境向台子 A 发送冻结或附魔请求，随后立即关菜单并打开台子 B。
2. 通过受控网络测试延迟该请求的执行，检查它能否误作用于 B。

**建议**

统一操作信封：containerId、菜单 nonce、规则 revision 和操作参数；服务端验证 stillValid 及目标实例，拒绝过期请求。

**回归验收**

- 真实双端延迟、快速重开、重复请求和两张台子切换。
- 保留费用、权限、物品与书架状态的服务端二次校验。

**源码证据**

- [src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingMenuPayloads.java:493-512](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingMenuPayloads.java#L493-L512)：附魔请求没有菜单标识。
- [src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java:57-90](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java#L57-L90)：按执行时的当前菜单类型派发。
- [src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java:100-107](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java#L100-L107)：SkipRitual 已有可复用的实例校验模式。

### CET-007 不可信附魔 ID 直接进入 getOrThrow

级别：P2 中风险 | 路径：源码 API | 证据：源码确认
本地复核：待复核

可解码但未注册的附魔 ID 会沿服务端操作路径抛出异常，缺少统一的语义拒绝边界。

**影响**

修改客户端可重复触发任务异常和日志噪声。没有证据证明这会使专服崩溃，不应将其表述为远程崩服漏洞。

**根因**

Identifier 解码只验证 ID 格式，不验证注册表存在性。EnchantmentApplication.apply 在进行解锁检查前调用 IdentifierToEnchantment，后者使用 getOrThrow；接收器没有针对非法操作的受控拒绝处理。

**复现 / 核查步骤**

1. 在打开本模组菜单后，发送合法格式但不存在的 audit:missing_enchantment ID。
2. 检查服务器日志及处理结果，再覆盖非法等级和已移除的注册项。

**建议**

先用 Optional 查询注册表，校验 optionType、level、目标可用性及解锁集合；无效请求安静拒绝并做限速诊断，不要吞掉真正的内部错误。

**回归验收**

- 未知命名空间、未知 ID、等级 0 / 负值 / 超上限均有显式拒绝。
- 在不改变物品或 XP 的前提下返回可诊断结果。

**源码证据**

- [src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java:2068-2069](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java#L2068-L2069)：通用查询助手直接抛异常。
- [src/main/java/chiseled_enchanting_table/mechanics/enchanting/EnchantmentApplication.java:34-49](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/mechanics/enchanting/EnchantmentApplication.java#L34-L49)：在解锁检查之前处理客户端给出的 ID。

### CET-008 无效转化物品被硬编码替换为苹果

级别：P2 中风险 | 路径：数据编解码 | 证据：源码确认
本地复核：待复核

缺失输出 ID 时仍然扣费并产出 apple；缺失材料 ID 则回退为 lapis_lazuli。

**影响**

可选模组缺失或数据包拼写错误时，配方语义被静默改变，玩家可能用昂贵材料换得苹果。WARN 并不能代替安全拒绝。

**根因**

ItemTransformation.outputStack 在未知输出或 AIR 时选择 Items.APPLE。ItemTransformationApplication 在构建产物前已调用 applyEnchantementCondition 扣费。ItemCostOption.candidateItems 对未知材料或空标签也回退为青金石。

**复现 / 核查步骤**

1. 添加输出为 missing_mod:artifact 的转化规则，并准备所有声明费用。
2. 执行转化，检查是否扣费后得到苹果；再对缺失材料 ID 和空物品标签进行测试。

**建议**

资源加载阶段验证输出与材料 ID；未知必需项应禁用该规则或让重载失败。可选集成使用明确的加载条件，不用通用物品兜底改变经济。

**回归验收**

- 测试缺失模组、未知输出、AIR 输出、空标签和未知费用。
- 所有无效规则都必须保证不扣物品、不扣 XP、不生成替代产物。

**源码证据**

- [src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java:1338-1345](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java#L1338-L1345)：未知输出的苹果兜底。
- [src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java:1660-1674](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java#L1660-L1674)：材料或标签无法解析时改用青金石。
- [src/main/java/chiseled_enchanting_table/mechanics/transformation/ItemTransformationApplication.java:49-60](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/mechanics/transformation/ItemTransformationApplication.java#L49-L60)：扣费发生在构造输出之前。

### CET-009 费用表的发送端没有匹配解码预算

级别：P2 中风险 | 路径：数据编解码 | 证据：条件风险
本地复核：待复核

解码限制每个集合 65,536 项，但发送端按全部附魔等级展开，没有分片或总预算。

**影响**

高等级附魔数据包或大型整合包可能生成客户端必然拒绝的费用表。嵌套集合还有放大分配风险，但包大小与实际阈值需要运行测试。

**根因**

每个 maxLevel=M 的附魔产生 4M + 2(M-1) = 6M-2 行。43 个上限为 255 的附魔就产生 65,704 行，已超过 readCount 的 65,536 限制，尚未计入其他附魔和转化。写入方只写 costs.size()，未对齐此上限。

**复现 / 核查步骤**

1. 用测试数据包注册 43 个 max_level=255 的附魔。
2. 连接服务器并捕获费用表生成和解码，检查行数、字节数与内存占用。

**建议**

规定发送与接收共享的总行数、总物品数、嵌套深度及字节预算；超预算使用 revision + 分片同步，或按可见操作按需生成费用。

**回归验收**

- 增加 65,535 / 65,536 / 65,537 边界的真实 codec 测试。
- 验证非空、带自定义组件的 registry-aware ItemStack 往返。

**源码证据**

- [src/main/java/chiseled_enchanting_table/menu/EnchantCostTablePayload.java:69-123](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/menu/EnchantCostTablePayload.java#L69-L123)：按所有附魔的所有等级无界展开费用行。
- [src/main/java/chiseled_enchanting_table/menu/EnchantCostTablePayload.java:269-278](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/menu/EnchantCostTablePayload.java#L269-L278)：写入前没有共同预算检查。
- [src/main/java/chiseled_enchanting_table/menu/PayloadLimits.java:6-16](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/menu/PayloadLimits.java#L6-L16)：接收端的单集合上限。

### CET-010 长恢复周期与会话进度重置互相放大

级别：P2 中风险 | 路径：数值与机制 | 证据：设计取舍
本地复核：待复核

42 书架时每点恢复约 1 小时；离开持续观察范围或重启，会丢失尚未结算的恢复进度。

**影响**

短时游玩的玩家可能多次游玩仍无法恢复 1 点。它是反套利与游玩节奏的取舍，不是单位换算错误；不能直接断言必须缩短为旧注释的数值。

**根因**

实际默认恢复间隔为 0 书架 24,000 秒、38 书架 12,000 秒、42 书架 3,600 秒。按 16 点完整磨损预算计算，42 书架需约 16 小时，复制一次的 4 点成本需约 4 小时。RegenerationScheduler 是纯会话状态，缺观察窗口会重置，停服也清空；原有部分注释仍写 30s / 10s，与实现不符。

**复现 / 核查步骤**

1. 42 书架下放入有磨损的母本，持续加载并观察 59 分钟。
2. 卸载相关区块或重启，再加载并观察恢复所需时间。
3. 与连续加载超过 1 小时的控制组比较。

**建议**

先确定是“连续驻留奖励”还是“累计恢复”。若目标是累计恢复，持久化服务端拥有的恢复进度，绑定世界、书架、槽位与书本身份，保持重叠台子不叠加、防移动套利。同步修正旧时长注释。

**回归验收**

- 覆盖 0 / 37 / 38 / 41 / 42 / 62 书架的精确间隔。
- 验证离线、区块卸载、重启、换书和改变恢复档位的产品约定。

**源码证据**

- [src/main/java/chiseled_enchanting_table/mechanics/resonance/MasterTomeWear.java:57-68](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/mechanics/resonance/MasterTomeWear.java#L57-L68)：恢复周期的真实默认值。
- [src/main/java/chiseled_enchanting_table/mechanics/resonance/RegenerationScheduler.java:33-67](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/mechanics/resonance/RegenerationScheduler.java#L33-L67)：缺失窗口、对象或速率变化会重置驻留进度。
- [src/main/java/chiseled_enchanting_table/mechanics/resonance/WorldRegeneration.java:27-39](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/mechanics/resonance/WorldRegeneration.java#L27-L39)：停服清空会话状态，没有保存部分恢复进度。

### CET-011 原版附魔上限对齐仍固定为半级上限

级别：P3 低风险 | 路径：Mixin 注入 | 证据：条件风险
本地复核：待复核

ALIGN_CAPS 固定 ceil(maxLevel / 2)，没有跟随可配置的 blankMaxTierMode。

**影响**

同时使用 ALIGN_CAPS 和 full_curve / level_one_only 时，两套台子的上限语义不一致。是否应跟随配置，需要先明确该模式的产品定义。

**根因**

DisableBookEnchanting 的 RETURN 注入始终执行 (maxLvl + 1) / 2；BookshelfProgression.maxBlankWoodenTier 已支持三个模式。如果 ALIGN_CAPS 的含义是对齐当前空白铭刻策略，应复用统一的 cap 解析器，而不是复制默认公式。现有证据不表明注入签名在 26.3 失效。

**复现 / 核查步骤**

1. 设置 vanilla_table_mode=align_caps，分别选择三种 blank_max_tier_mode。
2. 比较同一附魔在原版台子和纂刻台上的上限。

**建议**

明确 ALIGN_CAPS 是“固定半级”还是“跟随当前策略”。前者应改名和补充说明，后者提取无世界依赖的统一上限函数。

**回归验收**

- 覆盖 3 种 blank 策略与 ALL / NONE / BOOKS / ALIGN_CAPS 的组合。
- 铁砧和结构注入仍需在非平坦真实世界里执行验收。

**源码证据**

- [src/main/java/chiseled_enchanting_table/mixin/enchanting_table/DisableBookEnchanting.java:45-70](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/mixin/enchanting_table/DisableBookEnchanting.java#L45-L70)：注入中复制了固定的半级公式。
- [src/main/java/chiseled_enchanting_table/mechanics/resonance/BookshelfProgression.java:483-499](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/mechanics/resonance/BookshelfProgression.java#L483-L499)：业务规则已经有可配置的三分支上限。

### CET-012 遗留实现与无调用费用方法仍留在源码树

级别：P3 低风险 | 路径：死代码 | 证据：维护建议
本地复核：待复核

旧结构、战利品和集成实现被编译排除；Handler 内另有未使用的 XP 与材料检查方法。

**影响**

主要影响维护与审计准确性，不是运行时重复注入。误把排除目录当作现行实现，容易修错代码或重新引入旧 API。

**根因**

build.gradle 86-90 行明确排除 legacy 路径。相关四组目录约 2,027 行，另有被排除的工具文件。calculateXpCostToLevel 与 hasAdditionalCosts 在当前仓库中只有定义，没有调用，现行 XP 路径使用 XpCostConversion。

**复现 / 核查步骤**

1. 比对 sourceSets.main.java.exclude 与当前 mixin 配置。
2. 对两个方法进行全仓调用搜索，并检查构建产物是否包含旧类。

**建议**

移入明确的 archive 目录或删除已被 Git 历史保存的旧实现；删除私有无调用方法，公共方法先确认外部二进制兼容需求。让静态门禁区分活跃与归档源码。

**回归验收**

- 检查发布 JAR 中没有遗留类。
- 保留新旧实现迁移说明，确保编译排除项不能意外被重新启用。

**源码证据**

- [build.gradle:64-90](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/build.gradle#L64-L90)：编译排除项是判断死代码范围的依据。
- [src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java:2076-2108](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingTableScreenHandler.java#L2076-L2108)：两处方法当前只有定义，无内部调用。

### CET-013 转化目录通过 Object[] 位置契约传递

级别：P3 低风险 | 路径：耦合风险 | 证据：维护建议
本地复核：待复核

数据层和网络层依赖 0..7 的字段顺序与强制类型转换，缺少编译期保护。

**影响**

当前字段顺序一致，未发现现存字段错位。后续添加门槛、标签或解锁字段时容易引入 ClassCastException 或同步语义漂移。

**根因**

transformationDisplayTuples 构造 List<Object[]>，Payload 层根据 tuple.length 和下标读取 Identifier、int、boolean。领域模型变化不能由编译器完整追踪。

**复现 / 核查步骤**

1. 检查数据层 tuple 构造与 Payload 的八个下标。
2. 在独立测试分支模拟插入字段，观察编译器是否能识别所有消费者。

**建议**

引入不依赖网络类型的 TransformationDescriptor record，并由领域层生成不可变描述；网络与查看器适配器仅做明确字段映射。

**回归验收**

- 类型化后用非默认字段值做端到端映射测试。
- 空目录仍必须作为服务端权威值，不回退本地默认。

**源码证据**

- [src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java:401-419](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/data/ChiseledEnchantingTableData.java#L401-L419)：数据层输出弱类型位置数组。
- [src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingMenuPayloads.java:276-294](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/menu/ChiseledEnchantingMenuPayloads.java#L276-L294)：消费者按位置强制转换。

### CET-014 Loom 仍使用可漂移的 SNAPSHOT 版本

级别：P3 低风险 | 路径：源码 API | 证据：维护建议
本地复核：待复核

Minecraft 与查看器依赖已固定，但构建插件 1.17-SNAPSHOT 仍会随时间解析到不同构建。

**影响**

同一提交未来重建可能解析不同工具链，难以回溯“相应版本”的编译差异。不是当前 API 不兼容的证明。

**根因**

build.gradle 注释提及 1.17.20 参考版本，实际声明却为 1.17-SNAPSHOT。JEI / REI 已使用固定版本且排除了工具链传递覆盖，这些现有保护应保留。

**复现 / 核查步骤**

1. 在两个空 Gradle 缓存环境解析插件，记录实际解析的 Loom 构建。
2. 比较构建时间变化后的依赖解析与产物。

**建议**

固定经 26.3 CI 验证的精确 Loom 发布版本或时间戳构建，记录 Gradle/JDK 版本，并加入依赖验证元数据。不要未经验证直接套用注释中的版本。

**回归验收**

- 用 Java 25 完成有查看器与无查看器两条构建。
- 在干净缓存中复建并保留解析依赖清单。

**源码证据**

- [build.gradle:1-7](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/build.gradle#L1-L7)：构建插件仍为浮动快照。
- [gradle.properties:19-40](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/gradle.properties#L19-L40)：其他可选查看器版本已经固定，不应误报为浮动。

### CET-015 仪式平衡参数没有进入统一规则域

级别：P3 低风险 | 路径：数值与机制 | 证据：设计取舍
本地复核：待复核

5 分钟上限、10 附魔门槛、50% / 70% 退化与 20% 抄错上限都在 Java 中固定。

**影响**

整合包无法只用数据包调整仪式节奏。书架数增加反而触发等待并提高强度，需要清晰告知玩家，而不是自动视为实现 BUG。

**根因**

InscriptionRitualMechanics 既持有 256 步等安全边界，也直接持有大量平衡参数和原版附魔 ID 权重。应区分不能被玩家配置放大的资源上限、原版时间常量，以及应由服主调整的玩法参数。32 附近的等待从 0 突然跳到非零，与平滑升级曲线不是同一种设计。

**复现 / 核查步骤**

1. 比较默认 31 / 32 个广义书架且无母本时的同等级铭刻等待。
2. 在高级母本和超载 Infinity 母本情况下检查等待、跳过费用与抄错提示。

**建议**

将玩法参数提取为 RitualRules，纳入校验、规则来源和 S2C 同步；保留硬性的队列、字符和时间资源预算。考虑等待门槛的渐进开启或提供明确的风险预览。

**回归验收**

- 参数变化后服务端行为、GUI 提示和秘典须使用同一快照。
- 保留 XP 势能守恒及批量顺序等价的既有测试，不用“平衡调整”绕开它们。

**源码证据**

- [src/main/java/chiseled_enchanting_table/mechanics/ritual/InscriptionRitualMechanics.java:59-86](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/mechanics/ritual/InscriptionRitualMechanics.java#L59-L86)：玩法常量与安全常量混在业务类内。
- [src/main/java/chiseled_enchanting_table/mechanics/ritual/InscriptionRitualMechanics.java:246-265](https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source/blob/d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5/src/main/java/chiseled_enchanting_table/mechanics/ritual/InscriptionRitualMechanics.java#L246-L265)：等待强度使用固定归一化分母 42、22 与固定系数。

## 本轮验证记录

- python3 scripts/ci_static_checks.py：通过。9 个 Mixin 引用、11 种语言 / 621 个键、470 个文案引用与文档链接均通过。
- python3 scripts/test_sync_26_3.py：15 项通过。源码断言测试，不等同于 GUI 或实际网络行为测试。
- python3 scripts/compat_check.py：Tier 1 / 2 通过。获取目标 MC JAR 后重跑，原版 ID 与标签存在性 Tier 2 也通过，0 条 WARN。
- bash scripts/check_release_consistency.sh --strict：12 项通过。确认 mod 1.1.0 / Minecraft 26.3 / Loader 0.19.5 / Fabric API 0.162.0+26.3。
- bash docs/ci/install.sh --check：4 份一致。docs/ci 与 .github/workflows 的四个工作流一致。
- ./gradlew --no-daemon build：52 项通过。Java 25.0.5 / Gradle 9.5.1，JEI / REI 均启用。52 个测试，0 失败、0 错误、0 跳过。实际解析 Loom 1.17.21。 日志：public/audit/gradle-build.log
- ./gradlew clean build -Penable_jei=false -Penable_rei=false：构建通过。独立 clean 后重建，无 JEI / REI 依赖编译成功，现有 52 项 JUnit 再次全部通过。 日志：public/audit/gradle-no-viewers.log
- python3 scripts/server_smoke.py：运行通过。隔离平坦世界：启动、reload、命名/染色/冻结掉落、条件战利品、持久仪式完成、坏注册项隔离、破坏返还库存及正常停服。无真实玩家连接，不覆盖 GUI / 多人。预期隔离 WARN 不作为失败。 日志：public/audit/server-smoke.log
- python3 audit/verify_findings.py：8 项通过。核对分支源码与物品别名、重复材料、费用行数等反例模型；这些是源码断言和模型，不是 Minecraft 玩家操作测试。 日志：public/audit/source-assertions.log

## 数值与机制判断

- 38 书架升级曲线与 XP 势能守恒的现有 Java 测试已重跑通过，但不能据此声称覆盖了所有数据包经济环路。重复材料与备选费用分支仍需要新增行为回归。
- 0 / 38 / 42 书架恢复间隔分别为 24,000 / 12,000 / 3,600 秒。42 书架下一次 4 点复制成本约需 4 小时恢复；16 点预算约 16 小时。
- 持久库存是当前实现，关闭菜单不会自动返还台子内物品；重载验收必须按此行为检查，不应沿用旧报告的返回物品断言。
- 65,536 集合上限、256 队列步数、32,000 字符、扫描体积上限属于资源安全边界，不应全部暴露为无约束平衡配置。

## 建议顺序

1. 先修复 CET-001，保护物品守恒。
2. 修复 SDL 输入、材料账本和缺失物品校验，补充数据包集成回归。
3. 为请求加实例绑定、为费用表加双端总预算，然后进行真实双端延迟测试。
4. 再决定恢复进度与仪式节奏，最后清理旧代码和类型契约。
