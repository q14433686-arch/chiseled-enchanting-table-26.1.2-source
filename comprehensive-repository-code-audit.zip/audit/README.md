# Audit Artifacts

Target: `q14433686-arch/chiseled-enchanting-table-26.1.2-source`, branch `26.3`.

Snapshot: `d2abe2101d016a31d05cbbc28e7eba93a0d0d8b5`.

## Report

- `REPORT.md`: complete Chinese report, generated from `src/data/audit.ts` and `src/lib/report.ts`.
- `verification.json`: machine-readable execution summary.
- `gradle-build.log`: standard build with both optional viewers enabled.
- `gradle-no-viewers.log`: clean build without JEI or REI.
- `server-smoke-output.log`: real isolated dedicated-server probe, including final PASS.
- `source-assertions.log`: source assertions and behavioral counterexample models.

## Verification

The mod was built using a checksum-verified Temurin JDK 25.0.5, Gradle 9.5.1,
and resolved Loom 1.17.21. All 52 existing JUnit tests passed in each of the two
build variants. The repository's real server smoke script passed, including
reload, component-bearing drops, conditional loot, ritual completion,
quarantine, stored-input drops, and clean shutdown.

Builds ran in a disposable, detached worktree named `cet-source`, because
Gradle rejects a project name beginning with a dot. No project settings or
production Java sources were modified. Smoke fixtures were temporary. The
original `.audit-source` snapshot remains unchanged.

The smoke world was flat, structures were disabled, the server bound only to
localhost, and no real player connected. It does not exercise GUI inputs,
Shift-click transactions, actual multiplayer networking, all late-loaded
mixins, or every economic path. The quarantine WARN is expected test output,
not an unreported server failure.

## Extra Assertions

Run `python3 audit/verify_findings.py` with `.audit-source` available. These
eight tests verify source structure and small counterexample models. They do
not replace production Java execution or real player interaction tests.

## Report Application

Run `npm run dev`, `npx tsc --noEmit`, `npm run build`, and
`npx playwright test`. The report supports risk/path/type/search filters,
pagination, immutable source links, local review notes, Markdown/JSON export,
deep links, and the default recovery/ritual simulators. Browser review state
does not imply any remote issue has been fixed.