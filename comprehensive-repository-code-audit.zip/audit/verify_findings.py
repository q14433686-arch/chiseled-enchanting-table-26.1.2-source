"""Offline source assertions and behavioral models, not Minecraft runtime tests."""
from pathlib import Path
import math
import unittest

ROOT = Path(__file__).resolve().parent.parent / '.audit-source'
JAVA = ROOT / 'src/main/java/chiseled_enchanting_table'


class AuditEvidenceTests(unittest.TestCase):
    def test_ritual_quick_move_source_has_partial_guard(self):
        source = (JAVA / 'menu/ChiseledEnchantingTableScreenHandler.java').read_text()
        quick = source[source.index('public void clicked('):]
        self.assertIn('slotIndex == ENCHANTABLE_SLOT && isRitualActive()', quick)
        source_write = quick.index('this.getSlot(slotIndex).set(this.getSlot(ENCHANTABLE_SLOT).getItem())')
        target_write = quick.index('this.getSlot(ENCHANTABLE_SLOT).set(tempStack)')
        self.assertLess(source_write, target_write)
        self.assertNotIn('mayPlace(', quick[:target_write])

    def test_quick_move_aliasing_model(self):
        old_target = {'item': 'sword', 'count': 1}
        player_source = {'item': 'pickaxe', 'count': 1}
        table_slot = old_target
        attempted_new_target = player_source.copy()
        player_source = table_slot
        ritual_active = True
        if not ritual_active:
            table_slot = attempted_new_target
        self.assertIs(player_source, table_slot)
        self.assertEqual(player_source['item'], 'sword')

    def test_legacy_keyboard_constants_remain(self):
        source = (ROOT / 'src/client/java/chiseled_enchanting_table/gui/EnchantementListWidget.java').read_text()
        self.assertIn('keyCode == 257 || keyCode == 335', source)
        self.assertNotIn(40, (257, 335))
        self.assertNotIn(88, (257, 335))

    def test_repeated_material_counterexample(self):
        available = 8
        extras = [8, 8]
        current_units = min(available // needed for needed in extras)
        correct_units = available // sum(extras)
        self.assertEqual(current_units, 1)
        self.assertEqual(correct_units, 0)

    def test_alternatives_return_before_common_additional_costs(self):
        source = (JAVA / 'data/ChiseledEnchantingTableData.java').read_text()
        start = source.index('public static List<List<ItemStack>> transformationCostOptions(')
        end = source.index('public static ItemStack transformationPrimaryCost', start)
        method = source[start:end]
        self.assertLess(method.index('return transformation.alternativeBundles()'),
                        method.index('bundle.addAll(transformation.additionalCostStacks'))

    def test_discount_endpoint_is_replaced(self):
        source = (JAVA / 'data/ChiseledEnchantingTableData.java').read_text()
        self.assertIn('Math.max(lr.minDiscountBookshelves() + 1, maxDirect)', source)
        self.assertNotIn('lr.maxDiscountBookshelves()', source)

    def test_outbound_cost_rows_can_exceed_decoder_budget(self):
        rows = 43 * (6 * 255 - 2)
        self.assertEqual(rows, 65704)
        self.assertGreater(rows, 65536)

    def test_regeneration_baselines_and_ritual_discontinuity(self):
        source = (JAVA / 'mechanics/resonance/MasterTomeWear.java').read_text()
        for literal in ('24_000', '12_000', '3_600'):
            self.assertIn(literal, source)
        self.assertEqual(3600 * 4, 14400)
        self.assertEqual(3600 * 16, 57600)
        seconds_at_32 = 300 * (1 - math.exp(-0.62 * (0.42 * 32 / 42)))
        self.assertGreater(seconds_at_32, 50)


if __name__ == '__main__':
    unittest.main(verbosity=2)