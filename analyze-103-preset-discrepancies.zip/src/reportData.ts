export const repository =
  "https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source";

export const currentRevision = "360551d";
export const legacyRevision = "26.1.2_1.0.3";

type Revision = "old" | "current";

export type Evidence = {
  label: string;
  url: string;
  revision: "1.0.3" | "当前" | "API";
};

export type Category = "mechanic" | "economy" | "copy" | "content";
export type Priority = "P0" | "P1" | "P2";

export type Finding = {
  id: string;
  number: string;
  category: Category;
  priority: Priority;
  title: string;
  summary: string;
  baseline: string;
  current: string;
  recommendations: string[];
  acceptance: string;
  caveat?: string;
  evidence: Evidence[];
};

const java = "src/main/java/chiseled_enchanting_table/";
const client = "src/client/java/chiseled_enchanting_table/";
const lang = "src/client/resources/assets/chiseled_enchanting_table/lang/zh_cn.json";
const data = "src/main/resources/data/chiseled_enchanting_table/chiseled_enchanting_table/";
const recipe = "src/main/resources/data/chiseled_enchanting_table/recipe/";

export function sourceUrl(revision: Revision, path: string, lines?: string) {
  const ref = revision === "old" ? legacyRevision : currentRevision;
  return `${repository}/blob/${ref}/${path}${lines ? `#${lines}` : ""}`;
}

const evidence = (label: string, revision: Revision, path: string, lines: string): Evidence => ({
  label,
  url: sourceUrl(revision, path, lines),
  revision: revision === "old" ? "1.0.3" : "当前",
});

export const findings: Finding[] = [
  {
    id: "ritual-slip",
    number: "01",
    category: "mechanic",
    priority: "P0",
    title: "0 秒铭刻，仍可能抄错或串行",
    summary: "经典预设只将等待时间置零，没有关闭新版本的母本过载判定与结算阶段的抄写失误。",
    baseline: "1.0.3 的附魔应用直接写入目标物品。旧版没有排队铭刻、过载负载或随机串行的结算路径。",
    current: "当前 classic103Mode 令 waitTicks = 0，但随后仍通过 enqueueInscription 和 completeActiveRitual 完成。KEEP 母本虽不磨损，使用带免磨损标签的母本时仍返回 usedInfinityTome；完成阶段按负载计算非零 slip 概率，并可能降阶或写入其他词条。",
    recommendations: [
      "将经典模式的失败结果在服务端结算入口明确钉死为 NONE，覆盖即时完成与切换模式后遗留的排队任务；保留队列合法性与物品一致性校验。",
      "把经典模式下的抄错负载、串行补偿与对应提示一并视为不适用，而不是只设置 0 秒等待。",
    ],
    acceptance: "构造高负载免磨损母本，经典模式反复铭刻不发生降阶、杂项或诅咒串行；标准模式同一条件仍遵循配置概率。另测切换模式时的未完成队列。",
    caveat: "这是可达代码路径与条件性风险，不声称已经在实际游戏中复现。",
    evidence: [
      evidence("旧版直接施加附魔", "old", `${java}mechanics/enchanting/EnchantmentApplication.java`, "L29-L76"),
      evidence("经典仅跳过等待，仍走结算", "current", `${java}mechanics/enchanting/EnchantmentApplication.java`, "L163-L233"),
      evidence("KEEP 仍回传免磨损状态", "current", `${java}mechanics/resonance/MasterTomeWear.java`, "L687-L700"),
      evidence("结算仍抽取失误结果", "current", `${java}block/ChiseledEnchantingTableBlockEntity.java`, "L414-L450"),
    ],
  },
  {
    id: "epiphany-gate",
    number: "02",
    category: "mechanic",
    priority: "P0",
    title: "零概率顿悟，不等于关闭刷新与锁定",
    summary: "预设把基础与上限概率调成 0；达到书架门槛后，服务端仍允许付费刷新或锁定一个不会出现的结果。",
    baseline: "1.0.3 的 OptionType 只有普通附魔、物品置换、双书合并与单书进修，没有顿悟、刷新或锁定操作。",
    current: "预设仅把 epiphanyBaseChance / epiphanyMaxChance 设为 0。无外部覆盖时抽取概率为 0，但槽位、周期索引和可支付检查仍运行；rerollEpiphany / freezeEpiphany 可扣经验及材料，普通附魔和物品置换还会推进顿悟种子。若外部数据包覆盖零概率，服务端甚至可能重新生成有效顿悟。界面隐藏按钮不构成服务端禁用。",
    recommendations: [
      "建立 isEpiphanyEnabled(effectiveConfig) 单一能力判断：经典模式恒为 false；若玩家把最高概率主动设为 0，也明确解释此状态。将其用于槽位生成、支付前检查、服务端发包处理和 UI 可见性。",
      "经典模式下不要推进种子或消费锁定费用；旧的方块实体冻结数据可保留以保障存档兼容，但应明确规定切回标准模式后的恢复行为。",
    ],
    acceptance: "在至少 32 个普通书架下伪造合法容器 ID 的刷新/锁定包：经典模式 XP、材料、种子与冻结时间均不变；再用数据包把概率设为 100% 验证经典仍不可触发，标准模式照常工作。",
    evidence: [
      evidence("旧版选项类型", "old", `${java}menu/ChiseledEnchantingMenuPayloads.java`, "L26-L40"),
      evidence("预设只把概率归零", "current", `${java}config/ModRuntimeConfig.java`, "L194-L226"),
      evidence("付费判定没有经典门禁", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2454-L2529"),
      evidence("普通附魔推进种子", "current", `${java}mechanics/enchanting/EnchantmentApplication.java`, "L133-L136"),
      evidence("物品置换也推进种子", "current", `${java}mechanics/transformation/ItemTransformationApplication.java`, "L74-L84"),
      evidence("周期索引继续计算", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L412-L440"),
      evidence("数据包可覆盖预设标量", "current", `${java}config/rules/RuleBook.java`, "L165-L174"),
    ],
  },
  {
    id: "incremental-copy",
    number: "03",
    category: "copy",
    priority: "P0",
    title: "“仅补差价”与实际扣费相反",
    summary: "经典模式明确跳过材料差额与经验差额，升级行和页签提示却继续承诺自动抵扣。",
    baseline: "1.0.3 的处理器取目标等级的完整材料与 XP 成本，扣除对应经验点；没有逐级补差结算。",
    current: "经典模式的材料分支直接返回完整 costOptions，XP 分支直接走 forFullArcaneRitual(rawCost, 0)。但列表升级注释只要检测到已有等级，就使用“仅补差价”；页签说明和价格来源浮窗也可能显示“已自动抵扣”。",
    recommendations: [
      "让价格说明读取与扣费使用同一份已解析的 Quote/PriceMode，至少包含完整计价、逐级补差、母本量产、直接转移与置换几种互斥来源。不要仅凭“已有附魔”推断价格来源。",
      "经典模式文案改成“从 %s 升阶，按目标等级完整计价”；同步替换附魔页签、列表注释、悬浮说明及 11 种语言的等价文本。",
    ],
    acceptance: "在附魔 II 升 III、单书进修、双书合并三个路径分别比较行内材料、经验提示与服务端实扣；经典模式任何位置都不再出现“补差价”。",
    evidence: [
      evidence("旧版完整成本与经验扣除", "old", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L412-L439"),
      evidence("当前经典模式不扣材料差额", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L1635-L1645"),
      evidence("当前经典模式不扣 XP 差额", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2104-L2109"),
      evidence("列表注释没有经典判断", "current", `${client}gui/EnchantementListWidget.java`, "L1327-L1335"),
      evidence("文案与价格浮窗", "current", lang, "L101-L107"),
    ],
  },
  {
    id: "pricing-source",
    number: "04",
    category: "copy",
    priority: "P0",
    title: "消耗规则和计价来源各说各话",
    summary: "同一个经典模式操作，XP 浮窗按完整等级显示，行浮窗却可称母本 1-3 级量产或置换 1-3 级。",
    baseline: "1.0.3 直接通过目标等级的成本扣经验点；两种物品置换标价分别是 3 级与 1 级，不存在母本 1-3 级量产计价。",
    current: "resolveEffectiveXpRequirement 在 classic103Mode 下统一返回 full 模式。XP 徽章读取该结果，而行浮窗只看 storedMasterLevel 或 is_transformation 来选择“原版 1-3 级模式”；完整模式浮窗还提示玩家“放入同等级附魔书，之后只扣 1-3 级”。显示依据并非同一个结算结果。",
    recommendations: [
      "在服务端报价对象中明确 requiredLevel、deductedLevels、vanillaTierMode、priceSource 和 discountApplied；客户端将 XP 徽章与来源浮窗统一绑定这份结果。",
      "经典模式下母本只负责解锁等级，不承诺 1-3 级；置换浮窗应显示实际 3 / 1 级，隐藏误导性的量产提示。",
    ],
    acceptance: "依次用已存书附魔、无存书附魔与两项置换悬停：徽章、来源、材料和实际扣点含义一致；切回标准模式恢复量产说明。",
    evidence: [
      evidence("旧版置换 3 / 1 级", "old", `${data}item_transformations.json`, "L1-L24"),
      evidence("经典模式 XP 统一完整结算", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2104-L2118"),
      evidence("来源文字按类型猜测", "current", `${client}gui/ChiseledEnchantingTableScreen.java`, "L1665-L1748"),
      evidence("XP 徽章读取真实模式", "current", `${client}gui/ChiseledEnchantingTableScreen.java`, "L1467-L1529"),
      evidence("来源文字定义", "current", lang, "L314-L323"),
    ],
  },
  {
    id: "resonance-text",
    number: "05",
    category: "copy",
    priority: "P1",
    title: "共鸣减免没生效，细项提示仍出现",
    summary: "实际折扣上限是 0，但材料悬停可出现“同种藏书额外 -X%”的独立计算结果。",
    baseline: "1.0.3 有普通书架对附魔等级的 +floor(W/3) 提升，没有书库 XP 共鸣减免体系。",
    current: "经典预设把 maxTotalXpDiscountPercent 设为 0，最终折扣会被封顶到 0，且经典 XP 结算强制传入 0。顶部书架徽章与右侧面板在经典模式已经隐藏。遗漏的是材料悬停：只检查原始 specificEnchantDiscountBonus > 0，就显示“额外 -X%（共 -0%）”。",
    recommendations: [
      "不要把“隐藏顶部面板”误当成折扣开关；保留等级解锁信息，但所有经验减免文字必须以实际报价 discountApplied > 0 为条件。",
      "配置面板用一句明确状态说明“经典模式：经验减免未启用”；普通模式仍能看到真实生效的分项。",
    ],
    acceptance: "经典模式在满级藏书旁悬停材料、行与 XP 徽章，不出现正数减免承诺；普通模式只显示最终生效的比例。",
    evidence: [
      evidence("旧版只有书架提级逻辑", "old", `${java}block/ChiseledEnchantingTableBlock.java`, "L153-L203"),
      evidence("预设上限为 0", "current", `${java}config/ModRuntimeConfig.java`, "L209-L221"),
      evidence("细项先单独计算", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L1960-L1986"),
      evidence("总减免最后才封顶", "current", `${java}mechanics/resonance/LibraryResonance.java`, "L1038-L1085"),
      evidence("材料提示未检查经典模式", "current", `${client}gui/ChiseledEnchantingTableScreen.java`, "L1437-L1456"),
      evidence("顶部徽章已有经典门禁", "current", `${client}gui/ChiseledEnchantingTableScreen.java`, "L328-L332"),
    ],
  },
  {
    id: "cost-table",
    number: "06",
    category: "economy",
    priority: "P1",
    title: "完整收费仍引用 1.1.0 价格表",
    summary: "“不打折”只决定如何扣费，不会把原始 XP 与材料价格恢复成 1.0.3。",
    baseline: "1.0.3 的 enchantment_costs.json：I 级基数 5、常规满级 25、稀有单级 35，经验修补 I 的覆盖值为 35；材料还使用不同附魔的多选方案。",
    current: "同一文件在现行分支改成 2 / 10 / 10，经验修补 I 为 12，且大量材料曲线已改写。经典预设调整配置字段，但 applyRuntimeConfig 仍把当前 costTables 原样放入 RuntimeFrame；XP 的 classic 分支随后对这份新 rawCost 做“完整扣除”。",
    recommendations: [
      "将 1.0.3 原始 enchantment_costs.json 作为可校验的经典基线资源随包提供。构建 RuntimeFrame 时按有效预设选择表，不要在多个 UI 与处理器里散写价格常量。",
      "明确外部数据包优先级：严格还原是否覆盖外部包须让服主选择并显示冲突；切换配置后沿现有 S2C 成本同步链刷新客户端和配方查看器。",
    ],
    acceptance: "比对经验修补 I、保护 I / IV 与一种第三方附魔的报价：经典模式与 1.0.3 标签一致；标准模式仍保持现价，外部数据包覆盖按声明生效。",
    evidence: [
      evidence("1.0.3 XP 基数与覆盖", "old", `${data}enchantment_costs.json`, "L1-L37"),
      evidence("现行 XP 与材料表", "current", `${data}enchantment_costs.json`, "L1-L27"),
      evidence("运行帧保留现行成本表", "current", `${java}data/ChiseledEnchantingTableData.java`, "L1026-L1031"),
      evidence("经典模式使用新表的 rawCost", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2104-L2109"),
    ],
  },
  {
    id: "book-upgrades",
    number: "07",
    category: "economy",
    priority: "P1",
    title: "升书倍率调回去了，材料规则没有",
    summary: "预设恢复了双书与单书 XP 倍率，但单书进修仍可读到新版本催化剂和材料曲线。",
    baseline: "1.0.3 的 book_upgrades.json：双书 XP 倍率 1.0、单书 XP 倍率 0.5、单书材料倍率 0.5，且为锋利等魔咒指定了主题材料。",
    current: "预设只设置 combine = 1.0 和 research = 0.5。运行时 BookUpgradeRules 的 materialMultiplier、默认材料与各魔咒覆盖仍来自现行 rawBookUpgradeRules；现行 JSON 的单书材料倍率是 1.0，备选项包括新物品秘法凝晶。",
    recommendations: [
      "经典配置需要切换完整的升书数据规则，而不是只覆盖两个 XP 字段。将旧版研究材料、对应等级量和覆盖表成组载入。",
      "以服务端成本选项为唯一展示来源刷新材料格、JEI/REI 与提示文本；不要在经典模式告诉玩家可用新触媒。",
    ],
    acceptance: "用单词条锋利 II 到 III 单书进修与双书合并对照旧材料和倍率；另测多词条双书合并，保留当前按所有实际提升词条收费的反套利修复，并在偏差说明中列明。",
    caveat: "旧版多词条合并仅按点击词条收费，现行逐条计费属于应保留的经济修复，不能为追求字面一致而恢复漏洞。",
    evidence: [
      evidence("旧版升书规则", "old", `${data}book_upgrades.json`, "L1-L16"),
      evidence("新规则含触媒与 1.0 材料倍率", "current", `${data}book_upgrades.json`, "L1-L37"),
      evidence("预设只覆盖 XP 倍率", "current", `${java}config/ModRuntimeConfig.java`, "L209-L218"),
      evidence("运行帧继续引用新材料定义", "current", `${java}data/ChiseledEnchantingTableData.java`, "L855-L864"),
      evidence("当前多词条合并收费修复", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L2004-L2033"),
    ],
  },
  {
    id: "apple-emerald",
    number: "08",
    category: "economy",
    priority: "P1",
    title: "两项旧置换也并非逐项同价",
    summary: "附魔金苹果在旧数据中另需 2-5 绿宝石，当前经典分支固定为 2。",
    baseline: "1.0.3 金苹果置换是 3 级 + 8 金块 + 2-5 绿宝石的可变附加成本；经验之瓶是 1 级 + 6 青金石 + 2 紫水晶碎片。",
    current: "现行分支确实只保留这两种置换，属于已还原部分；但经典 ItemTransformation 和处理器里都把金苹果的绿宝石成本写死为 2，丢失旧版范围选价。",
    recommendations: [
      "恢复旧版带范围的 ItemCostOption，通过既有玩家盐值成本解析生成 2-5 的具体报价，不要硬编码 2；另一项置换保持已匹配的固定成本。",
      "让当前玩家的服务端报价同步至 UI 与查看器，保持预览、服务端验价和扣料同一结果。",
    ],
    acceptance: "使用多个玩家 UUID 验证金苹果置换可按旧版规则选价，任一玩家的预览与实扣一致；附魔之瓶仍为旧值。",
    evidence: [
      evidence("旧版 2-5 绿宝石", "old", `${data}item_transformations.json`, "L2-L24"),
      evidence("当前经典映射固定 2", "current", `${java}data/ChiseledEnchantingTableData.java`, "L917-L958"),
      evidence("处理器再次硬编码 2", "current", `${java}menu/ChiseledEnchantingTableScreenHandler.java`, "L1416-L1427"),
    ],
  },
  {
    id: "unlock-filter",
    number: "09",
    category: "mechanic",
    priority: "P1",
    title: "默认宝藏补回了七种，过滤口径却未回退",
    summary: "原版七种显式宝藏已被经典分支补回；第三方标签同时落入“宝藏”的附魔仍可能被新排除规则过滤。",
    baseline: "1.0.3 默认表显式列出 7 种宝藏附魔，再展开 #minecraft:in_enchanting_table；展开逻辑没有宝藏或 epiphany_exclusive 排除条件。",
    current: "当前 JSON 用 exclude_tags 排除宝藏、诅咒与顿悟专属。经典分支随后手工加回旧版 7 个 ID，但它先调用已经执行排除逻辑的 defaultEnchantments；因此额外落在这些标签中的第三方附魔不能像旧版一样通过 in_enchanting_table 被默认解锁。",
    recommendations: [
      "在默认魔咒解析入口按有效模式选择过滤策略，而不是事后只补七个 ID；保留现行的等级上限校验等安全修复。",
      "用测试数据包构造同时位于 in_enchanting_table 与 treasure / epiphany_exclusive 的模组附魔，分别验证经典与标准结果。",
    ],
    acceptance: "原版七种与旧版一致；双标签的自定义附魔在经典模式按旧版标签展开，在标准模式仍遵循新排除规则。",
    evidence: [
      evidence("旧版七种与标签展开", "old", `${data}default_enchantments.json`, "L3-L14"),
      evidence("旧版展开不排除", "old", `${java}data/ChiseledEnchantingTableData.java`, "L88-L96"),
      evidence("当前 exclude_tags", "current", `${data}default_enchantments.json`, "L3-L17"),
      evidence("先过滤后补七种", "current", `${java}block/ChiseledEnchantingTableBlock.java`, "L365-L393"),
    ],
  },
  {
    id: "world-loot",
    number: "10",
    category: "economy",
    priority: "P1",
    title: "新生成雕纹书架的附魔书率变为四倍",
    summary: "旧版每格 3%，现行默认 12%；经典预设没有覆盖这一项。",
    baseline: "1.0.3 的 bookshelf_book_pool.json 设置 enchanted_book_probability = 0.03，书本数量范围 3-5。",
    current: "现行资源与 Draft 默认设置为 0.12。经典预设仍把 bookshelfPoolEnabled 设为 true，但未修改 bookshelfEnchantedProb，所以新结构里仍沿用现行 12% 的附魔书概率。",
    recommendations: [
      "在经典预设中显式恢复 0.03，并把这项列入配置冲突/数据包优先级提示；配置滑杆当前以 0.02 递增，还应允许精确选回 0.03。若需进一步还原，再单独比对池权重与箱子注入表。",
      "界面注明只影响未来新生成的结构，绝不对已生成区块或已开箱子的结果作逆向承诺。",
    ],
    acceptance: "比较新生成结构的配置值及抽样分布；已生成雕纹书架不被追溯改写，切回标准恢复 0.12。",
    evidence: [
      evidence("1.0.3 概率 0.03", "old", `${data}bookshelf_book_pool.json`, "L4-L15"),
      evidence("当前概率 0.12", "current", `${data}bookshelf_book_pool.json`, "L3-L15"),
      evidence("预设未重设概率", "current", `${java}config/ModRuntimeConfig.java`, "L220-L230"),
      evidence("当前默认值 0.12", "current", `${java}config/ModRuntimeConfig.java`, "L1049-L1053"),
      evidence("世界生成滑杆步长 0.02", "current", `${java}config/ConfigCatalog.java`, "L859-L864"),
    ],
  },
  {
    id: "recipe-scope",
    number: "11",
    category: "content",
    priority: "P1",
    title: "玩法预设不会热切换合成表",
    summary: "1.0.3 的两块钻石块 + 三块黑曜石，现行变成两颗钻石 + 三块哭泣的黑曜石；额外配方仍加载。",
    baseline: "旧版纂刻附魔台配方中的 D 是 diamond_block，O 是 obsidian；该标签下没有秘法凝晶、退魔砂或秘典合成配方。",
    current: "现行同名 JSON 把 D/O 改为 diamond / crying_obsidian，还新增升级合成与新物品配方。classic103Mode 是运行时配置，不会改变已经由服务器资源管理器加载的 recipe JSON。保留注册兼容存档是合理的，但“原汁原味”需要交代静态内容边界。",
    recommendations: [
      "提供明确的“严格经典资源包”选项：包含旧配方与新配方的取舍、数据包覆盖优先级和 /reload 后的状态同步；不要暗示点一次游戏内预设就能即时替换静态配方。",
      "若不提供资源层切换，将预设改名为“1.0.3 玩法规则”并在悬停说明中列出仍沿用 1.1.0 的配方与新物品。",
    ],
    acceptance: "分别检查预设保存前后、资源包切换并 /reload 后的配方书与 JEI/REI；界面陈述的生效时机与实际一致。",
    evidence: [
      evidence("旧版附魔台配方", "old", `${recipe}chiseled_enchanting_table.json`, "L1-L17"),
      evidence("现行附魔台配方", "current", `${recipe}chiseled_enchanting_table.json`, "L1-L17"),
      evidence("现行额外秘法凝晶配方", "current", `${recipe}arcane_catalyst.json`, "L1-L19"),
      evidence("当前配置仅覆盖运行帧", "current", `${java}data/ChiseledEnchantingTableData.java`, "L760-L769"),
    ],
  },
  {
    id: "viewer-manual",
    number: "12",
    category: "copy",
    priority: "P1",
    title: "秘典、JEI、REI 仍在讲新版玩法",
    summary: "附魔台内部隐藏了新标签，但能打开的手册和配方查看器继续展示顿悟、减免、磨损与量产成本。",
    baseline: "1.0.3 没有九章节《纂刻秘典》或新版本的 1-3 级母本经济叙事；JEI/REI 当时只展示旧附魔与旧成本。",
    current: "当前秘典固定九章，其中第 4、5、6 章描述共鸣、母本耐久与顿悟，未按 classic103Mode 切换内容。JEI 和 REI 附魔类别都无条件按 forMasterTomeEnchant 渲染 1-3 级；JEI 物品说明仍承诺补差价、退魔与磨损。",
    recommendations: [
      "按有效规则生成“经典 / 当前”两套简述，或在不适用章节显式标注仅标准模式适用；不要仅隐藏游戏主屏而遗漏手册、物品说明和配方查看器。",
      "JEI/REI 的经验显示应按当前服务端同步成本及所选模式计算；服务端修改预设或 /reload 后刷新两种查看器缓存。",
    ],
    acceptance: "经典模式逐项悬停秘典、附魔书、台方块与 JEI/REI：无虚假的顿悟/磨损/减免/1-3 级承诺；标准模式保留完整教程，检查 11 种语言键一致。",
    evidence: [
      evidence("旧版中文文案范围", "old", lang, "L1-L16"),
      evidence("手册固定九章节", "current", `${client}gui/grimoire/ArcaneGrimoireScreen.java`, "L52-L75"),
      evidence("JEI 始终算母本模式", "current", `${client}compat/jei/EnchantingRecipeCategory.java`, "L82-L96"),
      evidence("REI 始终算母本模式", "current", `${client}compat/rei/ReiEnchantingCategory.java`, "L79-L105"),
      evidence("现行站点说明文字", "current", lang, "L11-L15"),
    ],
  },
  {
    id: "config-links",
    number: "13",
    category: "mechanic",
    priority: "P1",
    title: "配置项之间少了“功能已关闭”的联动",
    summary: "经典模式下顿悟子项、共鸣减免等仍可编辑；退魔开关甚至可显示打开但实际被经典模式强制关闭。",
    baseline: "1.0.3 不存在顿悟、共鸣折扣或退魔页设置，不会形成这些配置值与有效行为的冲突。",
    current: "ConfigCatalog 的顿悟门槛、概率、锁定/刷新费用与两个减免上限均以 ALWAYS 为适用条件；退魔总开关也为 ALWAYS。实际数据层使用 !classic103Mode && disenchantEnabled()，经典下仍强制禁用退魔。独立的 classic_1_0_3_mode 布尔值允许把经典模式与其他预设字段混搭。",
    recommendations: [
      "为每个选项定义生效条件与无效原因，而非仅禁用输入：在经典模式灰显顿悟/共鸣/退魔的无效子项，并同时展示“偏好值”与“实际生效值”。",
      "把“一键预设”和“手动混合规则”区分开：修改与经典定义不符的字段时，状态改为“基于经典的自定义规则”，不要继续宣称逐项还原。",
    ],
    acceptance: "经典模式下修改顿悟概率、退魔开关或共鸣上限，面板能解释它们为什么不生效；退出经典模式后恢复可编辑，不隐瞒持久化的自定义值。",
    evidence: [
      evidence("旧版仅有四种操作类型", "old", `${java}menu/ChiseledEnchantingMenuPayloads.java`, "L29-L40"),
      evidence("配置选项可用性判定", "current", `${java}config/ConfigCatalog.java`, "L284-L328"),
      evidence("经典布尔值仍可独立切换", "current", `${java}config/ConfigCatalog.java`, "L490-L504"),
      evidence("减免项不依赖经典模式", "current", `${java}config/ConfigCatalog.java`, "L670-L680"),
      evidence("顿悟所有子项 ALWAYS", "current", `${java}config/ConfigCatalog.java`, "L705-L759"),
      evidence("退魔实际上被强制禁用", "current", `${java}data/ChiseledEnchantingTableData.java`, "L897-L915"),
    ],
  },
  {
    id: "policy-truth",
    number: "14",
    category: "content",
    priority: "P2",
    title: "“已应用预设”不等于“实际规则已对齐”",
    summary: "预设保留数据包治理开关，存在锁定或外部覆盖时，草稿匹配与服务端最终规则可以不是同一份。",
    baseline: "1.0.3 以数据包 JSON 和服务器权威计价为基础，不存在“预设匹配”这个对外承诺；移植时的世界生成死锁和成本同步修复无需回退。",
    current: "applyTo 会保留 overrideDatapacks；Preset.matches 只比较本地草稿。RuleBook 解析时外部数据包和 lockedKeys 能覆盖草稿，网络同步包则分别发送偏好值、策略和有效值。附魔书 64 堆叠由启动期 DefaultItemComponentEvents 决定，保存游戏内配置不会即刻改变物品默认组件。",
    recommendations: [
      "以服务端有效 RuntimeFrame 生成逐项差异报告，分清“草稿已保存 / 已同步 / 被数据包覆盖 / 仅重启后生效”四种状态；只有关键项目都对齐时才使用“原味”标签。",
      "将 64 堆叠、已有存档兼容注册与重要移植修复单列为保留改进。尤其 1.0.3 标签源码仍有“待恢复 64 堆叠”的 TODO，避免把设计意图说成该标签构建已实现的事实。",
    ],
    acceptance: "服务端锁定配置与外部数据包覆盖各做一轮；玩家看到的状态、服务器报价、客户端同步值一致。测试重启前后堆叠上限及不同客户端的协议校验。",
    evidence: [
      evidence("旧版 64 堆叠尚为 TODO", "old", `${java}ChiseledEnchantingTable.java`, "L20-L28"),
      evidence("预设保留治理开关", "current", `${java}config/ModRuntimeConfig.java`, "L174-L188"),
      evidence("草稿匹配只比当前草稿", "current", `${java}config/ModRuntimeConfig.java`, "L322-L334"),
      evidence("数据包可优先于偏好值", "current", `${java}config/rules/RuleBook.java`, "L153-L185"),
      evidence("64 堆叠在初始化时注册", "current", `${java}ChiseledEnchantingTable.java`, "L38-L50"),
    ],
  },
];

export const categoryLabels: Record<Category, string> = {
  mechanic: "机制与门禁",
  economy: "数据与经济",
  copy: "界面与文案",
  content: "内容与边界",
};

export const auditApi = [
  {
    title: "网络与服务端校验",
    code: "PayloadTypeRegistry.serverboundPlay()",
    text: "26.1.2 API 提供服务端收包注册与 canSend 能力判断。隐藏按钮不等于撤销收包；刷新、锁定和附魔申请必须在服务端执行门禁。现有协议已带 revision_16，新增线协议字段时要考虑版本升级。",
    source: sourceUrl("current", `${java}menu/EnchantingNetworking.java`, "L82-L114"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/networking/v1/ServerPlayNetworking.html",
  },
  {
    title: "资源重载与配方",
    code: "PackType.SERVER_DATA / ResourceConditions",
    text: "成本 JSON 由服务器资源重载监听器读取；合成配方属于数据资源。26.1.2 的资源条件支持配方条件加载，但不能仅凭运行时布尔值声称已经热切换静态配方，严格经典资源包应声明 /reload 边界。",
    source: sourceUrl("current", `${java}data/ChiseledEnchantingTableData.java`, "L152-L155"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/resource/conditions/v1/ResourceConditions.html",
  },
  {
    title: "附魔书堆叠上限",
    code: "DefaultItemComponentEvents.MODIFY",
    text: "当前使用 26.1.2 Fabric 物品默认组件事件，在初始化阶段设置 MAX_STACK_SIZE。这个启动期行为与运行时预设不同步，不能作为“保存后立刻还原”的规则宣传。",
    source: sourceUrl("current", `${java}ChiseledEnchantingTable.java`, "L38-L50"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/item/v1/DefaultItemComponentEvents.html",
  },
  {
    title: "配置生效与客户端同步",
    code: "RuntimeFrame + S2C cost snapshot",
    text: "本分支已有原子运行帧、服主权限与价格同步。建议在这条已有链上选择经典数据集，再把实际报价和规则来源发给客户端，而不是让 GUI 自己猜结算模式。",
    source: sourceUrl("current", `${java}config/ModConfigNetworking.java`, "L188-L213"),
    api: "https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/net/fabricmc/fabric/api/networking/v1/PayloadTypeRegistry.html",
  },
];

export const testCases = [
  { scenario: "高负载免磨损母本", expected: "经典无串行 / 标准仍按概率结算", layer: "服务端结算" },
  { scenario: "32+ 普通书架，直接发送刷新包", expected: "经典不扣费、不改种子和冻结状态", layer: "网络门禁" },
  { scenario: "已有附魔 II 升 III", expected: "完整收费，列表与浮窗不声称补差价", layer: "经济 + UI" },
  { scenario: "经验修补 I / 金苹果置换", expected: "按对应旧数据和玩家盐值报价", layer: "数据表" },
  { scenario: "第三方宝藏附魔双标签", expected: "经典按旧标签展开，标准保留排除", layer: "数据包兼容" },
  { scenario: "切换预设、/reload、重启", expected: "实时规则、静态资源、堆叠分别提示生效时机", layer: "生命周期" },
  { scenario: "专用服、局域网与只读客户端", expected: "预览、有效配置与实扣一致，客户端不能越权", layer: "多端同步" },
];