import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  Copy,
  Menu,
  Search,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import {
  auditApi,
  categoryLabels,
  currentRevision,
  findings,
  legacyRevision,
  repository,
  sourceUrl,
  testCases,
  type Category,
  type Evidence,
  type Finding,
} from "./reportData";

type Filter = "all" | Category;

const navigation = [
  { id: "overview", number: "00", label: "审查概览" },
  { id: "scope", number: "01", label: "对照口径" },
  { id: "findings", number: "02", label: "问题清单" },
  { id: "crosswalk", number: "03", label: "联动断点" },
  { id: "api", number: "04", label: "26.1.2 API" },
  { id: "plan", number: "05", label: "实施顺序" },
  { id: "tests", number: "06", label: "验收矩阵" },
  { id: "sources", number: "07", label: "证据边界" },
];

const filters: { id: Filter; label: string }[] = [
  { id: "all", label: "全部问题" },
  { id: "mechanic", label: categoryLabels.mechanic },
  { id: "economy", label: categoryLabels.economy },
  { id: "copy", label: categoryLabels.copy },
  { id: "content", label: categoryLabels.content },
];

const crosswalk = [
  {
    key: "classic103Mode / epiphanyMaxChance = 0",
    effect: "抽取概率为零，付费锁定/刷新与种子推进仍存在",
    surface: "主界面隐藏按钮，服务端收包未停",
    target: "统一能力门禁，先验证再扣费",
    finding: "epiphany-gate",
  },
  {
    key: "classic103Mode / waitTicks = 0",
    effect: "即时结算仍经过过载母本抄错判断",
    surface: "0 秒给人以旧版确定性的印象",
    target: "经典模式结算结果固定为 NONE",
    finding: "ritual-slip",
  },
  {
    key: "maxTotalXpDiscountPercent = 0",
    effect: "实扣无共鸣减免，单项加成仍可独立算出",
    surface: "材料浮窗残留“额外 -X%”",
    target: "只展示实际生效的 discountApplied",
    finding: "resonance-text",
  },
  {
    key: "classic103Mode / full rawCost",
    effect: "完整收取现行价格表，不算逐级差额",
    surface: "“仅补差价”与“1-3 级量产”仍显示",
    target: "服务端报价成为唯一文案来源",
    finding: "incremental-copy",
  },
  {
    key: "Preset.applyTo(Draft)",
    effect: "只覆盖部分标量，成本 JSON/配方/材料规则另管",
    surface: "预设名称宣称“逐项还原”",
    target: "拆分运行时、资源层、启动期三种生效域",
    finding: "cost-table",
  },
];

const roadmap = [
  {
    number: "01",
    title: "先封住服务端入口",
    body: "先处理可花钱却无结果的顿悟刷新，以及经典模式仍可能发生的过载抄错。这两项不能靠隐藏按钮或改一句文案解决。",
    output: "涉及：Handler / Networking / BlockEntity",
  },
  {
    number: "02",
    title: "让报价驱动每一处文字",
    body: "把 XP、材料、价格来源与真实折扣汇为同一份报价。列表、XP 徽章、材料浮窗、JEI、REI 共用它，避免同屏互相矛盾。",
    output: "涉及：XpRequirement / UI / 11 个语言文件",
  },
  {
    number: "03",
    title: "补齐旧数据，而不是只改开关",
    body: "以 1.0.3 标签中的成本、升书材料、默认解锁与世界生成概率为基线，做可测试的经典数据配置。静态配方另设资源层切换边界。",
    output: "涉及：RuntimeFrame / 旧 JSON / 数据包策略",
  },
  {
    number: "04",
    title: "用两种模式反向回归",
    body: "每修一项同时验证经典、标准和数据包覆盖。保留 26.1.2 的世界生成修复、网络校验与存档兼容注册，避免为追求旧貌引入旧故障。",
    output: "涉及：JUnit / 联机实测 / 新区块与重启",
  },
];

function BrandMark() {
  return (
    <svg className="brand-mark" width="35" height="35" viewBox="0 0 35 35" fill="none" aria-hidden="true">
      <path d="M5.5 8.5C10.2 7.2 14.2 8.2 17.5 10.6C20.8 8.2 24.8 7.2 29.5 8.5V25.9C24.8 24.6 20.8 25.6 17.5 28C14.2 25.6 10.2 24.6 5.5 25.9V8.5Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M17.5 10.7V28M9 13C10.8 12.7 12.2 12.8 13.7 13.5M21.3 13.5C22.8 12.8 24.2 12.7 26 13" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
      <path d="M10 17H13.3M21.7 17H25" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  );
}

function SectionHeading({
  number,
  eyebrow,
  title,
  description,
  inverted = false,
}: {
  number: string;
  eyebrow: string;
  title: string;
  description?: string;
  inverted?: boolean;
}) {
  return (
    <div className={`section-heading${inverted ? " section-heading-inverted" : ""}`}>
      <span className="section-index">{number}</span>
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h2>{title}</h2>
        {description ? <p>{description}</p> : null}
      </div>
    </div>
  );
}

function EvidenceLink({ item }: { item: Evidence }) {
  return (
    <a href={item.url} target="_blank" rel="noopener noreferrer" className="evidence-link">
      <span className={`evidence-revision ${item.revision === "1.0.3" ? "is-old" : ""}`}>
        {item.revision}
      </span>
      <span>{item.label}</span>
      <ArrowUpRight size={13} strokeWidth={1.8} aria-hidden="true" />
    </a>
  );
}

function FindingRow({
  finding,
  open,
  toggle,
  copyLink,
  reducedMotion,
}: {
  finding: Finding;
  open: boolean;
  toggle: () => void;
  copyLink: () => void;
  reducedMotion: boolean;
}) {
  const detailId = `${finding.id}-details`;

  return (
    <article className={`finding ${open ? "finding-open" : ""}`} id={finding.id}>
      <button
        type="button"
        className="finding-toggle"
        onClick={toggle}
        aria-expanded={open}
        aria-controls={detailId}
      >
        <span className="finding-side">
          <span className="finding-number">{finding.number}</span>
          <span className={`priority priority-${finding.priority.toLowerCase()}`}>{finding.priority}</span>
        </span>
        <span className="finding-main">
          <span className="finding-category">{categoryLabels[finding.category]}</span>
          <span className="finding-title">{finding.title}</span>
          <span className="finding-summary">{finding.summary}</span>
        </span>
        <span className={`finding-chevron ${open ? "finding-chevron-open" : ""}`}>
          <ChevronDown size={20} strokeWidth={1.6} aria-hidden="true" />
        </span>
      </button>

      <AnimatePresence initial={false}>
        {open ? (
          <motion.div
            id={detailId}
            className="finding-detail-clip"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: reducedMotion ? 0 : 0.3, ease: [0.22, 1, 0.36, 1] }}
          >
            <div className="finding-detail">
              <div className="comparison">
                <div className="comparison-cell">
                  <span className="detail-label"><i /> 1.0.3 标签源码</span>
                  <p>{finding.baseline}</p>
                </div>
                <div className="comparison-cell">
                  <span className="detail-label"><i /> 当前 26.1.2 分支</span>
                  <p>{finding.current}</p>
                </div>
              </div>
              <div className="recommendation">
                <div className="detail-label detail-label-accent">建议如何改</div>
                <ol>
                  {finding.recommendations.map((item) => <li key={item}>{item}</li>)}
                </ol>
              </div>
              <div className="acceptance">
                <div className="detail-label">如何验收</div>
                <p>{finding.acceptance}</p>
              </div>
              {finding.caveat ? <p className="finding-caveat">判断边界：{finding.caveat}</p> : null}
              <div className="evidence-footer">
                <div className="evidence-header">
                  <span className="detail-label">源码证据</span>
                  <button type="button" onClick={copyLink} className="copy-issue">
                    <Copy size={14} aria-hidden="true" /> 复制此问题链接
                  </button>
                </div>
                <div className="evidence-list">
                  {finding.evidence.map((item) => <EvidenceLink key={item.url} item={item} />)}
                </div>
              </div>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </article>
  );
}

export default function App() {
  const [activeSection, setActiveSection] = useState("overview");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set(["ritual-slip"]));
  const [toast, setToast] = useState("");
  const prefersReducedMotion = useReducedMotion();

  const counts = useMemo(() => {
    const result: Record<Filter, number> = {
      all: findings.length,
      mechanic: 0,
      economy: 0,
      copy: 0,
      content: 0,
    };
    for (const item of findings) result[item.category] += 1;
    return result;
  }, []);

  const visibleFindings = useMemo(() => {
    const term = query.trim().toLocaleLowerCase();
    return findings.filter((item) => {
      if (filter !== "all" && item.category !== filter) return false;
      if (!term) return true;
      return [
        item.title,
        item.summary,
        item.baseline,
        item.current,
        item.recommendations.join(" "),
        item.acceptance,
        categoryLabels[item.category],
        item.priority,
      ].join(" ").toLocaleLowerCase().includes(term);
    });
  }, [filter, query]);

  const allVisibleExpanded = visibleFindings.length > 0 && visibleFindings.every((item) => expanded.has(item.id));

  useEffect(() => {
    const sections = navigation
      .map((item) => document.getElementById(item.id))
      .filter((item): item is HTMLElement => item !== null);
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((entry) => entry.isIntersecting);
        if (visible.length > 0) {
          setActiveSection(visible[visible.length - 1].target.id);
        }
      },
      { rootMargin: "-15% 0px -68% 0px", threshold: 0 },
    );
    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const hash = decodeURIComponent(window.location.hash.slice(1));
    if (findings.some((item) => item.id === hash)) {
      setExpanded((previous) => new Set([...previous, hash]));
      const timer = window.setTimeout(() => document.getElementById(hash)?.scrollIntoView(), 180);
      return () => window.clearTimeout(timer);
    }
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2700);
    return () => window.clearTimeout(timer);
  }, [toast]);

  function toggleFinding(id: string) {
    setExpanded((previous) => {
      const next = new Set(previous);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function toggleVisible() {
    setExpanded((previous) => {
      const next = new Set(previous);
      visibleFindings.forEach((item) => {
        if (allVisibleExpanded) next.delete(item.id);
        else next.add(item.id);
      });
      return next;
    });
  }

  function jumpToFinding(id: string) {
    setFilter("all");
    setQuery("");
    setExpanded((previous) => new Set([...previous, id]));
    window.setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: prefersReducedMotion ? "auto" : "smooth" }), 60);
  }

  async function copyText(text: string, message: string) {
    try {
      await navigator.clipboard.writeText(text);
      setToast(message);
    } catch {
      window.prompt("复制以下内容", text);
    }
  }

  const checklistText = [
    "纂刻附魔台 / 1.0.3 预设验收清单",
    ...testCases.map((item, index) => `${index + 1}. [ ] ${item.scenario}：${item.expected}（${item.layer}）`),
    `证据快照：${repository}/tree/${currentRevision}；基线：${repository}/tree/${legacyRevision}`,
  ].join("\n");

  return (
    <div className="app-shell">
      <div className="mobile-header">
        <div className="mobile-brand"><BrandMark /><span>纂刻附魔台 <small>审查报告</small></span></div>
        <button type="button" className="mobile-menu-button" onClick={() => setMobileNavOpen(!mobileNavOpen)} aria-expanded={mobileNavOpen} aria-label={mobileNavOpen ? "关闭目录" : "打开目录"}>
          {mobileNavOpen ? <X size={23} /> : <Menu size={23} />}
        </button>
      </div>

      {mobileNavOpen ? <button type="button" className="sidebar-scrim" onClick={() => setMobileNavOpen(false)} aria-label="关闭目录" /> : null}

      <aside className={`sidebar ${mobileNavOpen ? "sidebar-open" : ""}`}>
        <a href="#overview" className="sidebar-brand" onClick={() => setMobileNavOpen(false)}>
          <BrandMark />
          <span><strong>纂刻附魔台</strong><small>CHISELED ENCHANTING TABLE</small></span>
        </a>
        <div className="sidebar-report-title">
          <span className="sidebar-overline">SOURCE AUDIT / 001</span>
          <p>1.0.3 预设<br />还原性审查</p>
        </div>
        <div className="sidebar-nav-label">报告目录</div>
        <nav aria-label="报告目录" className="sidebar-nav">
          {navigation.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              className={`sidebar-nav-item ${activeSection === item.id ? "sidebar-nav-active" : ""}`}
              onClick={() => {
                setActiveSection(item.id);
                setMobileNavOpen(false);
              }}
            >
              {activeSection === item.id ? <motion.span layoutId="active-nav" className="nav-active-line" transition={{ duration: prefersReducedMotion ? 0 : 0.25 }} /> : null}
              <span className="nav-number">{item.number}</span>
              <span>{item.label}</span>
              {item.id === "findings" ? <span className="nav-count">{findings.length}</span> : null}
            </a>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="sidebar-bottom-label">对照版本</div>
          <div className="sidebar-version"><span>基线标签</span><strong>1.0.3</strong></div>
          <div className="sidebar-version"><span>当前快照</span><strong>1.1.0</strong></div>
          <a href={repository} target="_blank" rel="noopener noreferrer" className="sidebar-repo">打开源仓库 <ArrowUpRight size={15} /></a>
        </div>
      </aside>

      <div className="main-area">
        <header className="topbar">
          <div className="topbar-path"><span className="path-root">RESEARCH NOTE</span><span className="path-divider">/</span><span>MC 26.1.2</span><span className="path-divider">/</span><span>机制一致性</span></div>
          <div className="topbar-links">
            <a href={`${repository}/tree/${legacyRevision}`} target="_blank" rel="noopener noreferrer">1.0.3 标签 <ArrowUpRight size={13} /></a>
            <a href={`${repository}/tree/${currentRevision}`} target="_blank" rel="noopener noreferrer">当前源码 <ArrowUpRight size={13} /></a>
          </div>
        </header>

        <main>
          <section id="overview" className="hero content-width">
            <div className="hero-copy">
              <div className="hero-kicker"><span className="kicker-line" /> 原始源码对照 / 技术审查报告</div>
              <h1>纂刻附魔台</h1>
              <h2>“1.0.3 原味”预设<br /><em>还原性审查</em></h2>
              <p className="hero-description">不是要求撤销所有修复，而是让旧版玩法、现行代码与界面说法重新对齐。以下每个判断都指向 1.0.3 标签和 26.1.2 当前源码。</p>
              <div className="hero-links">
                <a href="#findings" className="hero-primary">阅读审查发现 <ArrowDownRight size={18} strokeWidth={1.7} /></a>
                <a href="#scope" className="hero-secondary">先看判定口径 <ArrowRight size={16} strokeWidth={1.7} /></a>
              </div>
            </div>
            <div className="hero-compare" aria-hidden="true">
              <div className="hero-compare-label">CODEBASE / COMPARISON</div>
              <div className="hero-version hero-version-old">1.0.3<span>TAGGED BASELINE</span></div>
              <div className="hero-track"><span /><i /><span /></div>
              <div className="hero-version hero-version-new">1.1.0<span>CURRENT SNAPSHOT</span></div>
              <div className="hero-compare-foot">Same Minecraft target<br />Different gameplay contract</div>
            </div>
          </section>

          <section className="verdict-band">
            <div className="content-width verdict-inner">
              <div className="verdict-side"><span className="verdict-line" /> 审查结论 <span>AT A GLANCE</span></div>
              <div className="verdict-copy"><strong>“数值归零”不等于“机制关闭”。</strong><p>当前预设修复了部分书架、母本与页面行为，但服务端仍保留新机制入口；旧价格表与资源内容也没有成组切换。应先修行为，再修报价与文案，最后明确静态内容边界。</p></div>
            </div>
          </section>

          <section id="scope" className="report-section content-width scope-section">
            <SectionHeading number="01" eyebrow="AUDIT BASIS / 判定口径" title="先确定比较的是哪两个版本" description="使用同一 Minecraft 26.1.2 移植线，避免把 26.3 的 API 或原作者早期版本混作 1.0.3 基线。" />
            <div className="scope-grid">
              <div className="scope-column">
                <span className="scope-column-top">BASELINE / 旧版</span>
                <h3>26.1.2_1.0.3</h3>
                <p>仓库正式标签，提交 <code>09f854e</code>。对照旧版的处理器、附魔应用、物品置换、成本 JSON 与书架生成数据，不以如今的 Wiki 叙述代替旧源码。</p>
                <a href={`${repository}/tree/${legacyRevision}`} target="_blank" rel="noopener noreferrer" className="text-link">打开旧版标签 <ArrowUpRight size={15} /></a>
              </div>
              <div className="scope-column">
                <span className="scope-column-top">WORKING TREE / 当前</span>
                <h3>{currentRevision} <small>/ 1.1.0</small></h3>
                <p>用户给定的 <code>arena/649fac5c...</code> 分支快照。依据实际配置解析、服务端支付、客户端显示及数据包加载路径，而不是只看预设按钮的名称。</p>
                <a href={`${repository}/tree/${currentRevision}`} target="_blank" rel="noopener noreferrer" className="text-link">打开当前快照 <ArrowUpRight size={15} /></a>
              </div>
            </div>
            <div className="scope-boundary"><span>保留什么</span><p>世界生成死锁修复、服务端成本同步、存档兼容注册与安全校验可以继续保留。64 堆叠属于当前移植保留改进：旧标签源码仍把恢复 64 堆叠列作 TODO，不应误写成那个构建已具备的事实。</p><a href={sourceUrl("old", "src/main/java/chiseled_enchanting_table/ChiseledEnchantingTable.java", "L20-L28")} target="_blank" rel="noopener noreferrer">查看旧版 TODO <ArrowUpRight size={13} /></a></div>
          </section>

          <section id="findings" className="report-section content-width findings-section">
            <SectionHeading number="02" eyebrow="FINDINGS / 逐项发现" title="问题不在一个开关里" description="按执行链追到配置、实际结算、屏幕与外部查看器。P0 优先处理会改变结果或造成错误付费的路径。" />
            <div className="finding-tools">
              <div className="filter-tabs" role="group" aria-label="按类别筛选问题">
                {filters.map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    className={`filter-tab ${filter === item.id ? "filter-active" : ""}`}
                    onClick={() => setFilter(item.id)}
                    aria-pressed={filter === item.id}
                  >
                    {item.label} <span>{counts[item.id]}</span>
                  </button>
                ))}
              </div>
              <div className="finding-utilities">
                <label className="search-field">
                  <Search size={16} strokeWidth={1.7} aria-hidden="true" />
                  <span className="sr-only">搜索问题内容</span>
                  <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索关键词或源码问题" />
                  {query ? <button type="button" onClick={() => setQuery("")} aria-label="清除搜索"><X size={14} /></button> : null}
                </label>
                <button type="button" className="expand-all" onClick={toggleVisible} disabled={visibleFindings.length === 0}>{allVisibleExpanded ? "收起当前" : "展开当前"}</button>
              </div>
            </div>
            <div className="findings-result" aria-live="polite">显示 {visibleFindings.length} 项 / 共 {findings.length} 项</div>
            <div className="finding-list">
              {visibleFindings.length ? visibleFindings.map((item) => (
                <FindingRow
                  key={item.id}
                  finding={item}
                  open={expanded.has(item.id)}
                  toggle={() => toggleFinding(item.id)}
                  copyLink={() => copyText(`${window.location.origin}${window.location.pathname}#${item.id}`, "问题链接已复制")}
                  reducedMotion={Boolean(prefersReducedMotion)}
                />
              )) : <div className="empty-results"><Search size={28} strokeWidth={1.3} /><strong>没有找到对应问题</strong><p>试试其他关键词，或切回“全部问题”。</p><button type="button" onClick={() => { setQuery(""); setFilter("all"); }}>清除筛选 <ArrowRight size={15} /></button></div>}
            </div>
          </section>

          <section id="crosswalk" className="report-section content-width crosswalk-section">
            <SectionHeading number="03" eyebrow="DEPENDENCY MAP / 联动断点" title="从设置到表现，中间断在哪里" description="同一个开关至少要管住四层：配置值、服务端能力、最终报价、面向玩家的说明。" />
            <div className="crosswalk-table" aria-label="配置与界面联动断点">
              <div className="crosswalk-head"><span>设置或条件</span><span>服务端实际</span><span>玩家看到</span><span>应修正</span></div>
              {crosswalk.map((row) => (
                <button type="button" className="crosswalk-row" key={row.key} onClick={() => jumpToFinding(row.finding)} title="查看相关问题">
                  <span><code>{row.key}</code></span><span>{row.effect}</span><span>{row.surface}</span><span className="crosswalk-target">{row.target} <ArrowUpRight size={13} /></span>
                </button>
              ))}
            </div>
            <p className="under-table-note">选择任一行，可跳转到对应问题的旧版、现行代码及具体改法。</p>
          </section>

          <section id="api" className="api-section">
            <div className="content-width">
              <SectionHeading number="04" eyebrow="IMPLEMENTATION CONTEXT / API 校核" title="建议必须落在 26.1.2 的 API 上" description="以下同时对照此分支的实际调用与 Fabric API 0.151.0+26.1.2 文档，避免套用其他 Minecraft 版本的接口名称。" inverted />
              <div className="api-list">
                {auditApi.map((item, index) => (
                  <div className="api-row" key={item.title}>
                    <span className="api-number">0{index + 1}</span>
                    <div className="api-main"><h3>{item.title}</h3><code>{item.code}</code><p>{item.text}</p><div className="api-links"><a href={item.source} target="_blank" rel="noopener noreferrer">分支调用 <ArrowUpRight size={13} /></a><a href={item.api} target="_blank" rel="noopener noreferrer">26.1.2 官方 API <ArrowUpRight size={13} /></a></div></div>
                  </div>
                ))}
              </div>
              <p className="api-footnote">依赖版本以仓库 <a href={sourceUrl("current", "gradle.properties", "L5-L26")} target="_blank" rel="noopener noreferrer">gradle.properties</a> 为准：Minecraft 26.1.2、Fabric Loader 0.19.3、Fabric API 0.151.0+26.1.2。资源条件只在加载或重载资源时生效，不可替代服务端运行时门禁。</p>
            </div>
          </section>

          <section id="plan" className="report-section content-width plan-section">
            <SectionHeading number="05" eyebrow="EXECUTION / 建议顺序" title="先让规则可信，再让文字可信" description="按影响面拆成可以独立提交与验收的四个改动批次；每一步都同时防止标准模式回归。" />
            <div className="roadmap-list">
              {roadmap.map((item) => (
                <div className="roadmap-step" key={item.number}>
                  <div className="roadmap-marker">{item.number}</div>
                  <div className="roadmap-copy"><h3>{item.title}</h3><p>{item.body}</p><span>{item.output}</span></div>
                </div>
              ))}
            </div>
          </section>

          <section id="tests" className="report-section content-width tests-section">
            <SectionHeading number="06" eyebrow="ACCEPTANCE / 验收矩阵" title="不要只测“按钮看不见了”" description="这里列的是建议新增的回归测试，不是声称已经在游戏内通过的结果。" />
            <div className="test-table">
              <div className="test-head"><span>测试场景</span><span>预期结果</span><span>覆盖层</span></div>
              {testCases.map((test) => <div className="test-row" key={test.scenario}><span>{test.scenario}</span><span>{test.expected}</span><span>{test.layer}</span></div>)}
            </div>
            <button type="button" className="copy-checklist" onClick={() => copyText(checklistText, "验收清单已复制")}><Copy size={16} strokeWidth={1.7} /> 复制验收清单 <ArrowUpRight size={15} /></button>
          </section>

          <footer id="sources" className="footer-section">
            <div className="content-width footer-inner">
              <div className="footer-main">
                <span className="eyebrow">SOURCE NOTE / 证据边界</span>
                <h2>让“原味”<br />成为可验证的承诺。</h2>
                <p>本页是针对公开源码的静态审查与修改建议，并非已合入模组的补丁，也未声称完成 Minecraft 客户端或专用服实测。条件性行为已在具体问题中注明；实际发布前须运行模组测试、构建及联机回归。</p>
              </div>
              <div className="footer-sources">
                <span className="footer-sources-label">核对所用的一手材料</span>
                <a href={`${repository}/tree/${legacyRevision}`} target="_blank" rel="noopener noreferrer"><span>1.0.3 标签源码</span><ArrowUpRight size={15} /></a>
                <a href={`${repository}/tree/${currentRevision}`} target="_blank" rel="noopener noreferrer"><span>当前 26.1.2 快照</span><ArrowUpRight size={15} /></a>
                <a href={`${repository}/compare/${legacyRevision}...${currentRevision}`} target="_blank" rel="noopener noreferrer"><span>两个版本的完整差异</span><ArrowUpRight size={15} /></a>
                <a href="https://maven.fabricmc.net/docs/fabric-api-0.151.0+26.1.2/" target="_blank" rel="noopener noreferrer"><span>Fabric API 0.151.0 Javadoc</span><ArrowUpRight size={15} /></a>
              </div>
            </div>
            <div className="content-width footer-bottom"><span>纂刻附魔台 / 源码审查报告</span><span>BASELINE {legacyRevision} &nbsp; / &nbsp; SNAPSHOT {currentRevision}</span><a href="#overview">返回顶部 <ArrowUpRight size={13} /></a></div>
          </footer>
        </main>
      </div>
      <AnimatePresence>
        {toast ? <motion.div className="toast" role="status" aria-live="polite" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 8 }} transition={{ duration: prefersReducedMotion ? 0 : 0.2 }}><Check size={16} />{toast}</motion.div> : null}
      </AnimatePresence>
    </div>
  );
}