// ─────────────────────────────────────────────────────────────
// 措辞校准、人话字典与直接可替换文本数据
// 对齐仓库: q14433686-arch/chiseled-enchanting-table-26.1.2-source
// ─────────────────────────────────────────────────────────────

export interface TermComparison {
  jargon: string;
  category: "pseudo-academic" | "confusing" | "hallucination";
  human: string;
  mcStyle: string;
  reason: string;
  exampleBad: string;
  exampleGood: string;
}

export const TERMINOLOGY_DICTIONARY: TermComparison[] = [
  {
    jargon: "铭刻 / 纂刻词条",
    category: "pseudo-academic",
    human: "附魔",
    mcStyle: "给装备附魔 / 附魔属性",
    reason: "虽然模组名为纂刻附魔台，但日常操作玩家最习惯的仍是『附魔』。过度堆砌『铭刻/纂刻』会让基础操作读起来像文言文。",
    exampleBad: "在此处铭刻毕业词条，不可逆地刻入装备基底。",
    exampleGood: "在此处为装备附魔，直接获得满级附魔属性。",
  },
  {
    jargon: "白板 / 白板基底",
    category: "confusing",
    human: "未附魔装备 / 干净的书",
    mcStyle: "未附魔物品",
    reason: "『白板』是卡牌与数值网游黑话，原版 Minecraft 玩家通常使用『未附魔的剑/镐』或『普通书』。",
    exampleBad: "轨道一【白板直附】：仅靠木书架在白板上最高直刻至 ceil(MAX/2)。",
    exampleGood: "普通书架直接附魔：给未附魔的装备附魔，最多附到最高等级的一半（如锋利 III）。",
  },
  {
    jargon: "磨浅刻痕 / 等级势能差",
    category: "pseudo-academic",
    human: "附魔降级",
    mcStyle: "降低附魔等级",
    reason: "『势能差』是物理学术语，在游戏手册里出现极其突兀。玩家需要知道的是：降一级能拿回多少经验点。",
    exampleBad: "按等级势能差 V(L_cur) - V(L_target) 精确返还经验球。",
    exampleGood: "降低附魔等级：按等级差返还经验点，分步降级和一步全洗拿回的经验完全相同。",
  },
  {
    jargon: "精细微创手术 / 精准摘除",
    category: "pseudo-academic",
    human: "单洗 / 抹除单条",
    mcStyle: "抹除指定附魔",
    reason: "附魔台不是手术台，用『微创手术』形容洗词条破坏了奇幻与沙盒氛围。直接说『抹除选中附魔，保留其他附魔』最清晰。",
    exampleBad: "洗练台 4 大手术模式对比：定向单洗（精准摘除单条属性）。",
    exampleGood: "退魔洗练功能对比：抹除单条附魔（保留装备上的其余附魔）。",
  },
  {
    jargon: "守恒经验 / 涤魔碎砂",
    category: "hallucination",
    human: "返还经验点（不产碎砂）",
    mcStyle: "返还经验",
    reason: "『涤魔碎砂』在代码中压根不存在！这是文案凭空编造的幽灵道具，会导致玩家全洗后困惑为什么没拿到碎砂。",
    exampleBad: "清空普通词条并返还经验与涤魔碎砂。",
    exampleGood: "清空普通附魔并返还经验球（装备保留，附魔书变为褪魔残卷）。",
  },
  {
    jargon: "差价抵扣 / 差价守恒",
    category: "confusing",
    human: "补差价升级",
    mcStyle: "升级已付抵扣",
    reason: "『差价守恒』生造词汇。人话是：已经升过的等级不用再交一遍材料，逐级升级和一步到位总花费一样，绝不吃亏。",
    exampleBad: "差价守恒：I → V 逐级升阶总耗材 ≈ 一步直冲，绝不吃亏！",
    exampleGood: "补差价升级：升级时自动扣除先前已付的材料和经验，逐级升和直接升总花费相同！",
  },
  {
    jargon: "三轨书架 / 轨道 1/2/3",
    category: "confusing",
    human: "书架三功能",
    mcStyle: "普通书架与雕纹书架",
    reason: "『轨道』听起来像地铁或经济政策。其实就是三种清晰的玩法：初级直附、已有升级、母本永久解锁。",
    exampleBad: "三轨分工：轨道 1 白板直附，轨道 2 词条升阶，轨道 3 雕纹母本。",
    exampleGood: "书架分工：普通书架解锁初级附魔与升级上限，雕纹书架存书永久解锁满级附魔！",
  },
  {
    jargon: "冰封定格 / 立即重随",
    category: "confusing",
    human: "锁定顿悟 / 刷新词条",
    mcStyle: "锁定 / 刷新",
    reason: "界面右侧按钮写的是锁定与刷新图标，手册写『冰封定格/立即重随』造成名词不一致。",
    exampleBad: "刷出心仪顿悟点右侧「冰封定格」，亦可「立即重随」。",
    exampleGood: "刷出心仪宝藏点右侧「锁定」（可延长到期时间），或花费经验与材料「刷新」。",
  },
  {
    jargon: "原版门槛量产制 / 秘法全额点数制",
    category: "pseudo-academic",
    human: "原版量产模式（绿球）/ 完整等级模式（紫瓶）",
    mcStyle: "原版模式 / 完整模式",
    reason: "玩家在界面上看到的是『绿经验球』和『紫药水瓶』。用视觉特征+核心机制（扣1-3级 vs 扣整级）解释最好懂。",
    exampleBad: "绿珠 Lv.X 原版门槛量产制与紫瓶 -XL 秘法全额点数制并存。",
    exampleGood: "原版量产模式（绿球）：只看等级门槛，每次只扣 1~3 级；完整等级模式（紫瓶）：按设定消耗完整等级。",
  },
];

export interface CodeDriftFact {
  id: string;
  title: string;
  location: string;
  wrongTextZh: string;
  wrongTextEn: string;
  actualCodeRule: string;
  hazard: string;
  correctedZh: string;
  correctedEn: string;
}

export const CODE_DRIFT_FACTS: CodeDriftFact[] = [
  {
    id: "DRIFT-01",
    title: "全部退魔虚构『产出碎砂』",
    location: "DisenchantmentApplication.java:348–373 applyFullDisenchant（经验由 :500–512 spawnOrAwardRefund 发放）· grimoire.ch8.s1 / diag.ch8_c1_b",
    wrongTextZh: "【全部退魔】：0 耗材一键清空全部非诅咒词条，返还守恒经验并产碎砂。",
    wrongTextEn: "Disenchant All (Free): wipes non-curses, refunds XP & yields Cleansing Grit.",
    actualCodeRule: "applyFullDisenchant() 仅发放真实经验球 ExperienceOrb，如果目标是附魔书则产出 1 本褪魔残卷 DEPLETED_TOME。绝对不产出任何退魔砂（cleansing_grit）！",
    hazard: "严重虚假宣传。玩家为了刷退魔砂去疯狂全洗附魔装备，发现背包空空如也，以为是模组恶性 Bug。",
    correctedZh: "【全部退魔】：0 耗材清空全部非诅咒附魔并返还经验球；若是附魔书则还原为褪魔残卷。",
    correctedEn: "Disenchant All (Free): wipes all non-curse enchantments for XP refund; enchanted books turn into Depleted Tomes.",
  },
  {
    id: "DRIFT-02",
    title: "降级附魔虚构『消耗紫水晶/碎砂』",
    location: "DisenchantmentApplication.java:374–407 applyDowngrade（全程无 deductMatchedBundle）· grimoire.diag.ch8_c2_b",
    wrongTextZh: "消耗少量紫水晶/碎砂，每次退 1 级并返还对应经验",
    wrongTextEn: "Costs Amethyst/Grit, lowers 1 level & refunds step XP",
    actualCodeRule: "applyDowngrade() 零材料消耗！代码只做等级校验与经验返还，根本没有任何材料扣除语句。只有单洗（STRIP_SINGLE）才消耗材料！",
    hazard: "颠倒黑白。降级明明是 100% 免费的，手册却谎称要材料，直接吓退想要微调附魔等级的生存玩家。",
    correctedZh: "零材料消耗！每次退 1 级并返还对应经验点，附魔书降至 0 级自动变为残卷",
    correctedEn: "Free of materials! Steps down 1 level & refunds XP; books reaching level 0 become Depleted Tomes",
  },
  {
    id: "DRIFT-03",
    title: "破除诅咒配方与数据包完全错乱",
    location: "disenchanting.json:71–107 curse_purge · grimoire.ch8.s4",
    wrongTextZh: "【破除诅咒】：支持纯原版金苹果+青金石、回响碎片或秘法凝晶祛咒。",
    wrongTextEn: "Curse Purge: Golden Apple + Lapis, Echo Shard + Lapis, or 1x Arcane Crystal.",
    actualCodeRule: "disenchanting.json 中破咒配方是：① 3 退魔砂 + 1 恶魂之泪；② 2 退魔砂 + 1 金苹果；③ 1 秘法凝晶；④ 纯原版：2 恶魂之泪 + 2 金苹果。完全没有青金石，也没有回响碎片！",
    hazard: "错误配方指引。玩家带着青金石和回响碎片去附魔台，发现配方根本不亮，导致无法破除诅咒。",
    correctedZh: "【破除诅咒】：需退魔砂 + 恶魂之泪/金苹果，或 1 颗秘法凝晶；纯原版也可用 2 恶魂之泪 + 2 金苹果。",
    correctedEn: "Curse Purge: requires Cleansing Grit + Ghast Tear/Golden Apple, 1x Arcane Catalyst, or vanilla 2x Ghast Tear + 2x Golden Apple.",
  },
  {
    id: "DRIFT-04",
    title: "双书合并误导『背包带书』",
    location: "BookUpgradeApplication.java:38 costBook = handler.get_cost_item() · grimoire.ch5.s1",
    wrongTextZh: "双书融合（0 耗材）：背包带同阶书，仅 0.6× 经验并返 1 本残卷。",
    wrongTextEn: "Combine (0 Items): matching book in bag, 0.6x XP, yields 1 Depleted Tome.",
    actualCodeRule: "applyCombine() 显式读取：ItemStack costBook = handler.get_cost_item(); 第二本附魔书必须放在下方的『材料格（副槽）』，背包里的书根本不参与合成！",
    hazard: "操作阻塞。玩家把书放背包里，左侧列表根本不亮，新玩家以为合并功能损坏。",
    correctedZh: "双书合并（0 耗材）：材料格放入另一本同阶附魔书，仅需 0.6× 经验，被消耗的书化为残卷。",
    correctedEn: "Combine (0 Items): place matching enchanted book into the material slot; costs 0.6x XP and leaves a Depleted Tome.",
  },
  {
    id: "DRIFT-05",
    title: "残卷覆写虚构『按住 Shift 批量』",
    location: "ItemTransformationApplication.java:42–43 batchCount（无任何 Shift 判断）· grimoire.ch7.s2",
    wrongTextZh: "每次点击转化 1 件；褪魔残卷按住 Shift 点击可整组批量还原为书。",
    wrongTextEn: "Consumes 1 item per click; Shift-click Blank Overwrite restores full stacks.",
    actualCodeRule: "代码根本没有检测键盘 Shift 键！只要上槽放了多本残卷，普通左键点击就会自动计算 batchCount（普通上限 8 本，梯度三上限 64 本），一次点击自动整批还原！",
    hazard: "误导玩家去按 Shift，结果按不按 Shift 行为完全一样；且不知道单次最多放 8 本。",
    correctedZh: "每次点击按当前支付能力整批还原（普通最多 8 本，满级母本达成后可一次还原整组 64 本）。",
    correctedEn: "Each click automatically restores in batch up to your affordable limit (8 books normally; full stack of 64 at Tier III).",
  },
  {
    id: "DRIFT-06",
    title: "宝藏顿悟书架门槛 30 vs 32",
    location: "treasure_epiphany.json:3 · grimoire.diag.ch3_epi_off / diag.ch6_gate",
    wrongTextZh: "未满 30 架木书架：宝藏顿悟休眠中 / 30+ 木书架唤醒大书库",
    wrongTextEn: "Below 30 Wooden Shelves: Epiphanies dormant / 30+ Wooden Shelves awaken 10:00 rolls",
    actualCodeRule: "数据包 treasure_epiphany.json 明确配置 min_regular_bookshelves = 32，Java 代码与界面仪表均读取 32。",
    hazard: "摆了 30 或 31 架书架的玩家看到手册以为已经解锁，但在游戏里顿悟系统仍然休眠，产生严重困惑。",
    correctedZh: "未满 32 架普通书架：宝藏顿悟休眠中 / 32+ 普通书架唤醒大书库（每 10:00 轮换）",
    correctedEn: "Below 32 Regular Bookshelves: Epiphanies dormant / 32+ Regular Bookshelves awaken 10:00 rolls",
  },
  {
    id: "DRIFT-07",
    title: "单件顿悟同时出现上限 3 条 vs 4 条",
    location: "treasure_epiphany.json:8 · grimoire.diag.ch6_slots",
    wrongTextZh: "藏书越多，触发率越高，最多同时 3 条！",
    wrongTextEn: "More stored Tomes boost rate up to 3 slots!",
    actualCodeRule: "treasure_epiphany.json 配置 max_slots_cap = 4，代码 epiphanyMaxSlots() 封顶值为 4，仪表也是 4 颗星。",
    hazard: "手册少算了 1 条上限，玩家不知道堆满藏书可以同时刷出 4 条宝藏附魔。",
    correctedZh: "藏书越多，触发率越高，同一件物品最多可同时刷出 4 条宝藏附魔！",
    correctedEn: "More stored Tomes boost proc rate; a single item can roll up to 4 treasure enchantments at once!",
  },
  {
    id: "DRIFT-08",
    title: "减免计算公式 15+20+15=40 自相矛盾",
    location: "LibraryResonance.java:447–480 baseXpDiscountPercent / effectiveXpDiscountPercent · grimoire.diag.ch4_res",
    wrongTextZh: "书库共鸣叠加减免上限：-40%（木架15%+全局20%+同词条15%）",
    wrongTextEn: "Library Resonance Cap: -40% (15% + 20% + 15%)",
    actualCodeRule: "Java 代码算法是：公共减免 = min(35%, 木架减免[最高15%] + 全局藏书[最高20%])；最终减免 = min(40%, 公共减免 + 同词条母本专属[最高15%])。三项简单相加是 50%，写成 40% 让人怀疑作者算术不过关。",
    hazard: "玩家误以为三项只要随便凑凑就能到 40%，不知道公共部分有 35% 的先期硬上限。",
    correctedZh: "经验减免最高 -40%：木架上限 15% + 全局藏书上限 20%（公共封顶 35%），同词条母本再 +15%（总封顶 40%）。",
    correctedEn: "XP Discount capped at -40%: Wooden max 15% + Global Tomes max 20% (Base cap 35%), plus up to +15% for matching Tome (Total cap 40%).",
  },
  {
    id: "DRIFT-09",
    title: "单洗副材料墨囊 vs 发光墨囊",
    location: "disenchanting.json:30 minecraft:glow_ink_sac · gui.cleanse.panel_rule_strip",
    wrongTextZh: "• 定向单洗：退魔砂（主槽）+ 青金石/墨囊/紫水晶",
    wrongTextEn: "• Strip 1 Trait: Cleansing Grit + secondary reagent",
    actualCodeRule: "disenchanting.json 的副料是 minecraft:glow_ink_sac（发光墨囊），普通墨囊（minecraft:ink_sac）根本不被单洗配方接受！普通墨囊只能用来做空白覆写或合成秘典。",
    hazard: "致命误导。玩家拿着普通墨囊去单洗，由于材料不匹配按钮永远是灰色，白白浪费时间寻找原因。",
    correctedZh: "• 定向单洗：退魔砂（下槽）+ 青金石/发光墨囊/紫水晶（背包），或单颗秘法凝晶",
    correctedEn: "• Strip 1 Trait: Cleansing Grit (lower slot) + Lapis/Glow Ink/Amethyst (in bag), or 1x Arcane Catalyst",
  },
  {
    id: "DRIFT-10",
    title: "单洗纯原版配方材料遗漏",
    location: "disenchanting.json:56 纯原版 amethyst_shard + lapis 选项 · grimoire.ch8.s3",
    wrongTextZh: "【定向单洗】：保留其余词条精准摘除单条（紫水晶+青金石/碎砂/凝晶）。",
    wrongTextEn: "Targeted Strip: removes 1 chosen trait while keeping all other traits intact.",
    actualCodeRule: "disenchanting.json 第 21 行明确支持纯原版材料替代：4~12 紫水晶碎片 + 6~18 青金石。手册写成『紫水晶+青金石/碎砂/凝晶』，把主辅料混为一谈，没说清楚到底是退魔砂还是纯原版。",
    hazard: "没装退魔砂模组物品的纯净服玩家，不知道可以直接用原版的紫水晶+青金石进行单洗。",
    correctedZh: "【定向单洗】：保留其余附魔，单独洗掉选定属性。可用退魔砂+辅料，或纯原版紫水晶+青金石，或 1 颗秘法凝晶。",
    correctedEn: "Targeted Strip: removes only the chosen enchantment. Accepts Cleansing Grit + reagent, vanilla Amethyst + Lapis, or 1x Arcane Catalyst.",
  },
];

export const DIRECT_REPLACE_ZH: Record<string, string> = {
  // ── 核心事实错误修正 ──
  "gui.chiseled_enchanting_table.grimoire.ch8.s1": "【全部退魔】：0 耗材清空全部非诅咒附魔并返还经验球；若是附魔书则还原为褪魔残卷。",
  "gui.chiseled_enchanting_table.grimoire.diag.ch8_c1_b": "保留诅咒，清空普通附魔并返还经验球；附魔书变为褪魔残卷",
  "gui.chiseled_enchanting_table.grimoire.diag.ch8_c2_b": "零材料消耗！每次退 1 级并返还对应经验点，附魔书降至 0 级自动变为残卷",
  "gui.chiseled_enchanting_table.grimoire.ch8.s3": "【定向单洗】：保留其余附魔，单独洗掉选定属性。可用退魔砂+辅料、纯原版紫水晶+青金石，或 1 颗秘法凝晶。",
  "gui.chiseled_enchanting_table.grimoire.ch8.s4": "【破除诅咒】：需退魔砂 + 恶魂之泪/金苹果，或 1 颗秘法凝晶；纯原版也可用 2 恶魂之泪 + 2 金苹果。",
  "gui.chiseled_enchanting_table.grimoire.ch5.s1": "双书合并（0 耗材）：材料格放入另一本同阶附魔书，仅需 0.6× 经验，被消耗的书化为残卷。",
  "gui.chiseled_enchanting_table.grimoire.ch7.s2": "每次点击按当前支付能力整批还原（普通最多 8 本，满级母本达成后可一次还原整组 64 本）。",
  "gui.chiseled_enchanting_table.grimoire.diag.ch3_epi_off": "未满 32 架普通书架：宝藏顿悟休眠中",
  "gui.chiseled_enchanting_table.grimoire.diag.ch6_gate": "32+ 普通书架唤醒大书库（每 10:00 轮换）",
  "gui.chiseled_enchanting_table.grimoire.diag.ch6_slots": "藏书越多，触发率越高，同一件物品最多可同时刷出 4 条宝藏附魔！",
  "gui.chiseled_enchanting_table.grimoire.diag.ch4_res": "经验减免最高 -40%：木架最高 15% + 全局最高 20%（公共封顶 35%），同词条再 +15%（总封顶 40%）",
  "gui.chiseled_enchanting_table.cleanse.panel_rule_strip": "• 定向单洗：退魔砂（下槽）+ 青金石/发光墨囊/紫水晶（背包），或单颗秘法凝晶",

  // ── 说人话与易读性润色 ──
  "gui.chiseled_enchanting_table.grimoire.ch3.t1": "轨道 1【直接附魔】：给未附魔的装备附魔，仅靠普通书架最高附到等级上限的一半（如最高 5 级最多附到 3 级）。",
  "gui.chiseled_enchanting_table.grimoire.ch3.t2": "轨道 2【升级附魔】：装备或书已有该附魔后，周围摆放 0~38 个普通书架即可逐级解锁升到满级！",
  "gui.chiseled_enchanting_table.grimoire.ch3.t3": "轨道 3【雕纹母本】：把附魔书存入雕纹书架，不仅未附魔装备能直接附满级，还直接解锁低消耗量产！",
  "gui.chiseled_enchanting_table.grimoire.ch4.m1": "绿球 Lv.X【原版量产模式】：雕纹母本覆盖的附魔与物品置换，达到等级门槛后每次仅扣 1~3 级，保留经验条进度！",
  "gui.chiseled_enchanting_table.grimoire.ch4.m2": "紫瓶 -XL【完整等级模式】：未存入雕纹书架的基础附魔、升阶、顿悟与破咒，按设定完整消耗等级。",
  "gui.chiseled_enchanting_table.grimoire.ch4.m3": "青色 +XP【退魔返还模式】：全部退魔与逐级降阶不收任何材料，还会像经验之瓶一样返还真实经验球！",
  "gui.chiseled_enchanting_table.grimoire.ch5.s3": "补差价升级：升级时自动扣除先前等级已付的材料和经验，逐级升和一步到位总花费完全一致！",
  "gui.chiseled_enchanting_table.grimoire.diag.ch5_r3a": "补差价无损：I → V 逐级升级总耗费 ≈ 直接升满，任何阶段升级绝不吃亏！",
  "gui.chiseled_enchanting_table.cleanse.panel_rule_free": "• 全部退魔 / 逐级降阶：不消耗任何材料，还会返还经验球",
  "gui.chiseled_enchanting_table.cleanse.panel_rule_curse": "• 破除诅咒：退魔砂 + 恶魂之泪/金苹果，或单颗秘法凝晶",
  "gui.chiseled_enchanting_table.cleanse.panel_title": "附魔洗练台",
  "gui.chiseled_enchanting_table.cleanse.panel_stats": "点击全洗可移除 %s 条普通附魔，返还 +%s 点经验",
  "gui.chiseled_enchanting_table.tab.cleanse": "退魔 · 洗练",
  "gui.chiseled_enchanting_table.tab.cleanse.title": "✦ 退魔与洗练",
  "gui.chiseled_enchanting_table.tab.cleanse.desc": "免费全部退魔或降级并返还经验；或用退魔砂单独抹除某一条不想要的附魔",
  "gui.chiseled_enchanting_table.depleted_tome.sub_t0": "✦ 普通书架达到 %s/%s 个可免经验",
  "gui.chiseled_enchanting_table.depleted_tome.sub_t1": "✦ I 阶免经验 · %s/%s 个书架材料减半",
  "gui.chiseled_enchanting_table.depleted_tome.sub_t2": "✦ II 阶材料减半 · 满级母本 %s/%s 种可免费",
  "gui.chiseled_enchanting_table.depleted_tome.sub_t3": "✦ III 阶达成：完全免费还原为普通书",
  "gui.chiseled_enchanting_table.depleted_tome.tip_title": "✦ 褪魔残卷 · 还原为普通书的门槛",
  "gui.chiseled_enchanting_table.depleted_tome.tip_g1": "• 梯度一（免除 1 级经验消耗）：普通书架达到 %s / %s 个",
  "gui.chiseled_enchanting_table.depleted_tome.tip_g2": "• 梯度二（免经验 + 所需材料减半）：普通书架达到 %s / %s 个",
  "gui.chiseled_enchanting_table.depleted_tome.tip_g3": "• 梯度三（零材料完全免费还原）：普通书架 %s/%s 且雕纹书架拥有不同满级母本 %s/%s 种",
};

export const DIRECT_REPLACE_EN: Record<string, string> = {
  "gui.chiseled_enchanting_table.grimoire.ch8.s1": "Disenchant All (Free): wipes all non-curse enchantments for XP refund; enchanted books turn into Depleted Tomes.",
  "gui.chiseled_enchanting_table.grimoire.diag.ch8_c1_b": "Keeps curses, wipes normal traits & refunds XP; books turn into Depleted Tomes",
  "gui.chiseled_enchanting_table.grimoire.diag.ch8_c2_b": "Zero materials! Steps down 1 level & refunds XP; books reaching level 0 become tomes",
  "gui.chiseled_enchanting_table.grimoire.ch8.s3": "Targeted Strip: removes chosen trait using Cleansing Grit + reagent, vanilla Amethyst + Lapis, or 1x Arcane Catalyst.",
  "gui.chiseled_enchanting_table.grimoire.ch8.s4": "Curse Purge: requires Cleansing Grit + Ghast Tear/Golden Apple, 1x Arcane Catalyst, or vanilla 2x Ghast Tear + 2x Golden Apple.",
  "gui.chiseled_enchanting_table.grimoire.ch5.s1": "Combine (0 Items): place matching enchanted book into lower slot; costs 0.6x XP and leaves a Depleted Tome.",
  "gui.chiseled_enchanting_table.grimoire.ch7.s2": "Each click automatically restores in batch up to your affordable limit (8 books normally; full stack of 64 at Tier III).",
  "gui.chiseled_enchanting_table.grimoire.diag.ch3_epi_off": "Below 32 Regular Bookshelves: Epiphanies dormant",
  "gui.chiseled_enchanting_table.grimoire.diag.ch6_gate": "32+ Regular Bookshelves awaken 10:00 rolls",
  "gui.chiseled_enchanting_table.grimoire.diag.ch6_slots": "More stored Tomes boost rate; a single item can roll up to 4 treasure slots at once!",
  "gui.chiseled_enchanting_table.grimoire.diag.ch4_res": "XP Discount capped at -40%: Wooden max 15% + Global max 20% (Base cap 35%), plus up to +15% for matching Tome (Total cap 40%).",
  "gui.chiseled_enchanting_table.cleanse.panel_rule_strip": "• Strip 1 Trait: Cleansing Grit (lower slot) + Lapis/Glow Ink/Amethyst (in bag), or 1x Arcane Catalyst",
  "gui.chiseled_enchanting_table.cleanse.panel_rule_free": "• Full Disenchant / Step-Down: costs 0 items & refunds experience orbs",
  "gui.chiseled_enchanting_table.cleanse.panel_rule_curse": "• Purge Curse: Cleansing Grit + Ghast Tear / Golden Apple, or 1x Arcane Catalyst",
  "gui.chiseled_enchanting_table.cleanse.panel_title": "Disenchant Altar",
  "gui.chiseled_enchanting_table.cleanse.panel_stats": "Full wipe removes %s normal enchantment(s) for +%s XP",
  "gui.chiseled_enchanting_table.depleted_tome.sub_t0": "✦ %s/%s Shelves to waive XP",
  "gui.chiseled_enchanting_table.depleted_tome.sub_t1": "✦ Tier I: 0 XP · %s/%s Shelves for half materials",
  "gui.chiseled_enchanting_table.depleted_tome.sub_t2": "✦ Tier II: -50%% Mats · %s/%s Stored Max Tomes for free",
  "gui.chiseled_enchanting_table.depleted_tome.sub_t3": "✦ Tier III: Completely free book restore",
  "gui.chiseled_enchanting_table.depleted_tome.tip_title": "✦ Depleted Tome · Book Restoration Gates",
  "gui.chiseled_enchanting_table.depleted_tome.tip_g1": "• Tier I (No XP Cost): reach %s / %s Regular Bookshelves",
  "gui.chiseled_enchanting_table.depleted_tome.tip_g2": "• Tier II (No XP + 50%% Material Discount): reach %s / %s Regular Bookshelves",
  "gui.chiseled_enchanting_table.depleted_tome.tip_g3": "• Tier III (100%% Free): %s/%s Shelves + %s/%s Distinct Max-Tier Stored Tomes",
};

export interface ChapterRewrite {
  chapterNum: number;
  title: string;
  originalBad: string;
  rewrittenGood: string;
  whyBetter: string;
}

export const CHAPTER_REWRITES: ChapterRewrite[] = [
  {
    chapterNum: 1,
    title: "合成与快速上手",
    originalBad: "秘典支持两种无序合成；附魔台既可直合，也可由原版台无损升级。手持染料右键附魔台可混色染布；本秘典也可存入雕纹书架。附魔书支持 64 本堆叠，铁砧合并已移除累积惩罚翻倍。",
    rewrittenGood: "两步做出你的附魔台：直接用 2 钻石 + 雕纹书架 + 3 哭泣黑曜石合成；或者拿 4 个紫水晶碎片把原版附魔台直接升级上来。用任何染料右键附魔台都能混色换桌布。另外，附魔书可以在背包里堆叠到 64 本，用铁砧合并也不会再出现『过于昂贵』的惩罚！",
    whyBetter: "去掉了生硬的『直合/无损升级/累积惩罚翻倍』，直接告诉玩家去背包里怎么合成、怎么染桌布、堆叠和铁砧省心在哪里。",
  },
  {
    chapterNum: 2,
    title: "界面与附魔步骤",
    originalBad: "界面分为 5 个清晰功能区，只需三步即可完成定向附魔或退魔：顶部页签切换「铭刻附魔」与「退魔洗练」，右上可随时开书。中栏上槽放目标装备/书本，下槽放轮播提示的主耗材。点击左侧高亮词条立刻生效；辅料直接从角色背包自动扣除。",
    rewrittenGood: "附魔非常简单，只需三步：① 上槽放入你要附魔的武器、工具、防具或普通书；② 下槽放入青金石、绿宝石或紫水晶（三种任选一种）；③ 在左侧列表直接点击你想要的附魔！如果提示需要额外材料，只要放在背包里就会自动扣除，不用来回倒腾格子。",
    whyBetter: "普通玩家打开界面最关心『我该把剑放哪，把青金石放哪』，三步流程清晰明了，副料自动扣背包的便利性表达得更亲切。",
  },
  {
    chapterNum: 3,
    title: "书架摆放与等级解锁",
    originalBad: "自动扫描水平 ±3 格、垂直 ±2 格（7×5×7），中间方块绝不遮挡。轨道 1【白板直附】：仅靠木书架在白板上最高直刻至 ceil(MAX/2)。轨道 2【词条升阶】：已有 1 级词条后，0–38 架木书架解锁至满级。轨道 3【雕纹母本】：雕纹书架存入附魔书，白板直刻对应阶及宝藏！",
    rewrittenGood: "附魔台会自动检测周围 7×5×7 范围内的书架，中间有空气或方块都不会阻挡！两种书架分工明确：普通书架用来解锁升级上限，摆满 38 个书架就能把已有附魔一路升到满级；雕纹书架则是你的『藏书阁』，放进去一本附魔书就永久解锁这个附魔，新装备拿来就能直接附满级！",
    whyBetter: "彻底废除令人困惑的『轨道 1/2/3』与『白板直附 ceil(MAX/2)』数学公式，用普通玩家秒懂的『已有附魔升满级』和『雕纹书架永久解锁』解释机制。",
  },
  {
    chapterNum: 4,
    title: "经验消耗与书库打折",
    originalBad: "两种经验结算模式并存，且 30 级以上单级经验宽度封顶不膨胀：绿珠 Lv.X【原版门槛】：母本复刻与物品置换仅扣 1–3 级且保留进度条。紫瓶 -XL【秘法全额】：无母本铭刻、书本升阶、顿悟与祛咒按点数结算。青珠 +XP【退魔返还】：免费全退与逐级降阶按守恒曲线返还经验值。",
    rewrittenGood: "看列表右侧的图标就知道怎么扣经验：① 绿色经验球（量产模式）：只要达到等级门槛，每次只扣除 1~3 级，还完整保留你经验条的小数百分比，批量做装备极度省经验！② 紫色药水瓶（完整模式）：未存入母本的新附魔或升级，按原版标准消耗等级。书架摆得越多经验折扣越高，最高可享 -40% 减免！",
    whyBetter: "以玩家眼前的绿色经验球和紫色药水瓶为线索，解释为什么雕纹书架做出来的装备只扣 1~3 级，点出『量产神装极省经验』的核心爽点。",
  },
  {
    chapterNum: 5,
    title: "附魔书合成与升级",
    originalBad: "两条路线均可把附魔书培养至满级母本，且升级自动抵扣前阶成本：双书融合（0 耗材）：背包带同阶书，仅 0.6× 经验并返 1 本残卷。单书研究（省附魔书）：消耗常规耗材或 1 颗秘法凝晶，1.4× 经验。差价抵扣：已有低阶词条升至高阶自动扣除已付材料，有母本仅 1–2 级。",
    rewrittenGood: "手里只有一本低级附魔书？有两种办法升满级：① 双书合并：把未满级的书放上槽，材料槽（下槽）放入另一本同等级的书，只花少量经验就能合出下一级，消耗的书还会变成褪魔残卷还给你！② 单书材料升级：没有第二本书时，直接投入青金石、绿宝石、紫水晶（或 1 颗秘法凝晶）即可突破升阶。做出一本满级书存进雕纹书架，以后全队都能无限量产！",
    whyBetter: "纠正了『背包带书』的代码严重错误（必须放下槽），并把生硬的『双书融合/单书研究/差价抵扣』翻译成了玩家容易理解的『合书』与『单书花材料硬升』。",
  },
  {
    chapterNum: 6,
    title: "宝藏附魔与顿悟",
    originalBad: "经验修补、精准采集等宝藏词条无法靠普通木架白嫖，有两种正道：通道一【藏书母本】：雕纹书架放入宝藏书，立即常驻 1–3 级单耗材复刻。通道二【大书库顿悟】：满 30 架木书架每 10 分钟自动刷新金色顿悟。无母本顿悟需双耗材，或单颗秘法凝晶一键替代。刷出心仪顿悟点右侧「冰封定格」，挖走附魔台也会保留！",
    rewrittenGood: "经验修补、无限、冰霜行者等宝藏附魔不用苦等刷村民箱子！当你摆满 32 个普通书架，附魔台就会唤醒『宝藏顿悟』，每 10 分钟自动刷出稀有宝藏词条。刷到好词条但材料不够？点击右上角的『雪花锁定』，就算把附魔台挖下来搬家，锁定的宝藏倒计时也不会丢！强烈建议：刷出经验修补后，先附魔在一本普通书上放进雕纹书架，此后全家桶随时量产！",
    whyBetter: "纠正了『30 架』的错误数字（实为 32 架），并把『通道一/二/冰封定格/秘法替代』改成接地气的宝藏获取指南和搬家保锁技巧。",
  },
  {
    chapterNum: 7,
    title: "神奇物品置换与残卷洗白",
    originalBad: "在上槽放入指定基底物品，左侧自动浮现金色原版门槛置换配方：支持转化附魔之瓶、回响碎片、图腾、三叉戟与附魔金苹果等。每次点击转化 1 件；褪魔残卷按住 Shift 点击可整组批量还原为书。满 18 架木书架且雕纹书架含 6 种高阶藏书时，残卷覆写完全免费！附魔之瓶至少要求 Lv.3 且实扣 ≥11 点经验，严防无限刷级。",
    rewrittenGood: "附魔台还能炼金！把玻璃瓶、金苹果、钻石剑放进上槽，就能直接换成附魔之瓶、附魔金苹果、三叉戟或不死图腾！合书留下的『褪魔残卷』也不用扔：只要放入上槽，花几张纸就能洗成全新的普通书。普通书架达到 18 个且雕纹书架存有 6 种满级母本后，残卷转化彻底免费，一次点击就能把整组 64 本残卷一键全部变回新书！",
    whyBetter: "删除了不存在的『按住 Shift 点击』误导，生动说明了金苹果变附魔金果、钻石剑变三叉戟的炼金玩法，以及免费一键洗白 64 本残卷的终极大福利。",
  },
  {
    chapterNum: 8,
    title: "退魔、降级与洗去诅咒",
    originalBad: "切至顶部青色「退魔洗练」页签，可对已附魔装备与附魔书精细手术：【全部退魔】：0 耗材一键清空全部非诅咒词条，返还守恒经验并产碎砂。【逐级降阶】：每次降 1 级并返经验，附魔书归零自动变为褪魔残卷。【定向单洗】：保留其余词条精准摘除单条（紫水晶+青金石/碎砂/凝晶）。【破除诅咒】：支持纯原版金苹果+青金石、回响碎片或秘法凝晶祛咒。",
    rewrittenGood: "装备附魔歪了？点击顶部『退魔 · 洗练』页签随时修正：① 全部退魔：完全不消耗材料，一键清除所有普通附魔，并把经验全部化作经验球还给你（附魔书会变为残卷）；② 逐级降级：同样零材料消耗！想把锋利 V 降到 IV，点一下就退一级并返还经验点；③ 抹除单条：只想洗掉某一条废附魔而保住其他毕业词条？放入退魔砂即可精准抹除；④ 破除诅咒：绑定诅咒与消失诅咒也能用恶魂之泪与金苹果彻底净化！",
    whyBetter: "彻底清除了虚假的『产出碎砂』、『降级消耗紫水晶』、『破咒用回响碎片』三大严重事实错误！用最亲切、最放心的口吻告诉玩家：退魔是免费的、降级是免费的、经验是会还给你的！",
  },
];
