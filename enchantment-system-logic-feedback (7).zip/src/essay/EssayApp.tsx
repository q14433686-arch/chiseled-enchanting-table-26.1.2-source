import { Fragment, useEffect, useRef, useState, type ReactNode } from "react";
import { motion, useScroll, useSpring, AnimatePresence } from "framer-motion";
import { BookOpen, ScrollText, PenLine, ExternalLink, ArrowUp, FileCode2, Database, FlaskConical, Calculator, Globe, Box } from "lucide-react";
import { Sprite } from "../wiki/pixel";
import { SECTIONS, FN_ORDER, FN_NUM, COMMIT, REPO, type Footnote, type FnKind, type Section } from "./essayData";

type View = "wiki" | "proposal" | "wording" | "essay";

const KIND: Record<FnKind, { label: string; tone: string; Icon: typeof FileCode2 }> = {
  code: { label: "代码", tone: "#a18cff", Icon: FileCode2 },
  data: { label: "数据", tone: "#e8c37c", Icon: Database },
  test: { label: "测试", tone: "#8df0a4", Icon: FlaskConical },
  calc: { label: "实算", tone: "#7ee8dc", Icon: Calculator },
  web: { label: "外部", tone: "#f08cc8", Icon: Globe },
  vanilla: { label: "原版", tone: "#9c93bd", Icon: Box },
};

const FN_BY_ID = Object.fromEntries(FN_ORDER.map((f) => [f.id, f]));

/* ── 脚注上标 + 弹出卡 ── */
const Fn = ({ id }: { id: string }) => {
  const f = FN_BY_ID[id];
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);
  const [below, setBelow] = useState(true);
  if (!f) return null;
  const n = FN_NUM[id];
  const k = KIND[f.kind];
  return (
    <span
      ref={ref}
      className="relative inline-block align-super"
      onMouseEnter={() => {
        const r = ref.current?.getBoundingClientRect();
        setBelow(!r || r.top < window.innerHeight * 0.55);
        setOpen(true);
      }}
      onMouseLeave={() => setOpen(false)}
    >
      <a
        href={`#fn-${n}`}
        id={`fnref-${id}-${n}`}
        onClick={(e) => {
          if (window.matchMedia("(hover: none)").matches) {
            e.preventDefault();
            setOpen((o) => !o);
          }
        }}
        className="font-code text-[10px] leading-none px-[3px] py-[1px] rounded-sm mx-[1px] transition-colors"
        style={{ color: k.tone, background: `${k.tone}18`, border: `1px solid ${k.tone}40` }}
      >
        {n}
      </a>
      <AnimatePresence>
        {open && (
          <motion.span
            initial={{ opacity: 0, y: below ? -4 : 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="absolute z-50 left-1/2 -translate-x-1/2 w-[340px] max-w-[86vw] text-left normal-case not-italic"
            style={below ? { top: "calc(100% + 8px)" } : { bottom: "calc(100% + 8px)" }}
          >
            <FnCard f={f} n={n} compact />
          </motion.span>
        )}
      </AnimatePresence>
    </span>
  );
};

const FnCard = ({ f, n, compact }: { f: Footnote; n: number; compact?: boolean }) => {
  const k = KIND[f.kind];
  return (
    <span
      className="block rounded-sm border p-3.5 shadow-2xl"
      style={{ background: "#120f22", borderColor: `${k.tone}55`, boxShadow: `0 18px 40px rgba(0,0,0,0.55), 0 0 0 1px ${k.tone}22` }}
    >
      <span className="flex items-center gap-2 mb-1.5">
        <span className="font-code text-[11px] font-bold" style={{ color: k.tone }}>
          [{n}]
        </span>
        <span className="inline-flex items-center gap-1 font-code text-[9.5px] px-1.5 py-0.5 rounded-sm" style={{ color: k.tone, background: `${k.tone}15` }}>
          <k.Icon size={10} />
          {k.label}
        </span>
        {f.url && (
          <a href={f.url} target="_blank" rel="noreferrer" className="ml-auto inline-flex items-center gap-1 text-[10px] text-faint hover:text-parch">
            打开 <ExternalLink size={10} />
          </a>
        )}
      </span>
      <span className="block font-code text-[10.5px] text-parch/85 break-all mb-1.5">{f.ref}</span>
      {f.quote && (
        <span className={`block font-code text-[10.5px] leading-[1.55] rounded-sm px-2 py-1.5 mb-1.5 break-words ${compact ? "max-h-24 overflow-hidden" : ""}`} style={{ background: "#07060d", color: "#cfc6ff", borderLeft: `2px solid ${k.tone}` }}>
          {f.quote}
        </span>
      )}
      <span className="block text-[12px] leading-[1.65] text-mute font-light">{f.note}</span>
    </span>
  );
};

/* ── 富文本：**粗体** 与 [[脚注]] ── */
const Rich = ({ t }: { t: string }) => {
  const parts: ReactNode[] = [];
  const re = /\*\*(.+?)\*\*|\[\[([a-z0-9_]+)\]\]/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let i = 0;
  while ((m = re.exec(t))) {
    if (m.index > last) parts.push(<Fragment key={i++}>{t.slice(last, m.index)}</Fragment>);
    if (m[1]) parts.push(<strong key={i++} className="text-parch font-semibold">{m[1]}</strong>);
    else if (m[2]) parts.push(<Fn key={i++} id={m[2]} />);
    last = m.index + m[0].length;
  }
  if (last < t.length) parts.push(<Fragment key={i++}>{t.slice(last)}</Fragment>);
  return <>{parts}</>;
};

/* ── 边界图 ── */
const BoundaryDiagram = () => {
  const ext = [
    { label: "原版附魔台（装备）", sub: "绕过白板封顶 / 顿悟专属", ang: -150, tone: "#ff6b8a" },
    { label: "村民交易书", sub: "母本来源 · 未改动", ang: -30, tone: "#e8c37c" },
    { label: "宝箱 / 考古书", sub: "原版书保留 + 41 表注入", ang: 30, tone: "#e8c37c" },
    { label: "物品置换", sub: "跳过结构核心奖励", ang: 150, tone: "#f08cc8" },
  ];
  const W = 640;
  const H = 360;
  const cx = W / 2;
  const cy = H / 2;
  return (
    <div className="pixelframe bg-[#0d0b1a] border border-arcane/20 p-4 md:p-6 my-8">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto">
        <defs>
          <radialGradient id="core" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#6d5ef0" stopOpacity="0.45" />
            <stop offset="100%" stopColor="#6d5ef0" stopOpacity="0.05" />
          </radialGradient>
          <marker id="arr" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
            <path d="M0 0 L10 5 L0 10 z" fill="#9c93bd" />
          </marker>
        </defs>
        <ellipse cx={cx} cy={cy} rx={150} ry={92} fill="url(#core)" stroke="#a18cff" strokeWidth="1.5" strokeDasharray="5 4" />
        <text x={cx} y={cy - 40} textAnchor="middle" fill="#a18cff" fontSize="11" fontFamily="JetBrains Mono">MOD 内部边界</text>
        <text x={cx} y={cy - 14} textAnchor="middle" fill="#ede6d4" fontSize="15" fontFamily="Noto Serif SC" fontWeight="700">母本 · 书架 · 守恒证明</text>
        <text x={cx} y={cy + 10} textAnchor="middle" fill="#8df0a4" fontSize="11.5" fontFamily="Noto Sans SC">返还 &lt; 成本（JUnit 1..255 ✓）</text>
        <text x={cx} y={cy + 30} textAnchor="middle" fill="#8df0a4" fontSize="11.5" fontFamily="Noto Sans SC">无母本价 ≥ 母本价 ✓</text>
        <text x={cx} y={cy + 50} textAnchor="middle" fill="#8df0a4" fontSize="11.5" fontFamily="Noto Sans SC">白板封顶 ⌈M/2⌉ ✓</text>
        {ext.map((e) => {
          const a = (e.ang * Math.PI) / 180;
          const ox = cx + Math.cos(a) * 262;
          const oy = cy + Math.sin(a) * 140;
          const ix = cx + Math.cos(a) * 156;
          const iy = cy + Math.sin(a) * 96;
          return (
            <g key={e.label}>
              <line x1={ox} y1={oy} x2={ix} y2={iy} stroke={e.tone} strokeWidth="1.6" markerEnd="url(#arr)" opacity="0.85" />
              <rect x={ox - 78} y={oy - 22} width={156} height={44} rx={3} fill="#171230" stroke={e.tone} strokeOpacity="0.6" />
              <text x={ox} y={oy - 4} textAnchor="middle" fill="#ede6d4" fontSize="12" fontFamily="Noto Sans SC" fontWeight="500">{e.label}</text>
              <text x={ox} y={oy + 12} textAnchor="middle" fill={e.tone} fontSize="10" fontFamily="Noto Sans SC">{e.sub}</text>
            </g>
          );
        })}
      </svg>
      <p className="text-[12px] text-faint text-center mt-2 leading-6">
        图 1 · mod 内部的规则是自洽的；四条外部通道不受这些规则约束，是第五节 D2、D3、D5、D7 的共同根源。
      </p>
    </div>
  );
};

/* ── 经验成本对照条 ── */
const CostBars = () => {
  const rows = [
    { k: "原版 30 级附魔（随机结果）", v: 306, tone: "#9c93bd", sub: "Lv.30 · 扣 3 级" },
    { k: "本台 · 母本量产 · 无减免", v: 306, tone: "#a18cff", sub: "Lv.30 · 扣 3 级 · 结果确定" },
    { k: "本台 · 母本量产 · −40%", v: 126, tone: "#8df0a4", sub: "Lv.18 · 扣 3 级" },
    { k: "本台 · 全洗返还（锋利 V）", v: 43, tone: "#7ee8dc", sub: "量产成本的 34%" },
  ];
  return (
    <div className="pixelframe bg-[#0d0b1a] border border-arcane/20 p-5 md:p-6 my-8">
      <p className="font-code text-[10.5px] tracking-[0.2em] text-gild mb-4">图 2 · 锋利 V 一次附魔的经验点数（玩家恰在门槛等级）</p>
      <div className="space-y-3">
        {rows.map((r, i) => (
          <div key={r.k} className="grid grid-cols-[1fr] md:grid-cols-[230px_1fr] items-center gap-2 md:gap-4">
            <span className="text-[12.5px] text-mute">{r.k}</span>
            <div className="flex items-center gap-3">
              <div className="flex-1 h-6 bg-obsidian rounded-sm overflow-hidden border border-arcane/10">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: `${(r.v / 306) * 100}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.9, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                  className="h-full"
                  style={{ background: `linear-gradient(90deg, ${r.tone}aa, ${r.tone})` }}
                />
              </div>
              <span className="font-vt text-[22px] w-14 text-right" style={{ color: r.tone }}>{r.v}</span>
            </div>
            <span className="hidden md:block" />
            <span className="text-[10.5px] text-faint -mt-1">{r.sub}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

/* ── 节渲染 ── */
const SEV_TONE = { 高: "#ff6b8a", 中: "#e8c37c", 低: "#7ee8dc" } as const;

const SectionView = ({ s }: { s: Section }) => (
  <section id={s.id} data-essay-section className="scroll-mt-24 py-14 md:py-16 border-t border-arcane/10 first:border-t-0">
    <motion.header initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: "-60px" }} transition={{ duration: 0.6 }} className="mb-8">
      <div className="flex items-baseline gap-4">
        <span className="font-display font-black text-5xl md:text-6xl leading-none" style={{ color: "transparent", WebkitTextStroke: "1.2px rgba(232,195,124,0.55)" }}>
          {s.num}
        </span>
        <div>
          <p className="font-code text-[10.5px] tracking-[0.32em] text-gild mb-1">{s.kicker}</p>
          <h2 className="font-display font-black text-2xl md:text-[2rem] text-parch leading-tight">{s.title}</h2>
        </div>
      </div>
      {s.lead && <p className="mt-4 text-[15px] leading-8 text-gild/80 font-display italic">{s.lead}</p>}
    </motion.header>

    {s.theses && (
      <ol className="space-y-3">
        {s.theses.map((t, i) => (
          <motion.li key={t.k} initial={{ opacity: 0, x: -10 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.06 }} className="flex gap-4 rounded-sm bg-vellum/50 border border-arcane/12 p-4 md:p-5">
            <span className="shrink-0 w-14 font-display font-black text-gild text-lg">{t.k}</span>
            <p className="text-[14.5px] leading-[1.95] text-mute font-light">
              <Rich t={t.v} />
            </p>
          </motion.li>
        ))}
      </ol>
    )}

    {s.id === "balance" && s.stats && (
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-6">
        {s.stats.map((st) => (
          <div key={st.label} className="rounded-sm bg-vellum/60 border border-arcane/15 p-4">
            <p className="text-[11px] text-faint mb-1.5">{st.label}</p>
            <p className="font-vt text-[26px] leading-none text-parch">{st.value}</p>
            <p className="text-[11px] text-mute mt-1.5">{st.sub}</p>
          </div>
        ))}
      </div>
    )}

    {s.compare && (
      <div className="overflow-x-auto wiki-scroll mb-8 -mx-1 px-1">
        <table className="w-full min-w-[860px] text-[12.5px] border-collapse">
          <thead>
            <tr>
              <th className="text-left font-normal text-faint py-2.5 pr-3 sticky left-0 bg-obsidian">mod</th>
              {s.compare.dims.map((d) => (
                <th key={d} className="text-left font-normal text-faint py-2.5 px-3 whitespace-nowrap">{d}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {s.compare.rows.map((r) => (
              <tr key={r.name} className="border-t border-arcane/10" style={{ background: r.self ? "rgba(161,140,255,0.07)" : undefined }}>
                <td className="py-3 pr-3 sticky left-0" style={{ background: r.self ? "#15112a" : "#0a0913" }}>
                  <span className="block font-display font-bold text-parch whitespace-nowrap">{r.name}</span>
                  {r.tag && <span className="block font-code text-[10px] text-faint">{r.tag}</span>}
                </td>
                {r.cells.map((c, i) => (
                  <td key={i} className="py-3 px-3 align-top text-mute leading-6">
                    <Rich t={c} />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    )}

    {s.id === "balance" && <CostBars />}

    {s.paras && (
      <div className="space-y-5">
        {s.paras.map((p, i) => (
          <p key={i} className="text-[15px] leading-[2.05] text-mute font-light first-letter:text-parch">
            <Rich t={p.t} />
          </p>
        ))}
      </div>
    )}

    {s.id === "singular" && <BoundaryDiagram />}

    {s.gaps && (
      <div className="space-y-4">
        {s.gaps.map((g, i) => (
          <motion.article key={g.id} initial={{ opacity: 0, y: 14 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: Math.min(i * 0.05, 0.25) }} className="pixelframe bg-vellum/60 border p-5 md:p-6" style={{ borderColor: `${SEV_TONE[g.sev]}35` }}>
            <div className="flex flex-wrap items-center gap-2.5 mb-3">
              <span className="font-code text-[10.5px] px-2 py-0.5 rounded-sm" style={{ color: SEV_TONE[g.sev], background: `${SEV_TONE[g.sev]}15`, border: `1px solid ${SEV_TONE[g.sev]}45` }}>
                {g.id} · {g.sev}
              </span>
              <h3 className="font-display font-bold text-[17px] text-parch">{g.title}</h3>
            </div>
            <p className="text-[14px] leading-[1.95] text-mute font-light">
              <Rich t={g.body} />
            </p>
            <p className="mt-3 text-[13.5px] leading-[1.85] text-tealw/90 border-l-2 border-tealw/40 pl-3">
              <span className="font-medium">建议：</span>
              <Rich t={g.fix} />
            </p>
          </motion.article>
        ))}
      </div>
    )}
  </section>
);

/* ── 主页面 ── */
export default function EssayApp({ onSwitch }: { onSwitch: (v: View) => void }) {
  const [active, setActive] = useState("abstract");
  const [kindFilter, setKindFilter] = useState<FnKind | "all">("all");
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 24 });

  useEffect(() => {
    const els = Array.from(document.querySelectorAll<HTMLElement>("[data-essay-section]"));
    const obs = new IntersectionObserver((es) => es.forEach((e) => e.isIntersecting && setActive(e.target.id)), { rootMargin: "-30% 0px -65% 0px" });
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  const counts = FN_ORDER.reduce<Record<string, number>>((m, f) => ((m[f.kind] = (m[f.kind] ?? 0) + 1), m), {});
  const shownFn = FN_ORDER.filter((f) => kindFilter === "all" || f.kind === kindFilter);

  return (
    <div className="min-h-screen bg-obsidian text-parch font-body selection:bg-arcane/30">
      <motion.div className="fixed top-0 left-0 right-0 h-[2px] z-[80] origin-left bg-gradient-to-r from-gild via-arcane to-tealw" style={{ scaleX: progress }} />

      <header className="sticky top-0 z-[70] h-14 flex items-center gap-3 px-4 md:px-8 bg-obsidian/90 backdrop-blur-md border-b border-arcane/12">
        <Sprite id="enchanted_book" size={26} />
        <span className="font-display font-black text-[15px]">设计自述</span>
        <span className="hidden md:inline font-code text-[10px] text-faint">基线 {COMMIT.slice(0, 7)}</span>
        <div className="ml-auto flex items-center gap-2">
          <button onClick={() => onSwitch("wiki")} className="flex items-center gap-1.5 px-3 py-1.5 rounded-sm border border-arcane/25 text-mute hover:text-parch text-[12px] cursor-pointer">
            <BookOpen size={13} />
            <span className="hidden sm:inline">交互式 WIKI</span>
          </button>
          <button onClick={() => onSwitch("wording")} className="flex items-center gap-1.5 px-3 py-1.5 rounded-sm border border-tealw/30 text-tealw text-[12px] hover:bg-tealw/10 cursor-pointer">
            <PenLine size={13} />
            <span className="hidden sm:inline">措辞校准</span>
          </button>
          <button onClick={() => onSwitch("proposal")} className="flex items-center gap-1.5 px-3 py-1.5 rounded-sm border border-gild/30 text-gild text-[12px] hover:bg-gild/10 cursor-pointer">
            <ScrollText size={13} />
            <span className="hidden sm:inline">提案与审计</span>
          </button>
        </div>
      </header>

      {/* 题头 */}
      <div className="relative overflow-hidden border-b border-arcane/10">
        <img src="/images/wiki-hero.jpg" alt="" className="absolute inset-0 w-full h-full object-cover opacity-20" />
        <div className="absolute inset-0 bg-gradient-to-b from-obsidian/40 via-obsidian/80 to-obsidian" />
        <div className="relative max-w-4xl mx-auto px-6 md:px-10 pt-20 pb-16">
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="font-code text-[11px] tracking-[0.4em] text-gild mb-5">
            A DESIGN READING · 纂刻附魔台 26.1.2
          </motion.p>
          <motion.h1 initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="font-display font-black leading-[1.12] text-parch" style={{ fontSize: "clamp(2.2rem, 5.4vw, 3.9rem)" }}>
            从抽奖到藏书
            <br />
            <span className="shimmer-text">一个附魔 mod 的方向、同类与边界</span>
          </motion.h1>
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }} className="mt-6 max-w-2xl text-[15px] leading-8 text-mute font-light">
            这是一篇基于源码的设计评论。正文共 {FN_ORDER.length} 处注释，每一处都可以悬停查看引文，点击跳到 GitHub 上对应的提交与行号；所有数字都由与 Java 实装一致的公式算出。凡是推论，都会写明是推论。
          </motion.p>
          <div className="mt-7 flex flex-wrap gap-2">
            {(Object.keys(KIND) as FnKind[]).filter((k) => counts[k]).map((k) => (
              <span key={k} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-sm text-[11.5px]" style={{ color: KIND[k].tone, background: `${KIND[k].tone}12`, border: `1px solid ${KIND[k].tone}35` }}>
                {(() => {
                  const I = KIND[k].Icon;
                  return <I size={12} />;
                })()}
                {KIND[k].label} {counts[k]}
              </span>
            ))}
            <a href={`${REPO}/tree/${COMMIT}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-sm text-[11.5px] text-faint border border-arcane/20 hover:text-parch">
              查看基线源码 <ExternalLink size={11} />
            </a>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 md:px-10 flex gap-10">
        {/* 目录 */}
        <aside className="hidden lg:block w-48 shrink-0">
          <nav className="sticky top-24 py-10 space-y-1">
            <p className="font-code text-[9.5px] tracking-[0.3em] text-faint mb-3">目录</p>
            {[...SECTIONS.map((s) => ({ id: s.id, num: s.num, title: s.title.split("：")[0] })), { id: "notes", num: "※", title: "注释" }].map((s) => (
              <a key={s.id} href={`#${s.id}`} className="flex items-baseline gap-2.5 py-1.5 text-[13px] transition-colors group" style={{ color: active === s.id ? "#ede6d4" : "#6f659a" }}>
                <span className="font-display font-bold w-5 text-center" style={{ color: active === s.id ? "#e8c37c" : undefined }}>
                  {s.num}
                </span>
                <span className="group-hover:text-parch">{s.title}</span>
              </a>
            ))}
          </nav>
        </aside>

        {/* 正文 */}
        <main className="flex-1 min-w-0 max-w-3xl pb-24">
          {SECTIONS.map((s) => (
            <SectionView key={s.id} s={s} />
          ))}

          {/* 注释 */}
          <section id="notes" data-essay-section className="scroll-mt-24 py-14 border-t border-arcane/10">
            <div className="flex flex-wrap items-baseline justify-between gap-3 mb-6">
              <div>
                <p className="font-code text-[10.5px] tracking-[0.32em] text-gild mb-1">NOTES</p>
                <h2 className="font-display font-black text-2xl text-parch">注释（{FN_ORDER.length}）</h2>
              </div>
              <div className="flex flex-wrap gap-1.5">
                <button onClick={() => setKindFilter("all")} className="px-2.5 py-1 rounded-sm text-[11px] border cursor-pointer" style={{ color: kindFilter === "all" ? "#0a0913" : "#ede6d4", background: kindFilter === "all" ? "#ede6d4" : "transparent", borderColor: "rgba(237,230,212,0.3)" }}>
                  全部
                </button>
                {(Object.keys(KIND) as FnKind[]).filter((k) => counts[k]).map((k) => (
                  <button key={k} onClick={() => setKindFilter(k)} className="px-2.5 py-1 rounded-sm text-[11px] border cursor-pointer" style={{ color: kindFilter === k ? "#0a0913" : KIND[k].tone, background: kindFilter === k ? KIND[k].tone : "transparent", borderColor: `${KIND[k].tone}55` }}>
                    {KIND[k].label} {counts[k]}
                  </button>
                ))}
              </div>
            </div>
            <ol className="space-y-3">
              {shownFn.map((f) => {
                const n = FN_NUM[f.id];
                return (
                  <li key={f.id} id={`fn-${n}`} className="scroll-mt-24 target:ring-1 target:ring-gild/60 rounded-sm">
                    <FnCard f={f} n={n} />
                  </li>
                );
              })}
            </ol>
          </section>

          <div className="flex justify-center">
            <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="inline-flex items-center gap-2 px-4 py-2 rounded-sm border border-arcane/25 text-[12px] text-mute hover:text-parch cursor-pointer">
              <ArrowUp size={13} /> 回到顶部
            </button>
          </div>
        </main>
      </div>
    </div>
  );
}
