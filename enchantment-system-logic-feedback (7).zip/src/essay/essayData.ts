// ═══════════════════════════════════════════════════════════
// 设计自述 · 纂刻附魔台（26.1.2 社区移植版）
// 基线提交：aa33a1a017939b064dce64a547f32734426b9b7d（2026-10-23）
// 正文中 [[id]] 为脚注锚点，按首次出现顺序自动编号。
// ═══════════════════════════════════════════════════════════

export const COMMIT = "aa33a1a017939b064dce64a547f32734426b9b7d";
export const REPO = "https://github.com/q14433686-arch/chiseled-enchanting-table-26.1.2-source";

export type FnKind = "code" | "data" | "test" | "calc" | "web" | "vanilla";

export interface Footnote {
  id: string;
  kind: FnKind;
  ref: string; // path:line 或来源名
  path?: string;
  line?: number;
  lineEnd?: number;
  url?: string;
  quote?: string;
  note: string;
}

const C = (id: string, path: string, line: number, quote: string, note: string, lineEnd?: number, kind: FnKind = "code"): Footnote => ({
  id,
  kind,
  path,
  line,
  lineEnd,
  ref: `${path.replace(/^src\/(main|client|test)\/(java|resources)\//, "")}:${line}${lineEnd ? `–${lineEnd}` : ""}`,
  url: `${REPO}/blob/${COMMIT}/${path}#L${line}${lineEnd ? `-L${lineEnd}` : ""}`,
  quote,
  note,
});
const J = "src/main/java/chiseled_enchanting_table/";
const DP = "src/main/resources/data/chiseled_enchanting_table/chiseled_enchanting_table/";

export const FOOTNOTES: Footnote[] = [
  // ── 方向 ──
  C("book_block", J + "mixin/enchanting_table/DisableBookEnchanting.java", 27, "if (!container.getItem(0).is(Items.BOOK)) return;", "原版附魔台只对「书」被拦截（清空三个选项并 cancel）；放装备时原逻辑照常运行。", 36),
  C("anvil_merge", J + "mixin/anvil/RemoveEnchantMerge.java", 49, "if (leftLevel > 0 && leftLevel == rightLevel && leftLevel < maxLevel) {", "铁砧上两本同级未满级附魔书的合并结果被清空——升阶只能走纂刻台。", 66),
  C("anvil_flat", J + "mixin/anvil/RemoveXpCostScaling.java", 17, "cir.setReturnValue(oldRepairCost);", "铁砧累积惩罚（2×cost+1）被固定为旧值，「过于昂贵」不再出现。", 19),
  C("tome_unlock", J + "block/ChiseledEnchantingTableBlock.java", 322, "// Track 3 (Chiseled Bookshelves): unlock each stored Master Tome 1:1 from the already-scanned map.", "雕纹书架里的书按 1:1 解锁对应魔咒的 1~L 级；扫描只读取，不修改书架内容。", 325),
  C("tome_mass", J + "menu/ChiseledEnchantingTableScreenHandler.java", 1007, "&& storedMasterLevel(e.enchantment_id()) >= e.enchantment_level();", "只要母本等级 ≥ 目标等级，该行就走「原版量产模式」计价。", 1011),
  C("tome_book", J + "mechanics/enchanting/EnchantmentApplication.java", 77, "if (enchantable_item.is(Items.BOOK)) {", "目标是普通书时，直接生成一本标准附魔书——母本可以复刻成新书。", 85),
  C("structure", J + "mechanics/structure/BookshelfReplacerProcessor.java", 28, "* (villages, mansions, ancient cities, ...) into filled {@link Blocks#CHISELED_BOOKSHELF} blocks", "结构生成时把普通书架替换成装了书的雕纹书架：知识散落在世界里，等待探索。", 30),
  C("pool", DP + "bookshelf_book_pool.json", 4, "\"book_count\": { \"min\": 3, \"max\": 5 }, \"enchanted_book_probability\": 0.12", "每座结构雕纹书架放 3~5 本书，每本 12% 为附魔书，期望约 0.48 本附魔书/座。", 8, "data"),
  C("loot", DP + "loot_injections.json", 4, "\"entries\": [ … 41 个原版战利品表 … ]", "向 41 张原版宝箱/考古战利品表注入指定附魔书（如末地城：经验修补、锋利 V…），全文件 1227 行。", undefined, "data"),
  C("stack64", J + "ChiseledEnchantingTable.java", 31, "builder.set(DataComponents.MAX_STACK_SIZE, bookStackSize)", "附魔书堆叠上限改为可配置（默认 64），书被当作「库存」管理。"),

  // ── 经验语言 ──
  C("xp_tier", J + "mechanics/enchanting/XpCostConversion.java", 152, "if (r <= 0.40) { return 1; } if (r <= 0.75) { return 2; } return 3;", "按相对等级 r = L/M 决定扣 1/2/3 级——与原版附魔台三个选项分别扣 1/2/3 级同构。", 165),
  C("xp_threshold", J + "mechanics/enchanting/XpCostConversion.java", 180, "Math.round(8.0 + 22.0 * ((double) Math.min(clampedMax, level) / (double) clampedMax))", "门槛等级 8 + 22·r，满级恰为 30——与原版附魔台的 30 级上限对齐。"),
  C("xp_bar", J + "mechanics/enchanting/XpCostConversion.java", 143, "player.giveExperienceLevels(-req.deductedLevels());", "量产模式扣「整级」并保留经验条百分比，和原版附魔台扣级方式一致。"),
  C("xp_floor", J + "mechanics/enchanting/XpCostConversion.java", 284, "int required = Math.max(deducted, Math.max(base.requiredLevel(), masterFloor.requiredLevel()));", "没有母本时，门槛与扣除都不低于同等级母本路线——母本永远是更便宜的那条路。", 304),

  // ── 守恒 ──
  C("margin", J + "mechanics/enchanting/DisenchantmentApplication.java", 50, "public static final int CONSERVATION_SAFETY_MARGIN_POINTS = 5;", "返还额比母本最低实付再少 5 点。"),
  C("conserve", J + "mechanics/enchanting/DisenchantmentApplication.java", 186, "int cap = Math.max(0, fullMin - CONSERVATION_SAFETY_MARGIN_POINTS); … int bounded = Math.min(desired, cap);", "返还曲线不是独立公式，而是逐级用「母本整级成本」与「每一段增量升级成本」归纳封顶。", 204),
  C("junit", "src/test/java/chiseled_enchanting_table/EconomyAndConfigVerificationTest.java", 159, "void exhaustiveConservationAcrossAllMaxLevelsOneTo255() {", "JUnit 在 maxLevel = 1..255 全量验证返还 < 成本，随 ./gradlew build 执行。", undefined, "test"),
  C("orb", J + "mechanics/enchanting/DisenchantmentApplication.java", 500, "ExperienceOrb.award(serverLevel, spawnPos, refundPoints);", "返还以真实经验球形式发放。", 512),
  C("downgrade_free", J + "mechanics/enchanting/DisenchantmentApplication.java", 374, "int refund = refundForStepDown(cfg, matched, curLvl, desiredLevel, menu.disenchantRefundScale());", "降级与全洗全程没有任何材料扣除调用；只有单洗（:408 起）调用 deductMatchedBundle。", 407),

  // ── 书架 ──
  C("scan", J + "block/ChiseledEnchantingTableBlock.java", 76, "for (int dx = -rx; dx <= rx; dx++) { for (int dy = -ry; dy <= ry; dy++) { … offsets.add(new BlockPos(dx, dy, dz));", "7×5×7 内全部 244 格都计入，没有「中间须为空气」的遮挡判定，紧贴附魔台的格子也算。", 100),
  C("shelf_tag", J + "block/ChiseledEnchantingTableBlock.java", 67, "return !state.is(Blocks.CHISELED_BOOKSHELF) && (state.is(REGULAR_BOOKSHELVES_TAG) || state.is(…ENCHANTMENT_POWER_PROVIDER));", "普通书架由标签判定，模组书架自动兼容。", 70),
  C("gates", DP + "shelf_gates.json", 9, "\"max_bookshelves\": 38, \"gamma\": 1.25, \"blank_max_tier_mode\": \"half_ceil\"", "38 架解锁满级升阶；白板直附封顶在 ⌈M/2⌉。", 11, "data"),
  C("half_ceil", J + "mechanics/resonance/BookshelfProgression.java", 396, "case HALF_CEIL -> Math.min((clampedMax + 1) / 2, curveUnlocked);", "白板（无该附魔）的直附上限 = ⌈M/2⌉。"),
  C("resonance", DP + "library_resonance.json", 5, "\"max_discount_bookshelves\": 38, \"max_wooden_discount_percent\": 15, … \"max_total_xp_discount_percent\": 40", "木架减免 38 架满 15%；公共上限 35%；总上限 40%。", 16, "data"),

  // ── 顿悟 ──
  C("epiphany", DP + "treasure_epiphany.json", 3, "\"min_regular_bookshelves\": 32, … \"max_chance\": 0.90, \"max_slots_cap\": 4, … \"cycle_ticks\": 12000", "32 架唤醒，概率上限 90%，单件最多 4 条，每 10 分钟轮转；可锁定至 60 分钟。", 12, "data"),
  C("exclusive", "src/main/resources/data/chiseled_enchanting_table/tags/enchantment/epiphany_exclusive.json", 4, "\"minecraft:aqua_affinity\", … \"minecraft:silk_touch\", \"minecraft:infinity\", …", "11 个魔咒被划为「顿悟专属」，不进入默认列表。", 14, "data"),
  C("defaults", DP + "default_enchantments.json", 11, "\"exclude_tags\": [ \"#minecraft:treasure\", \"#minecraft:curse\", \"#chiseled_enchanting_table:epiphany_exclusive\" ]", "默认列表 = #in_enchanting_table 减去宝藏、诅咒、顿悟专属。", 14, "data"),

  // ── 置换 ──
  C("tx_totem", DP + "item_transformations.json", 49, "\"input\": \"minecraft:emerald_block\", \"output\": \"minecraft:totem_of_undying\", … \"gold_block\" ×4 + \"ghast_tear\" ×1 + \"amethyst_shard\" ×5", "不死图腾：门槛 30（满减免 18），扣 3 级。", 62, "data"),
  C("tx_gapple", DP + "item_transformations.json", 23, "\"input\": \"minecraft:golden_apple\", \"output\": \"minecraft:enchanted_golden_apple\", … \"gold_block\" ×8 + \"emerald\" ×14", "附魔金苹果：1.9 起原版已删除其合成。", 36, "data"),
  C("tx_echo", DP + "item_transformations.json", 77, "\"input\": \"minecraft:amethyst_shard\", \"output\": \"minecraft:echo_shard\", … \"sculk\" ×4 + \"crying_obsidian\" ×2", "回响碎片：原版只出自远古城市宝箱。", 90, "data"),
  C("tx_trident", DP + "item_transformations.json", 63, "\"input\": \"minecraft:diamond_sword\", \"output\": \"minecraft:trident\", … \"nautilus_shell\" ×1 + prismarine", "三叉戟：原版只由溺尸掉落。", 76, "data"),
  C("curse", DP + "disenchanting.json", 3, "\"allow_curse_purge\": true,", "诅咒默认可被破除（原版中诅咒设计为永久负面）。", undefined, "data"),

  // ── 移植取舍 ──
  C("keep_both", J + "mechanics/loot/EnchantedBookLootInjector.java", 37, "we do <b>not</b> strip vanilla enchanted books from chests (user decision \"keep_both\")", "上游会移除宝箱中的原版附魔书；本移植版选择两者都保留。", 38),
  C("replace_const", J + "mechanics/structure/BookshelfReplacerProcessor.java", 75, "public static final boolean REPLACEMENT_ENABLED = true;", "结构书架替换开关是编译期常量，数据包无法关闭。"),
  C("compat", J + "mechanics/enchanting/EnchantmentApplication.java", 67, "if (!(enchantable_item.is(Items.BOOK) || enchantable_item.is(Items.ENCHANTED_BOOK))) { … if (!Enchantment.areCompatible(key, enchantment)) { newEnchantmentsComponent.set(key, 0);", "给装备附魔时冲突附魔会被直接移除（界面以「覆盖冲突附魔」提示），被覆盖的附魔不返还经验；书本跳过冲突检查。", 74),
  C("overlay", "src/client/java/chiseled_enchanting_table/gui/ChiseledEnchantingTableScreen.java", 272, "this.grimoireOverlay = new ArcaneGrimoireScreen(", "秘典改为在附魔台界面内以覆盖层打开，此前「换屏导致容器关闭」的问题已修复。", 279),

  // ── 外部来源 ──
  {
    id: "rpg",
    kind: "web",
    ref: "TheRedBrain/rpg-enchanting README",
    url: "https://github.com/TheRedBrain/rpg-enchanting",
    quote: "Enchanted Book Consumption Mode … KEEP / CONSUME / PARTIAL_CONSUME · Each item can be enchanted with a maximum of 2 enchantments",
    note: "本 mod README「Inspiration」一节明确致敬此项目。RPG Enchanting 同样用雕纹书架里的附魔书解锁魔咒，但提供书本消耗模式，并限制每件物品最多 2 条附魔。",
  },
  {
    id: "readme_insp",
    kind: "code",
    ref: "README.md:126–129",
    url: `${REPO}/blob/${COMMIT}/README.md#L126-L129`,
    quote: "## Inspiration … https://github.com/TheRedBrain/rpg-enchanting",
    note: "本 mod 的灵感来源声明。",
  },
  {
    id: "apoth",
    kind: "web",
    ref: "Apothic Enchanting（CurseForge 页）/ Apotheosis 书库",
    url: "https://www.curseforge.com/minecraft/mc-mods/apothic-enchanting",
    quote: "The Library uses Points … a level three enchantment is worth four points … you have to insert higher level ones at least once before you can pull them out.",
    note: "Apotheosis 的附魔书库按点数存取：L 级 = 2^(L−1) 点，取出即消耗点数——书本「守恒」，不能凭空复制。",
  },
  {
    id: "infuser",
    kind: "web",
    ref: "Enchanting Infuser（Fuzs）",
    url: "https://modrinth.com/mod/enchanting-infuser",
    quote: "Choose Your Enchantments … Bookshelves work just like they do with a vanilla enchanting table … Recover Experience … similar to a grindstone.",
    note: "确定性选择附魔、书架决定上限；基础版默认不提供经验修补等宝藏附魔；需付全部等级（满附约 25 级），高级版可改/删附魔并返还经验。",
  },
  {
    id: "quark",
    kind: "web",
    ref: "Quark · Matrix Enchanting",
    url: "https://quarkmod.net/",
    quote: "Pieces can be generated using lapis and XP. The pieces then have to be laid on the grid … Incompatible pieces can never be generated.",
    note: "用网格空间作为附魔「预算」，蜡烛引导方向，随机性被约束但未消除。",
  },

  // ── 原版参照 ──
  {
    id: "vanilla_table",
    kind: "vanilla",
    ref: "原版 EnchantmentMenu（Mojang）",
    note: "原版附魔台三个选项分别扣 1/2/3 级，最高门槛 30 级，需 15 个书架且书架与附魔台之间必须为空气。",
  },
  {
    id: "vanilla_trade",
    kind: "vanilla",
    ref: "原版 VillagerTrades.EnchantBookForEmeralds（Mojang）",
    quote: "int j = 2 + random.nextInt(5 + level * 10) + 3 * level; if (DOUBLE_TRADE_PRICE) j *= 2;",
    note: "经验修补（1 级、双倍价）在图书管理员处售价 10~38 绿宝石。本仓库无任何村民交易改动（全仓 grep villager/trade/merchant 结果为空）。",
  },

  // ── 实算 ──
  {
    id: "calc_mass",
    kind: "calc",
    ref: "实算 · forMasterTomeEnchant 移植",
    note: "锋利 V（M=5）母本量产：无减免门槛 30、扣 3 级（306 点）；−40% 时门槛 18、扣 3 级（126 点）。30 级起可连续量产 5 件（30→27→24→21→18）。材料按 enchantment_costs.json：20 青金石 / 18 绿宝石 / 8 紫水晶。",
  },
  {
    id: "calc_full",
    kind: "calc",
    ref: "实算 · forFullArcaneEnchantOrUpgrade 移植",
    note: "无母本白板锋利 III：0% 减免时门槛 21、扣 6 级；40% 减免时门槛 13、扣 4 级。母本量产同等级仅扣 2 级。",
  },
  {
    id: "calc_mending",
    kind: "calc",
    ref: "实算 · enchantment_costs.json:71 + forMasterTomeEnchant",
    note: "经验修补母本复刻一本新书：16 绿宝石（或 18 青金石 / 7 紫水晶）+ 门槛 18 扣 3 级（满减免）。可无限次重复。",
  },
  {
    id: "calc_refund",
    kind: "calc",
    ref: "实算 · essencePotentialFromParams 移植",
    note: "满级全洗返还：锋利 V 43 点、经验修补 49 点，约为量产成本 126 点的 34%~39%。低等级：耐久 I 9 点、耐久 II 28 点、效率 II 11 点。",
  },
  {
    id: "calc_mc",
    kind: "calc",
    ref: "蒙特卡洛 · 原版附魔算法 × 本台返还，20 万次/组",
    note: "金靴子（附魔能力 25）放原版附魔台第 1 槽、0 或 15 书架：期望返还 9.9 / 19.8 点，玩家恰在门槛等级时的最低经验成本 7.7 / 17.0 点，净 +2.1 / +2.8 点，另耗 1 青金石。第 2、3 槽及钻石工具均为净亏。假设：玩家精确停在门槛等级、原版附魔权重按 1.21 数据。",
  },
];

/* ═══════════════════ 正文 ═══════════════════ */

export interface Para {
  t: string; // 支持 [[fn]] 与 **粗体**
}
export interface Compare {
  dims: string[];
  rows: { name: string; tag?: string; cells: string[]; self?: boolean }[];
}
export interface Gap {
  id: string;
  sev: "高" | "中" | "低";
  title: string;
  body: string;
  fix: string;
}
export interface Section {
  id: string;
  num: string;
  kicker: string;
  title: string;
  lead?: string;
  paras?: Para[];
  compare?: Compare;
  stats?: { label: string; value: string; sub: string }[];
  gaps?: Gap[];
  theses?: { k: string; v: string }[];
}

export const SECTIONS: Section[] = [
  {
    id: "abstract",
    num: "〇",
    kicker: "ABSTRACT",
    title: "摘要：五个判断",
    theses: [
      { k: "方向", v: "把附魔从「抽奖」改成「藏书」：确定性选择 + 知识收集 + 图书馆经营。经验计价刻意保留原版的语言（扣 1/2/3 级、30 级门槛），改变的是**谁来决定结果**。" },
      { k: "同类", v: "最近的亲戚是 RPG Enchanting（同样以雕纹书架解锁），其次是 Enchanting Infuser（确定性选择）与 Apotheosis 书库（书本存储）。它与三者的根本差异在于：**母本永不消耗，且可以复刻**。" },
      { k: "特异点", v: "其一，「知识即资产」——一本书解锁无限次使用；其二，退魔返还由成本曲线归纳派生、并有 JUnit 全量证明，这在同类 mod 中少见。" },
      { k: "平衡", v: "前期与原版持平甚至略贵，后期显著便宜：经验从「消耗品」变为「门槛」，主要消耗转移给青金石等材料。这是有意为之的「先付知识成本、后享量产」曲线，但后期经验几乎失去回收作用。" },
      { k: "欠缺", v: "最大的结构性问题不在数值，而在**外部通道**：原版附魔台仍可给装备附魔、村民与宝箱照常出书、退魔不问来源——mod 自己的门槛和守恒证明，都只在自己的边界内成立。" },
    ],
  },
  {
    id: "direction",
    num: "壹",
    kicker: "DIRECTION",
    title: "方向：从抽奖到藏书",
    lead: "判断一个 mod 的方向，与其看它新增了什么，不如看它拿走了什么。",
    paras: [
      { t: "本 mod 对原版附魔生态动了三刀。第一刀，原版附魔台被禁止给**书**附魔[[book_block]]；第二刀，铁砧不再允许两本同级未满级的附魔书合并[[anvil_merge]]；第三刀，铁砧的累积惩罚被固定，「过于昂贵」从此消失[[anvil_flat]]。三刀合起来的效果是：**附魔书的生产与升阶只剩纂刻台这一条路**，而附魔书的使用（铁砧应用到装备上）反而变得更自由。" },
      { t: "被拿走的是「随机产书」，补回来的是「确定的知识」。雕纹书架里的每本附魔书都按 1:1 解锁对应魔咒[[tome_unlock]]，一旦母本等级覆盖目标等级，这一行就切换到廉价的量产计价[[tome_mass]]；目标是普通书时，台子直接产出一本新的附魔书[[tome_book]]。与此同时，世界生成会把村庄、林地府邸、远古城市里的普通书架替换成装了书的雕纹书架[[structure]]，每座约 0.48 本附魔书[[pool]]；41 张原版战利品表也被注入了指定的附魔书[[loot]]。附魔书甚至可以堆叠到 64[[stack64]]——它们被当作「库存」来管理。" },
      { t: "值得注意的是，mod 并没有发明一套新的经验经济，而是**借用了原版的经验语言**。原版附魔台三个选项分别扣 1/2/3 级、门槛最高 30 级[[vanilla_table]]；本 mod 按相对等级 r = L/M 决定扣 1/2/3 级[[xp_tier]]，门槛为 8 + 22·r、满级正好 30[[xp_threshold]]，并像原版一样扣整级、保留经验条百分比[[xp_bar]]。玩家熟悉的「30 级、扣 3 级」体感被完整保留，变化只有一点：**结果由玩家决定，而不是由种子决定**。" },
      { t: "所以，这个 mod 的方向可以概括为：**确定性附魔 + 知识收集 + 图书馆经营**。书架数量决定「能做到多高」，雕纹书架里的藏书决定「能不能便宜地做」，世界探索决定「藏书从哪来」。" },
    ],
  },
  {
    id: "peers",
    num: "贰",
    kicker: "PEERS",
    title: "同类：它像谁，又不像谁",
    lead: "下表只比较「附魔方式」这一维度，不评价各 mod 的整体质量。",
    compare: {
      dims: ["怎么选附魔", "知识/上限从哪来", "书本用后", "每件附魔数", "书架的作用", "经验回收", "宝藏附魔"],
      rows: [
        { name: "原版", tag: "Mojang", cells: ["随机三选一", "15 书架 → 30 级", "—", "不限（铁砧）", "提升等级，须隔一格空气", "砂轮少量返还", "仅交易/宝箱"] },
        { name: "纂刻附魔台", tag: "本 mod", self: true, cells: ["确定选择", "雕纹书架藏书 + 普通书架数量", "**永不消耗，可复刻**", "不限（冲突覆盖）", "7×5×7 计数，无遮挡判定；38 架满级", "全洗/降级按守恒曲线返还", "母本 / 32 架顿悟 / 宝箱 / 交易"] },
        { name: "RPG Enchanting", tag: "TheRedBrain", cells: ["确定选择", "进度 / 周围方块 / 雕纹书架藏书", "可配置：保留 / 消耗 / 部分消耗", "最多 2 条（前缀+后缀）", "解锁来源之一", "替换时付更高价", "按解锁方式"] },
        { name: "Apotheosis 书库", tag: "Shadows_of_Fire", cells: ["随机（属性引导）+ 书库取用", "书库记录存入过的最高级", "**按点数消耗**（L 级 = 2^(L−1) 点）", "不限", "Eterna/Quanta/Arcana 三属性", "—", "随机/书库"] },
        { name: "Enchanting Infuser", tag: "Fuzs", cells: ["确定选择", "书架能量（同原版）", "—", "不限", "同原版，满级约需 15~30", "高级版可返还（类砂轮）", "默认不提供"] },
        { name: "Quark 矩阵附魔", tag: "Vazkii", cells: ["随机生成碎片，自由摆放", "书架 + 蜡烛引导", "—", "受网格空间限制", "能量与碎片数", "—", "否"] },
      ],
    },
    paras: [
      { t: "**最像谁**：RPG Enchanting。本 mod 在 README 中明确把它列为灵感来源[[readme_insp]]，两者都让雕纹书架里的附魔书解锁魔咒[[rpg]]。但 RPG Enchanting 提供「保留 / 消耗 / 部分消耗」三种书本消耗模式，并把每件物品限制在 2 条附魔；本 mod 只有「保留」一种行为（扫描只读、不改书架[[tome_unlock]]），也不限制附魔条数。" },
      { t: "**和 Apotheosis 书库相比**：两者都把附魔书当作「可取用的库存」，但 Apotheosis 书库按点数存取，取出就消耗点数，书本数量守恒[[apoth]]；本 mod 的母本取用不消耗任何东西，复刻次数只受经验与材料限制[[tome_book]]。前者是仓库，后者是印刷机。" },
      { t: "**和 Enchanting Infuser 相比**：两者都是「确定性选择」，Infuser 用书架能量决定上限、默认不给宝藏附魔、且需付全部等级（满附约 25 级）[[infuser]]；本 mod 把「能不能做」拆成书架数量与藏书两条轴，并用量产模式把后期价格压到 1~3 级。" },
      { t: "**和 Quark 相比**：Quark 用网格空间给附魔设「预算」，随机性被约束但没有消除[[quark]]；本 mod 完全消除随机，也没有引入预算概念——附魔条数的唯一约束是原版冲突规则[[compat]]。" },
    ],
  },
  {
    id: "singular",
    num: "叁",
    kicker: "SINGULARITY",
    title: "特异点：它真正独有的东西",
    paras: [
      { t: "**一、知识即资产，且可复制。** 同类设计中，「解锁」通常意味着权限（RPG Enchanting）或库存（Apotheosis）。本 mod 的母本两者都是又都不是：它像权限一样不消耗[[tome_unlock]]，又像库存一样能产出实体书[[tome_book]]。一本从末地城翻出的经验修补[[loot]]，放进雕纹书架后，每次只需 16 绿宝石和 3 级经验就能复刻一本新的[[calc_mending]]——这比图书管理员的报价区间（10~38 绿宝石）[[vanilla_trade]]更稳定，而且不需要村民。整个经济由此变成「**前期付知识成本，后期享受量产**」。" },
      { t: "**二、经验守恒是被证明的，而不是被调出来的。** 大多数退魔/返还机制用一个独立的返还系数（砂轮式的「返还一半」）。本 mod 的返还曲线逐级用母本整级成本与每一段增量升级成本做上界[[conserve]]，再留 5 点安全裕度[[margin]]，并由 JUnit 在 maxLevel = 1..255 上穷举验证[[junit]]。这意味着「先附魔再退魔」在本台内部不可能净赚经验——在同类 mod 中，这种程度的经济自证并不常见。返还以真实经验球发放[[orb]]，降级和全洗不收任何材料[[downgrade_free]]。" },
      { t: "**三、两种书架、两种职能。** 普通书架只管「数量」（由标签判定，模组书架自动兼容[[shelf_tag]]）：决定能升到多高[[gates]]、给多少减免[[resonance]]、何时唤醒顿悟[[epiphany]]；雕纹书架只管「内容」：里面是什么书，就解锁什么魔咒。白板直附被封顶在一半等级[[half_ceil]]，迫使玩家要么收集母本、要么从已有附魔起步升级。" },
      { t: "**四、时间驱动的宝藏获取。** 宝藏顿悟以 10 分钟为周期轮转、可花费材料锁定[[epiphany]]，把经验修补、精准采集等「顿悟专属」魔咒[[exclusive]]从默认列表中拿出来[[defaults]]，变成需要 32 个书架才能触达的周期性机会。这是一个少见的、把「时间」作为附魔资源的设计。" },
    ],
  },
  {
    id: "balance",
    num: "肆",
    kicker: "BALANCE",
    title: "平衡性：用数字说话",
    lead: "下列数字均由与 Java 实装逐行一致的公式计算得出，标注了对应脚注。",
    stats: [
      { label: "锋利 V · 母本量产（满减免）", value: "Lv.18 · 扣 3 级", sub: "126 点 + 20 青金石" },
      { label: "原版 30 级附魔（随机）", value: "Lv.30 · 扣 3 级", sub: "306 点 + 3 青金石" },
      { label: "30 级起连续量产满级装备", value: "5 件", sub: "30→27→24→21→18" },
      { label: "白板锋利 III · 无母本", value: "扣 6 级 / 扣 4 级", sub: "0% / 40% 减免" },
      { label: "经验修补 · 母本复刻一本", value: "16 绿宝石 + 3 级", sub: "原版交易 10~38 绿宝石" },
      { label: "满级全洗返还 / 量产成本", value: "34%~39%", sub: "锋利 V 43 点 · 修补 49 点" },
    ],
    paras: [
      { t: "**前期**，没有母本时，所有附魔走完整消耗模式，且门槛与扣除被强制不低于母本路线[[xp_floor]]。白板锋利 III 在无减免时要扣 6 级[[calc_full]]——与原版相比持平甚至略贵。这一阶段的瓶颈是「书架够不够」与「藏书有没有」。" },
      { t: "**后期**，有了满级母本与书库减免，锋利 V 只需 18 级门槛、扣 3 级、126 点经验[[calc_mass]]，比原版一次 30 级附魔的 306 点低六成，且结果确定。30 级的玩家可以连续做出 5 件满级装备。经验在这里的角色从「消耗品」变成了「门槛」，真正被消耗的是青金石——而青金石恰恰是最容易获得的矿物之一。" },
      { t: "**退魔**，满级全洗只返还量产成本的三分之一左右[[calc_refund]]，内部循环被证明不能净赚[[junit]]。但证明的范围只覆盖本台自己的成本：用原版附魔台给金靴子附魔、再到本台全洗，模拟显示每次可净得约 2~3 点经验、消耗 1 青金石[[calc_mc]]。数额小到不足以构成漏洞，却说明「任何循环都不能净赚」只在 mod 自己的边界内成立。" },
      { t: "**结论**：数值层面是自洽的，而且有意为之——它奖励建书库、奖励收集，惩罚的只是「没有母本」。问题不在于某个数字是否偏高或偏低，而在于后期经验几乎失去回收作用，以及下一节要讲的几条外部通道。" },
    ],
  },
  {
    id: "gaps",
    num: "伍",
    kicker: "DESIGN GAPS",
    title: "设计层面的欠缺",
    lead: "以下按影响面排序。每条都区分「代码事实」与「推论」，并给出可落地的建议。",
    gaps: [
      {
        id: "D1",
        sev: "高",
        title: "知识无限复制，且没有任何可配置的消耗模式",
        body: "母本扫描只读不写[[tome_unlock]]，复刻目标可以是普通书[[tome_book]]，量产判定只看母本等级[[tome_mass]]。推论：任何一本附魔书一旦入架，就等于该魔咒在本世界永久「免费化」——稀缺性只存在于「第一本」。灵感来源 RPG Enchanting 提供了消耗模式[[rpg]]，Apotheosis 用点数守恒[[apoth]]，本 mod 两者都没有。",
        fix: "在 library_resonance.json 或新文件里加 consumption_mode（keep / wear / consume），或让「复刻成书」与「附魔装备」分开计价：复刻成书按 Apotheosis 式递增成本，附魔装备保持现价。",
      },
      {
        id: "D2",
        sev: "高",
        title: "原版附魔台仍能给装备附魔，绕过白板封顶与顿悟专属",
        body: "原版附魔台只拦截书[[book_block]]。白板直附被封顶在 ⌈M/2⌉[[half_ceil]]，精准采集、无限等被划为顿悟专属[[exclusive]][[defaults]]——但原版附魔台在 15 书架时照样能随机给镐子精准采集、给剑锋利 IV。推论：mod 精心设计的「先藏书、后满级」门槛，对愿意多赌几次原版台的玩家并不成立；而一旦装备带上了某附魔，就能走升阶轨道继续往上升。",
        fix: "给 DisableBookEnchanting 增加一个数据包开关（disable_vanilla_table: books | all | none），默认 books 保持现状；或者让「顿悟专属」标签同时作用于原版附魔台的可选池。",
      },
      {
        id: "D3",
        sev: "中",
        title: "退魔返还不问附魔来源，守恒证明只覆盖本台",
        body: "返还按魔咒与等级计算[[conserve]]，不检查这条附魔是否在本台产生。宝箱书[[loot]]、交易书[[vanilla_trade]]、原版附魔台的装备都能直接兑换成经验；对原版台的模拟显示存在每次约 +2~3 点的微小正收益[[calc_mc]]。推论：数额本身无害，但 JUnit 的「无套利」结论[[junit]]不能被理解为「全局无套利」。",
        fix: "本台附魔时给物品打一个数据组件标记，只有带标记的附魔按完整守恒曲线返还；外来附魔按更低比例（如砂轮水平）返还。",
      },
      {
        id: "D4",
        sev: "中",
        title: "书库没有空间约束，「建图书馆」退化为「堆方块」",
        body: "扫描覆盖 7×5×7 全部 244 格，没有遮挡判定，紧贴附魔台的格子也算[[scan]]。原版要求书架与附魔台之间必须是空气[[vanilla_table]]。推论：38 个书架可以塞成一个实心方块包住附魔台，mod 叙事里的「大书库」在空间上没有任何要求；也因此第 8/12/18/32/38 这些刻度只是「数量」，不是「建筑」。",
        fix: "对距离 1 的格子降权或不计，或保留原版的「中间须为空气」判定；为大书库加入最低占地或层高要求，让 32/38 架真正成为建筑目标。",
      },
      {
        id: "D5",
        sev: "中",
        title: "物品置换绕开探索内容，与「知识来自探索」的方向相悖",
        body: "不死图腾无需袭击或林地府邸[[tx_totem]]，附魔金苹果复活了 1.9 前的合成[[tx_gapple]]，回响碎片无需远古城市[[tx_echo]]，三叉戟无需溺尸[[tx_trident]]。推论：附魔系统本身鼓励玩家去结构里找书[[structure]]，但置换系统又让玩家可以跳过同一批结构的核心奖励——两套系统的价值观在打架。",
        fix: "默认关闭这四个置换，或把它们挂在对应进度（如「击杀唤魔者」「进入远古城市」）之后；保留附魔之瓶与空白覆写这类不替代探索奖励的置换。",
      },
      {
        id: "D6",
        sev: "低",
        title: "规则太多，需要一本 8 章手册来解释本身就是信号",
        body: "五道书架刻度（8/12/18/32/38）[[gates]][[resonance]][[epiphany]]、三种经验徽章[[xp_floor]]、三条解锁轨道[[half_ceil]]、七种以上耗材，再加上顿悟锁定与残卷梯度。秘典已改为覆盖层打开，体验问题已修[[overlay]]，但它的存在本身说明：玩家仅凭界面很难理解全部规则。",
        fix: "合并刻度（如残卷梯度复用 12/32），让界面在每行直接写出「为什么是这个价」，而不是依赖手册。",
      },
      {
        id: "D7",
        sev: "低",
        title: "移植版改变了上游的稀缺性前提",
        body: "上游会移除宝箱里的原版附魔书，移植版选择两者都保留[[keep_both]]。叠加 D1 的无限复制，母本来源远多于上游设想。另外，结构书架替换开关是 Java 常量[[replace_const]]，诅咒默认可破除[[curse]]，冲突附魔被覆盖时不返还经验[[compat]]——这些都是可以讨论的取舍。",
        fix: "把 keep_both 与结构替换做成数据包开关，让服主在「上游的稀缺」与「移植版的宽松」之间自己选。",
      },
    ],
  },
  {
    id: "verdict",
    num: "陆",
    kicker: "VERDICT",
    title: "结论",
    paras: [
      { t: "纂刻附魔台是一个**方向清晰、内部严谨、边界松散**的 mod。方向清晰：它知道自己要把附魔从抽奖变成藏书，并且用原版玩家熟悉的经验语言完成了这件事。内部严谨：返还由成本派生、有穷举测试、几乎所有数值都可由数据包覆盖。边界松散：原版附魔台、村民、宝箱、物品置换这些外部通道没有被纳入同一套规则，于是 mod 自己精心设计的门槛和守恒，都只在它自己的边界内成立。" },
      { t: "如果只改三件事：第一，给母本复刻加一个可配置的消耗或递增成本（D1）；第二，给原版附魔台加一个开关（D2）；第三，给本台产出的附魔打标记，让守恒覆盖到它该覆盖的范围（D3）。这三处都不需要推翻现有设计，只需要把已有的严谨延伸到边界上。" },
    ],
  },
  {
    id: "method",
    num: "注",
    kicker: "METHOD",
    title: "方法说明",
    paras: [
      { t: "代码基线为分支 arena/d0fffdab 的提交 aa33a1a（2026-10-23）。所有「代码」类脚注均链接到该提交的具体行；「数据」类脚注指向数据包 JSON；「测试」类指向 JUnit 方法。" },
      { t: "「实算」类脚注使用的是本站 WIKI 中移植的 TypeScript 公式，此前已用已知值逐项与 Java 实装核对（书架门槛曲线、木架减免端点、锋利 V 门槛 18 扣 3 级、附魔之瓶门槛等）。蒙特卡洛按原版 1.21 附魔权重与等级区间复刻，每组 20 万次，假设玩家恰好停在门槛等级——这是对 mod 最不利的假设。" },
      { t: "「外部」类脚注来自各 mod 的官方页面或 README；「原版」类为 Mojang 代码中的公式，不属于本仓库。凡标为「推论」的内容，均为基于代码事实的合理推断，尚未在游戏内实测。" },
      { t: "顺带更正：上一页「措辞校准」中有 8 处行号当时未逐一核实（如 L233、L263、L42），其指出的事实本身正确，行号已在本次一并改为真实位置。" },
    ],
  },
];

/* ═══════════════ 脚注编号：按首次出现顺序 ═══════════════ */
const FN_MAP = Object.fromEntries(FOOTNOTES.map((f) => [f.id, f]));

const collectText = (s: Section) => [
  ...(s.theses ?? []).map((t) => t.v),
  ...(s.paras ?? []).map((p) => p.t),
  ...(s.compare?.rows ?? []).flatMap((r) => r.cells),
  ...(s.gaps ?? []).flatMap((g) => [g.body, g.fix]),
];

export const FN_ORDER: Footnote[] = (() => {
  const seen = new Set<string>();
  const out: Footnote[] = [];
  for (const s of SECTIONS)
    for (const txt of collectText(s))
      for (const m of txt.matchAll(/\[\[([a-z0-9_]+)\]\]/g)) {
        const id = m[1];
        if (!seen.has(id) && FN_MAP[id]) {
          seen.add(id);
          out.push(FN_MAP[id]);
        }
      }
  return out;
})();

export const FN_NUM: Record<string, number> = Object.fromEntries(FN_ORDER.map((f, i) => [f.id, i + 1]));
export const UNUSED_FN = FOOTNOTES.filter((f) => !FN_NUM[f.id]).map((f) => f.id);
